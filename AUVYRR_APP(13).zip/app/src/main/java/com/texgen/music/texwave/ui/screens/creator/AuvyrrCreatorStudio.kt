package com.texgen.music.texwave.ui.screens.creator

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens

/**
 * AUVYRR CREATOR STUDIO
 *
 * Unified creative entry that routes into existing first-class editors
 * (Music Editor / Veltrix / Tag Editor / etc.) instead of duplicating them.
 *
 * Workflow emphasis: CREATE → EDIT → PREVIEW → ORGANIZE → EXPORT
 */
@Composable
fun AuvyrrCreatorStudio(
    onOpenMusicEditor: () -> Unit = {},
    onOpenVeltrix: () -> Unit = {},
    onOpenTagEditor: () -> Unit = {},
    onOpenVault: () -> Unit = {},
    onOpenEqualizer: () -> Unit = {},
    onBack: () -> Unit = {},
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(TexTokens.Bg)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = TexTokens.space20, vertical = TexTokens.space16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(TexTokens.Elevated.copy(alpha = 0.85f))
            ) {
                Icon(Icons.Rounded.ArrowBack, null, tint = TexTokens.TextPrimary, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "CREATOR STUDIO",
                    color = TexTokens.Magenta,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
                Text(
                    "Make something",
                    color = TexTokens.TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(start = TexTokens.space20, top = 0.dp, end = TexTokens.space20, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "WORKFLOW",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp
                )
            }

            item {
                WorkflowStrip()
            }

            item {
                Text(
                    "EDITORS",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            item {
                StudioEntry(
                    icon = Icons.Rounded.MusicNote,
                    title = "Music Editor",
                    subtitle = "Primary composition & arrangement",
                    accent = TexTokens.Magenta,
                    primary = true,
                    onClick = onOpenMusicEditor
                )
            }
            item {
                StudioEntry(
                    icon = Icons.Rounded.AutoAwesome,
                    title = "Veltrix",
                    subtitle = "Automation & generative flows",
                    accent = TexTokens.Violet,
                    onClick = onOpenVeltrix
                )
            }
            item {
                StudioEntry(
                    icon = Icons.Rounded.Label,
                    title = "Tag Editor",
                    subtitle = "Metadata, artwork, organization",
                    accent = TexTokens.Cyan,
                    onClick = onOpenTagEditor
                )
            }
            item {
                StudioEntry(
                    icon = Icons.Rounded.Equalizer,
                    title = "Equalizer",
                    subtitle = "Playback tone shaping",
                    accent = Color(0xFF3DFFB0),
                    onClick = onOpenEqualizer
                )
            }

            item {
                Text(
                    "ORGANIZE & EXPORT",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            item {
                StudioEntry(
                    icon = Icons.Rounded.Folder,
                    title = "Open Vault",
                    subtitle = "Projects, exports, discoveries",
                    accent = TexTokens.Violet,
                    onClick = onOpenVault
                )
            }

            item {
                Text(
                    "Music Editor remains the first-class creative surface. Creator Studio only organizes entry points and the overall CREATE → EXPORT path.",
                    color = TexTokens.TextSecondary.copy(0.7f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 12.dp, bottom = 24.dp)
                )
            }
        }
    }
}

@Composable
private fun WorkflowStrip() {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(TexTokens.Surface)
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        listOf("Create", "Edit", "Preview", "Organize", "Export").forEachIndexed { i, step ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TexTokens.Magenta.copy(0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("${i + 1}", color = TexTokens.Magenta, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(4.dp))
                Text(step, color = TexTokens.TextSecondary, fontSize = 10.sp)
            }
            if (i < 4) {
                Icon(
                    Icons.Rounded.ChevronRight,
                    null,
                    tint = TexTokens.TextSecondary.copy(0.4f),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
private fun StudioEntry(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    primary: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (primary) TexTokens.Elevated else TexTokens.Surface)
            .border(
                1.dp,
                if (primary) accent.copy(0.35f) else TexTokens.Outline,
                RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(accent.copy(0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TexTokens.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TexTokens.TextSecondary, fontSize = 12.sp)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = TexTokens.TextSecondary, modifier = Modifier.size(18.dp))
    }
}
