package com.texgen.music.texwave.ui.screens.devicehub

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens

/**
 * AUVYRR DEVICE HUB
 *
 * Coherent surface over the existing protocol / headphone work.
 * Principle: DISCOVER → HYPOTHESIZE → TEST SAFELY → VERIFY → REPORT
 *
 * This screen does not invent capabilities. It presents state and routes
 * into the real protocol engines already present in the project.
 */
@Composable
fun AuvyrrDeviceHub(
    isBluetoothOn: Boolean = false,
    connectedDeviceName: String? = null,
    connectedDeviceAddress: String? = null,
    batteryPercent: Int? = null,
    supportedCapabilities: List<String> = emptyList(),
    lastVerificationResult: String? = null,
    onDiscover: () -> Unit = {},
    onOpenProtocolLab: () -> Unit = {},
    onBack: () -> Unit = {},
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(TexTokens.Bg)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = TexTokens.space20, vertical = TexTokens.space16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(TexTokens.Elevated.copy(alpha = 0.85f))
            ) {
                Icon(Icons.Rounded.ArrowBack, null, tint = TexTokens.TextPrimary, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "DEVICE HUB",
                    color = TexTokens.Cyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
                Text(
                    "Headphones & Protocols",
                    color = TexTokens.TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(start = TexTokens.space20, top = 8.dp, end = TexTokens.space20, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Connection status
            item {
                ConnectionCard(
                    isBluetoothOn = isBluetoothOn,
                    deviceName = connectedDeviceName,
                    address = connectedDeviceAddress,
                    battery = batteryPercent
                )
            }

            item {
                Text(
                    "ACTIONS",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp
                )
            }

            item {
                ActionRow(
                    icon = Icons.Rounded.Search,
                    title = "Discover devices",
                    subtitle = "Scan for nearby supported hardware",
                    onClick = onDiscover
                )
            }

            item {
                ActionRow(
                    icon = Icons.Rounded.Science,
                    title = "Protocol Lab",
                    subtitle = "Safe capability testing & verification",
                    accent = Color(0xFFFFB020),
                    onClick = onOpenProtocolLab
                )
            }

            item {
                Text(
                    "CAPABILITIES",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            if (supportedCapabilities.isEmpty()) {
                item {
                    EmptyCapabilityCard()
                }
            } else {
                items(supportedCapabilities.size) { i ->
                    CapabilityChip(supportedCapabilities[i])
                }
            }

            if (lastVerificationResult != null) {
                item {
                    Text(
                        "LAST VERIFICATION",
                        color = TexTokens.TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.2.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                item {
                    Text(
                        lastVerificationResult,
                        color = TexTokens.TextPrimary,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(TexTokens.Surface)
                            .padding(14.dp)
                    )
                }
            }

            item {
                Text(
                    "AUVYRR never claims a feature works solely because a command was sent. " +
                        "Every capability follows Discover → Hypothesize → Test safely → Verify → Report.",
                    color = TexTokens.TextSecondary.copy(0.7f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 12.dp, bottom = 24.dp)
                )
            }
        }
    }
}

@Composable
private fun ConnectionCard(
    isBluetoothOn: Boolean,
    deviceName: String?,
    address: String?,
    battery: Int?
) {
    val connected = deviceName != null
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(TexTokens.radiusLg))
            .background(TexTokens.Elevated)
            .border(
                1.dp,
                if (connected) TexTokens.Cyan.copy(0.35f) else TexTokens.Outline,
                RoundedCornerShape(TexTokens.radiusLg)
            )
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (connected) TexTokens.Cyan.copy(0.15f)
                        else TexTokens.TextSecondary.copy(0.1f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Headphones,
                    null,
                    tint = if (connected) TexTokens.Cyan else TexTokens.TextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    deviceName ?: if (isBluetoothOn) "No device connected" else "Bluetooth off",
                    color = TexTokens.TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    when {
                        address != null -> address
                        !isBluetoothOn -> "Enable Bluetooth to discover"
                        else -> "Tap Discover to scan"
                    },
                    color = TexTokens.TextSecondary,
                    fontSize = 12.sp
                )
            }
            if (battery != null) {
                Text(
                    "$battery%",
                    color = when {
                        battery > 40 -> TexTokens.Success
                        battery > 15 -> Color(0xFFFFB020)
                        else -> TexTokens.Danger
                    },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun ActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color = TexTokens.Cyan,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TexTokens.Surface)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(accent.copy(0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TexTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = TexTokens.TextSecondary, fontSize = 12.sp)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = TexTokens.TextSecondary, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun CapabilityChip(name: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(TexTokens.Surface)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.CheckCircle, null, tint = TexTokens.Success, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(name, color = TexTokens.TextPrimary, fontSize = 13.sp)
    }
}

@Composable
private fun EmptyCapabilityCard() {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TexTokens.Surface)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "No verified capabilities yet.\nConnect a device and run Protocol Lab tests.",
            color = TexTokens.TextSecondary,
            fontSize = 13.sp,
            lineHeight = 18.sp
        )
    }
}
