# Build Fixes Applied — 2026-11-17

The previous CI build failed with three Kotlin compilation errors. All are resolved in this archive:

1. **TexwaveNotificationProvider.kt**
   - Removed unresolved `s.artOverride` reference.
   - `NotifMedia.loadSongArt` is now called without the named argument (default empty string).
   - Custom art is already handled earlier in `loadBase` via `cfg.customArt`.

2. **CosmicGl.kt**
   - Renamed `clearFocus()` → `clearBodyFocus()` so it no longer hides `GLSurfaceView.clearFocus()`.
   - The method was unused by any caller.

3. **VoiceInput.kt**
   - Explicitly typed the fallback lambda as `(String) -> Unit`.
   - Forced the body to evaluate to `Unit` (Handler.post returns Boolean; Kotlin 2.x treats the conversion as experimental otherwise).

No other changes. Re-run the GitHub Actions workflow (or local `./gradlew :app:assembleDebug`) to verify the debug APK builds cleanly.
