# AUVYRR Final Modules — Integration Guide

## 1. Copy the new packages

Copy these directories into the existing project under:

`app/src/main/java/com/texgen/music/texwave/ui/screens/`

- `nexus/`
- `security/`
- `devicehub/`
- `vault/`
- `lab/`
- `creator/`
- `intelligence/`

They depend only on:
- `com.texgen.music.texwave.ui.theme.TexTokens`
- Standard Compose Material3 + Icons.Rounded

## 2. Minimal wiring example (MusicApp-style)

```kotlin
// state
var showNexus by rememberSaveable { mutableStateOf(false) }
var showSecurity by rememberSaveable { mutableStateOf(false) }
var showDeviceHub by rememberSaveable { mutableStateOf(false) }
var showVault by rememberSaveable { mutableStateOf(false) }
var showLab by rememberSaveable { mutableStateOf(false) }
var showCreatorStudio by rememberSaveable { mutableStateOf(false) }
var showIntelligence by rememberSaveable { mutableStateOf(false) }

// somewhere in the existing "More" / cockpit / dock menu:
MoreItem("Nexus", ..., "Command center") { showNexus = true }

// overlays (same pattern used for Phantom, Arena, etc.)
if (showNexus) {
    AuvyrrNexusScreen(
        nowPlayingTitle = currentSong?.title,
        nowPlayingArtist = currentSong?.artist,
        isPlaying = playerState.isPlaying,
        recentProjectCount = vaultProjectCount,
        achievementCount = xpState.achievementsUnlocked,
        deviceConnected = protocolState.hasDevice,
        deviceName = protocolState.deviceName,
        securityScore = /* from SecurityCenter helper or 80 */,
        onNavigate = { dest ->
            showNexus = false
            when (dest) {
                NexusDestination.NowPlaying -> { /* expand player */ }
                NexusDestination.Library -> navigate(NavTarget.Library)
                NexusDestination.Cosmic -> showConstellation = true // or existing universe flag
                NexusDestination.CreatorStudio -> showCreatorStudio = true
                NexusDestination.Intelligence -> showIntelligence = true
                NexusDestination.Veltrix -> showVeltrix = true
                NexusDestination.Security -> showSecurity = true
                NexusDestination.DeviceHub -> showDeviceHub = true
                NexusDestination.Vault -> showVault = true
                NexusDestination.Lab -> showLab = true
                NexusDestination.Arena -> showArena = true
                NexusDestination.Social -> showCommunity = true
                // ...
                else -> {}
            }
        },
        onBack = { showNexus = false }
    )
}

if (showSecurity) {
    AuvyrrSecurityCenter(
        onBack = { showSecurity = false },
        onOpenAppSettings = {
            // Intent to application details settings
        }
    )
}

if (showDeviceHub) {
    AuvyrrDeviceHub(
        isBluetoothOn = bluetoothAdapter?.isEnabled == true,
        connectedDeviceName = protocolManager.currentDevice?.name,
        connectedDeviceAddress = protocolManager.currentDevice?.address,
        batteryPercent = protocolManager.currentDevice?.battery,
        supportedCapabilities = protocolManager.verifiedCapabilities.map { it.label },
        lastVerificationResult = protocolManager.lastReport?.summary,
        onDiscover = { protocolManager.startDiscovery() },
        onOpenProtocolLab = { showLab = true /* or specific protocol lab */ },
        onBack = { showDeviceHub = false }
    )
}

// similarly for Vault, Lab, CreatorStudio, Intelligence
```

## 3. Recommended placement in product navigation

- **Nexus** — primary entry from home / dock / long-press logo / “Command” item in More.
- **Creator Studio** — from Nexus Create pillar and from existing creative entry points.
- **Device Hub** — replace or wrap any previous scattered earbud / protocol screens.
- **Security** — under Settings or Protect pillar.
- **Vault** — under Organize / Library secondary actions.
- **Lab** — under More → Experimental (already has Universe Lab / Phantom Lab style entries).
- **Intelligence** — floating action or dedicated tab / Nexus pillar.

## 4. Do not

- Duplicate Music Editor, Veltrix, Cosmic Explorer, or Protocol engines.
- Claim headphone features without going through the existing verification pipeline.
- Add fake antivirus or network “threat” detectors.

## 5. Build

No new dependencies. After copy:

```bash
./gradlew :app:assembleDebug
```

Wire one screen at a time and verify navigation round-trips.
