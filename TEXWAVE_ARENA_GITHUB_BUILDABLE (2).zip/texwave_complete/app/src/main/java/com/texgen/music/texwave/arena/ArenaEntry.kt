package com.texgen.music.texwave.arena

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import com.texgen.music.texwave.arena.data.repository.ArenaModule
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.ui.navigation.ArenaRoot

/**
 * Public entry point for TEXWAVE ARENA.
 *
 * Production wiring (from TEXWAVE Application / DI):
 * ```
 * ArenaModule.initSupabase(TexwaveSupabaseArenaClient)
 * ```
 * or pass repository explicitly:
 * ```
 * ArenaEntry(repository = SupabaseArenaRepository(client))
 * ```
 *
 * Demo / UI tests only:
 * ```
 * ArenaModule.initLocalDemo()
 * ```
 */
@Composable
fun ArenaEntry(
    modifier: Modifier = Modifier,
    onClose: (() -> Unit)? = null,
    repository: ArenaRepository? = null
) {
    LaunchedEffect(repository) {
        if (repository != null) {
            ArenaModule.init(repository)
        }
        // Load authoritative state on open
        ArenaModule.repository.refreshHome()
    }

    ArenaRoot(
        modifier = modifier,
        onClose = onClose
    )
}
