package com.texgen.music.texwave.arena.data.repository

import com.texgen.music.texwave.arena.data.supabase.SupabaseArenaClient

/**
 * Process-wide repository holder for Arena.
 *
 * Production (TEXWAVE):
 *   ArenaModule.init(SupabaseArenaRepository(texwaveSupabaseClient))
 *
 * UI preview / offline:
 *   ArenaModule.init(LocalArenaRepository())  // or leave default
 *
 * Screens and ViewModels MUST call ArenaModule.repository — never construct
 * LocalArenaRepository() inline in production paths.
 */
object ArenaModule {
    @Volatile
    private var repo: ArenaRepository = LocalArenaRepository()

    @Volatile
    private var mode: Mode = Mode.LOCAL_DEMO

    enum class Mode { LOCAL_DEMO, SUPABASE }

    fun init(repository: ArenaRepository, mode: Mode = Mode.SUPABASE) {
        this.repo = repository
        this.mode = mode
    }

    fun initLocalDemo() {
        init(LocalArenaRepository(), Mode.LOCAL_DEMO)
    }

    fun initSupabase(client: SupabaseArenaClient) {
        init(SupabaseArenaRepository(client), Mode.SUPABASE)
    }

    val repository: ArenaRepository get() = repo
    val isDemo: Boolean get() = mode == Mode.LOCAL_DEMO
}
