package com.texgen.music.texwave.arena.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsGymnastics
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Leaderboard
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SportsGymnastics
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.texgen.music.texwave.arena.ui.achievements.AchievementsScreen
import com.texgen.music.texwave.arena.ui.camera.CameraWorkoutScreen
import com.texgen.music.texwave.arena.ui.warrior.WarriorSelectScreen
import com.texgen.music.texwave.arena.ui.battle.MatchmakingScreen
import com.texgen.music.texwave.arena.ui.battle.ChampionshipArenaScreen
import com.texgen.music.texwave.arena.ui.battle.OnlineMatchScreen
import com.texgen.music.texwave.arena.data.model.WarriorProfile
import com.texgen.music.texwave.arena.data.model.WarriorLoadout
import com.texgen.music.texwave.arena.domain.RankSystem
import com.texgen.music.texwave.arena.ui.challenges.ChallengesScreen
import com.texgen.music.texwave.arena.ui.leaderboard.LeaderboardScreen
import com.texgen.music.texwave.arena.ui.squads.SquadsScreen
import com.texgen.music.texwave.arena.ui.home.ArenaHomeScreen
import com.texgen.music.texwave.arena.ui.missions.MissionsScreen
import com.texgen.music.texwave.arena.ui.history.ActivityHistoryScreen
import com.texgen.music.texwave.arena.ui.logging.LogActivityScreen
import com.texgen.music.texwave.arena.ui.profile.ArenaProfileScreen
import com.texgen.music.texwave.arena.ui.theme.ArenaColors

/**
 * All Arena destinations.
 * Additional detail routes (challenge detail, squad detail, etc.) will be added in later parts.
 */
sealed class ArenaRoute(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    data object Home : ArenaRoute(
        "arena_home", "Arena",
        Icons.Filled.Home, Icons.Outlined.Home
    )
    data object Challenges : ArenaRoute(
        "arena_challenges", "Challenges",
        Icons.Filled.SportsGymnastics, Icons.Outlined.SportsGymnastics
    )
    data object Leaderboard : ArenaRoute(
        "arena_leaderboard", "Ranks",
        Icons.Filled.Leaderboard, Icons.Outlined.Leaderboard
    )
    data object Squads : ArenaRoute(
        "arena_squads", "Squads",
        Icons.Filled.Groups, Icons.Outlined.Groups
    )
    data object Profile : ArenaRoute(
        "arena_profile", "Profile",
        Icons.Filled.Person, Icons.Outlined.Person
    )
    data object Achievements : ArenaRoute(
        "arena_achievements", "Badges",
        Icons.Filled.EmojiEvents, Icons.Outlined.EmojiEvents
    )
    data object Missions : ArenaRoute(
        "arena_missions", "Missions",
        Icons.Filled.TaskAlt, Icons.Outlined.TaskAlt
    )
    data object History : ArenaRoute(
        "arena_history", "History",
        Icons.Filled.History, Icons.Outlined.History
    )
}

val arenaBottomRoutes = listOf(
    ArenaRoute.Home,
    ArenaRoute.Challenges,
    ArenaRoute.Leaderboard,
    ArenaRoute.Squads,
    ArenaRoute.Profile
)

/**
 * Root composable for the entire Arena module.
 * Can be opened from TEXWAVE SideNav / bottom nav without touching other modules.
 */
@Composable
fun ArenaRoot(
    modifier: Modifier = Modifier,
    onClose: (() -> Unit)? = null
) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = ArenaColors.Bg,
        bottomBar = {
            ArenaBottomBar(
                currentRoute = currentRoute,
                onNavigate = { route ->
                    navController.navigate(route.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = ArenaRoute.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(ArenaRoute.Home.route) {
                ArenaHomeScreen(
                    onOpenTraining = { navController.navigate("arena_log") },
                    onOpenCamera = { navController.navigate("arena_camera") },
                    onOpenChampionship = { navController.navigate("arena_online") },
                    onOpenWarrior = { navController.navigate("arena_warrior") },
                    onOpenRanks = { navController.navigate(ArenaRoute.Leaderboard.route) },
                    onOpenChallenges = { navController.navigate(ArenaRoute.Challenges.route) },
                    onOpenAchievements = { navController.navigate(ArenaRoute.Achievements.route) },
                    onOpenSquads = { navController.navigate(ArenaRoute.Squads.route) }
                )
            }

            composable(ArenaRoute.Challenges.route) {
                ChallengesScreen()
            }
            composable(ArenaRoute.Leaderboard.route) {
                LeaderboardScreen()
            }
            composable(ArenaRoute.Squads.route) {
                SquadsScreen()
            }
            composable(ArenaRoute.Profile.route) {
                ArenaProfileScreen(
                    onOpenHistory = { navController.navigate(ArenaRoute.History.route) },
                    onOpenLog = { navController.navigate("arena_log") },
                    onOpenCamera = { navController.navigate("arena_camera") }
                )
            }
            composable(ArenaRoute.Achievements.route) {
                AchievementsScreen()
            }
            composable(ArenaRoute.Missions.route) {
                MissionsScreen()
            }
            composable(ArenaRoute.History.route) {
                ActivityHistoryScreen()
            }
            // Log session (modal-style full screen)
            composable("arena_warrior") {
                val w = WarriorProfile(userId = "local", username = "phantom_rider", level = 12, rank = RankSystem.RankTier.D)
                WarriorSelectScreen(profile = w, onSave = { navController.popBackStack() }, onClose = { navController.popBackStack() })
            }
            composable("arena_online") {
                OnlineMatchScreen(onClose = { navController.popBackStack() })
            }
            composable("arena_matchmaking") {
                val w = WarriorProfile(userId = "local", username = "phantom_rider", level = 12, rank = RankSystem.RankTier.D, competitiveRating = 1120)
                var opp by remember { mutableStateOf<Triple<String, Int, Boolean>?>(null) }
                if (opp == null) {
                    MatchmakingScreen(me = w, onMatched = { n,l,win -> opp = Triple(n,l,win) }, onClose = { navController.popBackStack() })
                } else {
                    ChampionshipArenaScreen(me = w, opponentName = opp!!.first, opponentLevel = opp!!.second, didWin = opp!!.third, onFinished = { navController.popBackStack() })
                }
            }
            composable("arena_camera") {
                CameraWorkoutScreen(onClose = { navController.popBackStack() })
            }
            composable("arena_log") {
                LogActivityScreen(
                    onClose = { navController.popBackStack() },
                    onLogged = { /* stay open so user sees success, or pop if preferred */ }
                )
            }
        }
    }
}

@Composable
private fun ArenaBottomBar(
    currentRoute: String?,
    onNavigate: (ArenaRoute) -> Unit
) {
    NavigationBar(
        containerColor = ArenaColors.Surface.copy(alpha = 0.96f),
        contentColor = ArenaColors.Text
    ) {
        arenaBottomRoutes.forEach { route ->
            val selected = currentRoute == route.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(route) },
                icon = {
                    Icon(
                        imageVector = if (selected) route.selectedIcon else route.unselectedIcon,
                        contentDescription = route.label
                    )
                },
                label = {
                    Text(
                        text = route.label,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ArenaColors.Cyan,
                    selectedTextColor = ArenaColors.Cyan,
                    unselectedIconColor = ArenaColors.Muted,
                    unselectedTextColor = ArenaColors.Muted,
                    indicatorColor = ArenaColors.Cyan.copy(alpha = 0.12f)
                )
            )
        }
    }
}

@Composable
private fun ArenaPlaceholder(title: String, subtitle: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                text = title,
                color = ArenaColors.Text,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = subtitle,
                color = ArenaColors.Muted,
                fontSize = 14.sp
            )
        }
    }
}
