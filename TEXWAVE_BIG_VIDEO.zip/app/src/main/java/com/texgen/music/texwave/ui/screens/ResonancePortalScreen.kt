package com.texgen.music.texwave.ui.screens

import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.glassCard
import com.texgen.music.texwave.ui.components.glassShimmer
import com.texgen.music.texwave.ui.components.softFloat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Size
import com.texgen.music.texwave.ui.components.CaughtUpCard
import com.texgen.music.texwave.ui.components.DropRing
import com.texgen.music.texwave.ui.components.EngageStore
import com.texgen.music.texwave.ui.components.FeedSongCard
import com.texgen.music.texwave.ui.components.GalaxyBackdrop
import com.texgen.music.texwave.ui.components.StreakChip
import com.texgen.music.texwave.ui.components.buildDrops
import com.texgen.music.texwave.ui.components.buildFeed
import com.texgen.music.texwave.ui.components.TwinkleField
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable
import com.texgen.music.texwave.ui.components.rememberUiSound
import com.texgen.music.texwave.util.UiSound
import kotlin.math.cos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.EmotionMode
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.Artwork
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.sin

private val HomeBg = Color(0xFF040406)
private val Cyan = Tx.Accent2
private val Violet = Tx.Accent
private val Pink = Color(0xFFE040C0)
private val MutedText = Color(0xFF8A8F9C)

private class MoodCard(
    val mode: EmotionMode,
    val title: String,
    val subtitle: String,
    val art: Int,
    val edge: Color,
    val subtitleColor: Color,
)

/**
 * Home — "The Universe Awaits".
 * Matches the first screen of the TEXWAVE concept board: header + waveform, hero artwork with the
 * greeting overlaid, MoodWave cards and a Recently Played card, above the shared bottom nav bar.
 */
@Composable
fun ResonancePortalScreen(
    lib: LibraryState,
    player: PlayerState,
    position: State<Long>,
    reducedMotion: Boolean = false,
    onOpenNowPlaying: () -> Unit,
    onBeginWave: () -> Unit,
    onDiscover: () -> Unit,
    onLibrary: () -> Unit,
    onPhantom: () -> Unit,
    onContinue: (Song) -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onEmotion: (EmotionMode) -> Unit = {},
    onOpenSignature: () -> Unit = {},
    onPlayList: (List<Song>) -> Unit = {},
    onToggleLike: (Long) -> Unit = {},
    onOpenConstellation: () -> Unit = {},
    onOpenRadar: () -> Unit = {},
    onOpenStreamLibrary: () -> Unit = {},
    onOpenCommunity: () -> Unit = {},
    onOpenDownloads: () -> Unit = {},
) {
    val current = player.current
    val ctx = LocalContext.current
    val sound = rememberUiSound()
    val recent: Song? = remember(lib.recents, lib.songs, current) {
        current ?: lib.recents.firstNotNullOfOrNull { id -> lib.songs.find { it.id == id } }
    }
    val greeting = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 5..11 -> "Good morning,"
            in 12..16 -> "Good afternoon,"
            in 17..21 -> "Good evening,"
            else -> "Good night,"
        }
    }
    val moods = remember {
        listOf(
            MoodCard(EmotionMode.RAINY_NIGHT, "Rainy Night", "Calm & Cozy", R.drawable.mood_rainy, Color(0xFF3A7BFF), Color(0xFF8FB4FF)),
            MoodCard(EmotionMode.UNSTOPPABLE, "Unstoppable", "Energy Boost", R.drawable.mood_unstoppable, Color(0xFFE23A4A), Color(0xFFFF9A8A)),
            MoodCard(EmotionMode.FOCUS, "Deep Focus", "Study & Work", R.drawable.mood_focus, Color(0xFF2FA8FF), Color(0xFF8FD4FF)),
            MoodCard(EmotionMode.LET_ME_THINK, "After Hours", "Chill & Reflect", R.drawable.mood_afterhours, Color(0xFF8A4CFF), Color(0xFFC9A4FF)),
        )
    }

    // ── engagement layer: daily streak, story-style drops, For-you feed ──
    var streak by remember { mutableIntStateOf(EngageStore.streak(ctx)) }
    LaunchedEffect(Unit) { streak = EngageStore.touchStreak(ctx) }
    var seenDrops by remember { mutableStateOf(EngageStore.seenDrops(ctx)) }
    val day = remember { EngageStore.today() }
    val drops = remember(lib.songs) { buildDrops(lib.songs, lib.liked, lib.playCounts, day) }
    var feedRound by rememberSaveable { mutableIntStateOf(0) }
    // keyed on the library size + round only, so cards never swap under your thumb while you listen
    val feed = remember(lib.songs.size, feedRound) { buildFeed(lib.songs, lib.liked, lib.playCounts, day * 31L + feedRound) }

    Box(Modifier.fillMaxSize().background(HomeBg)) {
        // faint static starfield + violet bloom behind the header
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x18401A80), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.2f),
                    radius = size.width * 0.8f,
                ),
                radius = size.width * 0.8f,
                center = Offset(size.width * 0.5f, size.height * 0.2f),
            )
            for (i in 0 until 40) {
                val sx = ((i * 97 + 13) % 1000) / 1000f * size.width
                val sy = ((i * 53 + 29) % 1000) / 1000f * size.height
                drawCircle(
                    Color.White.copy(alpha = 0.06f + (i % 5) * 0.035f),
                    (0.5f + (i % 3) * 0.35f) * density,
                    Offset(sx, sy),
                )
            }
        }

        // the intro's galaxy keeps turning, very quietly, behind the content
        if (!reducedMotion) GalaxyBackdrop(Modifier.fillMaxSize())

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState()),
        ) {
            // ───────────── Hero: header + artwork + greeting + actions ─────────────
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .clickable { if (current != null) onOpenNowPlaying() else onBeginWave() },
            ) {
                Image(
                    painter = painterResource(R.drawable.home_hero),
                    contentDescription = null,
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier.fillMaxSize(),
                )

                // Full hero image — no orbiting ring/dot overlay

                // brand header — clean, exact match to reference
                Column(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        "TEXWAVE",
                        style = TextStyle(
                            brush = Brush.horizontalGradient(
                                listOf(Color(0xFFFFB8F0), Color(0xFFE8E0FF), Color(0xFF7FE8FF), Tx.Accent2)
                            ),
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Light,
                            letterSpacing = 10.sp,
                            shadow = Shadow(Color(0x883DE0FF), Offset.Zero, 12f),
                        ),
                    )
                    Spacer(Modifier.height(3.dp))
                    // simple thin wave line (not the busy animated glyph)
                    Canvas(Modifier.width(120.dp).height(12.dp)) {
                        val cy = size.height / 2f
                        val path = Path()
                        path.moveTo(0f, cy)
                        var x = 0f
                        while (x <= size.width) {
                            path.lineTo(x, cy + kotlin.math.sin(x * 0.12f) * 3.2f * density)
                            x += 2.5f
                        }
                        drawPath(path, Tx.Accent2.copy(alpha = 0.7f), style = Stroke(width = 1.4f * density, cap = StrokeCap.Round))
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "Your sound. Your people. Your universe.",
                        color = MutedText,
                        fontSize = 11.sp,
                    )
                }

                // phantom orb (top-right)
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 12.dp, end = 16.dp)
                        .size(38.dp)
                        .shadow(10.dp, CircleShape, ambientColor = Violet, spotColor = Cyan)
                        .clip(CircleShape)
                        .border(
                            1.5.dp,
                            Brush.sweepGradient(listOf(Cyan, Violet, Pink, Cyan)),
                            CircleShape,
                        )
                        .pressable { sound(UiSound.Kind.TAB); onPhantom() },
                ) {
                    com.texgen.music.texwave.ui.components.PhantomAvatar(Modifier.fillMaxSize(), 96.dp)
                }

                // greeting + primary actions, overlaid on the dark foreground
                Column(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(bottom = 18.dp),
                ) {
                    Text(
                        greeting,
                        color = Color.White,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(start = 26.dp),
                    )
                    Text(
                        "Let the music find you.",
                        color = MutedText,
                        fontSize = 11.5.sp,
                        modifier = Modifier.padding(start = 26.dp, top = 2.dp),
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(
                        Modifier.fillMaxWidth().padding(start = 26.dp, end = 30.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier
                                .size(58.dp)
                                .shadow(20.dp, CircleShape, ambientColor = Violet, spotColor = Cyan)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF2EC8FF), Tx.Accent, Color(0xFFE040C0)),
                                        start = Offset(0f, 0f),
                                        end = Offset(160f, 160f),
                                    )
                                )
                                .border(1.5.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                                .pressable {
                                    sound(if (player.isPlaying) UiSound.Kind.PAUSE else UiSound.Kind.PLAY)
                                    if (current != null) onToggle() else onBeginWave()
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (player.isPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp),
                            )
                        }
                        Spacer(Modifier.width(18.dp))
                        Icon(
                            Icons.Rounded.ArrowForward,
                            contentDescription = null,
                            tint = Cyan,
                            modifier = Modifier.size(14.dp).alpha(0.35f),
                        )
                        Spacer(Modifier.weight(1f))
                        Row(
                            Modifier
                                .height(42.dp)
                                .clip(RoundedCornerShape(22.dp))
                                .background(Color(0x551F1F21))
                                .border(
                                    1.2.dp,
                                    Brush.horizontalGradient(listOf(Color(0xAA3DE0FF), Color(0x888A5CFF))),
                                    RoundedCornerShape(22.dp),
                                )
                                .pressable { sound(UiSound.Kind.TAB); onLibrary() }
                                .padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.MusicNote, null, tint = Cyan, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("Your Library", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ───────────── Quick discovery: give the first screen a clear next step ─────────────
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(74.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF2B2B2D), Color(0xFF161618))))
                        .border(1.dp, Cyan.copy(alpha = 0.28f), RoundedCornerShape(18.dp))
                        .pressable { sound(UiSound.Kind.TAB); onDiscover() }
                        .padding(horizontal = 13.dp, vertical = 11.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("DISCOVER", color = Cyan, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                        Text("Find your next wave  ›", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
                Box(
                    Modifier
                        .weight(1f)
                        .height(74.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF29292B), Color(0xFF161618))))
                        .border(1.dp, Violet.copy(alpha = 0.32f), RoundedCornerShape(18.dp))
                        .pressable { sound(UiSound.Kind.TAB); onLibrary() }
                        .padding(horizontal = 13.dp, vertical = 11.dp),
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("YOUR MUSIC", color = Color(0xFFC3A5FF), fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                        Text("Jump back into sound  ›", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))


            // ───────────── Projected universe destinations ─────────────
            Text(
                "EXPLORE",
                color = Color(0xFF9AA3C2),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.6.sp,
                modifier = Modifier.padding(horizontal = 18.dp).appear(40),
            )
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp)
                    .appear(80),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                data class Dest(val title: String, val sub: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val go: () -> Unit)
                val dests = listOf(
                    Dest("Constellation", "Star map", Icons.Rounded.AutoAwesome, onOpenConstellation),
                    Dest("Radar", "Pulse mix", Icons.Rounded.TrackChanges, onOpenRadar),
                    Dest("Online", "Stream", Icons.Rounded.LibraryMusic, onOpenStreamLibrary),
                    Dest("Community", "Photos", Icons.Rounded.Image, onOpenCommunity),
                    Dest("Downloads", "Offline", Icons.Rounded.CloudDownload, onOpenDownloads),
                )
                dests.forEach { d ->
                    Column(
                        Modifier
                            .width(108.dp)
                            .softFloat(2.5f, 2800 + d.title.length * 40)
                            .glassCard(16)
                            .glassShimmer(16)
                            .pressable { sound(UiSound.Kind.TAB); d.go() }
                            .padding(12.dp),
                    ) {
                        Icon(d.icon, null, tint = Cyan, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.height(10.dp))
                        Text(d.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(d.sub, color = MutedText, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))

            // ───────────── Today's drops (story-style rings) + streak ─────────────
            if (drops.isNotEmpty()) {
                Row(
                    Modifier.appear(60).fillMaxWidth().padding(start = 18.dp, end = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Today's drops", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                        val left = drops.count { it.id !in seenDrops }
                        Text(
                            if (left == 0) "All opened — come back tomorrow" else "$left new, tap to play",
                            color = MutedText, fontSize = 11.5.sp, modifier = Modifier.padding(top = 2.dp),
                        )
                    }
                    StreakChip(streak)
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier
                        .appear(120)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    drops.forEach { d ->
                        DropRing(
                            drop = d,
                            seen = d.id in seenDrops,
                            onClick = {
                                EngageStore.markSeen(ctx, d.id)
                                seenDrops = seenDrops + d.id
                                sound(UiSound.Kind.OPEN)
                                onPlayList(d.songs)
                            },
                        )
                    }
                }
                Spacer(Modifier.height(22.dp))
            }

            // ───────────── MoodWave ─────────────
            SectionHeader("MOODWAVE", "Choose a vibe. Feel the wave.", onViewAll = { sound(UiSound.Kind.TAB); onDiscover() }, modifier = Modifier.appear(150))
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier
                    .appear(260)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                moods.forEach { m ->
                    Box(
                        Modifier
                            .width(96.dp)
                            .height(118.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .border(1.2.dp, m.edge.copy(alpha = 0.85f), RoundedCornerShape(18.dp))
                            .pressable(0.92f) { sound(UiSound.Kind.SELECT); onEmotion(m.mode) },
                    ) {
                        Image(
                            painter = painterResource(m.art),
                            contentDescription = m.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                        // bottom gradient for text readability
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, Color(0xCC000000)),
                                        startY = 50f
                                    )
                                )
                        )
                        Column(
                            Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = 9.dp, end = 6.dp, bottom = 10.dp),
                        ) {
                            Text(
                                m.title,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Clip,
                            )
                            Text(
                                m.subtitle,
                                color = m.subtitleColor,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Clip,
                            )
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
            }

            Spacer(Modifier.height(30.dp))

            // ───────────── Recently Played ─────────────
            SectionHeader("Recently Played", null, onViewAll = { sound(UiSound.Kind.TAB); onLibrary() }, modifier = Modifier.appear(380))
            Spacer(Modifier.height(12.dp))
            if (recent == null) {
                Text(
                    "Nothing played yet — start a wave above",
                    color = MutedText.copy(alpha = 0.7f),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            } else {
                val isNow = current?.id == recent.id
                val shape = RoundedCornerShape(20.dp)
                Box(
                    Modifier
                        .appear(460)
                        .padding(horizontal = 13.dp)
                        .fillMaxWidth()
                        .shadow(14.dp, shape, ambientColor = Violet.copy(alpha = 0.5f), spotColor = Cyan.copy(alpha = 0.3f))
                        .clip(shape)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF242426), Color(0xFF1C1C1E), Color(0xFF222224))
                            )
                        )
                        .border(
                            1.2.dp,
                            Brush.horizontalGradient(
                                listOf(Color(0xFFB05CFF), Color(0xFF3A8CFF), Tx.Accent2, Tx.Accent)
                            ),
                            shape,
                        )
                        .pressable(0.98f) { if (isNow) onOpenNowPlaying() else onContinue(recent) },
                ) {
                    Row(
                        Modifier.padding(start = 14.dp, end = 12.dp, top = 12.dp, bottom = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Artwork(recent, Modifier.size(44.dp), corner = 10.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                recent.title,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                recent.artist.ifBlank { "Unknown artist" },
                                color = MutedText,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Icon(
                            Icons.Rounded.ArrowForward, null, tint = Cyan,
                            modifier = Modifier.size(14.dp).alpha(0.3f),
                        )
                        Spacer(Modifier.width(10.dp))
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1A1A1C))
                                .border(
                                    2.dp,
                                    Brush.linearGradient(listOf(Tx.Accent2, Color(0xFF3A5CFF))),
                                    CircleShape,
                                )
                                .pressable { sound(if (isNow && player.isPlaying) UiSound.Kind.PAUSE else UiSound.Kind.PLAY); if (isNow) onToggle() else onContinue(recent) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (isNow && player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                        Icon(Icons.Rounded.ChevronRight, null, tint = Cyan, modifier = Modifier.size(22.dp))
                    }
                    // progress line along the bottom edge (state read only in the draw phase)
                    Canvas(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 14.dp)
                            .fillMaxWidth()
                            .height(10.dp),
                    ) {
                        val y = size.height - 3.dp.toPx()
                        val d = player.durationMs
                        val f = if (isNow && d > 0) (position.value.toFloat() / d).coerceIn(0f, 1f) else 0f
                        drawLine(
                            Color(0x22FFFFFF), Offset(0f, y), Offset(size.width, y),
                            strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round,
                        )
                        if (f > 0f) {
                            val x = size.width * f
                            drawLine(
                                Brush.horizontalGradient(listOf(Pink, Violet, Color(0xFF3A8CFF)), 0f, size.width),
                                Offset(0f, y), Offset(x, y),
                                strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round,
                            )
                            drawCircle(Color(0xFFE8E4FF), 3.5.dp.toPx(), Offset(x, y))
                        }
                    }
                }
            }

            // ───────────── For you (feed) ─────────────
            if (feed.isNotEmpty()) {
                Spacer(Modifier.height(30.dp))
                SectionHeader("For you", "Tap to play. Double-tap to love.", onViewAll = { sound(UiSound.Kind.TAB); onLibrary() })
                Spacer(Modifier.height(14.dp))
                Column(Modifier.padding(horizontal = 13.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    feed.forEachIndexed { i, item ->
                        val isCur = current?.id == item.song.id
                        FeedSongCard(
                            item = item,
                            liked = item.song.id in lib.liked,
                            isCurrent = isCur,
                            isPlaying = isCur && player.isPlaying,
                            plays = lib.playCounts[item.song.id] ?: 0,
                            // playing from a card continues down the feed, like scrolling a playlist
                            onPlay = { if (isCur) onToggle() else onPlayList(feed.drop(i).map { it.song }) },
                            onToggleLike = { onToggleLike(item.song.id) },
                        )
                    }
                    CaughtUpCard(onRefresh = { feedRound++ })
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String?, onViewAll: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(start = 18.dp, end = 16.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            if (subtitle != null) {
                Text(subtitle, color = MutedText, fontSize = 11.5.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
        Row(
            Modifier
                .padding(top = 3.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onViewAll)
                .padding(start = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("View all", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Icon(Icons.Rounded.ChevronRight, null, tint = Cyan, modifier = Modifier.size(16.dp))
        }
    }
}

/** Cyan audio-wave glyph with a hairline that fades out on both sides; the spikes breathe. */
@Composable
private fun WaveGlyph(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "glyph")
    val phase = t.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "glyphPhase",
    )
    Canvas(modifier) {
        val p = phase.value
        val cy = size.height / 2f
        val cyan = Tx.Accent2
        drawLine(
            Brush.horizontalGradient(
                listOf(Color.Transparent, cyan.copy(alpha = 0.45f), Color.Transparent), 0f, size.width
            ),
            Offset(0f, cy), Offset(size.width, cy), strokeWidth = 1.dp.toPx(),
        )
        val n = 21
        val mid = size.width / 2f
        val span = size.width * 0.30f
        for (i in 0 until n) {
            val u = i / (n - 1f)
            val x = mid - span + 2f * span * u
            val env = 1f - abs(u - 0.5f) * 2f
            val h = (0.2f + 0.8f * abs(sin(i * 2.1f + 0.7f + p * (1 + i % 3)))) * env * (size.height * 0.5f)
            drawLine(
                cyan.copy(alpha = 0.35f + 0.65f * env),
                Offset(x, cy - h), Offset(x, cy + h),
                strokeWidth = 1.2.dp.toPx(), cap = StrokeCap.Round,
            )
        }
    }
}

/** Pulsing glow on the hero ring with a small light travelling around it. */
@Composable
private fun HeroRing(modifier: Modifier = Modifier, playing: Boolean) {
    val t = rememberInfiniteTransition(label = "heroRing")
    val pulse = t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(if (playing) 1800 else 3200), RepeatMode.Reverse),
        label = "ringPulse",
    )
    val orbit = t.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "ringOrbit",
    )
    Canvas(modifier) {
        // ring geometry matches the artwork: centre (0.5, 585/1160), radius 350/1080 of the width
        val c = Offset(size.width * 0.5f, size.height * (585f / 1160f))
        val r = size.width * (350f / 1080f)
        val k = pulse.value
        // Atomic-precision multi-layer ring matching the mockup circular frame
        drawCircle(Tx.Accent2.copy(alpha = 0.12f + 0.28f * k), r, c, style = Stroke(width = (9f + 12f * k) * density))
        drawCircle(Color(0xFFC08CFF).copy(alpha = 0.18f + 0.22f * k), r + 5f * density, c, style = Stroke(width = (4.5f + 5f * k) * density))
        drawCircle(Tx.Accent2.copy(alpha = 0.08f + 0.15f * k), r + 13f * density, c, style = Stroke(width = 2.5f * density))
        drawCircle(Color(0x66FFFFFF).copy(alpha = 0.04f + 0.06f * k), r + 22f * density, c, style = Stroke(width = 1.5f * density))
        val a = orbit.value
        val p = Offset(c.x + cos(a) * r, c.y + sin(a) * r)
        drawCircle(Color(0xFF9FF1FF).copy(alpha = 1f), 3.8f * density, p)
        drawCircle(Tx.Accent2.copy(alpha = 0.4f), 12f * density, p)
        drawCircle(Color(0xAAFFFFFF), 2f * density, p)
    }
}
