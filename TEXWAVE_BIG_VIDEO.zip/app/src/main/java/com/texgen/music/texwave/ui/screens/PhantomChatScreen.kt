package com.texgen.music.texwave.ui.screens

import com.texgen.music.texwave.data.PhantomMemoryStore
import com.texgen.music.texwave.ui.components.sonicAtmosphere

import androidx.compose.foundation.background
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.SpeechOut
import com.texgen.music.texwave.util.VoskModelManager
import androidx.compose.runtime.collectAsState
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.foundation.layout.fillMaxWidth
import com.texgen.music.texwave.util.VoiceInput
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: Long,
    val role: String,
    val text: String,
)

@Composable
fun PhantomChatScreen(
    online: Boolean,
    hasKey: Boolean,
    onBack: () -> Unit,
    onSaveKey: (String) -> Unit,
    onSend: suspend (userText: String, history: List<ChatMessage>) -> Result<String>,
    onSendImage: suspend (userText: String, bytes: ByteArray, mime: String) -> Result<String> = { _, _, _ ->
        Result.failure(IllegalStateException("Image not supported"))
    },
    initialMode: String = "chat",
) {
    // Offline mode is fully supported for music commands; online adds web + Groq.
    var showKey by remember { mutableStateOf(online && !hasKey) }
    var keyInput by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                0,
                "assistant",
                "I'm PHANTOM — created by SOIF STAR ⭐.\n\n• Say “play” + a song, a mood, or “surprise me”.\n• Ask about your taste or anything else.\n• Attach an image and ask me to analyze or guide edits.\n• With a Groq key I go fully online.\n\nTap a prompt below — or attach a photo.",
            )
        )
    }
    var listening by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var pendingImageBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingImageMime by remember { mutableStateOf("image/jpeg") }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null && bytes.isNotEmpty()) {
                pendingImageBytes = bytes
                pendingImageMime = mime
            }
        }
    }
    val voice = remember { VoiceInput(context) }
    val speaker = remember { SpeechOut(context) }
    var speakReplies by remember { mutableStateOf(true) }
    DisposableEffect(Unit) {
        onDispose {
            voice.release()
            speaker.shutdown()
        }
    }

    fun sendText(text: String) {
        if (busy) return
        val img = pendingImageBytes
        if (text.isBlank() && img == null) return
        scope.launch {
            busy = true
            val label = if (img != null) {
                (if (text.isBlank()) "[Image attached]" else text) + " 📷"
            } else text
            messages.add(ChatMessage(System.currentTimeMillis(), "user", label))
            val result = if (img != null) {
                val r = onSendImage(text, img, pendingImageMime)
                pendingImageBytes = null
                r
            } else {
                onSend(text, messages.toList())
            }
            val reply = result.getOrElse { e -> "Error: ${e.message}" }
            messages.add(ChatMessage(System.currentTimeMillis() + 1, "assistant", reply))
            if (speakReplies && !reply.startsWith("Error:")) speaker.speak(reply)
            busy = false
        }
    }

    fun startListen() {
        if (busy || listening) return
        if (!voice.hasPermission()) {
            messages.add(
                ChatMessage(
                    System.currentTimeMillis(),
                    "assistant",
                    "Microphone permission is needed. Allow mic access, then try again.",
                )
            )
            return
        }
        listening = true
        voice.start(
            preferOffline = voice.models.isReady(),
            onPartial = { draft = it },
            onResult = { text ->
                listening = false
                draft = text
                sendText(text)
            },
            onError = { err ->
                listening = false
                messages.add(ChatMessage(System.currentTimeMillis(), "assistant", "Voice: $err"))
            },
            onEnd = { listening = false },
        )
    }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    val chips = listOf(
        "What's playing?",
        "Play rainy night",
        "Infinite mix",
        "Who is the richest person?",
        "Explain my music taste",
    )

    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .statusBarsPadding()
            .imePadding()
            .navigationBarsPadding(),
    ) {
        // Header
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(Tx.Accent.copy(alpha = 0.35f), Tx.Accent2.copy(alpha = 0.25f), Color.Transparent)
                    )
                )
                .padding(horizontal = 4.dp, vertical = 6.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, null, tint = Tx.Text)
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        "PHANTOM · GLASS",
                        color = Tx.Text,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        when {
                            !online -> "Offline · music commands active"
                            hasKey -> "Online · full PHANTOM"
                            else -> "Online · set key for web chat"
                        },
                        color = if (!online || hasKey) Tx.Accent2 else Tx.Muted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                IconButton(onClick = { speakReplies = !speakReplies }) {
                    Icon(
                        Icons.Rounded.VolumeUp,
                        "Speak replies",
                        tint = if (speakReplies) Tx.Accent2 else Tx.Muted,
                    )
                }
                IconButton(onClick = { showKey = !showKey }) {
                    Icon(Icons.Rounded.Key, "API key", tint = Tx.Accent2)
                }
            }
        }

        if (showKey) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Tx.Surface)
                    .padding(14.dp),
            ) {
                Text("Groq API key", color = Tx.Text, style = MaterialTheme.typography.titleMedium)
                Text(
                    "Stored only on this phone. Get a free key at console.groq.com",
                    color = Tx.Muted,
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { keyInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("gsk_…", color = Tx.Muted) },
                    colors = fieldColors(),
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = {
                        onSaveKey(keyInput)
                        showKey = keyInput.isBlank()
                    }) { Text("Save key", color = Tx.Accent2) }
                }
            }
        }


        // Offline voice model (standard ~128MB or maximum ~4GB-class)
        val voskState by voice.models.state.collectAsState()
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Tx.Surface)
                .padding(12.dp),
        ) {
            Text(
                "Offline voice (Vosk)",
                color = Tx.Text,
                style = MaterialTheme.typography.titleSmall,
            )
            Text(
                if (voskState.ready) "Voice model ready — mic works offline."
                else "Download a model for offline wake-word & commands (Wi‑Fi recommended).",
                color = Tx.Muted,
                style = MaterialTheme.typography.bodySmall,
            )
            if (voskState.downloading) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { voskState.progress },
                    modifier = Modifier.fillMaxWidth(),
                    color = Tx.Accent2,
                )
                val mb = if (voskState.bytesTotal > 0)
                    "${voskState.bytesDownloaded / 1_000_000} / ${voskState.bytesTotal / 1_000_000} MB"
                else "${(voskState.progress * 100).toInt()}%"
                Text(mb, color = Tx.Muted, style = MaterialTheme.typography.labelSmall)
            } else {
                Spacer(Modifier.height(6.dp))
                TextButton(
                    onClick = {
                        scope.launch {
                            val r = voice.models.ensureModel(com.texgen.music.texwave.util.VoskModelManager.ModelPack.STANDARD)
                            messages.add(
                                ChatMessage(
                                    System.currentTimeMillis(),
                                    "assistant",
                                    if (r.isSuccess) "Standard offline voice ready."
                                    else "Download failed: ${r.exceptionOrNull()?.message}",
                                )
                            )
                        }
                    },
                    enabled = online && !voskState.downloading,
                ) {
                    Text(
                        if (voice.models.isPackReady(com.texgen.music.texwave.util.VoskModelManager.ModelPack.STANDARD))
                            "Standard model installed ✓"
                        else "Download standard (~128 MB)",
                        color = Tx.Accent2,
                    )
                }
                TextButton(
                    onClick = {
                        scope.launch {
                            val r = voice.models.ensureModel(com.texgen.music.texwave.util.VoskModelManager.ModelPack.LARGE)
                            messages.add(
                                ChatMessage(
                                    System.currentTimeMillis(),
                                    "assistant",
                                    if (r.isSuccess) "Maximum-accuracy voice model ready (~4 GB class)."
                                    else "Large model download failed: ${r.exceptionOrNull()?.message}",
                                )
                            )
                        }
                    },
                    enabled = online && !voskState.downloading,
                ) {
                    Text(
                        if (voice.models.isPackReady(com.texgen.music.texwave.util.VoskModelManager.ModelPack.LARGE))
                            "Maximum model installed ✓"
                        else "Download maximum accuracy (~4 GB free needed)",
                        color = Tx.Accent2,
                    )
                }
                voskState.error?.let {
                    Text(it, color = Color(0xFFFF8A80), style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // Quick chips
        if (true) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                chips.forEach { chip ->
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Tx.SurfaceHigh)
                            .clickable(enabled = !busy) {
                                draft = ""
                                sendText(chip)
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    ) {
                        Text(chip, color = Tx.Text, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(messages, key = { it.id }) { msg ->
                val mine = msg.role == "user"
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
                ) {
                    Box(
                        Modifier
                            .widthIn(max = 340.dp)
                            .clip(
                                RoundedCornerShape(
                                    topStart = 18.dp,
                                    topEnd = 18.dp,
                                    bottomStart = if (mine) 18.dp else 6.dp,
                                    bottomEnd = if (mine) 6.dp else 18.dp,
                                )
                            )
                            .background(
                                if (mine) {
                                    Brush.horizontalGradient(
                                        listOf(Color(0xCC5B8CFF), Color(0xAA1DB98A))
                                    )
                                } else {
                                    Brush.horizontalGradient(
                                        listOf(Color(0x33FFFFFF), Color(0x14FFFFFF))
                                    )
                                }
                            )
                            .padding(14.dp),
                    ) {
                        Text(
                            msg.text,
                            color = if (mine) Color.White else Tx.Text,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
            if (busy) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), color = Tx.Accent2, strokeWidth = 2.dp)
                        Text(
                            if (listening) "  Listening…" else "  Searching & thinking…",
                            color = Tx.Muted,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }

        // quick prompts
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(
                "Surprise me",
                "Play something chill",
                "What's my top artist?",
                "My listening stats",
                "Infinite mix",
                "Recommend from my favorites",
                "What's playing?",
                "Weather today",
            ).forEach { chip ->
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0x1AFFFFFF))
                        .border(1.dp, Color(0x332BE4A4), RoundedCornerShape(50))
                        .clickable(enabled = !busy) { sendText(chip) }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                ) { Text(chip, color = Tx.Text, fontSize = 12.sp) }
            }
        }
        if (pendingImageBytes != null) {
            Text(
                "Image ready · describe the edit or ask Phantom to analyze 📷",
                color = Tx.Accent2,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = { pickImage.launch("image/*") },
                enabled = !busy,
            ) {
                Icon(
                    Icons.Rounded.Image,
                    "Attach image",
                    tint = if (pendingImageBytes != null) Tx.Accent else Tx.Accent2,
                )
            }
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                placeholder = { Text("Ask PHANTOM anything…", color = Tx.Muted) },
                enabled = !busy,
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (!busy && (draft.isNotBlank() || pendingImageBytes != null)) {
                        val text = draft.trim()
                        draft = ""
                        sendText(text)
                    }
                }),
                colors = fieldColors(),
                shape = RoundedCornerShape(18.dp),
            )
            IconButton(
                onClick = {
                    if (listening) {
                        voice.stop()
                        listening = false
                    } else startListen()
                },
                enabled = !busy,
            ) {
                Icon(
                    if (listening) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                    if (listening) "Stop" else "Speak",
                    tint = if (listening) Color(0xFFFF6B6B) else Tx.Accent2,
                )
            }
            IconButton(
                onClick = {
                    if (!busy && (draft.isNotBlank() || pendingImageBytes != null)) {
                        val text = draft.trim()
                        draft = ""
                        sendText(text)
                    }
                },
                enabled = !busy && (draft.isNotBlank() || pendingImageBytes != null),
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (draft.isNotBlank() || pendingImageBytes != null) Tx.Accent else Tx.SurfaceHigh
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Send, "Send", tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Tx.Text,
    unfocusedTextColor = Tx.Text,
    focusedBorderColor = Tx.Accent,
    unfocusedBorderColor = Tx.Outline,
    cursorColor = Tx.Accent2,
    focusedContainerColor = Tx.Surface,
    unfocusedContainerColor = Tx.Surface,
)
