package com.texgen.music.texwave.ui.screens.chat

import com.texgen.music.texwave.data.chat.ChatThemeStore
import com.texgen.music.texwave.data.chat.ChatAuthState

import com.texgen.music.texwave.data.chat.CallSignal
import com.texgen.music.texwave.data.chat.ChatPrefs

import com.texgen.music.texwave.data.chat.SilentSignalStore

import com.texgen.music.texwave.data.chat.ResonanceReply

import com.texgen.music.texwave.data.chat.WaveDropStore

import com.texgen.music.texwave.data.chat.WavePresenceStore

import com.texgen.music.texwave.data.chat.LivingGroupProtocol

import com.texgen.music.texwave.data.VerifiedBadgeStore
import com.texgen.music.texwave.ui.components.VerifiedStarBadge

import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloatAsState
import androidx.core.content.ContextCompat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.content.pm.PackageManager
import android.Manifest
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.result.ActivityResult
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.chat.*
import com.texgen.music.texwave.data.chat.ChatVibeStore
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.glassBar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import android.content.Context
import android.net.Uri
import java.io.File

@Composable
fun ConversationBody(
    repo: ChatRepository,
    conversationId: String,
    title: String,
    onBack: () -> Unit,
    librarySongs: List<Song>,
    onPlayResonance: (String, String, String?) -> Unit,
    messages: SnapshotStateList<ChatMessageUi>,
    members: ConversationMembers?,
    onlineIds: Set<String>,
    recentlyActive: Map<String, Long> = emptyMap(),
    typingIds: Set<String>,
    readAt: Map<String, Long>,
    loading: Boolean,
    error: String?,
    onError: (String?) -> Unit,
    input: String,
    onInputChange: (String) -> Unit,
    uploadProgress: Float,
    onUploadProgress: (Float) -> Unit,
    listState: LazyListState,
    theme: ChatThemeStore.Theme,
    onThemeChange: (ChatThemeStore.Theme) -> Unit,
    showResonance: Boolean,
    onShowResonance: (Boolean) -> Unit,
    showSoundtrack: Boolean,
    onShowSoundtrack: (Boolean) -> Unit,
    showCapsules: Boolean,
    onShowCapsules: (Boolean) -> Unit,
    showThemePw: Boolean,
    onShowThemePw: (Boolean) -> Unit,
    themePw: String,
    onThemePwChange: (String) -> Unit,
    themePwError: String?,
    onThemePwError: (String?) -> Unit,
    showThemePicker: Boolean,
    onShowThemePicker: (Boolean) -> Unit,
    menuOpen: Boolean,
    onMenuOpen: (Boolean) -> Unit,
    recording: Boolean,
    onRecordingChange: (Boolean) -> Unit,
    mediaRecorderHolder: MutableState<android.media.MediaRecorder?>,
    recordPathHolder: MutableState<String?>,
    pickThemeBg: ManagedActivityResultLauncher<String, Uri?>,
    imagePicker: ManagedActivityResultLauncher<String, Uri?>,
    videoPicker: ManagedActivityResultLauncher<String, Uri?>,
    filePicker: ManagedActivityResultLauncher<Array<String>, Uri?>,
    onSendMessage: (String) -> Unit,
    onPickedAttachment: (Uri?) -> Unit = {},
    live: ChatRepository.ConversationLive,
    myId: String,
    scope: CoroutineScope,
    context: Context,
    forceJoinRoom: String? = null,
    forceJoinPeer: String? = null,
    onForceJoinConsumed: () -> Unit = {},
) {
    var showDrawing by remember { mutableStateOf(false) }
    var sendBurst by remember { mutableStateOf(false) }
    var chatStreak by remember { mutableIntStateOf(ChatVibeStore.streak(context, conversationId)) }
    var sessionEnter by remember { mutableStateOf(true) }
    val enterAlpha by animateFloatAsState(if (sessionEnter) 1f else 0f, tween(900), label = "enterFlash")
    LaunchedEffect(conversationId) {
        sessionEnter = true
        kotlinx.coroutines.delay(700)
        sessionEnter = false
    }
    LaunchedEffect(sendBurst) {
        if (sendBurst) {
            kotlinx.coroutines.delay(320)
            sendBurst = false
        }
    }
    val others = members?.profiles.orEmpty()
    val isGroup = others.size > 1
    val other = if (!isGroup) others.firstOrNull() else null
    val typingNames = others.filter { it.id in typingIds }.map { it.displayName }
    val otherOnline = other != null && isUserOnline(other.id, other.lastSeenAt, onlineIds, recentlyActive[other.id] ?: 0L)
    val online = otherOnline
    var showOtherProfile by remember { mutableStateOf(false) }
    var pendingStartRecord by remember { mutableStateOf(false) }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingStartRecord = true
        else Toast.makeText(context, "Microphone permission required for voice notes", Toast.LENGTH_LONG).show()
    }

    var showChatTools by remember { mutableStateOf(false) }
    // Keep last_seen / presence fresh while this chat is open
    LaunchedEffect(conversationId) {
        while (true) {
            kotlinx.coroutines.delay(20_000)
            runCatching {
                repo.loadMembers(conversationId).onSuccess { m ->
                    m.profiles.forEach { p ->
                        if (isUserOnline(p.id, p.lastSeenAt, onlineIds, recentlyActive[p.id] ?: 0L)) {
                            repo.noteUserActive(p.id)
                        }
                    }
                }
            }
        }
    }
    var zeroChrome by remember { mutableStateOf(false) }
    var focusSkin by remember { mutableStateOf(false) }
    var cinematicIn by remember { mutableStateOf(false) }
    LaunchedEffect(conversationId) {
        cinematicIn = false
        kotlinx.coroutines.delay(40)
        cinematicIn = true
    }
    var activeCallRoom by remember { mutableStateOf<String?>(null) }
    var activeCallOutgoing by remember { mutableStateOf(false) }
    var activeCallPeer by remember { mutableStateOf(title) }

    LaunchedEffect(forceJoinRoom) {
        val room = forceJoinRoom ?: return@LaunchedEffect
        if (room.isBlank()) return@LaunchedEffect
        activeCallRoom = room
        activeCallOutgoing = false
        activeCallPeer = forceJoinPeer?.takeIf { it.isNotBlank() } ?: title
        onForceJoinConsumed()
    }
    val uiScope = rememberCoroutineScope()
    var showChatSearch by remember { mutableStateOf(false) }
    var chatSearchQuery by remember { mutableStateOf("") }
    var chatMuted by remember(conversationId) { mutableStateOf(ChatPrefs.isMuted(context, conversationId)) }
    var chatPinned by remember(conversationId) { mutableStateOf(ChatPrefs.isPinned(context, conversationId)) }

    fun startVoiceCall() {
        if (activeCallRoom != null) return
        val room = CallSignal.roomFor(conversationId)
        activeCallRoom = room
        activeCallOutgoing = true
        activeCallPeer = title
        onSendMessage(CallSignal.encodeInvite(false, room, repo.myDisplayName()))
    }


    LaunchedEffect(pendingStartRecord) {
        if (!pendingStartRecord) return@LaunchedEffect
        pendingStartRecord = false
        try {
            val file = java.io.File(context.cacheDir, "echo_${System.currentTimeMillis()}.m4a")
            recordPathHolder.value = file.absolutePath
            val rec = if (android.os.Build.VERSION.SDK_INT >= 31) {
                android.media.MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                android.media.MediaRecorder()
            }
            rec.setAudioSource(android.media.MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(192_000)
            rec.setAudioSamplingRate(44_100)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            mediaRecorderHolder.value = rec
            onRecordingChange(true)
            Toast.makeText(context, "Recording… tap Voice again to send", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, e.message ?: "Could not start recording", Toast.LENGTH_LONG).show()
            onRecordingChange(false)
        }
    }

    // Pick up the latest shared theme from chat history (either side can set it)
    var lastThemeBody by remember(conversationId) { mutableStateOf<String?>(null) }
    LaunchedEffect(messages.size, messages.lastOrNull()?.message?.id, messages.lastOrNull()?.message?.body) {
        val sharedMsg = messages.asReversed().firstOrNull {
            ChatThemeStore.parse(it.message.body) != null
        }
        val raw = sharedMsg?.message?.body
        val shared = ChatThemeStore.parse(raw)
        if (shared != null && raw != null && raw != lastThemeBody) {
            lastThemeBody = raw
            val bg = shared.backgroundUri
            if (bg != null && bg.startsWith("sb:")) {
                val already = ChatThemeStore.remoteToken(context, conversationId) == bg &&
                    theme.preset == 5 &&
                    !theme.backgroundUri.isNullOrBlank() &&
                    theme.backgroundUri?.startsWith("sb:") != true &&
                    kotlin.math.abs(shared.dim - theme.dim) < 0.02f
                if (!already) {
                    repo.downloadThemeBackground(bg).onSuccess { local ->
                        val applied = shared.copy(backgroundUri = local, preset = 5)
                        onThemeChange(applied)
                        ChatThemeStore.set(context, conversationId, applied)
                        ChatThemeStore.setRemoteToken(context, conversationId, bg)
                    }.onFailure {
                        android.util.Log.w("ChatTheme", "theme photo download failed: ${it.message}")
                        // Still apply preset/dim even if photo fails
                        onThemeChange(shared.copy(backgroundUri = null, preset = shared.preset.coerceIn(0, 4)))
                        ChatThemeStore.set(context, conversationId, shared.copy(backgroundUri = null, preset = shared.preset.coerceIn(0, 4)))
                    }
                }
            } else {
                // Color preset themes — always apply the latest shared one
                onThemeChange(shared)
                ChatThemeStore.set(context, conversationId, shared)
            }
        }
        // Incoming call invite
        val last = messages.lastOrNull()
        val call = CallSignal.parse(last?.message?.body)
        val ageMs = System.currentTimeMillis() - com.texgen.music.texwave.data.chat.parseIsoMillis(last?.message?.createdAt)
        if (call != null && call.action == CallSignal.Action.INVITE && last?.isMine == false &&
            activeCallRoom == null && ageMs in -30_000..120_000
        ) {
            activeCallRoom = call.room
            activeCallOutgoing = false
            activeCallPeer = call.fromName.ifBlank { title }
        } else if (call != null && call.action == CallSignal.Action.END && last?.isMine == false &&
            ageMs in -30_000..120_000 && activeCallRoom == call.room
        ) {
            // the other side ended / declined
            activeCallRoom = null
        }
    }


    val presetBrush = when (theme.preset) {
        1 -> Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF0D0D12), Color(0xFF000000)))
        2 -> Brush.verticalGradient(listOf(Color(0xFF1A0A08), Color(0xFF3D1A12), Color(0xFF0A0610)))
        3 -> Brush.verticalGradient(listOf(Color(0xFF021018), Color(0xFF0A2A40), Color(0xFF020812)))
        4 -> Brush.verticalGradient(listOf(Color(0xFF0A0618), Color(0xFF1A1040), Color(0xFF061820)))
        else -> Brush.verticalGradient(
            listOf(Color(0xFF000000), Color(0xFF07060F), Color(0xFF0C0A18), Color(0xFF05040C), Color(0xFF000000))
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(presetBrush),
        // force redraw when shared theme changes
    ) {
        if (enterAlpha > 0.02f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0x335CE1FF).copy(alpha = 0.25f * enterAlpha), Color.Transparent),
                        ),
                    ),
            )
        }
        // Custom photo background for this chat (password-gated to set)
        if (!theme.backgroundUri.isNullOrBlank()) {
            AsyncImage(
                model = theme.backgroundUri?.let { if (it.startsWith("/")) java.io.File(it) else it },
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().alpha(1f - theme.dim.coerceIn(0.2f, 0.85f)),
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = theme.dim.coerceIn(0.2f, 0.85f))),
            )
        }
        // soft glow
        Box(
            Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0xFF5CE1FF).copy(alpha = 0.06f),
                            Tx.Accent.copy(alpha = 0.03f),
                            Color.Transparent,
                        )
                    )
                ),
        )

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding(),
        ) {
            // Top session bar — glass
            if (!zeroChrome) Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .glassBar(22)
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, null, tint = Tx.Text)
                }
                Box(
                    Modifier
                        .clip(CircleShape)
                        .clickable(enabled = other != null && !isGroup) { showOtherProfile = true },
                ) {
                    ChatAvatar(
                        name = title,
                        imageUrl = other?.avatarModel,
                        size = 42.dp,
                        online = otherOnline,
                        isGroup = isGroup,
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(
                    Modifier
                        .weight(1f)
                        .clickable(enabled = other != null && !isGroup) { showOtherProfile = true },
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
                        val otherVerified = VerifiedBadgeStore.isProfileVerified(other?.bio)
                        val selfVerified = VerifiedBadgeStore.isVerified(context)
                        if (otherVerified || selfVerified) {
                            Spacer(Modifier.width(5.dp))
                            VerifiedStarBadge(size = 15.dp)
                        }
                    }
                    val (statusText, statusColor) = when {
                        typingNames.isNotEmpty() ->
                            (if (isGroup) {
                                val names = typingNames.take(2).joinToString(", ")
                                val extra = if (typingNames.size > 2) " +${typingNames.size - 2}" else ""
                                "$names$extra typing…"
                            } else "typing…") to Color(0xFFFF58D8)
                        isGroup -> {
                            val onlineCount = others.count { isUserOnline(it.id, it.lastSeenAt, onlineIds, recentlyActive[it.id] ?: 0L) }
                            "${others.size + 1} members · $onlineCount active" to Tx.Muted
                        }
                        other != null && otherOnline -> "● Active now" to Color(0xFF5CE1FF)
                        other != null -> lastSeenLabel(other.lastSeenAt) to Tx.Muted
                        else -> "" to Tx.Muted
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (statusText.isNotEmpty()) {
                            Text(statusText, color = statusColor, fontSize = 12.sp, maxLines = 1)
                        }
                        if (chatStreak > 0) {
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "🔥 $chatStreak day" + if (chatStreak == 1) "" else "s",
                                color = Color(0xFFFF8A3D),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                            )
                        }
                    }
                }
                IconButton(
                    onClick = {
                        chatStreak = ChatVibeStore.markSent(context, conversationId)
                        sendBurst = true
                        onSendMessage("👋 Wave")
                    },
                ) {
                    Text("👋", fontSize = 20.sp)
                }
                IconButton(onClick = { startVoiceCall() }) {
                    Icon(Icons.Rounded.Call, "Voice call", tint = Tx.Accent)
                }
                Box {
                    IconButton(onClick = { onMenuOpen(true) }) {
                        Icon(Icons.Rounded.MoreVert, "Options", tint = Tx.Muted)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { onMenuOpen(false) }) {
                        DropdownMenuItem(
                            text = { Text("Shared soundtrack") },
                            onClick = { onMenuOpen(false); onShowSoundtrack(true) },
                        )
                        DropdownMenuItem(
                            text = { Text("Memory capsules") },
                            onClick = { onMenuOpen(false); onShowCapsules(true) },
                        )
                        DropdownMenuItem(
                            text = { Text("Chat theme") },
                            onClick = {
                                onMenuOpen(false)
                                onShowThemePw(true)
                                onThemePwChange("")
                                onThemePwError(null)
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Refresh") },
                            onClick = {
                                onMenuOpen(false)
                                scope.launch {
                                    repo.loadMessages(conversationId).onSuccess { list ->
                                        messages.clear()
                                        messages.addAll(list)
                                    }
                                    repo.loadMembers(conversationId).onSuccess { m ->
                                        live.seedReadAt(m.readAt)
                                    }
                                }
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Chat tools (30+)") },
                            onClick = { onMenuOpen(false); showChatTools = true },
                        )
                        DropdownMenuItem(
                            text = { Text("Close session") },
                            onClick = { onMenuOpen(false); onBack() },
                        )
                    }
                }
            }

            Box(Modifier.fillMaxWidth().height(1.dp).background(Tx.Outline.copy(alpha = 0.4f)))


            if (otherOnline && !isGroup) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(listOf(Color(0x3312E0A0), Color(0x335CE1FF), Color(0x33FF2D55))),
                        )
                        .clickable {
                            chatStreak = ChatVibeStore.markSent(context, conversationId)
                            onSendMessage("👋 Wave — saw you’re active")
                        }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Text("● Active now", color = Color(0xFF5CE1FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("  ·  tap to Wave", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }

            if (loading && messages.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Tx.Accent, strokeWidth = 2.dp)
                }
            } else if (messages.isEmpty() && typingNames.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Start the vibe", color = Tx.Text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Break the ice — pick a line or send a Wave",
                            color = Tx.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(18.dp))
                        val starters = listOf(
                            "👋 Wave — you free?",
                            "🔥 Send me a song rn",
                            "✨ Rate my day 1–10",
                            "🎧 What are you on?",
                            "💜 Random fact go",
                        )
                        starters.forEach { line ->
                            Text(
                                line,
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier
                                    .padding(vertical = 5.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(Color(0xFF1A1030), Color(0xFF12243A)),
                                        ),
                                    )
                                    .border(
                                        1.dp,
                                        Brush.horizontalGradient(listOf(Color(0x66FF2D55), Color(0x665CE1FF))),
                                        RoundedCornerShape(16.dp),
                                    )
                                    .clickable {
                                        chatStreak = ChatVibeStore.markSent(context, conversationId)
                                        onSendMessage(line)
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    items(messages, key = { it.message.id }) { msg ->
                        val createdMs = parseIsoMillis(msg.message.createdAt)
                        val seen = msg.isMine && !msg.isPending && !msg.isFailed &&
                            others.isNotEmpty() && createdMs > 0L &&
                            others.all { (readAt[it.id] ?: 0L) >= createdMs }
                        val peerOnline = others.any { it.id in onlineIds }
                        val delivered = msg.isMine && !msg.isPending && !msg.isFailed && (seen || peerOnline)
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(tween(220)) +
                                scaleIn(initialScale = 0.82f, animationSpec = tween(320)) +
                                slideInVertically(initialOffsetY = { it / 4 }, animationSpec = tween(320)),
                        ) {
                            PremiumBubble(
                                msg = msg,
                                repo = repo,
                                seen = seen,
                                delivered = delivered,
                                onRetry = {
                                    val t = msg.message.body
                                    if (msg.isFailed && !t.isNullOrBlank()) onSendMessage(t)
                                },
                                conversationId = conversationId,
                                title = title,
                                onPlayResonance = onPlayResonance,
                                onQuickSend = { text -> onSendMessage(text) },
                            )
                        }
                    }
                    if (typingNames.isNotEmpty()) {
                        item(key = "typing-indicator") { TypingBubble() }
                    }
                }
            }

            if (uploadProgress in 0f..1f) {
                LinearProgressIndicator(
                    progress = { uploadProgress },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    color = Tx.Accent,
                    trackColor = Tx.SurfaceHigh,
                )
            }
            error?.let {
                Text(it, color = Tx.Danger, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }

            // BOTTOM SESSION BAR — all primary options live here
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xF00A0E1F), Color(0xFF060814))
                        )
                    )
                    .border(0.5.dp, Color(0x18FFFFFF), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            ) {
                // quick actions row
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    BottomChip("♪ Resonance", Icons.Rounded.MusicNote) {
                        onShowResonance(true)
                    }
                    val recPulse by rememberInfiniteTransition(label = "rec").animateFloat(
                        1f, 1.08f,
                        infiniteRepeatable(tween(600), RepeatMode.Reverse),
                        label = "rp",
                    )
                    Box(Modifier.scale(if (recording) recPulse else 1f)) {
                        BottomChip(
                            if (recording) "● Stop · Send" else "Voice",
                            Icons.Rounded.Mic,
                        ) {
                            if (!recording) {
                                val ok = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                if (!ok) {
                                    micPerm.launch(Manifest.permission.RECORD_AUDIO)
                                } else {
                                    pendingStartRecord = true
                                }
                            } else {
                                try {
                                    mediaRecorderHolder.value?.apply { stop(); release() }
                                } catch (_: Exception) {}
                                mediaRecorderHolder.value = null
                                onRecordingChange(false)
                                val path = recordPathHolder.value
                                if (path != null) {
                                    val f = java.io.File(path)
                                    if (f.exists() && f.length() > 200) {
                                        scope.launch {
                                            onUploadProgress(0f)
                                            onError(null)
                                            val uri = try {
                                                androidx.core.content.FileProvider.getUriForFile(
                                                    context, "${context.packageName}.fileprovider", f,
                                                )
                                            } catch (_: Exception) {
                                                android.net.Uri.fromFile(f)
                                            }
                                            repo.sendAttachment(conversationId, uri) { p -> onUploadProgress(p) }
                                                .onSuccess { ui ->
                                                    if (messages.none { it.message.id == ui.message.id }) messages.add(ui)
                                                    Toast.makeText(context, "Voice note sent", Toast.LENGTH_SHORT).show()
                                                }
                                                .onFailure { onError(it.message) }
                                            onUploadProgress(-1f)
                                        }
                                    } else {
                                        Toast.makeText(context, "Recording too short", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        }
                    }
                    BottomChip("Photo", Icons.Rounded.Image) {
                        imagePicker.launch("image/*")
                    }
                    BottomChip("Video", Icons.Rounded.Videocam) {
                        videoPicker.launch("video/*")
                    }
                    BottomChip("Draw", Icons.Rounded.Brush) {
                        showDrawing = true
                    }
                    BottomChip("File", Icons.Rounded.AttachFile) {
                        filePicker.launch(arrayOf("*/*"))
                    }
                }
                if (input.isBlank()) VibePromptTicker(onPick = { onInputChange(it) })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = onInputChange,
                        placeholder = { Text("Message…", color = Color(0xFF7A829E)) },
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                1.dp,
                                Brush.linearGradient(listOf(Color(0x445CE1FF), Color(0x44B388FF))),
                                RoundedCornerShape(26.dp),
                            ),
                        shape = RoundedCornerShape(26.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = Color(0xFFF5F7FF),
                            unfocusedTextColor = Color(0xFFF5F7FF),
                            cursorColor = Color(0xFF5CE1FF),
                            focusedContainerColor = Color(0xEE12162A),
                            unfocusedContainerColor = Color(0xCC0E1220),
                        ),
                        maxLines = 4,
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(
                                if (input.isNotBlank())
                                    Brush.linearGradient(
                                        listOf(Color(0xFFFF2D55), Color(0xFFC13584), Color(0xFF5CE1FF)),
                                    )
                                else
                                    Brush.linearGradient(listOf(Color(0xFF1A1F30), Color(0xFF141824))),
                            )
                            .border(1.dp, Color(0x44FFFFFF), CircleShape)
                            .clickable(enabled = input.isNotBlank()) {
                                val text = input.trim()
                                if (text.isEmpty()) return@clickable
                                onInputChange("")
                                onError(null)
                                chatStreak = ChatVibeStore.markSent(context, conversationId)
                                sendBurst = true
                                onSendMessage(text)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        val burstScale by animateFloatAsState(
                            if (sendBurst) 1.22f else 1f,
                            animationSpec = tween(220),
                            finishedListener = { if (sendBurst) sendBurst = false },
                            label = "sendBurst",
                        )
                        Icon(
                            Icons.Rounded.Send,
                            "Send",
                            tint = if (input.isNotBlank()) Color.White else Color(0xFF6A738F),
                            modifier = Modifier.size(21.dp).scale(burstScale),
                        )
                        if (sendBurst) {
                            Box(
                                Modifier
                                    .matchParentSize()
                                    .clip(CircleShape)
                                    .background(Color(0x44FF2D55)),
                            )
                        }
                    }
                }
            }
        }
    }


    if (showChatSearch) {
        val q = chatSearchQuery.trim()
        val hits = remember(q, messages.size) {
            if (q.length < 2) emptyList()
            else messages.withIndex().filter { (_, m) ->
                m.message.body?.contains(q, ignoreCase = true) == true && CallSignal.parse(m.message.body) == null
            }.toList().takeLast(40)
        }
        AlertDialog(
            onDismissRequest = { showChatSearch = false },
            confirmButton = { TextButton(onClick = { showChatSearch = false }) { Text("Close") } },
            title = { Text("Search this chat") },
            text = {
                Column {
                    OutlinedTextField(
                        value = chatSearchQuery,
                        onValueChange = { chatSearchQuery = it },
                        singleLine = true,
                        placeholder = { Text("Type at least 2 letters") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(10.dp))
                    if (q.length >= 2 && hits.isEmpty()) {
                        Text("No messages found", color = Tx.Muted, fontSize = 13.sp)
                    }
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        items(hits.size) { i ->
                            val (idx, m) = hits[i]
                            Text(
                                (if (m.isMine) "You: " else "") + (m.message.body ?: ""),
                                color = Tx.Text,
                                fontSize = 14.sp,
                                maxLines = 2,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showChatSearch = false
                                        uiScope.launch { runCatching { listState.animateScrollToItem(idx) } }
                                    }
                                    .padding(vertical = 8.dp),
                            )
                        }
                    }
                }
            },
        )
    }

    activeCallRoom?.let { room ->
        CallOverlay(
            repo = repo,
            peerName = activeCallPeer,
            room = room,
            outgoing = activeCallOutgoing,
            onEnd = { sendEnd ->
                if (sendEnd) onSendMessage(CallSignal.encodeEnd(false, room, activeCallPeer))
                activeCallRoom = null
            },
        )
    }

    if (showOtherProfile && other != null) {
        Box(Modifier.fillMaxSize()) {
            PeerProfileScreen(
                profile = other,
                onlineIds = onlineIds,
                recentlyActiveMs = recentlyActive[other.id] ?: 0L,
                onBack = { showOtherProfile = false },
                onMessage = { showOtherProfile = false },
                onCall = {
                    showOtherProfile = false
                    startVoiceCall()
                },
            )
        }
    }


    if (zeroChrome) {
        TextButton(
            onClick = { zeroChrome = false },
            modifier = Modifier.padding(8.dp),
        ) { Text("Show chrome", color = Color(0xFF5CE1FF), fontSize = 12.sp) }
    }
    if (focusSkin) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0x99000000))
                .clickable { focusSkin = false },
        ) {
            Text(
                "Focus · tap to exit",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp),
            )
        }
    }
    if (showChatTools) {
        // Side panel of unique one-tap signs (not emoji faces)
        data class ToolSign(val sign: String, val label: String, val action: String)
        val tools = listOf(
            ToolSign("◈", "Resonance", "resonance"),
            ToolSign("◎", "Poll", "poll"),
            ToolSign("◉", "Shared listen", "listen"),
            ToolSign("◇", "Challenge", "challenge"),
            ToolSign("▣", "Wave presence", "presence"),
            ToolSign("◫", "Wave Drop", "drop"),
            ToolSign("△", "Pulse", "pulse"),
            ToolSign("▽", "Support", "ripple"),
            ToolSign("▲", "Fire", "fire"),
            ToolSign("♪", "Soundtrack", "soundtrack"),
            ToolSign("✦", "Memory", "memory"),
            ToolSign("◐", "Theme", "theme"),
            ToolSign("▭", "Photo", "photo"),
            ToolSign("▶", "Video", "video"),
            ToolSign("✎", "Draw", "draw"),
            ToolSign("▤", "File", "file"),
            ToolSign("☰", "Chat info", "info"),
            ToolSign("⎘", "Export", "export"),
            ToolSign("⊘", "Clear local", "clear"),
            ToolSign("⊙", "Mute / unmute", "mute"),
            ToolSign("⌖", "Pin / unpin", "pin"),
            ToolSign("⟡", "Listening signal", "sig_listen"),
            ToolSign("⬡", "Focus signal", "sig_focus"),
            ToolSign("⬢", "Open signal", "sig_open"),
            ToolSign("▷", "Voice call", "vcall"),
            ToolSign("⇄", "Reply last", "reply"),
            ToolSign("⬚", "Search chat", "search"),
            ToolSign("⇩", "Jump to latest", "compass"),
            ToolSign("✧", "Silent note", "silent"),
            ToolSign("☺", "Group mood", "mood"),
            ToolSign("▣", "Plan meetup", "schedule"),
        )
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showChatTools = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .clickable { showChatTools = false },
            ) {
                Column(
                    Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .width(88.dp)
                        .background(Color(0xFF0B0F1A))
                        .clickable(enabled = false) {}
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("TOOLS", color = Tx.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    androidx.compose.foundation.lazy.LazyColumn(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        contentPadding = PaddingValues(bottom = 24.dp),
                    ) {
                        items(tools.size) { i ->
                            val t = tools[i]
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0xFF151A2C))
                                    .clickable {
                                        when (t.action) {
                                            "resonance" -> onShowResonance(true)
                                            "poll" -> onSendMessage(LivingGroupProtocol.encodePoll("What should we do?", listOf("Music", "Movie", "Chill", "Study")))
                                            "listen" -> onSendMessage(LivingGroupProtocol.encodeSharedListen("Group vibe", "TEXWAVE"))
                                            "challenge" -> onSendMessage(LivingGroupProtocol.encodeChallenge("Send a song that matches this chat"))
                                            "presence" -> {
                                                val p = WavePresenceStore.presets.random()
                                                WavePresenceStore.setLocal(context, p)
                                                onSendMessage(WavePresenceStore.encode(p))
                                            }
                                            "drop" -> {
                                                val d = WaveDropStore.today(context)
                                                val ans = WaveDropStore.myAnswer(context) ?: "Solved: ${d.title}"
                                                WaveDropStore.saveAnswer(context, ans)
                                                val myName = (repo.authState.value as? ChatAuthState.SignedIn)?.profile?.displayName ?: "Me"
                                                onSendMessage(WaveDropStore.encodeSolved(d, ans, myName))
                                            }
                                            "pulse" -> onSendMessage(ResonanceReply.encode("last", "pulse"))
                                            "ripple" -> onSendMessage(ResonanceReply.encode("last", "ripple"))
                                            "fire" -> onSendMessage(ResonanceReply.encode("last", "fire"))
                                            "soundtrack" -> onShowSoundtrack(true)
                                            "memory" -> onShowCapsules(true)
                                            "theme" -> onShowThemePw(true)
                                            "photo" -> imagePicker.launch("image/*")
                                            "video" -> videoPicker.launch("video/*")
                                            "draw" -> showDrawing = true
                                            "file" -> filePicker.launch(arrayOf("*/*"))
                                            "info" -> showOtherProfile = true
                                            "export" -> {
                                                val all = messages.mapNotNull { it.message.body }.joinToString("\n")
                                                val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                cm.setPrimaryClip(android.content.ClipData.newPlainText("chat", all))
                                                Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                                            }
                                            "clear" -> { messages.clear(); Toast.makeText(context, "Cleared local", Toast.LENGTH_SHORT).show() }
                                            "mute" -> {
                                                chatMuted = !chatMuted
                                                ChatPrefs.setMuted(context, conversationId, chatMuted)
                                                Toast.makeText(context, if (chatMuted) "Notifications muted" else "Notifications on", Toast.LENGTH_SHORT).show()
                                            }
                                            "pin" -> {
                                                chatPinned = !chatPinned
                                                ChatPrefs.setPinned(context, conversationId, chatPinned)
                                                Toast.makeText(context, if (chatPinned) "Pinned to top of chats" else "Unpinned", Toast.LENGTH_SHORT).show()
                                            }
                                            "reply" -> {
                                                val lastOther = messages.lastOrNull { !it.isMine && !it.message.body.isNullOrBlank() && CallSignal.parse(it.message.body) == null }
                                                val quote = lastOther?.message?.body?.take(60)
                                                if (quote == null) Toast.makeText(context, "Nothing to reply to yet", Toast.LENGTH_SHORT).show()
                                                else onInputChange("↩ \"$quote\"\n")
                                            }
                                            "search" -> { chatSearchQuery = ""; showChatSearch = true }
                                            "compass" -> uiScope.launch {
                                                if (messages.isNotEmpty()) runCatching { listState.animateScrollToItem(messages.size - 1) }
                                            }
                                            "silent" -> {
                                                val note = input.trim()
                                                if (note.isEmpty()) Toast.makeText(context, "Type your note first, then tap Silent note", Toast.LENGTH_SHORT).show()
                                                else { onSendMessage("🤫 $note"); onInputChange("") }
                                            }
                                            "mood" -> onSendMessage(LivingGroupProtocol.encodePoll("How is everyone feeling?", listOf("Hyped", "Chill", "Tired", "Focused")))
                                            "schedule" -> onSendMessage(LivingGroupProtocol.encodePoll("When should we meet up?", listOf("Tonight", "Tomorrow", "This weekend", "Later")))
                                            "sig_listen" -> onSendMessage(SilentSignalStore.encode(SilentSignalStore.Mode.LISTENING))
                                            "sig_focus" -> onSendMessage(SilentSignalStore.encode(SilentSignalStore.Mode.FOCUS))
                                            "sig_open" -> onSendMessage(SilentSignalStore.encode(SilentSignalStore.Mode.OPEN))
                                            "vcall" -> startVoiceCall()
                                            // --- Chat Empire ---
                                            "emp_song" -> {
                                                val cur = try {
                                                    // best-effort: last known from shared prefs if player not injected
                                                    val sp = context.getSharedPreferences("texwave_player_hint", android.content.Context.MODE_PRIVATE)
                                                    sp.getString("title", "Unknown") to sp.getString("artist", "")
                                                } catch (_: Exception) { "Unknown" to "" }
                                                onSendMessage(ChatEmpireProtocol.SongCard(cur.first ?: "A track", cur.second ?: "").encode())
                                                ChatEmpireStore.bumpStat(context, conversationId, songs = 1)
                                            }
                                            "emp_lyric" -> onSendMessage(ChatEmpireProtocol.LyricReply("This line hit different tonight", "Now playing").encode())
                                            "emp_harm" -> onSendMessage(ChatEmpireProtocol.Harmonic("A4", 440).encode())
                                            "emp_listen" -> onSendMessage(ChatEmpireProtocol.ListenTogether("Shared queue", "TEXWAVE", "host").encode())
                                            "emp_capsule" -> {
                                                val opens = System.currentTimeMillis() + 7L * 24 * 3600_000
                                                onSendMessage(ChatEmpireProtocol.CapsuleMsg("For later", "Open this when you need us", opens).encode())
                                            }
                                            "emp_crew" -> {
                                                val ends = System.currentTimeMillis() + 8L * 3600_000
                                                ChatEmpireStore.setNightCrewEnd(context, conversationId, ends)
                                                onSendMessage(ChatEmpireProtocol.NightCrew("Tonight's crew", ends).encode())
                                            }
                                            "emp_tone" -> onSendMessage(ChatEmpireProtocol.RoomTone("rain").encode())
                                            "emp_letter" -> onSendMessage(ChatEmpireProtocol.Letter("I wanted to say this properly — no rush to reply.").encode())
                                            "emp_vote" -> {
                                                val id = java.util.UUID.randomUUID().toString().take(8)
                                                onSendMessage(ChatEmpireProtocol.Vote("What do we play next?", listOf("Chill", "Hype", "Night drive", "Surprise"), id).encode())
                                            }
                                            "emp_duet" -> onSendMessage(ChatEmpireProtocol.DuetHalf(1, "Our song", "I'll take the verse").encode())
                                            "emp_recap" -> {
                                                val st = ChatEmpireStore.sessionStats(context, conversationId)
                                                onSendMessage(ChatEmpireProtocol.SessionRecap(st.first.coerceAtLeast(1), st.second, st.third.coerceAtLeast(5)).encode())
                                            }
                                            "emp_shield" -> {
                                                ChatEmpireStore.setShieldKeywords(context, conversationId, "spoiler,politics")
                                                onSendMessage(ChatEmpireProtocol.QuietShield("spoiler,politics").encode())
                                            }
                                            "emp_twokey" -> onSendMessage(ChatEmpireProtocol.TwoKey(java.util.UUID.randomUUID().toString().take(12)).encode())
                                            "emp_cover" -> onSendMessage(ChatEmpireProtocol.CoverDuel("Pick a classic", "A").encode())
                                            "emp_beat" -> onSendMessage(ChatEmpireProtocol.BeatSync(120).encode())
                                            "emp_phantom" -> onSendMessage(ChatEmpireProtocol.PhantomSeat("Phantom, suggest one track for this chat").encode())
                                            "emp_amb" -> onSendMessage(ChatEmpireProtocol.Ambassador("Start here").encode())
                                            "emp_energy" -> onSendMessage(ChatEmpireProtocol.EnergyShare(72, "Warm · present").encode())
                                            "emp_gaze" -> onSendMessage(ChatEmpireProtocol.Gaze("last", 12).encode())
                                            "emp_lock" -> {
                                                ChatEmpireStore.lockChat(context, conversationId, true)
                                                Toast.makeText(context, "Chat locked on this device", Toast.LENGTH_SHORT).show()
                                            }
                                            "emp_quiet" -> {
                                                ChatEmpireStore.setQuietHours(context, conversationId, 23, 8)
                                                Toast.makeText(context, "Quiet hours 23:00–08:00 for this chat", Toast.LENGTH_SHORT).show()
                                            }
                                            "emp_focus" -> {
                                                focusSkin = !focusSkin
                                                Toast.makeText(context, if (focusSkin) "Focus skin on" else "Focus skin off", Toast.LENGTH_SHORT).show()
                                            }
                                            "emp_chrome" -> {
                                                zeroChrome = !zeroChrome
                                                Toast.makeText(context, if (zeroChrome) "Chrome hidden — swipe tools anytime" else "Chrome restored", Toast.LENGTH_SHORT).show()
                                            }
                                            else -> Toast.makeText(context, "${t.label}", Toast.LENGTH_SHORT).show()
                                        }
                                        showChatTools = false
                                    }
                                    .padding(6.dp),
                            ) {
                                Text(t.sign, color = Tx.Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text(t.label, color = Tx.Muted, fontSize = 9.sp, maxLines = 2, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showResonance) {
        ResonancePickerDialog(
            librarySongs = librarySongs,
            conversationId = conversationId,
            repo = repo,
            messages = messages,
            onDismiss = { onShowResonance(false) },
            onError = onError,
        )
    }
    if (showSoundtrack) {
        SharedSoundtrackDialog(conversationId = conversationId, onDismiss = { onShowSoundtrack(false) })
    }
    if (showCapsules) {
        MemoryCapsulesDialog(conversationId = conversationId, onDismiss = { onShowCapsules(false) })
    }
    if (showThemePw) {
        ThemePasswordDialog(
            password = themePw,
            onPasswordChange = { onThemePwChange(it); onThemePwError(null) },
            error = themePwError,
            onConfirm = {
                if (ChatThemeStore.verifyPassword(themePw)) {
                    onShowThemePw(false)
                    onShowThemePicker(true)
                } else {
                    onThemePwError("Wrong password")
                }
            },
            onDismiss = { onShowThemePw(false) },
        )
    }
    if (showThemePicker) {
        ThemePickerDialog(
            theme = theme,
            onThemeChange = onThemeChange,
            conversationId = conversationId,
            onPickPhoto = { pickThemeBg.launch("image/*") },
            onDismiss = { onShowThemePicker(false) },
            onShare = { th ->
                val remote = ChatThemeStore.remoteToken(context, conversationId)
                val shareable = th.copy(
                    // Photo themes need the sb: token so the peer can download it
                    backgroundUri = when {
                        th.preset == 5 && !remote.isNullOrBlank() -> remote
                        th.preset == 5 && th.backgroundUri?.startsWith("sb:") == true -> th.backgroundUri
                        th.preset == 5 -> null // still uploading / local only
                        else -> null
                    },
                )
                ChatThemeStore.set(context, conversationId, th)
                onThemeChange(th)
                val body = ChatThemeStore.encode(shareable)
                // Push through the normal send path so realtime + history both carry it
                onSendMessage(body)
                if (th.preset == 5 && shareable.backgroundUri.isNullOrBlank()) {
                    Toast.makeText(
                        context,
                        "Preset colors shared · photo needs upload first (pick photo again)",
                        Toast.LENGTH_LONG,
                    ).show()
                } else {
                    Toast.makeText(context, "Theme shared with them", Toast.LENGTH_SHORT).show()
                }
            },
        )
    }
    if (showDrawing) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showDrawing = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false,
            ),
        ) {
            DrawingCanvasScreen(
                onClose = { showDrawing = false },
                onSend = { uri -> showDrawing = false; onPickedAttachment(uri) },
            )
        }
    }
}
