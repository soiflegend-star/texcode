package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.player.EqualizerController
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.ref.Ref
import com.texgen.music.texwave.ui.ref.RefBackground
import com.texgen.music.texwave.ui.ref.SongThumb
import com.texgen.music.texwave.ui.ref.refCard
import kotlinx.coroutines.delay

/**
 * Equalizer with live song controls, so you can change tracks while shaping the sound.
 * Adds bass boost, virtualizer and loudness on top of the band sliders.
 */
@Composable
fun EqualizerScreen(
    eq: EqualizerController,
    onBack: () -> Unit,
    player: PlayerState? = null,
    onPrevious: () -> Unit = {},
    onToggle: () -> Unit = {},
    onNext: () -> Unit = {},
) {
    // The audio session only exists once something has played; keep trying so the sliders become live.
    var attached by remember { mutableStateOf(eq.hasEffects) }
    LaunchedEffect(Unit) {
        while (true) {
            eq.ensureAttached()
            attached = eq.hasEffects
            delay(1200)
        }
    }
    var enabled by remember { mutableStateOf(eq.isEnabled()) }
    var preset by remember { mutableIntStateOf(-1) }
    val bandCount = eq.bandCount.coerceIn(3, 10)
    val range = eq.bandLevelRange
    val minL = range[0].toFloat()
    val maxL = range[1].toFloat()
    var levels by remember(attached, bandCount) { mutableStateOf(List(bandCount) { eq.getBandLevel(it).toFloat() }) }
    var bass by remember { mutableFloatStateOf(eq.bassStrength().toFloat()) }
    var virt by remember { mutableFloatStateOf(eq.virtStrength().toFloat()) }
    var loud by remember { mutableFloatStateOf(eq.loudGain().toFloat()) }

    fun turnOn() { if (!enabled) { enabled = true; eq.setEnabled(true) } }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF232325)).border(1.dp, Ref.Line, CircleShape).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Equalizer", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                    Text(if (attached) "Live on your music" else "Play a song to activate", color = if (attached) Ref.Cyan else Ref.Muted, fontSize = 12.sp)
                }
                Switch(
                    checked = enabled, onCheckedChange = { enabled = it; eq.setEnabled(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Ref.Purple, checkedThumbColor = Color.White),
                )
            }

            // Now playing strip — change songs without leaving the equalizer
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).refCard(18.dp).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SongThumb(player?.current, Modifier.size(52.dp), RoundedCornerShape(12.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(player?.current?.title ?: "Nothing playing", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(player?.current?.artist ?: "Pick a song to hear the changes", color = Ref.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(42.dp).clickable(onClick = onPrevious).padding(8.dp))
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Ref.Purple, Ref.Blue))).clickable(onClick = onToggle),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(if (player?.isPlaying == true) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(26.dp))
                }
                Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(42.dp).clickable(onClick = onNext).padding(8.dp))
            }

            Spacer(Modifier.height(16.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(EqualizerController.PRESET_NAMES) { index, name ->
                    val sel = preset == index
                    val s = RoundedCornerShape(18.dp)
                    Text(
                        name, color = if (sel) Color.White else Color(0xFFB9C6F5), fontSize = 13.sp,
                        modifier = Modifier.clip(s)
                            .background(if (sel) Brush.horizontalGradient(listOf(Ref.Purple, Ref.Blue)) else Brush.horizontalGradient(listOf(Color(0xFF232325), Color(0xFF232325))))
                            .border(1.dp, Ref.Line, s)
                            .clickable {
                                preset = index; eq.applyPreset(index); enabled = true
                                levels = List(bandCount) { eq.getBandLevel(it).toFloat() }
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).refCard(22.dp, hot = enabled).padding(16.dp)) {
                // Response curve
                Canvas(Modifier.fillMaxWidth().height(86.dp)) {
                    val w = size.width; val h = size.height
                    drawLine(Color(0xFF1A2B63), Offset(0f, h / 2), Offset(w, h / 2), 1.dp.toPx())
                    val pts = levels.mapIndexed { i, v ->
                        Offset(w * (i + 0.5f) / levels.size, h / 2 - ((v - (minL + maxL) / 2) / ((maxL - minL) / 2)) * (h / 2 - 8.dp.toPx()))
                    }
                    if (pts.size > 1) {
                        val path = Path().apply {
                            moveTo(0f, pts.first().y); lineTo(pts.first().x, pts.first().y)
                            for (i in 1 until pts.size) {
                                val a = pts[i - 1]; val b = pts[i]
                                cubicTo((a.x + b.x) / 2, a.y, (a.x + b.x) / 2, b.y, b.x, b.y)
                            }
                            lineTo(w, pts.last().y)
                        }
                        drawPath(path, Brush.horizontalGradient(listOf(Ref.Cyan, Ref.Violet, Ref.Magenta)), style = Stroke(3.dp.toPx()))
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth().height(190.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (i in 0 until bandCount) {
                        val freq = eq.getCenterFreq(i)
                        val label = if (freq >= 1000) "${freq / 1000}k" else "$freq"
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${(levels.getOrElse(i) { 0f } / 100).toInt()}", color = Ref.Cyan, fontSize = 11.sp)
                            BandBar(
                                value = levels.getOrElse(i) { 0f }, min = minL, max = maxL, enabled = enabled,
                                modifier = Modifier.weight(1f).width(44.dp),
                            ) { v ->
                                levels = levels.toMutableList().also { it[i] = v }
                                eq.setBandLevel(i, v.toInt()); turnOn(); preset = -1
                            }
                            Text(label, color = Ref.Sub, fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).refCard(22.dp).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Sound boosters", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Booster("Bass boost", bass, 1000f, "${(bass / 10).toInt()}%") { bass = it; eq.setBass(it.toInt()); turnOn() }
                Booster("Surround (virtualizer)", virt, 1000f, "${(virt / 10).toInt()}%") { virt = it; eq.setVirtualizer(it.toInt()); turnOn() }
                Booster("Loudness", loud, 1000f, "+${(loud / 100).toInt()} dB") { loud = it; eq.setLoudness(it.toInt()); turnOn() }
            }
        }
    }
}

@Composable
private fun Booster(label: String, value: Float, max: Float, shown: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color(0xFFDCE5FF), fontSize = 14.sp)
            Text(shown, color = Ref.Cyan, fontSize = 13.sp)
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = 0f..max,
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Ref.Violet, inactiveTrackColor = Color(0xFF1A2B63)),
        )
    }
}

/** Vertical band slider: drag or tap anywhere along the bar. */
@Composable
private fun BandBar(value: Float, min: Float, max: Float, enabled: Boolean, modifier: Modifier, onChange: (Float) -> Unit) {
    fun fromY(y: Float, h: Float): Float = (max - (y / h).coerceIn(0f, 1f) * (max - min))
    Canvas(
        modifier
            .pointerInput(min, max) { detectTapGestures { o -> onChange(fromY(o.y, size.height.toFloat())) } }
            .pointerInput(min, max) { detectVerticalDragGestures { change, _ -> change.consume(); onChange(fromY(change.position.y, size.height.toFloat())) } },
    ) {
        val cx = size.width / 2
        val frac = ((value - min) / (max - min)).coerceIn(0f, 1f)
        val y = size.height * (1f - frac)
        drawRoundRect(Color(0xFF14204F), Offset(cx - 3.dp.toPx(), 0f), Size(6.dp.toPx(), size.height), androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
        val zero = size.height * (1f - ((0f - min) / (max - min)).coerceIn(0f, 1f))
        drawRoundRect(
            Brush.verticalGradient(listOf(Ref.Cyan, Ref.Violet)).takeIf { enabled } ?: Brush.verticalGradient(listOf(Color(0xFF3A4580), Color(0xFF3A4580))),
            Offset(cx - 3.dp.toPx(), minOf(y, zero)), Size(6.dp.toPx(), kotlin.math.abs(zero - y).coerceAtLeast(2f)),
            androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()),
        )
        drawCircle(Color.White, 10.dp.toPx(), Offset(cx, y))
        drawCircle(if (enabled) Ref.Violet else Color(0xFF3A4580), 5.dp.toPx(), Offset(cx, y))
    }
}
