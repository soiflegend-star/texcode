package com.texgen.music.texwave.data.chat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.realtime.RealtimeChannel
import io.github.jan.supabase.realtime.broadcastFlow
import io.github.jan.supabase.realtime.channel
import io.github.jan.supabase.realtime.decodeRecord
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.presenceChangeFlow
import io.github.jan.supabase.realtime.realtime
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import io.github.jan.supabase.storage.upload
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Central chat data layer. All network / DB / storage access goes through here.
 * Uses only the public anon key + RLS for security.
 *
 * Live features (all realtime, with polling as a safety net in the UI):
 *  - [onlineUserIds]            who is online right now (Realtime Presence)
 *  - [openConversation]         new messages, "typing…" and "seen" for one chat
 *  - [inboxEvents]              "something changed" ping for the chat list
 */
class ChatRepository private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _authState = MutableStateFlow<ChatAuthState>(ChatAuthState.Loading)
    val authState: StateFlow<ChatAuthState> = _authState.asStateFlow()

    private val _conversations = MutableStateFlow<List<ConversationPreview>>(emptyList())
    val conversations: StateFlow<List<ConversationPreview>> = _conversations.asStateFlow()

    private val _onlineUserIds = MutableStateFlow<Set<String>>(emptySet())
    /** Ids of users that currently have the app open. */
    val onlineUserIds: StateFlow<Set<String>> = _onlineUserIds.asStateFlow()

    /** userId -> last local activity (message / typing) epoch ms — presence fallback */
    private val _recentlyActive = MutableStateFlow<Map<String, Long>>(emptyMap())
    val recentlyActive: StateFlow<Map<String, Long>> = _recentlyActive.asStateFlow()

    fun noteUserActive(userId: String) {
        if (userId.isBlank()) return
        val now = System.currentTimeMillis()
        _recentlyActive.update { it + (userId to now) }
        _onlineUserIds.update { it + userId }
    }

    @Volatile var activeConversationId: String? = null

    private val _inboxEvents = MutableSharedFlow<Unit>(
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    /** Emits whenever a message arrives or a conversation is created for me. */
    val inboxEvents: SharedFlow<Unit> = _inboxEvents.asSharedFlow()

    private var client: SupabaseClient? = null

    val isReady: Boolean
        get() = SupabaseConfig.isConfigured && client != null

    init {
        if (SupabaseConfig.isConfigured) {
            try {
                client = createSupabaseClient(
                    supabaseUrl = SupabaseConfig.SUPABASE_URL,
                    supabaseKey = SupabaseConfig.SUPABASE_ANON_KEY,
                ) {
                    install(Auth) {
                        // Keep the signed-in session across process death / app restarts.
                        alwaysAutoRefresh = true
                        autoLoadFromStorage = true
                        autoSaveToStorage = true
                        // Don't wipe the in-memory session the moment the Activity stops —
                        // that was dropping chat mid-session when the user switched apps.
                        enableLifecycleCallbacks = false
                    }
                    install(Postgrest)
                    install(Realtime)
                    install(Storage)
                }
                scope.launch { restoreSession() }
            } catch (e: Exception) {
                Log.e(TAG, "Supabase init failed", e)
                _authState.value = ChatAuthState.Error("Chat backend misconfigured")
            }
        } else {
            _authState.value = ChatAuthState.Error("Supabase not configured yet")
        }
    }

    private fun c(): SupabaseClient =
        client ?: throw IllegalStateException("Supabase not configured")

    /** For StoriesRepository and other internal helpers. */
    internal fun rawClient(): SupabaseClient = c()
    internal fun rawCurrentUserId(): String = currentUserId()

    /** Name the other person sees when I call them. */
    fun myDisplayName(): String =
        (_authState.value as? ChatAuthState.SignedIn)?.profile
            ?.let { it.displayName.ifBlank { it.username } }
            ?.ifBlank { null } ?: "TEXWAVE"

    // -------------------- Auth --------------------

    private suspend fun restoreSession() {
        try {
            // Explicitly load from disk — autoLoad can race with our first currentSessionOrNull().
            runCatching { c().auth.loadFromStorage(autoRefresh = true) }
            // Brief wait for auto-load / refresh to settle.
            repeat(6) {
                if (c().auth.currentSessionOrNull() != null) return@repeat
                delay(150)
            }
            val session = c().auth.currentSessionOrNull()
            if (session != null) {
                val uid = session.user?.id ?: resolveUserId(null)
                val profile = try { ensureProfile(uid) } catch (e: Exception) {
                    Log.e(TAG, "restore ensureProfile", e)
                    fetchProfile(uid)
                }
                if (profile != null) onSignedIn(profile) else _authState.value = ChatAuthState.SignedOut
            } else {
                _authState.value = ChatAuthState.SignedOut
            }
        } catch (e: Exception) {
            Log.e(TAG, "restoreSession", e)
            _authState.value = ChatAuthState.SignedOut
        }
    }

    private fun onSignedIn(profile: Profile) {
        _authState.value = ChatAuthState.SignedIn(profile)
        scope.launch { startRealtime() }
    }

    /** Robustly get the signed-in user id (session user, then server lookup, then fallback). */
    private suspend fun resolveUserId(fallback: String?): String {
        val a = c().auth
        a.currentSessionOrNull()?.user?.id?.let { return it }
        a.currentUserOrNull()?.id?.let { return it }
        try {
            a.retrieveUserForCurrentSession(updateSession = true).id.let { return it }
        } catch (e: Exception) {
            Log.e(TAG, "retrieveUser", e)
        }
        return fallback ?: throw IllegalStateException("Signed in, but session has no user. Check Supabase URL/key.")
    }

    /**
     * Returns my profile and creates it if it does not exist yet.
     * Uses the server function ensure_my_profile() (works even when the signup trigger is
     * missing); falls back to a plain select / insert if the function is not installed.
     */
    private suspend fun ensureProfile(userId: String): Profile {
        try {
            return c().postgrest.rpc("ensure_my_profile").decodeAs<Profile>()
        } catch (e: Exception) {
            Log.w(TAG, "ensure_my_profile unavailable, falling back", e)
        }
        fetchProfile(userId)?.let { return it }
        c().from("profiles").insert(buildJsonObject {
            put("id", userId)
            put("username", "user_" + userId.replace("-", "").take(12))
            put("display_name", "Texwave User")
        })
        return fetchProfile(userId)
            ?: throw IllegalStateException("Profile missing. Run RUN_THIS_ONCE.sql in the Supabase SQL Editor.")
    }

    private fun cleanEmail(email: String): String = email.trim().lowercase()

    private val emailRegex = Regex("""^[^\s@]+@[^\s@]+\.[^\s@]+$""")

    suspend fun signUp(email: String, password: String, displayName: String, username: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val mail = cleanEmail(email)
                val uname = username.trim().lowercase()
                val dname = displayName.trim().ifBlank { "Texwave User" }
                require(emailRegex.matches(mail)) { "Enter a valid email address." }
                require(password.length >= 6) { "Password must be at least 6 characters." }
                require(uname.matches(Regex("^[a-z0-9_]{3,24}$"))) {
                    "Username must be 3–24 chars: a-z, 0-9, underscore"
                }
                // Warn about a taken username BEFORE creating the account.
                val free = try {
                    c().postgrest.rpc(
                        "username_available",
                        parameters = buildJsonObject { put("u", uname) },
                    ).decodeAs<Boolean>()
                } catch (e: Exception) {
                    Log.w(TAG, "username_available unavailable", e)
                    true
                }
                require(free) { "That username is already taken. Choose a different username." }

                val created = c().auth.signUpWith(Email) {
                    this.email = mail
                    this.password = password
                    data = buildJsonObject {
                        put("display_name", dname)
                        put("username", uname)
                    }
                }
                // No session yet (email confirmation was on when the account was made):
                // RUN_THIS_ONCE.sql auto-confirms it, so a normal sign-in works immediately.
                // Confirm-email can leave no session; auto-confirm SQL + sign-in fixes any email.
                if (c().auth.currentSessionOrNull() == null) {
                    delay(400)
                    var signed = false
                    repeat(3) { attempt ->
                        if (signed) return@repeat
                        try {
                            c().auth.signInWith(Email) {
                                this.email = mail
                                this.password = password
                            }
                            signed = c().auth.currentSessionOrNull() != null
                        } catch (e: Exception) {
                            Log.w(TAG, "post-signup signIn attempt $attempt", e)
                            delay(500L * (attempt + 1))
                        }
                    }
                    if (!signed && c().auth.currentSessionOrNull() == null) {
                        throw IllegalStateException(
                            "Account created, but sign-in needs Confirm email OFF in Supabase " +
                                "(Authentication → Providers → Email). Then run RUN_THIS_ONCE.sql and try Sign in."
                        )
                    }
                }
                val userId = resolveUserId(created?.id)
                var profile = ensureProfile(userId)
                if (profile.username != uname || profile.displayName != dname) {
                    profile = try {
                        updateOwnProfile(userId, dname, uname, null)
                    } catch (e: Exception) {
                        Log.w(TAG, "could not apply requested username", e)
                        profile
                    }
                }
                onSignedIn(profile)
            }.recoverCatching { e -> throw friendlyError(e) }
        }

    suspend fun signIn(email: String, password: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val mail = cleanEmail(email)
                require(emailRegex.matches(mail)) { "Enter a valid email address." }
                require(password.isNotEmpty()) { "Enter your password." }
                var last: Throwable? = null
                repeat(2) { attempt ->
                    try {
                        c().auth.signInWith(Email) {
                            this.email = mail
                            this.password = password
                        }
                        val userId = resolveUserId(null)
                        onSignedIn(ensureProfile(userId))
                        return@runCatching
                    } catch (e: Exception) {
                        last = e
                        val m = (e.message ?: "").lowercase()
                        // retry only transient network / confirmation races
                        if (attempt == 0 && ("email not confirmed" in m || "network" in m || "timeout" in m)) {
                            delay(600)
                        } else throw e
                    }
                }
                throw last ?: IllegalStateException("Sign in failed")
            }.recoverCatching { e -> throw friendlyError(e) }
        }

    /** Turns raw backend / network errors into something a person can act on. */
    private fun friendlyError(error: Throwable): Throwable {
        if (error is IllegalArgumentException) return error
        val raw = (error.message ?: error.toString())
        val msg = raw.lowercase()
        val friendly = when {
            "unable to resolve host" in msg || "unknownhost" in msg || "failed to connect" in msg ||
                "timeout" in msg || "timed out" in msg || "network" in msg ->
                "No internet connection. Check your connection and try again."
            "email not confirmed" in msg || "email_not_confirmed" in msg ->
                "This email is not confirmed yet. Run RUN_THIS_ONCE.sql again in the Supabase SQL Editor (it confirms every account), then sign in."
            "invalid login credentials" in msg || "invalid_credentials" in msg ->
                "Email or password is incorrect."
            "user already registered" in msg || "already been registered" in msg || "user_already_exists" in msg ->
                "An account already exists for this email. Use Sign in instead."
            "rate limit" in msg || "over_email_send_rate_limit" in msg || "too many requests" in msg ->
                "Supabase is limiting confirmation e-mails. In Supabase go to Authentication → Sign In / Providers → Email and switch OFF \"Confirm email\", then try again."
            "signups not allowed" in msg || "signup is disabled" in msg || "signup_disabled" in msg ->
                "Sign-ups are switched off in Supabase (Authentication → Sign In / Providers → Allow new users to sign up)."
            "password" in msg && ("weak" in msg || "at least" in msg || "short" in msg) ->
                "Password is too weak. Use at least 6 characters."
            "username" in msg && ("duplicate" in msg || "unique" in msg || "23505" in msg) ->
                "That username is already taken. Choose a different username."
            "pgrst202" in msg || "could not find the function" in msg ->
                "The chat database is not set up yet. Run RUN_THIS_ONCE.sql in the Supabase SQL Editor."
            "profiles" in msg && ("permission" in msg || "row-level security" in msg || "42501" in msg) ->
                "Supabase blocked the profile. Run RUN_THIS_ONCE.sql in the Supabase SQL Editor."
            "bucket not found" in msg || "bucket_not_found" in msg || ("not found" in msg && "bucket" in msg) ->
                "Storage bucket missing. In Supabase SQL Editor run CREATE_STORAGE_BUCKETS.sql (creates chat-files, avatars, social-media)."
            "payload too large" in msg || "entity too large" in msg || "file size" in msg ->
                "File is too large (max 50 MB for chat, 5 MB for avatars)."
            else -> {
                // Never dump raw JWT / Authorization headers into the UI
                val cleaned = raw
                    .lineSequence()
                    .filterNot { line ->
                        val l = line.lowercase()
                        l.contains("authorization") || l.contains("bearer eyj") || l.startsWith("headers:")
                    }
                    .joinToString("\n")
                    .replace(Regex("eyJ[A-Za-z0-9_-]{20,}\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+"), "[token]")
                    .trim()
                    .take(180)
                cleaned.ifBlank { "Upload failed. Check Storage buckets in Supabase." }
            }
        }
        return IllegalStateException(friendly, error)
    }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        runCatching { stopRealtime() }
        runCatching {
            c().auth.signOut()
            _authState.value = ChatAuthState.SignedOut
            _conversations.value = emptyList()
        }
    }

    // -------------------- Profile --------------------

    private suspend fun updateOwnProfile(
        uid: String,
        displayName: String?,
        username: String?,
        bio: String?,
    ): Profile {
        val updated = c().from("profiles").update({
            displayName?.let { set("display_name", it.trim().take(40)) }
            username?.let { set("username", it.trim().lowercase()) }
            bio?.let { set("bio", it.trim().take(200)) }
        }) {
            filter { eq("id", uid) }
            select()
        }.decodeList<Profile>().firstOrNull()
        // Zero rows changed means the profile row does not exist yet: create it, then retry once.
        if (updated != null) return updated
        ensureProfile(uid)
        return c().from("profiles").update({
            displayName?.let { set("display_name", it.trim().take(40)) }
            username?.let { set("username", it.trim().lowercase()) }
            bio?.let { set("bio", it.trim().take(200)) }
        }) {
            filter { eq("id", uid) }
            select()
        }.decodeList<Profile>().firstOrNull()
            ?: throw IllegalStateException("Could not save your profile. Run RUN_THIS_ONCE.sql in the Supabase SQL Editor.")
    }

    suspend fun updateProfile(displayName: String? = null, username: String? = null, bio: String? = null): Result<Profile> =
        withContext(Dispatchers.IO) {
            runCatching {
                val uid = currentUserId()
                username?.let {
                    require(it.trim().lowercase().matches(Regex("^[a-z0-9_]{3,24}$"))) {
                        "Username must be 3–24 chars: a-z, 0-9, underscore"
                    }
                }
                displayName?.let { require(it.isNotBlank()) { "Display name can't be empty" } }
                val p = updateOwnProfile(uid, displayName, username, bio)
                _authState.value = ChatAuthState.SignedIn(p)
                p
            }.recoverCatching { e -> throw friendlyError(e) }
        }

    private suspend fun fetchProfile(userId: String): Profile? {
        return try {
            c().from("profiles")
                .select { filter { eq("id", userId) } }
                .decodeSingleOrNull<Profile>()
        } catch (e: Exception) {
            Log.e(TAG, "fetchProfile", e)
            null
        }
    }

    suspend fun getProfile(userId: String): Result<Profile?> = withContext(Dispatchers.IO) {
        runCatching { fetchProfile(userId) }
    }

    // -------------------- Search --------------------

    /**
     * Finds people by @username, display name (both partial), exact email or exact user id.
     * Uses the search_users() server function; falls back to a plain query on the profiles table.
     */
    suspend fun searchUsers(query: String): Result<List<Profile>> = withContext(Dispatchers.IO) {
        runCatching {
            val q = query.trim().removePrefix("@").trim()
            if (q.isEmpty()) return@runCatching emptyList()
            val me = runCatching { currentUserId() }.getOrNull()
                ?: throw IllegalStateException("Sign in to search for people.")
            // Prefer server RPC (also matches email via auth.users).
            val fromRpc = runCatching {
                c().postgrest.rpc(
                    "search_users",
                    parameters = buildJsonObject { put("q", q) },
                ).decodeList<Profile>()
            }.onFailure { Log.w(TAG, "search_users rpc", it) }.getOrNull()
            if (fromRpc != null) return@runCatching fromRpc

            // Fallback: profiles table only (username / display name).
            val safe = q.lowercase()
                .replace("%", "")
                .replace("_", "")
                .replace(",", " ")
                .replace("(", " ")
                .replace(")", " ")
                .trim()
            if (safe.isEmpty()) return@runCatching emptyList()
            val like = "%$safe%"
            c().from("profiles")
                .select {
                    filter {
                        or {
                            ilike("username", like)
                            ilike("display_name", like)
                        }
                        neq("id", me)
                    }
                    limit(40)
                }
                .decodeList<Profile>()
        }.recoverCatching { e -> throw friendlyError(e) }
    }

    // -------------------- Conversations --------------------

    suspend fun getOrCreateDirectConversation(otherUserId: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                c().postgrest.rpc(
                    "create_direct_conversation",
                    parameters = buildJsonObject {
                        put("other_user_id", otherUserId)
                    },
                ).decodeAs<String>()
            }.recoverCatching { e -> throw friendlyError(e) }
        }

    suspend fun createGroup(title: String, memberIds: List<String>): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(title.trim().length >= 2) { "Group name too short" }
                require(memberIds.isNotEmpty()) { "Add at least one member" }
                c().postgrest.rpc(
                    "create_group_conversation",
                    parameters = buildJsonObject {
                        put("group_title", title.trim().take(40))
                        put("member_ids", kotlinx.serialization.json.JsonArray(
                            memberIds.map { kotlinx.serialization.json.JsonPrimitive(it) }
                        ))
                    },
                ).decodeAs<String>()
            }.recoverCatching { e -> throw friendlyError(e) }
        }

    suspend fun loadConversations(): Result<List<ConversationPreview>> = withContext(Dispatchers.IO) {
        runCatching {
            val me = currentUserId()
            val mine = c().from("conversation_participants")
                .select { filter { eq("user_id", me) } }
                .decodeList<ConversationParticipant>()
            if (mine.isEmpty()) {
                _conversations.value = emptyList()
                return@runCatching emptyList<ConversationPreview>()
            }
            val convIds = mine.map { it.conversationId }
            val convs = c().from("conversations")
                .select { filter { isIn("id", convIds) } }
                .decodeList<Conversation>()
                .associateBy { it.id }
            val allMembers = c().from("conversation_participants")
                .select { filter { isIn("conversation_id", convIds) } }
                .decodeList<ConversationParticipant>()
                .groupBy { it.conversationId }
            val otherIds = allMembers.values.flatten().map { it.userId }.filter { it != me }.distinct()
            val profiles = if (otherIds.isEmpty()) emptyMap() else {
                c().from("profiles")
                    .select { filter { isIn("id", otherIds) } }
                    .decodeList<Profile>()
                    .associateBy { it.id }
            }

            val previews = mutableListOf<ConversationPreview>()
            for (p in mine) {
                val conv = convs[p.conversationId] ?: continue
                val otherId = allMembers[p.conversationId].orEmpty().firstOrNull { it.userId != me }?.userId
                val other = if (conv.isGroup) null else otherId?.let { profiles[it] }

                val lastMsg = c().from("messages")
                    .select {
                        filter {
                            eq("conversation_id", p.conversationId)
                            exact("deleted_at", null)
                        }
                        order("created_at", Order.DESCENDING)
                        limit(1)
                    }
                    .decodeList<Message>()
                    .firstOrNull()

                // Unread = messages from others after my last_read_at (never read -> all of them).
                val unread = c().from("messages")
                    .select(Columns.raw("id")) {
                        filter {
                            eq("conversation_id", p.conversationId)
                            if (p.lastReadAt != null) gt("created_at", p.lastReadAt)
                            neq("sender_id", me)
                            exact("deleted_at", null)
                        }
                    }
                    .decodeList<Map<String, String>>()
                    .size

                previews += ConversationPreview(conv, other, lastMsg, unread)
            }
            previews.sortedByDescending {
                maxOf(parseIsoMillis(it.lastMessage?.createdAt), parseIsoMillis(it.conversation.updatedAt))
            }.also { list ->
                _conversations.value = list
                // Seed online set from fresh last_seen so UI works even if Presence channel fails
                val now = System.currentTimeMillis()
                val hot = list.mapNotNull { prev ->
                    val u = prev.otherUser ?: return@mapNotNull null
                    val seen = parseIsoMillis(u.lastSeenAt)
                    if (seen > 0L && now - seen < 10 * 60_000L) u.id else null
                }.toSet()
                if (hot.isNotEmpty()) _onlineUserIds.update { it + hot }
                list.forEach { prev ->
                    val sid = prev.lastMessage?.senderId
                    if (sid != null && sid != me) {
                        val msgT = parseIsoMillis(prev.lastMessage?.createdAt)
                        if (msgT > 0 && now - msgT < 5 * 60_000L) noteUserActive(sid)
                    }
                }
            }
        }.recoverCatching { e -> throw friendlyError(e) }
    }

    /** Other members of a conversation (with profiles) and how far each has read. */
    suspend fun loadMembers(conversationId: String): Result<ConversationMembers> = withContext(Dispatchers.IO) {
        runCatching {
            val me = currentUserId()
            val parts = c().from("conversation_participants")
                .select { filter { eq("conversation_id", conversationId) } }
                .decodeList<ConversationParticipant>()
                .filter { it.userId != me }
            val ids = parts.map { it.userId }
            val profiles = if (ids.isEmpty()) emptyList() else {
                c().from("profiles")
                    .select { filter { isIn("id", ids) } }
                    .decodeList<Profile>()
            }
            ConversationMembers(
                profiles = profiles,
                readAt = parts.associate { it.userId to parseIsoMillis(it.lastReadAt) },
            )
        }
    }

    // -------------------- Messages --------------------

    suspend fun loadMessages(
        conversationId: String,
        before: String? = null,
        limit: Int = 40,
    ): Result<List<ChatMessageUi>> = withContext(Dispatchers.IO) {
        runCatching {
            val me = currentUserId()
            val msgs = c().from("messages")
                .select {
                    filter {
                        eq("conversation_id", conversationId)
                        if (before != null) lt("created_at", before)
                    }
                    order("created_at", Order.DESCENDING)
                    // Fetch a few extras so soft-deleted rows don't shrink the page.
                    limit((limit + 8).toLong())
                }
                .decodeList<Message>()
                .filter { it.deletedAt == null }
                .take(limit) // newest-first from server; reverse to chronological for the UI
                .reversed()

            val msgIds = msgs.map { it.id }
            val atts = if (msgIds.isNotEmpty()) {
                c().from("attachments")
                    .select { filter { isIn("message_id", msgIds) } }
                    .decodeList<Attachment>()
                    .groupBy { it.messageId }
            } else emptyMap()

            msgs.map { m ->
                ChatMessageUi(
                    message = m,
                    attachments = atts[m.id].orEmpty(),
                    isMine = m.senderId == me,
                )
            }
        }
    }

    /** Wraps a message that arrived by realtime (looks up attachments that may land a moment later). */
    suspend fun toUi(m: Message): ChatMessageUi = withContext(Dispatchers.IO) {
        val me = runCatching { currentUserId() }.getOrDefault("")
        var atts = emptyList<Attachment>()
        if (m.body.isNullOrBlank()) {
            // attachment messages: the attachment row is inserted right after the message row
            repeat(4) {
                if (atts.isEmpty()) {
                    delay(700)
                    atts = runCatching {
                        c().from("attachments")
                            .select { filter { eq("message_id", m.id) } }
                            .decodeList<Attachment>()
                    }.getOrDefault(emptyList())
                }
            }
        }
        ChatMessageUi(message = m, attachments = atts, isMine = m.senderId == me)
    }

    suspend fun sendText(conversationId: String, text: String, clientMsgId: String = UUID.randomUUID().toString()): Result<Message> =
        withContext(Dispatchers.IO) {
            val body = text.trim()
            require(body.isNotEmpty()) { "Empty message" }
            val me = runCatching { currentUserId() }.getOrElse { return@withContext Result.failure(friendlyError(it)) }
            noteUserActive(me)
            runCatching { c().postgrest.rpc("touch_presence") }
            var last: Throwable? = null
            repeat(3) { attempt ->
                try {
                    val msg = c().from("messages")
                        .insert(
                            buildJsonObject {
                                put("conversation_id", conversationId)
                                put("sender_id", me)
                                put("body", body)
                                put("client_msg_id", clientMsgId)
                            }
                        ) { select() }
                        .decodeSingle<Message>()
                    noteUserActive(me)
                    _inboxEvents.tryEmit(Unit)
                    return@withContext Result.success(msg)
                } catch (e: Exception) {
                    last = e
                    if (attempt < 2) kotlinx.coroutines.delay(350L * (attempt + 1))
                }
            }
            Result.failure(friendlyError(last ?: Exception("Send failed")))
        }

    /** Send a Resonance (song + optional mood). Uploads audio when possible so the other person can play/download it. */
    suspend fun sendResonance(
        conversationId: String,
        payload: Resonance.Payload,
        clientMsgId: String = UUID.randomUUID().toString(),
        audioUri: android.net.Uri? = null,
    ): Result<Message> = withContext(Dispatchers.IO) {
        runCatching {
            var pathInStorage: String? = null
            if (audioUri != null) {
                runCatching {
                    val bytes = when (audioUri.scheme?.lowercase()) {
                        "file" -> java.io.File(audioUri.path!!).readBytes()
                        else -> appContext.contentResolver.openInputStream(audioUri)?.use { it.readBytes() }
                    }
                    if (bytes != null && bytes.isNotEmpty() && bytes.size <= 20_971_520) { // 20 MB
                        val me = currentUserId()
                        val storagePath = "$conversationId/${me}_${UUID.randomUUID()}_resonance.m4a"
                        c().storage.from(SupabaseConfig.STORAGE_BUCKET)
                            .upload(storagePath, bytes, upsert = false)
                        pathInStorage = storagePath
                    }
                }
            }
            val body = payload.copy(storagePath = pathInStorage).encode()
            sendText(conversationId, body, clientMsgId).getOrThrow()
        }.recoverCatching { e -> throw friendlyError(e) }
    }

    /** Download a Resonance audio file from storage. */
    suspend fun downloadResonanceAudio(storagePath: String): Result<ByteArray> = withContext(Dispatchers.IO) {
        runCatching {
            c().storage.from(SupabaseConfig.STORAGE_BUCKET).downloadAuthenticated(storagePath)
        }
    }

    suspend fun softDeleteMessage(messageId: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            c().from("messages").update({
                set("deleted_at", Instant.now().toString())
            }) {
                filter {
                    eq("id", messageId)
                    eq("sender_id", currentUserId())
                }
            }
            Unit
        }
    }

    /** Marks everything in the conversation as seen (the other person sees ✓✓ turn blue). */
    suspend fun markRead(conversationId: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            runCatching { noteUserActive(currentUserId()) }
            runCatching { c().postgrest.rpc("touch_presence") }

            try {
                c().postgrest.rpc(
                    "mark_conversation_read",
                    parameters = buildJsonObject { put("conv", conversationId) },
                )
            } catch (e: Exception) {
                c().from("conversation_participants").update({
                    set("last_read_at", Instant.now().toString())
                }) {
                    filter {
                        eq("conversation_id", conversationId)
                        eq("user_id", currentUserId())
                    }
                }
            }
            Unit
        }
    }

    // -------------------- Attachments --------------------

    suspend fun sendAttachment(
        conversationId: String,
        uri: Uri,
        onProgress: (Float) -> Unit = {},
    ): Result<ChatMessageUi> = withContext(Dispatchers.IO) {
        runCatching {
            val me = currentUserId()
            noteUserActive(me)
            runCatching { c().postgrest.rpc("touch_presence") }
            val (name, size, mime) = resolveFileMeta(uri)
            require(size <= SupabaseConfig.MAX_FILE_BYTES) {
                "File exceeds 50 MB free-plan limit (${size / (1024 * 1024)} MB)"
            }
            require(size > 0) { "Empty file" }

            val bytes = when (uri.scheme?.lowercase()) {
                "file" -> {
                    val path = uri.path ?: throw IllegalStateException("Bad file path")
                    java.io.File(path).readBytes()
                }
                else -> appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("Cannot read file")
            }

            // 1. Upload with retries — never create message without successful storage
            val safeName = name.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(80)
            val storagePath = "$conversationId/${me}_${UUID.randomUUID()}_$safeName"
            onProgress(0.1f)
            var uploaded = false
            var lastUp: Exception? = null
            repeat(3) { attempt ->
                try {
                    c().storage.from(SupabaseConfig.STORAGE_BUCKET)
                        .upload(storagePath, bytes, upsert = attempt > 0)
                    uploaded = true
                    return@repeat
                } catch (e: Exception) {
                    lastUp = e
                    if (attempt < 2) kotlinx.coroutines.delay(400L * (attempt + 1))
                }
            }
            if (!uploaded) throw lastUp ?: IllegalStateException("Upload failed")
            onProgress(0.8f)

            // 2. Message + attachment rows
            val msg = c().from("messages")
                .insert(
                    buildJsonObject {
                        put("conversation_id", conversationId)
                        put("sender_id", me)
                        put("body", JsonNull)
                        put("client_msg_id", UUID.randomUUID().toString())
                    }
                ) { select() }
                .decodeSingle<Message>()

            val att = c().from("attachments")
                .insert(
                    buildJsonObject {
                        put("message_id", msg.id)
                        put("storage_path", storagePath)
                        put("original_name", name)
                        put("mime_type", mime)
                        put("size_bytes", size)
                    }
                ) { select() }
                .decodeSingle<Attachment>()

            onProgress(1f)
            noteUserActive(me)
            _inboxEvents.tryEmit(Unit)
            ChatMessageUi(message = msg, attachments = listOf(att), isMine = true)
        }.recoverCatching { e -> throw friendlyError(e) }
    }


    /**
     * Break a big file into 40 MB parts, upload each, then post ONE message that carries all parts.
     * The receiving app downloads the parts and joins them back into the original file.
     */
    suspend fun sendChunkedFile(
        conversationId: String,
        uri: Uri,
        onProgress: (Float) -> Unit = {},
    ): Result<ChatMessageUi> = withContext(Dispatchers.IO) {
        runCatching {
            val me = currentUserId()
            noteUserActive(me)
            val (name, size, _) = resolveFileMeta(uri)
            require(size > 0) { "Empty file" }
            require(size <= SupabaseConfig.MAX_CHUNKED_BYTES) {
                "Video is too large (${size / (1024 * 1024)} MB). Max is ${SupabaseConfig.MAX_CHUNKED_BYTES / (1024 * 1024)} MB."
            }
            val chunk = SupabaseConfig.CHUNK_BYTES
            val total = ((size + chunk - 1) / chunk).toInt()
            val groupId = UUID.randomUUID().toString().take(8)
            val safeName = name.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(60)
            val paths = ArrayList<String>()
            val sizes = ArrayList<Long>()
            val input = when (uri.scheme?.lowercase()) {
                "file" -> java.io.FileInputStream(java.io.File(uri.path ?: throw IllegalStateException("Bad file path")))
                else -> appContext.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot read file")
            }
            input.use { ins ->
                for (i in 0 until total) {
                    val want = minOf(chunk, size - i * chunk).toInt()
                    val buf = ByteArray(want)
                    var off = 0
                    while (off < want) {
                        val r = ins.read(buf, off, want - off)
                        if (r < 0) break
                        off += r
                    }
                    require(off == want) { "Could not read the whole file" }
                    val path = "$conversationId/${me}_${groupId}_$safeName.part${i + 1}of$total"
                    var uploaded = false
                    var lastUp: Exception? = null
                    repeat(3) { attempt ->
                        if (uploaded) return@repeat
                        try {
                            c().storage.from(SupabaseConfig.STORAGE_BUCKET).upload(path, buf, upsert = attempt > 0)
                            uploaded = true
                        } catch (e: Exception) {
                            lastUp = e
                            kotlinx.coroutines.delay(600L * (attempt + 1))
                        }
                    }
                    if (!uploaded) throw lastUp ?: IllegalStateException("Upload of part ${i + 1} failed")
                    paths.add(path)
                    sizes.add(want.toLong())
                    onProgress(0.05f + 0.9f * (i + 1) / total)
                }
            }
            val msg = c().from("messages")
                .insert(
                    buildJsonObject {
                        put("conversation_id", conversationId)
                        put("sender_id", me)
                        put("body", JsonNull)
                        put("client_msg_id", UUID.randomUUID().toString())
                    }
                ) { select() }
                .decodeSingle<Message>()
            val atts = ArrayList<Attachment>()
            for (i in 0 until total) {
                val a = c().from("attachments")
                    .insert(
                        buildJsonObject {
                            put("message_id", msg.id)
                            put("storage_path", paths[i])
                            put("original_name", "$name.part${i + 1}of$total")
                            put("mime_type", "application/x-texwave-part")
                            put("size_bytes", sizes[i])
                        }
                    ) { select() }
                    .decodeSingle<Attachment>()
                atts.add(a)
            }
            onProgress(1f)
            noteUserActive(me)
            _inboxEvents.tryEmit(Unit)
            ChatMessageUi(message = msg, attachments = atts, isMine = true)
        }.recoverCatching { e -> throw friendlyError(e) }
    }

    /**
     * Upload a chat theme background and return a public HTTPS URL both users can load.
     * Falls back to authenticated download path style public URL for chat-files bucket.
     */
    suspend fun uploadThemeBackground(conversationId: String, uri: Uri): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val me = currentUserId()
                val bytes = when (uri.scheme?.lowercase()) {
                    "file" -> {
                        val path = uri.path ?: throw IllegalStateException("Bad file path")
                        java.io.File(path).readBytes()
                    }
                    else -> appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw IllegalStateException("Cannot read image")
                }
                require(bytes.isNotEmpty()) { "Empty image" }
                require(bytes.size <= SupabaseConfig.MAX_FILE_BYTES) { "Image too large" }
                val storagePath = "themes/$conversationId/${me}_${UUID.randomUUID()}.jpg"
                c().storage.from(SupabaseConfig.STORAGE_BUCKET)
                    .upload(storagePath, bytes, upsert = true)
                // Token, not a public URL: the bucket may be private, so the peer downloads it with
                // their signed-in session (see downloadThemeBackground).
                "sb:$storagePath"
            }.recoverCatching { e -> throw friendlyError(e) }
        }

    /** Downloads a shared theme photo ("sb:<path>") with the signed-in session and caches it locally. */
    suspend fun downloadThemeBackground(token: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val path = token.removePrefix("sb:")
            val out = java.io.File(appContext.filesDir, "chat_theme_${path.hashCode().toUInt()}.jpg")
            if (!out.exists() || out.length() < 1000) {
                val bytes = c().storage.from(SupabaseConfig.STORAGE_BUCKET).downloadAuthenticated(path)
                out.writeBytes(bytes)
            }
            out.absolutePath
        }
    }

    suspend fun downloadAttachment(att: Attachment): Result<ByteArray> = withContext(Dispatchers.IO) {
        runCatching {
            c().storage.from(SupabaseConfig.STORAGE_BUCKET)
                .downloadAuthenticated(att.storagePath)
        }
    }

    // -------------------- Realtime: presence + inbox --------------------

    @Volatile private var foreground = true
    /** True while the app is on screen. */
    val isForeground: Boolean get() = foreground
    private val realtimeMutex = Mutex()
    private var presenceChannel: RealtimeChannel? = null
    private var inboxChannel: RealtimeChannel? = null
    private var realtimeJobs: Job? = null

    /** Called from MainActivity: online only while the app is on screen. */
    fun setForeground(fg: Boolean) {
        foreground = fg
        if (client == null) return
        scope.launch {
            if (fg) {
                // Re-attach session after background (lifecycle callbacks were disabled above).
                runCatching {
                    if (c().auth.currentSessionOrNull() == null) {
                        c().auth.loadFromStorage(autoRefresh = true)
                    } else {
                        // Soft refresh so JWT does not expire mid-chat.
                        runCatching {
                            val s = c().auth.currentSessionOrNull()
                            if (s != null && s.refreshToken.isNotBlank()) {
                                // gotrue-kt 2.x: refreshSession(refreshToken)
                                c().auth.refreshSession(s.refreshToken)
                            }
                        }
                    }
                }.onFailure { Log.w(TAG, "foreground session refresh", it) }

                val session = runCatching { c().auth.currentSessionOrNull() }.getOrNull()
                if (session != null && _authState.value !is ChatAuthState.SignedIn) {
                    val uid = session.user?.id ?: runCatching { resolveUserId(null) }.getOrNull()
                    if (uid != null) {
                        val profile = runCatching { ensureProfile(uid) }.getOrNull()
                            ?: runCatching { fetchProfile(uid) }.getOrNull()
                        if (profile != null) onSignedIn(profile)
                    }
                }
                if (_authState.value is ChatAuthState.SignedIn) startRealtime()
            } else {
                // Keep inbox realtime so we can notify on new messages while backgrounded.
                // Only drop presence (so we show offline).
                if (_authState.value is ChatAuthState.SignedIn) {
                    runCatching {
                        presenceChannel?.let { ch ->
                            runCatching { ch.untrack() }
                            runCatching { c().realtime.removeChannel(ch) }
                        }
                        presenceChannel = null
                        _onlineUserIds.value = emptySet()
                        runCatching { c().postgrest.rpc("touch_presence") }
                    }
                }
            }
        }
    }

    
    fun setActiveConversation(id: String?) {
        activeConversationId = id
    }

    /** Re-join inbox if the realtime socket dropped (called from ChatKeepAliveService). */
    suspend fun ensureInboxAlive() {
        if (_authState.value !is ChatAuthState.SignedIn) return
        val me = runCatching { currentUserId() }.getOrNull() ?: return
        if (inboxChannel == null) {
            runCatching { joinInbox(me) }
        }
        runCatching { c().postgrest.rpc("touch_presence") }
    }

private suspend fun startRealtime() = realtimeMutex.withLock {
        if (client == null) return@withLock
        if (_authState.value !is ChatAuthState.SignedIn) return@withLock
        val me = runCatching { currentUserId() }.getOrNull() ?: return@withLock

        // Always ensure inbox is joined (for push-style local notifications).
        runCatching { joinInbox(me) }.onFailure { Log.e(TAG, "inbox", it) }

        if (!foreground) return@withLock
        if (realtimeJobs?.isActive == true) {
            runCatching { joinPresence(me) }
            return@withLock
        }

        val job = scope.launch {
            // Heartbeat: keeps "last seen" fresh and re-joins presence if the socket dropped.
            launch {
                while (isActive) {
                    if (foreground) runCatching { c().postgrest.rpc("touch_presence") }
                    delay(8_000)
                    if (inboxChannel == null) runCatching { joinInbox(me) }
                    if (foreground && presenceChannel == null) runCatching { joinPresence(me) }
                }
            }
            runCatching { joinPresence(me) }.onFailure { Log.e(TAG, "presence", it) }
        }
        realtimeJobs = job
    }

    private suspend fun joinPresence(me: String) {
        if (presenceChannel != null) return
        val ch = c().channel("texwave-online") { presence { key = me } }
        presenceChannel = ch
        scope.launch {
            ch.presenceChangeFlow().collect { diff ->
                _onlineUserIds.update { cur ->
                    val joined = diff.joins.keys
                    // re-track is leave+join: keep those online
                    val next = (cur + joined) - (diff.leaves.keys - joined)
                    next + me // always count ourselves online while connected
                }
            }
        }
        // Do NOT wipe the online set on brief socket flaps — only clear on hard stopRealtime()
        delay(200)
        try {
            withTimeout(20_000) { ch.subscribe(blockUntilSubscribed = true) }
            ch.track(buildJsonObject {
                put("user_id", me)
                put("online", true)
                put("at", System.currentTimeMillis())
            })
            _onlineUserIds.update { it + me }
            // Keep presence alive with re-track every 20s
            scope.launch {
                while (presenceChannel === ch) {
                    delay(8_000)
                    runCatching {
                        ch.track(buildJsonObject {
                            put("user_id", me)
                            put("online", true)
                            put("at", System.currentTimeMillis())
                        })
                        _onlineUserIds.update { it + me }
                    }
                }
            }
        } catch (e: Exception) {
            runCatching { c().realtime.removeChannel(ch) }
            presenceChannel = null
            throw e
        }
    }

    private suspend fun joinInbox(me: String) {
        if (inboxChannel != null) return
        val ch = c().channel("texwave-inbox-$me")
        inboxChannel = ch
        val msgs = ch.postgresChangeFlow<PostgresAction.Insert>(schema = "public") { table = "messages" }
        val joined = ch.postgresChangeFlow<PostgresAction.Insert>(schema = "public") {
            table = "conversation_participants"
            filter = "user_id=eq.$me"
        }
        scope.launch {
            msgs.collect { change ->
                _inboxEvents.tryEmit(Unit)
                // Local notification when a message arrives (not from me)
                runCatching {
                    val m = change.decodeRecord<Message>()
                    val myId = runCatching { currentUserId() }.getOrNull()
                    if (myId != null && m.senderId != myId) {
                        noteUserActive(m.senderId)
                        val viewingThis = foreground && activeConversationId == m.conversationId
                        if (!viewingThis && !ChatPrefs.isMuted(appContext, m.conversationId)) {
                            ChatNotifier.ensureChannel(appContext)
                            val call = CallSignal.parse(m.body)
                            if (call != null && call.action == CallSignal.Action.INVITE) {
                                ChatNotifier.notifyIncomingCall(
                                    appContext,
                                    conversationId = m.conversationId,
                                    callerName = call.fromName.ifBlank { "Someone" },
                                    video = call.video,
                                    room = call.room,
                                )
                            } else {
                                ChatNotifier.notifyNewMessage(
                                    appContext,
                                    conversationId = m.conversationId,
                                    preview = when {
                                        Resonance.isResonance(m.body) ->
                                            Resonance.parse(m.body)?.preview() ?: "Shared a song"
                                        ChatThemeStore.parse(m.body) != null -> "Updated chat theme"
                                        SilentSignalStore.parse(m.body) != null ->
                                            SilentSignalStore.label(m.body) ?: "Sent a signal"
                                        m.body.isNullOrBlank() -> "Sent a photo or file"
                                        else -> m.body!!.take(80)
                                    },
                                    title = "TEXWAVE",
                                )
                            }
                        }
                    }
                }.onFailure {
                    Log.e(TAG, "notify failed", it)
                    // Still alert that something arrived
                    runCatching {
                        ChatNotifier.notifyNewMessage(
                            appContext,
                            conversationId = "inbox",
                            preview = "New message",
                            title = "TEXWAVE",
                        )
                    }
                }
            }
        }
        scope.launch { joined.collect { _inboxEvents.tryEmit(Unit) } }
        delay(200)
        try {
            withTimeout(20_000) { ch.subscribe(blockUntilSubscribed = true) }
        } catch (e: Exception) {
            runCatching { c().realtime.removeChannel(ch) }
            inboxChannel = null
            throw e
        }
    }

    private suspend fun stopRealtime() = realtimeMutex.withLock {
        realtimeJobs?.cancel()
        realtimeJobs = null
        withContext(NonCancellable) {
            presenceChannel?.let { ch ->
                runCatching { ch.untrack() }
                runCatching { c().realtime.removeChannel(ch) }
            }
            inboxChannel?.let { ch -> runCatching { c().realtime.removeChannel(ch) } }
            presenceChannel = null
            inboxChannel = null
            _onlineUserIds.value = emptySet()
            // stamp "last seen" right now so the other person sees an accurate time
            runCatching { if (c().auth.currentSessionOrNull() != null) c().postgrest.rpc("touch_presence") }
        }
    }

    // -------------------- Realtime: one open conversation --------------------

    /**
     * Live state of one open chat: incoming messages, who is typing, who has read what.
     * Call [ConversationLive.close] when the screen is left.
     */
    inner class ConversationLive(val conversationId: String) {
        private val _incoming = MutableSharedFlow<Message>(extraBufferCapacity = 64)
        val incoming: SharedFlow<Message> = _incoming.asSharedFlow()

        private val _typing = MutableStateFlow<Set<String>>(emptySet())
        /** User ids that are typing right now. */
        val typingUserIds: StateFlow<Set<String>> = _typing.asStateFlow()

        private val _readAt = MutableStateFlow<Map<String, Long>>(emptyMap())
        /** user id -> epoch millis of that user's last_read_at (live). */
        val readAt: StateFlow<Map<String, Long>> = _readAt.asStateFlow()

        private var channel: RealtimeChannel? = null
        private var job: Job? = null
        private val expiry = ConcurrentHashMap<String, Job>()
        private var me: String = ""

        /** Merge read times loaded by a normal query (keeps whichever is newer). */
        fun seedReadAt(map: Map<String, Long>) {
            _readAt.update { cur ->
                val out = cur.toMutableMap()
                map.forEach { (k, v) -> out[k] = maxOf(out[k] ?: 0L, v) }
                out
            }
        }

        internal fun start() {
            job = scope.launch {
                try {
                    me = currentUserId()
                    val ch = c().channel("chat-$conversationId")
                    channel = ch
                    val inserts = ch.postgresChangeFlow<PostgresAction.Insert>(schema = "public") {
                        table = "messages"
                        filter = "conversation_id=eq.$conversationId"
                    }
                    val reads = ch.postgresChangeFlow<PostgresAction.Update>(schema = "public") {
                        table = "conversation_participants"
                        filter = "conversation_id=eq.$conversationId"
                    }
                    val typingFlow = ch.broadcastFlow<TypingEvent>("typing")

                    launch {
                        inserts.collect { change ->
                            try {
                                val m = change.decodeRecord<Message>()
                                if (m.senderId != me) {
                                    clearTyping(m.senderId)
                                    _incoming.emit(m)
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "decode realtime message", e)
                            }
                        }
                    }
                    launch {
                        reads.collect { change ->
                            try {
                                val p = change.decodeRecord<ConversationParticipant>()
                                if (p.userId != me) {
                                    _readAt.update { it + (p.userId to parseIsoMillis(p.lastReadAt)) }
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "decode realtime read", e)
                            }
                        }
                    }
                    launch {
                        typingFlow.collect { ev ->
                            if (ev.userId == me) return@collect
                            if (ev.typing) {
                                noteUserActive(ev.userId)
                                _typing.update { it + ev.userId }
                                expiry[ev.userId]?.cancel()
                                // if the "stopped" event is lost, drop the indicator on its own
                                expiry[ev.userId] = launch {
                                    delay(4_500)
                                    _typing.update { it - ev.userId }
                                }
                            } else {
                                clearTyping(ev.userId)
                            }
                        }
                    }
                    delay(200)
                    withTimeout(20_000) { ch.subscribe(blockUntilSubscribed = true) }
                } catch (e: Exception) {
                    Log.e(TAG, "conversation realtime", e)
                }
            }
        }

        private fun clearTyping(userId: String) {
            expiry.remove(userId)?.cancel()
            _typing.update { it - userId }
        }

        /** Tell the other side that I am typing / stopped typing. */
        fun sendTyping(isTyping: Boolean) {
            val ch = channel ?: return
            val uid = me.ifEmpty { return }
            scope.launch {
                runCatching {
                    ch.broadcast("typing", buildJsonObject {
                        put("user_id", uid)
                        put("typing", isTyping)
                    })
                }
            }
        }

        fun close() {
            val ch = channel
            val uid = me
            job?.cancel()
            expiry.values.forEach { it.cancel() }
            scope.launch(NonCancellable) {
                if (ch != null && uid.isNotEmpty()) {
                    runCatching {
                        ch.broadcast("typing", buildJsonObject {
                            put("user_id", uid)
                            put("typing", false)
                        })
                    }
                }
                ch?.let { runCatching { c().realtime.removeChannel(it) } }
            }
        }
    }

    fun openConversation(conversationId: String): ConversationLive {
        activeConversationId = conversationId
        return ConversationLive(conversationId).also { it.start() }
    }

    fun clearActiveConversation(conversationId: String? = null) {
        if (conversationId == null || activeConversationId == conversationId) {
            activeConversationId = null
        }
    }

    // -------------------- Helpers --------------------

    private fun currentUserId(): String =
        c().auth.currentUserOrNull()?.id
            ?: c().auth.currentSessionOrNull()?.user?.id
            ?: throw IllegalStateException("Not signed in")

    private fun resolveFileMeta(uri: Uri): Triple<String, Long, String> {
        var name = "file"
        var size = 0L
        appContext.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
            }
        }
        if (uri.scheme == "file") {
            val f = java.io.File(uri.path ?: "")
            if (f.exists()) { name = f.name; size = f.length() }
        }
        val mime = appContext.contentResolver.getType(uri)
            ?: when {
                name.endsWith(".m4a", true) || name.endsWith(".aac", true) -> "audio/mp4"
                name.endsWith(".mp3", true) -> "audio/mpeg"
                name.endsWith(".mp4", true) -> "video/mp4"
                name.endsWith(".mov", true) -> "video/quicktime"
                name.endsWith(".webm", true) -> "video/webm"
                name.endsWith(".mkv", true) -> "video/x-matroska"
                name.endsWith(".3gp", true) -> "video/3gpp"
                name.endsWith(".jpg", true) || name.endsWith(".jpeg", true) -> "image/jpeg"
                name.endsWith(".png", true) -> "image/png"
                else -> "application/octet-stream"
            }
        if (size <= 0) {
            appContext.contentResolver.openInputStream(uri)?.use { size = it.available().toLong() }
        }
        return Triple(name, size, mime)
    }

    /** Shrinks any photo to a square-ish 512 px JPEG so uploads are small and always under the limit. */
    private fun compressAvatar(uri: Uri): ByteArray {
        val resolver = appContext.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        val longest = maxOf(bounds.outWidth, bounds.outHeight)
        while (longest / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("Cannot read that image")
        val scale = 512f / maxOf(bmp.width, bmp.height)
        val out = if (scale < 1f) {
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true)
        } else bmp
        val stream = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 88, stream)
        return stream.toByteArray()
    }

    /** Uploads a profile photo to the public "avatars" bucket and stores its URL on my profile. */
    suspend fun uploadAvatar(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val me = currentUserId()
            val bytes = compressAvatar(uri)
            val path = "$me/avatar.jpg"
            c().storage.from(SupabaseConfig.AVATAR_BUCKET).upload(path, bytes, upsert = true)
            // ?v= makes the image reload after the photo changes (same path every time)
            val url = "${SupabaseConfig.SUPABASE_URL}/storage/v1/object/public/${SupabaseConfig.AVATAR_BUCKET}/$path?v=${System.currentTimeMillis()}"
            val p = c().from("profiles").update({ set("avatar_url", url) }) {
                filter { eq("id", me) }
                select()
            }.decodeList<Profile>().firstOrNull() ?: throw IllegalStateException("Profile missing")
            _authState.value = ChatAuthState.SignedIn(p)
            url
        }.recoverCatching { e ->
            val m = (e.message ?: "").lowercase()
            if ("bucket" in m && "not found" in m) {
                throw IllegalStateException("Photo storage is not set up. Run RUN_THIS_ONCE.sql in the Supabase SQL Editor.", e)
            }
            throw friendlyError(e)
        }
    }

    companion object {
        private const val TAG = "ChatRepository"
        @Volatile private var instance: ChatRepository? = null

        fun get(context: Context): ChatRepository =
            instance ?: synchronized(this) {
                instance ?: ChatRepository(context.applicationContext).also { instance = it }
            }
    }
}
