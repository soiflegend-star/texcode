package com.texgen.music.texwave.ui.components

import com.texgen.music.texwave.ui.theme.Tx

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val NavViolet = Tx.Accent
private val NavCyan = Tx.Accent2
private val NavMagenta = Color(0xFFFF58D8)
private val NavIdle = Color(0xFF74819A)

private data class NavEntry(val label: String, val selectedIcon: ImageVector, val icon: ImageVector)

/** TEXWAVE floating glass dock: animated glow border, springy icons and a glowing active pill. */
@Composable
fun TexNavBar(selected: Int, onSelect: (Int) -> Unit) {
    val sound = rememberUiSound()
    val entries = remember {
        listOf(
            NavEntry("Home", Icons.Rounded.Home, Icons.Outlined.Home),
            NavEntry("Search", Icons.Rounded.Search, Icons.Rounded.Search),
            NavEntry("Library", Icons.Rounded.LibraryMusic, Icons.Rounded.LibraryMusic),
            NavEntry("Chat", Icons.Rounded.Chat, Icons.Rounded.Chat),
            NavEntry("Phantom", Icons.Rounded.AutoAwesome, Icons.Rounded.AutoAwesome),
        )
    }
    val sweep by rememberInfiniteTransition(label = "dockSweep").animateFloat(
        0f, 1200f,
        infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart),
        label = "dockSweepX",
    )
    val shape = RoundedCornerShape(28.dp)
    Box(
        Modifier
            .navigationBarsPadding()
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .shadow(22.dp, shape, ambientColor = NavViolet.copy(alpha = 0.20f), spotColor = NavCyan.copy(alpha = 0.16f))
                .clip(shape)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x14FFFFFF),
                            Color(0x04FFFFFF),
                            Color(0xF2131315),
                            Color(0xF20A0A0C),
                        )
                    )
                )
                .background(Color(0xE80E0E10))
                .border(
                    1.2.dp,
                    Brush.linearGradient(
                        listOf(
                            Color(0x20FFFFFF),
                            NavViolet.copy(alpha = 0.38f),
                            NavCyan.copy(alpha = 0.32f),
                            NavMagenta.copy(alpha = 0.10f),
                            NavViolet.copy(alpha = 0.26f),
                            Color(0x10FFFFFF),
                        ),
                        start = Offset(sweep, 0f),
                        end = Offset(sweep + 600f, 0f),
                        tileMode = TileMode.Repeated,
                    ),
                    shape,
                )
                .padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            entries.forEachIndexed { index, e ->
                val on = index == selected
                val tRaw by animateFloatAsState(
                    if (on) 1f else 0f,
                    spring(dampingRatio = 0.55f, stiffness = 380f),
                    label = "navT$index",
                )
                val t = tRaw.coerceIn(0f, 1f)
                Column(
                    Modifier
                        .weight(1f)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) {
                            if (!on) sound(com.texgen.music.texwave.util.UiSound.Kind.TAB)
                            onSelect(index)
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .width(46.dp)
                            .height(30.dp)
                            .graphicsLayer {
                                scaleX = 1f + 0.16f * tRaw
                                scaleY = 1f + 0.16f * tRaw
                                translationY = -3.dp.toPx() * tRaw
                            }
                            .clip(RoundedCornerShape(15.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(NavViolet.copy(alpha = 0.24f * t), NavCyan.copy(alpha = 0.13f * t))
                                )
                            )
                            .border(
                                1.dp,
                                Brush.horizontalGradient(
                                    listOf(NavViolet.copy(alpha = 0.72f * t), NavCyan.copy(alpha = 0.5f * t))
                                ),
                                RoundedCornerShape(15.dp),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            if (on) e.selectedIcon else e.icon,
                            contentDescription = e.label,
                            tint = if (on) Color.White else NavIdle,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                    Text(
                        e.label,
                        color = if (on) NavCyan else NavIdle,
                        fontSize = 10.5.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.padding(top = 3.dp),
                    )
                }
            }
        }
    }
}
