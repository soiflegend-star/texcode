package com.texgen.music.texwave.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.Artwork
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Library Radar — every song is a soft light on a sky-map.
 * Tap a light to play that song; bigger/brighter = more plays or liked.
 */
@Composable
fun PulseRadarScreen(
    lib: LibraryState,
    player: com.texgen.music.texwave.player.PlayerState? = null,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: ((List<Song>) -> Unit)? = null,
    onEmotion: ((String) -> Unit)? = null,
    onBack: (() -> Unit)? = null,
) {
    com.texgen.music.texwave.ui.ref.CockpitGuide(com.texgen.music.texwave.ui.ref.Guides.radar) {
        PulseRadarBody(lib = lib, player = player, onPlay = onPlay, onShuffle = onShuffle, onEmotion = onEmotion, onBack = onBack)
    }
}

@Composable
private fun PulseRadarBody(
    lib: LibraryState,
    player: com.texgen.music.texwave.player.PlayerState? = null,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: ((List<Song>) -> Unit)? = null,
    onEmotion: ((String) -> Unit)? = null,
    onBack: (() -> Unit)? = null,
) {
    val songs = remember(lib.songs, lib.liked, lib.playCounts) {
        lib.songs
            .sortedByDescending { (lib.playCounts[it.id] ?: 0) + if (it.id in lib.liked) 50 else 0 }
            .take(80)
    }
    var selected by remember { mutableStateOf<Song?>(null) }
    val t = rememberInfiniteTransition(label = "radarSky")
    val drift by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift",
    )

    // Stable positions for each song id
    val points = remember(songs) {
        songs.mapIndexed { i, s ->
            val rnd = Random(s.id)
            val angle = rnd.nextFloat() * Math.PI.toFloat() * 2f
            val radius = 0.18f + rnd.nextFloat() * 0.72f
            RadarPoint(s, cos(angle) * radius, sin(angle) * radius, radius)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF08080B), Color(0xFF121214), Color(0xFF0A0A0C)),
                ),
            )
            .padding(16.dp),
    ) {
        Text("Your sky", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "${lib.songs.size} songs as lights · brighter = you play them more",
            color = Color(0xFF9AA3C0),
            fontSize = 13.sp,
        )
        Spacer(Modifier.height(12.dp))

        Box(
            Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF19191B), Color(0xFF0C0C0E)),
                    ),
                )
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(28.dp)),
        ) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            val c = Offset(size.width / 2f, size.height / 2f)
                            val maxR = min(size.width, size.height) * 0.42f
                            var best: Song? = null
                            var bestD = 28f
                            points.forEach { p ->
                                val pos = Offset(c.x + p.nx * maxR, c.y + p.ny * maxR)
                                val d = hypot(pos.x - offset.x, pos.y - offset.y)
                                if (d < bestD) {
                                    bestD = d
                                    best = p.song
                                }
                            }
                            if (best != null) selected = best
                        }
                    },
            ) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val maxR = min(size.width, size.height) * 0.42f
                // soft rings — ambient, not military
                for (i in 1..3) {
                    drawCircle(
                        Color.White.copy(alpha = 0.04f + i * 0.015f),
                        maxR * (i / 3f),
                        c,
                        style = Stroke(width = 1.2f),
                    )
                }
                points.forEachIndexed { i, p ->
                    val pos = Offset(c.x + p.nx * maxR, c.y + p.ny * maxR)
                    val plays = lib.playCounts[p.song.id] ?: 0
                    val liked = p.song.id in lib.liked
                    val base = 3.2f + (plays.coerceAtMost(20) * 0.25f) + if (liked) 2.5f else 0f
                    val pulse = 0.85f + 0.15f * sin((drift * 6.28f) + i * 0.4f)
                    val col = when {
                        liked -> Color(0xFFFF7AD9)
                        plays > 8 -> Color(0xFF8FF0CB)
                        plays > 0 -> Color(0xFFB6F5DC)
                        else -> Color(0xFF8A90A8)
                    }
                    drawCircle(col.copy(alpha = 0.2f * pulse), base * 2.4f, pos)
                    drawCircle(col.copy(alpha = 0.9f), base * pulse, pos)
                }
                selected?.let { sel ->
                    points.firstOrNull { it.song.id == sel.id }?.let { p ->
                        val pos = Offset(c.x + p.nx * maxR, c.y + p.ny * maxR)
                        drawCircle(Color.White.copy(alpha = 0.9f), 13f + 3f * sin(drift * 6.28f), pos, style = Stroke(width = 2.5f))
                        drawCircle(Color(0xFF2BE4A4).copy(alpha = 0.25f), 24f, pos)
                    }
                }
                // center glow
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0x338A5CFF), Color.Transparent),
                        c, maxR * 0.28f,
                    ),
                    maxR * 0.28f,
                    c,
                )
            }
            if (points.isEmpty()) {
                Text(
                    "No songs yet — add music to your phone and rescan to light up your sky.",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.Center).padding(32.dp),
                )
            }
            Text(
                "Tap a light",
                color = Color.White.copy(alpha = 0.45f),
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
            )
        }

        Spacer(Modifier.height(14.dp))

        val focus = selected
        if (focus != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0x22FFFFFF))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(18.dp))
                    .clickable {
                        val idx = songs.indexOfFirst { it.id == focus.id }.coerceAtLeast(0)
                        onPlay(songs, idx)
                    }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Artwork(focus, Modifier.size(48.dp), corner = 12.dp)
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(focus.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(focus.artist, color = Color(0xFF9AA3C0), fontSize = 12.sp, maxLines = 1)
                }
                Icon(Icons.Rounded.PlayArrow, "Play", tint = Color(0xFF8FF0CB), modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.height(10.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ChipAction("Play brightest", Icons.Rounded.Favorite) {
                if (songs.isNotEmpty()) onPlay(songs, 0)
            }
            ChipAction("Shuffle sky", Icons.Rounded.Shuffle) {
                if (onShuffle != null && songs.isNotEmpty()) onShuffle(songs)
                else if (songs.isNotEmpty()) onPlay(songs.shuffled(), 0)
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("In this sky", color = Color(0xFF9AA3C0), fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
            items(songs.take(40), key = { it.id }) { s ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x10FFFFFF))
                        .clickable {
                            selected = s
                            onPlay(songs, songs.indexOfFirst { it.id == s.id }.coerceAtLeast(0))
                        }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Artwork(s, Modifier.size(36.dp), corner = 8.dp)
                    Spacer(Modifier.size(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.artist, color = Color(0xFF8A90A8), fontSize = 11.sp, maxLines = 1)
                    }
                    val plays = lib.playCounts[s.id] ?: 0
                    Text(
                        if (s.id in lib.liked) "♥" else "${plays}×",
                        color = if (s.id in lib.liked) Color(0xFFFF7AD9) else Color(0xFF8A8F9C),
                        fontSize = 11.sp,
                    )
                }
            }
        }
    }
}

private data class RadarPoint(val song: Song, val nx: Float, val ny: Float, val ring: Float)

@Composable
private fun ChipAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Color(0x22FFFFFF))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = Color(0xFFB6F5DC), modifier = Modifier.size(16.dp))
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}
