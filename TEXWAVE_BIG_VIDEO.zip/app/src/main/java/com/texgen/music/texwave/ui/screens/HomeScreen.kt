package com.texgen.music.texwave.ui.screens

import android.icu.util.Calendar
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Nightlife
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.texgen.music.texwave.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.Artwork
import com.texgen.music.texwave.ui.components.GradientTile
import com.texgen.music.texwave.ui.components.SectionHeader
import com.texgen.music.texwave.ui.components.SongRow
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.songCount

private fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        hour < 5 -> "Late night vibes"
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        hour < 22 -> "Good evening"
        else -> "Late night vibes"
    }
}

@Composable
fun HomeScreen(
    lib: LibraryState,
    player: PlayerState,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onMore: (Song) -> Unit,
    onSleepTimer: () -> Unit = {},
    onDailyMix: () -> Unit = {},
    onEmotion: (String) -> Unit = {},
    onInfiniteMix: () -> Unit = {},
) {
    val songs = lib.songs
    val recents = remember(lib.recents, songs) {
        val byId = songs.associateBy { it.id }
        lib.recents.mapNotNull { byId[it] }
    }
    val recentlyAdded = remember(songs) { songs.sortedByDescending { it.dateAdded }.take(15) }
    val likedSongs = remember(songs, lib.liked) { songs.filter { it.id in lib.liked } }
    val mixes = remember(songs) {
        songs.groupBy { it.artist }
            .filterKeys { !it.startsWith("Unknown") }
            .entries.sortedByDescending { it.value.size }
            .take(8)
    }
    val dailyMix = remember(songs, lib.recents, lib.liked) {
        val ids = (lib.liked + lib.recents).distinct().shuffled()
        val byId = songs.associateBy { it.id }
        ids.mapNotNull { byId[it] }.ifEmpty { songs.shuffled() }.take(30)
    }

    LazyColumn(contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 22.dp, end = 22.dp, top = 12.dp, bottom = 4.dp),
            ) {
                Text(
                    "T E X W A V E  /  SONIC SOCIAL",
                    color = Tx.Accent2.copy(alpha = 0.94f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 3.sp,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    greeting(),
                    color = Tx.Text,
                    fontSize = 29.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = (-0.65).sp,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Your music. Your memories. Your universe.",
                    color = Tx.Muted,
                    fontSize = 13.sp,
                )
            }
        }

        // Hero shuffle — dark glass premium card
        item {
            Box(
                Modifier
                    .padding(horizontal = 20.dp, vertical = 14.dp)
                    .fillMaxWidth()
                    .height(278.dp)
                    .shadow(28.dp, RoundedCornerShape(28.dp), ambientColor = Tx.Accent.copy(alpha = 0.20f))
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF08080B))
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                Tx.Accent.copy(alpha = 0.34f),
                                Tx.Accent2.copy(alpha = 0.18f),
                                Color.Transparent,
                            )
                        ),
                        RoundedCornerShape(24.dp),
                    )
                    .clickable { onShuffle(songs) }
            ) {
                Image(
                    painter = painterResource(R.drawable.portal_universe),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x220A0A0C), Color(0x550A0A0C), Color(0xF50A0A0C)))))
                Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
                    Text(
                        "MOODWAVE  /  YOUR SONIC UNIVERSE",
                        color = Tx.Accent.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.labelSmall,
                        letterSpacing = 1.8.sp,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Every connection begins with a wave.",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Tx.Accent.copy(alpha = 0.35f), Tx.Accent2.copy(alpha = 0.25f))
                                )
                            )
                            .border(1.dp, Tx.Accent.copy(alpha = 0.4f), RoundedCornerShape(999.dp))
                            .padding(horizontal = 18.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(Icons.Rounded.Shuffle, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Text("ENTER YOUR WAVE", color = Color.White, style = MaterialTheme.typography.labelLarge, letterSpacing = 1.1.sp)
                    }
                }
            }
        }

        // Quick actions: Daily Mix, Sleep Timer, Moods
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    QuickChip(Icons.Rounded.AutoAwesome, "Daily Mix", Tx.Accent) { onDailyMix() }
                }
                item {
                    QuickChip(Icons.Rounded.Timer, "Sleep Timer", Tx.Accent2) { onSleepTimer() }
                }
                item {
                    QuickChip(Icons.Rounded.Favorite, "Liked", Color(0xFFFF5A7A)) {
                        if (likedSongs.isNotEmpty()) onPlay(likedSongs, 0)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // Mood mixes
        item {
            SectionHeader("Moodwave")
            Text(
                "Choose a frequency for the moment",
                color = Tx.Muted,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            val emotions = listOf(
                Triple("rainy", "Rainy Night", listOf(Color(0xFF28282A), Color(0xFF111113))),
                Triple("unstoppable", "Unstoppable", listOf(Color(0xFF3A1725), Color(0xFF101012))),
                Triple("space", "Lost in Space", listOf(Color(0xFF2C2C2E), Color(0xFF101012))),
                Triple("think", "Let Me Think", listOf(Color(0xFF2B2B2D), Color(0xFF0F0F11))),
                Triple("boss", "Final Boss", listOf(Color(0xFF361322), Color(0xFF0B070D))),
                Triple("focus", "Deep Focus", listOf(Color(0xFF2B2B2D), Color(0xFF101012))),
                Triple("drive", "Night Drive", listOf(Color(0xFF2B2B2D), Color(0xFF0E0E10))),
            )
            Row(
                Modifier
                    .padding(horizontal = 16.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                emotions.forEach { (id, label, colors) ->
                    Box(
                        Modifier
                            .width(148.dp)
                            .height(84.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Brush.linearGradient(colors))
                            .border(1.dp, Tx.Accent.copy(alpha = 0.22f), RoundedCornerShape(18.dp))
                            .clickable { onEmotion(id) }
                            .padding(14.dp),
                        contentAlignment = Alignment.BottomStart,
                    ) {
                        Text(label, color = Color.White, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Tx.Brand)
                    .clickable { onInfiniteMix() },
                contentAlignment = Alignment.Center,
            ) {
                Text("∞  Infinite Mix   ·   evolves with your session", color = Color.White, style = MaterialTheme.typography.titleSmall)
            }
            Spacer(Modifier.height(8.dp))
        }

        // Jump back in
        if (recents.isNotEmpty()) {
            item {
                SectionHeader("Recently played")
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(recents.take(12), key = { it.id }) { song ->
                        Column(
                            Modifier
                                .width(118.dp)
                                .clickable { onPlay(listOf(song) + songs.filter { it.id != song.id }, 0) },
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Artwork(song, Modifier.size(118.dp), corner = 18.dp, iconSize = 36.dp)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                song.title, color = Tx.Text, style = MaterialTheme.typography.bodySmall,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                song.artist, color = Tx.Muted, style = MaterialTheme.typography.labelSmall,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        // Made for you / Daily Mix card
        if (dailyMix.isNotEmpty()) {
            item {
                SectionHeader("Made for your frequency")
                Box(
                    Modifier
                        .padding(horizontal = 20.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(Tx.Accent.copy(alpha = 0.35f), Tx.Accent2.copy(alpha = 0.2f), Tx.Surface)
                            )
                        )
                        .border(0.5.dp, Tx.Outline.copy(alpha = 0.4f), RoundedCornerShape(22.dp))
                        .clickable { onPlay(dailyMix, 0) }
                        .padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Tx.Brand),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Daily Mix", color = Tx.Text, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Built from likes & history · ${dailyMix.size} tracks",
                                color = Tx.Muted,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        // Artist mixes
        if (mixes.isNotEmpty()) {
            item {
                SectionHeader("Artist stations")
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(mixes, key = { it.key }) { (artist, list) ->
                        Column(
                            Modifier
                                .width(140.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .clickable { onPlay(list, 0) }
                        ) {
                            GradientTile(artist, Icons.Rounded.Person, Modifier.size(140.dp).clip(RoundedCornerShape(18.dp)))
                            Spacer(Modifier.height(8.dp))
                            Text(artist, color = Tx.Text, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${list.size} songs", color = Tx.Muted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        // Recently added
        if (recentlyAdded.isNotEmpty()) {
            item { SectionHeader("Recently added") }
            itemsIndexed(recentlyAdded, key = { _, s -> s.id }) { index, song ->
                SongRow(
                    song = song,
                    isCurrent = player.current?.id == song.id,
                    isPlaying = player.isPlaying && player.current?.id == song.id,
                    liked = song.id in lib.liked,
                    onClick = { onPlay(recentlyAdded, index) },
                    onMore = { onMore(song) },
                )
            }
        }
    }
}

@Composable
private fun QuickChip(icon: ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Tx.SurfaceHigh)
            .border(0.5.dp, Tx.Outline.copy(alpha = 0.5f), RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Text(label, color = Tx.Text, style = MaterialTheme.typography.labelLarge)
    }
}
