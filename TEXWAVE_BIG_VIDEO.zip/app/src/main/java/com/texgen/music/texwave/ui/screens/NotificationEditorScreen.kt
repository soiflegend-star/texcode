package com.texgen.music.texwave.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.texgen.music.texwave.data.chat.ChatNotifier
import com.texgen.music.texwave.data.chat.NotifPrefs
import com.texgen.music.texwave.ui.theme.Tx

/** Notification editor: choose what alerts you get, how they look and sound, and when to stay quiet. */
@Composable
fun NotificationEditorScreen(onBack: () -> Unit, onOpenStyle: () -> Unit = {}) {
    val context = LocalContext.current
    var messages by remember { mutableStateOf(NotifPrefs.messages(context)) }
    var calls by remember { mutableStateOf(NotifPrefs.calls(context)) }
    var preview by remember { mutableStateOf(NotifPrefs.preview(context)) }
    var sound by remember { mutableStateOf(NotifPrefs.sound(context)) }
    var vibrate by remember { mutableStateOf(NotifPrefs.vibrate(context)) }
    var lock by remember { mutableStateOf(NotifPrefs.hideOnLockScreen(context)) }
    var quiet by remember { mutableStateOf(NotifPrefs.quietEnabled(context)) }
    var qStart by remember { mutableStateOf(NotifPrefs.quietStart(context)) }
    var qEnd by remember { mutableStateOf(NotifPrefs.quietEnd(context)) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) ChatNotifier.sendTest(context)
        else Toast.makeText(context, "Allow notifications in system settings to receive alerts", Toast.LENGTH_LONG).show()
    }
    fun test() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else {
            ChatNotifier.sendTest(context)
            Toast.makeText(context, "Test sent", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().background(Tx.Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Tx.Text) }
            Column(Modifier.weight(1f)) {
                Text("Notification editor", color = Tx.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Choose what you hear about and when", color = Tx.Muted, fontSize = 12.sp)
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            // live preview of what a message alert will look like with the current choices
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Tx.Surface)
                    .border(1.dp, Tx.Outline, RoundedCornerShape(18.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(Tx.Accent.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Notifications, null, tint = Tx.Accent)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Aarav", color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text(if (preview) "Are you free to listen together tonight?" else "New message", color = Tx.Muted, fontSize = 13.sp)
                    Text(
                        when {
                            !messages -> "Message alerts are off"
                            quiet -> "Quiet ${hourLabel(qStart)} – ${hourLabel(qEnd)} · otherwise " + soundLabel(sound, vibrate)
                            else -> soundLabel(sound, vibrate)
                        },
                        color = Tx.Accent, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
            EditorHeader("WHAT TO NOTIFY")
            EditorSwitch("Messages", "New chat messages", messages) { messages = it; NotifPrefs.set(context, "messages", it) }
            EditorSwitch("Calls", "Incoming voice and video calls", calls) { calls = it; NotifPrefs.set(context, "calls", it) }
            EditorHeader("HOW IT ALERTS")
            EditorSwitch("Sound", "Play a tone for messages", sound) { sound = it; NotifPrefs.set(context, "sound", it) }
            EditorSwitch("Vibration", "Buzz for messages", vibrate) { vibrate = it; NotifPrefs.set(context, "vibrate", it) }
            EditorHeader("PRIVACY")
            EditorSwitch("Show message text", "Off shows only “New message”", preview) { preview = it; NotifPrefs.set(context, "preview", it) }
            EditorSwitch("Hide on lock screen", "Keep content private when locked", lock) { lock = it; NotifPrefs.set(context, "lock_private", it) }
            EditorHeader("QUIET HOURS")
            EditorSwitch("Quiet hours", "Messages arrive silently inside this window", quiet) { quiet = it; NotifPrefs.set(context, "quiet", it) }
            if (quiet) {
                HourStepper("From", qStart) { qStart = it; NotifPrefs.setHour(context, "quiet_start", it) }
                HourStepper("Until", qEnd) { qEnd = it; NotifPrefs.setHour(context, "quiet_end", it) }
            }
            EditorHeader("LOOK")
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Tx.Surface)
                    .clickable(onClick = onOpenStyle)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("In-app alert style", color = Tx.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text("Pick how alerts appear inside TEXWAVE", color = Tx.Muted, fontSize = 12.sp)
                }
                Text("Change", color = Tx.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Tx.Accent)
                    .clickable { test() },
                contentAlignment = Alignment.Center,
            ) { Text("Send a test notification", color = Color.Black, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(28.dp))
        }
    }
}

private fun soundLabel(sound: Boolean, vibrate: Boolean) = when {
    sound && vibrate -> "Sound + vibration"
    sound -> "Sound only"
    vibrate -> "Vibration only"
    else -> "Silent"
}

private fun hourLabel(h: Int): String {
    val hh = if (h % 12 == 0) 12 else h % 12
    return "$hh ${if (h < 12) "AM" else "PM"}"
}

@Composable
private fun EditorHeader(text: String) {
    Text(
        text, color = Tx.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp,
        modifier = Modifier.padding(top = 18.dp, bottom = 6.dp),
    )
}

@Composable
private fun EditorSwitch(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Tx.Surface)
            .clickable { onChange(!on) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Tx.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = Tx.Muted, fontSize = 12.sp)
        }
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Tx.Accent, checkedThumbColor = Color.Black),
        )
    }
}

@Composable
private fun HourStepper(label: String, hour: Int, onChange: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Tx.Surface)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Tx.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(
            "−", color = Tx.Accent, fontSize = 24.sp,
            modifier = Modifier.clip(CircleShape).clickable { onChange(hour - 1) }.padding(horizontal = 14.dp, vertical = 2.dp),
        )
        Text(hourLabel(hour), color = Tx.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(64.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Text(
            "+", color = Tx.Accent, fontSize = 24.sp,
            modifier = Modifier.clip(CircleShape).clickable { onChange(hour + 1) }.padding(horizontal = 14.dp, vertical = 2.dp),
        )
    }
}
