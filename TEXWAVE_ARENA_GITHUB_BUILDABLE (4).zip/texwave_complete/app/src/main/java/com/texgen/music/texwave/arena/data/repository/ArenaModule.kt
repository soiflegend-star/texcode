package com.texgen.music.texwave.arena.data.repository

import com.texgen.music.texwave.arena.data.supabase.SupabaseArenaClient

/**
 * Process-wide repository holder. Never constructs LocalArenaRepository during class load.
 */
object ArenaModule {
    @Volatile
    private var repo: ArenaRepository? = null

    @Volatile
    private var mode: Mode = Mode.LOCAL_DEMO

    enum class Mode { LOCAL_DEMO, SUPABASE }

    fun init(repository: ArenaRepository, mode: Mode = Mode.SUPABASE) {
        this.repo = repository
        this.mode = mode
    }

    fun initLocalDemo() {
        init(LocalArenaRepository(), Mode.LOCAL_DEMO)
    }

    fun initSupabase(client: SupabaseArenaClient) {
        init(SupabaseArenaRepository(client), Mode.SUPABASE)
    }

    val repository: ArenaRepository
        get() {
            val existing = repo
            if (existing != null) return existing
            synchronized(this) {
                val again = repo
                if (again != null) return again
                val created = LocalArenaRepository()
                repo = created
                mode = Mode.LOCAL_DEMO
                return created
            }
        }

    val isDemo: Boolean get() = mode == Mode.LOCAL_DEMO
}
