package com.texgen.music.texwave.arena.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.texgen.music.texwave.arena.data.model.ArenaHomeState
import com.texgen.music.texwave.arena.data.model.ArenaPlayer
import com.texgen.music.texwave.arena.data.repository.ArenaModule
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ArenaHomeViewModel(
    private val repository: ArenaRepository
) : ViewModel() {

    val homeState: StateFlow<ArenaHomeState> = repository
        .observeHomeState()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ArenaHomeState(
                player = ArenaPlayer(userId = "", username = "…"),
                isLoading = true
            )
        )

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            runCatching { repository.refreshHome() }
        }
    }

    companion object {
        /** Call only from composition / runtime — not as a class-load default expression. */
        fun factory(repository: ArenaRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    require(modelClass.isAssignableFrom(ArenaHomeViewModel::class.java)) {
                        "Unknown ViewModel $modelClass"
                    }
                    return ArenaHomeViewModel(repository) as T
                }
            }

        fun defaultFactory(): ViewModelProvider.Factory =
            factory(ArenaModule.repository)
    }
}
