package com.texgen.music.texwave.sonara.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode as AnimRepeat
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.sonara.data.RepeatMode
import com.texgen.music.texwave.sonara.data.Track
import com.texgen.music.texwave.sonara.data.download.DownloadProgress
import com.texgen.music.texwave.sonara.data.settings.AudioQuality
import com.texgen.music.texwave.sonara.rights.ContentSubmission
import kotlin.math.abs
import kotlin.math.sin

// ───────────────────────────── NOW PLAYING

@Composable
private fun Waveform(progress: Float, playing: Boolean, modifier: Modifier = Modifier) {
    val phase by rememberInfiniteTransition(label = "wave").animateFloat(
        0f, 6.2832f, infiniteRepeatable(tween(1600, easing = LinearEasing), AnimRepeat.Restart), label = "p",
    )
    val on = SC.Accent2
    val off = SC.Sub.copy(alpha = 0.45f)
    Canvas(modifier.fillMaxWidth().height(40.dp)) {
        val n = 64
        val gap = 3.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val base = 0.25f + 0.75f * abs(sin(i * 0.37f) * kotlin.math.cos(i * 0.13f + 1f))
            val v = if (playing) base * (0.65f + 0.35f * sin(phase + i * 0.5f)) else base * 0.8f
            val h = (size.height * v).coerceAtLeast(3.dp.toPx())
            drawRoundRect(
                color = if (i.toFloat() / n <= progress) on else off,
                topLeft = Offset(i * (w + gap), (size.height - h) / 2f), size = Size(w, h), cornerRadius = CornerRadius(w / 2f),
            )
        }
    }
}

@Composable
internal fun NowPlayingScreen(vm: SonaraViewModel, s: SonaraUi, onClose: () -> Unit, onQuick: () -> Unit, onLyrics: () -> Unit) {
    val pb by vm.playback.collectAsState()
    val t = pb.currentTrack
    if (t == null) { LaunchedEffect(Unit) { onClose() }; return }
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = pb.durationMs.coerceAtLeast(1L)
    val shown = drag ?: (pb.positionMs.toFloat() / dur).coerceIn(0f, 1f)

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Filled.KeyboardArrowDown, "Close", onClose)
            Text("Now Playing", color = SC.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            IconBtn(Icons.Filled.MoreVert, "Quick actions", onQuick)
        }
        Spacer(Modifier.height(10.dp))
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f, fill = false), contentAlignment = Alignment.Center) {
            val side = maxWidth.coerceAtMost(340.dp)
            Cover(t.artworkUrl, t.id, side, 26.dp, Modifier.border(1.dp, SC.Accent.copy(alpha = 0.45f), RoundedCornerShape(26.dp)))
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.title, color = SC.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, color = SC.Sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val liked = t.id in s.likedIds
            IconBtn(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like", { vm.toggleLike(t.id) }, if (liked) SC.Accent else SC.Text)
        }
        Slider(
            value = shown, onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { vm.seekTo((it * dur).toLong()) }; drag = null },
            colors = SliderDefaults.colors(thumbColor = SC.Accent2, activeTrackColor = SC.Accent, inactiveTrackColor = SC.Line),
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmtMs((shown * dur).toLong()), color = SC.Sub, fontSize = 11.sp, modifier = Modifier.weight(1f))
            Text(fmtMs(pb.durationMs), color = SC.Sub, fontSize = 11.sp)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconBtn(Icons.Filled.Shuffle, "Shuffle", { vm.setShuffle(!pb.shuffle) }, if (pb.shuffle) SC.Accent2 else SC.Text)
            Icon(Icons.Filled.SkipPrevious, "Previous", tint = SC.Text, modifier = Modifier.size(52.dp).clip(CircleShape).clickable { vm.previous() }.padding(10.dp))
            Box(
                Modifier.size(74.dp).clip(CircleShape).border(2.dp, SC.Text.copy(alpha = 0.85f), CircleShape).glass(37.dp).clickable { vm.togglePlayPause() },
                contentAlignment = Alignment.Center,
            ) { Icon(if (pb.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", tint = SC.Text, modifier = Modifier.size(38.dp)) }
            Icon(Icons.Filled.SkipNext, "Next", tint = SC.Text, modifier = Modifier.size(52.dp).clip(CircleShape).clickable { vm.next() }.padding(10.dp))
            IconBtn(if (pb.repeatMode == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Repeat", { vm.cycleRepeat() },
                if (pb.repeatMode == RepeatMode.OFF) SC.Text else SC.Accent2)
        }
        if (SonaraPrefs.visualizer) {
            Spacer(Modifier.height(12.dp))
            Waveform(shown, pb.isPlaying)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().padding(bottom = 14.dp).glass(18.dp).clickable { onLyrics() }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Equalizer, null, tint = SC.Accent2, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text("Lyrics", color = SC.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.KeyboardArrowUp, null, tint = SC.Text)
        }
    }
}

@Composable
internal fun LyricsScreen(t: Track?, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Lyrics", onBack)
        Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(40.dp))
            Icon(Icons.Filled.Notes, null, tint = SC.Accent2, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(16.dp))
            Text(t?.title ?: "", color = SC.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("Lyrics aren't available for this track yet. Synced lyrics are planned for a future update.", color = SC.Sub, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
internal fun QueueScreen(vm: SonaraViewModel, s: SonaraUi, onBack: () -> Unit) {
    val pb by vm.playback.collectAsState()
    Column(Modifier.fillMaxSize()) {
        TopBar("Queue", onBack)
        LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
            itemsIndexed(pb.queue, key = { i, t -> "${t.id}#$i" }) { i, t ->
                TrackRow(t, t.id in s.likedIds, pb.currentTrack?.id == t.id, { vm.playAll(pb.queue, i) }, { vm.toggleLike(t.id) })
            }
        }
    }
}

// ───────────────────────────── QUICK ACTIONS PANEL

@Composable
internal fun QuickPanel(vm: SonaraViewModel, s: SonaraUi, onClose: () -> Unit, onQueue: () -> Unit, onLyrics: () -> Unit) {
    val pb by vm.playback.collectAsState()
    val dl by vm.downloadIds.collectAsState(initial = emptySet())
    val sleep by vm.sleepMinutes.collectAsState()
    val ctx = LocalContext.current
    val t = pb.currentTrack ?: run { LaunchedEffect(Unit) { onClose() }; return }
    var sleepDialog by remember { mutableStateOf(false) }
    val dur = pb.durationMs.coerceAtLeast(1L)

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).clickable(onClick = onClose)) {
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(10.dp).navigationBarsPadding()
                .glass(28.dp).background(SC.Bg.copy(alpha = 0.92f)).clickable(enabled = false) {}.padding(16.dp),
        ) {
            Icon(Icons.Filled.KeyboardArrowDown, null, tint = SC.Sub, modifier = Modifier.align(Alignment.CenterHorizontally).clickable { onClose() })
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(t.artworkUrl, t.id, 50.dp, 12.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, color = SC.Text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.artist, color = SC.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(if (pb.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = SC.Text,
                    modifier = Modifier.size(40.dp).clip(CircleShape).clickable { vm.togglePlayPause() }.padding(6.dp))
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(SC.Line)) {
                Box(Modifier.fillMaxWidth((pb.positionMs.toFloat() / dur).coerceIn(0f, 1f)).fillMaxHeight().background(SC.Accent))
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconBtn(Icons.Filled.Shuffle, "Shuffle", { vm.setShuffle(!pb.shuffle) }, if (pb.shuffle) SC.Accent2 else SC.Text)
                IconBtn(Icons.Filled.SkipPrevious, "Previous", { vm.previous() })
                Box(Modifier.size(52.dp).clip(CircleShape).border(2.dp, SC.Text.copy(alpha = 0.85f), CircleShape).clickable { vm.togglePlayPause() }, contentAlignment = Alignment.Center) {
                    Icon(if (pb.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = SC.Text, modifier = Modifier.size(28.dp))
                }
                IconBtn(Icons.Filled.SkipNext, "Next", { vm.next() })
                IconBtn(Icons.Filled.Repeat, "Repeat", { vm.cycleRepeat() }, if (pb.repeatMode == RepeatMode.OFF) SC.Text else SC.Accent2)
            }
            Spacer(Modifier.height(8.dp))
            Text("Quick Actions", color = SC.Text, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
            val actions: List<Triple<String, ImageVector, () -> Unit>> = listOf(
                Triple("Queue", Icons.Filled.QueueMusic) { onClose(); onQueue() },
                Triple(if (t.id in dl) "Downloaded" else "Download", Icons.Filled.Download) { if (t.isDownloadable) vm.download(t) },
                Triple("Share", Icons.Filled.Share) {
                    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${t.title} — ${t.artist} (via AUVYRR Sonara)") }
                    ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
                Triple(if (sleep > 0) "Sleep · ${sleep}m" else "Sleep Timer", Icons.Filled.Timer) { sleepDialog = true },
                Triple("Radio", Icons.Filled.Radio) { vm.startRadio(t); onClose() },
                Triple("Lyrics", Icons.Filled.Notes) { onClose(); onLyrics() },
            )
            actions.chunked(3).forEach { rowItems ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { (label, icon, act) ->
                        Column(
                            Modifier.weight(1f).glass(16.dp).clickable { act() }.padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(icon, null, tint = SC.Text, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.height(4.dp))
                            Text(label, color = SC.Text, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
    if (sleepDialog) AlertDialog(
        onDismissRequest = { sleepDialog = false }, containerColor = SC.Card,
        title = { Text("Sleep timer", color = SC.Text) },
        text = {
            Column {
                listOf(15, 30, 45, 60, 0).forEach { m ->
                    Text(if (m == 0) "Off" else "$m minutes", color = SC.Text, fontSize = 16.sp,
                        modifier = Modifier.fillMaxWidth().clickable { vm.setSleepTimer(m); sleepDialog = false }.padding(vertical = 12.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = { sleepDialog = false }) { Text("Close", color = SC.Accent2) } },
    )
}

// ───────────────────────────── MORE MENU

@Composable
internal fun MoreDialog(vm: SonaraViewModel, s: SonaraUi, t: Track, onArtist: (String) -> Unit, dismiss: () -> Unit) {
    var pick by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = dismiss, containerColor = SC.Card,
        title = { Text(t.title, color = SC.Text, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                if (!pick) {
                    MenuItem("Start radio") { vm.startRadio(t); dismiss() }
                    MenuItem("Go to artist") { onArtist(t.artist); dismiss() }
                    MenuItem("Add to playlist") { pick = true }
                    if (t.isDownloadable) MenuItem("Download") { vm.download(t); dismiss() }
                } else if (s.playlists.isEmpty()) {
                    Text("Create a playlist in Your Library first.", color = SC.Sub)
                } else s.playlists.forEach { p -> MenuItem(p.name) { vm.addToPlaylist(p.id, t.id); dismiss() } }
            }
        },
        confirmButton = { TextButton(onClick = dismiss) { Text("Close", color = SC.Accent2) } },
    )
}

@Composable
private fun MenuItem(text: String, onClick: () -> Unit) {
    Text(text, color = SC.Text, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp))
}

// ───────────────────────────── SETTINGS

@Composable
internal fun SettingsHome(vm: SonaraViewModel, onPage: (String) -> Unit) {
    val user by vm.user.collectAsState()
    val premium by vm.premiumDemo.collectAsState(initial = false)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Settings", null)
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp).glass(20.dp).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(CircleShape).background(coverBrush(user?.id ?: "guest")).border(2.dp, SC.Accent, CircleShape), contentAlignment = Alignment.Center) {
                Text((user?.displayName ?: "G").take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(user?.displayName ?: "Guest listener", color = SC.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(if (premium) "Premium Member 👑" else "Free listener", color = if (premium) Color(0xFFFFB84D) else SC.Sub, fontSize = 12.sp)
            }
        }
        Column(Modifier.padding(horizontal = 6.dp)) {
            SettingRow(Icons.Filled.AccountCircle, "Account") { onPage("account") }
            SettingRow(Icons.Filled.Palette, "Appearance", when (SonaraPrefs.themeMode) { 0 -> "Light"; 2 -> "Auto"; else -> "Dark" }) { onPage("appearance") }
            SettingRow(Icons.Filled.PlayCircleFilled, "Playback") { onPage("playback") }
            SettingRow(Icons.Filled.Notifications, "Notifications") { onPage("notifications") }
            SettingRow(Icons.Filled.Lock, "Privacy & Security") { onPage("privacy") }
            SettingRow(Icons.Filled.Info, "About") { onPage("about") }
        }
        Spacer(Modifier.height(18.dp))
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).glass(26.dp).clickable { if (user != null) vm.signOut() else onPage("account") }.padding(vertical = 15.dp),
            contentAlignment = Alignment.Center,
        ) { Text(if (user != null) "Log Out" else "Sign in", color = SC.Text, fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ThemeCard(label: String, selected: Boolean, preview: @Composable BoxScope.() -> Unit, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.width(96.dp).clip(shape).border(if (selected) 2.dp else 1.dp, if (selected) SC.Accent else SC.Line, shape).clickable { onClick() }.padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(11.dp)), content = preview)
        Spacer(Modifier.height(6.dp))
        Text(label, color = SC.Text, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
internal fun AppearanceScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Appearance", onBack)
        Text("Choose Theme", color = SC.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(18.dp, 8.dp, 18.dp, 10.dp))
        Row(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ThemeCard("Light", SonaraPrefs.themeMode == 0, { Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFFFFFFFF), Color(0xFFD9D6EA))))) }) { SonaraPrefs.setTheme(0) }
            ThemeCard("Dark", SonaraPrefs.themeMode == 1, { Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF1A1426), Color(0xFF050507))))) }) { SonaraPrefs.setTheme(1) }
            ThemeCard("Auto", SonaraPrefs.themeMode == 2, {
                Row(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFFE9E6F5)))
                    Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF0B0A10)))
                }
            }) { SonaraPrefs.setTheme(2) }
        }
        Text("Accent Colour", color = SC.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(18.dp, 22.dp, 18.dp, 10.dp))
        Row(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AccentChoices.forEach { c ->
                val sel = SonaraPrefs.accent == c
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(Color(c)).then(if (sel) Modifier.border(3.dp, SC.Text, CircleShape) else Modifier)
                        .clickable { SonaraPrefs.setAccent(c) },
                    contentAlignment = Alignment.Center,
                ) { if (sel) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
            }
        }
        Spacer(Modifier.height(14.dp))
        SwitchRow("Glass Effect", SonaraPrefs.glass) { SonaraPrefs.setGlass(it) }
        SwitchRow("Dynamic Effect", SonaraPrefs.dynamic) { SonaraPrefs.setDynamic(it) }
        SwitchRow("Waveform Visualizer", SonaraPrefs.visualizer) { SonaraPrefs.setVisualizer(it) }
        Box(Modifier.fillMaxWidth().padding(18.dp).height(110.dp).glass(20.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(com.texgen.music.texwave.R.drawable.auvyrr_logo_clear),
                    contentDescription = "AUVYRR", modifier = Modifier.size(54.dp),
                )
                Text("AUVYRR", color = SC.Text, fontSize = 15.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Light)
            }
        }
    }
}

@Composable
internal fun PlaybackScreen(vm: SonaraViewModel, onBack: () -> Unit) {
    val premium by vm.premiumDemo.collectAsState(initial = false)
    val quality by vm.audioQuality.collectAsState(initial = AudioQuality.NORMAL)
    val crossfade by vm.crossfade.collectAsState(initial = false)
    val normalize by vm.normalize.collectAsState(initial = false)
    val wifi by vm.wifiOnly.collectAsState(initial = true)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Playback", onBack)
        Text("Audio quality", color = SC.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(18.dp, 8.dp, 18.dp, 10.dp))
        androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.foundation.lazy.items(AudioQuality.values().toList()) { q -> Chip(q.label, q == quality) { vm.setQuality(q) } }
        }
        Spacer(Modifier.height(12.dp))
        SwitchRow("Crossfade", crossfade) { vm.setCrossfade(it) }
        SwitchRow("Normalize volume", normalize) { vm.setNormalize(it) }
        SwitchRow("Download on Wi-Fi only", wifi) { vm.setWifiOnly(it) }
        SwitchRow("Premium (demo)", premium) { vm.setDemoPremium(it) }
    }
}

@Composable
internal fun AccountScreen(vm: SonaraViewModel, onBack: () -> Unit) {
    val user by vm.user.collectAsState()
    val xp by vm.xp.collectAsState(initial = 0)
    val subs by vm.submissions.collectAsState(initial = emptyList())
    var signIn by remember { mutableStateOf(false) }
    var submitDialog by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Account", onBack)
        Column(Modifier.padding(18.dp)) {
            Text(user?.displayName ?: "Guest listener", color = SC.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Level ${xp / 100 + 1} · $xp XP", color = SC.Sub, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(SC.CardHi)) {
                Box(Modifier.fillMaxWidth((xp % 100) / 100f).fillMaxHeight().background(SC.Accent))
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (user == null) Chip("Sign in", true) { signIn = true } else Chip("Sign out", false) { vm.signOut() }
                Chip("Submit music", false) { submitDialog = true }
            }
            Spacer(Modifier.height(14.dp))
            subs.forEach { Text("• ${it.title} — ${it.status}", color = SC.Sub, fontSize = 13.sp) }
        }
    }
    if (signIn) {
        var email by remember { mutableStateOf("") }
        var pass by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { signIn = false }, containerColor = SC.Card,
            title = { Text("Sign in", color = SC.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(email, { email = it }, singleLine = true, label = { Text("Email") })
                    OutlinedTextField(pass, { pass = it }, singleLine = true, label = { Text("Password") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { vm.signIn(email, pass) { e -> if (e == null) signIn = false else err = e } }) { Text("Continue", color = SC.Accent2) } },
            dismissButton = { TextButton(onClick = { signIn = false }) { Text("Cancel", color = SC.Sub) } },
        )
    }
    if (submitDialog) {
        var title by remember { mutableStateOf("") }
        var artist by remember { mutableStateOf("") }
        var own by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { submitDialog = false }, containerColor = SC.Card,
            title = { Text("Submit a track", color = SC.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, singleLine = true, label = { Text("Title") })
                    OutlinedTextField(artist, { artist = it }, singleLine = true, label = { Text("Artist") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(own, { own = it })
                        Text("I own or control the rights to this music", color = SC.Sub, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = own && title.isNotBlank() && artist.isNotBlank(),
                    onClick = {
                        vm.submit(ContentSubmission(title = title.trim(), artistName = artist.trim(), ownershipDeclaration = "Submitter declares ownership"))
                        submitDialog = false
                    },
                ) { Text("Submit", color = SC.Accent2) }
            },
            dismissButton = { TextButton(onClick = { submitDialog = false }) { Text("Cancel", color = SC.Sub) } },
        )
    }
}

@Composable
internal fun InfoScreen(kind: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val (title, body) = when (kind) {
        "privacy" -> "Privacy & Security" to "Your likes, playlists, recents and settings are stored only on this phone. Sonara sends search words to Audius and Apple's public catalogue (and Jamendo if enabled) so it can find songs. No account is required to listen."
        "about" -> "About" to "AUVYRR · KT Sonara music module.\n\nFull songs stream from Audius (independent artists) and Jamendo (Creative Commons). 30-second previews come from Apple's public catalogue and are labelled. Artwork and audio belong to their respective owners."
        else -> "Notifications" to "Sonara shows playback controls in the notification shade and on the lock screen while music plays. You can change which notifications AUVYRR is allowed to show in Android settings."
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(title, onBack)
        Text(body, color = SC.Sub, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(18.dp))
        if (kind == "notifications") Box(Modifier.padding(18.dp)) {
            Chip("Open Android notification settings", true) {
                ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}
