package com.texgen.music.texwave.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.texgen.music.texwave.player.WakeWordService
import org.json.JSONObject
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener as VoskListener
import org.vosk.android.SpeechService
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Voice input that works online AND offline.
 *
 *  - Online: the phone's speech service (Google etc.).
 *  - Offline: Vosk, using a small model that is downloaded once automatically.
 *
 * Engines are tried in the best order for the current connection and the next one is used
 * automatically if the first fails, so the mic button never just dies. Every callback is
 * delivered on the main thread, and only for the most recent [start] call.
 */
class VoiceInput(context: Context) {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    val models = VoskModelManager.get(app)

    private var session = 0
    private var systemRecognizer: SpeechRecognizer? = null
    private var voskService: SpeechService? = null
    private var voskRecognizer: Recognizer? = null
    private var pausedWake = false

    private enum class Engine { VOSK, SYSTEM }

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    fun isSystemAvailable(): Boolean = try {
        SpeechRecognizer.isRecognitionAvailable(app)
    } catch (_: Throwable) { false }

    fun isOfflineReady(): Boolean = models.isReady()

    fun start(
        preferOffline: Boolean = true,
        onPartial: (String) -> Unit = {},
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        onEnd: () -> Unit = {},
    ) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { start(preferOffline, onPartial, onResult, onError, onEnd) }
            return
        }
        stopInternal(notify = false)
        val id = ++session
        if (!hasPermission()) {
            onError("Microphone permission required")
            onEnd()
            return
        }

        val online = NetUtil.isOnline(app)
        val voskReady = models.isReady()
        val sysOk = isSystemAvailable()
        // Quietly fetch the offline model when we are online and don't have it yet.
        if (!voskReady && online) VoskModelManager.autoDownloadIfNeeded(app)

        val order = ArrayList<Engine>(2)
        if (voskReady && (preferOffline || !online || !sysOk)) order += Engine.VOSK
        if (sysOk) order += Engine.SYSTEM
        if (voskReady && Engine.VOSK !in order) order += Engine.VOSK

        if (order.isEmpty()) {
            onError(
                if (online) "Voice engine not available — downloading the offline voice model, try again in a minute."
                else "No speech engine on this phone. Connect to the internet once so the offline voice model can download."
            )
            onEnd()
            return
        }

        // Free the microphone if the wake-word service is holding it.
        if (WakeWordService.active) {
            pausedWake = true
            WakeWordService.stop(app)
        }

        val cb = Callbacks(id, onPartial, onResult, onError, onEnd)
        // Give the wake service a moment to release the mic.
        main.postDelayed({ if (session == id) runEngine(cb, order, 0, online, null) }, if (pausedWake) 350L else 0L)
    }

    fun stop() = stopInternal(notify = true)

    fun release() {
        stopInternal(notify = false)
    }

    // ---------------------------------------------------------------- internals

    private class Callbacks(
        val id: Int,
        val onPartial: (String) -> Unit,
        val onResult: (String) -> Unit,
        val onError: (String) -> Unit,
        val onEnd: () -> Unit,
    )

    private var activeEnd: (() -> Unit)? = null

    private fun stopInternal(notify: Boolean) {
        session++ // invalidates every callback from the previous run
        val end = activeEnd
        activeEnd = null
        teardownEngines()
        resumeWake()
        if (notify) try { end?.invoke() } catch (_: Throwable) {}
    }

    private fun teardownEngines() {
        try { systemRecognizer?.cancel() } catch (_: Throwable) {}
        try { systemRecognizer?.destroy() } catch (_: Throwable) {}
        systemRecognizer = null
        try { voskService?.cancel() } catch (_: Throwable) {}
        try { voskService?.shutdown() } catch (_: Throwable) {}
        voskService = null
        try { voskRecognizer?.close() } catch (_: Throwable) {}
        voskRecognizer = null
    }

    private fun resumeWake() {
        if (pausedWake) {
            pausedWake = false
            try { WakeWordService.startIfEnabled(app) } catch (_: Throwable) {}
        }
    }

    private fun finish(cb: Callbacks, text: String?, error: String?) {
        if (session != cb.id) return
        session++ // one outcome per run
        activeEnd = null
        teardownEngines()
        resumeWake()
        try {
            when {
                !text.isNullOrBlank() -> cb.onResult(text.trim())
                error != null -> cb.onError(error)
            }
        } finally {
            try { cb.onEnd() } catch (_: Throwable) {}
        }
    }

    private fun runEngine(cb: Callbacks, order: List<Engine>, index: Int, online: Boolean, lastError: String?) {
        if (session != cb.id) return
        if (index >= order.size) {
            finish(cb, null, lastError ?: "Couldn't start voice input")
            return
        }
        if (index > 0) teardownEngines()
        activeEnd = cb.onEnd
        val next: (String) -> Unit = { err: String ->
            main.post { runEngine(cb, order, index + 1, online, err) }
        }
        when (order[index]) {
            Engine.VOSK -> startVosk(cb, next)
            Engine.SYSTEM -> startSystem(cb, online, next)
        }
    }

    // ---- Vosk (offline)

    private fun startVosk(cb: Callbacks, fallback: (String) -> Unit) {
        val path = models.modelPath()
        if (path == null) { fallback("Offline voice model not installed"); return }
        thread(name = "vosk-load", isDaemon = true) {
            val loaded: Pair<Recognizer, SpeechService>? = try {
                val model = VoskShared.model(path)
                val rec = Recognizer(model, 16_000f)
                rec to SpeechService(rec, 16_000f)
            } catch (t: Throwable) {
                android.util.Log.e("VoiceInput", "Vosk load failed", t)
                // A corrupt model must not keep failing forever.
                VoskShared.invalidate()
                null
            }
            main.post {
                if (session != cb.id) {
                    try { loaded?.second?.shutdown() } catch (_: Throwable) {}
                    try { loaded?.first?.close() } catch (_: Throwable) {}
                    return@post
                }
                if (loaded == null) { fallback("Offline voice model failed to load"); return@post }
                voskRecognizer = loaded.first
                voskService = loaded.second
                val ok = try {
                    loaded.second.startListening(object : VoskListener {
                        override fun onPartialResult(hypothesis: String?) {
                            val t = jsonField(hypothesis, "partial")
                            if (t.isNotBlank()) main.post { if (session == cb.id) cb.onPartial(t) }
                        }

                        override fun onResult(hypothesis: String?) {
                            val t = jsonField(hypothesis, "text")
                            if (t.isNotBlank()) main.post { finish(cb, t, null) }
                        }

                        override fun onFinalResult(hypothesis: String?) {
                            val t = jsonField(hypothesis, "text")
                            main.post { finish(cb, t, "Didn't catch that — try again") }
                        }

                        override fun onError(exception: Exception?) {
                            main.post { fallback(exception?.message ?: "Offline recognition error") }
                        }

                        override fun onTimeout() {
                            main.post { finish(cb, null, "Didn't hear anything — try again") }
                        }
                    }, 15_000)
                } catch (t: Throwable) {
                    android.util.Log.e("VoiceInput", "Vosk start failed", t)
                    false
                }
                if (!ok) fallback("Microphone is busy")
            }
        }
    }

    private fun jsonField(json: String?, key: String): String = try {
        if (json.isNullOrBlank()) "" else JSONObject(json).optString(key, "").trim()
    } catch (_: Throwable) { "" }

    // ---- System recognizer (online, or on-device packs)

    private fun startSystem(cb: Callbacks, online: Boolean, fallback: (String) -> Unit) {
        val rec: SpeechRecognizer? = try {
            if (!online && Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(app)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(app)
            } else {
                SpeechRecognizer.createSpeechRecognizer(app)
            }
        } catch (t: Throwable) {
            android.util.Log.e("VoiceInput", "create recognizer failed", t)
            null
        }
        if (rec == null) { fallback("Speech service unavailable"); return }
        systemRecognizer = rec

        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = extractText(partialResults)
                if (t.isNotBlank()) main.post { if (session == cb.id) cb.onPartial(t) }
            }

            override fun onResults(results: Bundle?) {
                val t = extractText(results)
                main.post { finish(cb, t, "Didn't catch that — try again") }
            }

            override fun onError(error: Int) {
                main.post {
                    if (session != cb.id) return@post
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            finish(cb, null, "Didn't catch that — try again")
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            finish(cb, null, "Microphone permission required")
                        // Network / server / busy / client / language problems: try the other engine.
                        else -> fallback(describeError(error))
                    }
                }
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
            if (!online) putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        try {
            rec.startListening(intent)
        } catch (t: Throwable) {
            android.util.Log.e("VoiceInput", "startListening failed", t)
            fallback("Speech service failed to start")
        }
    }

    private fun extractText(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull { it.isNotBlank() }?.trim().orEmpty()

    private fun describeError(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "No internet for online voice"
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service busy"
        SpeechRecognizer.ERROR_SERVER -> "Speech server error"
        SpeechRecognizer.ERROR_CLIENT -> "Speech client error"
        else -> "Speech error ($code)"
    }
}
