# AUVYRR + SYNTRA — how the app is wired

```
AUVYRR app  →  SYNTRA (Supabase Edge Function /ai-router)  →  Groq  →  SYNTRA  →  AUVYRR app
```

## In the app
- `data/SyntraClient.kt` posts to `https://<project>.supabase.co/functions/v1/ai-router` with the signed-in user's
  Supabase JWT, `x-auvyrr-app-id: auvyrr-android-v1`, `x-installation-id` (random, made once) and `x-platform: android`.
  The URL comes from `SupabaseConfig.SUPABASE_URL`, so it uses the same project as chat.
- `data/GroqClient.kt` (used by Phantom, lyrics, mood ranking, Phantom chat and the alarm assistant) now tries SYNTRA first.
  `hasKey()` is always true, so no screen asks for a key. A key typed in Phantom settings is only an optional
  fallback if SYNTRA fails.
- No provider key is in the APK. If the user is signed out, offline, rate-limited or the server is down, AI features
  show a short message and the alarm keeps working (the ring screen falls back to local replies).

## Server steps (you do these once, see `backend/syntra/docs/FINAL_DEPLOYMENT.md`)
1. `cd backend/syntra && supabase link --project-ref ascwhsyyznwgchexboug && supabase db push`
2. `supabase functions deploy ai-router admin health monitor`
3. `supabase secrets set ADMIN_API_KEY=$(openssl rand -hex 32) GROQ_API_KEY_1=gsk_...`
4. Register the app key `auvyrr-android-v1` (POST /admin/applications), a groq account and the credential metadata
   (POST /admin/accounts, /admin/credentials) exactly as in the deployment guide.
5. Check `GET /functions/v1/health` shows `healthy_credentials >= 1`.

Until step 1–4 are done the app's AI calls fail with "The assistant had a problem" — everything else works.
