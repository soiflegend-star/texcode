/**
 * SYNTRA Key Monitor — client
 * Uses only the /monitor/* endpoints. Never handles provider API keys.
 */

const STORAGE_KEY = "syntra_monitor_session_v1";

const $ = (id) => document.getElementById(id);

let session = loadSession();

function loadSession() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
  } catch {
    return null;
  }
}

function saveSession(s) {
  session = s;
  if (s) localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  else localStorage.removeItem(STORAGE_KEY);
}

function setLoading(on) {
  $("loading").hidden = !on;
}

function showAuth(err) {
  $("authPanel").hidden = false;
  $("dashboard").hidden = true;
  if (err) {
    $("authError").hidden = false;
    $("authError").textContent = err;
  } else {
    $("authError").hidden = true;
  }
}

function showDash() {
  $("authPanel").hidden = true;
  $("dashboard").hidden = false;
  $("authError").hidden = true;
}

async function api(path) {
  const base = session.baseUrl.replace(/\/$/, "");
  const res = await fetch(`${base}/monitor/${path}`, {
    headers: {
      Authorization: `Bearer ${session.token}`,
      Accept: "application/json",
    },
  });
  const text = await res.text();
  let body = null;
  try {
    body = JSON.parse(text);
  } catch {
    /* ignore */
  }
  if (!res.ok) {
    const msg = body?.error?.message || body?.message || `HTTP ${res.status}`;
    const code = body?.error?.code || "";
    const err = new Error(msg);
    err.status = res.status;
    err.code = code;
    throw err;
  }
  return body;
}

function fmtTime(iso) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

function healthDot(status) {
  const s = (status || "unknown").toLowerCase();
  const cls =
    s === "healthy" ? "healthy" : s === "degraded" ? "degraded" : s === "unhealthy" ? "unhealthy" : "unknown";
  return `<span class="dot ${cls}"></span>${status || "unknown"}`;
}

function renderOverview(data) {
  const c = data.credentials || {};
  const items = [
    { label: "Total", value: c.total ?? 0, cls: "cyan" },
    { label: "Available", value: c.available ?? 0, cls: "green" },
    { label: "Busy", value: c.busy ?? 0, cls: "amber" },
    { label: "Disabled", value: c.disabled ?? 0, cls: "violet" },
    { label: "Suspended", value: c.suspended ?? 0, cls: "amber" },
    { label: "Unhealthy", value: c.unhealthy ?? 0, cls: "red" },
    { label: "Quota exhausted", value: c.quota_exhausted ?? 0, cls: "red" },
  ];
  $("overviewStats").innerHTML = items
    .map(
      (i) => `
    <div class="stat">
      <div class="label">${i.label}</div>
      <div class="value ${i.cls}">${i.value}</div>
    </div>`,
    )
    .join("");
}

function renderProviders(data, filter = "") {
  const list = (data.providers || []).filter((p) => {
    const q = filter.trim().toLowerCase();
    if (!q) return true;
    return (
      (p.code || "").toLowerCase().includes(q) ||
      (p.display_name || "").toLowerCase().includes(q)
    );
  });
  $("providerEmpty").hidden = list.length > 0;
  $("providerList").innerHTML = list
    .map((p) => {
      const qLabel =
        (p.accounts_detail || []).some((a) => a.quota_status === "exhausted")
          ? '<span class="pill bad">account quota exhausted</span>'
          : '<span class="pill ok">quota ok / unknown</span>';
      return `
      <article class="provider-card">
        <div>
          <h3>${escapeHtml(p.display_name || p.code)} <span class="muted">(${escapeHtml(p.code)})</span></h3>
          <div class="provider-meta">
            <span>${p.accounts ?? 0} accounts</span>
            <span>${p.credentials ?? 0} credentials</span>
            <span>${p.available_credentials ?? 0} available</span>
            <span>24h local: ${p.usage_24h?.requests ?? 0} req · ${p.usage_24h?.successes ?? 0} ok</span>
            <span>Last success: ${fmtTime(p.last_success_at)}</span>
          </div>
        </div>
        <div>${p.is_enabled ? '<span class="pill ok">enabled</span>' : '<span class="pill bad">disabled</span>'} ${qLabel}</div>
      </article>`;
    })
    .join("");
}

function renderCredentials(data, filter = "") {
  const list = (data.credentials || []).filter((c) => {
    const q = filter.trim().toLowerCase();
    if (!q) return true;
    return JSON.stringify(c).toLowerCase().includes(q);
  });
  $("credEmpty").hidden = list.length > 0;
  $("credBody").innerHTML = list
    .map((c) => {
      const susp = c.suspension?.active
        ? `<span class="pill warn">until ${fmtTime(c.suspension.until)}</span>`
        : '<span class="pill ok">none</span>';
      const quota =
        c.quota?.status === "exhausted"
          ? `<span class="pill bad">account exhausted</span>`
          : `<span class="pill info">unknown remaining</span>`;
      return `<tr>
        <td><code>${escapeHtml(c.credential_id)}</code></td>
        <td>${escapeHtml(c.provider)}</td>
        <td>${escapeHtml(c.account)}</td>
        <td>${c.priority}</td>
        <td>${healthDot(c.health_status)}</td>
        <td>${c.in_flight} / ${c.concurrency_limit}</td>
        <td>${susp}</td>
        <td>${quota}</td>
        <td>${fmtTime(c.last_success_at)}</td>
      </tr>`;
    })
    .join("");
}

function renderUsage(data) {
  const daily = data.daily || [];
  const max = Math.max(1, ...daily.map((d) => d.requests || 0));
  const life = data.lifetime || {};
  $("usagePanel").innerHTML = `
    <p class="muted">${escapeHtml(data.note || "")}</p>
    <p>Lifetime: <strong>${life.total_requests ?? 0}</strong> requests · <strong>${life.successful_requests ?? 0}</strong> successful <span class="pill info">local</span></p>
    ${daily
      .map((d) => {
        const pct = Math.round(((d.requests || 0) / max) * 100);
        return `<div class="usage-row">
          <span>${escapeHtml(d.day)}</span>
          <div class="bar"><span style="width:${pct}%"></span></div>
          <span>${d.requests ?? 0}</span>
        </div>`;
      })
      .join("")}`;
}

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function refresh() {
  if (!session?.baseUrl || !session?.token) {
    showAuth();
    return;
  }
  setLoading(true);
  $("dashError").hidden = true;
  try {
    const [overview, providers, credentials, usage] = await Promise.all([
      api("overview"),
      api("providers"),
      api("credentials"),
      api("usage"),
    ]);
    showDash();
    renderOverview(overview);
    renderProviders(providers, $("providerFilter").value);
    renderCredentials(credentials, $("credFilter").value);
    renderUsage(usage);
    $("lastUpdated").textContent = `Updated ${new Date().toLocaleString()}`;
    // stash for filters
    window.__monitorCache = { providers, credentials };
  } catch (err) {
    if (err.status === 401 || err.status === 403) {
      showAuth(err.message || "Access denied");
    } else {
      showDash();
      $("dashError").hidden = false;
      $("dashError").textContent = err.message || "Failed to load monitor data";
    }
  } finally {
    setLoading(false);
  }
}

$("btnConnect").addEventListener("click", () => {
  const baseUrl = $("baseUrl").value.trim();
  const token = $("accessToken").value.trim();
  if (!baseUrl || !token) {
    $("authError").hidden = false;
    $("authError").textContent = "Base URL and access token are required.";
    return;
  }
  saveSession({ baseUrl, token });
  refresh();
});

$("btnRefresh").addEventListener("click", () => refresh());
$("btnLogout").addEventListener("click", () => {
  saveSession(null);
  $("accessToken").value = "";
  showAuth();
});

$("providerFilter").addEventListener("input", (e) => {
  if (window.__monitorCache?.providers) {
    renderProviders(window.__monitorCache.providers, e.target.value);
  }
});
$("credFilter").addEventListener("input", (e) => {
  if (window.__monitorCache?.credentials) {
    renderCredentials(window.__monitorCache.credentials, e.target.value);
  }
});

// Init
if (session?.baseUrl) {
  $("baseUrl").value = session.baseUrl;
  refresh();
} else {
  showAuth();
}
