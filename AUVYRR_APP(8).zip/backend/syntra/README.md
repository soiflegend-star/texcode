# SYNTRA — Final Production Package

Central API headquarters for AUVYRR applications.

```
AUVYRR APP  →  SYNTRA  →  Groq (extensible providers)  →  SYNTRA  →  AUVYRR APP
```

**Version: 2.2 final**  
Users never enter provider API keys. Keys live only in Supabase Edge Function Secrets.

## What is included

- AI router (auth, validation, rate limits, credential selection, failover)
- Groq provider adapter + modular provider interface
- Admin API, health endpoint
- Key Monitor API + premium static dashboard
- SQL-controlled `key_monitor_access` permissions
- Migrations 001–006
- Android Kotlin client
- Automated tests (42 passing)
- Full documentation

## Quick start

See **`docs/FINAL_DEPLOYMENT.md`** for the complete checklist on your **existing** Supabase project.

Primary endpoint after deploy:

```
POST https://<project-ref>.supabase.co/functions/v1/ai-router
```

## Documentation

| Doc | Purpose |
|-----|---------|
| docs/FINAL_DEPLOYMENT.md | Deploy & configure |
| docs/FINAL_VERIFICATION_REPORT.md | Verification scorecard |
| docs/API_CONTRACT.md | Request/response contract |
| docs/KEY_MONITOR.md | Monitor access & SQL grant/revoke |
| docs/SECURITY.md | Security model |
| docs/ROUTING.md | Selection & failover |
| docs/DATABASE.md | Schema |
| docs/TESTING.md | How to run tests |

## Tests

```bash
deno test --allow-net --allow-env tests/
```

## License

Proprietary — AUVYRR / SYNTRA internal use.
