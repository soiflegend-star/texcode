// =============================================================================
// Credential & account availability updates
// =============================================================================

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

export async function markCredentialSuccess(
  service: SupabaseClient,
  credentialId: string,
): Promise<void> {
  await service
    .from("syntra_credentials")
    .update({
      health_status: "healthy",
      last_success_at: new Date().toISOString(),
      last_error_message: null,
      suspended_until: null,
    })
    .eq("id", credentialId);
}

export async function markCredentialError(
  service: SupabaseClient,
  credentialId: string,
  message: string,
  opts?: {
    markUnhealthy?: boolean;
    suspendSeconds?: number;
    quotaExhaustedSeconds?: number;
  },
): Promise<void> {
  const updates: Record<string, unknown> = {
    last_error_at: new Date().toISOString(),
    last_error_message: message.slice(0, 500),
  };
  if (opts?.markUnhealthy) {
    updates.health_status = "unhealthy";
  }
  if (opts?.suspendSeconds && opts.suspendSeconds > 0) {
    updates.suspended_until = new Date(Date.now() + opts.suspendSeconds * 1000).toISOString();
  }
  await service.from("syntra_credentials").update(updates).eq("id", credentialId);

  if (opts?.quotaExhaustedSeconds && opts.quotaExhaustedSeconds > 0) {
    const { data: cred } = await service
      .from("syntra_credentials")
      .select("account_id")
      .eq("id", credentialId)
      .single();
    if (cred) {
      const until = new Date(Date.now() + opts.quotaExhaustedSeconds * 1000).toISOString();
      await service
        .from("syntra_provider_accounts")
        .update({ quota_exhausted_until: until })
        .eq("id", cred.account_id);
    }
  }
}

/**
 * Resolve real API key from Edge secrets. Never logs the value.
 */
export function resolveSecret(secretRef: string): string | null {
  if (!secretRef || secretRef.trim().length === 0) return null;
  const key = Deno.env.get(secretRef);
  if (!key || key.trim().length === 0) {
    console.error(`Secret not found or empty: ${secretRef}`);
    return null;
  }
  return key.trim();
}
