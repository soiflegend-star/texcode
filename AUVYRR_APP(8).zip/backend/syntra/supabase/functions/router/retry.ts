// =============================================================================
// Controlled retry with exponential backoff
// Only used for genuine transient failures (never for quota or invalid requests).
// =============================================================================

export interface RetryPolicy {
  maxAttempts: number;
  baseDelayMs: number;
  maxDelayMs: number;
  jitter: boolean;
}

export const DEFAULT_RETRY_POLICY: RetryPolicy = {
  maxAttempts: 2, // initial + 1 retry
  baseDelayMs: 200,
  maxDelayMs: 2000,
  jitter: true,
};

/**
 * Compute delay before the next attempt (0-based attempt index after first failure).
 */
export function computeBackoffMs(attempt: number, policy: RetryPolicy = DEFAULT_RETRY_POLICY): number {
  const exp = Math.min(policy.maxDelayMs, policy.baseDelayMs * Math.pow(2, attempt));
  if (!policy.jitter) return exp;
  const jitter = Math.floor(Math.random() * (exp * 0.3));
  return Math.min(policy.maxDelayMs, exp + jitter);
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Run an async operation with limited retries.
 * shouldRetry(result, attempt) decides whether to continue.
 */
export async function withRetry<T>(
  operation: () => Promise<T>,
  shouldRetry: (result: T, attempt: number) => boolean,
  policy: RetryPolicy = DEFAULT_RETRY_POLICY,
): Promise<T> {
  let last: T;
  for (let attempt = 0; attempt < policy.maxAttempts; attempt++) {
    last = await operation();
    if (attempt === policy.maxAttempts - 1) return last;
    if (!shouldRetry(last, attempt)) return last;
    await sleep(computeBackoffMs(attempt, policy));
  }
  return last!;
}
