// =============================================================================
// Failover & recovery helpers
// Distinguishes failure categories and decides next action without
// rotating keys to bypass account quotas.
// =============================================================================

export type FailureCategory =
  | "rate_limited"
  | "quota_exhausted"
  | "auth_error"
  | "invalid_request"
  | "timeout"
  | "network"
  | "server_error"
  | "unknown"
  | "busy"
  | "disabled"
  | "unhealthy"
  | "no_credential";

export interface FailoverDecision {
  /** Whether a retry against the *same* credential is allowed */
  retrySame: boolean;
  /** Whether the router may try a different eligible credential */
  tryAlternate: boolean;
  /** Whether the account should be marked quota-exhausted */
  markQuotaExhausted: boolean;
  /** Suggested cooldown seconds for quota */
  quotaCooldownSeconds: number;
  /** Whether the credential should be marked unhealthy */
  markUnhealthy: boolean;
  /** Client-facing error code */
  clientCode:
    | "PROVIDER_UNAVAILABLE"
    | "TEMPORARY_SERVICE_UNAVAILABLE"
    | "INVALID_REQUEST"
    | "UNAUTHORIZED";
  /** Safe client message */
  clientMessage: string;
}

/**
 * Decide recovery behaviour from a normalized failure category.
 * Never recommends rotating across keys of the same account to bypass quotas.
 */
export function decideFailover(
  category: FailureCategory,
  retryAfterSeconds?: number,
): FailoverDecision {
  switch (category) {
    case "quota_exhausted":
    case "rate_limited":
      return {
        retrySame: false,
        tryAlternate: false, // same account quota — alternate keys share it
        markQuotaExhausted: true,
        quotaCooldownSeconds: retryAfterSeconds && retryAfterSeconds > 0 ? retryAfterSeconds : 60,
        markUnhealthy: false,
        clientCode: "TEMPORARY_SERVICE_UNAVAILABLE",
        clientMessage:
          "Provider quota temporarily exhausted. Please try again later.",
      };

    case "timeout":
    case "network":
    case "server_error":
      return {
        retrySame: true,
        tryAlternate: true,
        markQuotaExhausted: false,
        quotaCooldownSeconds: 0,
        markUnhealthy: false,
        clientCode: "PROVIDER_UNAVAILABLE",
        clientMessage: "Provider temporarily unavailable. Please retry.",
      };

    case "auth_error":
      return {
        retrySame: false,
        tryAlternate: true, // different account may work
        markQuotaExhausted: false,
        quotaCooldownSeconds: 0,
        markUnhealthy: true,
        clientCode: "PROVIDER_UNAVAILABLE",
        clientMessage: "Provider authentication failed for the selected credential.",
      };

    case "invalid_request":
      return {
        retrySame: false,
        tryAlternate: false,
        markQuotaExhausted: false,
        quotaCooldownSeconds: 0,
        markUnhealthy: false,
        clientCode: "INVALID_REQUEST",
        clientMessage: "The request was rejected by the provider.",
      };

    case "busy":
      return {
        retrySame: false,
        tryAlternate: true,
        markQuotaExhausted: false,
        quotaCooldownSeconds: 0,
        markUnhealthy: false,
        clientCode: "TEMPORARY_SERVICE_UNAVAILABLE",
        clientMessage: "All provider capacity is currently busy. Please retry shortly.",
      };

    case "disabled":
    case "unhealthy":
    case "no_credential":
      return {
        retrySame: false,
        tryAlternate: false,
        markQuotaExhausted: false,
        quotaCooldownSeconds: 0,
        markUnhealthy: false,
        clientCode: "PROVIDER_UNAVAILABLE",
        clientMessage: "No authorized provider credential is currently available.",
      };

    default:
      return {
        retrySame: false,
        tryAlternate: false,
        markQuotaExhausted: false,
        quotaCooldownSeconds: 0,
        markUnhealthy: false,
        clientCode: "PROVIDER_UNAVAILABLE",
        clientMessage: "Provider request failed.",
      };
  }
}
