// =============================================================================
// Atomic concurrency slot management
// Uses a database function so serverless instances do not race on counters.
// =============================================================================

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

/**
 * Attempt to acquire one concurrency slot.
 * Returns true only if the row was under its limit and the increment succeeded.
 */
export async function acquireConcurrencySlot(
  service: SupabaseClient,
  credentialId: string,
): Promise<boolean> {
  // Prefer the atomic RPC if present
  const { data, error } = await service.rpc("syntra_acquire_slot", {
    p_credential_id: credentialId,
  });

  if (!error && data === true) return true;
  if (!error && data === false) return false;

  // Fallback: optimistic compare-and-set (best-effort if RPC missing)
  const { data: row } = await service
    .from("syntra_credentials")
    .select("in_flight_count, concurrency_limit")
    .eq("id", credentialId)
    .single();

  if (!row || row.in_flight_count >= row.concurrency_limit) return false;

  const { error: updErr, count } = await service
    .from("syntra_credentials")
    .update({ in_flight_count: row.in_flight_count + 1 })
    .eq("id", credentialId)
    .eq("in_flight_count", row.in_flight_count)
    .select("id");

  return !updErr && Array.isArray(count) ? (count as any).length > 0 : !updErr;
}

/**
 * Release one concurrency slot (never goes below zero).
 */
export async function releaseConcurrencySlot(
  service: SupabaseClient,
  credentialId: string,
): Promise<void> {
  const { error } = await service.rpc("syntra_release_slot", {
    p_credential_id: credentialId,
  });

  if (!error) return;

  // Fallback
  const { data: row } = await service
    .from("syntra_credentials")
    .select("in_flight_count")
    .eq("id", credentialId)
    .single();
  if (!row) return;
  const next = Math.max(0, (row.in_flight_count as number) - 1);
  await service
    .from("syntra_credentials")
    .update({ in_flight_count: next })
    .eq("id", credentialId);
}
