// =============================================================================
// Credential Selector
// Deterministic selection: priority ASC → in_flight ASC among eligible rows.
// Distinguishes: disabled, busy, quota, unhealthy, suspended, unavailable.
// v2.1: respects suspended_until
// =============================================================================

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

export type SelectionReason =
  | "selected"
  | "no_credentials"
  | "all_disabled"
  | "all_busy"
  | "all_quota_exhausted"
  | "all_unhealthy"
  | "all_suspended"
  | "provider_disabled";

export interface SelectedCredential {
  id: string;
  account_id: string;
  credential_key: string;
  secret_ref: string;
  priority: number;
  concurrency_limit: number;
  in_flight_count: number;
  health_status: string;
  provider_code: string;
  provider_base_url: string;
}

export interface SelectionResult {
  reason: SelectionReason;
  credential: SelectedCredential | null;
  candidates_examined: number;
}

/**
 * Select the best eligible credential for a provider.
 * Never returns a disabled, unhealthy, suspended, over-concurrency,
 * or quota-blocked credential.
 */
export async function selectEligibleCredential(
  service: SupabaseClient,
  providerCode: string,
): Promise<SelectionResult> {
  const { data, error } = await service
    .from("syntra_credentials")
    .select(`
      id,
      account_id,
      credential_key,
      secret_ref,
      is_enabled,
      health_status,
      concurrency_limit,
      in_flight_count,
      priority,
      suspended_until,
      syntra_provider_accounts!inner (
        is_enabled,
        quota_exhausted_until,
        syntra_providers!inner (
          code,
          base_url,
          is_enabled
        )
      )
    `)
    .eq("syntra_provider_accounts.syntra_providers.code", providerCode)
    .order("priority", { ascending: true })
    .order("in_flight_count", { ascending: true });

  if (error) {
    console.error("selectEligibleCredential query error", error.message);
    return { reason: "no_credentials", credential: null, candidates_examined: 0 };
  }

  if (!data?.length) {
    return { reason: "no_credentials", credential: null, candidates_examined: 0 };
  }

  const now = Date.now();
  let anyEnabled = false;
  let anyHealthy = false;
  let anyNotBusy = false;
  let anyNotQuota = false;
  let anyNotSuspended = false;
  let providerEnabled = false;

  for (const raw of data) {
    const account = (raw as any).syntra_provider_accounts;
    const provider = account?.syntra_providers;

    if (provider?.is_enabled) providerEnabled = true;
    else continue;

    if (!raw.is_enabled || !account?.is_enabled) continue;
    anyEnabled = true;

    if (raw.health_status === "unhealthy") continue;
    anyHealthy = true;

    // Active suspension blocks selection; expired suspension is ignored
    const suspendedUntil = (raw as any).suspended_until as string | null;
    if (suspendedUntil && new Date(suspendedUntil).getTime() > now) {
      continue;
    }
    anyNotSuspended = true;

    const quotaUntil = account?.quota_exhausted_until;
    if (quotaUntil && new Date(quotaUntil) > new Date()) continue;
    anyNotQuota = true;

    if (raw.in_flight_count >= raw.concurrency_limit) continue;
    anyNotBusy = true;

    return {
      reason: "selected",
      credential: {
        id: raw.id,
        account_id: raw.account_id,
        credential_key: raw.credential_key,
        secret_ref: raw.secret_ref,
        priority: raw.priority,
        concurrency_limit: raw.concurrency_limit,
        in_flight_count: raw.in_flight_count,
        health_status: raw.health_status,
        provider_code: provider.code,
        provider_base_url: provider.base_url,
      },
      candidates_examined: data.length,
    };
  }

  if (!providerEnabled) {
    return { reason: "provider_disabled", credential: null, candidates_examined: data.length };
  }
  if (!anyEnabled) {
    return { reason: "all_disabled", credential: null, candidates_examined: data.length };
  }
  if (!anyHealthy) {
    return { reason: "all_unhealthy", credential: null, candidates_examined: data.length };
  }
  if (!anyNotSuspended) {
    return { reason: "all_suspended", credential: null, candidates_examined: data.length };
  }
  if (!anyNotQuota) {
    return { reason: "all_quota_exhausted", credential: null, candidates_examined: data.length };
  }
  if (!anyNotBusy) {
    return { reason: "all_busy", credential: null, candidates_examined: data.length };
  }
  return { reason: "no_credentials", credential: null, candidates_examined: data.length };
}

/**
 * Pure helper for unit tests: is a credential currently suspended?
 */
export function isCurrentlySuspended(
  suspendedUntil: string | null | undefined,
  nowMs: number = Date.now(),
): boolean {
  if (!suspendedUntil) return false;
  const t = new Date(suspendedUntil).getTime();
  if (Number.isNaN(t)) return false;
  return t > nowMs;
}
