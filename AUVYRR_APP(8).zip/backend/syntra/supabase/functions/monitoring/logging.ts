// =============================================================================
// Structured request logging — never logs secrets or full prompts
// =============================================================================

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

export interface RequestLogInput {
  requestId: string;
  userId: string | null;
  appId: string | null;
  installationId: string | null;
  provider?: string;
  model?: string;
  credentialId?: string;
  status: string;
  httpStatus?: number;
  durationMs: number;
  errorCode?: string;
  errorMessage?: string;
  retryCount?: number;
}

export async function logRequest(
  service: SupabaseClient,
  input: RequestLogInput,
): Promise<void> {
  try {
    await service.from("syntra_request_logs").insert({
      request_id: input.requestId,
      user_id: input.userId,
      app_id: input.appId,
      installation_id: input.installationId,
      provider_code: input.provider ?? null,
      model: input.model ?? null,
      credential_id: input.credentialId ?? null,
      status: input.status,
      http_status: input.httpStatus ?? null,
      duration_ms: input.durationMs,
      error_code: input.errorCode ?? null,
      error_message: input.errorMessage ? input.errorMessage.slice(0, 500) : null,
    });
  } catch (e: any) {
    console.error("logRequest failed", e?.message);
  }
}

export async function logErrorRecord(
  service: SupabaseClient,
  source: string,
  errorCode: string,
  message: string,
  requestId?: string,
  details?: Record<string, unknown>,
): Promise<void> {
  try {
    await service.from("syntra_error_records").insert({
      request_id: requestId ?? null,
      source,
      error_code: errorCode,
      message: message.slice(0, 1000),
      details: details ?? null,
    });
  } catch (e: any) {
    console.error("logErrorRecord failed", e?.message);
  }
}

export async function audit(
  service: SupabaseClient,
  actorType: string,
  action: string,
  targetType?: string,
  targetId?: string,
  payload?: unknown,
): Promise<void> {
  try {
    await service.from("syntra_audit_logs").insert({
      actor_type: actorType,
      action,
      target_type: targetType ?? null,
      target_id: targetId ?? null,
      payload: payload ?? null,
    });
  } catch {
    /* ignore */
  }
}
