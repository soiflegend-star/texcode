// =============================================================================
// Provider Adapter Interface
// All provider-specific logic must implement this contract.
// The router never contains provider-specific assumptions.
// =============================================================================

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ProviderRequest {
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  max_tokens?: number;
  request_id?: string;
  /** Opaque extra fields some providers may accept */
  extra?: Record<string, unknown>;
}

export interface ProviderUsage {
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
}

export interface ProviderChoice {
  index: number;
  message: { role: string; content: string };
  finish_reason: string | null;
}

export interface ProviderSuccess {
  ok: true;
  status: number;
  model: string;
  choices: ProviderChoice[];
  usage?: ProviderUsage;
  created: number;
  raw?: unknown;
}

export interface ProviderFailure {
  ok: false;
  status: number;
  /** Normalized category used by the router */
  category:
    | "rate_limited"
    | "quota_exhausted"
    | "auth_error"
    | "invalid_request"
    | "timeout"
    | "network"
    | "server_error"
    | "unknown";
  message: string;
  retry_after_seconds?: number;
  is_transient: boolean;
  is_quota_exhausted: boolean;
}

export type ProviderResult = ProviderSuccess | ProviderFailure;

export interface ProviderAdapter {
  /** Stable provider code, e.g. "groq" */
  readonly code: string;

  /** Human-readable name */
  readonly displayName: string;

  /**
   * Execute a chat completion against this provider.
   * Must never log or return the API key.
   */
  complete(
    apiKey: string,
    baseUrl: string,
    request: ProviderRequest,
    timeoutMs: number,
  ): Promise<ProviderResult>;
}

/**
 * Registry of available adapters.
 * New providers are added by implementing ProviderAdapter and registering here.
 */
const registry = new Map<string, ProviderAdapter>();

export function registerProvider(adapter: ProviderAdapter): void {
  registry.set(adapter.code.toLowerCase(), adapter);
}

export function getProvider(code: string): ProviderAdapter | null {
  return registry.get(code.toLowerCase()) ?? null;
}

export function listProviders(): string[] {
  return Array.from(registry.keys());
}
