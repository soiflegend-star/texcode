// =============================================================================
// Groq Provider Adapter (OpenAI-compatible chat completions)
// Implements ProviderAdapter — no router-specific logic here.
// =============================================================================

import {
  ProviderAdapter,
  ProviderRequest,
  ProviderResult,
  registerProvider,
} from "../provider-interface.ts";

export const groqAdapter: ProviderAdapter = {
  code: "groq",
  displayName: "Groq",

  async complete(
    apiKey: string,
    baseUrl: string,
    request: ProviderRequest,
    timeoutMs: number,
  ): Promise<ProviderResult> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const url = `${baseUrl.replace(/\/$/, "")}/chat/completions`;
      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: request.model,
          messages: request.messages,
          temperature: request.temperature ?? 0.7,
          max_tokens: request.max_tokens ?? 1024,
          stream: false,
        }),
        signal: controller.signal,
      });

      clearTimeout(timer);
      const text = await response.text();
      let parsed: any = null;
      try {
        parsed = JSON.parse(text);
      } catch {
        /* non-JSON body */
      }

      if (response.status === 429) {
        const retryAfter = response.headers.get("Retry-After");
        const seconds = retryAfter ? parseInt(retryAfter, 10) : 60;
        return {
          ok: false,
          status: 429,
          category: "quota_exhausted",
          message: parsed?.error?.message ?? "Rate limited by provider",
          retry_after_seconds: Number.isFinite(seconds) ? seconds : 60,
          is_transient: true,
          is_quota_exhausted: true,
        };
      }

      if (response.status === 401 || response.status === 403) {
        return {
          ok: false,
          status: response.status,
          category: "auth_error",
          message: parsed?.error?.message ?? "Provider authentication failed",
          is_transient: false,
          is_quota_exhausted: false,
        };
      }

      if (response.status === 400) {
        return {
          ok: false,
          status: 400,
          category: "invalid_request",
          message: parsed?.error?.message ?? "Invalid request to provider",
          is_transient: false,
          is_quota_exhausted: false,
        };
      }

      if (!response.ok) {
        return {
          ok: false,
          status: response.status,
          category: response.status >= 500 ? "server_error" : "unknown",
          message: parsed?.error?.message ?? text.slice(0, 300),
          is_transient: response.status >= 500,
          is_quota_exhausted: false,
        };
      }

      return {
        ok: true,
        status: 200,
        model: parsed.model ?? request.model,
        choices: (parsed.choices ?? []).map((c: any, i: number) => ({
          index: c.index ?? i,
          message: {
            role: c.message?.role ?? "assistant",
            content: c.message?.content ?? "",
          },
          finish_reason: c.finish_reason ?? null,
        })),
        usage: parsed.usage
          ? {
              prompt_tokens: parsed.usage.prompt_tokens ?? 0,
              completion_tokens: parsed.usage.completion_tokens ?? 0,
              total_tokens: parsed.usage.total_tokens ?? 0,
            }
          : undefined,
        created: parsed.created ?? Math.floor(Date.now() / 1000),
        raw: parsed,
      };
    } catch (err: any) {
      clearTimeout(timer);
      const isAbort = err?.name === "AbortError";
      return {
        ok: false,
        status: isAbort ? 504 : 500,
        category: isAbort ? "timeout" : "network",
        message: isAbort ? "Provider timeout" : (err?.message ?? "Network error"),
        is_transient: true,
        is_quota_exhausted: false,
      };
    }
  },
};

// Auto-register on import
registerProvider(groqAdapter);

// Backward-compatible wrapper used by older call sites
export async function callGroq(
  baseUrl: string,
  apiKey: string,
  payload: {
    model?: string;
    messages: Array<{ role: "system" | "user" | "assistant"; content: string }>;
    temperature?: number;
    max_tokens?: number;
    request_id?: string;
  },
  timeoutMs: number,
) {
  const result = await groqAdapter.complete(
    apiKey,
    baseUrl,
    {
      model: payload.model ?? "llama-3.1-8b-instant",
      messages: payload.messages,
      temperature: payload.temperature,
      max_tokens: payload.max_tokens,
      request_id: payload.request_id,
    },
    timeoutMs,
  );

  // Map to legacy shape expected by existing ai-router
  if (result.ok) {
    return {
      ok: true as const,
      status: 200,
      body: {
        request_id: payload.request_id ?? crypto.randomUUID(),
        provider: "groq",
        model: result.model,
        choices: result.choices,
        usage: result.usage,
        created: result.created,
      },
    };
  }
  return {
    ok: false as const,
    status: result.status,
    rawError: result.message,
    retryAfterSeconds: result.retry_after_seconds,
    isQuotaExhausted: result.is_quota_exhausted,
    isTransient: result.is_transient,
    category: result.category,
  };
}
