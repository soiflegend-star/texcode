// =============================================================================
// Public health endpoint (no secrets, no user data)
// =============================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createServiceClient } from "../_shared/auth.ts";

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, OPTIONS",
      },
    });
  }

  try {
    const service = createServiceClient();
    const { count } = await service
      .from("syntra_credentials")
      .select("id", { count: "exact", head: true })
      .eq("is_enabled", true)
      .neq("health_status", "unhealthy");

    return new Response(
      JSON.stringify({
        status: "ok",
        service: "syntra",
        healthy_credentials: count ?? 0,
        timestamp: new Date().toISOString(),
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      },
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({
        status: "degraded",
        service: "syntra",
        message: "Health check could not query database",
        timestamp: new Date().toISOString(),
      }),
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      },
    );
  }
});
