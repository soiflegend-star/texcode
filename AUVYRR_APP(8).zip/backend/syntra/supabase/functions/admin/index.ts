// =============================================================================
// SYNTRA Admin endpoints
// Protected by ADMIN_API_KEY secret (never put this in any client app).
// =============================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createServiceClient, requireAdmin } from "../_shared/auth.ts";
import {
  invalidRequest,
  unauthorized,
  internalError,
  forbidden,
} from "../_shared/errors.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-admin-key, content-type",
  "Access-Control-Allow-Methods": "GET, POST, PATCH, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }

  const adminCheck = requireAdmin(req);
  if ("error" in adminCheck) {
    return withCors(adminCheck.error);
  }

  const url = new URL(req.url);
  const path = url.pathname.replace(/\/functions\/v1\/admin\/?/, "").replace(/^\//, "");
  const service = createServiceClient();

  try {
    // GET /admin/status
    if (req.method === "GET" && (path === "" || path === "status")) {
      const { data: creds } = await service
        .from("syntra_credentials")
        .select("id, credential_key, is_enabled, health_status, in_flight_count, concurrency_limit, last_success_at, last_error_at");
      const { count: totalRequests } = await service
        .from("syntra_request_logs")
        .select("id", { count: "exact", head: true });
      const { count: recentErrors } = await service
        .from("syntra_request_logs")
        .select("id", { count: "exact", head: true })
        .neq("status", "success")
        .gte("created_at", new Date(Date.now() - 3600_000).toISOString());

      return json({
        status: "ok",
        credentials: creds ?? [],
        total_requests: totalRequests ?? 0,
        errors_last_hour: recentErrors ?? 0,
      });
    }

    // POST /admin/applications — register an app
    if (req.method === "POST" && path === "applications") {
      const body = await req.json();
      if (!body.app_key || !body.display_name) {
        return withCors(invalidRequest("app_key and display_name required"));
      }
      const { data, error } = await service
        .from("syntra_applications")
        .insert({
          app_key: body.app_key,
          display_name: body.display_name,
          description: body.description ?? null,
          rate_limit_rpm: body.rate_limit_rpm ?? 60,
          rate_limit_rpd: body.rate_limit_rpd ?? 1000,
        })
        .select()
        .single();
      if (error) return withCors(internalError(error.message));
      await audit(service, "admin", "register_application", "application", data.id, body);
      return json(data, 201);
    }

    // POST /admin/accounts — register provider account metadata
    if (req.method === "POST" && path === "accounts") {
      const body = await req.json();
      if (!body.provider_code || !body.account_label) {
        return withCors(invalidRequest("provider_code and account_label required"));
      }
      const { data: provider } = await service
        .from("syntra_providers")
        .select("id")
        .eq("code", body.provider_code)
        .single();
      if (!provider) return withCors(invalidRequest("Unknown provider_code"));

      const { data, error } = await service
        .from("syntra_provider_accounts")
        .insert({
          provider_id: provider.id,
          account_label: body.account_label,
          notes: body.notes ?? null,
        })
        .select()
        .single();
      if (error) return withCors(internalError(error.message));
      await audit(service, "admin", "register_account", "provider_account", data.id, body);
      return json(data, 201);
    }

    // POST /admin/credentials — add credential metadata (secret must already exist in Edge secrets)
    if (req.method === "POST" && path === "credentials") {
      const body = await req.json();
      if (!body.account_id || !body.credential_key || !body.secret_ref) {
        return withCors(
          invalidRequest("account_id, credential_key and secret_ref are required"),
        );
      }
      // Verify the secret actually exists in the environment
      if (!Deno.env.get(body.secret_ref)) {
        return withCors(
          invalidRequest(
            `Secret "${body.secret_ref}" is not present in Edge Function secrets. Add it first via the Supabase dashboard or CLI.`,
          ),
        );
      }

      const { data, error } = await service
        .from("syntra_credentials")
        .insert({
          account_id: body.account_id,
          credential_key: body.credential_key,
          secret_ref: body.secret_ref,
          concurrency_limit: body.concurrency_limit ?? 5,
          priority: body.priority ?? 100,
          health_status: "unknown",
        })
        .select()
        .single();
      if (error) return withCors(internalError(error.message));
      await audit(service, "admin", "register_credential", "credential", data.id, {
        credential_key: body.credential_key,
        secret_ref: body.secret_ref,
      });
      return json(data, 201);
    }

    // PATCH /admin/credentials/:id — enable/disable, change limits
    if (req.method === "PATCH" && path.startsWith("credentials/")) {
      const id = path.split("/")[1];
      const body = await req.json();
      const allowed: Record<string, unknown> = {};
      if (typeof body.is_enabled === "boolean") allowed.is_enabled = body.is_enabled;
      if (typeof body.concurrency_limit === "number") allowed.concurrency_limit = body.concurrency_limit;
      if (typeof body.priority === "number") allowed.priority = body.priority;
      if (body.health_status) allowed.health_status = body.health_status;

      if (Object.keys(allowed).length === 0) {
        return withCors(invalidRequest("No valid fields to update"));
      }

      const { data, error } = await service
        .from("syntra_credentials")
        .update(allowed)
        .eq("id", id)
        .select()
        .single();
      if (error) return withCors(internalError(error.message));
      await audit(service, "admin", "update_credential", "credential", id, allowed);
      return json(data);
    }

    // POST /admin/credentials/:id/revoke
    if (req.method === "POST" && path.match(/^credentials\/[^/]+\/revoke$/)) {
      const id = path.split("/")[1];
      const { data, error } = await service
        .from("syntra_credentials")
        .update({ is_enabled: false, health_status: "unhealthy" })
        .eq("id", id)
        .select()
        .single();
      if (error) return withCors(internalError(error.message));
      await audit(service, "admin", "revoke_credential", "credential", id, {});
      return json(data);
    }

    // GET /admin/stats
    if (req.method === "GET" && path === "stats") {
      const { data: daily } = await service
        .from("syntra_usage_daily")
        .select("*")
        .order("day", { ascending: false })
        .limit(30);
      const { data: recent } = await service
        .from("syntra_request_logs")
        .select("status, provider_code, model, duration_ms, created_at, error_code")
        .order("created_at", { ascending: false })
        .limit(50);
      return json({ daily_usage: daily ?? [], recent_requests: recent ?? [] });
    }

    // GET /admin/errors
    if (req.method === "GET" && path === "errors") {
      const { data } = await service
        .from("syntra_request_logs")
        .select("*")
        .neq("status", "success")
        .order("created_at", { ascending: false })
        .limit(100);
      return json({ errors: data ?? [] });
    }

    return withCors(invalidRequest(`Unknown admin path: ${path}`));
  } catch (err: any) {
    console.error("admin error", err?.message);
    return withCors(internalError("Admin operation failed"));
  }
});

function json(data: unknown, status = 200) {
  return withCors(
    new Response(JSON.stringify(data), {
      status,
      headers: { "Content-Type": "application/json" },
    }),
  );
}

function withCors(res: Response): Response {
  const headers = new Headers(res.headers);
  for (const [k, v] of Object.entries(CORS)) headers.set(k, v);
  return new Response(res.body, { status: res.status, headers });
}

async function audit(
  service: ReturnType<typeof createServiceClient>,
  actorType: string,
  action: string,
  targetType: string,
  targetId: string,
  payload: unknown,
) {
  try {
    await service.from("syntra_audit_logs").insert({
      actor_type: actorType,
      action,
      target_type: targetType,
      target_id: targetId,
      payload,
    });
  } catch { /* ignore */ }
}
