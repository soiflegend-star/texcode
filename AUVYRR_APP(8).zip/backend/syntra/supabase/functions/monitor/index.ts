// =============================================================================
// SYNTRA Key Monitor API
// GET /monitor/overview | /providers | /credentials | /usage | /health
// Requires: valid JWT + explicit key_monitor_access permission
// Never returns secrets, secret_ref values, or raw API keys.
// =============================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createServiceClient, createUserClient } from "../_shared/auth.ts";
import { requireKeyMonitorAccess } from "../_shared/authorization/permissions.ts";
import {
  unauthorized,
  forbidden,
  invalidRequest,
  internalError,
} from "../_shared/errors.ts";

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (req.method !== "GET") {
    return withCors(invalidRequest("Only GET is supported"));
  }

  try {
    // --- Auth: valid JWT required ---
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return withCors(unauthorized("Missing or invalid Authorization header"));
    }

    const userClient = createUserClient(authHeader);
    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) {
      return withCors(unauthorized("Invalid or expired token"));
    }

    const service = createServiceClient();

    // --- Permission: key_monitor_access must be explicitly granted ---
    const allowed = await requireKeyMonitorAccess(service, user.id);
    if (!allowed) {
      return withCors(
        forbidden(
          "key_monitor_access is not granted for this profile. Contact an administrator.",
        ),
      );
    }

    const url = new URL(req.url);
    // Path may be /monitor, /monitor/overview, /functions/v1/monitor/overview, etc.
    const rawPath = url.pathname.replace(/\/functions\/v1\/monitor\/?/, "").replace(/^\//, "");
    const path = rawPath === "" || rawPath === "monitor" ? "overview" : rawPath.split("/")[0];

    switch (path) {
      case "overview":
        return withCors(json(await buildOverview(service)));
      case "providers":
        return withCors(json(await buildProviders(service)));
      case "credentials":
        return withCors(json(await buildCredentials(service)));
      case "usage":
        return withCors(json(await buildUsage(service)));
      case "health":
        return withCors(json(await buildHealth(service)));
      default:
        return withCors(invalidRequest(`Unknown monitor path: ${path}`));
    }
  } catch (err: any) {
    console.error("monitor error", err?.message ?? err);
    return withCors(internalError("Monitor request failed"));
  }
});

// ---------------------------------------------------------------------------
// Safe response builders — never include secret_ref or API keys
// ---------------------------------------------------------------------------

async function buildOverview(service: ReturnType<typeof createServiceClient>) {
  const { data: creds } = await service
    .from("syntra_credentials")
    .select(
      "id, is_enabled, health_status, in_flight_count, concurrency_limit, suspended_until, syntra_provider_accounts(quota_exhausted_until, is_enabled)",
    );

  const now = Date.now();
  let total = 0;
  let available = 0;
  let busy = 0;
  let disabled = 0;
  let suspended = 0;
  let unhealthy = 0;
  let quotaExhausted = 0;

  for (const c of creds ?? []) {
    total++;
    const account = (c as any).syntra_provider_accounts;
    const susp = c.suspended_until && new Date(c.suspended_until).getTime() > now;
    const quota =
      account?.quota_exhausted_until &&
      new Date(account.quota_exhausted_until).getTime() > now;

    if (!c.is_enabled || account?.is_enabled === false) {
      disabled++;
      continue;
    }
    if (c.health_status === "unhealthy") {
      unhealthy++;
      continue;
    }
    if (susp) {
      suspended++;
      continue;
    }
    if (quota) {
      quotaExhausted++;
      continue;
    }
    if (c.in_flight_count >= c.concurrency_limit) {
      busy++;
      continue;
    }
    available++;
  }

  return {
    generated_at: new Date().toISOString(),
    credentials: {
      total,
      available,
      busy,
      disabled,
      suspended,
      unhealthy,
      quota_exhausted: quotaExhausted,
    },
  };
}

async function buildProviders(service: ReturnType<typeof createServiceClient>) {
  const { data: providers } = await service
    .from("syntra_providers")
    .select("id, code, display_name, is_enabled, base_url");

  const result = [];
  for (const p of providers ?? []) {
    const { data: accounts } = await service
      .from("syntra_provider_accounts")
      .select("id, account_label, is_enabled, quota_exhausted_until")
      .eq("provider_id", p.id);

    const accountIds = (accounts ?? []).map((a) => a.id);
    let credCount = 0;
    let available = 0;
    let lastSuccess: string | null = null;

    if (accountIds.length) {
      const { data: creds } = await service
        .from("syntra_credentials")
        .select(
          "id, is_enabled, health_status, in_flight_count, concurrency_limit, suspended_until, last_success_at, account_id",
        )
        .in("account_id", accountIds);

      const now = Date.now();
      for (const c of creds ?? []) {
        credCount++;
        if (c.last_success_at && (!lastSuccess || c.last_success_at > lastSuccess)) {
          lastSuccess = c.last_success_at;
        }
        const susp = c.suspended_until && new Date(c.suspended_until).getTime() > now;
        const acct = (accounts ?? []).find((a) => a.id === c.account_id);
        const quota =
          acct?.quota_exhausted_until &&
          new Date(acct.quota_exhausted_until).getTime() > now;
        if (
          c.is_enabled &&
          acct?.is_enabled &&
          c.health_status !== "unhealthy" &&
          !susp &&
          !quota &&
          c.in_flight_count < c.concurrency_limit
        ) {
          available++;
        }
      }
    }

    // Local usage (last 24h request_logs for this provider)
    const dayAgo = new Date(Date.now() - 86400_000).toISOString();
    const { count: requests24h } = await service
      .from("syntra_request_logs")
      .select("id", { count: "exact", head: true })
      .eq("provider_code", p.code)
      .gte("created_at", dayAgo);

    const { count: success24h } = await service
      .from("syntra_request_logs")
      .select("id", { count: "exact", head: true })
      .eq("provider_code", p.code)
      .eq("status", "success")
      .gte("created_at", dayAgo);

    result.push({
      code: p.code,
      display_name: p.display_name,
      is_enabled: p.is_enabled,
      accounts: (accounts ?? []).length,
      credentials: credCount,
      available_credentials: available,
      accounts_detail: (accounts ?? []).map((a) => ({
        label: a.account_label,
        is_enabled: a.is_enabled,
        quota_status: quotaStatus(a.quota_exhausted_until),
        // Provider-reported remaining quota is unknown unless a provider exposes it
        remaining_quota: { source: "unknown", value: null as number | null },
      })),
      usage_24h: {
        source: "local",
        requests: requests24h ?? 0,
        successes: success24h ?? 0,
      },
      last_success_at: lastSuccess,
    });
  }

  return { generated_at: new Date().toISOString(), providers: result };
}

async function buildCredentials(service: ReturnType<typeof createServiceClient>) {
  const { data: creds } = await service
    .from("syntra_credentials")
    .select(`
      id,
      credential_key,
      is_enabled,
      health_status,
      priority,
      concurrency_limit,
      in_flight_count,
      suspended_until,
      last_success_at,
      last_error_at,
      last_error_message,
      syntra_provider_accounts!inner (
        account_label,
        is_enabled,
        quota_exhausted_until,
        syntra_providers!inner (
          code,
          display_name
        )
      )
    `)
    .order("priority", { ascending: true });

  const now = Date.now();
  const list = (creds ?? []).map((c) => {
    const account = (c as any).syntra_provider_accounts;
    const provider = account?.syntra_providers;
    const suspActive =
      c.suspended_until && new Date(c.suspended_until).getTime() > now;
    const quotaActive =
      account?.quota_exhausted_until &&
      new Date(account.quota_exhausted_until).getTime() > now;

    return {
      // Masked identifier — never secret_ref or API key
      credential_id: maskId(c.credential_key || c.id),
      provider: provider?.code ?? "unknown",
      provider_name: provider?.display_name ?? "unknown",
      account: account?.account_label ?? "unknown",
      priority: c.priority,
      health_status: c.health_status,
      is_enabled: c.is_enabled && account?.is_enabled !== false,
      in_flight: c.in_flight_count,
      concurrency_limit: c.concurrency_limit,
      suspension: {
        active: !!suspActive,
        until: suspActive ? c.suspended_until : null,
      },
      quota: {
        // Account-level — not per-key independent quotas
        scope: "account",
        status: quotaStatus(account?.quota_exhausted_until),
        exhausted_until: quotaActive ? account.quota_exhausted_until : null,
        remaining: { source: "unknown", value: null as number | null },
      },
      last_success_at: c.last_success_at,
      last_error_at: c.last_error_at,
      // Safe truncated error message only
      last_error_message: c.last_error_message
        ? String(c.last_error_message).slice(0, 200)
        : null,
    };
  });

  return { generated_at: new Date().toISOString(), credentials: list };
}

async function buildUsage(service: ReturnType<typeof createServiceClient>) {
  const today = new Date().toISOString().slice(0, 10);
  const { data: daily } = await service
    .from("syntra_usage_daily")
    .select("day, request_count, success_count, error_count, tokens_in, tokens_out")
    .order("day", { ascending: false })
    .limit(14);

  const { count: totalLogs } = await service
    .from("syntra_request_logs")
    .select("id", { count: "exact", head: true });

  const { count: successLogs } = await service
    .from("syntra_request_logs")
    .select("id", { count: "exact", head: true })
    .eq("status", "success");

  return {
    generated_at: new Date().toISOString(),
    note: "Usage figures are locally tracked by SYNTRA. Provider-reported remaining quotas are unknown unless the provider exposes them.",
    lifetime: {
      source: "local",
      total_requests: totalLogs ?? 0,
      successful_requests: successLogs ?? 0,
    },
    daily: (daily ?? []).map((d) => ({
      day: d.day,
      source: "local",
      requests: d.request_count,
      successes: d.success_count,
      errors: d.error_count,
      tokens_in: d.tokens_in,
      tokens_out: d.tokens_out,
    })),
    today,
  };
}

async function buildHealth(service: ReturnType<typeof createServiceClient>) {
  const overview = await buildOverview(service);
  const ok =
    overview.credentials.available > 0 ||
    overview.credentials.busy > 0;

  return {
    generated_at: new Date().toISOString(),
    status: ok ? "operational" : "degraded",
    credentials: overview.credentials,
  };
}

function quotaStatus(until: string | null | undefined): string {
  if (!until) return "ok";
  if (new Date(until).getTime() > Date.now()) return "exhausted";
  return "ok";
}

/** Mask credential_key / id for display — never full secret material */
function maskId(value: string): string {
  if (!value) return "****";
  if (value.length <= 6) return "****" + value.slice(-2);
  return value.slice(0, 4) + "••••" + value.slice(-4);
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function withCors(res: Response): Response {
  const headers = new Headers(res.headers);
  for (const [k, v] of Object.entries(CORS)) headers.set(k, v);
  return new Response(res.body, { status: res.status, headers });
}
