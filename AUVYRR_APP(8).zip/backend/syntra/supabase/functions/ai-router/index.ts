// =============================================================================
// SYNTRA AI Router (upgraded)
// Modular: auth → validation → rate-limit → select → acquire → provider → log
// =============================================================================

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { resolveAuthContext, createServiceClient } from "../_shared/auth.ts";
import {
  invalidRequest,
  temporaryUnavailable,
  providerUnavailable,
  internalError,
} from "../_shared/errors.ts";
import { validateAiRequest } from "../_shared/validation/request.ts";
import { checkAndRecordUsage, recordOutcome } from "../_shared/rate-limit.ts";
import { selectEligibleCredential } from "../router/selector.ts";
import { acquireConcurrencySlot, releaseConcurrencySlot } from "../router/concurrency.ts";
import { decideFailover } from "../router/failover.ts";
import { withRetry, DEFAULT_RETRY_POLICY } from "../router/retry.ts";
import { markCredentialSuccess, markCredentialError, resolveSecret } from "../router/availability.ts";
import { logRequest, logErrorRecord } from "../monitoring/logging.ts";

// Register providers (side-effect import)
import "../providers/groq/index.ts";
import { getProvider } from "../providers/provider-interface.ts";

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-auvyrr-app-id, x-app-id, x-installation-id, x-platform, x-app-version, x-api-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  if (req.method !== "POST") {
    return withCors(invalidRequest("Only POST is supported"));
  }

  const requestId = crypto.randomUUID();
  const started = Date.now();
  let service: ReturnType<typeof createServiceClient> | null = null;
  let credentialId: string | null = null;
  let syntraUserId: string | null = null;
  let appId: string | null = null;
  let installationId: string | null = null;

  try {
    // ---- Maintenance mode ----
    service = createServiceClient();
    const { data: maint } = await service
      .from("syntra_config")
      .select("value")
      .eq("key", "maintenance_mode")
      .maybeSingle();
    if (maint?.value === true || maint?.value === "true") {
      return withCors(
        temporaryUnavailable("SYNTRA is in maintenance mode. Please try again later.", 60, requestId),
      );
    }

    // ---- Auth ----
    const authResult = await resolveAuthContext(req);
    if ("error" in authResult) {
      return withCors(authResult.error);
    }
    const ctx = authResult.ctx;
    syntraUserId = ctx.syntraUserId;
    appId = ctx.appId;
    installationId = ctx.installationId;

    // ---- Rate limit ----
    const limitResponse = await checkAndRecordUsage(service, ctx, requestId);
    if (limitResponse) {
      await logRequest(service, {
        requestId,
        userId: syntraUserId,
        appId,
        installationId,
        status: "rate_limited",
        durationMs: Date.now() - started,
        errorCode: "RATE_LIMITED",
      });
      return withCors(limitResponse);
    }

    // ---- Body size + validation ----
    const rawText = await req.text();
    const maxBytes = Number(Deno.env.get("MAX_REQUEST_BODY_BYTES") ?? "1048576");
    let parsed: unknown;
    try {
      parsed = JSON.parse(rawText);
    } catch {
      return withCors(invalidRequest("Invalid JSON body", requestId));
    }

    const validation = validateAiRequest(parsed, maxBytes, new TextEncoder().encode(rawText).length);
    if (!validation.ok) {
      return withCors(invalidRequest(validation.message, requestId));
    }
    const body = validation.body;
    body.request_id = body.request_id ?? requestId;

    const providerCode = (body.provider ?? "groq").toLowerCase();
    const model = body.model ?? "llama-3.1-8b-instant";

    const adapter = getProvider(providerCode);
    if (!adapter) {
      await logRequest(service, {
        requestId, userId: syntraUserId, appId, installationId,
        status: "error", durationMs: Date.now() - started,
        provider: providerCode, model, errorCode: "INVALID_REQUEST",
        errorMessage: `Unknown provider: ${providerCode}`,
      });
      return withCors(invalidRequest(`Unsupported provider: ${providerCode}`, requestId));
    }

    // ---- Select credential ----
    const selection = await selectEligibleCredential(service, providerCode);
    if (selection.reason !== "selected" || !selection.credential) {
      const decision = decideFailover(
        selection.reason === "all_busy" ? "busy"
          : selection.reason === "all_quota_exhausted" ? "quota_exhausted"
          : selection.reason === "all_disabled" || selection.reason === "all_unhealthy" || selection.reason === "all_suspended" ? "disabled"
          : "no_credential",
      );
      await logRequest(service, {
        requestId, userId: syntraUserId, appId, installationId,
        status: selection.reason, durationMs: Date.now() - started,
        provider: providerCode, model, errorCode: decision.clientCode,
        errorMessage: decision.clientMessage,
      });
      if (decision.clientCode === "TEMPORARY_SERVICE_UNAVAILABLE") {
        return withCors(temporaryUnavailable(decision.clientMessage, 5, requestId));
      }
      return withCors(providerUnavailable(decision.clientMessage, requestId));
    }

    const credential = selection.credential;

    // ---- Acquire concurrency slot ----
    const acquired = await acquireConcurrencySlot(service, credential.id);
    if (!acquired) {
      await logRequest(service, {
        requestId, userId: syntraUserId, appId, installationId,
        status: "busy", durationMs: Date.now() - started,
        provider: providerCode, model, credentialId: credential.id,
        errorCode: "TEMPORARY_SERVICE_UNAVAILABLE",
      });
      return withCors(
        temporaryUnavailable("All provider capacity is currently busy. Please retry shortly.", 5, requestId),
      );
    }
    credentialId = credential.id;

    const apiKey = resolveSecret(credential.secret_ref);
    if (!apiKey) {
      await releaseConcurrencySlot(service, credential.id);
      credentialId = null;
      await markCredentialError(service, credential.id, "Secret not configured", { markUnhealthy: true });
      return withCors(temporaryUnavailable("Provider credential is misconfigured", undefined, requestId));
    }

    // ---- Call provider with controlled retry ----
    const timeoutMs = Number(Deno.env.get("PROVIDER_TIMEOUT_MS") ?? "30000");
    const policy = { ...DEFAULT_RETRY_POLICY, maxAttempts: Number(Deno.env.get("DEFAULT_RETRY_ATTEMPTS") ?? "2") };

    let retryCount = 0;
    const result = await withRetry(
      async () => {
        return adapter.complete(
          apiKey,
          credential.provider_base_url,
          {
            model,
            messages: body.messages,
            temperature: body.temperature,
            max_tokens: body.max_tokens,
            request_id: body.request_id,
          },
          timeoutMs,
        );
      },
      (r, attempt) => {
        if (r.ok) return false;
        if (!r.is_transient || r.is_quota_exhausted) return false;
        retryCount = attempt + 1;
        return true;
      },
      policy,
    );

    await releaseConcurrencySlot(service, credential.id);
    credentialId = null;

    if (!result.ok) {
      const decision = decideFailover(
        result.category as any,
        result.retry_after_seconds,
      );
      await markCredentialError(service, credential.id, result.message, {
        markUnhealthy: decision.markUnhealthy,
        quotaExhaustedSeconds: decision.markQuotaExhausted ? decision.quotaCooldownSeconds : undefined,
      });
      await logRequest(service, {
        requestId, userId: syntraUserId, appId, installationId,
        status: "error", durationMs: Date.now() - started,
        provider: providerCode, model, credentialId: credential.id,
        httpStatus: result.status, errorCode: decision.clientCode,
        errorMessage: result.message, retryCount,
      });
      await logErrorRecord(service, "provider", decision.clientCode, result.message, requestId, {
        category: result.category, status: result.status,
      });
      await recordOutcome(service, ctx, false);

      if (decision.clientCode === "TEMPORARY_SERVICE_UNAVAILABLE") {
        return withCors(
          temporaryUnavailable(decision.clientMessage, decision.quotaCooldownSeconds || 30, requestId),
        );
      }
      if (decision.clientCode === "INVALID_REQUEST") {
        return withCors(invalidRequest(decision.clientMessage, requestId));
      }
      return withCors(providerUnavailable(decision.clientMessage, requestId));
    }

    // ---- Success ----
    await markCredentialSuccess(service, credential.id);
    const tokensIn = result.usage?.prompt_tokens ?? 0;
    const tokensOut = result.usage?.completion_tokens ?? 0;
    await recordOutcome(service, ctx, true, tokensIn, tokensOut);

    const responseBody = {
      request_id: requestId,
      provider: providerCode,
      model: result.model,
      choices: result.choices,
      usage: result.usage,
      created: result.created,
    };

    await logRequest(service, {
      requestId, userId: syntraUserId, appId, installationId,
      status: "success", durationMs: Date.now() - started,
      provider: providerCode, model, credentialId: credential.id,
      httpStatus: 200, retryCount,
    });

    return withCors(
      new Response(JSON.stringify(responseBody), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }),
    );
  } catch (err: any) {
    console.error("ai-router unhandled", err?.message ?? err);
    if (service && credentialId) {
      try { await releaseConcurrencySlot(service, credentialId); } catch { /* ignore */ }
    }
    if (service) {
      await logRequest(service, {
        requestId,
        userId: syntraUserId,
        appId,
        installationId,
        status: "error",
        durationMs: Date.now() - started,
        errorCode: "INTERNAL_SERVER_ERROR",
        errorMessage: "Unhandled exception",
      });
    }
    return withCors(internalError("An unexpected error occurred", requestId));
  }
});

function withCors(res: Response): Response {
  const headers = new Headers(res.headers);
  for (const [k, v] of Object.entries(CORS_HEADERS)) headers.set(k, v);
  return new Response(res.body, { status: res.status, headers });
}
