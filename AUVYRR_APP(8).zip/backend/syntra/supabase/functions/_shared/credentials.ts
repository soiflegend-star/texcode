// =============================================================================
// Backward-compatible re-exports + legacy selectCredential wrapper
// Prefer importing from router/ directly in new code.
// =============================================================================

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { selectEligibleCredential } from "../router/selector.ts";
import {
  acquireConcurrencySlot,
  releaseConcurrencySlot,
} from "../router/concurrency.ts";
import {
  markCredentialSuccess,
  markCredentialError,
  resolveSecret,
} from "../router/availability.ts";
import { CredentialRow } from "./types.ts";

export async function selectCredential(
  service: SupabaseClient,
  providerCode: string,
): Promise<CredentialRow | null> {
  const result = await selectEligibleCredential(service, providerCode);
  if (result.reason !== "selected" || !result.credential) return null;
  const c = result.credential;
  return {
    id: c.id,
    account_id: c.account_id,
    credential_key: c.credential_key,
    secret_ref: c.secret_ref,
    is_enabled: true,
    health_status: c.health_status as any,
    concurrency_limit: c.concurrency_limit,
    in_flight_count: c.in_flight_count,
    last_success_at: null,
    last_error_at: null,
    last_error_message: null,
    priority: c.priority,
    provider_code: c.provider_code,
    provider_base_url: c.provider_base_url,
  };
}

export const acquireSlot = acquireConcurrencySlot;
export const releaseSlot = releaseConcurrencySlot;
export const markSuccess = markCredentialSuccess;
export const markError = markCredentialError;
export const resolveApiKey = resolveSecret;
