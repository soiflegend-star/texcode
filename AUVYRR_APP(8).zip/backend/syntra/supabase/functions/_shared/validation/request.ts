// =============================================================================
// Request validation & size limits
// =============================================================================

import { AiRouterRequest } from "../types.ts";

export interface ValidationOk {
  ok: true;
  body: AiRouterRequest;
}

export interface ValidationErr {
  ok: false;
  message: string;
}

export type ValidationResult = ValidationOk | ValidationErr;

const MAX_MESSAGES = 50;
const MAX_CONTENT_CHARS = 100_000;
const ALLOWED_ROLES = new Set(["system", "user", "assistant"]);

export function validateAiRequest(
  raw: unknown,
  maxBodyBytes: number,
  bodyByteLength: number,
): ValidationResult {
  if (bodyByteLength > maxBodyBytes) {
    return { ok: false, message: `Request body exceeds ${maxBodyBytes} bytes` };
  }

  if (!raw || typeof raw !== "object") {
    return { ok: false, message: "Request body must be a JSON object" };
  }

  const body = raw as Record<string, unknown>;

  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    return { ok: false, message: "messages array is required and must not be empty" };
  }

  if (body.messages.length > MAX_MESSAGES) {
    return { ok: false, message: `messages must contain at most ${MAX_MESSAGES} items` };
  }

  let totalChars = 0;
  for (const m of body.messages as any[]) {
    if (!m || typeof m !== "object") {
      return { ok: false, message: "Each message must be an object" };
    }
    if (!m.role || !ALLOWED_ROLES.has(m.role)) {
      return { ok: false, message: "Each message role must be system, user, or assistant" };
    }
    if (typeof m.content !== "string" || m.content.length === 0) {
      return { ok: false, message: "Each message must have non-empty string content" };
    }
    totalChars += m.content.length;
  }

  if (totalChars > MAX_CONTENT_CHARS) {
    return { ok: false, message: `Total message content exceeds ${MAX_CONTENT_CHARS} characters` };
  }

  if (body.temperature != null && (typeof body.temperature !== "number" || body.temperature < 0 || body.temperature > 2)) {
    return { ok: false, message: "temperature must be a number between 0 and 2" };
  }

  if (body.max_tokens != null && (typeof body.max_tokens !== "number" || body.max_tokens < 1 || body.max_tokens > 128000)) {
    return { ok: false, message: "max_tokens must be a positive number" };
  }

  return {
    ok: true,
    body: {
      provider: typeof body.provider === "string" ? body.provider : undefined,
      model: typeof body.model === "string" ? body.model : undefined,
      messages: body.messages as AiRouterRequest["messages"],
      temperature: body.temperature as number | undefined,
      max_tokens: body.max_tokens as number | undefined,
      request_id: typeof body.request_id === "string" ? body.request_id : undefined,
      stream: body.stream === true,
    },
  };
}
