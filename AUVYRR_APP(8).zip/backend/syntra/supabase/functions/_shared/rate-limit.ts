// =============================================================================
// Rate limiting (per-user, per-app, daily + sliding window)
// v2.1: RPD enforced via RPC return value (-1 = blocked); atomic total_requests
// =============================================================================

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { AuthContext } from "./types.ts";
import { rateLimited } from "./errors.ts";

/**
 * Check RPM, then atomically increment daily usage (capped at rateLimitRpd)
 * and total_requests. Returns RATE_LIMITED response if over limit, else null.
 *
 * syntra_increment_usage returns:
 *   - new request_count after successful increment, or
 *   - -1 if the daily limit was already reached (no increment performed)
 */
export async function checkAndRecordUsage(
  service: SupabaseClient,
  ctx: AuthContext,
  requestId: string,
): Promise<Response | null> {
  const today = new Date().toISOString().slice(0, 10);

  // --- RPM via recent request_logs ---
  const oneMinuteAgo = new Date(Date.now() - 60_000).toISOString();
  const { count: recentCount } = await service
    .from("syntra_request_logs")
    .select("id", { count: "exact", head: true })
    .eq("user_id", ctx.syntraUserId)
    .gte("created_at", oneMinuteAgo);

  if ((recentCount ?? 0) >= ctx.rateLimitRpm) {
    return rateLimited(
      `Rate limit exceeded: maximum ${ctx.rateLimitRpm} requests per minute`,
      60,
      requestId,
    );
  }

  // --- RPD via atomic RPC ---
  const rpd = ctx.rateLimitRpd > 0 ? ctx.rateLimitRpd : null;

  const { data: newCount, error: rpcErr } = await service.rpc("syntra_increment_usage", {
    p_user_id: ctx.syntraUserId,
    p_app_id: ctx.appId,
    p_day: today,
    p_max: rpd,
  });

  if (rpcErr) {
    const limited = await fallbackIncrementAndCheck(service, ctx, today, requestId);
    if (limited) return limited;
  } else {
    const count = typeof newCount === "number" ? newCount : Number(newCount);
    if (count === -1 || Number.isNaN(count)) {
      return rateLimited(
        `Daily rate limit exceeded: maximum ${ctx.rateLimitRpd} requests per day`,
        3600,
        requestId,
      );
    }
  }

  // --- Atomic lifetime counter ---
  const { error: totalErr } = await service.rpc("syntra_increment_total_requests", {
    p_user_id: ctx.syntraUserId,
  });
  if (totalErr) {
    // Best-effort fallback
    await fallbackIncrementTotal(service, ctx.syntraUserId);
  }

  return null;
}

async function fallbackIncrementAndCheck(
  service: SupabaseClient,
  ctx: AuthContext,
  today: string,
  requestId: string,
): Promise<Response | null> {
  let q = service
    .from("syntra_usage_daily")
    .select("id, request_count")
    .eq("user_id", ctx.syntraUserId)
    .eq("day", today);

  if (ctx.appId) {
    q = q.eq("app_id", ctx.appId);
  } else {
    q = q.is("app_id", null);
  }

  const { data: row } = await q.maybeSingle();

  if (row) {
    if (row.request_count >= ctx.rateLimitRpd) {
      return rateLimited(
        `Daily rate limit exceeded: maximum ${ctx.rateLimitRpd} requests per day`,
        3600,
        requestId,
      );
    }
    await service
      .from("syntra_usage_daily")
      .update({ request_count: row.request_count + 1 })
      .eq("id", row.id)
      .eq("request_count", row.request_count);
  } else {
    await service.from("syntra_usage_daily").insert({
      user_id: ctx.syntraUserId,
      app_id: ctx.appId,
      day: today,
      request_count: 1,
    });
  }
  return null;
}

async function fallbackIncrementTotal(
  service: SupabaseClient,
  userId: string,
): Promise<void> {
  const { data: user } = await service
    .from("syntra_users")
    .select("total_requests")
    .eq("id", userId)
    .maybeSingle();
  if (user) {
    await service
      .from("syntra_users")
      .update({ total_requests: (user.total_requests ?? 0) + 1 })
      .eq("id", userId);
  }
}

/**
 * Record success / error outcome for usage stats (tokens, success/error counts).
 */
export async function recordOutcome(
  service: SupabaseClient,
  ctx: AuthContext,
  success: boolean,
  tokensIn = 0,
  tokensOut = 0,
): Promise<void> {
  const today = new Date().toISOString().slice(0, 10);
  let q = service
    .from("syntra_usage_daily")
    .select("id, success_count, error_count, tokens_in, tokens_out")
    .eq("user_id", ctx.syntraUserId)
    .eq("day", today);

  if (ctx.appId) {
    q = q.eq("app_id", ctx.appId);
  } else {
    q = q.is("app_id", null);
  }

  const { data: row } = await q.maybeSingle();
  if (row) {
    await service
      .from("syntra_usage_daily")
      .update({
        success_count: success ? row.success_count + 1 : row.success_count,
        error_count: success ? row.error_count : row.error_count + 1,
        tokens_in: row.tokens_in + tokensIn,
        tokens_out: row.tokens_out + tokensOut,
      })
      .eq("id", row.id);
  }
}
