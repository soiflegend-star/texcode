// =============================================================================
// Authentication & identity binding
// =============================================================================

import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { AuthContext } from "./types.ts";
import { unauthorized, forbidden, invalidRequest } from "./errors.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

export function createServiceClient(): SupabaseClient {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error("Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY");
  }
  return createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export function createUserClient(authHeader: string): SupabaseClient {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    throw new Error("Missing SUPABASE_URL or SUPABASE_ANON_KEY");
  }
  return createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

/**
 * Validate JWT, resolve or create syntra_users row, bind installation, load app limits.
 * Returns AuthContext or a Response error.
 */
export async function resolveAuthContext(
  req: Request,
): Promise<{ ctx: AuthContext } | { error: Response }> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return { error: unauthorized("Missing or invalid Authorization header") };
  }

  const appKey = req.headers.get("x-auvyrr-app-id") ?? req.headers.get("x-app-id");
  const installationId = req.headers.get("x-installation-id") ?? null;

  const userClient = createUserClient(authHeader);
  const { data: { user }, error: userError } = await userClient.auth.getUser();
  if (userError || !user) {
    return { error: unauthorized("Invalid or expired token") };
  }

  const service = createServiceClient();

  // Resolve / create syntra_users
  let { data: syntraUser, error: suError } = await service
    .from("syntra_users")
    .select("id, is_blocked, total_requests")
    .eq("auth_user_id", user.id)
    .maybeSingle();

  if (suError) {
    console.error("syntra_users lookup failed", suError.message);
    return { error: unauthorized("Identity resolution failed") };
  }

  if (!syntraUser) {
    const { data: created, error: createErr } = await service
      .from("syntra_users")
      .insert({ auth_user_id: user.id, display_name: user.email ?? null })
      .select("id, is_blocked, total_requests")
      .single();
    if (createErr || !created) {
      console.error("syntra_users create failed", createErr?.message);
      return { error: unauthorized("Could not create user record") };
    }
    syntraUser = created;
  }

  if (syntraUser.is_blocked) {
    return { error: forbidden("Account is blocked") };
  }

  // Resolve application
  let appId: string | null = null;
  let rateLimitRpm = 60;
  let rateLimitRpd = 1000;
  let resolvedAppKey: string | null = appKey ?? null;

  if (appKey) {
    const { data: app } = await service
      .from("syntra_applications")
      .select("id, is_enabled, rate_limit_rpm, rate_limit_rpd")
      .eq("app_key", appKey)
      .maybeSingle();
    if (!app || !app.is_enabled) {
      return { error: invalidRequest(`Unknown or disabled application: ${appKey}`) };
    }
    appId = app.id;
    rateLimitRpm = app.rate_limit_rpm;
    rateLimitRpd = app.rate_limit_rpd;
  }

  // Bind installation (non-secret identifier)
  if (installationId && installationId.length > 0 && installationId.length < 256) {
    await service.from("syntra_installations").upsert(
      {
        user_id: syntraUser.id,
        installation_id: installationId,
        platform: req.headers.get("x-platform") ?? "android",
        app_version: req.headers.get("x-app-version") ?? null,
        last_seen_at: new Date().toISOString(),
        is_revoked: false,
      },
      { onConflict: "user_id,installation_id" },
    );

    // Check revocation
    const { data: inst } = await service
      .from("syntra_installations")
      .select("is_revoked")
      .eq("user_id", syntraUser.id)
      .eq("installation_id", installationId)
      .maybeSingle();
    if (inst?.is_revoked) {
      return { error: forbidden("Installation has been revoked") };
    }
  }

  return {
    ctx: {
      authUserId: user.id,
      syntraUserId: syntraUser.id,
      appId,
      appKey: resolvedAppKey,
      installationId,
      rateLimitRpm,
      rateLimitRpd,
    },
  };
}

/**
 * Simple admin check via shared secret header (set as Edge Function secret ADMIN_API_KEY).
 * Never embed this in the APK.
 */
export function requireAdmin(req: Request): { ok: true } | { error: Response } {
  const adminKey = Deno.env.get("ADMIN_API_KEY");
  if (!adminKey) {
    return { error: unauthorized("Admin access is not configured") };
  }
  const provided = req.headers.get("x-admin-key") ?? req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!provided || provided !== adminKey) {
    return { error: unauthorized("Invalid admin credentials") };
  }
  return { ok: true };
}
