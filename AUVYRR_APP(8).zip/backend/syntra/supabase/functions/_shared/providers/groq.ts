// Backward-compatible re-export of the modular Groq adapter
export { callGroq, groqAdapter } from "../../providers/groq/index.ts";
