// =============================================================================
// Permission checks — server-side only
// key_monitor_access is denied by default until granted via SQL
// =============================================================================

import { SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

export const PERMISSION_KEY_MONITOR = "key_monitor_access";

/**
 * Returns true only if the auth user has an active, non-revoked permission row.
 */
export async function hasPermission(
  service: SupabaseClient,
  authUserId: string,
  permission: string,
): Promise<boolean> {
  const { data, error } = await service.rpc("syntra_has_permission", {
    p_auth_user_id: authUserId,
    p_permission: permission,
  });

  if (!error && typeof data === "boolean") return data;

  // Fallback direct query if RPC missing (pre-migration)
  const { data: row } = await service
    .from("syntra_user_permissions")
    .select("id")
    .eq("auth_user_id", authUserId)
    .eq("permission", permission)
    .eq("is_active", true)
    .is("revoked_at", null)
    .maybeSingle();

  return !!row;
}

export async function requireKeyMonitorAccess(
  service: SupabaseClient,
  authUserId: string,
): Promise<boolean> {
  return hasPermission(service, authUserId, PERMISSION_KEY_MONITOR);
}
