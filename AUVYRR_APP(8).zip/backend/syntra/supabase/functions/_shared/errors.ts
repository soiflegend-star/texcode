// =============================================================================
// Consistent error responses — never leak secrets or stack traces
// =============================================================================

import { ErrorCode, SyntraErrorBody } from "./types.ts";

export function jsonError(
  code: ErrorCode,
  message: string,
  status: number,
  extras?: { request_id?: string; retry_after_seconds?: number },
): Response {
  const body: SyntraErrorBody = {
    error: {
      code,
      message,
      ...(extras?.request_id ? { request_id: extras.request_id } : {}),
      ...(extras?.retry_after_seconds != null
        ? { retry_after_seconds: extras.retry_after_seconds }
        : {}),
    },
  };

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };
  if (extras?.retry_after_seconds != null) {
    headers["Retry-After"] = String(extras.retry_after_seconds);
  }

  return new Response(JSON.stringify(body), { status, headers });
}

export function unauthorized(message = "Authentication required", requestId?: string) {
  return jsonError("UNAUTHORIZED", message, 401, { request_id: requestId });
}

export function invalidRequest(message: string, requestId?: string) {
  return jsonError("INVALID_REQUEST", message, 400, { request_id: requestId });
}

export function rateLimited(message: string, retryAfterSeconds: number, requestId?: string) {
  return jsonError("RATE_LIMITED", message, 429, {
    request_id: requestId,
    retry_after_seconds: retryAfterSeconds,
  });
}

export function providerUnavailable(message: string, requestId?: string) {
  return jsonError("PROVIDER_UNAVAILABLE", message, 503, { request_id: requestId });
}

export function temporaryUnavailable(message: string, retryAfterSeconds?: number, requestId?: string) {
  return jsonError("TEMPORARY_SERVICE_UNAVAILABLE", message, 503, {
    request_id: requestId,
    retry_after_seconds: retryAfterSeconds,
  });
}

export function internalError(message = "An internal error occurred", requestId?: string) {
  return jsonError("INTERNAL_SERVER_ERROR", message, 500, { request_id: requestId });
}

export function forbidden(message = "Forbidden", requestId?: string) {
  return jsonError("FORBIDDEN", message, 403, { request_id: requestId });
}
