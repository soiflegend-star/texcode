// =============================================================================
// SYNTRA shared types
// =============================================================================

export type HealthStatus = "healthy" | "degraded" | "unhealthy" | "unknown";

export type ErrorCode =
  | "UNAUTHORIZED"
  | "INVALID_REQUEST"
  | "RATE_LIMITED"
  | "PROVIDER_UNAVAILABLE"
  | "TEMPORARY_SERVICE_UNAVAILABLE"
  | "INTERNAL_SERVER_ERROR"
  | "QUOTA_EXHAUSTED"
  | "FORBIDDEN";

export interface SyntraErrorBody {
  error: {
    code: ErrorCode;
    message: string;
    request_id?: string;
    retry_after_seconds?: number;
  };
}

export interface AiRouterRequest {
  model?: string;
  provider?: string;
  messages: Array<{
    role: "system" | "user" | "assistant";
    content: string;
  }>;
  temperature?: number;
  max_tokens?: number;
  stream?: boolean;
  // Client-supplied request id (optional, we generate one if missing)
  request_id?: string;
}

export interface AiRouterResponse {
  request_id: string;
  provider: string;
  model: string;
  choices: Array<{
    index: number;
    message: {
      role: string;
      content: string;
    };
    finish_reason: string | null;
  }>;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
  created: number;
}

export interface CredentialRow {
  id: string;
  account_id: string;
  credential_key: string;
  secret_ref: string;
  is_enabled: boolean;
  health_status: HealthStatus;
  concurrency_limit: number;
  in_flight_count: number;
  last_success_at: string | null;
  last_error_at: string | null;
  last_error_message: string | null;
  priority: number;
  // joined
  account_is_enabled?: boolean;
  quota_exhausted_until?: string | null;
  provider_code?: string;
  provider_base_url?: string;
  provider_is_enabled?: boolean;
}

export interface AuthContext {
  authUserId: string;
  syntraUserId: string;
  appId: string | null;
  appKey: string | null;
  installationId: string | null;
  rateLimitRpm: number;
  rateLimitRpd: number;
}
