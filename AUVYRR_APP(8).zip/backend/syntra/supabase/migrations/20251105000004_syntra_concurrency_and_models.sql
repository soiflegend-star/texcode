-- =============================================================================
-- Atomic concurrency helpers + models + routing policies + circuit state
-- Additive — does not drop or rewrite existing tables.
-- =============================================================================

-- Atomic acquire: returns true only if slot was available and taken
CREATE OR REPLACE FUNCTION syntra_acquire_slot(p_credential_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  updated INTEGER;
BEGIN
  UPDATE syntra_credentials
  SET in_flight_count = in_flight_count + 1,
      updated_at = now()
  WHERE id = p_credential_id
    AND is_enabled = true
    AND in_flight_count < concurrency_limit
  RETURNING 1 INTO updated;

  RETURN updated IS NOT NULL;
END;
$$;

REVOKE ALL ON FUNCTION syntra_acquire_slot(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION syntra_acquire_slot(UUID) TO service_role;

-- Atomic release: never below zero
CREATE OR REPLACE FUNCTION syntra_release_slot(p_credential_id UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE syntra_credentials
  SET in_flight_count = GREATEST(0, in_flight_count - 1),
      updated_at = now()
  WHERE id = p_credential_id;
END;
$$;

REVOKE ALL ON FUNCTION syntra_release_slot(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION syntra_release_slot(UUID) TO service_role;

-- -----------------------------------------------------------------------------
-- Model catalog (optional guidance for clients; not a hard restriction)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS syntra_models (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider_id     UUID NOT NULL REFERENCES syntra_providers(id) ON DELETE CASCADE,
    model_code      TEXT NOT NULL,
    display_name    TEXT NOT NULL,
    is_enabled      BOOLEAN NOT NULL DEFAULT true,
    max_tokens      INTEGER,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(provider_id, model_code)
);

CREATE INDEX IF NOT EXISTS idx_syntra_models_provider ON syntra_models(provider_id);

-- Seed common Groq models
INSERT INTO syntra_models (provider_id, model_code, display_name, max_tokens)
SELECT p.id, m.code, m.name, m.mt
FROM syntra_providers p
CROSS JOIN (VALUES
    ('llama-3.1-8b-instant', 'Llama 3.1 8B Instant', 8192),
    ('llama-3.3-70b-versatile', 'Llama 3.3 70B Versatile', 32768),
    ('mixtral-8x7b-32768', 'Mixtral 8x7B', 32768)
) AS m(code, name, mt)
WHERE p.code = 'groq'
ON CONFLICT (provider_id, model_code) DO NOTHING;

-- -----------------------------------------------------------------------------
-- Routing policies (configurable selection behaviour)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS syntra_routing_policies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT NOT NULL UNIQUE,
    provider_code   TEXT,
    selection_mode  TEXT NOT NULL DEFAULT 'priority'
                    CHECK (selection_mode IN ('priority', 'least_loaded', 'round_robin')),
    max_retries     INTEGER NOT NULL DEFAULT 1,
    timeout_ms      INTEGER NOT NULL DEFAULT 30000,
    is_default      BOOLEAN NOT NULL DEFAULT false,
    is_enabled      BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO syntra_routing_policies (name, provider_code, selection_mode, max_retries, timeout_ms, is_default)
VALUES ('default-groq', 'groq', 'priority', 1, 30000, true)
ON CONFLICT (name) DO NOTHING;

-- -----------------------------------------------------------------------------
-- Circuit-breaker style suspension (temporary credential suspension)
-- -----------------------------------------------------------------------------
ALTER TABLE syntra_credentials
  ADD COLUMN IF NOT EXISTS suspended_until TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_syntra_credentials_suspended
  ON syntra_credentials(suspended_until)
  WHERE suspended_until IS NOT NULL;

-- -----------------------------------------------------------------------------
-- Maintenance mode flag in config
-- -----------------------------------------------------------------------------
INSERT INTO syntra_config (key, value, description) VALUES
    ('maintenance_mode', 'false', 'When true, ai-router returns TEMPORARY_SERVICE_UNAVAILABLE'),
    ('max_request_body_bytes', '1048576', 'Maximum accepted request body size'),
    ('default_retry_attempts', '1', 'Max retries on transient provider failures')
ON CONFLICT (key) DO NOTHING;

-- RLS for new tables (service-role only for models/policies)
ALTER TABLE syntra_models ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_routing_policies ENABLE ROW LEVEL SECURITY;

CREATE POLICY syntra_models_select_authenticated
    ON syntra_models FOR SELECT
    TO authenticated
    USING (is_enabled = true);

-- No write policies for authenticated on models/policies
