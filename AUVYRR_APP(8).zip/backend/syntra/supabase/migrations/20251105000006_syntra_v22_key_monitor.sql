-- =============================================================================
-- SYNTRA v2.2 — Key monitor access control
-- Additive only. Does not rewrite prior migrations.
--
-- Permission: key_monitor_access
-- - Disabled by default for every profile
-- - Granted/revoked only via administrator SQL (or service-role)
-- - Linked to auth.users.id (Supabase Auth UUID)
-- - Ordinary users cannot grant or modify permissions
-- =============================================================================

CREATE TABLE IF NOT EXISTS syntra_user_permissions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auth_user_id    UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    permission      TEXT NOT NULL,
    granted_by      TEXT,                          -- admin note / actor label (not a secret)
    granted_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at      TIMESTAMPTZ,
    is_active       BOOLEAN NOT NULL DEFAULT true,
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (auth_user_id, permission)
);

CREATE INDEX IF NOT EXISTS idx_syntra_user_permissions_auth
    ON syntra_user_permissions(auth_user_id);

CREATE INDEX IF NOT EXISTS idx_syntra_user_permissions_active
    ON syntra_user_permissions(permission, is_active)
    WHERE is_active = true AND revoked_at IS NULL;

ALTER TABLE syntra_user_permissions ENABLE ROW LEVEL SECURITY;

-- Authenticated users may only read their OWN active permissions
CREATE POLICY syntra_user_permissions_select_own
    ON syntra_user_permissions FOR SELECT
    TO authenticated
    USING (auth_user_id = auth.uid());

-- No INSERT / UPDATE / DELETE policies for authenticated
-- → only service_role (and SQL as postgres/admin) can grant or revoke

-- -----------------------------------------------------------------------------
-- Helper: check whether a user currently has a permission
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION syntra_has_permission(
    p_auth_user_id UUID,
    p_permission TEXT
)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM syntra_user_permissions
        WHERE auth_user_id = p_auth_user_id
          AND permission = p_permission
          AND is_active = true
          AND revoked_at IS NULL
    );
$$;

REVOKE ALL ON FUNCTION syntra_has_permission(UUID, TEXT) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION syntra_has_permission(UUID, TEXT) TO service_role;
GRANT EXECUTE ON FUNCTION syntra_has_permission(UUID, TEXT) TO authenticated;

-- -----------------------------------------------------------------------------
-- Audit permission changes (uses existing syntra_audit_logs)
-- Grant example (run as project admin / service role in SQL editor):
--
--   INSERT INTO syntra_user_permissions (auth_user_id, permission, granted_by, notes)
--   VALUES ('00000000-0000-0000-0000-000000000000', 'key_monitor_access', 'sql-admin', 'ops access')
--   ON CONFLICT (auth_user_id, permission)
--   DO UPDATE SET is_active = true, revoked_at = NULL, granted_at = now(),
--                 granted_by = EXCLUDED.granted_by, notes = EXCLUDED.notes,
--                 updated_at = now();
--
-- Revoke:
--   UPDATE syntra_user_permissions
--   SET is_active = false, revoked_at = now(), updated_at = now()
--   WHERE auth_user_id = '00000000-0000-0000-0000-000000000000'
--     AND permission = 'key_monitor_access';
--
-- List who has access:
--   SELECT auth_user_id, granted_at, granted_by, notes
--   FROM syntra_user_permissions
--   WHERE permission = 'key_monitor_access' AND is_active = true AND revoked_at IS NULL;
-- -----------------------------------------------------------------------------
