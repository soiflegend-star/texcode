-- =============================================================================
-- SYNTRA v2.1 — Reliability & database integrity patch
-- Additive only. Does not rewrite prior migrations.
--
-- Fixes:
--   1. Atomic usage increment that RETURNS new count, or -1 if daily limit hit
--   2. Atomic total_requests increment on syntra_users
--   3. NULL-safe uniqueness on syntra_usage_daily (user_id, app_id, day)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. Deduplicate existing daily usage rows where app_id IS NULL
-- -----------------------------------------------------------------------------
DO $$
DECLARE
  r RECORD;
  survivor UUID;
  total_req INTEGER;
  total_ok INTEGER;
  total_err INTEGER;
  total_in BIGINT;
  total_out BIGINT;
BEGIN
  FOR r IN
    SELECT user_id, day
    FROM syntra_usage_daily
    WHERE app_id IS NULL
    GROUP BY user_id, day
    HAVING COUNT(*) > 1
  LOOP
    SELECT id INTO survivor
    FROM syntra_usage_daily
    WHERE user_id = r.user_id AND day = r.day AND app_id IS NULL
    ORDER BY request_count DESC, id ASC
    LIMIT 1;

    SELECT
      COALESCE(SUM(request_count), 0),
      COALESCE(SUM(success_count), 0),
      COALESCE(SUM(error_count), 0),
      COALESCE(SUM(tokens_in), 0),
      COALESCE(SUM(tokens_out), 0)
    INTO total_req, total_ok, total_err, total_in, total_out
    FROM syntra_usage_daily
    WHERE user_id = r.user_id AND day = r.day AND app_id IS NULL;

    UPDATE syntra_usage_daily
    SET request_count = total_req,
        success_count = total_ok,
        error_count = total_err,
        tokens_in = total_in,
        tokens_out = total_out
    WHERE id = survivor;

    DELETE FROM syntra_usage_daily
    WHERE user_id = r.user_id
      AND day = r.day
      AND app_id IS NULL
      AND id <> survivor;
  END LOOP;
END $$;

-- -----------------------------------------------------------------------------
-- 2. Replace UNIQUE with NULLS NOT DISTINCT (PostgreSQL 15+)
-- -----------------------------------------------------------------------------
DO $$
DECLARE
  cname TEXT;
BEGIN
  FOR cname IN
    SELECT c.conname
    FROM pg_constraint c
    JOIN pg_class t ON c.conrelid = t.oid
    WHERE t.relname = 'syntra_usage_daily'
      AND c.contype = 'u'
      AND pg_get_constraintdef(c.oid) ILIKE '%user_id%'
      AND pg_get_constraintdef(c.oid) ILIKE '%app_id%'
      AND pg_get_constraintdef(c.oid) ILIKE '%day%'
  LOOP
    EXECUTE format('ALTER TABLE syntra_usage_daily DROP CONSTRAINT %I', cname);
  END LOOP;
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Constraint drop note: %', SQLERRM;
END $$;

ALTER TABLE syntra_usage_daily
  DROP CONSTRAINT IF EXISTS syntra_usage_daily_user_id_app_id_day_key;

ALTER TABLE syntra_usage_daily
  DROP CONSTRAINT IF EXISTS syntra_usage_daily_user_app_day_uidx;

ALTER TABLE syntra_usage_daily
  ADD CONSTRAINT syntra_usage_daily_user_app_day_uidx
  UNIQUE NULLS NOT DISTINCT (user_id, app_id, day);

-- -----------------------------------------------------------------------------
-- 3. syntra_increment_usage — returns new count, or -1 if blocked by p_max
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION syntra_increment_usage(
    p_user_id UUID,
    p_app_id UUID,
    p_day DATE,
    p_max INTEGER DEFAULT NULL
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_count INTEGER;
  new_count INTEGER;
BEGIN
  -- Lock / upsert path
  INSERT INTO syntra_usage_daily (user_id, app_id, day, request_count)
  VALUES (p_user_id, p_app_id, p_day, 0)
  ON CONFLICT (user_id, app_id, day)
  DO NOTHING;

  SELECT request_count INTO current_count
  FROM syntra_usage_daily
  WHERE user_id = p_user_id
    AND day = p_day
    AND app_id IS NOT DISTINCT FROM p_app_id
  FOR UPDATE;

  IF p_max IS NOT NULL AND p_max > 0 AND current_count >= p_max THEN
    RETURN -1;  -- blocked: already at or over daily limit
  END IF;

  UPDATE syntra_usage_daily
  SET request_count = request_count + 1
  WHERE user_id = p_user_id
    AND day = p_day
    AND app_id IS NOT DISTINCT FROM p_app_id
  RETURNING request_count INTO new_count;

  RETURN new_count;
END;
$$;

REVOKE ALL ON FUNCTION syntra_increment_usage(UUID, UUID, DATE, INTEGER) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION syntra_increment_usage(UUID, UUID, DATE, INTEGER) TO service_role;

-- 3-arg wrapper (unlimited) for compatibility
CREATE OR REPLACE FUNCTION syntra_increment_usage(
    p_user_id UUID,
    p_app_id UUID,
    p_day DATE
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN syntra_increment_usage(p_user_id, p_app_id, p_day, NULL);
END;
$$;

REVOKE ALL ON FUNCTION syntra_increment_usage(UUID, UUID, DATE) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION syntra_increment_usage(UUID, UUID, DATE) TO service_role;

-- -----------------------------------------------------------------------------
-- 4. Atomic total_requests increment
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION syntra_increment_total_requests(p_user_id UUID)
RETURNS BIGINT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_total BIGINT;
BEGIN
  UPDATE syntra_users
  SET total_requests = total_requests + 1,
      updated_at = now()
  WHERE id = p_user_id
  RETURNING total_requests INTO new_total;

  RETURN COALESCE(new_total, 0);
END;
$$;

REVOKE ALL ON FUNCTION syntra_increment_total_requests(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION syntra_increment_total_requests(UUID) TO service_role;
