-- =============================================================================
-- Helper functions used by Edge Functions
-- =============================================================================

-- Atomic daily usage increment (avoids race conditions)
CREATE OR REPLACE FUNCTION syntra_increment_usage(
    p_user_id UUID,
    p_app_id UUID,
    p_day DATE
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    INSERT INTO syntra_usage_daily (user_id, app_id, day, request_count)
    VALUES (p_user_id, p_app_id, p_day, 1)
    ON CONFLICT (user_id, app_id, day)
    DO UPDATE SET request_count = syntra_usage_daily.request_count + 1;
END;
$$;

-- Allow service role (and authenticated via function) to call it
REVOKE ALL ON FUNCTION syntra_increment_usage(UUID, UUID, DATE) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION syntra_increment_usage(UUID, UUID, DATE) TO service_role;
