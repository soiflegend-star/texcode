-- =============================================================================
-- SYNTRA Row Level Security
-- Ordinary users cannot read/modify credentials, admin records, or other users' data.
-- Sensitive operations are performed exclusively by Edge Functions using the
-- service role (which bypasses RLS).
-- =============================================================================

ALTER TABLE syntra_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_installations ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_provider_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_usage_daily ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_request_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_error_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE syntra_config ENABLE ROW LEVEL SECURITY;

-- -----------------------------------------------------------------------------
-- Helper: current authenticated user id
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION syntra_current_auth_uid()
RETURNS UUID AS $$
    SELECT auth.uid();
$$ LANGUAGE sql STABLE;

-- -----------------------------------------------------------------------------
-- Applications: readable by authenticated users (public metadata only)
-- -----------------------------------------------------------------------------
CREATE POLICY syntra_apps_select_authenticated
    ON syntra_applications FOR SELECT
    TO authenticated
    USING (is_enabled = true);

-- No insert/update/delete for ordinary users

-- -----------------------------------------------------------------------------
-- Users: a user can only see / update their own row
-- -----------------------------------------------------------------------------
CREATE POLICY syntra_users_select_own
    ON syntra_users FOR SELECT
    TO authenticated
    USING (auth_user_id = auth.uid());

CREATE POLICY syntra_users_update_own
    ON syntra_users FOR UPDATE
    TO authenticated
    USING (auth_user_id = auth.uid())
    WITH CHECK (auth_user_id = auth.uid());

-- Inserts happen via service role from Edge Functions

-- -----------------------------------------------------------------------------
-- Installations: owner only
-- -----------------------------------------------------------------------------
CREATE POLICY syntra_installations_select_own
    ON syntra_installations FOR SELECT
    TO authenticated
    USING (
        user_id IN (SELECT id FROM syntra_users WHERE auth_user_id = auth.uid())
    );

CREATE POLICY syntra_installations_insert_own
    ON syntra_installations FOR INSERT
    TO authenticated
    WITH CHECK (
        user_id IN (SELECT id FROM syntra_users WHERE auth_user_id = auth.uid())
    );

CREATE POLICY syntra_installations_update_own
    ON syntra_installations FOR UPDATE
    TO authenticated
    USING (
        user_id IN (SELECT id FROM syntra_users WHERE auth_user_id = auth.uid())
    );

-- -----------------------------------------------------------------------------
-- Providers: public read of enabled providers
-- -----------------------------------------------------------------------------
CREATE POLICY syntra_providers_select_enabled
    ON syntra_providers FOR SELECT
    TO authenticated
    USING (is_enabled = true);

-- Accounts & credentials: NO policies for authenticated → fully locked to service role
-- (service role bypasses RLS)

-- -----------------------------------------------------------------------------
-- Usage: own records only
-- -----------------------------------------------------------------------------
CREATE POLICY syntra_usage_select_own
    ON syntra_usage_daily FOR SELECT
    TO authenticated
    USING (
        user_id IN (SELECT id FROM syntra_users WHERE auth_user_id = auth.uid())
    );

-- -----------------------------------------------------------------------------
-- Request logs: own records only
-- -----------------------------------------------------------------------------
CREATE POLICY syntra_request_logs_select_own
    ON syntra_request_logs FOR SELECT
    TO authenticated
    USING (
        user_id IN (SELECT id FROM syntra_users WHERE auth_user_id = auth.uid())
    );

-- Error records, audit logs, config: no client access
-- (service role only)

-- -----------------------------------------------------------------------------
-- Explicit deny for credential tables (documentation)
-- -----------------------------------------------------------------------------
-- No policies exist for:
--   syntra_provider_accounts
--   syntra_credentials
--   syntra_error_records
--   syntra_audit_logs
--   syntra_config
-- Therefore only the service role can touch them.
