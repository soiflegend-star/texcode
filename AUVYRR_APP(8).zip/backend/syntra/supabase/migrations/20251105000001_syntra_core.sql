-- =============================================================================
-- SYNTRA Core Schema
-- Isolated tables for the AUVYRR backend headquarters.
-- Never store raw provider API keys here — only secret references + metadata.
-- =============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -----------------------------------------------------------------------------
-- 1. Registered applications (AUVYRR apps that may call SYNTRA)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS syntra_applications (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    app_key         TEXT NOT NULL UNIQUE,          -- e.g. "auvyrr-android-v1"
    display_name    TEXT NOT NULL,
    description     TEXT,
    is_enabled      BOOLEAN NOT NULL DEFAULT true,
    rate_limit_rpm  INTEGER NOT NULL DEFAULT 60,   -- requests per minute per user
    rate_limit_rpd  INTEGER NOT NULL DEFAULT 1000, -- requests per day per user
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_syntra_apps_key ON syntra_applications(app_key);

-- -----------------------------------------------------------------------------
-- 2. Users / installations (bound to Supabase Auth users)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS syntra_users (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    auth_user_id      UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
    primary_app_id    UUID REFERENCES syntra_applications(id),
    display_name      TEXT,
    is_blocked        BOOLEAN NOT NULL DEFAULT false,
    total_requests    BIGINT NOT NULL DEFAULT 0,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_syntra_users_auth ON syntra_users(auth_user_id);

CREATE TABLE IF NOT EXISTS syntra_installations (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID NOT NULL REFERENCES syntra_users(id) ON DELETE CASCADE,
    installation_id   TEXT NOT NULL,               -- client-generated, not secret
    platform          TEXT,                        -- android, ios, web
    app_version       TEXT,
    last_seen_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    is_revoked        BOOLEAN NOT NULL DEFAULT false,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(user_id, installation_id)
);

CREATE INDEX IF NOT EXISTS idx_syntra_installations_user ON syntra_installations(user_id);
CREATE INDEX IF NOT EXISTS idx_syntra_installations_id ON syntra_installations(installation_id);

-- -----------------------------------------------------------------------------
-- 3. Providers → Accounts → Credentials (metadata only)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS syntra_providers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            TEXT NOT NULL UNIQUE,          -- "groq", "openai", ...
    display_name    TEXT NOT NULL,
    base_url        TEXT NOT NULL,
    is_enabled      BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS syntra_provider_accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider_id     UUID NOT NULL REFERENCES syntra_providers(id) ON DELETE CASCADE,
    account_label   TEXT NOT NULL,                 -- human-readable label
    is_enabled      BOOLEAN NOT NULL DEFAULT true,
    quota_exhausted_until TIMESTAMPTZ,             -- set when 429 indicates account quota
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(provider_id, account_label)
);

CREATE INDEX IF NOT EXISTS idx_syntra_provider_accounts_provider ON syntra_provider_accounts(provider_id);

CREATE TABLE IF NOT EXISTS syntra_credentials (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id          UUID NOT NULL REFERENCES syntra_provider_accounts(id) ON DELETE CASCADE,
    credential_key      TEXT NOT NULL UNIQUE,      -- stable identifier e.g. "groq-main-1"
    secret_ref          TEXT NOT NULL,             -- name of the Edge Function secret that holds the real key
    is_enabled          BOOLEAN NOT NULL DEFAULT true,
    health_status       TEXT NOT NULL DEFAULT 'unknown'
                        CHECK (health_status IN ('healthy', 'degraded', 'unhealthy', 'unknown')),
    concurrency_limit   INTEGER NOT NULL DEFAULT 5,
    in_flight_count     INTEGER NOT NULL DEFAULT 0 CHECK (in_flight_count >= 0),
    last_success_at     TIMESTAMPTZ,
    last_error_at       TIMESTAMPTZ,
    last_error_message  TEXT,
    last_health_check_at TIMESTAMPTZ,
    priority            INTEGER NOT NULL DEFAULT 100, -- lower = preferred
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_syntra_credentials_account ON syntra_credentials(account_id);
CREATE INDEX IF NOT EXISTS idx_syntra_credentials_enabled ON syntra_credentials(is_enabled, health_status);
CREATE INDEX IF NOT EXISTS idx_syntra_credentials_priority ON syntra_credentials(priority);

-- -----------------------------------------------------------------------------
-- 4. Usage, request logs, errors, audit
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS syntra_usage_daily (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES syntra_users(id) ON DELETE CASCADE,
    app_id          UUID REFERENCES syntra_applications(id),
    day             DATE NOT NULL,
    request_count   INTEGER NOT NULL DEFAULT 0,
    success_count   INTEGER NOT NULL DEFAULT 0,
    error_count     INTEGER NOT NULL DEFAULT 0,
    tokens_in       BIGINT NOT NULL DEFAULT 0,
    tokens_out      BIGINT NOT NULL DEFAULT 0,
    UNIQUE(user_id, app_id, day)
);

CREATE INDEX IF NOT EXISTS idx_syntra_usage_daily_user_day ON syntra_usage_daily(user_id, day);

CREATE TABLE IF NOT EXISTS syntra_request_logs (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id        TEXT NOT NULL UNIQUE,        -- client or server generated UUID
    user_id           UUID REFERENCES syntra_users(id),
    app_id            UUID REFERENCES syntra_applications(id),
    installation_id   TEXT,
    provider_code     TEXT,
    model             TEXT,
    credential_id     UUID REFERENCES syntra_credentials(id),
    status            TEXT NOT NULL,               -- success | error | rate_limited | ...
    http_status       INTEGER,
    duration_ms       INTEGER,
    error_code        TEXT,
    error_message     TEXT,                        -- safe, never contains secrets
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_syntra_request_logs_user ON syntra_request_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_syntra_request_logs_created ON syntra_request_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_syntra_request_logs_status ON syntra_request_logs(status);

CREATE TABLE IF NOT EXISTS syntra_error_records (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id        TEXT,
    source            TEXT NOT NULL,               -- router | provider | auth | ...
    error_code        TEXT NOT NULL,
    message           TEXT NOT NULL,
    details           JSONB,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_syntra_error_records_created ON syntra_error_records(created_at DESC);

CREATE TABLE IF NOT EXISTS syntra_audit_logs (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_type        TEXT NOT NULL,               -- admin | system | user
    actor_id          TEXT,
    action            TEXT NOT NULL,
    target_type       TEXT,
    target_id         TEXT,
    payload           JSONB,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_syntra_audit_logs_created ON syntra_audit_logs(created_at DESC);

-- -----------------------------------------------------------------------------
-- 5. Configuration settings
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS syntra_config (
    key               TEXT PRIMARY KEY,
    value             JSONB NOT NULL,
    description       TEXT,
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Seed default config
INSERT INTO syntra_config (key, value, description) VALUES
    ('default_provider', '"groq"', 'Default AI provider code'),
    ('default_model', '"llama-3.1-8b-instant"', 'Default model when none specified'),
    ('max_request_body_bytes', '1048576', '1 MiB max request body'),
    ('provider_timeout_ms', '30000', 'Timeout for upstream provider calls'),
    ('max_retries_transient', '1', 'Max retries on genuine transient failures')
ON CONFLICT (key) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 6. Updated-at trigger helper
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION syntra_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_syntra_apps_updated
    BEFORE UPDATE ON syntra_applications
    FOR EACH ROW EXECUTE FUNCTION syntra_set_updated_at();

CREATE TRIGGER trg_syntra_users_updated
    BEFORE UPDATE ON syntra_users
    FOR EACH ROW EXECUTE FUNCTION syntra_set_updated_at();

CREATE TRIGGER trg_syntra_providers_updated
    BEFORE UPDATE ON syntra_providers
    FOR EACH ROW EXECUTE FUNCTION syntra_set_updated_at();

CREATE TRIGGER trg_syntra_provider_accounts_updated
    BEFORE UPDATE ON syntra_provider_accounts
    FOR EACH ROW EXECUTE FUNCTION syntra_set_updated_at();

CREATE TRIGGER trg_syntra_credentials_updated
    BEFORE UPDATE ON syntra_credentials
    FOR EACH ROW EXECUTE FUNCTION syntra_set_updated_at();

-- -----------------------------------------------------------------------------
-- 7. Seed Groq provider (no real keys)
-- -----------------------------------------------------------------------------
INSERT INTO syntra_providers (code, display_name, base_url)
VALUES ('groq', 'Groq', 'https://api.groq.com/openai/v1')
ON CONFLICT (code) DO NOTHING;
