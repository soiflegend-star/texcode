# SYNTRA Changelog

## 2.0.0 — Infrastructure upgrade (2026-11-05)

### Added
- Formal `ProviderAdapter` interface and registry
- Modular router: selector, concurrency, failover, retry, availability
- Atomic `syntra_acquire_slot` / `syntra_release_slot` SQL functions
- `syntra_models` and `syntra_routing_policies` tables
- Maintenance mode via `syntra_config`
- Request validation module (size, roles, temperature, max_tokens)
- Structured monitoring/logging helpers
- Expanded test suites (unit, routing, security) — 28 tests passing
- Docs: DATABASE, SECURITY, ROUTING, TESTING, CHANGELOG

### Changed
- `ai-router` rewritten to use modular components
- Groq implementation moved under `providers/groq` implementing the interface
- Legacy `_shared/credentials.ts` and `_shared/providers/groq.ts` kept as re-exports

### Preserved
- All existing tables, RLS, admin endpoints, health endpoint
- Android Kotlin client
- Original migrations (additive 4th migration only)

### Security
- Failover never rotates same-account keys to bypass quotas
- Empty secret_ref handled safely
- Error responses remain sanitized

## 2.1.0 — Reliability & database integrity (2026-11-05)

### Fixed
1. **Daily RPD enforcement** — `syntra_increment_usage` now returns the new count or `-1` when the daily limit is reached; `checkAndRecordUsage` enforces RATE_LIMITED on the RPC success path.
2. **Suspended credentials** — selector skips credentials whose `suspended_until` is in the future; new reason `all_suspended`.
3. **total_requests counter** — atomic `syntra_increment_total_requests` RPC; no more no-op update.
4. **NULL app_id uniqueness** — `UNIQUE NULLS NOT DISTINCT (user_id, app_id, day)` with safe dedupe of existing rows.

### Added
- Migration `20251105000005_syntra_v21_reliability.sql` (additive)
- Regression tests in `tests/unit/v21_reliability_test.ts`

### Tests
- 37 passed, 0 failed

## 2.2.0 — Key Monitor & SQL-controlled access (2026-11-05)

### Added
- `syntra_user_permissions` + `syntra_has_permission()` (migration 006)
- Permission `key_monitor_access` (default deny)
- Edge Function `monitor` — overview, providers, credentials, usage, health
- Premium static dashboard (`dashboard/`)
- Docs: `docs/KEY_MONITOR.md` with grant/revoke SQL
- Security tests for monitor access contract

### Security
- JWT + explicit permission required on every monitor request
- Responses never include secrets or secret_ref
- Quota remaining shown as unknown unless provider-reported
- Account-level quota exhaustion (not fake per-key remaining %)
