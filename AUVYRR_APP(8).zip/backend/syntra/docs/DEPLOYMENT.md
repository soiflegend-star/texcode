# SYNTRA Deployment Guide

## Prerequisites

- A Supabase project (free tier is sufficient to start)
- Supabase CLI (`npm i -g supabase`)
- Deno (for local tests)
- Access to create Edge Function secrets

## 1. Link the project

```bash
cd syntra
supabase login
supabase link --project-ref <your-project-ref>
```

## 2. Apply database migrations

```bash
supabase db push
# or, for a fresh local stack:
supabase db reset
```

This creates all `syntra_*` tables, indexes, triggers, and RLS policies.

## 3. Deploy Edge Functions

```bash
supabase functions deploy ai-router
supabase functions deploy admin
supabase functions deploy health
```

## 4. Set secrets (never commit real values)

```bash
# Required for admin endpoints
supabase secrets set ADMIN_API_KEY="$(openssl rand -hex 32)"

# Provider keys — names must match secret_ref you will register
supabase secrets set GROQ_API_KEY_1="gsk_your_real_key"

# Service role is usually injected automatically; if not:
# supabase secrets set SUPABASE_SERVICE_ROLE_KEY="..."
```

Verify:

```bash
supabase secrets list
```

## 5. Seed initial data

### 5.1 Register an application

```bash
curl -X POST "https://<project-ref>.supabase.co/functions/v1/admin/applications" \
  -H "x-admin-key: $ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "app_key": "auvyrr-android-v1",
    "display_name": "AUVYRR Android",
    "rate_limit_rpm": 30,
    "rate_limit_rpd": 500
  }'
```

### 5.2 Create a provider account

```bash
curl -X POST "https://<project-ref>.supabase.co/functions/v1/admin/accounts" \
  -H "x-admin-key: $ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "provider_code": "groq",
    "account_label": "primary"
  }'
```

Note the returned `id` (account_id).

### 5.3 Register credential metadata

```bash
curl -X POST "https://<project-ref>.supabase.co/functions/v1/admin/credentials" \
  -H "x-admin-key: $ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "account_id": "<account-uuid-from-previous-step>",
    "credential_key": "groq-primary-1",
    "secret_ref": "GROQ_API_KEY_1",
    "concurrency_limit": 5,
    "priority": 10
  }'
```

## 6. Smoke test

```bash
# Health
curl "https://<project-ref>.supabase.co/functions/v1/health"

# AI router (requires a real user JWT from your Supabase Auth)
curl -X POST "https://<project-ref>.supabase.co/functions/v1/ai-router" \
  -H "Authorization: Bearer <user-jwt>" \
  -H "x-auvyrr-app-id: auvyrr-android-v1" \
  -H "x-installation-id: test-install-001" \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Say hello in one sentence."}
    ]
  }'
```

## 7. Endpoint AUVYRR will use

```
POST https://<project-ref>.supabase.co/functions/v1/ai-router
```

Replace `<project-ref>` with your actual Supabase project reference.

## Troubleshooting

| Symptom | Likely cause |
|---------|--------------|
| 401 on ai-router | Invalid / missing user JWT |
| 400 "Unknown application" | `x-auvyrr-app-id` not registered |
| 503 "No eligible credential" | No enabled credential, secret missing, or all under concurrency / quota |
| Admin 401 | Wrong or missing `ADMIN_API_KEY` |
| "Secret not configured" | `secret_ref` name does not match an Edge Function secret |

See also `docs/TROUBLESHOOTING.md`.
