# SYNTRA Database

## Tables

| Table | Purpose |
|-------|---------|
| `syntra_applications` | Registered AUVYRR apps + rate limits |
| `syntra_users` | 1:1 with `auth.users` |
| `syntra_installations` | Device bindings (revocable) |
| `syntra_providers` | Provider catalog |
| `syntra_provider_accounts` | Account-level quota state |
| `syntra_credentials` | Credential metadata + concurrency |
| `syntra_models` | Optional model catalog |
| `syntra_routing_policies` | Selection / retry / timeout policies |
| `syntra_usage_daily` | Per-user daily counters |
| `syntra_request_logs` | Per-request audit trail |
| `syntra_error_records` | Structured errors |
| `syntra_audit_logs` | Admin action history |
| `syntra_config` | Runtime configuration |

## Hierarchy

```
Provider
 └── Account
      └── Credential (secret_ref → Edge Secret)
```

## Security

- RLS enabled on all tables.
- Credential / account / audit / config tables have **no** policies for `authenticated` — only service role.
- Users can read their own usage and request logs only.

## Atomic helpers

- `syntra_acquire_slot(uuid)` — compare-and-increment concurrency
- `syntra_release_slot(uuid)` — never below zero
- `syntra_increment_usage(...)` — daily counter upsert

## Migrations

Applied in order:

1. `20251105000001_syntra_core.sql`
2. `20251105000002_syntra_rls.sql`
3. `20251105000003_syntra_helpers.sql`
4. `20251105000004_syntra_concurrency_and_models.sql` (additive)

## v2.1 additions (migration 005)

- `syntra_increment_usage(user, app, day, max)` → INTEGER (−1 if blocked)
- `syntra_increment_total_requests(user)` → BIGINT
- `UNIQUE NULLS NOT DISTINCT (user_id, app_id, day)` on `syntra_usage_daily`
