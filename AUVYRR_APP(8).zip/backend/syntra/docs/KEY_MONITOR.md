# SYNTRA Key Monitor (v2.2)

Premium credential monitoring with **SQL-controlled** profile access.

## Access model

| Rule | Behaviour |
|------|-----------|
| Default | **Denied** for every profile |
| Grant | Administrator SQL only (or service-role) |
| Revoke | Administrator SQL |
| Self-grant | **Impossible** — no client write policies |
| Server check | Every `/monitor/*` request verifies JWT **and** `key_monitor_access` |

Permission name: `key_monitor_access`  
Stored in: `syntra_user_permissions`  
Linked to: `auth.users.id` (Supabase Auth UUID)

## SQL examples

Replace the UUID with the real Auth user id (Authentication → Users in the Supabase dashboard).

### Grant access

```sql
INSERT INTO syntra_user_permissions (auth_user_id, permission, granted_by, notes)
VALUES (
  '00000000-0000-0000-0000-000000000000',  -- auth.users.id
  'key_monitor_access',
  'sql-admin',
  'Operations access'
)
ON CONFLICT (auth_user_id, permission)
DO UPDATE SET
  is_active = true,
  revoked_at = NULL,
  granted_at = now(),
  granted_by = EXCLUDED.granted_by,
  notes = EXCLUDED.notes,
  updated_at = now();
```

### Revoke access

```sql
UPDATE syntra_user_permissions
SET is_active = false,
    revoked_at = now(),
    updated_at = now()
WHERE auth_user_id = '00000000-0000-0000-0000-000000000000'
  AND permission = 'key_monitor_access';
```

### List who has access

```sql
SELECT auth_user_id, granted_at, granted_by, notes
FROM syntra_user_permissions
WHERE permission = 'key_monitor_access'
  AND is_active = true
  AND revoked_at IS NULL;
```

### Check one profile

```sql
SELECT syntra_has_permission(
  '00000000-0000-0000-0000-000000000000',
  'key_monitor_access'
);
```

## API endpoints

Base: `https://<project-ref>.supabase.co/functions/v1/monitor`

| Method | Path | Description |
|--------|------|-------------|
| GET | `/monitor/overview` | Global credential counts |
| GET | `/monitor/providers` | Per-provider summary + local 24h usage |
| GET | `/monitor/credentials` | Masked credential rows |
| GET | `/monitor/usage` | Local SYNTRA usage history |
| GET | `/monitor/health` | Aggregate health |

**Headers:** `Authorization: Bearer <user-jwt>`

**Never returned:** API keys, `secret_ref`, environment secret values.

### Quota honesty

- **Provider-reported remaining quota:** only if a provider exposes it (currently **unknown** for Groq in this implementation).
- **Locally tracked usage:** from `syntra_request_logs` / `syntra_usage_daily`.
- **Account-level exhaustion:** from `quota_exhausted_until` on the **account**, not invented per-key percentages.

## Dashboard UI

Static app under `dashboard/`:

1. Open `dashboard/index.html` in a browser (or host as static files).
2. Enter function base URL and a user JWT that has `key_monitor_access`.
3. View overview, providers, credentials, and local usage.

## Migration

Apply on the **same** Supabase project:

```
20251105000006_syntra_v22_key_monitor.sql
```

Then deploy the `monitor` Edge Function:

```bash
supabase functions deploy monitor
```
