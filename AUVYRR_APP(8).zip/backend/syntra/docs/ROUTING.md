# SYNTRA Routing Engine

## Flow

1. Validate auth + rate limits + body.
2. Resolve provider adapter by code.
3. **Select** eligible credential (`router/selector.ts`):
   - Provider enabled
   - Account enabled
   - Credential enabled
   - Not unhealthy
   - Not under quota cooldown
   - Under concurrency limit
   - Ordered by priority ASC, then in_flight ASC
4. **Acquire** atomic concurrency slot (`syntra_acquire_slot`).
5. Resolve API key from Edge secret via `secret_ref`.
6. Call provider adapter with controlled retry (`router/retry.ts`).
7. On failure → `decideFailover` (`router/failover.ts`) distinguishes:
   - quota_exhausted / rate_limited
   - timeout / network / server_error
   - auth_error
   - invalid_request
   - busy / disabled / no_credential
8. Update health / quota state; release slot; log; return clean response.

## Failure categories are not identical

| Category | Retry same | Try alternate | Mark quota | Mark unhealthy |
|----------|------------|---------------|------------|----------------|
| quota_exhausted | no | no | yes | no |
| timeout / network / 5xx | yes | yes | no | no |
| auth_error | no | yes | no | yes |
| invalid_request | no | no | no | no |
| busy | no | yes | no | no |

## Files

- `supabase/functions/router/selector.ts`
- `supabase/functions/router/concurrency.ts`
- `supabase/functions/router/failover.ts`
- `supabase/functions/router/retry.ts`
- `supabase/functions/router/availability.ts`
- `supabase/functions/providers/provider-interface.ts`
- `supabase/functions/providers/groq/index.ts`
