# SYNTRA Troubleshooting

## Authentication failures (401)

- Confirm the client sends `Authorization: Bearer <valid supabase user JWT>`.
- Token must not be expired.
- Supabase Auth must be the same project that owns the Edge Functions.

## Unknown application (400)

- Register the app via `POST /admin/applications` with the exact `app_key` the client sends in `x-auvyrr-app-id`.

## No eligible credential (503)

Checklist:

1. At least one row in `syntra_credentials` with `is_enabled = true`.
2. Parent `syntra_provider_accounts.is_enabled = true`.
3. Parent `syntra_providers.is_enabled = true` and matching `code`.
4. `health_status` is not `unhealthy`.
5. `in_flight_count < concurrency_limit`.
6. `quota_exhausted_until` is null or in the past.
7. The Edge Function secret named by `secret_ref` exists and is non-empty.

## Secret not configured

The admin endpoint refuses to register a credential whose `secret_ref` is missing from the runtime environment. Add the secret first:

```bash
supabase secrets set GROQ_API_KEY_1="gsk_..."
```

Then re-register the credential metadata.

## Rate limited (429 from SYNTRA)

- Per-app limits live on `syntra_applications.rate_limit_rpm` / `rate_limit_rpd`.
- Check `syntra_usage_daily` and recent `syntra_request_logs` for the user.

## 429 from Groq (propagated as TEMPORARY_SERVICE_UNAVAILABLE)

- SYNTRA records `quota_exhausted_until` on the account.
- Do **not** add more keys from the same account expecting them to bypass the limit.
- Wait for the cooldown or use a different authorized account that has remaining quota.

## Admin 401

- Header must be `x-admin-key: <value of ADMIN_API_KEY secret>`.
- Confirm the secret is set on the same project the function is deployed to.

## Logs contain no API keys

By design. If you ever see a key in logs, treat it as a bug and rotate the key immediately.
