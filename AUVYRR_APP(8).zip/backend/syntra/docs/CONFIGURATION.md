# SYNTRA Configuration Checklist

## Required secrets (Edge Function Secrets)

| Secret name | Purpose |
|-------------|---------|
| `ADMIN_API_KEY` | Protects `/admin/*` endpoints |
| `GROQ_API_KEY_1` (and optionally `_2`, …) | Actual Groq API keys; referenced by `secret_ref` |
| `SUPABASE_SERVICE_ROLE_KEY` | Usually auto-injected; needed for privileged DB ops |

## Required database seed steps

1. Apply migrations.
2. Register at least one application (`app_key` that the Android app will send).
3. Confirm the `groq` provider row exists (seeded by migration).
4. Create a provider account under Groq.
5. Create a credential pointing at an existing secret (`secret_ref = "GROQ_API_KEY_1"`).

## Optional config keys (`syntra_config`)

| Key | Default | Meaning |
|-----|---------|---------|
| `default_provider` | `"groq"` | Used when client omits provider |
| `default_model` | `"llama-3.1-8b-instant"` | Used when client omits model |
| `provider_timeout_ms` | `30000` | Upstream call timeout |
| `max_retries_transient` | `1` | Safe retry count |

## What remains for you to provide

1. A Supabase project (project-ref + access).
2. One or more real Groq API keys (set only as Edge secrets).
3. A strong random `ADMIN_API_KEY`.
4. The decision of which app_key values your AUVYRR clients will use.

After those are in place, follow `docs/DEPLOYMENT.md` to go live.
