# SYNTRA Testing

## How to run

```bash
# Requires Deno
deno test --allow-net --allow-env tests/
```

## Suites

| Suite | Path | Coverage |
|-------|------|----------|
| Legacy + Groq | `tests/ai-router_test.ts` | Error shapes, Groq mock success/429/5xx/timeout |
| Unit – routing decisions | `tests/unit/selector_test.ts` | Failover decisions, backoff |
| Unit – validation | `tests/unit/validation_test.ts` | Request body rules |
| Routing – adapters | `tests/routing/provider_adapter_test.ts` | Registry, success, 429, timeout |
| Security | `tests/security/errors_and_secrets_test.ts` | Sanitized errors, secret resolution |

## Results (last local run)

```
ok | 28 passed | 0 failed
```

## Not covered in CI (requires live Supabase)

- Full JWT auth against a real project
- Live RLS enforcement with real roles
- Live concurrency under multi-instance load

Those require a linked Supabase project and are documented as manual verification steps in DEPLOYMENT.md.
