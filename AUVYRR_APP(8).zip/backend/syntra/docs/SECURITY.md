# SYNTRA Security

## Principles

1. Provider API keys exist only in Edge Function Secrets.
2. Database stores `secret_ref` (secret name), never the key value.
3. Clients never receive provider credentials.
4. Installation IDs are not authentication credentials.
5. Admin operations require `ADMIN_API_KEY` (server-side secret only).
6. Service-role key never ships in any client APK.
7. Error responses are sanitized — no stacks, no secrets.
8. Logs never contain API keys, Authorization headers, or full user prompts.

## Authentication

- Supabase Auth JWT validated on every protected request.
- Application identified via `x-auvyrr-app-id` (must be registered and enabled).
- Installation bound and revocable via `x-installation-id`.

## Authorization / RLS

- Ordinary users: own profile, own usage, own request logs.
- No client access to credentials, accounts, audit logs, or config writes.
- Admin endpoints gated by shared secret header (not embedded in APK).

## Rate limiting

- Per-application RPM and RPD enforced server-side.
- Daily counters stored in `syntra_usage_daily`.

## Request limits

- Configurable max body size (default 1 MiB).
- Message count and total content length caps.

## Provider compliance

- 429 responses set account-level `quota_exhausted_until`.
- Router does **not** rotate keys belonging to the same account to bypass quotas.
- Transient failures may retry once; quota failures do not.
