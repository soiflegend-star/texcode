# SYNTRA Architecture

## High-level flow

```
┌─────────────────┐     JWT + app-id      ┌──────────────────────┐
│  AUVYRR App     │ ───────────────────►  │  SYNTRA Edge Fn      │
│  (Android etc.) │                       │  ai-router           │
└─────────────────┘                       └──────────┬───────────┘
                                                     │
                          ┌──────────────────────────┼──────────────────────────┐
                          │                          │                          │
                          ▼                          ▼                          ▼
                   Auth + identity            Rate limits               Credential
                   (Supabase Auth             (usage_daily +            selection
                    + syntra_users)            request_logs)            (priority +
                                                                        concurrency +
                                                                        health + quota)
                                                     │
                                                     ▼
                                            Resolve secret_ref
                                            from Edge secrets
                                                     │
                                                     ▼
                                            Provider adapter
                                            (Groq OpenAI-compat)
                                                     │
                                                     ▼
                                            Log + return clean
                                            response to client
```

## Design principles

1. **No provider keys in clients** — AUVYRR never sees Groq (or any other) API keys.
2. **Metadata only in PostgreSQL** — actual keys live exclusively in Edge Function Secrets.
3. **Service-role for privileged work** — RLS blocks ordinary users from credentials, audit logs, config.
4. **Deterministic selection** — credentials ordered by priority then in-flight count; no random rotation to bypass quotas.
5. **Respect provider terms** — 429s set account-level `quota_exhausted_until`; no aggressive key spinning.
6. **Modular providers** — new adapters live under `_shared/providers/` and are selected by `provider` code.
7. **Observable** — every request is logged; admin endpoints expose status, stats, and errors.

## Data model (summary)

| Table | Purpose |
|-------|---------|
| `syntra_applications` | Registered AUVYRR apps + rate limits |
| `syntra_users` | 1:1 with `auth.users` |
| `syntra_installations` | Device/install bindings (revocable) |
| `syntra_providers` | Provider catalog (groq, …) |
| `syntra_provider_accounts` | Account-level quota state |
| `syntra_credentials` | Credential metadata + concurrency |
| `syntra_usage_daily` | Per-user daily counters |
| `syntra_request_logs` | Per-request audit trail |
| `syntra_error_records` | Structured errors |
| `syntra_audit_logs` | Admin action history |
| `syntra_config` | Runtime configuration |

## Security boundaries

- Client JWT → validates identity only.
- Installation ID → binding + revocation, **not** authentication.
- Admin operations → require `ADMIN_API_KEY` secret (never shipped in APK).
- Credential tables → no RLS policies for `authenticated`; only service role.
- Logs never contain API keys, Authorization headers, or full user prompts.

## Extending to a new provider

1. Add a row to `syntra_providers`.
2. Implement `_shared/providers/<name>.ts` with a `callX(...)` function matching the existing result shape.
3. Branch in `ai-router` (or a small factory) on `providerCode`.
4. Register accounts + credentials as usual.
