# SYNTRA API Contract

## Base URL (after deployment)

```
https://<project-ref>.supabase.co/functions/v1
```

## 1. AI Router

### `POST /ai-router`

Primary endpoint used by AUVYRR applications.

#### Headers

| Header | Required | Description |
|--------|----------|-------------|
| `Authorization` | Yes | `Bearer <supabase-user-jwt>` |
| `Content-Type` | Yes | `application/json` |
| `x-auvyrr-app-id` | Recommended | Registered application key (e.g. `auvyrr-android-v1`) |
| `x-installation-id` | Recommended | Client-generated stable installation identifier (not a secret) |
| `x-platform` | Optional | `android` / `ios` / `web` |
| `x-app-version` | Optional | App version string |

#### Request body

```json
{
  "provider": "groq",
  "model": "llama-3.1-8b-instant",
  "messages": [
    { "role": "system", "content": "You are a helpful assistant." },
    { "role": "user", "content": "Hello" }
  ],
  "temperature": 0.7,
  "max_tokens": 1024,
  "request_id": "optional-client-uuid"
}
```

- `provider` defaults to `"groq"`.
- `model` defaults to `"llama-3.1-8b-instant"`.
- `stream` is currently ignored (non-streaming only).

#### Success response `200`

```json
{
  "request_id": "server-generated-or-echoed-uuid",
  "provider": "groq",
  "model": "llama-3.1-8b-instant",
  "choices": [
    {
      "index": 0,
      "message": { "role": "assistant", "content": "..." },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 12,
    "completion_tokens": 34,
    "total_tokens": 46
  },
  "created": 1730790000
}
```

#### Error responses

All errors share the shape:

```json
{
  "error": {
    "code": "RATE_LIMITED",
    "message": "Human readable explanation",
    "request_id": "...",
    "retry_after_seconds": 60
  }
}
```

| HTTP | code | Meaning |
|------|------|---------|
| 400 | `INVALID_REQUEST` | Malformed body or missing fields |
| 401 | `UNAUTHORIZED` | Missing/invalid JWT |
| 403 | `FORBIDDEN` | Blocked user or revoked installation |
| 429 | `RATE_LIMITED` | User exceeded RPM/RPD |
| 503 | `PROVIDER_UNAVAILABLE` | No eligible credential or upstream failure |
| 503 | `TEMPORARY_SERVICE_UNAVAILABLE` | Capacity busy or quota cooldown |
| 500 | `INTERNAL_SERVER_ERROR` | Unexpected server error |

`Retry-After` header is set when appropriate.

---

## 2. Health

### `GET /health`

Public, unauthenticated.

```json
{
  "status": "ok",
  "service": "syntra",
  "healthy_credentials": 2,
  "timestamp": "2026-11-05T..."
}
```

---

## 3. Admin (protected)

All admin routes require header:

```
x-admin-key: <ADMIN_API_KEY secret>
```

or `Authorization: Bearer <ADMIN_API_KEY>`.

### Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/admin/status` | Credential health + high-level counters |
| GET | `/admin/stats` | Recent usage + request samples |
| GET | `/admin/errors` | Recent failed requests |
| POST | `/admin/applications` | Register an AUVYRR app |
| POST | `/admin/accounts` | Register a provider account |
| POST | `/admin/credentials` | Register credential metadata (secret must already exist) |
| PATCH | `/admin/credentials/:id` | Enable/disable, change limits |
| POST | `/admin/credentials/:id/revoke` | Disable + mark unhealthy |

**Important:** Actual API key values are **never** accepted through these endpoints. They must be set as Edge Function secrets first; then you register metadata that points at the secret name via `secret_ref`.
