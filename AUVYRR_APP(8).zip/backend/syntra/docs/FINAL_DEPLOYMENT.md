# SYNTRA — Final Deployment Guide (Existing Supabase Project)

Use **your existing** Supabase project. Do not create a second project.

Version: **2.2 final** (migrations 001–006)

---

## 1. Migrations to apply

Apply **in order** on the same database. If you already applied some earlier, only run the ones you have not applied yet.

| File | Purpose |
|------|---------|
| `20251105000001_syntra_core.sql` | Core tables |
| `20251105000002_syntra_rls.sql` | Row Level Security |
| `20251105000003_syntra_helpers.sql` | Usage helper (superseded by 005 for increment semantics) |
| `20251105000004_syntra_concurrency_and_models.sql` | Atomic slots, models, policies, `suspended_until` |
| `20251105000005_syntra_v21_reliability.sql` | RPD-safe usage RPC, total_requests, NULL-safe unique |
| `20251105000006_syntra_v22_key_monitor.sql` | `key_monitor_access` permissions |

```bash
cd syntra
supabase link --project-ref <your-existing-project-ref>
supabase db push
```

Or paste each pending file in the SQL Editor in order.

**Already applied?** Skip those files. Never re-run destructive edits on production data without a backup.

---

## 2. Edge Functions to deploy

```bash
supabase functions deploy ai-router
supabase functions deploy admin
supabase functions deploy health
supabase functions deploy monitor
```

---

## 3. Secrets to configure

```bash
supabase secrets set ADMIN_API_KEY="$(openssl rand -hex 32)"
supabase secrets set GROQ_API_KEY_1="gsk_your_real_key"
# optional additional keys:
# supabase secrets set GROQ_API_KEY_2="gsk_..."
```

Never put these values in the Android app, dashboard, or git.

Runtime also needs `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` (normally injected by Supabase for Edge Functions).

---

## 4. Register application

```bash
curl -X POST "https://<project-ref>.supabase.co/functions/v1/admin/applications" \
  -H "x-admin-key: $ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "app_key": "auvyrr-android-v1",
    "display_name": "AUVYRR Android",
    "rate_limit_rpm": 30,
    "rate_limit_rpd": 500
  }'
```

---

## 5. Register provider account + credential metadata

```bash
# Account (note returned id)
curl -X POST "https://<project-ref>.supabase.co/functions/v1/admin/accounts" \
  -H "x-admin-key: $ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"provider_code":"groq","account_label":"primary"}'

# Credential metadata — secret_ref must match an Edge secret name
curl -X POST "https://<project-ref>.supabase.co/functions/v1/admin/credentials" \
  -H "x-admin-key: $ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "account_id": "<account-uuid>",
    "credential_key": "groq-primary-1",
    "secret_ref": "GROQ_API_KEY_1",
    "concurrency_limit": 5,
    "priority": 10
  }'
```

---

## 6. Grant Key Monitor access to your profile

In Supabase Dashboard → Authentication → Users, copy **your user UUID**.

```sql
INSERT INTO syntra_user_permissions (auth_user_id, permission, granted_by, notes)
VALUES (
  '<your-auth-user-uuid>',
  'key_monitor_access',
  'sql-admin',
  'Owner monitor access'
)
ON CONFLICT (auth_user_id, permission)
DO UPDATE SET
  is_active = true,
  revoked_at = NULL,
  granted_at = now(),
  granted_by = EXCLUDED.granted_by,
  notes = EXCLUDED.notes,
  updated_at = now();
```

---

## 7. Revoke Key Monitor access

```sql
UPDATE syntra_user_permissions
SET is_active = false, revoked_at = now(), updated_at = now()
WHERE auth_user_id = '<your-auth-user-uuid>'
  AND permission = 'key_monitor_access';
```

Revocation is checked on the **next** monitor request (no client-side cache of permission beyond the JWT session).

---

## 8. Open the dashboard

1. Open `dashboard/index.html` in a browser (or host the `dashboard/` folder as static files).
2. Base URL: `https://<project-ref>.supabase.co/functions/v1`
3. Access token: a **user JWT** for the account that has `key_monitor_access` (from Supabase Auth sign-in).
4. Connect → overview, providers, credentials, usage load via `/monitor/*`.

---

## 9. Smoke-test the complete system

```bash
# Health (public)
curl "https://<project-ref>.supabase.co/functions/v1/health"

# AI router (authenticated user JWT)
curl -X POST "https://<project-ref>.supabase.co/functions/v1/ai-router" \
  -H "Authorization: Bearer <user-jwt>" \
  -H "x-auvyrr-app-id: auvyrr-android-v1" \
  -H "x-installation-id: test-install-001" \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Say hello in one short sentence."}]}'

# Monitor without permission → 403
# Monitor with permission → 200 JSON
curl "https://<project-ref>.supabase.co/functions/v1/monitor/overview" \
  -H "Authorization: Bearer <user-jwt>"
```

Android: use `android/SyntraClient.kt` with the same base URL and user JWT.

---

## Primary endpoints

| Role | URL |
|------|-----|
| AI | `POST …/functions/v1/ai-router` |
| Admin | `…/functions/v1/admin/*` + `x-admin-key` |
| Health | `GET …/functions/v1/health` |
| Monitor | `GET …/functions/v1/monitor/{overview\|providers\|credentials\|usage\|health}` |
