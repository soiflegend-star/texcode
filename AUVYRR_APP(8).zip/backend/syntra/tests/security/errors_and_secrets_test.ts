import { assertEquals, assertStringIncludes } from "https://deno.land/std@0.168.0/testing/asserts.ts";
import { jsonError, unauthorized, rateLimited } from "../../supabase/functions/_shared/errors.ts";
import { resolveSecret } from "../../supabase/functions/router/availability.ts";

Deno.test("error responses never include stack traces", async () => {
  const res = jsonError("INTERNAL_SERVER_ERROR", "safe message", 500, { request_id: "r1" });
  const body = await res.json();
  assertEquals(body.error.message, "safe message");
  assertEquals(body.error.code, "INTERNAL_SERVER_ERROR");
  // Ensure no nested stack or secret fields
  assertEquals(Object.keys(body.error).sort().join(","), "code,message,request_id");
});

Deno.test("unauthorized returns 401", async () => {
  const res = unauthorized("no token");
  assertEquals(res.status, 401);
  const body = await res.json();
  assertEquals(body.error.code, "UNAUTHORIZED");
});

Deno.test("rateLimited sets Retry-After", async () => {
  const res = rateLimited("slow down", 42, "rid");
  assertEquals(res.status, 429);
  assertEquals(res.headers.get("Retry-After"), "42");
});

Deno.test("resolveSecret returns null for missing env", () => {
  assertEquals(resolveSecret("THIS_SECRET_DOES_NOT_EXIST_XYZ"), null);
});

Deno.test("resolveSecret does not throw on empty", () => {
  // Ensure no exception and no value leakage path
  const v = resolveSecret("");
  assertEquals(v, null);
});
