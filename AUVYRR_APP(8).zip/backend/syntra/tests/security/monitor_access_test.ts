/**
 * Key monitor access & response safety tests (no live DB).
 */
import { assertEquals, assertStringIncludes } from "https://deno.land/std@0.168.0/testing/asserts.ts";
import { PERMISSION_KEY_MONITOR } from "../../supabase/functions/_shared/authorization/permissions.ts";
import { forbidden, unauthorized } from "../../supabase/functions/_shared/errors.ts";

Deno.test("key_monitor_access permission constant", () => {
  assertEquals(PERMISSION_KEY_MONITOR, "key_monitor_access");
});

Deno.test("forbidden response for missing permission", async () => {
  const res = forbidden("key_monitor_access is not granted for this profile. Contact an administrator.");
  assertEquals(res.status, 403);
  const body = await res.json();
  assertEquals(body.error.code, "FORBIDDEN");
  assertStringIncludes(body.error.message, "key_monitor_access");
});

Deno.test("unauthorized without JWT", async () => {
  const res = unauthorized("Missing or invalid Authorization header");
  assertEquals(res.status, 401);
  const body = await res.json();
  assertEquals(body.error.code, "UNAUTHORIZED");
});

Deno.test("monitor response shape never includes secret fields (contract)", () => {
  // Documented safe credential payload keys
  const sample = {
    credential_id: "groq••••y-1",
    provider: "groq",
    account: "primary",
    priority: 10,
    health_status: "healthy",
    is_enabled: true,
    in_flight: 0,
    concurrency_limit: 5,
    suspension: { active: false, until: null },
    quota: {
      scope: "account",
      status: "ok",
      exhausted_until: null,
      remaining: { source: "unknown", value: null },
    },
    last_success_at: null,
    last_error_at: null,
    last_error_message: null,
  };
  const json = JSON.stringify(sample);
  assertEquals(json.includes("secret_ref"), false);
  assertEquals(json.includes("api_key"), false);
  assertEquals(json.includes("gsk_"), false);
  assertEquals(sample.quota.remaining.source, "unknown");
  assertEquals(sample.quota.scope, "account");
});

Deno.test("quota remaining unknown when provider does not expose it", () => {
  const remaining = { source: "unknown", value: null };
  assertEquals(remaining.source, "unknown");
  assertEquals(remaining.value, null);
});
