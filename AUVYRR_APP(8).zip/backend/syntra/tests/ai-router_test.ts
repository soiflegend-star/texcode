/**
 * SYNTRA automated tests
 * Run with: deno test --allow-net --allow-env tests/
 *
 * These tests mock provider responses and do not require real Groq keys.
 * Full end-to-end tests against a live Supabase project are out of scope here.
 */

import { assertEquals, assertExists } from "https://deno.land/std@0.168.0/testing/asserts.ts";
import { callGroq } from "../supabase/functions/_shared/providers/groq.ts";
import { jsonError } from "../supabase/functions/_shared/errors.ts";

// ---------------------------------------------------------------------------
// Error response shape
// ---------------------------------------------------------------------------
Deno.test("jsonError produces consistent shape", async () => {
  const res = jsonError("UNAUTHORIZED", "test message", 401, { request_id: "abc" });
  assertEquals(res.status, 401);
  const body = await res.json();
  assertEquals(body.error.code, "UNAUTHORIZED");
  assertEquals(body.error.message, "test message");
  assertEquals(body.error.request_id, "abc");
});

Deno.test("rateLimited sets Retry-After header", async () => {
  const { rateLimited } = await import("../supabase/functions/_shared/errors.ts");
  const res = rateLimited("too many", 30, "rid");
  assertEquals(res.status, 429);
  assertEquals(res.headers.get("Retry-After"), "30");
  const body = await res.json();
  assertEquals(body.error.retry_after_seconds, 30);
});

// ---------------------------------------------------------------------------
// Groq adapter with mocked fetch
// ---------------------------------------------------------------------------
Deno.test("callGroq maps successful response", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () =>
    new Response(
      JSON.stringify({
        model: "llama-3.1-8b-instant",
        choices: [{ index: 0, message: { role: "assistant", content: "Hello" }, finish_reason: "stop" }],
        usage: { prompt_tokens: 5, completion_tokens: 2, total_tokens: 7 },
        created: 123,
      }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );

  try {
    const result = await callGroq(
      "https://api.groq.com/openai/v1",
      "fake-key",
      { messages: [{ role: "user", content: "hi" }], request_id: "t1" },
      5000,
    );
    assertEquals(result.ok, true);
    assertEquals(result.status, 200);
    assertExists(result.body);
    assertEquals(result.body!.choices[0].message.content, "Hello");
    assertEquals(result.body!.usage?.total_tokens, 7);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

Deno.test("callGroq handles 429 with Retry-After", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () =>
    new Response(JSON.stringify({ error: { message: "rate limited" } }), {
      status: 429,
      headers: { "Retry-After": "45", "Content-Type": "application/json" },
    });

  try {
    const result = await callGroq(
      "https://api.groq.com/openai/v1",
      "fake-key",
      { messages: [{ role: "user", content: "hi" }] },
      5000,
    );
    assertEquals(result.ok, false);
    assertEquals(result.status, 429);
    assertEquals(result.isQuotaExhausted, true);
    assertEquals(result.retryAfterSeconds, 45);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

Deno.test("callGroq treats 5xx as transient", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () =>
    new Response("internal", { status: 500 });

  try {
    const result = await callGroq(
      "https://api.groq.com/openai/v1",
      "fake-key",
      { messages: [{ role: "user", content: "hi" }] },
      5000,
    );
    assertEquals(result.ok, false);
    assertEquals(result.isTransient, true);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

Deno.test("callGroq handles timeout", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = (_input, init) =>
    new Promise((_, reject) => {
      const err = new Error("aborted");
      (err as any).name = "AbortError";
      // Simulate abort
      if (init?.signal) {
        init.signal.addEventListener("abort", () => reject(err));
      }
      // Never resolve so timeout fires
    });

  try {
    const result = await callGroq(
      "https://api.groq.com/openai/v1",
      "fake-key",
      { messages: [{ role: "user", content: "hi" }] },
      50, // very short timeout
    );
    assertEquals(result.ok, false);
    assertEquals(result.isTransient, true);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

// ---------------------------------------------------------------------------
// Credential secret resolution (no real secrets)
// ---------------------------------------------------------------------------
Deno.test("resolveApiKey returns null for missing secret", async () => {
  const { resolveApiKey } = await import("../supabase/functions/_shared/credentials.ts");
  const key = resolveApiKey("NONEXISTENT_SECRET_XYZ");
  assertEquals(key, null);
});
