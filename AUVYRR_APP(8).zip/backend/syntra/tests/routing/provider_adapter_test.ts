import { assertEquals, assertExists } from "https://deno.land/std@0.168.0/testing/asserts.ts";
import { groqAdapter } from "../../supabase/functions/providers/groq/index.ts";
import { getProvider, listProviders } from "../../supabase/functions/providers/provider-interface.ts";

Deno.test("groq adapter is registered", () => {
  // side-effect registration happens on import
  const p = getProvider("groq");
  assertExists(p);
  assertEquals(p!.code, "groq");
  assertEquals(listProviders().includes("groq"), true);
});

Deno.test("groq adapter maps success", async () => {
  const original = globalThis.fetch;
  globalThis.fetch = async () =>
    new Response(
      JSON.stringify({
        model: "llama-3.1-8b-instant",
        choices: [{ index: 0, message: { role: "assistant", content: "ok" }, finish_reason: "stop" }],
        usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
        created: 1,
      }),
      { status: 200 },
    );
  try {
    const r = await groqAdapter.complete("fake", "https://api.groq.com/openai/v1", {
      model: "llama-3.1-8b-instant",
      messages: [{ role: "user", content: "hi" }],
    }, 5000);
    assertEquals(r.ok, true);
    if (r.ok) assertEquals(r.choices[0].message.content, "ok");
  } finally {
    globalThis.fetch = original;
  }
});

Deno.test("groq adapter maps 429 as quota_exhausted", async () => {
  const original = globalThis.fetch;
  globalThis.fetch = async () =>
    new Response(JSON.stringify({ error: { message: "rate" } }), {
      status: 429,
      headers: { "Retry-After": "30" },
    });
  try {
    const r = await groqAdapter.complete("fake", "https://api.groq.com/openai/v1", {
      model: "m",
      messages: [{ role: "user", content: "hi" }],
    }, 5000);
    assertEquals(r.ok, false);
    if (!r.ok) {
      assertEquals(r.is_quota_exhausted, true);
      assertEquals(r.category, "quota_exhausted");
      assertEquals(r.retry_after_seconds, 30);
    }
  } finally {
    globalThis.fetch = original;
  }
});

Deno.test("groq adapter maps timeout", async () => {
  const original = globalThis.fetch;
  globalThis.fetch = (_u, init) =>
    new Promise((_, reject) => {
      const err = new Error("aborted");
      (err as any).name = "AbortError";
      init?.signal?.addEventListener("abort", () => reject(err));
    });
  try {
    const r = await groqAdapter.complete("fake", "https://api.groq.com/openai/v1", {
      model: "m",
      messages: [{ role: "user", content: "hi" }],
    }, 30);
    assertEquals(r.ok, false);
    if (!r.ok) {
      assertEquals(r.category, "timeout");
      assertEquals(r.is_transient, true);
    }
  } finally {
    globalThis.fetch = original;
  }
});
