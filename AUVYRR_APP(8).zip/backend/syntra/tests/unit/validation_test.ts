import { assertEquals } from "https://deno.land/std@0.168.0/testing/asserts.ts";
import { validateAiRequest } from "../../supabase/functions/_shared/validation/request.ts";

Deno.test("validateAiRequest accepts valid body", () => {
  const r = validateAiRequest(
    { messages: [{ role: "user", content: "hi" }] },
    1_000_000,
    50,
  );
  assertEquals(r.ok, true);
});

Deno.test("validateAiRequest rejects empty messages", () => {
  const r = validateAiRequest({ messages: [] }, 1_000_000, 20);
  assertEquals(r.ok, false);
});

Deno.test("validateAiRequest rejects bad role", () => {
  const r = validateAiRequest(
    { messages: [{ role: "hacker", content: "x" }] },
    1_000_000,
    40,
  );
  assertEquals(r.ok, false);
});

Deno.test("validateAiRequest rejects oversized body", () => {
  const r = validateAiRequest(
    { messages: [{ role: "user", content: "x" }] },
    10,
    100,
  );
  assertEquals(r.ok, false);
});

Deno.test("validateAiRequest rejects invalid temperature", () => {
  const r = validateAiRequest(
    { messages: [{ role: "user", content: "hi" }], temperature: 5 },
    1_000_000,
    50,
  );
  assertEquals(r.ok, false);
});
