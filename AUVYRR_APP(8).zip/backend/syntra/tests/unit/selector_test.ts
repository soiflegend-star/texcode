/**
 * Unit tests for credential selection logic (pure decision helpers)
 */
import { assertEquals } from "https://deno.land/std@0.168.0/testing/asserts.ts";
import { decideFailover } from "../../supabase/functions/router/failover.ts";
import { computeBackoffMs, DEFAULT_RETRY_POLICY } from "../../supabase/functions/router/retry.ts";

Deno.test("decideFailover quota_exhausted does not try alternate keys", () => {
  const d = decideFailover("quota_exhausted", 90);
  assertEquals(d.retrySame, false);
  assertEquals(d.tryAlternate, false);
  assertEquals(d.markQuotaExhausted, true);
  assertEquals(d.quotaCooldownSeconds, 90);
  assertEquals(d.clientCode, "TEMPORARY_SERVICE_UNAVAILABLE");
});

Deno.test("decideFailover timeout allows retry and alternate", () => {
  const d = decideFailover("timeout");
  assertEquals(d.retrySame, true);
  assertEquals(d.tryAlternate, true);
  assertEquals(d.markQuotaExhausted, false);
});

Deno.test("decideFailover auth_error marks unhealthy and allows alternate", () => {
  const d = decideFailover("auth_error");
  assertEquals(d.markUnhealthy, true);
  assertEquals(d.tryAlternate, true);
  assertEquals(d.retrySame, false);
});

Deno.test("decideFailover invalid_request does not retry", () => {
  const d = decideFailover("invalid_request");
  assertEquals(d.retrySame, false);
  assertEquals(d.tryAlternate, false);
  assertEquals(d.clientCode, "INVALID_REQUEST");
});

Deno.test("decideFailover busy tries alternate", () => {
  const d = decideFailover("busy");
  assertEquals(d.tryAlternate, true);
  assertEquals(d.clientCode, "TEMPORARY_SERVICE_UNAVAILABLE");
});

Deno.test("computeBackoffMs increases with attempt", () => {
  const a0 = computeBackoffMs(0, { ...DEFAULT_RETRY_POLICY, jitter: false });
  const a1 = computeBackoffMs(1, { ...DEFAULT_RETRY_POLICY, jitter: false });
  const a2 = computeBackoffMs(2, { ...DEFAULT_RETRY_POLICY, jitter: false });
  assertEquals(a0, 200);
  assertEquals(a1, 400);
  assertEquals(a2, 800);
});

Deno.test("computeBackoffMs respects maxDelay", () => {
  const d = computeBackoffMs(10, { maxAttempts: 5, baseDelayMs: 200, maxDelayMs: 500, jitter: false });
  assertEquals(d, 500);
});
