/**
 * SYNTRA v2.1 regression tests for the four reliability fixes.
 * Pure logic + mocked behaviour — no live database required.
 */
import { assertEquals } from "https://deno.land/std@0.168.0/testing/asserts.ts";
import { isCurrentlySuspended } from "../../supabase/functions/router/selector.ts";
import { decideFailover } from "../../supabase/functions/router/failover.ts";
import { rateLimited } from "../../supabase/functions/_shared/errors.ts";

// ---------------------------------------------------------------------------
// FIX 2 — suspended_until selection helper
// ---------------------------------------------------------------------------
Deno.test("active suspension blocks credential", () => {
  const future = new Date(Date.now() + 60_000).toISOString();
  assertEquals(isCurrentlySuspended(future), true);
});

Deno.test("expired suspension does not block credential", () => {
  const past = new Date(Date.now() - 60_000).toISOString();
  assertEquals(isCurrentlySuspended(past), false);
});

Deno.test("null suspension does not block credential", () => {
  assertEquals(isCurrentlySuspended(null), false);
  assertEquals(isCurrentlySuspended(undefined), false);
});

Deno.test("invalid suspension timestamp is treated as not suspended", () => {
  assertEquals(isCurrentlySuspended("not-a-date"), false);
});

// ---------------------------------------------------------------------------
// FIX 1 — RPD error shape still correct when blocked
// ---------------------------------------------------------------------------
Deno.test("RATE_LIMITED daily response has correct shape and Retry-After", async () => {
  const res = rateLimited(
    "Daily rate limit exceeded: maximum 1000 requests per day",
    3600,
    "req-daily-1",
  );
  assertEquals(res.status, 429);
  assertEquals(res.headers.get("Retry-After"), "3600");
  const body = await res.json();
  assertEquals(body.error.code, "RATE_LIMITED");
  assertEquals(body.error.request_id, "req-daily-1");
  assertEquals(body.error.retry_after_seconds, 3600);
});

// ---------------------------------------------------------------------------
// RPC sentinel contract: -1 means blocked (documented for migration 005)
// ---------------------------------------------------------------------------
Deno.test("blocked sentinel -1 is recognized as over limit", () => {
  const count = -1;
  const blocked = count === -1;
  assertEquals(blocked, true);
});

Deno.test("positive count is allowed", () => {
  const count: number = 42;
  const blocked = count === -1;
  assertEquals(blocked, false);
});

// ---------------------------------------------------------------------------
// FIX 2 — all_suspended maps to provider unavailable path
// ---------------------------------------------------------------------------
Deno.test("disabled failover used for suspended credentials", () => {
  const d = decideFailover("disabled");
  assertEquals(d.retrySame, false);
  assertEquals(d.tryAlternate, false);
  assertEquals(d.clientCode, "PROVIDER_UNAVAILABLE");
});

// ---------------------------------------------------------------------------
// Selection reason type includes all_suspended
// ---------------------------------------------------------------------------
Deno.test("SelectionReason includes all_suspended", async () => {
  const mod = await import("../../supabase/functions/router/selector.ts");
  // Compile-time presence is enough; runtime check that function exports exist
  assertEquals(typeof mod.selectEligibleCredential, "function");
  assertEquals(typeof mod.isCurrentlySuspended, "function");
});
