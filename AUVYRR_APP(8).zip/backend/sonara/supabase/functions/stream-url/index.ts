// VELTRIX Edge Function: batch-resolve published tracks to playable URLs.
// Public listeners may request published tracks; the service-role key stays server-side.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
}
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...cors, "Content-Type": "application/json", "Cache-Control": "no-store" },
})

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors })
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405)

  try {
    const body = await req.json()
    const ids: string[] = Array.isArray(body.track_ids)
      ? body.track_ids
      : (typeof body.track_id === "string" ? [body.track_id] : [])
    const uniqueIds = [...new Set(ids)].slice(0, 50)
    if (uniqueIds.length === 0 || uniqueIds.some(id => !/^[0-9a-f-]{36}$/i.test(id))) {
      return json({ error: "valid_track_ids_required" }, 400)
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false, autoRefreshToken: false } },
    )

    const { data: tracks, error } = await supabase
      .from("tracks")
      .select("id,status,storage_bucket,storage_object_path,external_stream_url")
      .in("id", uniqueIds)
      .eq("status", "published")
    if (error) return json({ error: "catalogue_lookup_failed" }, 500)

    const pairs = await Promise.all((tracks ?? []).map(async (track) => {
      const { data: allowed, error: rightsError } = await supabase.rpc(
        "track_stream_allowed", { p_track_id: track.id },
      )
      if (rightsError || allowed === false) return null
      if (track.external_stream_url) return [track.id, track.external_stream_url] as const
      if (!track.storage_object_path) return null
      const { data: signed, error: signError } = await supabase.storage
        .from(track.storage_bucket || "music")
        .createSignedUrl(track.storage_object_path, 6 * 60 * 60)
      if (signError || !signed?.signedUrl) return null
      return [track.id, signed.signedUrl] as const
    }))

    const urls: Record<string, string> = {}
    for (const pair of pairs) if (pair) urls[pair[0]] = pair[1]
    return json({ urls, expires_in: 21600 })
  } catch (_error) {
    return json({ error: "invalid_request" }, 400)
  }
})
