-- Sonara v0.5 — Rights, licensing, roles, moderation
-- Run after 001 and 002. Metadata only; audio remains in Storage.

-- Roles
create type public.app_role as enum ('listener', 'artist', 'label', 'moderator', 'admin');

create table if not exists public.user_roles (
  user_id uuid references public.profiles(id) on delete cascade,
  role public.app_role not null,
  granted_at timestamptz not null default now(),
  granted_by uuid references public.profiles(id),
  primary key (user_id, role)
);

alter table public.user_roles enable row level security;
create policy "read own roles" on public.user_roles for select using (auth.uid() = user_id);
-- Admin role grants must go through service role / edge functions only

-- Rights record per track (sound recording + composition simplified)
create table if not exists public.track_rights (
  id uuid primary key default uuid_generate_v4(),
  track_id uuid not null references public.tracks(id) on delete cascade,
  owner_name text not null,
  owner_user_id uuid references public.profiles(id),
  master_owner text,
  composition_owner text,
  publisher text,
  isrc text,
  iswc text,
  territory text not null default 'WW', -- ISO or WW
  allow_stream boolean not null default true,
  allow_download boolean not null default false,
  allow_commercial boolean not null default false,
  license_type text not null default 'original'
    check (license_type in ('original','exclusive','non_exclusive','cc0','cc_by','public_domain','label','distributor')),
  license_start date,
  license_end date,
  royalty_share_bps int default 0, -- basis points to platform
  documentation_url text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index track_rights_track_idx on public.track_rights(track_id);
create index track_rights_territory_idx on public.track_rights(territory);

alter table public.track_rights enable row level security;
create policy "rights readable if track published or owner"
  on public.track_rights for select using (
    exists (
      select 1 from public.tracks t
      where t.id = track_id and (t.status = 'published' or t.owner_id = auth.uid())
    )
  );

-- Submissions (artist / user uploads awaiting review)
create table if not exists public.content_submissions (
  id uuid primary key default uuid_generate_v4(),
  submitter_id uuid not null references public.profiles(id),
  track_id uuid references public.tracks(id),
  title text not null,
  artist_name text not null,
  album_name text,
  genre text,
  storage_path text,
  artwork_path text,
  duration_ms bigint,
  ownership_declaration text not null,
  documentation_urls text[] default '{}',
  status text not null default 'pending'
    check (status in ('pending','needs_info','approved','rejected','takedown')),
  reviewer_id uuid references public.profiles(id),
  reviewer_notes text,
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz
);

alter table public.content_submissions enable row level security;
create policy "submitter reads own" on public.content_submissions
  for select using (auth.uid() = submitter_id);
create policy "submitter inserts own" on public.content_submissions
  for insert with check (auth.uid() = submitter_id);

-- Labels
create table if not exists public.labels (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  contact_email text,
  owner_user_id uuid references public.profiles(id),
  verified boolean default false,
  created_at timestamptz not null default now()
);

-- Copyright complaints / DMCA-style takedown queue
create table if not exists public.copyright_complaints (
  id uuid primary key default uuid_generate_v4(),
  track_id uuid references public.tracks(id),
  complainant_name text not null,
  complainant_email text not null,
  description text not null,
  evidence_url text,
  status text not null default 'open'
    check (status in ('open','investigating','upheld','rejected','resolved')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolver_notes text
);

alter table public.copyright_complaints enable row level security;
-- Inserts may be public via edge function; selects restricted

-- Audit log
create table if not exists public.admin_audit_log (
  id bigserial primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  entity_type text,
  entity_id text,
  meta jsonb default '{}',
  created_at timestamptz not null default now()
);

-- Subscription plans (config; payments verified server-side)
create table if not exists public.subscription_plans (
  id text primary key,
  name text not null,
  monthly_price_cents int not null default 0,
  download_limit int, -- null = unlimited under plan rules
  high_quality boolean default false,
  features jsonb default '[]',
  active boolean default true
);

insert into public.subscription_plans (id, name, monthly_price_cents, download_limit, high_quality, features)
values
  ('free', 'Free', 0, 10, false, '["stream_free_catalogue"]'),
  ('premium_monthly', 'Premium', 999, null, true, '["stream_all","expanded_downloads","hq"]')
on conflict (id) do nothing;

create table if not exists public.user_subscriptions (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  plan_id text not null references public.subscription_plans(id),
  status text not null default 'active'
    check (status in ('active','cancelled','expired','grace')),
  provider text default 'none', -- 'google_play' | 'none'
  provider_purchase_token text,
  started_at timestamptz not null default now(),
  expires_at timestamptz,
  updated_at timestamptz not null default now()
);

alter table public.user_subscriptions enable row level security;
create policy "own subscription" on public.user_subscriptions
  for select using (auth.uid() = user_id);

-- Helper: published track may stream if rights allow and not expired
create or replace function public.track_stream_allowed(p_track_id uuid, p_territory text default 'WW')
returns boolean
language sql
stable
as $$
  select exists (
    select 1 from public.tracks t
    left join public.track_rights r on r.track_id = t.id
    where t.id = p_track_id
      and t.status = 'published'
      and coalesce(r.allow_stream, true) = true
      and (r.territory is null or r.territory = 'WW' or r.territory = p_territory)
      and (r.license_end is null or r.license_end >= current_date)
  );
$$;
