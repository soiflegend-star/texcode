-- Sonara online streaming schema (extends 001)
-- Metadata in Postgres. Audio files in Storage (or external CDN). Never store binary audio in DB rows.

create extension if not exists pg_trgm;

-- Artists
create table if not exists public.artists (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text unique,
  image_url text,
  bio text default '',
  owner_user_id uuid references public.profiles(id),
  monthly_listeners int default 0,
  is_verified boolean default false,
  created_at timestamptz not null default now()
);

-- Albums
create table if not exists public.albums (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  artist_id uuid references public.artists(id),
  artist_name text not null,
  artwork_url text,
  release_year int,
  track_count int default 0,
  created_at timestamptz not null default now()
);

-- Enrich tracks for streaming
alter table public.tracks
  add column if not exists artist_id uuid references public.artists(id),
  add column if not exists album_id uuid references public.albums(id),
  add column if not exists storage_bucket text default 'music',
  add column if not exists storage_object_path text,  -- path inside bucket; stream via signed URL
  add column if not exists external_stream_url text,  -- for licensed external / demo CDN URLs
  add column if not exists license_type text default 'platform'
    check (license_type in ('platform', 'cc0', 'cc_by', 'licensed', 'original', 'public_domain')),
  add column if not exists license_note text,
  add column if not exists bitrate_kbps int,
  add column if not exists is_premium_only boolean default false;

-- Stream access log (analytics + entitlement)
create table if not exists public.stream_events (
  id bigserial primary key,
  user_id uuid references public.profiles(id),
  track_id uuid not null references public.tracks(id) on delete cascade,
  started_at timestamptz not null default now(),
  duration_played_ms bigint,
  client text default 'android'
);

-- Likes (server-side)
create table if not exists public.likes (
  user_id uuid references public.profiles(id) on delete cascade,
  track_id uuid references public.tracks(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, track_id)
);

-- Downloads entitlement usage
create table if not exists public.download_grants (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  track_id uuid not null references public.tracks(id) on delete cascade,
  granted_at timestamptz not null default now(),
  expires_at timestamptz
);

-- App config (free download limit etc.)
create table if not exists public.app_config (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

insert into public.app_config (key, value) values
  ('free_download_limit', '10'),
  ('streaming_enabled', 'true')
on conflict (key) do nothing;

-- RLS
alter table public.artists enable row level security;
alter table public.albums enable row level security;
alter table public.likes enable row level security;
alter table public.stream_events enable row level security;

create policy "artists public read" on public.artists for select using (true);
create policy "albums public read" on public.albums for select using (true);
create policy "likes own" on public.likes for all using (auth.uid() = user_id);
create policy "stream events own insert" on public.stream_events for insert with check (auth.uid() = user_id);
create policy "stream events own read" on public.stream_events for select using (auth.uid() = user_id);

-- Storage buckets (run in dashboard or via API): music (private), artwork (public)
-- Signed URLs issued by edge function stream-url for private audio objects.
