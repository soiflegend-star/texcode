-- VELTRIX: publish approved creator uploads into the public catalogue.
-- Run after migrations 001-005. Audio stays in the private music bucket.

alter table public.content_submissions
  add column if not exists artwork_url text;

-- Only moderator/admin roles may review submissions. Owners can still read their own rows.
drop policy if exists "moderators review submissions" on public.content_submissions;
create policy "moderators review submissions"
on public.content_submissions
for update to authenticated
using (
  exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text in ('moderator', 'admin')
  )
)
with check (
  exists (
    select 1 from public.user_roles r
    where r.user_id = auth.uid() and r.role::text in ('moderator', 'admin')
  )
);

create or replace function public.publish_approved_creator_submission()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_track_id uuid;
begin
  if new.status = 'approved' and old.status is distinct from 'approved' then
    if coalesce(new.storage_path, '') = '' or coalesce(new.artwork_url, '') = '' then
      raise exception 'Audio and unique artwork must both exist before publication';
    end if;

    v_track_id := coalesce(new.track_id, uuid_generate_v4());
    insert into public.tracks (
      id, title, artist_name, album_name, artwork_url, stream_path,
      source, genre, owner_id, status, storage_bucket, storage_object_path,
      external_stream_url, is_downloadable
    ) values (
      v_track_id, new.title, new.artist_name, new.album_name, new.artwork_url,
      new.storage_path, 'uploaded', new.genre, new.submitter_id, 'published',
      'music', new.storage_path, null, false
    )
    on conflict (id) do update set
      title = excluded.title,
      artist_name = excluded.artist_name,
      album_name = excluded.album_name,
      artwork_url = excluded.artwork_url,
      storage_object_path = excluded.storage_object_path,
      owner_id = excluded.owner_id,
      status = 'published';

    new.track_id := v_track_id;
  end if;
  return new;
end;
$$;

drop trigger if exists publish_approved_creator_submission_trigger on public.content_submissions;
create trigger publish_approved_creator_submission_trigger
before update of status on public.content_submissions
for each row execute function public.publish_approved_creator_submission();

comment on function public.publish_approved_creator_submission() is
'When an authorized moderator approves a submission, publishes it to tracks while retaining private audio storage and its unique public artwork.';
