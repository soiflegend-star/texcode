-- Sonara Creator Studio: owner-scoped storage access and real catalogue analytics.
-- Run after migrations 001-004. Never put a service-role key in the Android app.

create index if not exists stream_events_track_idx on public.stream_events(track_id, started_at desc);
create index if not exists likes_track_idx on public.likes(track_id);

-- Storage buckets must exist before these object policies are applied.
-- Create 'music' as PRIVATE and 'artwork' as PUBLIC in Supabase Storage.

drop policy if exists "creator uploads own audio" on storage.objects;
create policy "creator uploads own audio" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'music'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "creator reads own audio" on storage.objects;
create policy "creator reads own audio" on storage.objects
for select to authenticated
using (
  bucket_id = 'music'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "creator deletes own audio" on storage.objects;
create policy "creator deletes own audio" on storage.objects
for delete to authenticated
using (
  bucket_id = 'music'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "creator uploads own artwork" on storage.objects;
create policy "creator uploads own artwork" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'artwork'
  and (storage.foldername(name))[1] = auth.uid()::text
);

drop policy if exists "public artwork is readable" on storage.objects;
create policy "public artwork is readable" on storage.objects
for select to public
using (bucket_id = 'artwork');

drop policy if exists "creator deletes own artwork" on storage.objects;
create policy "creator deletes own artwork" on storage.objects
for delete to authenticated
using (
  bucket_id = 'artwork'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Keep the review queue private to its submitter; moderators should use a trusted server role.
-- Existing 003 policies provide owner-only insert/select. This adds owner-only delete for drafts.
drop policy if exists "submitter deletes own pending submission" on public.content_submissions;
create policy "submitter deletes own pending submission" on public.content_submissions
for delete to authenticated
using (auth.uid() = submitter_id and status in ('pending', 'needs_info'));

-- The view owner can aggregate all event rows, but the predicate limits every result
-- to the currently authenticated creator's own tracks. It exposes aggregate counts only.
create or replace view public.creator_track_analytics as
select
  t.id as track_id,
  t.owner_id,
  t.title,
  t.artist_name,
  t.artwork_url,
  count(distinct se.id)::bigint as play_count,
  count(distinct l.user_id)::bigint as like_count,
  count(distinct se.user_id)::bigint as listener_count
from public.tracks t
left join public.stream_events se on se.track_id = t.id
left join public.likes l on l.track_id = t.id
where t.owner_id = auth.uid()
  and t.status = 'published'
group by t.id, t.owner_id, t.title, t.artist_name, t.artwork_url;

revoke all on public.creator_track_analytics from anon;
grant select on public.creator_track_analytics to authenticated;

comment on view public.creator_track_analytics is
'Owner-scoped aggregate plays, likes, and unique listeners for published creator tracks. Views are not reported because no view event is currently recorded.';

-- Owners may edit their own published metadata and request a takedown.
drop policy if exists "owners update own tracks" on public.tracks;
create policy "owners update own tracks" on public.tracks
for update to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

-- Creator edits may change display metadata, but cannot publish or approve tracks.
create or replace function public.guard_creator_track_status()
returns trigger
language plpgsql
security invoker
as $$
begin
  if auth.uid() = old.owner_id and new.status is distinct from old.status
     and new.status <> 'takedown' then
    raise exception 'Creators may only request a takedown; publication status is moderator-controlled';
  end if;
  return new;
end;
$$;

drop trigger if exists guard_creator_track_status_trigger on public.tracks;
create trigger guard_creator_track_status_trigger
before update on public.tracks
for each row execute function public.guard_creator_track_status();
