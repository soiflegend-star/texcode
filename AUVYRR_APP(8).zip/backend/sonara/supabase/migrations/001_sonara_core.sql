-- Sonara core schema (draft)
-- Run against a fresh Supabase project. Do not use the existing TexWave project.

-- Enable required extensions
create extension if not exists "uuid-ossp";

-- Profiles (extends auth.users)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null,
  avatar_url text,
  bio text default '',
  is_premium boolean not null default false,
  free_downloads_remaining int not null default 10,
  follower_count int not null default 0,
  following_count int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Tracks (catalogue + user uploads)
create table public.tracks (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  artist_name text not null,
  album_name text,
  duration_ms bigint,
  artwork_url text,
  stream_path text,                -- storage path or external URL
  source text not null check (source in ('catalogue', 'uploaded', 'local_meta')),
  genre text,
  year int,
  is_explicit boolean default false,
  is_downloadable boolean default false,
  owner_id uuid references public.profiles(id),
  status text not null default 'published'
    check (status in ('draft', 'pending_review', 'published', 'rejected', 'takedown')),
  play_count bigint default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index tracks_owner_idx on public.tracks(owner_id);
create index tracks_status_idx on public.tracks(status);
create index tracks_title_trgm on public.tracks using gin (title gin_trgm_ops); -- requires pg_trgm

-- Playlists
create table public.playlists (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  description text default '',
  owner_id uuid not null references public.profiles(id) on delete cascade,
  artwork_url text,
  is_public boolean not null default true,
  is_collaborative boolean not null default false,
  track_count int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.playlist_tracks (
  playlist_id uuid references public.playlists(id) on delete cascade,
  track_id uuid references public.tracks(id) on delete cascade,
  position int not null,
  added_by uuid references public.profiles(id),
  added_at timestamptz not null default now(),
  primary key (playlist_id, track_id)
);

-- Social
create table public.follows (
  follower_id uuid references public.profiles(id) on delete cascade,
  following_id uuid references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);

-- Listening history (for recommendations / recents)
create table public.listening_history (
  id bigserial primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  track_id uuid not null references public.tracks(id) on delete cascade,
  played_at timestamptz not null default now(),
  duration_played_ms bigint
);

create index listening_history_user_idx on public.listening_history(user_id, played_at desc);

-- Uploads / review queue
create table public.upload_submissions (
  id uuid primary key default uuid_generate_v4(),
  track_id uuid references public.tracks(id),
  submitter_id uuid not null references public.profiles(id),
  copyright_declaration text not null,
  rights_documentation_url text,
  status text not null default 'pending'
    check (status in ('pending', 'approved', 'rejected')),
  reviewer_notes text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

-- Basic RLS (tighten in later migrations)
alter table public.profiles enable row level security;
alter table public.tracks enable row level security;
alter table public.playlists enable row level security;
alter table public.playlist_tracks enable row level security;
alter table public.follows enable row level security;
alter table public.listening_history enable row level security;
alter table public.upload_submissions enable row level security;

-- Example policies (expand carefully)
create policy "Public profiles are viewable by everyone"
  on public.profiles for select using (true);

create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);

create policy "Published tracks are readable"
  on public.tracks for select using (status = 'published' or owner_id = auth.uid());

create policy "Owners manage their playlists"
  on public.playlists for all using (owner_id = auth.uid());

create policy "Public playlists readable"
  on public.playlists for select using (is_public = true or owner_id = auth.uid());
