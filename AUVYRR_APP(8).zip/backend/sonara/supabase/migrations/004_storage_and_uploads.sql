-- Storage-oriented metadata for community uploads (run after 001-003)
-- Create buckets in Dashboard: music (private), artwork (public)

alter table public.content_submissions
  add column if not exists storage_path text,
  add column if not exists artwork_storage_path text,
  add column if not exists mime_type text,
  add column if not exists file_size_bytes bigint,
  add column if not exists audio_hash text;

create index if not exists content_submissions_status_idx on public.content_submissions(status);
create index if not exists content_submissions_submitter_idx on public.content_submissions(submitter_id);

-- Published uploads become tracks (moderator-triggered via edge function ideally)
comment on table public.content_submissions is 'User uploads pending human rights review before publish';
