# Sonara online library

Search and Home rows query these sources live (see `sonara/data/online/OnlineCatalogue.kt`):

| Source  | What you get                                   | Key needed |
|---------|-----------------------------------------------|------------|
| Audius  | Full-length streams, millions of indie tracks | No (optional `AUDIUS_API_KEY` in `SonaraConfig`) |
| Jamendo | Full-length Creative Commons streams          | Free client id -> `SonaraConfig.JAMENDO_CLIENT_ID` |
| iTunes  | 30-second previews of almost any song         | No |

Major-label songs are NOT available as full streams from any open source; they show as "30s preview".
Do not add scraping of Spotify / YouTube / Apple Music.
Played, liked and playlisted online tracks are cached on-device (`TrackCacheStore`) so the library survives restarts.
