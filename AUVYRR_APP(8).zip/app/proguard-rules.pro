# Media3 / ExoPlayer ship consumer rules. Add project-specific keep rules here.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile


# Vosk offline speech
-keep class org.vosk.** { *; }
-dontwarn org.vosk.**

# WebRTC (JNI calls into org.webrtc)
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# Brains (MediaPipe on-device LLM) — native code calls back into these classes
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.protobuf.**
-keep class com.texgen.music.texwave.brain.** { *; }

# Veltrix automation module (kotlinx.serialization models + receivers)
-keepattributes *Annotation*, InnerClasses, Signature
-keep class com.texgen.music.texwave.veltrix.model.** { *; }
-keep class com.texgen.music.texwave.veltrix.engine.VeltrixReceiver { *; }
-keep class com.texgen.music.texwave.veltrix.engine.VeltrixBootReceiver { *; }
-keepclassmembers class com.texgen.music.texwave.veltrix.model.** {
    *** Companion;
    kotlinx.serialization.KSerializer serializer(...);
}
# Cosmic explorer GL renderer is referenced by GLSurfaceView
-keep class com.texgen.music.texwave.ui.screens.universe.** { *; }
