plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.texgen.music.texwave"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.texgen.music.texwave"
        minSdk = 26
        targetSdk = 34
        versionCode = 65
        versionName = "6.9.0"
    }

    // Optional release signing: provide these environment variables (e.g. in CI secrets).
    signingConfigs {
        create("release") {
            val keystore = System.getenv("TEXWAVE_KEYSTORE")
            if (keystore != null) {
                storeFile = file(keystore)
                storePassword = System.getenv("TEXWAVE_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("TEXWAVE_KEY_ALIAS")
                keyPassword = System.getenv("TEXWAVE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (System.getenv("TEXWAVE_KEYSTORE") != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.8" }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        resources.excludes += "META-INF/DEPENDENCIES"
        jniLibs {
            pickFirsts += listOf(
                "lib/arm64-v8a/libc++_shared.so",
                "lib/armeabi-v7a/libc++_shared.so",
                "lib/x86/libc++_shared.so",
                "lib/x86_64/libc++_shared.so"
            )
            useLegacyPackaging = true
        }
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    // Offline speech (Vosk) — model downloaded on demand into app storage
    implementation("com.alphacephei:vosk-android:0.3.75")

    val bom = platform("androidx.compose:compose-bom:2024.02.00")
    implementation(bom)
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    implementation("androidx.media3:media3-exoplayer:1.2.1")
    implementation("androidx.media3:media3-session:1.2.1")
    implementation("androidx.media3:media3-common:1.2.1")
    implementation("androidx.media3:media3-datasource:1.2.1")
    implementation("androidx.media3:media3-database:1.2.1")
    implementation("androidx.media3:media3-ui:1.2.1")
    implementation("androidx.media3:media3-transformer:1.2.1")
    implementation("androidx.media3:media3-effect:1.2.1")
    implementation("com.google.guava:guava:32.1.3-android")

    implementation("io.coil-kt:coil-compose:2.5.0")
    // Sonara module
    implementation("androidx.datastore:datastore-preferences:1.0.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Supabase — pinned versions (BOM was resolving empty version on CI)
    val sb = "2.5.3"
    implementation("io.github.jan-tennert.supabase:gotrue-kt:$sb")
    implementation("io.github.jan-tennert.supabase:postgrest-kt:$sb")
    implementation("io.github.jan-tennert.supabase:realtime-kt:$sb")
    implementation("io.github.jan-tennert.supabase:storage-kt:$sb")
    implementation("io.ktor:ktor-client-android:2.3.12")
    implementation("io.ktor:ktor-client-content-negotiation:2.3.12")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.12")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")

    // Session persistence for Supabase Auth (SharedPreferences-backed on Android)
    implementation("com.russhwolf:multiplatform-settings-no-arg:1.1.1")

    // Real-time voice calls (WebRTC)
    implementation("io.getstream:stream-webrtc-android:1.1.1")

    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // SYNERGY ARENA
    val camera = "1.3.1"
    implementation("androidx.camera:camera-core:$camera")
    implementation("androidx.camera:camera-camera2:$camera")
    implementation("androidx.camera:camera-lifecycle:$camera")
    implementation("androidx.camera:camera-view:$camera")
    implementation("com.google.mediapipe:tasks-vision:0.10.21")
    implementation("com.google.mediapipe:tasks-genai:0.10.22")
    implementation("io.github.sceneview:sceneview:2.2.1")

    testImplementation("junit:junit:4.13.2")
}
