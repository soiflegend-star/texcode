package com.texgen.music.texwave.sonara.data.online

import com.texgen.music.texwave.sonara.SonaraConfig
import com.texgen.music.texwave.sonara.data.Track
import com.texgen.music.texwave.sonara.data.TrackSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Live, legal catalogue search across open music services:
 *  - Audius   : full-length streams, millions of independent tracks (incl. phonk, lo-fi, hip-hop, EDM)
 *  - Jamendo  : full-length Creative Commons streams (needs a free client id in SonaraConfig)
 *  - iTunes   : 30-second previews of almost any commercial song (discovery, clearly labelled)
 * Every function swallows network errors and returns an empty list, so one dead source never breaks search.
 */
object OnlineCatalogue {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private suspend fun getJson(url: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(url).header("User-Agent", "AUVYRR-Sonara/1.0").build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) null else JSONObject(r.body?.string() ?: return@use null)
            }
        } catch (_: Exception) { null }
    }

    private fun audiusUrl(path: String, params: Map<String, String>): String {
        val b = "https://api.audius.co/v1/$path".toHttpUrl().newBuilder()
        b.addQueryParameter("app_name", SonaraConfig.APP_NAME)
        if (SonaraConfig.AUDIUS_API_KEY.isNotBlank()) b.addQueryParameter("api_key", SonaraConfig.AUDIUS_API_KEY)
        params.forEach { (k, v) -> b.addQueryParameter(k, v) }
        return b.build().toString()
    }

    // ───────── Audius
    private fun parseAudius(arr: JSONArray?): List<Track> {
        if (arr == null) return emptyList()
        val out = ArrayList<Track>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isBlank() || o.optBoolean("is_delete", false) || o.optBoolean("is_unlisted", false)) continue
            if (!o.optBoolean("is_streamable", true)) continue
            val art = o.optJSONObject("artwork")
            val art480 = art?.optString("480x480")?.takeIf { it.isNotBlank() }
                ?: art?.optString("1000x1000")?.takeIf { it.isNotBlank() }
                ?: art?.optString("150x150")?.takeIf { it.isNotBlank() }
            val stream = audiusUrl("tracks/$id/stream", emptyMap())
            out.add(
                Track(
                    id = "au_$id",
                    title = o.optString("title", "Untitled"),
                    artist = o.optJSONObject("user")?.optString("name")?.takeIf { it.isNotBlank() } ?: "Unknown artist",
                    durationMs = o.optLong("duration", 0L) * 1000L,
                    artworkUrl = art480,
                    streamUrl = stream,
                    source = TrackSource.CATALOGUE,
                    genre = o.optString("genre").takeIf { it.isNotBlank() },
                    year = o.optString("release_date").take(4).toIntOrNull(),
                    origin = "audius",
                )
            )
        }
        return out
    }

    suspend fun audiusSearch(q: String, limit: Int = 25): List<Track> =
        parseAudius(getJson(audiusUrl("tracks/search", mapOf("query" to q, "limit" to "$limit")))?.optJSONArray("data"))

    suspend fun audiusTrending(genre: String? = null, limit: Int = 20): List<Track> {
        val p = mutableMapOf("time" to "week", "limit" to "$limit")
        if (genre != null) p["genre"] = genre
        return parseAudius(getJson(audiusUrl("tracks/trending", p))?.optJSONArray("data"))
    }

    // ───────── Jamendo
    private val jamendoOn get() = SonaraConfig.JAMENDO_CLIENT_ID.isNotBlank()

    private fun parseJamendo(arr: JSONArray?): List<Track> {
        if (arr == null) return emptyList()
        val out = ArrayList<Track>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val audio = o.optString("audio")
            if (audio.isBlank()) continue
            out.add(
                Track(
                    id = "ja_${o.optString("id")}",
                    title = o.optString("name", "Untitled"),
                    artist = o.optString("artist_name", "Unknown artist"),
                    album = o.optString("album_name"),
                    durationMs = o.optLong("duration", 0L) * 1000L,
                    artworkUrl = o.optString("image").takeIf { it.isNotBlank() },
                    streamUrl = audio,
                    source = TrackSource.CATALOGUE,
                    year = o.optString("releasedate").take(4).toIntOrNull(),
                    origin = "jamendo",
                )
            )
        }
        return out
    }

    private fun jamendoUrl(params: Map<String, String>): String {
        val b = "https://api.jamendo.com/v3.0/tracks/".toHttpUrl().newBuilder()
        b.addQueryParameter("client_id", SonaraConfig.JAMENDO_CLIENT_ID)
        b.addQueryParameter("format", "json")
        b.addQueryParameter("audioformat", "mp32")
        b.addQueryParameter("imagesize", "500")
        params.forEach { (k, v) -> b.addQueryParameter(k, v) }
        return b.build().toString()
    }

    suspend fun jamendoSearch(q: String, limit: Int = 25): List<Track> {
        if (!jamendoOn) return emptyList()
        return parseJamendo(getJson(jamendoUrl(mapOf("search" to q, "limit" to "$limit")))?.optJSONArray("results"))
    }

    suspend fun jamendoPopular(tag: String? = null, limit: Int = 20): List<Track> {
        if (!jamendoOn) return emptyList()
        val p = mutableMapOf("order" to "popularity_week", "limit" to "$limit")
        if (tag != null) p["tags"] = tag
        return parseJamendo(getJson(jamendoUrl(p))?.optJSONArray("results"))
    }

    // ───────── iTunes 30s previews (discovery for songs no open service carries)
    suspend fun itunesSearch(q: String, limit: Int = 25): List<Track> {
        val url = "https://itunes.apple.com/search".toHttpUrl().newBuilder()
            .addQueryParameter("term", q).addQueryParameter("media", "music")
            .addQueryParameter("entity", "song").addQueryParameter("limit", "$limit").build().toString()
        val arr = getJson(url)?.optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Track>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val preview = o.optString("previewUrl")
            if (preview.isBlank()) continue
            out.add(
                Track(
                    id = "it_${o.optLong("trackId")}",
                    title = o.optString("trackName", "Untitled"),
                    artist = o.optString("artistName", "Unknown artist"),
                    album = o.optString("collectionName"),
                    durationMs = 30_000L,
                    artworkUrl = o.optString("artworkUrl100").takeIf { it.isNotBlank() }?.replace("100x100", "600x600"),
                    streamUrl = preview,
                    source = TrackSource.CATALOGUE,
                    genre = o.optString("primaryGenreName").takeIf { it.isNotBlank() },
                    year = o.optString("releaseDate").take(4).toIntOrNull(),
                    isExplicit = o.optString("trackExplicitness") == "explicit",
                    previewOnly = true,
                    origin = "itunes",
                )
            )
        }
        return out
    }

    // ───────── combined
    /** Full-length streams first (Audius + Jamendo, interleaved), then 30s previews not already covered. */
    suspend fun search(q: String): List<Track> = coroutineScope {
        val a = async { audiusSearch(q) }
        val j = async { jamendoSearch(q) }
        val i = async { itunesSearch(q) }
        val full = interleave(a.await(), j.await())
        val seen = full.map { norm(it.title, it.artist) }.toHashSet()
        (full + i.await().filter { seen.add(norm(it.title, it.artist)) }).distinctBy { it.id }
    }

    /** Home rows: trending weekly across genres. Empty rows are dropped. */
    suspend fun homeRows(): List<Pair<String, List<Track>>> = coroutineScope {
        val jobs = listOf(
            "Trending on Audius" to async { audiusTrending() },
            "Phonk & drift" to async { audiusSearch("phonk", 20) },
            "Hip-Hop / Rap" to async { audiusTrending("Hip-Hop/Rap") },
            "Electronic" to async { audiusTrending("Electronic") },
            "Lo-Fi" to async { audiusTrending("Lo-Fi") },
            "Pop" to async { audiusTrending("Pop") },
            "R&B / Soul" to async { audiusTrending("R&B/Soul") },
            "Rock" to async { audiusTrending("Rock") },
            "Popular on Jamendo" to async { jamendoPopular() },
        )
        jobs.map { (t, d) -> t to d.await() }.filter { it.second.isNotEmpty() }
    }

    private fun norm(t: String, a: String) = (t + "|" + a).lowercase().filter { it.isLetterOrDigit() || it == '|' }

    private fun interleave(a: List<Track>, b: List<Track>): List<Track> {
        val out = ArrayList<Track>(a.size + b.size)
        var i = 0
        while (i < a.size || i < b.size) {
            if (i < a.size) out.add(a[i])
            if (i < b.size) out.add(b[i])
            i++
        }
        return out
    }
}
