package com.texgen.music.texwave.arena.ui.camera

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.texgen.music.texwave.arena.data.camera.PoseLandmarkerHelper
import com.texgen.music.texwave.arena.data.model.ActivitySource
import com.texgen.music.texwave.arena.data.model.ActivityType
import com.texgen.music.texwave.arena.data.repository.ArenaModule
import com.texgen.music.texwave.arena.domain.PushUpDetectionEngine
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Live camera push-up workout.
 *
 * Pose runs on-device via MediaPipe. Frames are not uploaded.
 * Finishing a session submits count through [ArenaModule.repository.logActivity]
 * with source MANUAL unless server RPC later accepts a separate camera evidence path.
 * Client never self-awards XP or marks is_verified.
 */
@Composable
fun CameraWorkoutScreen(
    onClose: () -> Unit,
    onSessionSubmitted: (reps: Int) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var permissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { permissionGranted = it }

    LaunchedEffect(Unit) {
        if (!permissionGranted) permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    val engine = remember { PushUpDetectionEngine() }
    var detection by remember { mutableStateOf(engine.currentState()) }
    var running by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    var useFront by remember { mutableStateOf(true) }
    var poseError by remember { mutableStateOf<String?>(null) }
    var submitting by remember { mutableStateOf(false) }
    var submitMessage by remember { mutableStateOf<String?>(null) }
    val analyzing = remember { AtomicBoolean(false) }

    val poseHelper = remember {
        PoseLandmarkerHelper(context) { err -> poseError = err }
    }

    DisposableEffect(Unit) {
        onDispose {
            poseHelper.close()
            engine.reset()
        }
    }

    LaunchedEffect(running, paused) {
        if (!running || paused) return@LaunchedEffect
        val start = System.currentTimeMillis() - elapsedMs
        while (running && !paused) {
            elapsedMs = System.currentTimeMillis() - start
            delay(250)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (!permissionGranted) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Camera permission required", color = ArenaColors.Text, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Cyan, contentColor = Color.Black)
                ) { Text("Grant camera") }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onClose) { Text("Close", color = ArenaColors.Muted) }
            }
            return@Box
        }

        // Camera preview + analysis
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    bindCamera(
                        cameraProvider = cameraProvider,
                        lifecycleOwner = lifecycleOwner,
                        previewView = previewView,
                        useFront = useFront,
                        running = { running && !paused },
                        analyzing = analyzing,
                        poseHelper = poseHelper,
                        engine = engine,
                        onDetection = { detection = it },
                        onPoseError = { poseError = it }
                    )
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            update = { previewView ->
                val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    bindCamera(
                        cameraProvider = cameraProvider,
                        lifecycleOwner = lifecycleOwner,
                        previewView = previewView,
                        useFront = useFront,
                        running = { running && !paused },
                        analyzing = analyzing,
                        poseHelper = poseHelper,
                        engine = engine,
                        onDetection = { detection = it },
                        onPoseError = { poseError = it }
                    )
                }, ContextCompat.getMainExecutor(context))
            }
        )

        // HUD
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, null, tint = Color.White)
                }
                Text(
                    "CAMERA SESSION",
                    color = ArenaColors.Cyan,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    fontSize = 12.sp
                )
                IconButton(onClick = { useFront = !useFront }) {
                    Icon(Icons.Filled.Cameraswitch, null, tint = Color.White)
                }
            }

            Spacer(Modifier.weight(1f))

            // Counter card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .arenaGlassCard(20)
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "${detection.repCount}",
                    color = ArenaColors.Text,
                    fontSize = 64.sp,
                    fontWeight = FontWeight.Bold
                )
                Text("REPS", color = ArenaColors.Muted, fontSize = 13.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    formatTime(elapsedMs),
                    color = ArenaColors.Cyan,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(8.dp))
                val statusColor = if (detection.trackingOk) ArenaColors.Success else ArenaColors.Warning
                Text(
                    if (detection.trackingOk) "Tracking" else "Seeking pose",
                    color = statusColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    detection.feedback,
                    color = ArenaColors.Muted,
                    fontSize = 13.sp
                )
                detection.averageElbowAngleDeg?.let {
                    Text("Elbow ∠ ${it.toInt()}°", color = ArenaColors.Muted, fontSize = 11.sp)
                }
                if (poseError != null) {
                    Text(poseError!!, color = ArenaColors.Magenta, fontSize = 11.sp)
                }
                if (!poseHelper.available) {
                    Text(
                        "Pose model missing — place pose_landmarker_lite.task in assets",
                        color = ArenaColors.Magenta,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                if (!running) {
                    Button(
                        onClick = {
                            engine.reset()
                            detection = engine.currentState()
                            elapsedMs = 0L
                            running = true
                            paused = false
                            submitMessage = null
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ArenaColors.Cyan,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Text("  Start")
                    }
                } else {
                    Button(
                        onClick = { paused = !paused },
                        colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Violet)
                    ) {
                        Icon(if (paused) Icons.Filled.PlayArrow else Icons.Filled.Pause, null)
                        Text(if (paused) "  Resume" else "  Pause")
                    }
                    Button(
                        onClick = {
                            running = false
                            paused = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Magenta)
                    ) {
                        Icon(Icons.Filled.Stop, null, modifier = Modifier.size(18.dp))
                        Text("  Finish")
                    }
                }
            }

            if (!running && detection.repCount > 0) {
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        if (submitting) return@Button
                        submitting = true
                        scope.launch {
                            // Secure path: same logActivity RPC — server decides XP.
                            // Source stays non-verified until server evidence API exists.
                            val result = ArenaModule.repository.logActivity(
                                count = detection.repCount,
                                type = ActivityType.PUSH_UPS,
                                source = ActivitySource.MANUAL,
                                note = "camera_session:${UUID.randomUUID()}"
                            )
                            submitting = false
                            result.fold(
                                onSuccess = {
                                    submitMessage = "Submitted ${it.count} reps · +${it.xpAwarded} XP (server)"
                                    onSessionSubmitted(it.count)
                                },
                                onFailure = {
                                    submitMessage = it.message ?: "Submit failed"
                                }
                            )
                        }
                    },
                    enabled = !submitting,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ArenaColors.Cyan,
                        contentColor = Color.Black
                    )
                ) {
                    Text(
                        if (submitting) "Submitting…" else "Submit ${detection.repCount} reps to Synergy Arena",
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            submitMessage?.let {
                Text(it, color = ArenaColors.Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

private fun bindCamera(
    cameraProvider: ProcessCameraProvider,
    lifecycleOwner: androidx.lifecycle.LifecycleOwner,
    previewView: PreviewView,
    useFront: Boolean,
    running: () -> Boolean,
    analyzing: AtomicBoolean,
    poseHelper: PoseLandmarkerHelper,
    engine: PushUpDetectionEngine,
    onDetection: (PushUpDetectionEngine.DetectionState) -> Unit,
    onPoseError: (String) -> Unit
) {
    try {
        cameraProvider.unbindAll()
        val preview = Preview.Builder().build().also { p ->
            p.setSurfaceProvider(previewView.surfaceProvider)
        }
        val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()

        analysis.setAnalyzer(Dispatchers.Default.asExecutor()) { imageProxy ->
            if (!running() || !poseHelper.available || !analyzing.compareAndSet(false, true)) {
                imageProxy.close()
                return@setAnalyzer
            }
            try {
                val bitmap = imageProxy.toBitmapSafe()
                if (bitmap != null) {
                    val frame = poseHelper.detect(bitmap)
                    if (frame != null) {
                        val state = engine.onPose(frame)
                        // post to main implicitly via state snapshot in compose
                        onDetection(state)
                    }
                    bitmap.recycle()
                }
            } catch (t: Throwable) {
                onPoseError(t.message ?: "analyze error")
            } finally {
                analyzing.set(false)
                imageProxy.close()
            }
        }

        val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
        else CameraSelector.DEFAULT_BACK_CAMERA
        cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview, analysis)
    } catch (t: Throwable) {
        onPoseError(t.message ?: "Camera bind failed")
    }
}

private fun androidx.camera.core.ImageProxy.toBitmapSafe(): Bitmap? {
    return try {
        val plane = planes[0]
        val buffer = plane.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(bytes))
        val rotation = imageInfo.rotationDegrees
        if (rotation != 0) {
            val m = Matrix().apply { postRotate(rotation.toFloat()) }
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true).also {
                if (it != bmp) bmp.recycle()
            }
        } else bmp
    } catch (_: Throwable) {
        null
    }
}

private fun formatTime(ms: Long): String {
    val s = (ms / 1000) % 60
    val m = (ms / 1000) / 60
    return "%02d:%02d".format(m, s)
}
