package com.texgen.music.texwave.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import com.texgen.music.texwave.AlarmRingActivity
import com.texgen.music.texwave.MainActivity
import com.texgen.music.texwave.R
import org.json.JSONArray
import java.util.Calendar

class TexwaveAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val act = intent.action
        // Storage is still locked at LOCKED_BOOT; BOOT_COMPLETED follows once the user unlocks.
        if (act == Intent.ACTION_LOCKED_BOOT_COMPLETED) return
        if (act == Intent.ACTION_BOOT_COMPLETED ||
            act == "android.intent.action.QUICKBOOT_POWERON" ||
            act == Intent.ACTION_MY_PACKAGE_REPLACED ||
            act == Intent.ACTION_TIMEZONE_CHANGED ||
            act == Intent.ACTION_TIME_CHANGED ||
            act == Intent.ACTION_DATE_CHANGED
        ) {
            runCatching { com.texgen.music.texwave.data.AlarmEngine.rescheduleAll(context) }
            try {
                com.texgen.music.texwave.player.WakeWordService.startIfEnabled(context)
            } catch (_: Exception) {
            }
            return
        }
        val id = intent.getIntExtra("alarm_id", 0)
        // Two independent exact alarms are armed per alarm (clock + backup); only ring once per firing.
        val fireKey = "last_fire_" + id + if (intent.getBooleanExtra("alarm_snoozed", false)) "_s" else ""
        val fp = context.getSharedPreferences("texwave_alarms", Context.MODE_PRIVATE)
        val nowMs = System.currentTimeMillis()
        if (nowMs - fp.getLong(fireKey, 0L) in 0..45_000L) return
        fp.edit().putLong(fireKey, nowMs).apply()
        val label = intent.getStringExtra("alarm_label") ?: "AUVYRR Alarm"
        val soundExtra = intent.getStringExtra("alarm_sound").orEmpty()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        // Foreground service owns the sound/vibration so the alarm rings even if the UI can't open.
        runCatching { AlarmRingService.start(context, id, label, soundExtra) }

        val silent = soundExtra == "silent"
        val soundUri: Uri = when {
            soundExtra.isNotBlank() && !silent -> Uri.parse(soundExtra)
            else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val channelId = when {
                silent -> "texwave_alarm_silent"
                soundExtra.isNotBlank() -> "texwave_alarm_custom_$id"
                else -> CHANNEL
            }
            manager.createNotificationChannel(
                NotificationChannel(channelId, "AUVYRR Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(null, null) // AlarmRingService plays the sound
                    enableVibration(true)
                    setBypassDnd(true)
                    lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                },
            )
        }

        val channelId = when {
            silent -> "texwave_alarm_silent"
            soundExtra.isNotBlank() -> "texwave_alarm_custom_$id"
            else -> CHANNEL
        }

        // Full-screen alarm activity — this is the primary UX
        val fullScreenIntent = Intent(context, AlarmRingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_NO_USER_ACTION
            putExtra(AlarmRingActivity.EXTRA_ALARM_ID, id)
            putExtra(AlarmRingActivity.EXTRA_LABEL, label)
            putExtra(AlarmRingActivity.EXTRA_SOUND, soundExtra)
        }
        val fullScreenPi = PendingIntent.getActivity(
            context, id + 1000, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val openApp = PendingIntent.getActivity(
            context, id,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        // High-priority notification with full-screen intent (required on modern Android)
        val base = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle(label)
            .setContentText("Alarm is ringing — tap to open")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .setFullScreenIntent(fullScreenPi, true)
            .setSound(null) // sound handled by AlarmRingActivity
            .setOngoing(true)

        manager.notify(id, base.build())


        // Async: weather + spoken briefing, then update activity if still open
        val pending = goAsync()
        Thread {
            try {
                val prefs = context.getSharedPreferences("texwave_alarms", Context.MODE_PRIVATE)
                val city = prefs.getString("briefing_city", null)?.takeIf { it.isNotBlank() }
                    ?: context.getSharedPreferences("texwave_settings", Context.MODE_PRIVATE)
                        .getString("weather_city", "Delhi") ?: "Delhi"
                val cal = Calendar.getInstance()
                val hour = cal.get(Calendar.HOUR_OF_DAY)
                val minute = cal.get(Calendar.MINUTE)
                val timeStr = String.format("%02d:%02d", hour, minute)
                val dayName = cal.getDisplayName(
                    Calendar.DAY_OF_WEEK,
                    Calendar.LONG,
                    java.util.Locale.getDefault(),
                ) ?: ""
                val greeting = when (hour) {
                    in 5..11 -> "Good morning"
                    in 12..16 -> "Good afternoon"
                    in 17..20 -> "Good evening"
                    else -> "Hello"
                }
                var weatherLine = "Weather is unavailable right now."
                runCatching {
                    val report = kotlinx.coroutines.runBlocking {
                        com.texgen.music.texwave.data.WeatherHelper.forCity(city).getOrThrow()
                    }
                    weatherLine = report.spoken()
                }
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
                val battery = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
                val batteryLine = if (battery in 0..100) "Battery is at $battery percent." else ""
                val sayGreeting = prefs.getBoolean("say_greeting", true)
                val sayTime = prefs.getBoolean("say_time", true)
                val sayLabel = prefs.getBoolean("say_label", true)
                val sayWeather = prefs.getBoolean("say_weather", true)
                val sayBattery = prefs.getBoolean("say_battery", true)
                val briefing = buildString {
                    if (sayGreeting) append("$greeting. ")
                    if (sayTime) append("It's $dayName, $timeStr. ")
                    if (sayLabel) append("$label. ")
                    if (sayWeather) append(weatherLine)
                    if (sayBattery && batteryLine.isNotBlank()) append(" $batteryLine")
                    if (isEmpty()) append("Your AUVYRR alarm is ringing.")
                    else append(" Have a great day with AUVYRR.")
                }

                // Deliver briefing to the ringing activity (and keep a static fallback).
                // If the user already dismissed (weather can take a while) do NOT reopen the ring screen.
                try {
                    AlarmRingActivity.pendingBriefing = briefing
                    if (!AlarmRingService.running) throw IllegalStateException("already dismissed")
                    val withBrief = Intent(context, AlarmRingActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                        putExtra(AlarmRingActivity.EXTRA_ALARM_ID, id)
                        putExtra(AlarmRingActivity.EXTRA_LABEL, label)
                        putExtra(AlarmRingActivity.EXTRA_SOUND, soundExtra)
                        putExtra(AlarmRingActivity.EXTRA_BRIEFING, briefing)
                    }
                    context.startActivity(withBrief)
                } catch (_: Exception) {
                }

                if (!AlarmRingService.running) return@Thread
                // Update notification text
                val detailed = base
                    .setContentText(weatherLine.take(80))
                    .setStyle(NotificationCompat.BigTextStyle().bigText(briefing))
                    .setOngoing(false)
                    .build()
                manager.notify(id, detailed)
            } finally {
                pending.finish()
            }
        }.start()

        // Arm the next day (repeating) or switch off (one-time). Snooze rings don't change the schedule.
        if (!intent.getBooleanExtra("alarm_snoozed", false)) {
            runCatching { com.texgen.music.texwave.data.AlarmEngine.onFired(context, id) }
        }
    }

    private fun rescheduleDaily(context: Context, id: Int) {
        val prefs = context.getSharedPreferences("texwave_alarms", Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString("alarms", "[]")) }.getOrNull() ?: return
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getInt("id") != id) continue
            if (!o.optBoolean("daily") || !o.optBoolean("enabled", true)) return
            val hour = o.getInt("hour")
            val minute = o.getInt("minute")
            val label = o.optString("label", "AUVYRR Alarm")
            val sound = if (o.isNull("soundUri")) "" else o.optString("soundUri", "")
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.DAY_OF_YEAR, 1)
            }
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, TexwaveAlarmReceiver::class.java).apply {
                putExtra("alarm_id", id)
                putExtra("alarm_label", label)
                putExtra("alarm_sound", sound)
            }
            val pi = PendingIntent.getBroadcast(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                }
            } catch (_: Exception) {
                am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
            return
        }
    }

    private fun rescheduleSaved(context: Context) {
        val prefs = context.getSharedPreferences("texwave_alarms", Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString("alarms", "[]")) }.getOrNull() ?: return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!o.optBoolean("enabled", true)) continue
            val id = o.getInt("id")
            val hour = o.getInt("hour")
            val minute = o.getInt("minute")
            val label = o.optString("label", "AUVYRR Alarm")
            val sound = if (o.isNull("soundUri")) "" else o.optString("soundUri", "")
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(context, TexwaveAlarmReceiver::class.java).apply {
                putExtra("alarm_id", id)
                putExtra("alarm_label", label)
                putExtra("alarm_sound", sound)
            }
            val pi = PendingIntent.getBroadcast(
                context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                }
            } catch (_: Exception) {
                am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        }
    }

    companion object {
        private const val CHANNEL = "texwave_alarms"
    }
}
