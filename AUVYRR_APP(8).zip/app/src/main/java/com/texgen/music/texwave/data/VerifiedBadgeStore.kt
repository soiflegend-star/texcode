package com.texgen.music.texwave.data

import android.content.Context

/**
 * AUVYRR verified star — password unlock, shown after display names.
 * Marker in profile bio so friends see it too: [TW_VERIFIED]
 */
object VerifiedBadgeStore {
    const val PASSWORD = "soifstar"
    const val BIO_MARKER = "[TW_VERIFIED]"
    private const val PREFS = "texwave_verified"
    private const val KEY = "unlocked"

    fun isVerified(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false)

    fun unlock(context: Context, password: String): Boolean {
        if (password.trim() != PASSWORD) return false
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY, true).apply()
        return true
    }

    fun lock(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY, false).apply()
    }

    /** True if this profile is verified (bio marker or local unlock for self). */
    fun isProfileVerified(bio: String?, isSelf: Boolean = false, context: Context? = null): Boolean {
        if (bio?.contains(BIO_MARKER) == true) return true
        if (isSelf && context != null) return isVerified(context)
        return false
    }

    fun stripMarker(bio: String?): String =
        bio?.replace(BIO_MARKER, "")?.trim().orEmpty()

    fun withMarker(bio: String?): String {
        val clean = stripMarker(bio)
        return if (clean.isBlank()) BIO_MARKER else "$clean $BIO_MARKER"
    }
}
