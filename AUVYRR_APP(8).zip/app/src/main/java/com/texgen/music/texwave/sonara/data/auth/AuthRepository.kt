package com.texgen.music.texwave.sonara.data.auth

import com.texgen.music.texwave.sonara.data.UserProfile
import com.texgen.music.texwave.sonara.data.remote.SupabaseProvider
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Email auth via Supabase GoTrue.
 * When Supabase is not configured, exposes a local demo session so UI flows can be exercised.
 */
class AuthRepository {

    private val _session = MutableStateFlow<UserProfile?>(null)
    val session: StateFlow<UserProfile?> = _session.asStateFlow()

    val isBackendConfigured: Boolean get() = SupabaseProvider.isConfigured

    @Serializable
    data class ProfileRow(
        val id: String,
        val username: String,
        @SerialName("display_name") val displayName: String,
        @SerialName("avatar_url") val avatarUrl: String? = null,
        val bio: String? = null,
        @SerialName("is_premium") val isPremium: Boolean = false,
        @SerialName("free_downloads_remaining") val freeDownloadsRemaining: Int = 10,
    )

    suspend fun restoreSession() = withContext(Dispatchers.IO) {
        val client = SupabaseProvider.client ?: return@withContext
        try {
            val user = client.auth.currentUserOrNull() ?: return@withContext
            loadProfile(user.id)
        } catch (_: Exception) { }
    }

    suspend fun signUp(email: String, password: String, username: String, displayName: String): Result<UserProfile> =
        withContext(Dispatchers.IO) {
            val client = SupabaseProvider.client
            if (client == null) {
                // Demo mode: local-only session for acceptance testing without backend
                val demo = UserProfile(
                    id = "demo_user",
                    username = username.ifBlank { "listener" },
                    displayName = displayName.ifBlank { "Sonara Listener" },
                    email = email,
                    isPremium = false,
                    freeDownloadsRemaining = 10,
                )
                _session.value = demo
                return@withContext Result.success(demo)
            }
            try {
                client.auth.signUpWith(Email) {
                    this.email = email.trim()
                    this.password = password
                }
                val user = client.auth.currentUserOrNull()
                    ?: return@withContext Result.failure(IllegalStateException("Sign-up succeeded but no session"))
                // Upsert profile
                client.from("profiles").upsert(
                    mapOf(
                        "id" to user.id,
                        "username" to username.trim().lowercase(),
                        "display_name" to displayName.trim().ifBlank { username },
                    )
                )
                val profile = loadProfile(user.id)
                    ?: UserProfile(id = user.id, username = username, displayName = displayName, email = email)
                _session.value = profile
                Result.success(profile)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun signIn(email: String, password: String): Result<UserProfile> =
        withContext(Dispatchers.IO) {
            val client = SupabaseProvider.client
            if (client == null) {
                val demo = UserProfile(
                    id = "demo_user",
                    username = "listener",
                    displayName = "Sonara Listener",
                    email = email,
                    freeDownloadsRemaining = 10,
                )
                _session.value = demo
                return@withContext Result.success(demo)
            }
            try {
                client.auth.signInWith(Email) {
                    this.email = email.trim()
                    this.password = password
                }
                val user = client.auth.currentUserOrNull()
                    ?: return@withContext Result.failure(IllegalStateException("No session after sign-in"))
                val profile = loadProfile(user.id)
                    ?: UserProfile(id = user.id, username = user.email ?: "user", displayName = user.email ?: "User", email = user.email)
                _session.value = profile
                Result.success(profile)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        try {
            SupabaseProvider.client?.auth?.signOut()
        } catch (_: Exception) { }
        _session.value = null
    }

    private suspend fun loadProfile(userId: String): UserProfile? {
        val client = SupabaseProvider.client ?: return null
        return try {
            val row = client.from("profiles").select {
                filter { eq("id", userId) }
            }.decodeSingleOrNull<ProfileRow>()
            row?.let {
                UserProfile(
                    id = it.id,
                    username = it.username,
                    displayName = it.displayName,
                    avatarUrl = it.avatarUrl,
                    bio = it.bio ?: "",
                    isPremium = it.isPremium,
                    freeDownloadsRemaining = it.freeDownloadsRemaining,
                )
            }
        } catch (_: Exception) {
            null
        }
    }
}
