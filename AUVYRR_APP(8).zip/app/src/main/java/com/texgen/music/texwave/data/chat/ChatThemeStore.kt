package com.texgen.music.texwave.data.chat

import android.content.Context
import android.net.Uri

/**
 * Per-conversation chat themes (background + accent).
 * Editing requires the shared password [THEME_PASSWORD].
 * Themes are stored on-device so they apply when you open that chat.
 */
object ChatThemeStore {
    const val THEME_PASSWORD = "soifstar"

    data class Theme(
        val backgroundUri: String? = null,
        /** 0 = default cosmic, 1 = midnight, 2 = sunset, 3 = ocean, 4 = aurora, 5 = custom photo */
        val preset: Int = 0,
        val dim: Float = 0.55f,
    )

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("texwave_chat_themes", Context.MODE_PRIVATE)

    /** Look chosen in Themes & looks; used by every chat that has no look of its own. */
    fun defaultPreset(ctx: Context): Int = prefs(ctx).getInt("__default.preset", 0).coerceIn(0, 4)
    fun setDefaultPreset(ctx: Context, preset: Int) {
        prefs(ctx).edit().putInt("__default.preset", preset.coerceIn(0, 4)).apply()
    }

    fun get(ctx: Context, conversationId: String): Theme {
        val p = prefs(ctx)
        val key = conversationId
        return Theme(
            backgroundUri = p.getString("$key.bg", null),
            preset = p.getInt("$key.preset", defaultPreset(ctx)),
            dim = p.getFloat("$key.dim", 0.55f),
        )
    }

    fun set(ctx: Context, conversationId: String, theme: Theme) {
        prefs(ctx).edit()
            .putString("$conversationId.bg", theme.backgroundUri)
            .putInt("$conversationId.preset", theme.preset)
            .putFloat("$conversationId.dim", theme.dim)
            .apply()
    }

    /** The remote token (sb:...) a locally cached theme photo came from, so we don't re-download it. */
    fun remoteToken(ctx: Context, conversationId: String): String? = prefs(ctx).getString("$conversationId.remote", null)
    fun setRemoteToken(ctx: Context, conversationId: String, token: String?) {
        prefs(ctx).edit().putString("$conversationId.remote", token).apply()
    }

    fun clear(ctx: Context, conversationId: String) {
        prefs(ctx).edit()
            .remove("$conversationId.bg")
            .remove("$conversationId.preset")
            .remove("$conversationId.dim")
            .apply()
    }

    fun verifyPassword(input: String): Boolean =
        input.trim().equals(THEME_PASSWORD, ignoreCase = false)

    /** Share theme with the other person via a chat system payload. */
    fun encode(theme: Theme): String {
        // Only share http(s) backgrounds — content:// URIs are device-local
        val bg = theme.backgroundUri
            ?.takeIf { it.startsWith("http://") || it.startsWith("https://") || it.startsWith("sb:") }
            ?.replace("|", "")
            ?: ""
        // Custom photo without public URL → share preset colors (0–4) so both match
        val preset = when {
            theme.preset == 5 && bg.isBlank() -> 0
            theme.preset !in 0..5 -> 0
            else -> theme.preset
        }
        val dim = String.format(java.util.Locale.US, "%.2f", theme.dim.coerceIn(0.2f, 0.9f))
        return "TEXWAVE_THEME:$preset|$dim|$bg"
    }

    fun parse(body: String?): Theme? {
        if (body == null) return null
        val trimmed = body.trim()
        // Accept message that contains the token anywhere (safety)
        val idx = trimmed.indexOf("TEXWAVE_THEME:")
        if (idx < 0) return null
        val payload = trimmed.substring(idx).removePrefix("TEXWAVE_THEME:")
        val parts = payload.split("|")
        if (parts.isEmpty()) return null
        val preset = parts[0].toIntOrNull()?.coerceIn(0, 5) ?: 0
        val dim = parts.getOrNull(1)?.replace(",", ".")?.toFloatOrNull()?.coerceIn(0.2f, 0.9f) ?: 0.55f
        val bg = parts.getOrNull(2)?.takeIf {
            it.isNotBlank() && (it.startsWith("http://") || it.startsWith("https://") || it.startsWith("sb:"))
        }
        return Theme(preset = if (preset == 5 && bg == null) 0 else preset, dim = dim, backgroundUri = bg)
    }

    val presetNames = listOf(
        "Cosmic (default)",
        "Midnight",
        "Sunset",
        "Ocean",
        "Aurora",
        "Custom photo",
    )
}
