package com.texgen.music.texwave.veltrix.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.texgen.music.texwave.veltrix.data.VeltrixStore
import com.texgen.music.texwave.veltrix.model.VxAutomationStatus
import com.texgen.music.texwave.veltrix.model.VxNodeKind
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Schedules time-based Veltrix automations via AlarmManager
 * (same approach as existing AlarmEngine — reuses platform patterns).
 */
object VeltrixScheduler {

    private const val ACTION = "com.texgen.music.texwave.veltrix.RUN"
    private const val EXTRA_ID = "automation_id"

    fun scheduleEnabled(context: Context, store: VeltrixStore) {
        CoroutineScope(Dispatchers.IO).launch {
            store.load()
            store.automations.value
                .filter { it.status == VxAutomationStatus.ENABLED }
                .forEach { auto ->
                    val timeNode = auto.nodes.find { it.kind == VxNodeKind.TRIGGER_TIME } ?: return@forEach
                    val hour = timeNode.c("hour").toIntOrNull() ?: return@forEach
                    val minute = timeNode.c("minute").toIntOrNull() ?: 0
                    scheduleDaily(context, auto.id, hour, minute)
                }
        }
    }

    fun scheduleDaily(context: Context, automationId: String, hour: Int, minute: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context, automationId)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            } else {
                am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        } catch (_: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }

    fun cancel(context: Context, automationId: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(context, automationId))
    }

    private fun pending(context: Context, automationId: String): PendingIntent {
        val intent = Intent(context, VeltrixReceiver::class.java).apply {
            action = ACTION
            putExtra(EXTRA_ID, automationId)
        }
        return PendingIntent.getBroadcast(
            context,
            automationId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

class VeltrixReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getStringExtra("automation_id") ?: return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val store = VeltrixStore(context.applicationContext)
                store.load()
                val auto = store.getAutomation(id) ?: return@launch
                if (auto.status != VxAutomationStatus.ENABLED) return@launch
                val engine = VeltrixEngine(context.applicationContext, store)
                engine.run(auto, trigger = "schedule")
                // reschedule next day if still enabled
                val timeNode = auto.nodes.find { it.kind == VxNodeKind.TRIGGER_TIME }
                if (timeNode != null && timeNode.c("repeatDaily") != "false") {
                    val hour = timeNode.c("hour").toIntOrNull() ?: 8
                    val minute = timeNode.c("minute").toIntOrNull() ?: 0
                    VeltrixScheduler.scheduleDaily(context, auto.id, hour, minute)
                }
            } finally {
                pending.finish()
            }
        }
    }
}

class VeltrixBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val store = VeltrixStore(context.applicationContext)
        VeltrixScheduler.scheduleEnabled(context, store)
        // Also run boot-triggered automations
        CoroutineScope(Dispatchers.IO).launch {
            store.load()
            val engine = VeltrixEngine(context.applicationContext, store)
            store.automations.value
                .filter { it.status == VxAutomationStatus.ENABLED }
                .filter { auto -> auto.nodes.any { it.kind == VxNodeKind.TRIGGER_BOOT } }
                .forEach { engine.run(it, trigger = "boot") }
        }
    }
}
