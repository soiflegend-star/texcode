package com.texgen.music.texwave.ui.screens.universe

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Random
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** Render detail. Higher = smoother planets and more stars (and more GPU work). */
enum class CosmicQuality(val label: String, val segments: Int, val stars: Int, val belt: Int) {
    STANDARD("Standard", 48, 1800, 1200),
    HIGH("High", 80, 4200, 2800),
    ULTRA("Ultra", 128, 9000, 5200),
}

/** A body's position on screen, for tap picking and name labels. */
data class CosmicLabel(val name: String, val x: Float, val y: Float, val radiusPx: Float, val isStar: Boolean)

private class World(
    val name: String,
    val orbit: Float,
    val size: Float,
    val color: FloatArray,
    val speed: Float,
    val texture: String = "",
    val ring: Boolean = false,
    val atmo: Float = 0f,
    val kind: Float = 0f, // 1 = emissive star
)

private class DeepStar(val name: String, val x: Float, val y: Float, val z: Float, val size: Float, val color: FloatArray)

/**
 * Real-time OpenGL ES 2.0 solar system and deep-space viewer.
 * Procedural nebula sky, textured planets with atmosphere and soft day/night terminator, a glowing Sun,
 * Saturn's banded rings, an asteroid belt, orbit lines, a 1/4 core cutaway, follow-camera and tap picking.
 */
class Cosmic3DView(context: Context) : GLSurfaceView(context) {
    private val renderer = CosmicRenderer(context)
    private val main = Handler(Looper.getMainLooper())

    private var lastX = 0f
    private var lastY = 0f
    private var downX = 0f
    private var downY = 0f
    private var downAt = 0L
    private var moved = false
    private var pinchDist = 0f

    /** Called on the main thread when the user taps a planet or star. */
    var onPick: ((String) -> Unit)? = null

    /** Called on the main thread about 8 times a second with screen positions of all bodies. */
    var onLabels: ((List<CosmicLabel>) -> Unit)? = null

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        renderer.labelSink = { list -> main.post { onLabels?.invoke(list) } }
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun focusOn(name: String) { renderer.focusName = name }
    fun clearFocus() { renderer.focusName = "" }
    fun setCoreMode(enabled: Boolean) { renderer.core = enabled }
    fun setPaused(p: Boolean) { renderer.paused = p }
    fun setSpeed(s: Float) { renderer.speed = s }
    fun setOrbits(on: Boolean) { renderer.showOrbits = on }
    fun setQuality(q: CosmicQuality) { queueEvent { renderer.applyQuality(q) } }

    /** Renders the current view offscreen at [longSide] pixels and writes a PNG into the cache folder. */
    fun exportImage(context: Context, longSide: Int, onDone: (Result<File>) -> Unit) {
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        queueEvent {
            val result = renderer.exportImage(context, w, h, longSide)
            main.post { onDone(result) }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y; downX = e.x; downY = e.y
                downAt = System.currentTimeMillis(); moved = false
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_DOWN -> { pinchDist = spacing(e); moved = true }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 2) {
                    val d = spacing(e)
                    if (pinchDist > 0f && d > 0f) renderer.zoomBy(pinchDist / d)
                    pinchDist = d
                    moved = true
                } else {
                    val dx = e.x - lastX
                    val dy = e.y - lastY
                    if (!moved && (kotlin.math.abs(e.x - downX) > 14f || kotlin.math.abs(e.y - downY) > 14f)) moved = true
                    if (moved) renderer.rotate(dx * 0.35f, dy * 0.28f)
                    lastX = e.x; lastY = e.y
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!moved && System.currentTimeMillis() - downAt < 350) {
                    val px = e.x; val py = e.y
                    queueEvent {
                        val hit = renderer.pick(px, py)
                        if (hit != null) main.post { onPick?.invoke(hit) }
                    }
                }
                pinchDist = 0f
                performClick()
            }
            MotionEvent.ACTION_CANCEL -> pinchDist = 0f
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    private fun spacing(e: MotionEvent): Float {
        if (e.pointerCount < 2) return 0f
        val dx = e.getX(0) - e.getX(1)
        val dy = e.getY(0) - e.getY(1)
        return sqrt(dx * dx + dy * dy)
    }
}

private class CosmicRenderer(private val context: Context) : GLSurfaceView.Renderer {

    // ---- public controls (set from the UI thread)
    @Volatile var focusName: String = ""
    @Volatile var core: Boolean = false
    @Volatile var paused: Boolean = false
    @Volatile var speed: Float = 1f
    @Volatile var showOrbits: Boolean = true
    var labelSink: ((List<CosmicLabel>) -> Unit)? = null

    // ---- camera
    @Volatile private var yaw = -28f
    @Volatile private var pitch = 32f
    @Volatile private var distance = 17f
    @Volatile private var desired = 17f
    private val target = floatArrayOf(0f, 0f, 0f)
    private val goal = floatArrayOf(0f, 0f, 0f)

    private var vw = 1
    private var vh = 1
    private var time = 0f
    private var lastNs = 0L
    private var labelAt = 0L
    private var quality = CosmicQuality.HIGH
    private var maxPoint = 64f

    // ---- GL objects
    private var bodyProg = 0
    private var starProg = 0
    private var nebProg = 0
    private var lineProg = 0
    private var ringProg = 0
    private var sphere: FloatBuffer? = null
    private var sphereVerts = 0
    private var bgStars: FloatBuffer? = null
    private var bgCount = 0
    private var belt: FloatBuffer? = null
    private var beltCount = 0
    private var deepBuf: FloatBuffer? = null
    private var deepCount = 0
    private val sunGlow: FloatBuffer = floatBuf(floatArrayOf(0f, 0f, 0f, 1f, 1f, 0.62f, 0.25f))
    private val circle: FloatBuffer = makeCircle(128)
    private val ringStrip: FloatBuffer = makeRingStrip(96)
    private val quad: FloatBuffer = floatBuf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val textures = HashMap<String, Int>()

    // ---- scratch matrices
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val tmp = FloatArray(16)
    private val eye = FloatArray(3)
    private val clip = FloatArray(4)
    private val vec = floatArrayOf(0f, 0f, 0f, 1f)

    // ---- picking
    @Volatile private var screenItems: List<CosmicLabel> = emptyList()

    private val worlds = listOf(
        World("Sun", 0f, .42f, f(1f, .55f, .08f), 0f, "cosmic_sun", kind = 1f),
        World("Mercury", .82f, .075f, f(.55f, .56f, .58f), 2.7f, "cosmic_rock"),
        World("Venus", 1.08f, .095f, f(.88f, .58f, .25f), 2f, "cosmic_rock", atmo = .8f),
        World("Earth", 1.38f, .10f, f(.18f, .42f, 1f), 1.55f, "cosmic_earth", atmo = 1f),
        World("Mars", 1.72f, .086f, f(.75f, .18f, .10f), 1.18f, "cosmic_mars", atmo = .25f),
        World("Jupiter", 2.35f, .19f, f(.70f, .52f, .34f), .72f, "cosmic_jupiter", atmo = .45f),
        World("Saturn", 2.9f, .17f, f(.83f, .69f, .42f), .48f, "cosmic_saturn", ring = true, atmo = .4f),
        World("Uranus", 3.4f, .14f, f(.42f, .80f, .92f), .34f, "cosmic_neptune", atmo = .6f),
        World("Neptune", 3.85f, .135f, f(.18f, .32f, .92f), .26f, "cosmic_neptune", atmo = .6f),
        World("Pluto", 4.3f, .06f, f(.62f, .55f, .46f), .20f, "cosmic_rock"),
        World("Kepler-22 b", 4.85f, .085f, f(.28f, .55f, 1f), .16f, "cosmic_earth", atmo = .8f),
        World("Kepler-452 b", 5.25f, .095f, f(.40f, .55f, .95f), .13f, "cosmic_rock"),
        World("Proxima Centauri b", 5.65f, .065f, f(1f, .30f, .14f), .11f, "cosmic_mars"),
        World("WASP-12 b", 6.02f, .12f, f(.95f, .42f, .10f), .095f, "cosmic_jupiter", atmo = .5f),
        World("TOI-700 d", 6.42f, .075f, f(.28f, .78f, .62f), .08f, "cosmic_earth", atmo = .7f),
        World("TRAPPIST-1e", 6.82f, .095f, f(.60f, .36f, .82f), .07f, "cosmic_rock"),
    )

    private val deepStars = listOf(
        DeepStar("Sirius", -5.5f, 2.8f, -7.5f, .20f, f(.72f, .84f, 1f)),
        DeepStar("Proxima Centauri", 6.2f, -2.4f, -5.8f, .13f, f(1f, .34f, .20f)),
        DeepStar("Betelgeuse", -8.2f, 3.9f, -4.5f, .29f, f(1f, .22f, .12f)),
        DeepStar("Vega", 5.2f, 4.6f, -8.8f, .18f, f(.65f, .82f, 1f)),
        DeepStar("Polaris", -4.5f, 5.6f, -9f, .15f, f(1f, .92f, .68f)),
        DeepStar("Rigel", 8.5f, 2.5f, -7f, .24f, f(.52f, .72f, 1f)),
        DeepStar("Antares", 7.2f, -4.4f, -6.2f, .25f, f(1f, .25f, .12f)),
        DeepStar("TRAPPIST-1", -7f, -3.5f, -8.5f, .14f, f(1f, .34f, .18f)),
        DeepStar("Alpha Centauri A", 3.2f, 5f, -10f, .15f, f(1f, .82f, .55f)),
        DeepStar("Arcturus", 8f, 5f, -12f, .17f, f(1f, .55f, .28f)),
        DeepStar("Canopus", -9f, .5f, -13f, .21f, f(1f, .92f, .76f)),
        DeepStar("Deneb", 1f, 6.8f, -14f, .22f, f(.78f, .88f, 1f)),
        DeepStar("Mu Cephei", 9f, 5.8f, -15f, .26f, f(1f, .18f, .10f)),
        DeepStar("R136a1", 4f, -7f, -16f, .29f, f(.55f, .75f, 1f)),
        DeepStar("Pollux", 7f, 9f, -25f, .14f, f(1f, .72f, .42f)),
        DeepStar("Castor", -8f, 9f, -25f, .13f, f(.72f, .84f, 1f)),
        DeepStar("Bellatrix", 12f, 4f, -28f, .13f, f(.55f, .75f, 1f)),
        DeepStar("Alnilam", 13f, 2f, -29f, .16f, f(.58f, .78f, 1f)),
        DeepStar("Alnitak", -14f, 1f, -29f, .15f, f(.55f, .76f, 1f)),
        DeepStar("Shaula", 10f, -7f, -33f, .14f, f(.55f, .75f, 1f)),
    )

    // ------------------------------------------------------------------ controls

    fun rotate(dx: Float, dy: Float) {
        yaw -= dx
        pitch = (pitch + dy).coerceIn(-85f, 85f)
    }

    fun zoomBy(factor: Float) {
        desired = (desired * factor).coerceIn(0.35f, 34f)
        distance = (distance * factor).coerceIn(0.2f, 36f)
    }

    fun applyQuality(q: CosmicQuality) {
        quality = q
        if (bodyProg != 0) buildGeometry()
    }

    fun pick(x: Float, y: Float): String? {
        var best: CosmicLabel? = null
        var bestD = Float.MAX_VALUE
        for (it in screenItems) {
            val dx = it.x - x
            val dy = it.y - y
            val d = sqrt(dx * dx + dy * dy)
            val reach = max(it.radiusPx, 22f * context.resources.displayMetrics.density)
            if (d <= reach && d < bestD) { best = it; bestD = d }
        }
        return best?.name
    }

    // ------------------------------------------------------------------ GL lifecycle

    @Volatile private var broken = false

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        try {
            createGl()
            broken = false
        } catch (t: Throwable) {
            broken = true
            android.util.Log.e("CosmicGl", "GL setup failed", t)
        }
    }

    private fun createGl() {
        GLES20.glClearColor(0f, 0f, 0.01f, 1f)
        val range = FloatArray(2)
        GLES20.glGetFloatv(GLES20.GL_ALIASED_POINT_SIZE_RANGE, range, 0)
        maxPoint = range[1].coerceIn(16f, 512f)

        bodyProg = buildProgram(BODY_VS, BODY_FS)
        starProg = buildProgram(STAR_VS, STAR_FS)
        nebProg = buildProgram(NEB_VS, NEB_FS)
        lineProg = buildProgram(LINE_VS, LINE_FS)
        ringProg = buildProgram(RING_VS, RING_FS)
        buildGeometry()
        textures.clear()
        val sizes = mapOf(
            "cosmic_earth" to 2048, "cosmic_sun" to 2048, "cosmic_jupiter" to 2048,
            "cosmic_mars" to 2048, "cosmic_saturn" to 2048, "cosmic_rock" to 1024, "cosmic_neptune" to 1024,
        )
        for (n in worlds.map { it.texture }.filter { it.isNotBlank() }.distinct()) {
            val id = context.resources.getIdentifier(n, "drawable", context.packageName)
            if (id != 0) loadTexture(id, sizes[n] ?: 1024)?.let { textures[n] = it }
        }
        lastNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        vw = width.coerceAtLeast(1)
        vh = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, vw, vh)
    }

    override fun onDrawFrame(gl: GL10?) {
        if (broken) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            return
        }
        val now = System.nanoTime()
        val dt = ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNs = now
        if (!paused) time += dt * 0.4f * speed
        updateCamera(dt)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, vw, vh)
        renderScene(vw, vh, true)
    }

    // ------------------------------------------------------------------ geometry

    private fun buildGeometry() {
        val m = makeSphere(quality.segments)
        sphere = m.first
        sphereVerts = m.second
        val rnd = Random(7)

        // background stars on a unit sphere: x y z size r g b
        val bg = FloatArray(quality.stars * 7)
        for (i in 0 until quality.stars) {
            var x: Float; var y: Float; var z: Float; var l: Float
            do {
                x = rnd.nextFloat() * 2 - 1; y = rnd.nextFloat() * 2 - 1; z = rnd.nextFloat() * 2 - 1
                l = x * x + y * y + z * z
            } while (l > 1f || l < 0.05f)
            val inv = 1f / sqrt(l)
            val t = rnd.nextFloat()
            val bright = rnd.nextFloat()
            val size = if (bright > 0.985f) 4.2f else if (bright > 0.93f) 2.6f else 1.2f + rnd.nextFloat() * 0.9f
            val (r, g, b) = when {
                t < 0.55f -> Triple(0.85f, 0.9f, 1f)
                t < 0.75f -> Triple(0.65f, 0.78f, 1f)
                t < 0.9f -> Triple(1f, 0.88f, 0.72f)
                else -> Triple(1f, 0.62f, 0.45f)
            }
            val o = i * 7
            bg[o] = x * inv; bg[o + 1] = y * inv; bg[o + 2] = z * inv
            bg[o + 3] = size
            val dim = 0.45f + 0.55f * bright
            bg[o + 4] = r * dim; bg[o + 5] = g * dim; bg[o + 6] = b * dim
        }
        bgStars = floatBuf(bg)
        bgCount = quality.stars

        // asteroid belt between Mars and Jupiter
        val bl = FloatArray(quality.belt * 7)
        for (i in 0 until quality.belt) {
            val a = rnd.nextFloat() * (2 * PI).toFloat()
            val r = 1.9f + rnd.nextFloat() * 0.2f + (rnd.nextFloat() - 0.5f) * 0.06f
            val o = i * 7
            bl[o] = cos(a) * r; bl[o + 1] = (rnd.nextFloat() - 0.5f) * 0.05f; bl[o + 2] = sin(a) * r
            bl[o + 3] = 0.012f + rnd.nextFloat() * 0.02f
            val tone = 0.35f + rnd.nextFloat() * 0.4f
            bl[o + 4] = tone * 1.0f; bl[o + 5] = tone * 0.86f; bl[o + 6] = tone * 0.7f
        }
        belt = floatBuf(bl)
        beltCount = quality.belt

        // named deep-space stars
        val ds = FloatArray(deepStars.size * 7)
        deepStars.forEachIndexed { i, s ->
            val o = i * 7
            ds[o] = s.x; ds[o + 1] = s.y; ds[o + 2] = s.z
            ds[o + 3] = s.size * 5.5f
            ds[o + 4] = s.color[0]; ds[o + 5] = s.color[1]; ds[o + 6] = s.color[2]
        }
        deepBuf = floatBuf(ds)
        deepCount = deepStars.size
    }

    private fun loadTexture(resId: Int, size: Int): Int? {
        val opts = BitmapFactory.Options().apply { inScaled = false }
        val src = BitmapFactory.decodeResource(context.resources, resId, opts) ?: return null
        val bmp = if (src.width != size || src.height != size / 2) {
            Bitmap.createScaledBitmap(src, size, size / 2, true).also { if (it !== src) src.recycle() }
        } else src
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        bmp.recycle()
        return ids[0]
    }

    // ------------------------------------------------------------------ camera

    private fun worldPos(i: Int, out: FloatArray) {
        val w = worlds[i]
        if (i == 0 || w.orbit == 0f) { out[0] = 0f; out[1] = 0f; out[2] = 0f; return }
        val a = time * w.speed + i * 0.72f
        out[0] = cos(a) * w.orbit; out[1] = 0f; out[2] = sin(a) * w.orbit
    }

    private val posTmp = FloatArray(3)

    private fun updateCamera(dt: Float) {
        val f = focusName
        var wantDist = 17f
        var found = false
        if (f.isNotEmpty()) {
            val wi = worlds.indexOfFirst { it.name == f }
            if (wi >= 0) {
                worldPos(wi, posTmp)
                goal[0] = posTmp[0]; goal[1] = posTmp[1]; goal[2] = posTmp[2]
                wantDist = max(worlds[wi].size * 6.5f, 0.75f)
                found = true
            } else {
                val si = deepStars.indexOfFirst { it.name == f }
                if (si >= 0) {
                    val s = deepStars[si]
                    goal[0] = s.x; goal[1] = s.y; goal[2] = s.z
                    wantDist = 4.2f
                    found = true
                }
            }
        }
        if (!found) { goal[0] = 0f; goal[1] = 0f; goal[2] = 0f }
        val k = min(1f, dt * 4.5f)
        for (i in 0..2) target[i] += (goal[i] - target[i]) * k
        // The focus distance is only applied when focus changes; pinch keeps working afterwards.
        if (focusApplied != f) {
            focusApplied = f
            desired = wantDist
        }
        distance += (desired - distance) * min(1f, dt * 3.5f)
    }

    private var focusApplied = ""

    // ------------------------------------------------------------------ drawing

    private fun renderScene(w: Int, h: Int, publish: Boolean) {
        val aspect = w.toFloat() / h.toFloat()
        val fovY = 46f
        Matrix.perspectiveM(proj, 0, fovY, aspect, 0.05f, 140f)
        val yr = Math.toRadians(yaw.toDouble())
        val pr = Math.toRadians(pitch.toDouble())
        eye[0] = target[0] + (sin(yr) * cos(pr)).toFloat() * distance
        eye[1] = target[1] + sin(pr).toFloat() * distance
        eye[2] = target[2] + (cos(yr) * cos(pr)).toFloat() * distance
        Matrix.setLookAtM(view, 0, eye[0], eye[1], eye[2], target[0], target[1], target[2], 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glDisable(GLES20.GL_CULL_FACE)

        drawNebula(aspect, tan(Math.toRadians(fovY / 2.0)).toFloat())

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val pxScale = h / 1080f
        // background stars follow the camera (sky box)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, eye[0], eye[1], eye[2])
        Matrix.scaleM(model, 0, 70f, 70f, 70f)
        drawPoints(bgStars, bgCount, model, (1.15f * pxScale).coerceAtLeast(0.8f), 0f, 0.9f)

        // orbit lines
        if (showOrbits) drawOrbits()

        // asteroid belt
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, time * 3f, 0f, 1f, 0f)
        drawPoints(belt, beltCount, model, (h * 0.5f) / tan(Math.toRadians(fovY / 2.0)).toFloat(), 1f, 0.95f)

        // named stars + sun glow (additive, no depth writes)
        val attenScale = (h * 0.5f) / tan(Math.toRadians(fovY / 2.0)).toFloat()
        Matrix.setIdentityM(model, 0)
        GLES20.glDepthMask(false)
        drawPoints(deepBuf, deepCount, model, attenScale, 1f, 1f)
        Matrix.setIdentityM(model, 0)
        drawPoints(sunGlow, 1, model, attenScale * 4.2f, 1f, 0.85f)
        GLES20.glDepthMask(true)

        // planets
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glUseProgram(bodyProg)
        val focus = focusName
        for (i in worlds.indices) {
            val wd = worlds[i]
            worldPos(i, posTmp)
            val rot = time * (20f + i * 3f)
            if (core && wd.name == focus) drawCutaway(wd, posTmp, rot) else drawBody(wd, posTmp, rot, 1f, 0f, wd.color, wd.texture)
        }

        // Saturn's rings
        val si = worlds.indexOfFirst { it.ring }
        if (si >= 0 && !(core && worlds[si].name == focus)) {
            worldPos(si, posTmp)
            drawRing(posTmp, worlds[si].size)
        }

        if (publish) publishScreen(w, h)
    }

    private fun drawNebula(aspect: Float, tanHalf: Float) {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glUseProgram(nebProg)
        // camera basis
        val fx = target[0] - eye[0]; val fy = target[1] - eye[1]; val fz = target[2] - eye[2]
        val fl = sqrt(fx * fx + fy * fy + fz * fz).coerceAtLeast(1e-4f)
        val f0 = fx / fl; val f1 = fy / fl; val f2 = fz / fl
        // right = f x up(0,1,0)
        var r0 = f1 * 0f - f2 * 1f; var r1 = f2 * 0f - f0 * 0f; var r2 = f0 * 1f - f1 * 0f
        val rl = sqrt(r0 * r0 + r1 * r1 + r2 * r2).coerceAtLeast(1e-4f)
        r0 /= rl; r1 /= rl; r2 /= rl
        val u0 = r1 * f2 - r2 * f1; val u1 = r2 * f0 - r0 * f2; val u2 = r0 * f1 - r1 * f0
        GLES20.glUniform3f(GLES20.glGetUniformLocation(nebProg, "uF"), f0, f1, f2)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(nebProg, "uR"), r0, r1, r2)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(nebProg, "uU"), u0, u1, u2)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(nebProg, "uAspect"), aspect)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(nebProg, "uTan"), tanHalf)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(nebProg, "uTime"), time)
        val a = GLES20.glGetAttribLocation(nebProg, "aPos")
        quad.position(0)
        GLES20.glEnableVertexAttribArray(a)
        GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(a)
    }

    /** Draws a point-sprite buffer laid out as x y z size r g b (stride 28). Additive blending. */
    private fun drawPoints(buf: FloatBuffer?, count: Int, modelM: FloatArray, scale: Float, atten: Float, alpha: Float) {
        if (buf == null || count <= 0) return
        GLES20.glUseProgram(starProg)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE)
        Matrix.multiplyMM(mvp, 0, vp, 0, modelM, 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(starProg, "uMvp"), 1, false, mvp, 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(starProg, "uScale"), scale)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(starProg, "uAtten"), atten)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(starProg, "uAlpha"), alpha)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(starProg, "uMaxPoint"), maxPoint)
        val ap = GLES20.glGetAttribLocation(starProg, "aPos")
        val asz = GLES20.glGetAttribLocation(starProg, "aSize")
        val ac = GLES20.glGetAttribLocation(starProg, "aColor")
        buf.position(0)
        GLES20.glEnableVertexAttribArray(ap)
        GLES20.glVertexAttribPointer(ap, 3, GLES20.GL_FLOAT, false, 28, buf)
        buf.position(3)
        GLES20.glEnableVertexAttribArray(asz)
        GLES20.glVertexAttribPointer(asz, 1, GLES20.GL_FLOAT, false, 28, buf)
        buf.position(4)
        GLES20.glEnableVertexAttribArray(ac)
        GLES20.glVertexAttribPointer(ac, 3, GLES20.GL_FLOAT, false, 28, buf)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, count)
        GLES20.glDisableVertexAttribArray(ap)
        GLES20.glDisableVertexAttribArray(asz)
        GLES20.glDisableVertexAttribArray(ac)
        buf.position(0)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun drawOrbits() {
        GLES20.glUseProgram(lineProg)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        val ap = GLES20.glGetAttribLocation(lineProg, "aPos")
        val um = GLES20.glGetUniformLocation(lineProg, "uMvp")
        val uc = GLES20.glGetUniformLocation(lineProg, "uColor")
        circle.position(0)
        GLES20.glEnableVertexAttribArray(ap)
        GLES20.glVertexAttribPointer(ap, 3, GLES20.GL_FLOAT, false, 0, circle)
        GLES20.glLineWidth(1.2f)
        for (i in 1 until worlds.size) {
            val wd = worlds[i]
            Matrix.setIdentityM(model, 0)
            Matrix.scaleM(model, 0, wd.orbit, 1f, wd.orbit)
            Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
            GLES20.glUniformMatrix4fv(um, 1, false, mvp, 0)
            val sel = wd.name == focusName
            val exo = i >= 10
            if (sel) GLES20.glUniform4f(uc, 0.35f, 0.9f, 1f, 0.75f)
            else if (exo) GLES20.glUniform4f(uc, 0.7f, 0.55f, 1f, 0.12f)
            else GLES20.glUniform4f(uc, 0.6f, 0.8f, 1f, 0.16f)
            GLES20.glDrawArrays(GLES20.GL_LINE_STRIP, 0, 129)
        }
        GLES20.glDisableVertexAttribArray(ap)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    private fun drawBody(wd: World, pos: FloatArray, rot: Float, scale: Float, cut: Float, color: FloatArray, tex: String) {
        val sph = sphere ?: return
        GLES20.glUseProgram(bodyProg)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, pos[0], pos[1], pos[2])
        if (wd.ring) Matrix.rotateM(model, 0, 26f, 0f, 0f, 1f)
        Matrix.rotateM(model, 0, rot, 0f, 1f, 0f)
        val s = wd.size * scale
        Matrix.scaleM(model, 0, s, s, s)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(bodyProg, "uMvp"), 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(bodyProg, "uModel"), 1, false, model, 0)
        GLES20.glUniform3fv(GLES20.glGetUniformLocation(bodyProg, "uColor"), 1, color, 0)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(bodyProg, "uCamera"), eye[0], eye[1], eye[2])
        GLES20.glUniform1f(GLES20.glGetUniformLocation(bodyProg, "uCut"), cut)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(bodyProg, "uAtmo"), wd.atmo)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(bodyProg, "uKind"), wd.kind)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(bodyProg, "uTime"), time)
        val id = textures[tex] ?: 0
        GLES20.glUniform1f(GLES20.glGetUniformLocation(bodyProg, "uUseTex"), if (id != 0) 1f else 0f)
        if (id != 0) {
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(bodyProg, "uTex"), 0)
        }
        val ap = GLES20.glGetAttribLocation(bodyProg, "aPos")
        val an = GLES20.glGetAttribLocation(bodyProg, "aNormal")
        val au = GLES20.glGetAttribLocation(bodyProg, "aUv")
        sph.position(0)
        GLES20.glEnableVertexAttribArray(ap)
        GLES20.glVertexAttribPointer(ap, 3, GLES20.GL_FLOAT, false, 32, sph)
        sph.position(3)
        GLES20.glEnableVertexAttribArray(an)
        GLES20.glVertexAttribPointer(an, 3, GLES20.GL_FLOAT, false, 32, sph)
        sph.position(6)
        GLES20.glEnableVertexAttribArray(au)
        GLES20.glVertexAttribPointer(au, 2, GLES20.GL_FLOAT, false, 32, sph)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, sphereVerts)
        GLES20.glDisableVertexAttribArray(ap)
        GLES20.glDisableVertexAttribArray(an)
        GLES20.glDisableVertexAttribArray(au)
        sph.position(0)
    }

    /** A quarter of the body removed to show nested layers: crust, mantle, outer core, inner core. */
    private fun drawCutaway(wd: World, pos: FloatArray, rot: Float) {
        val gas = wd.name in listOf("Jupiter", "Saturn", "Uranus", "Neptune", "WASP-12 b")
        val sun = wd.kind > 0.5f
        drawBody(wd, pos, rot, 1f, 1f, wd.color, wd.texture)
        val layers: List<Pair<Float, FloatArray>> = when {
            sun -> listOf(0.86f to f(1f, .62f, .12f), 0.58f to f(1f, .8f, .3f), 0.3f to f(1f, .96f, .7f))
            gas -> listOf(0.84f to f(.55f, .40f, .30f), 0.52f to f(.85f, .62f, .38f), 0.26f to f(1f, .85f, .55f))
            else -> listOf(0.88f to f(.55f, .22f, .08f), 0.56f to f(.95f, .45f, .08f), 0.29f to f(1f, .85f, .35f))
        }
        for ((sc, col) in layers) {
            val glowWorld = World(wd.name, wd.orbit, wd.size, col, 0f, "", false, 0f, if (sun) 1f else 0f)
            drawBody(glowWorld, pos, rot, sc, 1f, col, "")
        }
    }

    private fun drawRing(pos: FloatArray, planetSize: Float) {
        GLES20.glUseProgram(ringProg)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, pos[0], pos[1], pos[2])
        Matrix.rotateM(model, 0, 26f, 0f, 0f, 1f)
        val s = planetSize * 2.5f
        Matrix.scaleM(model, 0, s, s, s)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(ringProg, "uMvp"), 1, false, mvp, 0)
        val ap = GLES20.glGetAttribLocation(ringProg, "aPos")
        val at = GLES20.glGetAttribLocation(ringProg, "aT")
        ringStrip.position(0)
        GLES20.glEnableVertexAttribArray(ap)
        GLES20.glVertexAttribPointer(ap, 3, GLES20.GL_FLOAT, false, 16, ringStrip)
        ringStrip.position(3)
        GLES20.glEnableVertexAttribArray(at)
        GLES20.glVertexAttribPointer(at, 1, GLES20.GL_FLOAT, false, 16, ringStrip)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 2 * 97)
        GLES20.glDisableVertexAttribArray(ap)
        GLES20.glDisableVertexAttribArray(at)
        ringStrip.position(0)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    // ------------------------------------------------------------------ screen positions (tap + labels)

    private fun project(x: Float, y: Float, z: Float, w: Int, h: Int, out: FloatArray): Boolean {
        vec[0] = x; vec[1] = y; vec[2] = z; vec[3] = 1f
        Matrix.multiplyMV(clip, 0, vp, 0, vec, 0)
        if (clip[3] <= 0.01f) return false
        out[0] = (clip[0] / clip[3] * 0.5f + 0.5f) * w
        out[1] = (1f - (clip[1] / clip[3] * 0.5f + 0.5f)) * h
        out[2] = clip[3]
        return true
    }

    private val projOut = FloatArray(3)

    private fun publishScreen(w: Int, h: Int) {
        val list = ArrayList<CosmicLabel>(worlds.size + deepStars.size)
        val p5 = proj[5]
        for (i in worlds.indices) {
            worldPos(i, posTmp)
            if (!project(posTmp[0], posTmp[1], posTmp[2], w, h, projOut)) continue
            val r = worlds[i].size * p5 / projOut[2] * h * 0.5f
            list.add(CosmicLabel(worlds[i].name, projOut[0], projOut[1], r, false))
        }
        for (s in deepStars) {
            if (!project(s.x, s.y, s.z, w, h, projOut)) continue
            val r = s.size * 2.2f * p5 / projOut[2] * h * 0.5f
            list.add(CosmicLabel(s.name, projOut[0], projOut[1], r, true))
        }
        screenItems = list
        val now = System.currentTimeMillis()
        if (now - labelAt > 120) {
            labelAt = now
            labelSink?.invoke(list)
        }
    }

    // ------------------------------------------------------------------ export

    fun exportImage(ctx: Context, viewW: Int, viewH: Int, longSide: Int): Result<File> {
        val fbo = IntArray(1)
        val tex = IntArray(1)
        val depth = IntArray(1)
        return try {
            val maxTex = IntArray(1)
            GLES20.glGetIntegerv(GLES20.GL_MAX_RENDERBUFFER_SIZE, maxTex, 0)
            val cap = min(longSide, maxTex[0].coerceAtLeast(1024))
            val scale = cap.toFloat() / max(viewW, viewH).toFloat()
            val w = (viewW * scale).toInt().coerceAtLeast(64)
            val h = (viewH * scale).toInt().coerceAtLeast(64)

            GLES20.glGenFramebuffers(1, fbo, 0)
            GLES20.glGenTextures(1, tex, 0)
            GLES20.glGenRenderbuffers(1, depth, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glBindRenderbuffer(GLES20.GL_RENDERBUFFER, depth[0])
            GLES20.glRenderbufferStorage(GLES20.GL_RENDERBUFFER, GLES20.GL_DEPTH_COMPONENT16, w, h)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex[0], 0)
            GLES20.glFramebufferRenderbuffer(GLES20.GL_FRAMEBUFFER, GLES20.GL_DEPTH_ATTACHMENT, GLES20.GL_RENDERBUFFER, depth[0])
            if (GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER) != GLES20.GL_FRAMEBUFFER_COMPLETE) {
                throw IllegalStateException("This GPU cannot render an image that large.")
            }
            GLES20.glViewport(0, 0, w, h)
            renderScene(w, h, false)

            val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
            GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
            buf.position(0)
            val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            raw.copyPixelsFromBuffer(buf)
            val flip = android.graphics.Matrix().apply { preScale(1f, -1f) }
            val out = Bitmap.createBitmap(raw, 0, 0, w, h, flip, false)
            raw.recycle()
            val file = File(ctx.cacheDir, "cosmos_${System.currentTimeMillis()}_${w}x$h.png")
            FileOutputStream(file).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            out.recycle()
            Result.success(file)
        } catch (t: Throwable) {
            Result.failure(t)
        } finally {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            if (fbo[0] != 0) GLES20.glDeleteFramebuffers(1, fbo, 0)
            if (tex[0] != 0) GLES20.glDeleteTextures(1, tex, 0)
            if (depth[0] != 0) GLES20.glDeleteRenderbuffers(1, depth, 0)
            GLES20.glViewport(0, 0, vw, vh)
        }
    }

    // ------------------------------------------------------------------ shaders

    companion object {
        private const val PREC = "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"

        private const val NOISE = """
float hash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
float noise(vec3 p){
  vec3 i=floor(p); vec3 f=fract(p); f=f*f*(3.0-2.0*f);
  float a=mix(mix(hash(i),hash(i+vec3(1.0,0.0,0.0)),f.x),mix(hash(i+vec3(0.0,1.0,0.0)),hash(i+vec3(1.0,1.0,0.0)),f.x),f.y);
  float b=mix(mix(hash(i+vec3(0.0,0.0,1.0)),hash(i+vec3(1.0,0.0,1.0)),f.x),mix(hash(i+vec3(0.0,1.0,1.0)),hash(i+vec3(1.0,1.0,1.0)),f.x),f.y);
  return mix(a,b,f.z);
}
float fbm3(vec3 p){float v=0.0;float a=0.5;for(int i=0;i<3;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=0.5;}return v;}
float fbm(vec3 p){float v=0.0;float a=0.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.03+vec3(1.7,9.2,3.1);a*=0.5;}return v;}
"""

        private const val BODY_VS = """
attribute vec3 aPos; attribute vec3 aNormal; attribute vec2 aUv;
uniform mat4 uMvp; uniform mat4 uModel;
varying vec3 vN; varying vec3 vP; varying vec3 vLocal; varying vec2 vUv;
void main(){
  vN=normalize((uModel*vec4(aNormal,0.0)).xyz);
  vP=(uModel*vec4(aPos,1.0)).xyz;
  vLocal=aPos; vUv=aUv;
  gl_Position=uMvp*vec4(aPos,1.0);
}
"""

        private val BODY_FS = PREC + """
varying vec3 vN; varying vec3 vP; varying vec3 vLocal; varying vec2 vUv;
uniform vec3 uColor; uniform vec3 uCamera; uniform float uCut; uniform float uAtmo; uniform float uKind;
uniform float uTime; uniform sampler2D uTex; uniform float uUseTex;
""" + NOISE + """
void main(){
  if(uCut>0.5 && vLocal.x>0.0 && vLocal.z>0.0) discard;
  vec3 N=normalize(vN);
  vec3 V=normalize(uCamera-vP);
  vec3 L=normalize(-vP);
  vec3 tex=texture2D(uTex,vUv).rgb;
  float n=fbm(vLocal*6.0);
  vec3 albedo=uColor*(0.72+0.55*n);
  if(uUseTex>0.5) albedo=tex*1.22*mix(vec3(1.0),uColor*1.5,0.10);
  float ndl=dot(N,L);
  float lit=smoothstep(-0.16,0.38,ndl);
  float diff=max(ndl,0.0);
  vec3 H=normalize(L+V);
  float spec=pow(max(dot(N,H),0.0),42.0)*0.22*lit;
  float rim=pow(clamp(1.0-dot(N,V),0.0,1.0),2.4);
  vec3 atmo=mix(vec3(0.28,0.52,1.0),uColor,0.25)*rim*(0.18+0.82*lit)*uAtmo*1.35;
  vec3 c=albedo*(0.05+lit*(0.30+0.78*diff))+vec3(spec)+atmo;
  if(uKind>0.5){
    float g=fbm(vLocal*8.0+vec3(uTime*0.4));
    float limb=pow(max(dot(N,V),0.0),0.42);
    vec3 hot=mix(uColor,vec3(1.0,0.93,0.62),g);
    c=hot*(1.15+g*0.9)*limb*1.35;
    if(uUseTex>0.5) c*=mix(vec3(0.85),tex*1.5,0.65);
  }
  c=vec3(1.0)-exp(-c*1.35);
  gl_FragColor=vec4(c,1.0);
}
"""

        private const val STAR_VS = """
attribute vec3 aPos; attribute float aSize; attribute vec3 aColor;
uniform mat4 uMvp; uniform float uScale; uniform float uAtten; uniform float uMaxPoint;
varying vec3 vC;
void main(){
  vec4 p=uMvp*vec4(aPos,1.0);
  gl_Position=p;
  float s=aSize*uScale;
  s=s/mix(1.0,max(p.w,0.3),uAtten);
  gl_PointSize=clamp(s,1.0,uMaxPoint);
  vC=aColor;
}
"""

        private val STAR_FS = PREC + """
varying vec3 vC; uniform float uAlpha;
void main(){
  vec2 d=gl_PointCoord-vec2(0.5);
  float r=length(d)*2.0;
  if(r>1.0) discard;
  float core=exp(-r*r*16.0);
  float halo=exp(-r*r*3.4)*0.42;
  float spike=exp(-abs(d.x)*38.0)*exp(-abs(d.y)*5.0)*0.35+exp(-abs(d.y)*38.0)*exp(-abs(d.x)*5.0)*0.35;
  float a=(core+halo+spike*(1.0-r))*uAlpha;
  gl_FragColor=vec4(vC*a,a);
}
"""

        private const val NEB_VS = """
attribute vec2 aPos; varying vec2 vUv;
void main(){ vUv=aPos; gl_Position=vec4(aPos,0.999,1.0); }
"""

        private val NEB_FS = PREC + """
varying vec2 vUv;
uniform vec3 uF; uniform vec3 uR; uniform vec3 uU; uniform float uAspect; uniform float uTan; uniform float uTime;
""" + NOISE + """
void main(){
  vec3 dir=normalize(uF+uR*vUv.x*uAspect*uTan+uU*vUv.y*uTan);
  float n1=fbm3(dir*2.1+vec3(uTime*0.003));
  float n2=fbm3(dir*4.4+vec3(7.3,1.1,3.9));
  float n3=noise(dir*9.0+vec3(3.1,5.7,2.2));
  float haze=smoothstep(0.36,0.86,n1);
  vec3 col=mix(vec3(0.09,0.03,0.28),vec3(0.04,0.20,0.58),n2)*haze*1.25;
  float warm=smoothstep(0.55,0.92,fbm3(dir*3.0+vec3(11.0)))*smoothstep(0.28,0.7,n2);
  col+=vec3(0.62,0.22,0.08)*warm*0.6;
  col+=vec3(0.58,0.10,0.48)*smoothstep(0.60,0.9,n3)*0.28*haze;
  float bt=dir.y*2.3+0.28*sin(dir.x*3.1);
  float band=exp(-bt*bt*3.2);
  col+=vec3(0.72,0.62,0.95)*band*(0.05+0.14*n2);
  col*=1.0-0.45*smoothstep(0.5,0.8,noise(dir*6.2+vec3(2.0)))*band;
  gl_FragColor=vec4(col,1.0);
}
"""

        private const val LINE_VS = """
attribute vec3 aPos; uniform mat4 uMvp;
void main(){ gl_Position=uMvp*vec4(aPos,1.0); }
"""
        private val LINE_FS = PREC + """
uniform vec4 uColor;
void main(){ gl_FragColor=uColor; }
"""

        private const val RING_VS = """
attribute vec3 aPos; attribute float aT; uniform mat4 uMvp; varying float vT;
void main(){ vT=aT; gl_Position=uMvp*vec4(aPos,1.0); }
"""
        private val RING_FS = PREC + """
varying float vT;
void main(){
  float t=vT;
  float band=0.55+0.45*sin(t*70.0)*sin(t*27.0+1.3);
  float edge=smoothstep(0.0,0.05,t)*(1.0-smoothstep(0.94,1.0,t));
  float gap=1.0-smoothstep(0.0,0.035,abs(t-0.58))*0.0-(1.0-smoothstep(0.0,0.03,abs(t-0.58)))*0.85;
  vec3 c=mix(vec3(0.58,0.48,0.36),vec3(0.93,0.82,0.62),band);
  gl_FragColor=vec4(c*(0.72+0.28*band),0.78*edge*gap*(0.35+0.65*band));
}
"""

        private fun f(a: Float, b: Float, c: Float) = floatArrayOf(a, b, c)

        private fun floatBuf(a: FloatArray): FloatBuffer =
            ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(a); position(0) }

        private fun makeCircle(n: Int): FloatBuffer {
            val v = FloatArray((n + 1) * 3)
            for (i in 0..n) {
                val a = i.toFloat() / n * (2 * PI).toFloat()
                v[i * 3] = cos(a); v[i * 3 + 1] = 0f; v[i * 3 + 2] = sin(a)
            }
            return floatBuf(v)
        }

        /** Triangle strip of an annulus: x y z t (t: 0 inner edge .. 1 outer edge), outer radius 1. */
        private fun makeRingStrip(n: Int): FloatBuffer {
            val inner = 0.62f
            val v = FloatArray((n + 1) * 2 * 4)
            for (i in 0..n) {
                val a = i.toFloat() / n * (2 * PI).toFloat()
                val c = cos(a); val s = sin(a)
                val o = i * 8
                v[o] = c * inner; v[o + 1] = 0f; v[o + 2] = s * inner; v[o + 3] = 0f
                v[o + 4] = c; v[o + 5] = 0f; v[o + 6] = s; v[o + 7] = 1f
            }
            return floatBuf(v)
        }

        /** Interleaved x y z, nx ny nz, u v for a unit UV sphere, as plain triangles. */
        private fun makeSphere(seg: Int): Pair<FloatBuffer, Int> {
            val stacks = seg
            val slices = seg * 2
            val out = FloatArray(stacks * slices * 6 * 8)
            var o = 0
            fun put(i: Int, j: Int) {
                val lat = PI.toFloat() * i / stacks
                val lon = 2f * PI.toFloat() * j / slices
                val x = sin(lat) * cos(lon)
                val y = cos(lat)
                val z = sin(lat) * sin(lon)
                out[o++] = x; out[o++] = y; out[o++] = z
                out[o++] = x; out[o++] = y; out[o++] = z
                out[o++] = j.toFloat() / slices; out[o++] = i.toFloat() / stacks
            }
            for (i in 0 until stacks) {
                for (j in 0 until slices) {
                    put(i, j); put(i + 1, j); put(i + 1, j + 1)
                    put(i, j); put(i + 1, j + 1); put(i, j + 1)
                }
            }
            return floatBuf(out) to stacks * slices * 6
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(s)
                GLES20.glDeleteShader(s)
                throw IllegalStateException("Shader error: $log")
            }
            return s
        }

        private fun buildProgram(vs: String, fs: String): Int {
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) {
                val log = GLES20.glGetProgramInfoLog(p)
                GLES20.glDeleteProgram(p)
                throw IllegalStateException("Program link error: $log")
            }
            return p
        }
    }
}
