package com.texgen.music.texwave.data.chat

/**
 * AUVYRR Chat Empire — special message protocol.
 * All types travel as normal text bodies so existing sync keeps working.
 * Prefix: TEXWAVE_<TYPE>:payload
 */
object ChatEmpireProtocol {

    data class SongCard(val title: String, val artist: String, val songId: Long = 0L) {
        fun encode() = "TEXWAVE_SONG:${title.replace("|","/")}|${artist.replace("|","/")}|$songId"
        fun preview() = "🎵 $title — $artist"
    }

    data class LyricReply(val lyric: String, val songTitle: String) {
        fun encode() = "TEXWAVE_LYRIC:${lyric.take(280).replace("|","/")}|${songTitle.replace("|","/")}"
        fun preview() = "💬 “${lyric.take(48)}” · $songTitle"
    }

    data class Harmonic(val note: String, val hz: Int = 440) {
        fun encode() = "TEXWAVE_HARM:$note|$hz"
        fun preview() = "🎼 Harmonic · $note"
    }

    data class ListenTogether(val title: String, val artist: String, val host: String) {
        fun encode() = "TEXWAVE_LISTEN:${title.replace("|","/")}|${artist.replace("|","/")}|$host"
        fun preview() = "🎧 Listen together · $title"
    }

    data class CapsuleMsg(val title: String, val note: String, val opensAt: Long) {
        fun encode() = "TEXWAVE_CAPSULE:${title.replace("|","/")}|${note.replace("|","/")}|$opensAt"
        fun preview() = "⏳ Capsule · $title"
    }

    data class NightCrew(val name: String, val endsAt: Long) {
        fun encode() = "TEXWAVE_CREW:${name.replace("|","/")}|$endsAt"
        fun preview() = "🌙 Night crew · $name"
    }

    data class RoomTone(val tone: String) {
        fun encode() = "TEXWAVE_TONE:$tone"
        fun preview() = "🌫 Room · $tone"
    }

    data class Letter(val body: String) {
        fun encode() = "TEXWAVE_LETTER:${body.take(4000)}"
        fun preview() = "✉ Letter · ${body.take(40)}…"
    }

    data class Vote(val question: String, val options: List<String>, val id: String) {
        fun encode() = "TEXWAVE_VOTE:$id|${question.replace("|","/")}|${options.joinToString(";") { it.replace(";","/") }}"
        fun preview() = "🗳 $question"
    }

    data class VoteCast(val voteId: String, val option: String) {
        fun encode() = "TEXWAVE_VOTECAST:$voteId|${option.replace("|","/")}"
        fun preview() = "✓ Voted · $option"
    }

    data class Gaze(val targetMsg: String, val seconds: Int) {
        fun encode() = "TEXWAVE_GAZE:$targetMsg|$seconds"
        fun preview() = "👁 Opened for ${seconds}s"
    }

    data class DuetHalf(val part: Int, val title: String, val note: String) {
        fun encode() = "TEXWAVE_DUET:$part|${title.replace("|","/")}|${note.replace("|","/")}"
        fun preview() = "🎤 Duet part $part · $title"
    }

    data class SessionRecap(val songs: Int, val drawings: Int, val minutes: Int) {
        fun encode() = "TEXWAVE_RECAP:$songs|$drawings|$minutes"
        fun preview() = "🎞 Night recap · $songs tracks · ${minutes}m"
    }

    data class QuietShield(val keywords: String) {
        fun encode() = "TEXWAVE_SHIELD:${keywords.take(200)}"
        fun preview() = "🛡 Topic shield set"
    }

    data class TwoKey(val token: String) {
        fun encode() = "TEXWAVE_TWOKEY:$token"
        fun preview() = "🔐 Two-key vault message"
    }

    data class CoverDuel(val title: String, val side: String) {
        fun encode() = "TEXWAVE_COVER:${title.replace("|","/")}|$side"
        fun preview() = "⚔️ Cover duel · $title ($side)"
    }

    data class BeatSync(val bpm: Int) {
        fun encode() = "TEXWAVE_BEAT:$bpm"
        fun preview() = "💓 Beat sync · ${bpm} BPM"
    }

    data class PhantomSeat(val prompt: String) {
        fun encode() = "TEXWAVE_PHANTOM:${prompt.take(300)}"
        fun preview() = "👻 Phantom tagged"
    }

    data class Ambassador(val songTitle: String) {
        fun encode() = "TEXWAVE_AMB:${songTitle.replace("|","/")}"
        fun preview() = "🕊 Ambassador · $songTitle"
    }

    data class EnergyShare(val level: Int, val label: String) {
        fun encode() = "TEXWAVE_ENERGY:$level|$label"
        fun preview() = "⚡ Energy · $label"
    }

    /** Human preview for list + notifications. */
    fun preview(body: String?): String? {
        if (body.isNullOrBlank()) return null
        return when {
            body.startsWith("TEXWAVE_SONG:") -> parseSong(body)?.preview()
            body.startsWith("TEXWAVE_LYRIC:") -> parseLyric(body)?.preview()
            body.startsWith("TEXWAVE_HARM:") -> parseHarmonic(body)?.preview()
            body.startsWith("TEXWAVE_LISTEN:") -> parseListen(body)?.preview()
            body.startsWith("TEXWAVE_CAPSULE:") -> parseCapsule(body)?.preview()
            body.startsWith("TEXWAVE_CREW:") -> parseCrew(body)?.preview()
            body.startsWith("TEXWAVE_TONE:") -> parseTone(body)?.preview()
            body.startsWith("TEXWAVE_LETTER:") -> parseLetter(body)?.preview()
            body.startsWith("TEXWAVE_VOTE:") -> parseVote(body)?.preview()
            body.startsWith("TEXWAVE_VOTECAST:") -> parseVoteCast(body)?.preview()
            body.startsWith("TEXWAVE_GAZE:") -> parseGaze(body)?.preview()
            body.startsWith("TEXWAVE_DUET:") -> parseDuet(body)?.preview()
            body.startsWith("TEXWAVE_RECAP:") -> parseRecap(body)?.preview()
            body.startsWith("TEXWAVE_SHIELD:") -> parseShield(body)?.preview()
            body.startsWith("TEXWAVE_TWOKEY:") -> parseTwoKey(body)?.preview()
            body.startsWith("TEXWAVE_COVER:") -> parseCover(body)?.preview()
            body.startsWith("TEXWAVE_BEAT:") -> parseBeat(body)?.preview()
            body.startsWith("TEXWAVE_PHANTOM:") -> parsePhantom(body)?.preview()
            body.startsWith("TEXWAVE_AMB:") -> parseAmb(body)?.preview()
            body.startsWith("TEXWAVE_ENERGY:") -> parseEnergy(body)?.preview()
            else -> null
        }
    }

    fun parseSong(b: String): SongCard? {
        val p = b.removePrefix("TEXWAVE_SONG:").split("|")
        if (p.size < 2) return null
        return SongCard(p[0], p[1], p.getOrNull(2)?.toLongOrNull() ?: 0L)
    }
    fun parseLyric(b: String): LyricReply? {
        val p = b.removePrefix("TEXWAVE_LYRIC:").split("|")
        if (p.size < 2) return null
        return LyricReply(p[0], p[1])
    }
    fun parseHarmonic(b: String): Harmonic? {
        val p = b.removePrefix("TEXWAVE_HARM:").split("|")
        if (p.isEmpty()) return null
        return Harmonic(p[0], p.getOrNull(1)?.toIntOrNull() ?: 440)
    }
    fun parseListen(b: String): ListenTogether? {
        val p = b.removePrefix("TEXWAVE_LISTEN:").split("|")
        if (p.size < 2) return null
        return ListenTogether(p[0], p[1], p.getOrNull(2) ?: "")
    }
    fun parseCapsule(b: String): CapsuleMsg? {
        val p = b.removePrefix("TEXWAVE_CAPSULE:").split("|")
        if (p.size < 3) return null
        return CapsuleMsg(p[0], p[1], p[2].toLongOrNull() ?: 0L)
    }
    fun parseCrew(b: String): NightCrew? {
        val p = b.removePrefix("TEXWAVE_CREW:").split("|")
        if (p.size < 2) return null
        return NightCrew(p[0], p[1].toLongOrNull() ?: 0L)
    }
    fun parseTone(b: String): RoomTone? = RoomTone(b.removePrefix("TEXWAVE_TONE:"))
    fun parseLetter(b: String): Letter? = Letter(b.removePrefix("TEXWAVE_LETTER:"))
    fun parseVote(b: String): Vote? {
        val p = b.removePrefix("TEXWAVE_VOTE:").split("|")
        if (p.size < 3) return null
        return Vote(p[1], p[2].split(";").filter { it.isNotBlank() }, p[0])
    }
    fun parseVoteCast(b: String): VoteCast? {
        val p = b.removePrefix("TEXWAVE_VOTECAST:").split("|")
        if (p.size < 2) return null
        return VoteCast(p[0], p[1])
    }
    fun parseGaze(b: String): Gaze? {
        val p = b.removePrefix("TEXWAVE_GAZE:").split("|")
        if (p.size < 2) return null
        return Gaze(p[0], p[1].toIntOrNull() ?: 0)
    }
    fun parseDuet(b: String): DuetHalf? {
        val p = b.removePrefix("TEXWAVE_DUET:").split("|")
        if (p.size < 3) return null
        return DuetHalf(p[0].toIntOrNull() ?: 1, p[1], p[2])
    }
    fun parseRecap(b: String): SessionRecap? {
        val p = b.removePrefix("TEXWAVE_RECAP:").split("|")
        if (p.size < 3) return null
        return SessionRecap(p[0].toIntOrNull() ?: 0, p[1].toIntOrNull() ?: 0, p[2].toIntOrNull() ?: 0)
    }
    fun parseShield(b: String): QuietShield? = QuietShield(b.removePrefix("TEXWAVE_SHIELD:"))
    fun parseTwoKey(b: String): TwoKey? = TwoKey(b.removePrefix("TEXWAVE_TWOKEY:"))
    fun parseCover(b: String): CoverDuel? {
        val p = b.removePrefix("TEXWAVE_COVER:").split("|")
        if (p.size < 2) return null
        return CoverDuel(p[0], p[1])
    }
    fun parseBeat(b: String): BeatSync? = BeatSync(b.removePrefix("TEXWAVE_BEAT:").toIntOrNull() ?: 120)
    fun parsePhantom(b: String): PhantomSeat? = PhantomSeat(b.removePrefix("TEXWAVE_PHANTOM:"))
    fun parseAmb(b: String): Ambassador? = Ambassador(b.removePrefix("TEXWAVE_AMB:"))
    fun parseEnergy(b: String): EnergyShare? {
        val p = b.removePrefix("TEXWAVE_ENERGY:").split("|")
        if (p.size < 2) return null
        return EnergyShare(p[0].toIntOrNull() ?: 50, p[1])
    }
}
