package com.texgen.music.texwave.sonara.data.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore by preferencesDataStore("sonara_settings")

enum class AudioQuality(val label: String, val key: String) {
    DATA_SAVER("Data saver", "data_saver"),
    NORMAL("Normal", "normal"),
    HIGH("High", "high"),
    BEST("Best available", "best");
    companion object {
        fun fromKey(k: String?) = entries.find { it.key == k } ?: NORMAL
    }
}

class UserSettingsStore(private val context: Context) {
    private val onboardingDone = booleanPreferencesKey("onboarding_done")
    private val quality = stringPreferencesKey("audio_quality")
    private val crossfade = booleanPreferencesKey("crossfade")
    private val normalize = booleanPreferencesKey("normalize")
    private val downloadWifiOnlyKey = booleanPreferencesKey("download_wifi_only")

    val hasCompletedOnboarding: Flow<Boolean> =
        context.settingsStore.data.map { it[onboardingDone] ?: false }
    val audioQuality: Flow<AudioQuality> =
        context.settingsStore.data.map { AudioQuality.fromKey(it[quality]) }
    val crossfadeEnabled: Flow<Boolean> =
        context.settingsStore.data.map { it[crossfade] ?: false }
    val normalizeEnabled: Flow<Boolean> =
        context.settingsStore.data.map { it[normalize] ?: true }
    val downloadWifiOnly: Flow<Boolean> =
        context.settingsStore.data.map { it[downloadWifiOnlyKey] ?: true }

    suspend fun setOnboardingDone(done: Boolean = true) {
        context.settingsStore.edit { it[onboardingDone] = done }
    }
    suspend fun setAudioQuality(q: AudioQuality) {
        context.settingsStore.edit { it[quality] = q.key }
    }
    suspend fun setCrossfade(v: Boolean) {
        context.settingsStore.edit { it[crossfade] = v }
    }
    suspend fun setNormalize(v: Boolean) {
        context.settingsStore.edit { it[normalize] = v }
    }
    suspend fun setDownloadWifiOnly(v: Boolean) {
        context.settingsStore.edit { it[downloadWifiOnlyKey] = v }
    }
}
