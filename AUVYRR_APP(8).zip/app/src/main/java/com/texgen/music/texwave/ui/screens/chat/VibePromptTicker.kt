package com.texgen.music.texwave.ui.screens.chat

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** 20+ rotating icebreaker / mood lines — each stays ~2s, slides up + fades, next rises from below. */
private val VIBE_LINES = listOf(
    "How’s your day treating you?",
    "What’s the song on loop right now?",
    "One word for your mood — go.",
    "Who should you Wave to first?",
    "What made you smile today?",
    "Night owl or early bird right now?",
    "Drop a 🔥 if you’re free to chat",
    "What’s your current main character energy?",
    "Need a hype track or a soft one?",
    "Tell someone a random fact",
    "What are you avoiding today? 👀",
    "Rate this hour from 1–10",
    "Who’s your comfort artist?",
    "Text someone you miss (gently)",
    "What’s the vibe of your room rn?",
    "Study mode or chaos mode?",
    "Share the last reel that hit you",
    "If today had a soundtrack…?",
    "Who’s online that you’d say hi to?",
    "What’s one thing you’re proud of this week?",
    "Coffee, water, or nothing yet?",
    "Send a Wave before you overthink it",
)

/**
 * One quiet line above the input: a rotating idea. Tap it and the idea is typed into the box for you.
 */
@Composable
fun VibePromptTicker(
    modifier: Modifier = Modifier,
    intervalMs: Long = 3000L,
    onPick: ((String) -> Unit)? = null,
) {
    var index by remember { mutableIntStateOf((0 until VIBE_LINES.size).random()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(intervalMs)
            index = (index + 1) % VIBE_LINES.size
        }
    }

    Row(
        modifier
            .fillMaxWidth()
            .height(34.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(enabled = onPick != null) { onPick?.invoke(VIBE_LINES[index]) }
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Tap to type", color = Color(0xFF8A8F9C), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(10.dp))
        AnimatedContent(
            targetState = index,
            transitionSpec = {
                (fadeIn(tween(350)) + slideInVertically(tween(380)) { it / 2 }) togetherWith
                    (fadeOut(tween(250)) + slideOutVertically(tween(300)) { -it / 2 }) using SizeTransform(clip = true)
            },
            label = "vibeTicker",
            modifier = Modifier.weight(1f),
        ) { i ->
            Text(
                VIBE_LINES[i],
                color = Color(0xFFC9CDD6),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Start,
            )
        }
    }
}
