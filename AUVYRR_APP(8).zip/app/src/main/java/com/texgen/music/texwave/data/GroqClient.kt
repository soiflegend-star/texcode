package com.texgen.music.texwave.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Groq LLM client for PHANTOM online intelligence.
 * API key is stored only on-device in private prefs — never hardcoded.
 */
class GroqClient(context: Context) {
    private val prefs = context.getSharedPreferences("texwave_groq", Context.MODE_PRIVATE)
    private val appContext = context.applicationContext

    var apiKey: String
        get() = prefs.getString(KEY, "") ?: ""
        set(value) {
            val cleaned = value.trim().replace("\n", "").replace("\r", "").replace(" ", "")
            prefs.edit().putString(KEY, cleaned).commit()
        }

    private val syntra = SyntraClient(context)

    /**
     * True when online AI can work without the user doing anything: the SYNTRA gateway holds
     * the provider key. A key typed on the device is only an optional legacy fallback.
     */
    fun hasKey(): Boolean = true

    private fun hasLocalKey(): Boolean = apiKey.isNotBlank()

    private fun shouldFallback(e: Throwable?): Boolean {
        val m = e?.message?.lowercase() ?: return false
        // Always rotate models on not-found / decommission / rate-limit / overload
        if ("model_not_found" in m || "does not exist" in m || "decommission" in m) return true
        if ("model" in m && ("404" in m || "400" in m || "invalid" in m)) return true
        if (m.startsWith("groq 404") || m.startsWith("groq 400") || m.startsWith("groq 429") || m.startsWith("groq 503")) return true
        if ("not found" in m) return true
        return false
    }

    /** Live list of model ids the key can see (cached briefly). */
    @Volatile private var cachedModels: List<String>? = null
    @Volatile private var cachedAt = 0L

    private fun fetchAvailableModels(): List<String> {
        val now = System.currentTimeMillis()
        cachedModels?.let { if (now - cachedAt < 10 * 60_000L) return it }
        val key = apiKey
        if (key.isBlank()) return emptyList()
        return try {
            val conn = (URL("https://api.groq.com/openai/v1/models").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("Authorization", "Bearer $key")
                setRequestProperty("Accept", "application/json")
                connectTimeout = 8_000
                readTimeout = 10_000
            }
            if (conn.responseCode !in 200..299) return emptyList()
            val text = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).readText()
            val data = JSONObject(text).optJSONArray("data") ?: return emptyList()
            val ids = mutableListOf<String>()
            for (i in 0 until data.length()) {
                val id = data.optJSONObject(i)?.optString("id").orEmpty()
                if (id.isNotBlank()) ids += id
            }
            cachedModels = ids
            cachedAt = now
            ids
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun modelChain(preferred: String): List<String> {
        val available = fetchAvailableModels()
        val preferredList = (listOf(preferred) + FALLBACK_MODELS).distinct()
        if (available.isEmpty()) return preferredList
        // Prefer intersection in our preferred order, then any remaining chat models
        val hit = preferredList.filter { it in available }
        val extra = available.filter {
            it !in hit &&
                !it.contains("whisper", true) &&
                !it.contains("guard", true) &&
                !it.contains("orpheus", true) &&
                !it.contains("tts", true)
        }
        return (hit + extra).ifEmpty { preferredList }
    }

    /** Qwen-style reasoning models emit <think>…</think>; never show that to the user. */
    private fun clean(text: String): String =
        text.replace(Regex("(?s)<think>.*?</think>"), "").trim()

    suspend fun chat(
        system: String,
        user: String,
        model: String = DEFAULT_MODEL,
        temperature: Double = 0.4,
        maxTokens: Int = 1024,
    ): Result<String> {
        val viaSyntra = syntra.chat(listOf("system" to system, "user" to user), temperature, maxTokens)
        if (viaSyntra.isSuccess) return viaSyntra.map(::clean)
        if (!hasLocalKey()) return viaSyntra
        var last: Result<String> = Result.failure(IllegalStateException("No model available"))
        val chain = modelChain(model)
        for (m in chain) {
            last = chatOnce(system, user, m, temperature, maxTokens)
            if (last.isSuccess) return last.map(::clean)
            // Keep trying other models unless the key itself is invalid / missing
            val msg = last.exceptionOrNull()?.message.orEmpty().lowercase()
            if ("api key" in msg || "unauthorized" in msg || msg.startsWith("groq 401") || msg.startsWith("groq 403")) break
            if (!shouldFallback(last.exceptionOrNull()) && chain.size <= 1) break
        }
        return last
    }

    /** Multi-turn chat. [messages] are (role, content) pairs with role user / assistant / system. */
    suspend fun chatMessages(
        messages: List<Pair<String, String>>,
        model: String = DEFAULT_MODEL,
        temperature: Double = 0.6,
        maxTokens: Int = 1600,
    ): Result<String> {
        val viaSyntra = syntra.chat(messages, temperature, maxTokens)
        if (viaSyntra.isSuccess) return viaSyntra.map(::clean)
        if (!hasLocalKey()) return viaSyntra
        var last: Result<String> = Result.failure(IllegalStateException("No model available"))
        val chain = modelChain(model)
        for (m in chain) {
            last = chatMessagesOnce(messages, m, temperature, maxTokens)
            if (last.isSuccess) return last.map(::clean)
            val msg = last.exceptionOrNull()?.message.orEmpty().lowercase()
            if ("api key" in msg || "unauthorized" in msg || msg.startsWith("groq 401") || msg.startsWith("groq 403")) break
        }
        // Friendlier final error if every model 404'd
        val err = last.exceptionOrNull()?.message.orEmpty()
        if ("404" in err || "model" in err.lowercase()) {
            return Result.failure(
                IllegalStateException(
                    "Groq model unavailable for this key. Open console.groq.com → API keys, create a fresh key, paste it in Phantom settings. (Tried: ${chain.take(4).joinToString()})",
                ),
            )
        }
        return last
    }

    private suspend fun chatOnce(
        system: String,
        user: String,
        model: String = DEFAULT_MODEL,
        temperature: Double = 0.4,
        maxTokens: Int = 1024,
    ): Result<String> = withContext(Dispatchers.IO) {
        val key = apiKey
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Groq API key not set"))
        if (!NetworkGate.isOnline(appContext)) {
            return@withContext Result.failure(IllegalStateException("Internet required for PHANTOM"))
        }
        try {
            val body = JSONObject()
                .put("model", model)
                .put("temperature", temperature)
                .put("max_tokens", maxTokens)
                .put(
                    "messages",
                    JSONArray()
                        .put(JSONObject().put("role", "system").put("content", system))
                        .put(JSONObject().put("role", "user").put("content", user)),
                )
            val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Authorization", "Bearer $key")
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 20_000
                readTimeout = 45_000
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
            if (code !in 200..299) {
                val detail = try {
                    JSONObject(text).optJSONObject("error")?.optString("message")?.take(280)
                } catch (_: Exception) { null }
                val msg = detail ?: text.take(200)
                return@withContext Result.failure(Exception("Groq $code: $msg"))
            }
            val json = JSONObject(text)
            val content = json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
            Result.success(content)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    
    /** Multi-turn chat. [history] is list of role to content ("user"/"assistant"/"system"). */
    private suspend fun chatMessagesOnce(
        messages: List<Pair<String, String>>,
        model: String = DEFAULT_MODEL,
        temperature: Double = 0.5,
        maxTokens: Int = 1600,
    ): Result<String> = withContext(Dispatchers.IO) {
        val key = apiKey
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Groq API key not set"))
        try {
            val arr = JSONArray()
            messages.forEach { (role, content) ->
                arr.put(JSONObject().put("role", role).put("content", content))
            }
            val body = JSONObject()
                .put("model", model)
                .put("temperature", temperature)
                .put("max_tokens", maxTokens)
                .put("messages", arr)
            val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Authorization", "Bearer $key")
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 20_000
                readTimeout = 60_000
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
            if (code !in 200..299) {
                val detail = try {
                    JSONObject(text).optJSONObject("error")?.optString("message")?.take(280)
                } catch (_: Exception) { null }
                val msg = detail ?: text.take(200)
                return@withContext Result.failure(Exception("Groq $code: $msg"))
            }
            val json = JSONObject(text)
            val content = json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
            Result.success(content)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Rank / explain song picks for an emotion mode. */
    suspend fun emotionRank(
        modeLabel: String,
        candidates: List<Song>,
        limit: Int = 20,
    ): Result<List<Long>> {
        if (candidates.isEmpty()) return Result.success(emptyList())
        val catalog = candidates.take(80).joinToString("\n") {
            "${it.id}|${it.title}|${it.artist}|${it.durationMs / 1000}s"
        }
        val system = """You are AUVYRR PHANTOM, a precise mood-matching engine.
Return ONLY a JSON array of song ids (numbers) that truly fit the requested experience.
Rules:
- Match emotional energy, not just a word in the title.
- Rainy / mellow → slow, soft, ambient, ballads. Reject gym/hype/party tracks.
- Unstoppable / energy → high energy, anthems, strong beat. Reject lullabies and pure ambient.
- Night drive → cinematic, cruise, synth/night-city feel.
- Focus → instrumental/calm/lofi; avoid aggressive vocals.
- Prefer clear fits over filling the list. Fewer good ids is better than wrong ones.
No markdown, no commentary. Max $limit ids, best first."""
        val user = "Experience: $modeLabel\nLibrary (id|title|artist|duration):\n$catalog\n\nJSON array of matching ids only:"
        return chat(system, user, maxTokens = 400).mapCatching { raw ->
            val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val arr = JSONArray(cleaned)
            (0 until arr.length()).mapNotNull {
                when (val v = arr.get(it)) {
                    is Number -> v.toLong()
                    is String -> v.toLongOrNull()
                    else -> null
                }
            }.take(limit)
        }
    }

    /** Music DNA explanation + cluster labels. */
    suspend fun musicDnaExplain(songs: List<Song>): Result<String> {
        val sample = songs.take(40).joinToString("\n") {
            "${it.title} — ${it.artist} (${it.durationMs / 1000}s)"
        }
        val system = "You are AUVYRR Music DNA. Analyze taste patterns. Be vivid, concise, structured with short bullets."
        val user = "Local library sample:\n$sample\n\nDescribe hidden structure of this listener's taste (textures, energy, patterns)."
        return chat(system, user, maxTokens = 600)
    }

    /** Sound Detective — structural notes for one track. */
    suspend fun soundDetective(song: Song): Result<String> {
        val system = "You are AUVYRR Sound Detective. Infer likely structure from metadata. Mark times as estimates."
        val user = """Track: ${song.title}
Artist: ${song.artist}
Album: ${song.album}
Duration: ${song.durationMs / 1000}s

Give: estimated tempo range, likely sections with times, energy arc, listening tips."""
        return chat(system, user, maxTokens = 500)
    }

    /** Infinite Mix ordering rationale + preferred order of ids. */
    suspend fun infiniteMixOrder(songs: List<Song>): Result<List<Long>> {
        if (songs.size <= 2) return Result.success(songs.map { it.id })
        val catalog = songs.take(40).joinToString("\n") {
            "${it.id}|${it.title}|${it.artist}|${it.durationMs / 1000}s"
        }
        val system = """You are AUVYRR Infinite Mix. Order tracks for a coherent emotional arc.
Return ONLY a JSON array of all given song ids in play order. No markdown."""
        val user = "Tracks:\n$catalog\n\nOrdered JSON array of ids:"
        return chat(system, user, maxTokens = 500).mapCatching { raw ->
            val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val arr = JSONArray(cleaned)
            (0 until arr.length()).mapNotNull {
                when (val v = arr.get(it)) {
                    is Number -> v.toLong()
                    is String -> v.toLongOrNull()
                    else -> null
                }
            }
        }
    }

    /** Universe constellation labels between songs. */
    suspend fun universeLinks(seed: Song, neighbors: List<Song>): Result<String> {
        val list = neighbors.take(12).joinToString("\n") { "• ${it.title} — ${it.artist}" }
        val system = "You are AUVYRR Local Music Universe. Explain connections poetically but clearly."
        val user = "Seed: ${seed.title} — ${seed.artist}\nNearby in library:\n$list\n\nWhy these form a constellation:"
        return chat(system, user, maxTokens = 400)
    }

    /**
     * Vision: send an image + text instruction (describe / suggest edits / analyze).
     * Uses a vision-capable model when available.
     */
    suspend fun chatWithImage(
        system: String,
        userText: String,
        imageBytes: ByteArray,
        mime: String = "image/jpeg",
        model: String = VISION_MODEL,
        maxTokens: Int = 1200,
    ): Result<String> = withContext(Dispatchers.IO) {
        val key = apiKey
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Groq API key not set"))
        val b64 = android.util.Base64.encodeToString(imageBytes, android.util.Base64.NO_WRAP)
        val dataUrl = "data:$mime;base64,$b64"
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", userText))
            .put(
                JSONObject()
                    .put("type", "image_url")
                    .put("image_url", JSONObject().put("url", dataUrl)),
            )
        var last: Result<String> = Result.failure(IllegalStateException("No vision model available"))
        for (m in (listOf(model) + VISION_FALLBACKS).distinct()) {
            last = try {
                val body = JSONObject()
                    .put("model", m)
                    .put("temperature", 0.3)
                    .put("max_tokens", maxTokens)
                    .put(
                        "messages",
                        JSONArray()
                            .put(JSONObject().put("role", "system").put("content", system))
                            .put(JSONObject().put("role", "user").put("content", content)),
                    )
                val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                    connectTimeout = 25_000
                    readTimeout = 90_000
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                if (code !in 200..299) {
                    val detail = try {
                        JSONObject(text).optJSONObject("error")?.optString("message")?.take(280)
                    } catch (_: Exception) { null }
                    Result.failure(Exception("Groq $code: ${detail ?: text.take(200)}"))
                } else {
                    val contentOut = JSONObject(text)
                        .getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                    Result.success(clean(contentOut))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
            if (last.isSuccess) return@withContext last
            if (!shouldFallback(last.exceptionOrNull())) return@withContext last
        }
        last
    }

    companion object {
        const val KEY = "api_key"
        const val ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"
        /**
         * Groq model IDs (Nov 2026). Free/developer tier favors openai/gpt-oss-* and qwen.
         * Llama 3.3/3.1 may be enterprise-only — keep them as last resorts.
         * Chain on 404 / model_not_found so Phantom still answers.
         */
        // Prefer free/public chat models first (Nov 2026)
        const val VISION_MODEL = "openai/gpt-oss-20b"
        const val DEFAULT_MODEL = "openai/gpt-oss-20b"
        val FALLBACK_MODELS = listOf(
            "openai/gpt-oss-20b",
            "openai/gpt-oss-120b",
            "qwen/qwen3.8-27b",
            "allam-2-7b",
            "openai/gpt-oss-safeguard-20b",
            "llama-3.1-8b-instant",
            "llama-3.3-70b-versatile",
        )
        val VISION_FALLBACKS = listOf(
            "openai/gpt-oss-20b",
            "openai/gpt-oss-120b",
            "qwen/qwen3.8-27b",
            "allam-2-7b",
        )
    }
}
