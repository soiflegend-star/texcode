package com.texgen.music.texwave.brain

/** How a model expects its chat prompt to be written. */
enum class PromptStyle { CHATML, ZEPHYR, PHI, GEMMA }

/**
 * A "Brain" = a small language model that lives on the phone and answers with no internet.
 * People never see the word "LLM" — only Brain names, size, and how smart/fast it is.
 */
data class Brain(
    val id: String,
    val name: String,
    val tagline: String,
    val sizeLabel: String,
    val approxBytes: Long,
    val minRamGb: Int,
    val url: String,
    val fileName: String,
    val style: PromptStyle,
    val speed: String,
    val smarts: String,
    val recommended: Boolean = false,
    val custom: Boolean = false,
)

object BrainCatalog {
    private const val HF = "https://huggingface.co/litert-community"

    /** Only files whose name and size were checked on Hugging Face (public, no login needed). */
    val builtIn: List<Brain> = listOf(
        Brain(
            id = "pico",
            name = "Pico",
            tagline = "Smallest possible. Greets, simple chat, music commands.",
            sizeLabel = "170 MB",
            approxBytes = 167_000_000L,
            minRamGb = 2,
            url = "$HF/SmolLM-135M-Instruct/resolve/main/SmolLM-135M-Instruct_multi-prefill-seq_q8_ekv1280.task",
            fileName = "pico_smollm_135m_q8.task",
            style = PromptStyle.CHATML,
            speed = "Instant", smarts = "Very basic",
        ),
        Brain(
            id = "spark",
            name = "Spark",
            tagline = "Tiny and quick. Greets you, chats, plays music.",
            sizeLabel = "0.55 GB",
            approxBytes = 547_000_000L,
            minRamGb = 3,
            url = "$HF/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
            fileName = "spark_qwen25_05b_q8.task",
            style = PromptStyle.CHATML,
            speed = "Very fast", smarts = "Basic",
        ),
        Brain(
            id = "nova",
            name = "Nova",
            tagline = "Light and friendly everyday chat.",
            sizeLabel = "1.1 GB",
            approxBytes = 1_150_000_000L,
            minRamGb = 4,
            url = "$HF/TinyLlama-1.1B-Chat-v1.0/resolve/main/TinyLlama-1.1B-Chat-v1.0_multi-prefill-seq_q8_ekv1280.task",
            fileName = "nova_tinyllama_11b_q8.task",
            style = PromptStyle.ZEPHYR,
            speed = "Fast", smarts = "Basic+",
        ),
        Brain(
            id = "atlas",
            name = "Atlas",
            tagline = "Best balance. Clear answers, follows music commands well.",
            sizeLabel = "1.6 GB",
            approxBytes = 1_600_000_000L,
            minRamGb = 4,
            url = "$HF/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task",
            fileName = "atlas_qwen25_15b_q8.task",
            style = PromptStyle.CHATML,
            speed = "Medium", smarts = "Good",
        ),
        Brain(
            id = "sparkpro",
            name = "Spark Pro",
            tagline = "Spark at full precision. Slightly cleaner wording.",
            sizeLabel = "2.0 GB",
            approxBytes = 1_990_000_000L,
            minRamGb = 4,
            url = "$HF/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_f32_ekv1280.task",
            fileName = "sparkpro_qwen25_05b_f32.task",
            style = PromptStyle.CHATML,
            speed = "Fast", smarts = "Basic+",
        ),
        Brain(
            id = "titan",
            name = "Titan",
            tagline = "Much smarter. Needs a strong phone.",
            sizeLabel = "3.9 GB",
            approxBytes = 3_940_000_000L,
            minRamGb = 8,
            url = "$HF/Phi-4-mini-instruct/resolve/main/Phi-4-mini-instruct_multi-prefill-seq_q8_ekv1280.task",
            fileName = "titan_phi4mini_q8.task",
            style = PromptStyle.PHI,
            speed = "Slower", smarts = "Great",
        ),
        Brain(
            id = "novapro",
            name = "Nova Pro",
            tagline = "Nova at full precision.",
            sizeLabel = "4.4 GB",
            approxBytes = 4_410_000_000L,
            minRamGb = 8,
            url = "$HF/TinyLlama-1.1B-Chat-v1.0/resolve/main/TinyLlama-1.1B-Chat-v1.0_multi-prefill-seq_f32_ekv1280.task",
            fileName = "novapro_tinyllama_11b_f32.task",
            style = PromptStyle.ZEPHYR,
            speed = "Slow", smarts = "Basic+",
        ),
        Brain(
            id = "cosmos",
            name = "Cosmos",
            tagline = "Full-precision Atlas. Best quality, flagship phones only.",
            sizeLabel = "6.2 GB",
            approxBytes = 6_180_000_000L,
            minRamGb = 12,
            url = "$HF/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_f32_ekv1280.task",
            fileName = "cosmos_qwen25_15b_f32.task",
            style = PromptStyle.CHATML,
            speed = "Slow", smarts = "Great+",
        ),
    )
}
