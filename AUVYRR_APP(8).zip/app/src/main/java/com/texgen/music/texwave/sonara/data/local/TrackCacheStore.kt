package com.texgen.music.texwave.sonara.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.texgen.music.texwave.sonara.data.Track
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

private val Context.trackCacheStore by preferencesDataStore("sonara_trackcache")

/**
 * Remembers metadata of online tracks the user played, liked or put in a playlist, so the library
 * can show them again after a restart (ids alone can't be resolved offline).
 */
class TrackCacheStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val key = stringPreferencesKey("tracks_json")
    private val ser = ListSerializer(Track.serializer())

    val tracks: Flow<List<Track>> = context.trackCacheStore.data.map { prefs ->
        val raw = prefs[key] ?: return@map emptyList()
        try { json.decodeFromString(ser, raw) } catch (_: Exception) { emptyList() }
    }

    suspend fun remember(newTracks: List<Track>) {
        val fresh = newTracks.filter { it.origin != null }
        if (fresh.isEmpty()) return
        context.trackCacheStore.edit { prefs ->
            val old = try { json.decodeFromString(ser, prefs[key] ?: "[]") } catch (_: Exception) { emptyList() }
            val merged = (fresh + old).distinctBy { it.id }.take(800)
            prefs[key] = json.encodeToString(ser, merged)
        }
    }
}
