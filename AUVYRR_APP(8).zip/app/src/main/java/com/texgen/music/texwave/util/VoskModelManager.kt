package com.texgen.music.texwave.util

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Downloads Vosk English models for offline voice.
 * - Standard: ~128MB lgraph (fast, good accuracy)
 * - Large / Max: ~1.8–2.3GB full model (highest accuracy; needs free space ~4GB including unpack)
 */
class VoskModelManager(context: Context) {
    private val app = context.applicationContext
    private val root = File(app.filesDir, "vosk")
    private val prefs = app.getSharedPreferences("vosk_models", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(readState())
    val state: StateFlow<State> = _state.asStateFlow()

    /**
     * Every Vosk model that exists for English and Hindi, from phone-light to server-grade.
     * (Vosk publishes nothing between 130 MB and 1 GB, and nothing above 2.3 GB.)
     */
    enum class ModelPack(
        val id: String,
        val label: String,
        val sizeHint: String,
        val url: String,
        val dirName: String,
        val marker: String,
        val lang: String,
        val blurb: String,
        val zipBytes: Long,
        val minRamGb: Int,
    ) {
        SMALL(
            "small", "English (US) — Fast", "40 MB",
            "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
            "vosk-model-small-en-us-0.15", ".ready_small_015_v1",
            "English", "Light and quick. Best for commands. Works on every phone.", 40_000_000L, 2,
        ),
        IN_SMALL(
            "in_small", "English (India) — Fast", "36 MB",
            "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip",
            "vosk-model-small-en-in-0.4", ".ready_small_in_04_v1",
            "English (India)", "Tuned for Indian accents. Light and quick.", 36_000_000L, 2,
        ),
        HI_SMALL(
            "hi_small", "Hindi — Fast", "42 MB",
            "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip",
            "vosk-model-small-hi-0.22", ".ready_small_hi_022_v1",
            "Hindi", "Light Hindi recognition.", 42_000_000L, 2,
        ),
        STANDARD(
            "standard", "English (US) — Accurate", "128 MB",
            "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip",
            "vosk-model-en-us-0.22-lgraph", ".ready_lgraph_v1",
            "English", "Much better with names, songs and longer sentences.", 128_000_000L, 4,
        ),
        IN_BIG(
            "in_big", "English (India) — Large", "1 GB",
            "https://alphacephei.com/vosk/models/vosk-model-en-in-0.5.zip",
            "vosk-model-en-in-0.5", ".ready_en_in_05_v1",
            "English (India)", "High accuracy for Indian English. Needs a strong phone.", 1_000_000_000L, 6,
        ),
        HI_BIG(
            "hi_big", "Hindi — Large", "1.5 GB",
            "https://alphacephei.com/vosk/models/vosk-model-hi-0.22.zip",
            "vosk-model-hi-0.22", ".ready_hi_022_v1",
            "Hindi", "High-accuracy Hindi (server-grade). Needs a strong phone.", 1_500_000_000L, 8,
        ),
        US_BIG(
            "us_big", "English (US) — Large", "1.8 GB",
            "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip",
            "vosk-model-en-us-0.22", ".ready_full_022_v1",
            "English", "Most accurate standard English model. Needs a strong phone.", 1_800_000_000L, 8,
        ),
        GIGA(
            "giga", "English (US) — Maximum", "2.3 GB",
            "https://alphacephei.com/vosk/models/vosk-model-en-us-0.42-gigaspeech.zip",
            "vosk-model-en-us-0.42-gigaspeech", ".ready_giga_042_v1",
            "English", "Largest English model available. Flagship phones only.", 2_300_000_000L, 12,
        ),
    }

    data class State(
        val ready: Boolean = false,
        val downloading: Boolean = false,
        val progress: Float = 0f,
        val error: String? = null,
        val modelPath: String? = null,
        val activePack: String = ModelPack.STANDARD.id,
        val bytesDownloaded: Long = 0L,
        val bytesTotal: Long = 0L,
    )

    private fun activePack(): ModelPack {
        val id = prefs.getString(KEY_ACTIVE, ModelPack.SMALL.id) ?: ModelPack.SMALL.id
        return ModelPack.entries.find { it.id == id } ?: ModelPack.SMALL
    }

    /** The pack to load: the chosen one if installed, otherwise any installed pack. */
    private fun usablePack(): ModelPack? {
        val chosen = activePack()
        // A model too heavy for this phone's memory would crash the app: prefer one that fits.
        if (isPackReady(chosen) && fitsPhone(chosen)) return chosen
        return ModelPack.entries.firstOrNull { isPackReady(it) && fitsPhone(it) }
            ?: ModelPack.entries.firstOrNull { isPackReady(it) }
    }

    fun totalRamGb(): Double {
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.totalMem / 1_073_741_824.0
    }

    fun fitsPhone(pack: ModelPack): Boolean = totalRamGb() >= pack.minRamGb * 0.8

    /** Pack that is actually used for recognition right now (null if none installed). */
    fun inUse(): ModelPack? = usablePack()

    fun partialBytes(pack: ModelPack): Long {
        val f = File(root, "${pack.dirName}.zip.part")
        return if (f.exists()) f.length() else 0L
    }

    fun deletePack(pack: ModelPack) {
        if (_state.value.downloading && _state.value.activePack == pack.id) return
        try { File(root, pack.dirName).deleteRecursively() } catch (_: Exception) {}
        try { File(root, pack.marker).delete() } catch (_: Exception) {}
        try { File(root, "${pack.dirName}.zip").delete() } catch (_: Exception) {}
        try { File(root, "${pack.dirName}.zip.part").delete() } catch (_: Exception) {}
        VoskShared.invalidate()
        refresh()
    }

    @Volatile private var pauseRequested = false
    private val bgScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO)

    /** Start a download that keeps running even if the user leaves the screen. */
    fun startDownload(pack: ModelPack) {
        if (_state.value.downloading) return
        pauseRequested = false
        bgScope.launch { ensureModel(pack) }
    }

    fun pauseDownload() { pauseRequested = true }

    fun isReady(): Boolean = usablePack() != null

    fun modelPath(): String? = usablePack()?.let { File(root, it.dirName).absolutePath }

    /** A Vosk model folder always contains conf/model.conf and am/final.mdl. */
    fun isPackReady(pack: ModelPack): Boolean {
        val marker = File(root, pack.marker)
        val dir = File(root, pack.dirName)
        if (!marker.exists() || !dir.isDirectory) return false
        return File(dir, "am").isDirectory && File(dir, "conf").isDirectory
    }

    private fun readState(): State {
        val pack = usablePack() ?: activePack()
        val path = modelPath()
        return State(
            ready = path != null,
            modelPath = path,
            activePack = pack.id,
        )
    }

    fun refresh() {
        _state.value = readState().copy(
            downloading = _state.value.downloading,
            progress = _state.value.progress,
            bytesDownloaded = _state.value.bytesDownloaded,
            bytesTotal = _state.value.bytesTotal,
        )
    }

    fun setActivePack(pack: ModelPack) {
        prefs.edit().putString(KEY_ACTIVE, pack.id).apply()
        refresh()
    }

    /** Download [pack] (standard or large/max). Large needs ~4GB free space while unpacking. */
    suspend fun ensureModel(pack: ModelPack = activePack()): Result<String> = withContext(Dispatchers.IO) {
        if (_state.value.downloading) return@withContext Result.failure(IllegalStateException("Already downloading"))
        pauseRequested = false
        if (isPackReady(pack)) {
            prefs.edit().putString(KEY_ACTIVE, pack.id).apply()
            val p = File(root, pack.dirName).absolutePath
            _state.value = State(ready = true, modelPath = p, activePack = pack.id)
            return@withContext Result.success(p)
        }
        _state.value = State(downloading = true, progress = 0f, activePack = pack.id)
        try {
            root.mkdirs()
            val need = pack.zipBytes * 3 + 100_000_000L // zip + unpacked copy + slack
            if (root.usableSpace < need) {
                val msg = "Not enough free space (need ${need / 1_000_000} MB)."
                _state.value = State(ready = false, downloading = false, error = msg, activePack = pack.id)
                return@withContext Result.failure(IllegalStateException(msg))
            }
            val zip = File(root, "${pack.dirName}.zip")
            val part = File(root, "${pack.dirName}.zip.part")
            download(pack.url, part) { read, total ->
                val prog = if (total > 0) (read.toFloat() / total).coerceIn(0f, 1f) else 0f
                _state.value = State(
                    downloading = true,
                    progress = prog * 0.85f,
                    activePack = pack.id,
                    bytesDownloaded = read,
                    bytesTotal = total,
                )
            }
            zip.delete()
            if (!part.renameTo(zip)) throw java.io.IOException("Could not finalise download")
            _state.value = State(downloading = true, progress = 0.88f, activePack = pack.id)
            val target = File(root, pack.dirName)
            if (target.exists()) target.deleteRecursively()
            // Unpack into a private temp folder so other installed models are never touched.
            val tmp = File(root, ".unpack_${pack.id}")
            tmp.deleteRecursively()
            tmp.mkdirs()
            unzip(zip, tmp)
            val inner = tmp.listFiles()?.singleOrNull { it.isDirectory } ?: tmp
            if (!inner.renameTo(target)) throw java.io.IOException("Could not install the voice model")
            tmp.deleteRecursively()
            try { zip.delete() } catch (_: Exception) {}
            if (!File(target, "am").isDirectory) throw java.io.IOException("Downloaded model is incomplete")
            VoskShared.invalidate()
            File(root, pack.marker).writeText("ok")
            prefs.edit().putString(KEY_ACTIVE, pack.id).apply()
            val path = target.absolutePath
            _state.value = State(ready = true, modelPath = path, activePack = pack.id, progress = 1f)
            Result.success(path)
        } catch (e: Throwable) {
            // The .part file is kept on purpose so the next try resumes where it stopped.
            val msg = when {
                pauseRequested -> { pauseRequested = false; "Paused — tap Resume to continue." }
                e is java.net.UnknownHostException || e is java.net.SocketTimeoutException || e is java.net.ConnectException ->
                    "No internet connection — connect and try again."
                else -> e.message ?: "Download failed"
            }
            _state.value = State(ready = isReady(), downloading = false, progress = 0f, error = msg, activePack = pack.id)
            Result.failure(Exception(msg))
        }
    }

    private fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val have = if (dest.exists()) dest.length() else 0L
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            if (have > 0) setRequestProperty("Range", "bytes=$have-")
            setRequestProperty("User-Agent", "TexwaveMusic/6.9 (Android; Vosk)")
            connectTimeout = 45_000
            readTimeout = 600_000
            instanceFollowRedirects = true
        }
        val code = conn.responseCode
        if (code == 416 && have > 0) { conn.disconnect(); return } // already complete
        if (code !in 200..299) { conn.disconnect(); throw java.io.IOException("Server returned HTTP $code") }
        val append = code == 206 && have > 0
        val start = if (append) have else 0L
        val len = conn.contentLengthLong
        val total = if (len > 0) start + len else -1L
        BufferedInputStream(conn.inputStream).use { input ->
            FileOutputStream(dest, append).use { out ->
                val buf = ByteArray(256 * 1024)
                var readTotal = start
                while (true) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    if (pauseRequested) throw java.io.IOException("Paused")
                    out.write(buf, 0, n)
                    readTotal += n
                    onProgress(readTotal, total)
                }
                if (total > 0 && readTotal != total) throw java.io.IOException("Download interrupted")
            }
        }
        conn.disconnect()
    }

    private fun unzip(zip: File, target: File) {
        ZipInputStream(BufferedInputStream(zip.inputStream())).use { zis ->
            var entry = zis.nextEntry
            val buf = ByteArray(256 * 1024)
            while (entry != null) {
                val outFile = File(target, entry.name)
                // zip-slip guard
                if (!outFile.canonicalPath.startsWith(target.canonicalPath + File.separator)) {
                    throw java.io.IOException("Bad zip entry")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        while (true) {
                            val n = zis.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    companion object {
        private const val KEY_ACTIVE = "active_pack"
        private val autoStarted = java.util.concurrent.atomic.AtomicBoolean(false)
        @Volatile private var inst: VoskModelManager? = null

        /** One shared manager so every screen sees the same download progress. */
        fun get(context: Context): VoskModelManager =
            inst ?: synchronized(this) { inst ?: VoskModelManager(context.applicationContext).also { inst = it } }

        /**
         * Quietly fetches the small offline model once, as soon as the phone is online, so offline
         * voice works without the user doing anything. Safe to call repeatedly.
         */
        fun autoDownloadIfNeeded(context: Context) {
            val mgr = get(context)
            if (mgr.isReady() || !NetUtil.isOnline(context)) return
            if (!autoStarted.compareAndSet(false, true)) return
            kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                try { mgr.ensureModel(ModelPack.SMALL) } finally { autoStarted.set(false) }
            }
        }
        /** @deprecated use ModelPack.STANDARD.url */
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip"
        const val MODEL_DIR_NAME = "vosk-model-en-us-0.22-lgraph"
        private const val READY_MARKER = ".ready_lgraph_v1"
    }
}


/** One Vosk model instance shared by every voice feature (loading a model is slow and memory-heavy). */
object VoskShared {
    private var path: String? = null
    private var model: org.vosk.Model? = null

    @Synchronized
    fun model(modelPath: String): org.vosk.Model {
        val cur = model
        if (cur != null && path == modelPath) return cur
        try { cur?.close() } catch (_: Throwable) {}
        org.vosk.LibVosk.setLogLevel(org.vosk.LogLevel.WARNINGS)
        val m = org.vosk.Model(modelPath)
        model = m; path = modelPath
        return m
    }

    @Synchronized
    fun invalidate() {
        try { model?.close() } catch (_: Throwable) {}
        model = null; path = null
    }
}

object NetUtil {
    /** Looser than [isOnline]: any network that claims internet access (no validation round-trip). */
    fun hasNetwork(context: Context): Boolean = try {
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        cm.getNetworkCapabilities(cm.activeNetwork)
            ?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (_: Exception) { false }

    fun isOnline(context: Context): Boolean = try {
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Exception) { false }

    fun isUnmetered(context: Context): Boolean = try {
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == true
    } catch (_: Exception) { false }
}
