package com.texgen.music.texwave.sonara.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.texgen.music.texwave.sonara.data.PlaybackState
import com.texgen.music.texwave.sonara.data.RepeatMode
import com.texgen.music.texwave.sonara.data.Track
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Connects UI to the Media3 PlaybackService via MediaController.
 * Owns queue, shuffle, repeat, and exposes a clean PlaybackState flow.
 */
class PlayerController(private val context: Context) {

    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    private var queue: List<Track> = emptyList()
    private var currentIndex: Int = -1

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.update { it.copy(isPlaying = isPlaying) }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                // Continuous listening: if not repeating one, Media3 advances queue;
                // when queue exhausted and repeat off, stay on last track paused.
                publishFromController()
            }
            publishPosition()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val id = mediaItem?.mediaId
            if (id != null) {
                val idx = queue.indexOfFirst { it.id == id }
                if (idx >= 0) {
                    currentIndex = idx
                    _state.update {
                        it.copy(
                            currentTrack = queue[idx],
                            durationMs = controller?.duration?.coerceAtLeast(0) ?: queue[idx].durationMs,
                            queue = queue,
                        )
                    }
                }
            }
            publishPosition()
        }

        override fun onEvents(player: Player, events: Player.Events) {
            if (events.contains(Player.EVENT_POSITION_DISCONTINUITY) ||
                events.contains(Player.EVENT_PLAYBACK_STATE_CHANGED) ||
                events.contains(Player.EVENT_IS_PLAYING_CHANGED)
            ) {
                publishPosition()
            }
        }
    }

    fun connect() {
        if (controller != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                // Restore basic state if service already playing
                publishFromController()
            } catch (_: Exception) {
                // Service not ready yet — will retry on next user action
            }
        }, MoreExecutors.directExecutor())
    }

    fun disconnect() {
        controller?.removeListener(listener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        controllerFuture = null
    }

    fun playTracks(tracks: List<Track>, startIndex: Int = 0) {
        if (tracks.isEmpty()) return
        connect()
        queue = tracks
        currentIndex = startIndex.coerceIn(0, tracks.lastIndex)
        val items = tracks.map { it.toMediaItem() }
        val c = controller
        if (c != null) {
            c.setMediaItems(items, currentIndex, 0L)
            c.prepare()
            c.play()
            _state.update {
                it.copy(
                    currentTrack = tracks[currentIndex],
                    isPlaying = true,
                    queue = tracks,
                    durationMs = tracks[currentIndex].durationMs,
                )
            }
        } else {
            // Controller still connecting — retry shortly
            controllerFuture?.addListener({
                try {
                    val ready = controllerFuture?.get()
                    controller = ready
                    ready?.addListener(listener)
                    ready?.setMediaItems(items, currentIndex, 0L)
                    ready?.prepare()
                    ready?.play()
                    _state.update {
                        it.copy(
                            currentTrack = tracks[currentIndex],
                            isPlaying = true,
                            queue = tracks,
                            durationMs = tracks[currentIndex].durationMs,
                        )
                    }
                } catch (_: Exception) { }
            }, MoreExecutors.directExecutor())
        }
    }

    fun play(track: Track, contextQueue: List<Track> = listOf(track)) {
        val idx = contextQueue.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        playTracks(if (contextQueue.isNotEmpty()) contextQueue else listOf(track), idx)
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs.coerceAtLeast(0))
        publishPosition()
    }

    fun skipNext() {
        controller?.seekToNextMediaItem()
    }

    fun skipPrevious() {
        val c = controller ?: return
        if (c.currentPosition > 3000) {
            c.seekTo(0)
        } else {
            c.seekToPreviousMediaItem()
        }
    }

    fun setShuffle(enabled: Boolean) {
        controller?.shuffleModeEnabled = enabled
        _state.update { it.copy(shuffle = enabled) }
    }

    fun cycleRepeat() {
        val next = when (_state.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        controller?.repeatMode = when (next) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
        }
        _state.update { it.copy(repeatMode = next) }
    }

    fun publishPosition() {
        val c = controller ?: return
        _state.update {
            it.copy(
                positionMs = c.currentPosition.coerceAtLeast(0),
                durationMs = c.duration.coerceAtLeast(0).takeIf { d -> d > 0 } ?: it.durationMs,
                isPlaying = c.isPlaying,
            )
        }
    }

    private fun publishFromController() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId
        val track = queue.find { it.id == id }
        _state.update {
            it.copy(
                currentTrack = track ?: it.currentTrack,
                isPlaying = c.isPlaying,
                positionMs = c.currentPosition.coerceAtLeast(0),
                durationMs = c.duration.coerceAtLeast(0),
                shuffle = c.shuffleModeEnabled,
                repeatMode = when (c.repeatMode) {
                    Player.REPEAT_MODE_ONE -> RepeatMode.ONE
                    Player.REPEAT_MODE_ALL -> RepeatMode.ALL
                    else -> RepeatMode.OFF
                },
                queue = queue,
            )
        }
    }

    private fun Track.toMediaItem(): MediaItem {
        val uri = localUri?.let { Uri.parse(it) }
            ?: streamUrl?.let { Uri.parse(it) }
            ?: Uri.EMPTY
        val meta = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album)
            .setArtworkUri(artworkUrl?.let { Uri.parse(it) })
            .build()
        return MediaItem.Builder()
            .setMediaId(id)
            .setUri(uri)
            .setMediaMetadata(meta)
            .build()
    }
}
