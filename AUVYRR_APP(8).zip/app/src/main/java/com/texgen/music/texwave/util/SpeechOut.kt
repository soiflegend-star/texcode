package com.texgen.music.texwave.util

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

/** Clear, natural PHANTOM voice replies. */
class SpeechOut(
    context: Context,
    /** USAGE_ALARM so alarm speech still plays under DND / silent. */
    private val audioUsage: Int = AudioAttributes.USAGE_ASSISTANCE_SONIFICATION,
) : TextToSpeech.OnInitListener {
    private val app = context.applicationContext
    private var tts: TextToSpeech? = TextToSpeech(app, this)
    private var ready = false
    private var pendingText: String? = null
    private var pitch = 1.02f
    private var rate = 0.96f
    @Volatile private var doneCb: (() -> Unit)? = null

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) return
        val engine = tts ?: return
        engine.language = Locale.US
        try {
            val best = engine.voices
                ?.filter { v ->
                    v.locale.language == "en" &&
                        !v.isNetworkConnectionRequired &&
                        v.quality >= Voice.QUALITY_NORMAL
                }
                ?.sortedByDescending { it.quality }
                ?.firstOrNull()
            if (best != null) engine.voice = best
        } catch (_: Exception) {
        }
        engine.setSpeechRate(rate)
        engine.setPitch(pitch)
        try {
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { fireDone() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { fireDone() }
            })
        } catch (_: Exception) {
        }
        try {
            engine.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(audioUsage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
        } catch (_: Exception) {
        }
        pendingText?.let { p ->
            pendingText = null
            doSpeak(p)
        }
    }

    /** Default PHANTOM voice. */
    fun speak(text: String) {
        pitch = 1.02f
        rate = 0.96f
        if (ready) {
            tts?.setPitch(pitch)
            tts?.setSpeechRate(rate)
        }
        doSpeak(text)
    }

    private fun doSpeak(text: String) {
        if (text.isBlank()) { fireDone(); return }
        if (!ready) {
            pendingText = text
            android.os.Handler(app.mainLooper).postDelayed({
                val p = pendingText
                if (ready && p != null) {
                    pendingText = null
                    doSpeak(p)
                }
            }, 800)
            return
        }
        val clean = text
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("[*_#>`\\[\\]]"), "")
            .replace(Regex("https?://\\S+"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(900)
        if (clean.isBlank()) { fireDone(); return }
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "phantom_${System.currentTimeMillis()}")
    }

    private fun fireDone() {
        val cb = doneCb
        doneCb = null
        if (cb != null) android.os.Handler(app.mainLooper).post { cb() }
    }

    /** Speak with a chosen pitch/rate; [onDone] runs on the main thread when speech finishes. */
    fun speakStyled(text: String, pitch: Float, rate: Float, onDone: (() -> Unit)? = null) {
        this.pitch = pitch
        this.rate = rate
        if (ready) {
            tts?.setPitch(pitch)
            tts?.setSpeechRate(rate)
        }
        if (text.isBlank()) { onDone?.invoke(); return }
        doneCb = onDone
        doSpeak(text)
    }

    fun stop() {
        doneCb = null
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
