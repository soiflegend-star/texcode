package com.texgen.music.texwave.arena.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.ui.theme.Tx

/**
 * Premium Arena visual system — aligned with AUVYRR Tx, elevated for competitive feel.
 */
object ArenaColors {
    val Cyan = Tx.Accent2
    val Violet = Tx.Accent
    val Magenta = Tx.Accent3
    val Surface = Tx.Surface
    val SurfaceHigh = Tx.SurfaceHigh
    val Bg = Tx.Bg
    val Text = Tx.Text
    val Muted = Tx.Muted
    val Outline = Tx.Outline

    val RankGold = Color(0xFFFFD700)
    val RankSilver = Color(0xFFE8E8E8)
    val RankBronze = Color(0xFFE0A060)

    val Success = Color(0xFF00E676)
    val Warning = Color(0xFFFFAB00)

    val GlowCyan = Cyan.copy(alpha = 0.28f)
    val GlowViolet = Violet.copy(alpha = 0.22f)
    val GlowMagenta = Magenta.copy(alpha = 0.18f)

    /** Subtle top ambient wash for screens */
    val AmbientTop = Brush.verticalGradient(
        listOf(
            Violet.copy(alpha = 0.12f),
            Cyan.copy(alpha = 0.06f),
            Color.Transparent
        )
    )

    val ScreenBg = Brush.verticalGradient(
        listOf(
            Color(0xFF05070F),
            Color(0xFF03050A),
            Color(0xFF06041A),
            Color(0xFF03050A)
        )
    )
}

object ArenaShapes {
    val Card = RoundedCornerShape(22.dp)
    val CardSmall = RoundedCornerShape(16.dp)
    val Pill = RoundedCornerShape(50)
    val Progress = RoundedCornerShape(10.dp)
    val Hero = RoundedCornerShape(28.dp)
}

fun Modifier.arenaGlow(
    color: Color = ArenaColors.GlowCyan,
    radius: Dp = 28.dp
): Modifier = this.drawBehind {
    val r = radius.toPx()
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(color, color.copy(alpha = 0.08f), Color.Transparent),
            center = Offset(size.width / 2f, size.height / 2f),
            radius = r
        ),
        radius = r,
        center = Offset(size.width / 2f, size.height / 2f)
    )
}

/**
 * Premium multi-layer glass — specular edge + depth, no runtime blur required.
 */
fun Modifier.arenaGlassCard(corner: Int = 22): Modifier =
    this
        .shadow(
            elevation = 12.dp,
            shape = RoundedCornerShape(corner.dp),
            ambientColor = Color.Black.copy(alpha = 0.45f),
            spotColor = ArenaColors.Violet.copy(alpha = 0.15f)
        )
        .clip(RoundedCornerShape(corner.dp))
        .background(
            Brush.verticalGradient(
                listOf(
                    Color(0x1AFFFFFF),
                    Color(0x0CFFFFFF),
                    Color(0x08FFFFFF),
                    ArenaColors.Surface.copy(alpha = 0.82f)
                )
            )
        )
        .background(ArenaColors.Surface.copy(alpha = 0.35f))
        .border(
            width = 1.dp,
            brush = Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = 0.16f),
                    ArenaColors.Cyan.copy(alpha = 0.22f),
                    ArenaColors.Violet.copy(alpha = 0.12f),
                    Color.White.copy(alpha = 0.04f)
                )
            ),
            shape = RoundedCornerShape(corner.dp)
        )

/** Hero / elevated panel for primary identity blocks */
fun Modifier.arenaHeroCard(corner: Int = 28): Modifier =
    this
        .shadow(
            elevation = 18.dp,
            shape = RoundedCornerShape(corner.dp),
            ambientColor = Color.Black.copy(alpha = 0.5f),
            spotColor = ArenaColors.Cyan.copy(alpha = 0.2f)
        )
        .clip(RoundedCornerShape(corner.dp))
        .background(
            Brush.linearGradient(
                listOf(
                    Color(0x22FFFFFF),
                    ArenaColors.Violet.copy(alpha = 0.14f),
                    ArenaColors.Cyan.copy(alpha = 0.08f),
                    ArenaColors.Surface.copy(alpha = 0.9f)
                )
            )
        )
        .border(
            width = 1.2.dp,
            brush = Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = 0.22f),
                    ArenaColors.Cyan.copy(alpha = 0.35f),
                    ArenaColors.Violet.copy(alpha = 0.2f),
                    Color.Transparent
                )
            ),
            shape = RoundedCornerShape(corner.dp)
        )

fun Modifier.arenaRing(color: Color = ArenaColors.Cyan, stroke: Dp = 2.dp): Modifier =
    this.drawBehind {
        drawCircle(
            brush = Brush.sweepGradient(
                listOf(
                    color.copy(alpha = 0.9f),
                    color.copy(alpha = 0.25f),
                    ArenaColors.Violet.copy(alpha = 0.7f),
                    color.copy(alpha = 0.9f)
                )
            ),
            style = Stroke(width = stroke.toPx())
        )
    }

@Composable
fun arenaBrandGradient(): Brush = Brush.linearGradient(
    listOf(ArenaColors.Violet, ArenaColors.Cyan, ArenaColors.Magenta)
)

@Composable
fun arenaProgressBrush(): Brush = Brush.horizontalGradient(
    listOf(ArenaColors.Violet, ArenaColors.Cyan)
)
