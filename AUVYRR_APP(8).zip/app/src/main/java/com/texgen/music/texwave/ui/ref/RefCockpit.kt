package com.texgen.music.texwave.ui.ref

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** One short tip about a screen. */
data class GuideStep(val label: String, val text: String)

data class ScreenGuide(val id: String, val title: String, val tagline: String, val steps: List<GuideStep>)

/** Friendly tips for special screens (radar, mood map, universe, constellation). */
object Guides {
    val radar = ScreenGuide(
        "radar", "Your music map", "See your whole library as a soft sky of songs. Pick by feeling, not by typing.",
        listOf(
            GuideStep("Dots", "Each glowing dot is one song you already own."),
            GuideStep("Bigger / brighter", "Songs you play more often shine a bit more."),
            GuideStep("Tap a dot", "Opens that song so you can play it."),
            GuideStep("Drag", "Move around the map to explore different areas."),
        ),
    )
    val stars = ScreenGuide(
        "stars", "Constellation", "Connect songs into little shapes — your own star pictures.",
        listOf(
            GuideStep("Stars", "Each star is a song."),
            GuideStep("Lines", "Draw lines between songs that feel related to you."),
            GuideStep("Save", "Keep a constellation and come back to it later."),
        ),
    )
    val gps = ScreenGuide(
        "gps", "Mood map", "Tell the app how you feel — it builds a short playlist from your library.",
        listOf(
            GuideStep("Circle", "Moods sit around the circle. Tap one to choose it."),
            GuideStep("Highlight", "The bright mood is the one you picked."),
            GuideStep("Song list", "Songs from YOUR library that match that mood."),
            GuideStep("Play this path", "Starts that list as a queue."),
        ),
    )
    val hub = ScreenGuide(
        "hub", "Special screens", "Extra ways to explore your music — mood, memory, and sharing.",
        listOf(
            GuideStep("Cards", "Tap any card to open that experience."),
            GuideStep("Simple names", "Each title says what the screen does in plain words."),
            GuideStep("Help", "Tap the ? button anytime for a short explanation."),
        ),
    )
    fun generic(id: String, title: String, subtitle: String) = ScreenGuide(
        id, title, subtitle,
        listOf(
            GuideStep("What this is", subtitle),
            GuideStep("Your songs only", "Everything here comes from YOUR library — nothing is invented."),
            GuideStep("Play", "Use the play button to start a queue made for this screen."),
            GuideStep("Back", "Use the back arrow to return."),
        ),
    )
}

/**
 * Friendly help wrapper: soft ? button + simple tip sheet.
 * No cockpit frames, no HUD brackets — just clear guidance.
 */
@Composable
fun CockpitGuide(guide: ScreenGuide, content: @Composable BoxScope.() -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("texwave_ui", android.content.Context.MODE_PRIVATE) }
    var open by remember(guide.id) { mutableStateOf(false) }
    LaunchedEffect(guide.id) {
        if (!prefs.getBoolean("guide_seen_${guide.id}", false)) {
            kotlinx.coroutines.delay(450)
            open = true
        }
    }
    Box(Modifier.fillMaxSize()) {
        content()
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .statusBarsPadding()
                .padding(end = 16.dp, bottom = 88.dp)
                .size(40.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF2A1B5E), Color(0xFF15305A))))
                .border(1.dp, Color(0x66FFFFFF), CircleShape)
                .clickable { open = true },
            contentAlignment = Alignment.Center,
        ) {
            Text("?", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
    if (open) {
        Dialog(
            onDismissRequest = {
                open = false
                prefs.edit().putBoolean("guide_seen_${guide.id}", true).apply()
            },
            properties = DialogProperties(usePlatformDefaultWidth = true),
        ) {
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(tween(220)) + scaleIn(initialScale = 0.94f, animationSpec = tween(220)),
                exit = fadeOut(tween(160)) + scaleOut(targetScale = 0.96f, animationSpec = tween(160)),
            ) {
                val shape = RoundedCornerShape(28.dp)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF1D1D1F), Color(0xFF111113)),
                            ),
                        )
                        .border(1.dp, Color(0x33FFFFFF), shape)
                        .padding(22.dp),
                ) {
                    Text(
                        "Quick tip",
                        color = Color(0xFF9BB6FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 0.5.sp,
                    )
                    Text(
                        guide.title,
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    Text(
                        guide.tagline,
                        color = Color(0xFFB8C0DE),
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 6.dp, bottom = 16.dp),
                        lineHeight = 20.sp,
                    )
                    Column(
                        Modifier
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        guide.steps.forEachIndexed { i, s ->
                            Row(verticalAlignment = Alignment.Top) {
                                Box(
                                    Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF6B5CFF), Color(0xFF3D8BFF)),
                                            ),
                                        ),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text("${i + 1}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(s.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                    Text(s.text, color = Color(0xFFA8B0CC), fontSize = 13.sp, lineHeight = 18.sp)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF6B5CFF), Color(0xFF3D8BFF)),
                                ),
                            )
                            .clickable {
                                open = false
                                prefs.edit().putBoolean("guide_seen_${guide.id}", true).apply()
                            }
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("Got it", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
