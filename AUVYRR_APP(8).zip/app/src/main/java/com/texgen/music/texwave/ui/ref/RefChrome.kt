package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.Image
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.player.PlayerState

/**
 * Bottom bar: Home · Search · Library · Chat · Menu.
 * selected: 0 Home, 1 Search, 2 Library, 3 Chat, 4 Menu, anything else = none.
 * "Menu" opens the full catalogue of every screen, so nothing is ever hidden.
 */
@Composable
fun RefNavBar(
    selected: Int,
    onHome: () -> Unit,
    onSearch: () -> Unit,
    onLibrary: () -> Unit,
    onChat: () -> Unit,
    onMenu: () -> Unit,
) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
        val sh = RoundedCornerShape(30.dp)
        Row(
            Modifier.fillMaxWidth().height(66.dp)
                .clip(sh)
                .background(Ref.Bg.copy(alpha = 0.92f))
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.2f), Ref.Line.copy(alpha = 0.5f))), sh)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NavItem("Home", Icons.Rounded.Home, selected == 0, Modifier.weight(1f), onHome)
            NavItem("Search", Icons.Rounded.Search, selected == 1, Modifier.weight(1f), onSearch)
            NavItem("Library", Icons.Rounded.VideoLibrary, selected == 2, Modifier.weight(1f), onLibrary)
            NavItem("Chat", Icons.Rounded.ChatBubble, selected == 3, Modifier.weight(1f), onChat)
            NavItem("Menu", Icons.Rounded.GridView, selected == 4, Modifier.weight(1f), onMenu)
        }
    }
}

@Composable
private fun NavItem(
    label: String,
    icon: ImageVector,
    on: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val tint by animateColorAsState(if (on) Ref.Cyan else Color(0xFF9A9FAC), tween(220), label = "navTint")
    val pill by animateFloatAsState(if (on) 1f else 0f, tween(260), label = "navPill")
    Column(
        modifier.pressScale().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.height(30.dp).width(54.dp).clip(RoundedCornerShape(15.dp))
                .background(Ref.Cyan.copy(alpha = 0.24f * pill)),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, label, tint = tint, modifier = Modifier.size(24.dp)) }
        Text(label, color = tint, fontSize = 11.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
    }
}

/** Reference mini player: cover · title/artist · prev · pause · next. */
@Composable
fun RefMiniPlayer(
    state: PlayerState,
    position: State<Long>,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
) {
    val song = state.current ?: return
    Row(
        Modifier
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .fillMaxWidth()
            .height(62.dp)
            .refCard(20.dp, hot = true)
            .clickable(onClick = onOpen)
            .drawBehind {
                val d = state.durationMs
                if (d > 0) {
                    val f = (position.value.toFloat() / d).coerceIn(0f, 1f)
                    drawRect(
                        Brush.horizontalGradient(listOf(Ref.Purple, Ref.Cyan, Ref.Lavender)),
                        topLeft = Offset(0f, size.height - 3.dp.toPx()),
                        size = Size(size.width * f, 3.dp.toPx()),
                    )
                }
            }
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SongThumb(song, Modifier.size(46.dp), RoundedCornerShape(10.dp), fallback = R.drawable.ref_mini_art)
        Box(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Ref.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(
            Icons.Rounded.SkipPrevious, "Previous", tint = Color.White,
            modifier = Modifier.size(34.dp).clickable(onClick = onPrevious).padding(4.dp),
        )
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Ref.Cyan, Ref.Purple)))
                .pressScale()
                .clickable(onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                if (state.isPlaying) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(24.dp),
            )
        }
        Icon(
            Icons.Rounded.SkipNext, "Next", tint = Color.White,
            modifier = Modifier.size(34.dp).clickable(onClick = onNext).padding(4.dp),
        )
    }
}
