package com.texgen.music.texwave.ui.screens

import android.app.DownloadManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix as ComposeColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.chat.SocialFeedRepository
import com.texgen.music.texwave.data.chat.SocialPost
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

private data class PhotoFilter(val id: String, val label: String, val matrix: FloatArray)

private val PHOTO_FILTERS = listOf(
    PhotoFilter("none", "Original", floatArrayOf(
        1f, 0f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f, 0f,
        0f, 0f, 1f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f,
    )),
    PhotoFilter("mono", "Mono", floatArrayOf(
        0.33f, 0.33f, 0.33f, 0f, 0f,
        0.33f, 0.33f, 0.33f, 0f, 0f,
        0.33f, 0.33f, 0.33f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f,
    )),
    PhotoFilter("warm", "Warm", floatArrayOf(
        1.15f, 0f, 0f, 0f, 12f,
        0f, 1.05f, 0f, 0f, 6f,
        0f, 0f, 0.9f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f,
    )),
    PhotoFilter("cool", "Cool", floatArrayOf(
        0.9f, 0f, 0f, 0f, 0f,
        0f, 1.02f, 0f, 0f, 4f,
        0f, 0f, 1.18f, 0f, 10f,
        0f, 0f, 0f, 1f, 0f,
    )),
    PhotoFilter("vivid", "Vivid", floatArrayOf(
        1.25f, -0.05f, -0.05f, 0f, 0f,
        -0.05f, 1.2f, -0.05f, 0f, 0f,
        -0.05f, -0.05f, 1.25f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f,
    )),
    PhotoFilter("fade", "Fade", floatArrayOf(
        0.9f, 0.05f, 0.05f, 0f, 18f,
        0.05f, 0.9f, 0.05f, 0f, 18f,
        0.05f, 0.05f, 0.9f, 0f, 18f,
        0f, 0f, 0f, 1f, 0f,
    )),
    PhotoFilter("noir", "Noir", floatArrayOf(
        0.4f, 0.4f, 0.2f, 0f, -20f,
        0.3f, 0.3f, 0.3f, 0f, -20f,
        0.2f, 0.2f, 0.4f, 0f, -20f,
        0f, 0f, 0f, 1f, 0f,
    )),
)

private fun applyFilterToBitmap(src: Bitmap, matrix: FloatArray): Bitmap {
    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(matrix))
    canvas.drawBitmap(src, 0f, 0f, paint)
    return out
}

private fun parseSongLine(caption: String): Pair<String, String>? {
    val line = caption.lineSequence().firstOrNull { it.startsWith("♪ ") } ?: return null
    val body = line.removePrefix("♪ ").trim()
    val parts = body.split(" — ", limit = 2)
    return if (parts.size == 2) parts[0] to parts[1] else body to ""
}

@Composable
fun SocialFeedScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { SocialFeedRepository.get(context) }
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf<List<SocialPost>>(emptyList()) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var caption by remember { mutableStateOf("") }
    var pickedSong by remember { mutableStateOf<com.texgen.music.texwave.data.Song?>(null) }
    var showSongPicker by remember { mutableStateOf(false) }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var previewBmp by remember { mutableStateOf<Bitmap?>(null) }
    var filterId by remember { mutableStateOf("none") }
    var likeState by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var likeCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var commentCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var commentInputs by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    fun refresh() {
        scope.launch {
            repo.feed().onSuccess { list ->
                val images = list.filter { it.media_type == "image" }
                // Show more-liked posts first when counts are known (Instagram-style)
                posts = images
                list.forEach { p ->
                    repo.likesFor(p.id).onSuccess { likes ->
                        likeCounts = likeCounts + (p.id to likes.size)
                        likeState = likeState + (p.id to likes.any { it.user_id == repo.myUserId() })
                    }
                    repo.commentsFor(p.id).onSuccess { c ->
                        commentCounts = commentCounts + (p.id to c.size)
                    }
                }
            }.onFailure { status = "Feed unavailable: ${it.message}" }
        }
    }

    LaunchedEffect(Unit) { refresh() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        pickedUri = uri
        scope.launch {
            previewBmp = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            filterId = "none"
        }
    }

    val activeFilter = PHOTO_FILTERS.first { it.id == filterId }

    fun publish() {
        val bmp = previewBmp ?: run {
            Toast.makeText(context, "Pick a photo first", Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        status = null
        scope.launch {
            try {
                val filtered = withContext(Dispatchers.Default) {
                    applyFilterToBitmap(bmp, activeFilter.matrix)
                }
                val bytes = withContext(Dispatchers.IO) {
                    ByteArrayOutputStream().use { out ->
                        filtered.compress(Bitmap.CompressFormat.JPEG, 90, out)
                        out.toByteArray()
                    }
                }
                val fullCaption = com.texgen.music.texwave.ui.components.SongTag.encode(caption, pickedSong)
                repo.publishImageBytes(bytes, fullCaption, "image/jpeg")
                    .onSuccess {
                        status = "Published"
                        caption = ""; pickedSong = null
                        pickedUri = null; previewBmp = null; filterId = "none"
                        refresh()
                    }
                    .onFailure { status = it.message ?: "Publish failed — sign in & social SQL" }
            } finally {
                busy = false
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0E0E10), Color(0xFF070709))))
            .statusBarsPadding()
            .padding(horizontal = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = Color.White) }
            Text("Community", color = Tx.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp, modifier = Modifier.weight(1f))
            Text("Photos · music", color = Tx.Muted, fontSize = 12.sp)
        }

        // Composer
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF1D1D1F), Color(0xFF111113))))
                .border(1.dp, Brush.linearGradient(listOf(Color(0x5586EFFF), Color(0x229A78FF), Color(0x11FFFFFF))), RoundedCornerShape(24.dp))
                .padding(14.dp),
        ) {
            Text("New post", color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            if (previewBmp != null) {
                Box {
                    Image(
                        bitmap = previewBmp!!.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        colorFilter = ColorFilter.colorMatrix(ComposeColorMatrix(activeFilter.matrix)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(12.dp)),
                    )
                    IconButton(
                        onClick = { pickedUri = null; previewBmp = null },
                        modifier = Modifier.align(Alignment.TopEnd),
                    ) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
                }
                Spacer(Modifier.height(8.dp))
                Text("Filter", color = Tx.Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    PHOTO_FILTERS.forEach { f ->
                        val on = filterId == f.id
                        Text(
                            f.label,
                            color = if (on) Color.Black else Tx.Text,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(if (on) Tx.Accent2 else Tx.SurfaceHigh)
                                .clickable { filterId = f.id }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }
                }
            } else {
                Button(
                    onClick = { picker.launch("image/*") },
                    colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Rounded.Image, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choose photo")
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = caption,
                onValueChange = { caption = it.take(2000) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Write a caption…") },
                minLines = 2,
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Tx.Text,
                    unfocusedTextColor = Tx.Text,
                    focusedBorderColor = Tx.Accent2,
                    unfocusedBorderColor = Tx.Outline,
                ),
            )
            Spacer(Modifier.height(8.dp))
            val sp = pickedSong
            if (sp != null) {
                com.texgen.music.texwave.ui.components.SongChip(
                    sp.title, sp.artist, playable = false, onClear = { pickedSong = null },
                )
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Tx.SurfaceHigh)
                        .clickable { showSongPicker = true }
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.MusicNote, null, tint = Tx.Accent2, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Add a song from your library", color = Tx.Text, fontSize = 14.sp)
                }
            }
            if (showSongPicker) {
                com.texgen.music.texwave.ui.components.SongPickerDialog(
                    onDismiss = { showSongPicker = false },
                    onPick = { pickedSong = it; showSongPicker = false },
                )
            }
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { publish() },
                enabled = !busy && previewBmp != null,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent2, contentColor = Color.Black),
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
                else Text("Share photo", fontWeight = FontWeight.Bold)
            }
        }

        status?.let {
            Text(it, color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        }

        LazyColumn(
            Modifier.weight(1f).padding(top = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (posts.isEmpty()) {
                item {
                    Text(
                        "No posts yet. Share a photo with a filter and a song.",
                        color = Tx.Muted,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(24.dp),
                    )
                }
            }
            items(posts, key = { it.id }) { post ->
                val song = parseSongLine(post.caption)
                val body = post.caption.lineSequence().filterNot { it.startsWith("♪ ") }.joinToString("\n").trim()
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF1C1C1E), Color(0xFF0E0E10))))
                        .border(1.dp, Color(0x2BFFFFFF), RoundedCornerShape(24.dp))
                        .padding(bottom = 10.dp),
                ) {
                    AsyncImage(
                        model = post.media_url,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(300.dp),
                    )
                    if (song != null) {
                        com.texgen.music.texwave.ui.components.SongChip(
                            song.first, song.second,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        )
                    }
                    if (body.isNotBlank()) {
                        Text(body, color = Tx.Text, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                    }
                    Row(
                        Modifier.padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        TextButton(onClick = {
                            val liked = likeState[post.id] == true
                            scope.launch {
                                repo.toggleLike(post.id, liked).onSuccess {
                                    likeState = likeState + (post.id to !liked)
                                    likeCounts = likeCounts + (post.id to ((likeCounts[post.id] ?: 0) + if (liked) -1 else 1))
                                }
                            }
                        }) {
                            Icon(
                                Icons.Rounded.Favorite,
                                null,
                                tint = if (likeState[post.id] == true) Color(0xFFFF4F91) else Tx.Muted,
                            )
                            Text(" ${likeCounts[post.id] ?: 0}", color = Tx.Text)
                        }
                        Text("${commentCounts[post.id] ?: 0} comments", color = Tx.Muted, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = {
                            runCatching {
                                val req = DownloadManager.Request(Uri.parse(post.media_url))
                                    .setTitle("AUVYRR photo")
                                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "texwave_${post.id}.jpg")
                                (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                                Toast.makeText(context, "Download started", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Rounded.Download, null, tint = Tx.Accent2)
                        }
                    }
                    Row(
                        Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        OutlinedTextField(
                            value = commentInputs[post.id].orEmpty(),
                            onValueChange = { commentInputs = commentInputs + (post.id to it.take(500)) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            placeholder = { Text("Comment…", fontSize = 12.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Tx.Text,
                                unfocusedTextColor = Tx.Text,
                                focusedBorderColor = Tx.Accent,
                                unfocusedBorderColor = Tx.Outline,
                            ),
                        )
                        TextButton(onClick = {
                            val bodyText = commentInputs[post.id].orEmpty()
                            if (bodyText.isBlank()) return@TextButton
                            scope.launch {
                                repo.addComment(post.id, bodyText).onSuccess {
                                    commentInputs = commentInputs + (post.id to "")
                                    commentCounts = commentCounts + (post.id to ((commentCounts[post.id] ?: 0) + 1))
                                }
                            }
                        }) { Text("Post", color = Tx.Accent2) }
                    }
                }
            }
            item { Spacer(Modifier.height(88.dp)) }
        }
    }
}
