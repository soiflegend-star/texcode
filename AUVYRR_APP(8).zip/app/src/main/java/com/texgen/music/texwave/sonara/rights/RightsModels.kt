package com.texgen.music.texwave.sonara.rights

import kotlinx.serialization.Serializable

@Serializable
data class TrackRights(
    val id: String = "",
    val trackId: String,
    val ownerName: String,
    val masterOwner: String? = null,
    val compositionOwner: String? = null,
    val publisher: String? = null,
    val isrc: String? = null,
    val territory: String = "WW",
    val allowStream: Boolean = true,
    val allowDownload: Boolean = false,
    val allowCommercial: Boolean = false,
    val licenseType: String = "original",
    val licenseStart: String? = null,
    val licenseEnd: String? = null,
    val documentationUrl: String? = null,
    val notes: String? = null,
)

@Serializable
data class ContentSubmission(
    val id: String = "",
    val submitterId: String = "",
    val title: String,
    val artistName: String,
    val albumName: String = "",
    val genre: String = "",
    val ownershipDeclaration: String,
    val documentationUrls: List<String> = emptyList(),
    val status: String = "pending",
    val reviewerNotes: String? = null,
    val submittedAt: Long = System.currentTimeMillis(),
)

/**
 * Client-side enforcement helpers. Server RLS + track_stream_allowed() are authoritative.
 */
object RightsPolicy {
    fun canStream(rights: TrackRights?, trackPublished: Boolean, territory: String = "WW"): Boolean {
        if (!trackPublished) return false
        if (rights == null) return true // demo catalogue without rights rows
        if (!rights.allowStream) return false
        if (rights.territory != "WW" && rights.territory != territory) return false
        // license_end checked server-side when present
        return true
    }

    fun canDownload(rights: TrackRights?, isPremium: Boolean, freeRemaining: Int): Boolean {
        if (rights != null && !rights.allowDownload) return false
        if (isPremium) return true
        return freeRemaining > 0
    }
}
