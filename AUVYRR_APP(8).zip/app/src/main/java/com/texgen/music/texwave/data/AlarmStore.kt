package com.texgen.music.texwave.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** One saved alarm. `days` is a bitmask, bit0 = Monday … bit6 = Sunday; 0 means "once". */
data class AlarmRec(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String,
    val days: Int,
    val enabled: Boolean,
    val trigger: Long,
    /** "" = default alarm tone, "silent" = voice only, otherwise a content/file uri. */
    val soundUri: String?,
    val soundName: String,
    val theme: String,
    val snooze: Int = 5,
    val vibrate: Boolean = true,
    /** "auto" picks sun/moon from the hour; or "sun", "moon", "dumbbell", "bell", "work". */
    val icon: String = "auto",
) {
    val repeating: Boolean get() = days != 0
}

object Days {
    const val ALL = 127
    const val WEEKDAYS = 31       // Mon–Fri
    const val WEEKEND = 96        // Sat + Sun
    val short = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    val letters = listOf("M", "T", "W", "T", "F", "S", "S")

    /** Calendar.DAY_OF_WEEK (Sun=1…Sat=7) → bit index (Mon=0…Sun=6). */
    fun bitOf(calendarDow: Int): Int = (calendarDow + 5) % 7

    fun summary(days: Int): String = when {
        days == 0 -> "Once"
        days == ALL -> "Every day"
        days == WEEKDAYS -> "Mon – Fri"
        days == WEEKEND -> "Sat – Sun"
        else -> short.filterIndexed { i, _ -> days and (1 shl i) != 0 }.joinToString(" ")
    }
}

object AlarmStore {
    const val PREFS = "texwave_alarms"
    private const val KEY = "alarms"

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context): List<AlarmRec> = runCatching {
        val arr = JSONArray(sp(ctx).getString(KEY, "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            // Old saves only had "daily": true/false
            val days = if (o.has("days")) o.optInt("days") else if (o.optBoolean("daily")) Days.ALL else 0
            AlarmRec(
                id = o.getInt("id"), hour = o.getInt("hour"), minute = o.getInt("minute"),
                label = o.optString("label", "AUVYRR Alarm"),
                days = days, enabled = o.optBoolean("enabled", true), trigger = o.optLong("trigger"),
                soundUri = if (o.isNull("soundUri")) null else o.optString("soundUri", ""),
                soundName = o.optString("soundName", ""),
                theme = o.optString("theme", "").ifBlank { com.texgen.music.texwave.ui.ref.DefaultAlarmTheme },
                snooze = o.optInt("snooze", 5).coerceIn(1, 30),
                vibrate = o.optBoolean("vibrate", true),
                icon = o.optString("icon", "auto"),
            )
        }
    }.getOrDefault(emptyList())

    fun get(ctx: Context, id: Int): AlarmRec? = load(ctx).firstOrNull { it.id == id }

    fun save(ctx: Context, list: List<AlarmRec>) {
        val arr = JSONArray()
        val ed = sp(ctx).edit()
        list.forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id); put("hour", a.hour); put("minute", a.minute)
                put("label", a.label); put("days", a.days); put("daily", a.days != 0)
                put("enabled", a.enabled); put("trigger", a.trigger)
                put("soundUri", a.soundUri ?: JSONObject.NULL)
                put("soundName", a.soundName); put("theme", a.theme)
                put("snooze", a.snooze); put("vibrate", a.vibrate); put("icon", a.icon)
            })
            ed.putString("theme_${a.id}", a.theme)
        }
        ed.putString(KEY, arr.toString()).apply()
    }

    fun update(ctx: Context, rec: AlarmRec) {
        save(ctx, load(ctx).map { if (it.id == rec.id) rec else it })
    }

    fun nextId(list: List<AlarmRec>): Int = (list.maxOfOrNull { it.id } ?: 1000) + 1

    // ---------------- Routine log (on-device) ----------------

    /** Remember that an alarm was dismissed now (used for streak + average wake time). */
    fun logDismiss(ctx: Context, id: Int) {
        val arr = runCatching { JSONArray(sp(ctx).getString("dismiss_log", "[]")) }.getOrDefault(JSONArray())
        arr.put(JSONObject().apply { put("t", System.currentTimeMillis()); put("id", id) })
        // keep the last 60 entries
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 60) until arr.length()) trimmed.put(arr.get(i))
        sp(ctx).edit().putString("dismiss_log", trimmed.toString()).apply()
    }

    private fun dismissTimes(ctx: Context): List<Long> = runCatching {
        val arr = JSONArray(sp(ctx).getString("dismiss_log", "[]"))
        (0 until arr.length()).map { arr.getJSONObject(it).getLong("t") }
    }.getOrDefault(emptyList())

    data class Routine(val streakDays: Int, val avgWake: String?, val last7: List<Boolean>)

    /** Consecutive days (ending today or yesterday) with at least one dismissed alarm. */
    fun routine(ctx: Context): Routine {
        val times = dismissTimes(ctx)
        fun dayKey(t: Long): Long {
            val c = Calendar.getInstance().apply { timeInMillis = t; set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            return c.timeInMillis / 86_400_000L
        }
        val days = times.map { dayKey(it) }.toSet()
        val today = dayKey(System.currentTimeMillis())
        var streak = 0
        var d = if (today in days) today else today - 1
        while (d in days) { streak++; d-- }
        val last7 = (6 downTo 0).map { (today - it) in days }
        val recent = times.filter { System.currentTimeMillis() - it < 7 * 86_400_000L }
        val avg = if (recent.isEmpty()) null else {
            val mins = recent.map {
                val c = Calendar.getInstance().apply { timeInMillis = it }
                c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            }.average().toInt()
            "%02d:%02d".format(mins / 60, mins % 60)
        }
        return Routine(streak, avg, last7)
    }
}
