package com.texgen.music.texwave.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.texgen.music.texwave.MainActivity
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.AppSettings
import com.texgen.music.texwave.util.SpeechOut
import com.texgen.music.texwave.util.VoskModelManager
import com.texgen.music.texwave.util.VoskShared
import org.vosk.Model
import org.vosk.Recognizer
import kotlin.concurrent.thread
import kotlin.math.sqrt

/**
 * Fully autonomous wake-word listener.
 *
 * Say "phantom" → hears it → speaks "I am hearing" → captures your next utterance →
 * broadcasts the command so Phantom can answer.
 *
 * Prefers offline Vosk when model is downloaded; otherwise uses Android SpeechRecognizer
 * in a reliable two-phase loop.
 */
class WakeWordService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var settings: AppSettings? = null
    private var running = false
    private var worker: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var speech: SpeechOut? = null
    private var androidSr: android.speech.SpeechRecognizer? = null

    @Volatile private var model: Model? = null

    /** IDLE = waiting for wake word; COMMAND = capturing the request after ack */
    @Volatile private var phase = Phase.IDLE

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        speech = SpeechOut(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // Must still satisfy the startForegroundService() contract on Android 8+.
            try { promoteToForeground("Stopping…") } catch (_: Throwable) {}
            stopSelfSafe()
            return START_NOT_STICKY
        }
        val hasMic = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        try {
            promoteToForeground(if (hasMic) "Starting…" else "Microphone permission required")
        } catch (_: Throwable) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!hasMic) {
            // A microphone foreground service is illegal without the permission; stop cleanly.
            stopSelfSafe()
            return START_NOT_STICKY
        }
        return try {
            val word = intent?.getStringExtra(EXTRA_WORD) ?: settings?.loadWakeWord() ?: "phantom"
            val silence = intent?.getIntExtra(EXTRA_SILENCE, settings?.loadWakeSilenceMs() ?: 1800) ?: 1800
            active = true
            startListening(word.lowercase().trim().ifBlank { "phantom" }, silence.coerceIn(800, 5000))
            START_STICKY
        } catch (_: Throwable) {
            stopSelfSafe()
            START_NOT_STICKY
        }
    }

    private fun promoteToForeground(text: String) {
        val notif = buildNotif(text)
        if (Build.VERSION.SDK_INT >= 29) {
            ServiceCompat.startForeground(
                this,
                NOTIF_ID,
                notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
            )
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun startListening(wakeWord: String, silenceMs: Int) {
        if (running) return
        val mgr = VoskModelManager(this)
        running = true
        phase = Phase.IDLE
        if (!mgr.isReady()) {
            promoteToForeground("Listening for “$wakeWord”")
            startAndroidWake(wakeWord)
            return
        }
        try {
            notifyListening("Listening for “$wakeWord”")
        } catch (_: Exception) {
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "texwave:wake").apply {
            setReferenceCounted(false)
        }

        worker = thread(name = "texwave-wake", isDaemon = true) {
            var recognizer: Recognizer? = null
            var record: AudioRecord? = null
            try {
                val m = VoskShared.model(mgr.modelPath()!!)
                model = m
                recognizer = Recognizer(m, SAMPLE_RATE.toFloat())
                val minBuf = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                )
                val bufSize = minBuf.coerceAtLeast(SAMPLE_RATE / 5)
                record = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufSize * 2,
                )
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    main.post {
                        notifyListening("Mic busy — using system voice")
                        startAndroidWake(wakeWord)
                    }
                    return@thread
                }
                record.startRecording()
                val shortBuf = ShortArray(bufSize)
                val byteBuf = ByteArray(bufSize * 2)

                val command = StringBuilder()
                var lastPartial = ""
                var lastVoiceAt = 0L
                var commandStartAt = 0L
                var ackUntil = 0L

                while (running) {
                    val n = record.read(shortBuf, 0, shortBuf.size)
                    if (n < 0) throw IllegalStateException("AudioRecord read error $n")
                    if (n == 0) continue
                    val now = System.currentTimeMillis()

                    // Ignore the assistant's own greeting so it is not heard as a command.
                    if (now < ackUntil) continue

                    var sum = 0.0
                    for (i in 0 until n) {
                        val v = shortBuf[i].toDouble()
                        sum += v * v
                    }
                    val voiced = sqrt(sum / n) > RMS_THRESHOLD
                    for (i in 0 until n) {
                        val sv = shortBuf[i].toInt()
                        byteBuf[i * 2] = (sv and 0xff).toByte()
                        byteBuf[i * 2 + 1] = ((sv shr 8) and 0xff).toByte()
                    }

                    // Always feed the recognizer (it needs the silences to find sentence ends).
                    val accept = recognizer.acceptWaveForm(byteBuf, n * 2)
                    val partial = if (accept) "" else extract(recognizer.partialResult, "partial")
                    val finalText = if (accept) extract(recognizer.result, "text") else ""

                    when (phase) {
                        Phase.IDLE -> {
                            val hay = normalize("$partial $finalText")
                            if (hay.isNotBlank() && matchesWake(hay, wakeWord)) {
                                phase = Phase.COMMAND
                                command.setLength(0)
                                lastPartial = ""
                                commandStartAt = now
                                lastVoiceAt = now
                                try { recognizer.reset() } catch (_: Exception) {}
                                val leftover = stripWake(hay, wakeWord)
                                if (leftover.isNotBlank()) command.append(leftover)
                                ackUntil = now + (if (leftover.isBlank()) 1_600L else 0L)
                                main.post {
                                    notifyListening("I am hearing…")
                                    if (leftover.isBlank()) speakAck()
                                }
                            }
                        }
                        Phase.COMMAND -> {
                            if (finalText.isNotBlank()) {
                                val cleaned = stripWake(normalize(finalText), wakeWord)
                                if (cleaned.isNotBlank()) {
                                    if (command.isNotEmpty()) command.append(' ')
                                    command.append(cleaned)
                                }
                                lastPartial = ""
                                lastVoiceAt = now
                            } else if (partial.isNotBlank() && partial != lastPartial) {
                                lastPartial = partial
                                lastVoiceAt = now
                            } else if (voiced && partial.isNotBlank()) {
                                lastVoiceAt = now
                            }

                            val heard = (command.toString() + " " + normalize(lastPartial)).trim()
                            val silentFor = now - lastVoiceAt
                            val finished = heard.isNotBlank() && silentFor >= silenceMs
                            val tooLong = now - commandStartAt > 12_000L
                            val nothing = heard.isBlank() && now - commandStartAt > 8_000L
                            if (finished || tooLong || nothing) {
                                val text = stripWake(normalize(heard), wakeWord).ifBlank { normalize(heard) }
                                command.setLength(0)
                                lastPartial = ""
                                phase = Phase.IDLE
                                try { recognizer.reset() } catch (_: Exception) {}
                                main.post {
                                    notifyListening("Listening for “$wakeWord”")
                                    if (text.isNotBlank()) sendCommand(text)
                                }
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                android.util.Log.e("WakeWord", "loop failed", t)
                if (running) {
                    main.post {
                        notifyListening("Using system voice")
                        startAndroidWake(wakeWord)
                    }
                }
            } finally {
                try { record?.stop() } catch (_: Throwable) {}
                try { record?.release() } catch (_: Throwable) {}
                try { recognizer?.close() } catch (_: Throwable) {}
                model = null // shared instance stays alive in VoskShared
            }
        }
    }

    private fun speakAck() {
        try {
            PhantomOrbService.show(this)
        } catch (_: Exception) {
        }
        try {
            speech?.speak("Welcome sir, what can I play?")
        } catch (_: Exception) {
        }
    }

    private fun normalize(s: String): String =
        s.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun matchesWake(hay: String, wakeWord: String): Boolean {
        val ww = wakeWord.lowercase().trim()
        if (ww.length < 2 || hay.isBlank()) return false
        val tokens = hay.split(" ").filter { it.isNotEmpty() }
        val variants = listOf(
            ww, "phantom", "fantom", "phantomm", "fan tom", "phan tom",
            "hey $ww", "ok $ww", "okay $ww",
        )
        if (variants.any { it in hay }) return true
        if (tokens.any { tok -> variants.any { v -> tok == v || (v.length >= 4 && tok.startsWith(v.take(4))) } }) return true
        return tokens.any { it.startsWith(ww) && it.length <= ww.length + 3 } ||
            (ww.length >= 3 && tokens.any { ww.startsWith(it) && it.length >= 3 })
    }

    private fun stripWake(hay: String, wakeWord: String): String {
        var t = hay
        listOf("hey $wakeWord", "ok $wakeWord", "okay $wakeWord", wakeWord, "hey phantom", "ok phantom", "phantom", "fantom", "fantom")
            .sortedByDescending { it.length }
            .forEach { prefix ->
                t = t.replace(prefix, " ")
            }
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private fun extract(json: String?, key: String): String {
        if (json.isNullOrBlank()) return ""
        return try {
            val i = json.indexOf("\"$key\"")
            if (i < 0) return ""
            val colon = json.indexOf(':', i)
            val start = json.indexOf('"', colon + 1) + 1
            val end = json.indexOf('"', start)
            if (start > 0 && end > start) json.substring(start, end).trim() else ""
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * Two-phase Android SpeechRecognizer loop:
     *  Phase IDLE  → listen until wake word heard → speak "I am hearing"
     *  Phase COMMAND → listen for the actual request → sendCommand → back to IDLE
     */
    private fun startAndroidWake(wakeWord: String) {
        main.post {
            try {
                if (!android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
                    notifyListening("Speech not available on this device")
                    stopSelfSafe()
                    return@post
                }
                try { androidSr?.destroy() } catch (_: Exception) {}
                val sr = android.speech.SpeechRecognizer.createSpeechRecognizer(this)
                androidSr = sr
                phase = Phase.IDLE

                fun buildIntent(commandMode: Boolean): Intent {
                    return Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(
                            android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                        )
                        putExtra(android.speech.RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                        putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                        putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "en-US")
                        // Longer window when capturing the command
                        putExtra(
                            android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
                            if (commandMode) 1800 else 1200,
                        )
                        putExtra(
                            android.speech.RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,
                            if (commandMode) 1200 else 800,
                        )
                    }
                }

                fun listenAgain() {
                    if (!running) {
                        try { sr.destroy() } catch (_: Exception) {}
                        return
                    }
                    val cmdMode = phase == Phase.COMMAND
                    try {
                        sr.startListening(buildIntent(cmdMode))
                    } catch (e: Exception) {
                        notifyListening("Mic error — retrying…")
                        main.postDelayed({ if (running) listenAgain() }, 900)
                    }
                }

                sr.setRecognitionListener(object : android.speech.RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) {
                        if (phase == Phase.IDLE) {
                            notifyListening("Say “$wakeWord”…")
                        } else {
                            notifyListening("I am hearing… speak now")
                        }
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        // Don't die on no-match / timeout — keep listening
                        val delay = when (error) {
                            android.speech.SpeechRecognizer.ERROR_NO_MATCH,
                            android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                            -> 350L
                            android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                            -> 900L
                            android.speech.SpeechRecognizer.ERROR_CLIENT,
                            -> 700L
                            else -> 600L
                        }
                        // If we timed out waiting for a command, go back to wake mode
                        if (phase == Phase.COMMAND &&
                            (error == android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                                error == android.speech.SpeechRecognizer.ERROR_NO_MATCH)
                        ) {
                            // give user one more chance, then reset after second fail
                            main.postDelayed({
                                if (!running) return@postDelayed
                                phase = Phase.IDLE
                                notifyListening("Listening for “$wakeWord”")
                                listenAgain()
                            }, delay)
                            return
                        }
                        main.postDelayed({ if (running) listenAgain() }, delay)
                    }
                    override fun onResults(results: android.os.Bundle?) {
                        val texts = results
                            ?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                            .orEmpty()
                        handleAndroidResult(texts, wakeWord) {
                            main.postDelayed({ if (running) listenAgain() }, 400)
                        }
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) {
                        // Only use partials for wake detection (faster ack)
                        if (phase != Phase.IDLE) return
                        val texts = partialResults
                            ?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                            .orEmpty()
                        for (raw in texts) {
                            val hay = normalize(raw)
                            if (matchesWake(hay, wakeWord)) {
                                try { sr.stopListening() } catch (_: Exception) {}
                                phase = Phase.COMMAND
                                notifyListening("I am hearing…")
                                speakAck()
                                val leftover = stripWake(hay, wakeWord)
                                if (leftover.isNotBlank()) {
                                    // User said "phantom play x" in one go
                                    sendCommand(leftover)
                                    phase = Phase.IDLE
                                }
                                main.postDelayed({ if (running) listenAgain() }, 700)
                                return
                            }
                        }
                    }
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
                listenAgain()
            } catch (e: Exception) {
                notifyListening("Wake failed: ${e.message?.take(40)}")
                stopSelfSafe()
            }
        }
    }

    private fun handleAndroidResult(texts: List<String>, wakeWord: String, continueListen: () -> Unit) {
        if (texts.isEmpty()) {
            continueListen()
            return
        }
        when (phase) {
            Phase.IDLE -> {
                for (raw in texts) {
                    val hay = normalize(raw)
                    if (matchesWake(hay, wakeWord)) {
                        phase = Phase.COMMAND
                        notifyListening("I am hearing…")
                        speakAck()
                        val leftover = stripWake(hay, wakeWord)
                        if (leftover.isNotBlank()) {
                            sendCommand(leftover)
                            phase = Phase.IDLE
                            notifyListening("Listening for “$wakeWord”")
                        }
                        continueListen()
                        return
                    }
                }
                continueListen()
            }
            Phase.COMMAND -> {
                // Pick the best non-empty transcript
                val best = texts
                    .map { stripWake(normalize(it), wakeWord) }
                    .firstOrNull { it.isNotBlank() }
                    ?: texts.firstOrNull()?.let { normalize(it) }.orEmpty()
                phase = Phase.IDLE
                if (best.isNotBlank()) {
                    notifyListening("Heard: $best")
                    sendCommand(best)
                } else {
                    notifyListening("Listening for “$wakeWord”")
                }
                continueListen()
            }
        }
    }

    private fun sendCommand(text: String) {
        val cleaned = text.trim()
        if (cleaned.isBlank()) return
        notifyListening("Heard: ${cleaned.take(40)}")
        // Persist so MusicApp can process even if broadcast is missed
        try {
            AppSettings(this).savePendingWakeCommand(cleaned)
        } catch (_: Exception) {
        }
        val i = Intent(ACTION_COMMAND).apply {
            setPackage(packageName)
            putExtra(EXTRA_TEXT, cleaned)
        }
        try { sendBroadcast(i) } catch (_: Exception) {}
        try {
            val open = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra("wake_command", cleaned)
                action = ACTION_COMMAND
            }
            startActivity(open)
        } catch (_: Exception) {
        }
        try {
            PhantomOrbService.show(this)
        } catch (_: Exception) {
        }
        try {
            speech?.speak("Okay")
        } catch (_: Exception) {
        }
    }

    private var lastNotifMsg = ""
    private var lastNotifAt = 0L
    private fun notifyListening(msg: String) {
        val now = System.currentTimeMillis()
        // Avoid notification spam (saves battery + UI jank)
        if (msg == lastNotifMsg && now - lastNotifAt < 4_000) return
        lastNotifMsg = msg
        lastNotifAt = now
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotif(msg))
    }

    private fun buildNotif(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle("PHANTOM is listening")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "Stop", stop)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Wake word", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Always-on PHANTOM wake-word listening"
                    setShowBadge(false)
                    setSound(null, null)
                },
            )
        }
    }

    private fun stopSelfSafe() {
        running = false
        active = false
        phase = Phase.IDLE
        try { androidSr?.destroy() } catch (_: Exception) {}
        androidSr = null
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        active = false
        try { androidSr?.destroy() } catch (_: Exception) {}
        androidSr = null
        worker = null
        try { speech?.shutdown() } catch (_: Exception) {}
        speech = null
        super.onDestroy()
    }

    private enum class Phase { IDLE, COMMAND }

    companion object {
        const val ACTION_COMMAND = "com.texgen.music.texwave.WAKE_COMMAND"
        const val ACTION_STOP = "com.texgen.music.texwave.WAKE_STOP"
        const val EXTRA_TEXT = "text"
        const val EXTRA_WORD = "word"
        const val EXTRA_SILENCE = "silence"
        private const val CHANNEL = "texwave_wake"
        private const val NOTIF_ID = 4250
        private const val SAMPLE_RATE = 16_000
        private const val RMS_THRESHOLD = 90.0

        /** True while the service is running (used by VoiceInput to free the mic). */
        @Volatile var active: Boolean = false

        fun start(context: Context, word: String = "phantom", silenceMs: Int = 1800) {
            val app = context.applicationContext
            if (androidx.core.content.ContextCompat.checkSelfPermission(app, android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) return
            val i = Intent(app, WakeWordService::class.java).apply {
                putExtra(EXTRA_WORD, word.ifBlank { "phantom" })
                putExtra(EXTRA_SILENCE, silenceMs)
            }
            try {
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i)
                else app.startService(i)
            } catch (e: Exception) {
                android.util.Log.e("WakeWord", "start failed", e)
            }
        }

        fun stop(context: Context) {
            val app = context.applicationContext
            if (!active) return
            active = false
            try {
                app.startService(Intent(app, WakeWordService::class.java).setAction(ACTION_STOP))
            } catch (_: Exception) {
                try { app.stopService(Intent(app, WakeWordService::class.java)) } catch (_: Exception) {}
            }
        }

        /** Resume wake listening after boot / app launch if user had it enabled. */
        fun startIfEnabled(context: Context) {
            val s = AppSettings(context)
            if (!s.loadWakeEnabled()) return
            start(context, s.loadWakeWord(), s.loadWakeSilenceMs())
        }
    }
}
