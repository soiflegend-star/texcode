package com.texgen.music.texwave.sonara.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer

private val Context.libraryDataStore: DataStore<Preferences> by preferencesDataStore("sonara_library")

/**
 * Local user library state: likes, recents, simple playlists.
 * Fully offline-capable. Survives process death.
 */
class UserLibraryStore(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }

    private val likesKey = stringSetPreferencesKey("liked_ids")
    private val recentsKey = stringPreferencesKey("recent_ids")
    private val playlistsKey = stringPreferencesKey("playlists_json")

    val likedIds: Flow<Set<String>> = context.libraryDataStore.data.map { prefs ->
        prefs[likesKey] ?: emptySet()
    }

    val recentIds: Flow<List<String>> = context.libraryDataStore.data.map { prefs ->
        val raw = prefs[recentsKey] ?: return@map emptyList()
        raw.split(",").filter { it.isNotBlank() }
    }

    suspend fun toggleLike(trackId: String): Boolean {
        var nowLiked = false
        context.libraryDataStore.edit { prefs ->
            val current = prefs[likesKey]?.toMutableSet() ?: mutableSetOf()
            if (current.contains(trackId)) {
                current.remove(trackId)
                nowLiked = false
            } else {
                current.add(trackId)
                nowLiked = true
            }
            prefs[likesKey] = current
        }
        return nowLiked
    }

    suspend fun isLiked(trackId: String): Boolean {
        var result = false
        context.libraryDataStore.data.map { it[likesKey] ?: emptySet() }.collect {
            result = trackId in it
            return@collect
        }
        return result
    }

    suspend fun addRecent(trackId: String) {
        context.libraryDataStore.edit { prefs ->
            val current = (prefs[recentsKey] ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
            current.remove(trackId)
            current.add(0, trackId)
            prefs[recentsKey] = current.take(50).joinToString(",")
        }
    }

    // Simple local playlists: id -> name + ordered track ids
    @kotlinx.serialization.Serializable
    data class LocalPlaylist(
        val id: String,
        val name: String,
        val trackIds: List<String> = emptyList(),
    )

    val playlists: Flow<List<LocalPlaylist>> = context.libraryDataStore.data.map { prefs ->
        val raw = prefs[playlistsKey] ?: return@map emptyList()
        try {
            json.decodeFromString(ListSerializer(LocalPlaylist.serializer()), raw)
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun savePlaylists(list: List<LocalPlaylist>) {
        context.libraryDataStore.edit { prefs ->
            prefs[playlistsKey] = json.encodeToString(ListSerializer(LocalPlaylist.serializer()), list)
        }
    }

    suspend fun createPlaylist(name: String): LocalPlaylist {
        val pl = LocalPlaylist(id = "pl_${System.currentTimeMillis()}", name = name.trim().ifBlank { "Playlist" })
        context.libraryDataStore.edit { prefs ->
            val current = try {
                val raw = prefs[playlistsKey] ?: "[]"
                json.decodeFromString(ListSerializer(LocalPlaylist.serializer()), raw).toMutableList()
            } catch (_: Exception) {
                mutableListOf()
            }
            current.add(0, pl)
            prefs[playlistsKey] = json.encodeToString(ListSerializer(LocalPlaylist.serializer()), current)
        }
        return pl
    }

    suspend fun addToPlaylist(playlistId: String, trackId: String) {
        context.libraryDataStore.edit { prefs ->
            val current = try {
                val raw = prefs[playlistsKey] ?: "[]"
                json.decodeFromString(ListSerializer(LocalPlaylist.serializer()), raw).toMutableList()
            } catch (_: Exception) {
                mutableListOf()
            }
            val idx = current.indexOfFirst { it.id == playlistId }
            if (idx >= 0) {
                val pl = current[idx]
                if (trackId !in pl.trackIds) {
                    current[idx] = pl.copy(trackIds = pl.trackIds + trackId)
                    prefs[playlistsKey] = json.encodeToString(ListSerializer(LocalPlaylist.serializer()), current)
                }
            }
        }
    }
}
