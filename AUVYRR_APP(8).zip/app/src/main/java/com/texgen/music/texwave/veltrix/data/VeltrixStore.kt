package com.texgen.music.texwave.veltrix.data

import android.content.Context
import com.texgen.music.texwave.veltrix.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

/**
 * Lightweight JSON file store — no Room dependency.
 * Files live under context.filesDir/veltrix/
 */
class VeltrixStore(context: Context) {
    private val dir = File(context.filesDir, "veltrix").also { it.mkdirs() }
    private val autoFile = File(dir, "automations.json")
    private val execFile = File(dir, "executions.json")

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private val _automations = MutableStateFlow<List<VxAutomation>>(emptyList())
    val automations: StateFlow<List<VxAutomation>> = _automations.asStateFlow()

    private val _executions = MutableStateFlow<List<VxExecution>>(emptyList())
    val executions: StateFlow<List<VxExecution>> = _executions.asStateFlow()

    private val loadLock = Mutex()
    @Volatile private var loaded = false

    suspend fun load() {
        loadLock.withLock {
            if (loaded) return
            withContext(Dispatchers.IO) {
                _automations.value = readList(autoFile)
                _executions.value = readList(execFile).sortedByDescending { it.startedAt }.take(200)
                if (_automations.value.isEmpty() && !autoFile.exists()) {
                    for (t in seedTemplates()) saveAutomation(t)
                }
            }
            loaded = true
        }
    }

    suspend fun saveAutomation(a: VxAutomation) = withContext(Dispatchers.IO) {
        val updated = a.copy(updatedAt = System.currentTimeMillis())
        val list = _automations.value.toMutableList()
        val idx = list.indexOfFirst { it.id == updated.id }
        if (idx >= 0) list[idx] = updated else list.add(0, updated)
        _automations.value = list
        writeList(autoFile, list)
    }

    suspend fun deleteAutomation(id: String) = withContext(Dispatchers.IO) {
        val list = _automations.value.filter { it.id != id }
        _automations.value = list
        writeList(autoFile, list)
    }

    suspend fun getAutomation(id: String): VxAutomation? =
        _automations.value.find { it.id == id }

    suspend fun saveExecution(e: VxExecution) = withContext(Dispatchers.IO) {
        val list = (listOf(e) + _executions.value).take(200)
        _executions.value = list
        writeList(execFile, list)
    }

    suspend fun updateStats(automationId: String, success: Boolean) {
        val a = getAutomation(automationId) ?: return
        saveAutomation(
            a.copy(
                lastRunAt = System.currentTimeMillis(),
                runCount = a.runCount + 1,
                successCount = a.successCount + if (success) 1 else 0,
                failureCount = a.failureCount + if (success) 0 else 1
            )
        )
    }

    fun exportJson(a: VxAutomation): String = json.encodeToString(a)

    fun importJson(raw: String): VxAutomation? = try {
        json.decodeFromString<VxAutomation>(raw).copy(
            id = UUID.randomUUID().toString(),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            lastRunAt = null,
            runCount = 0,
            successCount = 0,
            failureCount = 0
        )
    } catch (_: Exception) { null }

    private inline fun <reified T> readList(file: File): List<T> {
        if (!file.exists()) return emptyList()
        return try {
            json.decodeFromString<List<T>>(file.readText())
        } catch (_: Exception) { emptyList() }
    }

    private inline fun <reified T> writeList(file: File, list: List<T>) {
        file.writeText(json.encodeToString(list))
    }

    private fun seedTemplates(): List<VxAutomation> {
        fun n(kind: VxNodeKind, title: String, x: Float, y: Float, cfgs: List<VxConfig> = defaultConfigs(kind)) =
            VxNode(kind = kind, title = title, x = x, y = y, configs = cfgs)

        val morningTrigger = n(VxNodeKind.TRIGGER_TIME, "08:00 daily", 60f, 160f)
        val morningNotif = n(
            VxNodeKind.ACTION_NOTIFICATION, "Good morning", 300f, 160f,
            listOf(VxConfig("title", "Good morning"), VxConfig("body", "Have a great day from Veltrix"))
        )
        val morning = VxAutomation(
            name = "Morning Notification",
            description = "Daily 8:00 notification",
            status = VxAutomationStatus.ENABLED,
            nodes = listOf(morningTrigger, morningNotif),
            links = listOf(VxLink(fromId = morningTrigger.id, toId = morningNotif.id))
        )

        val batTrig = n(VxNodeKind.TRIGGER_MANUAL, "Manual", 60f, 160f)
        val info = n(VxNodeKind.ACTION_DEVICE_INFO, "Device Info", 260f, 160f)
        val cond = n(
            VxNodeKind.CONDITION, "Battery < 20", 460f, 160f,
            listOf(VxConfig("left", "{{battery}}"), VxConfig("operator", "<"), VxConfig("right", "20"))
        )
        val low = n(
            VxNodeKind.ACTION_NOTIFICATION, "Low battery", 700f, 80f,
            listOf(VxConfig("title", "Battery low"), VxConfig("body", "Battery is at {{battery}}%"))
        )
        val ok = n(VxNodeKind.ACTION_LOG, "OK", 700f, 240f, listOf(VxConfig("message", "Battery OK: {{battery}}%")))
        val battery = VxAutomation(
            name = "Low Battery Check",
            description = "Notify when battery is under 20%",
            status = VxAutomationStatus.ENABLED,
            nodes = listOf(batTrig, info, cond, low, ok),
            links = listOf(
                VxLink(fromId = batTrig.id, toId = info.id),
                VxLink(fromId = info.id, toId = cond.id),
                VxLink(fromId = cond.id, toId = low.id, label = "true"),
                VxLink(fromId = cond.id, toId = ok.id, label = "false")
            )
        )

        val urlTrig = n(VxNodeKind.TRIGGER_MANUAL, "Manual", 60f, 160f)
        val open = n(
            VxNodeKind.ACTION_OPEN_URL, "Open site", 300f, 160f,
            listOf(VxConfig("url", "https://musicbrainz.org"))
        )
        val website = VxAutomation(
            name = "Open Website",
            description = "Open a URL",
            status = VxAutomationStatus.DRAFT,
            nodes = listOf(urlTrig, open),
            links = listOf(VxLink(fromId = urlTrig.id, toId = open.id))
        )

        val httpTrig = n(VxNodeKind.TRIGGER_MANUAL, "Manual", 40f, 160f)
        val http = n(
            VxNodeKind.ACTION_HTTP, "GET httpbin", 240f, 160f,
            listOf(VxConfig("method", "GET"), VxConfig("url", "https://httpbin.org/get"), VxConfig("saveAs", "body"))
        )
        val httpNotif = n(
            VxNodeKind.ACTION_NOTIFICATION, "HTTP done", 480f, 160f,
            listOf(VxConfig("title", "HTTP Check"), VxConfig("body", "Request finished — see history for body"))
        )
        val httpAuto = VxAutomation(
            name = "HTTP Check",
            description = "HTTP GET then notify",
            status = VxAutomationStatus.DRAFT,
            nodes = listOf(httpTrig, http, httpNotif),
            links = listOf(
                VxLink(fromId = httpTrig.id, toId = http.id),
                VxLink(fromId = http.id, toId = httpNotif.id)
            )
        )

        return listOf(morning, battery, website, httpAuto)
    }
}
