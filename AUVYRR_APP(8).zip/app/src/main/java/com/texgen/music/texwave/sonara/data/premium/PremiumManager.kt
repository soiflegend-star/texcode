package com.texgen.music.texwave.sonara.data.premium

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.premiumStore by preferencesDataStore("sonara_premium")

/**
 * Free vs premium entitlements.
 * Free users: configurable download/save allowance (default 10).
 * Premium flag is server-authoritative when Supabase is configured;
 * local flag is for demo / offline display only — never trust client alone for payments.
 *
 * Google Play Billing integration is the production path for setting isPremium;
 * this class only enforces local counters and reads the premium state.
 */
class PremiumManager(private val context: Context) {

    private val downloadsUsedKey = intPreferencesKey("downloads_used")
    private val downloadedIdsKey = stringSetPreferencesKey("downloaded_track_ids")
    private val localPremiumKey = booleanPreferencesKey("local_premium_demo")
    private val freeLimitKey = intPreferencesKey("free_limit")

    val freeLimit: Flow<Int> = context.premiumStore.data.map { it[freeLimitKey] ?: 10 }

    val downloadsUsed: Flow<Int> = context.premiumStore.data.map { it[downloadsUsedKey] ?: 0 }

    val downloadedIds: Flow<Set<String>> = context.premiumStore.data.map { it[downloadedIdsKey] ?: emptySet() }

    val isLocalPremiumDemo: Flow<Boolean> = context.premiumStore.data.map { it[localPremiumKey] ?: false }

    suspend fun setFreeLimit(limit: Int) {
        context.premiumStore.edit { it[freeLimitKey] = limit.coerceAtLeast(0) }
    }

    /** Demo-only toggle. Production must use Play Billing + server entitlement. */
    suspend fun setDemoPremium(enabled: Boolean) {
        context.premiumStore.edit { it[localPremiumKey] = enabled }
    }

    /**
     * Attempt to grant a download. Returns false if free quota exhausted and not premium.
     */
    suspend fun tryGrantDownload(trackId: String, isPremium: Boolean, freeLimit: Int = 10): Boolean {
        var allowed = false
        context.premiumStore.edit { prefs ->
            val used = prefs[downloadsUsedKey] ?: 0
            val ids = prefs[downloadedIdsKey]?.toMutableSet() ?: mutableSetOf()
            if (trackId in ids) {
                allowed = true
                return@edit
            }
            if (isPremium || prefs[localPremiumKey] == true || used < freeLimit) {
                ids.add(trackId)
                prefs[downloadedIdsKey] = ids
                if (!isPremium && prefs[localPremiumKey] != true) {
                    prefs[downloadsUsedKey] = used + 1
                }
                allowed = true
            }
        }
        return allowed
    }

    suspend fun removeDownload(trackId: String) {
        context.premiumStore.edit { prefs ->
            val ids = prefs[downloadedIdsKey]?.toMutableSet() ?: return@edit
            if (ids.remove(trackId)) {
                prefs[downloadedIdsKey] = ids
            }
        }
    }
}
