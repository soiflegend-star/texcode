package com.texgen.music.texwave.ui.screens

import com.texgen.music.texwave.ui.theme.Tx
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.sin

/** AUVYRR signature — Living Wave (crash-safe). */
@Composable
fun LivingWaveScreen(
    reducedMotion: Boolean = false,
    onEnterWave: () -> Unit,
    onEnterLibrary: () -> Unit,
    onEnterYou: () -> Unit,
) {
    val intro = remember { Animatable(if (reducedMotion) 1f else 0f) }
    val ripples = remember { mutableStateListOf<Ripple>() }
    var time by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(reducedMotion) {
        if (reducedMotion) {
            intro.snapTo(1f)
            return@LaunchedEffect
        }
        try {
            delay(80)
            intro.animateTo(0.4f, tween(450, easing = FastOutSlowInEasing))
            intro.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
        } catch (_: Exception) {
            intro.snapTo(1f)
        }
    }

    LaunchedEffect(Unit) {
        try {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.04f)
                time += dt
                last = now
                val t = time
                ripples.removeAll { t - it.born > 1.2f }
            }
        } catch (_: Exception) {
        }
    }

    val breath by rememberInfiniteTransition(label = "bw").animateFloat(
        0.97f, 1.03f,
        infiniteRepeatable(tween(3000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bv",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Tx.Bg)
            .pointerInput(Unit) {
                detectTapGestures { off ->
                    if (ripples.size < 10) ripples.add(Ripple(off.x, off.y, time))
                }
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            if (w < 16f || h < 16f) return@Canvas
            val t = time
            val cx = w * 0.5f
            val cy = h * 0.42f
            val expand = intro.value.coerceIn(0f, 1f)

            drawRect(
                Brush.radialGradient(
                    listOf(Color(0xFF151517), Tx.Bg),
                    Offset(cx, cy),
                    w * 0.9f,
                )
            )

            if (expand < 0.3f) {
                val r = (6f + expand * 90f)
                drawCircle(Tx.Accent2.copy(alpha = 0.85f), r * 0.2f, Offset(cx, cy))
                drawCircle(Tx.Accent2.copy(alpha = 0.3f), r, Offset(cx, cy))
            }

            val amp = h * 0.035f * expand * (if (reducedMotion) 0.6f else breath)
            val colors = listOf(Color(0xFF00F0C8), Tx.Accent2, Tx.Accent)
            for (layer in 0..2) {
                val path = Path()
                val yBase = cy + layer * h * 0.016f
                val phase = t * (0.65f + layer * 0.12f) + layer
                val col = colors[layer].copy(alpha = (0.3f + layer * 0.1f) * expand)
                path.moveTo(0f, yBase)
                var x = 0f
                while (x <= w) {
                    val y = yBase + amp * (
                        sin(x * 0.008f + phase) * 0.65f +
                            sin(x * 0.018f - phase * 1.2f) * 0.35f
                        ).toFloat()
                    path.lineTo(x, y)
                    x += 10f
                }
                drawPath(path, col, style = Stroke(width = (2.2f + layer) * density, cap = StrokeCap.Round))
            }

            val now = t
            for (r in ripples.toList()) {
                val age = ((now - r.born) / 1.2f).coerceIn(0f, 1f)
                val radius = age * w * 0.3f
                val a = (1f - age) * 0.5f
                drawCircle(
                    Tx.Accent2.copy(alpha = a),
                    radius,
                    Offset(r.x, r.y),
                    style = Stroke(width = 1.5f * density),
                )
            }
        }

        val contentAlpha = ((intro.value - 0.25f) / 0.75f).coerceIn(0f, 1f)
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
                .alpha(contentAlpha),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(36.dp))
            Text(
                "T E X W A V E",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 8.sp,
            )
            Box(
                Modifier
                    .padding(top = 10.dp)
                    .fillMaxWidth(0.4f)
                    .height(2.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Tx.Accent2, Tx.Accent, Color.Transparent)
                        )
                    )
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "Every connection begins with a wave.",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.weight(1f))
            Box(
                Modifier
                    .scale(if (reducedMotion) 1f else breath)
                    .size(110.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0x3340E0FF), Color(0x228B6CFF), Color.Transparent)
                        )
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("YOUR SPACE.", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("YOUR WAVE.", color = Tx.Accent2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("Everything begins here.", color = Color.White.copy(alpha = 0.45f), fontSize = 10.sp)
                }
            }
            Spacer(Modifier.weight(0.9f))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0x22FFFFFF))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                Dock(Icons.Rounded.GraphicEq, "Wave", true, onEnterWave)
                Dock(Icons.Rounded.LibraryMusic, "Library", false, onEnterLibrary)
                Dock(Icons.Rounded.Person, "You", false, onEnterYou)
            }
            TextButton(onClick = onEnterWave) {
                Text("Enter AUVYRR", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun Dock(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) Color(0x3300E5FF) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Icon(icon, null, tint = if (selected) Tx.Accent2 else Color.White.copy(alpha = 0.85f), modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = if (selected) Tx.Accent2 else Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
    }
}

private data class Ripple(val x: Float, val y: Float, val born: Float)
