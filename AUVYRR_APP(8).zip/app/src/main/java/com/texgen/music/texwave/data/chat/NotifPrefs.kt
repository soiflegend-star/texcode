package com.texgen.music.texwave.data.chat

import android.content.Context
import java.util.Calendar

/** What the user chose in the Notification editor. Read by [ChatNotifier] every time it posts. */
object NotifPrefs {
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("texwave_notif_prefs", Context.MODE_PRIVATE)

    fun messages(ctx: Context) = sp(ctx).getBoolean("messages", true)
    fun calls(ctx: Context) = sp(ctx).getBoolean("calls", true)
    fun preview(ctx: Context) = sp(ctx).getBoolean("preview", true)
    fun sound(ctx: Context) = sp(ctx).getBoolean("sound", true)
    fun vibrate(ctx: Context) = sp(ctx).getBoolean("vibrate", true)
    fun hideOnLockScreen(ctx: Context) = sp(ctx).getBoolean("lock_private", true)
    fun quietEnabled(ctx: Context) = sp(ctx).getBoolean("quiet", false)
    fun quietStart(ctx: Context) = sp(ctx).getInt("quiet_start", 22)
    fun quietEnd(ctx: Context) = sp(ctx).getInt("quiet_end", 7)

    fun set(ctx: Context, key: String, v: Boolean) { sp(ctx).edit().putBoolean(key, v).apply() }
    fun setHour(ctx: Context, key: String, h: Int) { sp(ctx).edit().putInt(key, ((h % 24) + 24) % 24).apply() }

    /** True while quiet hours are on and the clock is inside the window (works across midnight). */
    fun inQuietHours(ctx: Context): Boolean {
        if (!quietEnabled(ctx)) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val s = quietStart(ctx)
        val e = quietEnd(ctx)
        return if (s == e) false else if (s < e) h in s until e else (h >= s || h < e)
    }
}
