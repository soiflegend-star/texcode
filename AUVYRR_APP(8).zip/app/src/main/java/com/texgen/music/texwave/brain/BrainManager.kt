package com.texgen.music.texwave.brain

import android.app.ActivityManager
import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.texgen.music.texwave.util.NetUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

/**
 * Everything about Brains in one place: download (percent, pause, resume, delete),
 * choosing the active one, loading it safely, and asking it questions.
 */
class BrainManager private constructor(context: Context) {

    enum class Status { NOT_INSTALLED, DOWNLOADING, PAUSED, INSTALLED, ERROR }

    data class Dl(
        val status: Status = Status.NOT_INSTALLED,
        val bytes: Long = 0,
        val total: Long = 0,
        val error: String? = null,
    ) {
        val percent: Int get() = if (total > 0) ((bytes * 100) / total).toInt().coerceIn(0, 100) else 0
    }

    data class Assist(val text: String, val playQuery: String?)

    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("auvyrr_brain", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
    private val dir: File = (app.getExternalFilesDir("brains") ?: File(app.filesDir, "brains")).also { it.mkdirs() }

    private val jobs = HashMap<String, Job>()
    private val _states = MutableStateFlow<Map<String, Dl>>(emptyMap())
    val states: StateFlow<Map<String, Dl>> = _states.asStateFlow()

    private val _activeId = MutableStateFlow(prefs.getString(KEY_ACTIVE, null))
    val activeId: StateFlow<String?> = _activeId.asStateFlow()

    private val _customs = MutableStateFlow(loadCustoms())
    val customs: StateFlow<List<Brain>> = _customs.asStateFlow()

    private val _thinking = MutableStateFlow(false)
    val thinking: StateFlow<Boolean> = _thinking.asStateFlow()

    // ---- engine
    private val genLock = Mutex()
    private var llm: LlmInference? = null
    private var loadedId: String? = null
    private var idleJob: Job? = null

    init {
        // A previous load that never finished means the phone ran out of memory: flag that Brain.
        prefs.getString(KEY_LOADING, null)?.let { crashed ->
            prefs.edit().putBoolean(KEY_BAD + crashed, true).remove(KEY_LOADING).commit()
        }
        refresh()
    }

    fun allBrains(): List<Brain> = BrainCatalog.builtIn + _customs.value

    fun find(id: String?): Brain? = allBrains().firstOrNull { it.id == id }

    private fun fileOf(b: Brain) = File(dir, b.fileName)
    private fun partOf(b: Brain) = File(dir, b.fileName + ".part")

    private fun looksComplete(b: Brain): Boolean {
        val f = fileOf(b)
        if (!f.exists()) return false
        val min = if (b.custom) 20_000_000L else (b.approxBytes * 0.9).toLong()
        return f.length() >= min
    }

    fun refresh() {
        val cur = _states.value
        val next = HashMap<String, Dl>()
        for (b in allBrains()) {
            val old = cur[b.id]
            next[b.id] = when {
                old != null && old.status == Status.DOWNLOADING && jobs[b.id]?.isActive == true -> old
                looksComplete(b) -> Dl(Status.INSTALLED, fileOf(b).length(), fileOf(b).length())
                partOf(b).exists() && partOf(b).length() > 0 ->
                    Dl(Status.PAUSED, partOf(b).length(), if (b.custom) 0 else b.approxBytes)
                else -> Dl()
            }
        }
        _states.value = next
        // Auto-pick a Brain if none is active yet
        val act = _activeId.value
        if (act == null || next[act]?.status != Status.INSTALLED) {
            val first = allBrains().firstOrNull { next[it.id]?.status == Status.INSTALLED }
            setActiveInternal(first?.id)
        }
    }

    private fun setActiveInternal(id: String?) {
        _activeId.value = id
        prefs.edit().apply { if (id == null) remove(KEY_ACTIVE) else putString(KEY_ACTIVE, id) }.apply()
    }

    fun use(id: String) {
        val b = find(id) ?: return
        if (_states.value[id]?.status != Status.INSTALLED) return
        prefs.edit().remove(KEY_BAD + b.id).apply() // user chose it explicitly: give it another chance
        setActiveInternal(id)
        releaseEngine()
    }

    fun isBad(id: String): Boolean = prefs.getBoolean(KEY_BAD + id, false)

    fun activeBrain(): Brain? = find(_activeId.value)?.takeIf { _states.value[it.id]?.status == Status.INSTALLED }

    /** True when a Brain is installed, selected and has not crashed the phone before. */
    fun isReady(): Boolean = activeBrain()?.let { !isBad(it.id) } == true

    fun totalRamGb(): Double {
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.totalMem / 1_073_741_824.0
    }

    /** True if the phone has enough memory for this Brain (with a little slack for rounding). */
    fun fitsPhone(b: Brain): Boolean = totalRamGb() >= b.minRamGb * 0.8

    // ------------------------------------------------------------------ downloads

    private fun put(id: String, dl: Dl) {
        _states.value = _states.value.toMutableMap().also { it[id] = dl }
    }

    fun download(b: Brain) {
        if (jobs[b.id]?.isActive == true) return
        jobs[b.id] = scope.launch { runDownload(b) }
    }

    fun pause(id: String) {
        val b = find(id) ?: return
        jobs[id]?.cancel()
        jobs.remove(id)
        val have = partOf(b).length()
        put(id, Dl(Status.PAUSED, have, if (b.custom) 0 else b.approxBytes))
    }

    /** Stop and throw away everything for this Brain. */
    fun delete(id: String) {
        val b = find(id) ?: return
        jobs[id]?.cancel()
        jobs.remove(id)
        if (loadedId == id) releaseEngine()
        runCatching { fileOf(b).delete() }
        runCatching { partOf(b).delete() }
        prefs.edit().remove(KEY_BAD + id).apply()
        put(id, Dl())
        if (_activeId.value == id) setActiveInternal(null)
        refresh()
    }

    private suspend fun runDownload(b: Brain) {
        val part = partOf(b)
        var have = if (part.exists()) part.length() else 0L
        put(b.id, Dl(Status.DOWNLOADING, have, if (b.custom) 0 else b.approxBytes))
        try {
            val need = (if (b.custom) 2_000_000_000L else b.approxBytes) - have + 300_000_000L
            if (dir.usableSpace < need) {
                throw IOException("Not enough free space — need about ${need / 1_000_000} MB more.")
            }
            var attempt = 0
            while (true) {
                try {
                    transfer(b, part)
                    break
                } catch (e: IOException) {
                    if (!coroutineContext.isActive) throw e
                    attempt++
                    have = if (part.exists()) part.length() else 0L
                    if (attempt >= 6) throw e
                    put(b.id, Dl(Status.DOWNLOADING, have, _states.value[b.id]?.total ?: 0, "Connection problem, retrying…"))
                    delay(2_000L * attempt)
                }
            }
            val total = _states.value[b.id]?.total ?: 0L
            if (total > 0 && part.length() != total) throw IOException("Download incomplete, tap Resume.")
            val dest = fileOf(b)
            dest.delete()
            if (!part.renameTo(dest)) throw IOException("Could not save the Brain file.")
            put(b.id, Dl(Status.INSTALLED, dest.length(), dest.length()))
            if (_activeId.value == null) setActiveInternal(b.id)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Throwable) {
            val msg = when (e) {
                is java.net.UnknownHostException, is java.net.ConnectException -> "No internet — connect and tap Resume."
                is java.net.SocketTimeoutException -> "Connection too slow — tap Resume."
                else -> e.message ?: "Download failed"
            }
            val have = if (part.exists()) part.length() else 0L
            put(b.id, Dl(Status.ERROR, have, _states.value[b.id]?.total ?: 0, msg))
        }
    }

    /** One HTTP transfer that resumes from whatever is already in the .part file. */
    private suspend fun transfer(b: Brain, part: File) {
        val have = if (part.exists()) part.length() else 0L
        val req = Request.Builder().url(b.url).apply {
            if (have > 0) header("Range", "bytes=$have-")
        }.build()
        client.newCall(req).execute().use { resp ->
            if (resp.code == 416 && have > 0) return // already have everything
            if (!resp.isSuccessful) {
                throw if (resp.code == 401 || resp.code == 403)
                    IllegalStateException("This Brain needs a login to download (HTTP ${resp.code}).")
                else IOException("Server error HTTP ${resp.code}")
            }
            val body = resp.body ?: throw IOException("Empty response")
            val append = resp.code == 206 && have > 0
            val start = if (append) have else 0L
            val len = body.contentLength()
            val total = if (len > 0) start + len else (_states.value[b.id]?.total ?: 0L)
            var done = start
            var lastUi = 0L
            put(b.id, Dl(Status.DOWNLOADING, done, total))
            FileOutputStream(part, append).use { out ->
                body.byteStream().use { input ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        if (!coroutineContext.isActive) throw kotlinx.coroutines.CancellationException()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastUi > 300) {
                            lastUi = now
                            put(b.id, Dl(Status.DOWNLOADING, done, total))
                        }
                    }
                    out.flush()
                }
            }
            put(b.id, Dl(Status.DOWNLOADING, done, total))
        }
    }

    // ------------------------------------------------------------------ custom Brains

    private fun loadCustoms(): List<Brain> = try {
        val arr = JSONArray(prefs.getString(KEY_CUSTOMS, "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Brain(
                id = o.getString("id"),
                name = o.getString("name"),
                tagline = "Your own Brain",
                sizeLabel = "custom",
                approxBytes = 0L,
                minRamGb = 0,
                url = o.getString("url"),
                fileName = o.getString("file"),
                style = runCatching { PromptStyle.valueOf(o.getString("style")) }.getOrDefault(PromptStyle.CHATML),
                speed = "?", smarts = "?",
                custom = true,
            )
        }
    } catch (_: Throwable) { emptyList() }

    /** Add a Brain from any direct .task / .bin download link (for people who want another model). */
    fun addCustom(name: String, url: String, style: PromptStyle): Result<Brain> {
        val u = url.trim()
        if (!u.startsWith("https://")) return Result.failure(IllegalArgumentException("Link must start with https://"))
        val clean = name.trim().ifBlank { "My Brain" }.take(24)
        val id = "custom_" + System.currentTimeMillis()
        val brain = Brain(
            id = id, name = clean, tagline = "Your own Brain", sizeLabel = "custom", approxBytes = 0L,
            minRamGb = 0, url = u, fileName = "$id.task", style = style, speed = "?", smarts = "?", custom = true,
        )
        val list = _customs.value + brain
        _customs.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)
                .put("file", it.fileName).put("style", it.style.name))
        }
        prefs.edit().putString(KEY_CUSTOMS, arr.toString()).apply()
        refresh()
        return Result.success(brain)
    }

    fun removeCustom(id: String) {
        delete(id)
        val list = _customs.value.filterNot { it.id == id }
        _customs.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)
                .put("file", it.fileName).put("style", it.style.name))
        }
        prefs.edit().putString(KEY_CUSTOMS, arr.toString()).apply()
        refresh()
    }

    // ------------------------------------------------------------------ engine

    fun releaseEngine() {
        idleJob?.cancel()
        val old = llm
        llm = null
        loadedId = null
        if (old != null) scope.launch { runCatching { genLock.withLock { old.close() } } }
    }

    private fun scheduleIdleRelease() {
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(4 * 60_000L)
            if (!genLock.isLocked) releaseEngine()
        }
    }

    private fun ensureLoaded(b: Brain): LlmInference {
        val cur = llm
        if (cur != null && loadedId == b.id) return cur
        runCatching { cur?.close() }
        llm = null
        loadedId = null
        if (!fileOf(b).exists()) throw IllegalStateException("Brain file is missing — download it again.")
        if (!fitsPhone(b)) {
            throw IllegalStateException("${b.name} needs about ${b.minRamGb} GB of RAM. Pick a smaller Brain.")
        }
        // If the phone kills the app while loading, this marker tells us next launch (see init).
        prefs.edit().putString(KEY_LOADING, b.id).commit()
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(fileOf(b).absolutePath)
            .setMaxTokens(1024)
            .build()
        val engine = try {
            LlmInference.createFromOptions(app, opts)
        } finally {
            // Reached on success or on a normal exception; only a hard kill leaves the marker behind.
            prefs.edit().remove(KEY_LOADING).commit()
        }
        llm = engine
        loadedId = b.id
        return engine
    }

    private fun buildPrompt(b: Brain, system: String, history: List<Pair<Boolean, String>>, user: String): String {
        val turns = history.takeLast(4).map { it.first to it.second.take(300) } + (true to user.take(600))
        val sb = StringBuilder()
        when (b.style) {
            PromptStyle.CHATML -> {
                sb.append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
                turns.forEach { (u, t) -> sb.append("<|im_start|>").append(if (u) "user" else "assistant").append("\n").append(t).append("<|im_end|>\n") }
                sb.append("<|im_start|>assistant\n")
            }
            PromptStyle.ZEPHYR -> {
                sb.append("<|system|>\n").append(system).append("</s>\n")
                turns.forEach { (u, t) -> sb.append(if (u) "<|user|>\n" else "<|assistant|>\n").append(t).append("</s>\n") }
                sb.append("<|assistant|>\n")
            }
            PromptStyle.PHI -> {
                sb.append("<|system|>").append(system).append("<|end|>")
                turns.forEach { (u, t) -> sb.append(if (u) "<|user|>" else "<|assistant|>").append(t).append("<|end|>") }
                sb.append("<|assistant|>")
            }
            PromptStyle.GEMMA -> {
                sb.append("<start_of_turn>user\n").append(system).append("\n\n")
                turns.forEachIndexed { i, (u, t) ->
                    if (i > 0) sb.append(if (u) "<start_of_turn>user\n" else "<start_of_turn>model\n")
                    sb.append(t).append("<end_of_turn>\n")
                }
                sb.append("<start_of_turn>model\n")
            }
        }
        return sb.toString()
    }

    private fun clean(raw: String): String =
        raw.replace(Regex("<\\|?[a-zA-Z_/]+\\|?>"), " ")
            .replace("</s>", " ")
            .replace(Regex("\\s+\\n"), "\n")
            .trim()

    /** Ask the active Brain. Runs off the main thread; one question at a time. */
    suspend fun generate(
        system: String,
        user: String,
        history: List<Pair<Boolean, String>> = emptyList(),
    ): Result<String> = withContext(Dispatchers.Default) {
        val b = activeBrain() ?: return@withContext Result.failure(IllegalStateException("No Brain installed yet."))
        if (isBad(b.id)) {
            return@withContext Result.failure(
                IllegalStateException("${b.name} ran out of memory last time. Choose a smaller Brain in Brains."),
            )
        }
        genLock.withLock {
            _thinking.value = true
            try {
                val engine = ensureLoaded(b)
                val out = engine.generateResponse(buildPrompt(b, system, history, user))
                val text = clean(out.orEmpty())
                scheduleIdleRelease()
                if (text.isBlank()) Result.failure(IllegalStateException("The Brain had no answer."))
                else Result.success(text)
            } catch (t: Throwable) {
                android.util.Log.e("Brain", "generate failed", t)
                releaseEngineLocked()
                Result.failure(IllegalStateException(t.message ?: "Brain failed to answer"))
            } finally {
                _thinking.value = false
            }
        }
    }

    private fun releaseEngineLocked() {
        runCatching { llm?.close() }
        llm = null
        loadedId = null
    }

    // ------------------------------------------------------------------ assistant helpers

    private fun nowText(): String {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR)
        val hh = if (h == 0) 12 else h
        val ampm = if (c.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"
        val day = c.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()) ?: ""
        return "%d:%02d %s, %s".format(hh, c.get(Calendar.MINUTE), ampm, day)
    }

    /**
     * Chat + music brain. If the user wants music the model answers "PLAY: <what>" and the caller starts it.
     * Tone follows the user's mood (see [Persona]).
     */
    suspend fun assist(
        question: String,
        nowPlaying: String? = null,
        history: List<Pair<Boolean, String>> = emptyList(),
        mood: Persona.Mood = Persona.Mood.NEUTRAL,
    ): Result<Assist> {
        val system = buildString {
            append(Persona.voiceDirective(mood)).append(' ')
            append("You run fully offline on the user's phone, so you cannot check live data such as weather, news or the web. ")
            append("Reply in one to three short sentences. ")
            append("If the user wants to hear music (a song, artist, mood or genre), reply with exactly one line: PLAY: <song, artist or mood>. ")
            append("Time now: ").append(nowText()).append(". ")
            if (!nowPlaying.isNullOrBlank()) append("Now playing: ").append(nowPlaying).append(".")
        }
        return generate(system, question, history).map { raw ->
            val m = Regex("(?im)^\\s*PLAY\\s*:\\s*(.+)$").find(raw)
            if (m != null) Assist(raw, m.groupValues[1].trim().trim('"', '.', ' ')) else Assist(raw, null)
        }
    }

    /**
     * Morning greeting. Built only from facts the phone really knows (time, date, alarm name), so it is
     * always true — the Brain is deliberately not allowed to improvise here.
     */
    fun morningGreeting(label: String, extraTruth: String? = null): String =
        Persona.greeting(label, NetUtil.isOnline(app), extraTruth)

    fun isOnline(): Boolean = NetUtil.isOnline(app)

    companion object {
        private const val KEY_ACTIVE = "active"
        private const val KEY_LOADING = "loading"
        private const val KEY_BAD = "bad_"
        private const val KEY_CUSTOMS = "customs"

        @Volatile private var inst: BrainManager? = null

        fun get(context: Context): BrainManager =
            inst ?: synchronized(this) { inst ?: BrainManager(context).also { inst = it } }
    }
}
