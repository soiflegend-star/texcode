package com.texgen.music.texwave.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Phantom studio capabilities: structured coding assistance (TEXCODE rulebook)
 * and practical image tools.
 *
 * Honesty contract:
 * - Coding quality is bounded by the configured LLM (Groq/etc.). It is not
 *   equivalent to a full senior-engineer pair-programmer (e.g. Grok).
 * - “Image generation” requires a dedicated image API key; without it we only
 *   do local transforms + prompt drafting.
 * - Local edits (filters, contrast) are real pixel operations on-device.
 */
object PhantomStudio {

    enum class Mode { CHAT, CODE, IMAGE }

    // ── Rulebook ────────────────────────────────────────────────────────────

    fun loadRulebookSnippet(context: Context, relativePath: String, maxChars: Int = 12_000): String {
        return try {
            context.assets.open("rulebook/$relativePath").use { input ->
                BufferedReader(InputStreamReader(input)).readText().take(maxChars)
            }
        } catch (t: Throwable) {
            Log.w("PhantomStudio", "rulebook missing $relativePath: ${t.message}")
            ""
        }
    }

    fun codeSystemPrompt(context: Context): String {
        val standards = loadRulebookSnippet(context, "standards/CODING_STANDARDS.md", 6_000)
        val quality = loadRulebookSnippet(context, "standards/QUALITY_GATE.md", 4_000)
        val brain = loadRulebookSnippet(context, "playbooks/BRAIN_ENGINE.md", 4_000)
        return buildString {
            appendLine("You are PHANTOM CODE inside AUVYRR — a structured coding assistant.")
            appendLine("You follow the TEXCODE rulebook for planning and quality gates.")
            appendLine("Be honest: you are not as capable as a frontier model pair-programmer.")
            appendLine("Prefer small, working code units; explain limitations; never invent APIs.")
            appendLine()
            appendLine("=== CODING_STANDARDS (excerpt) ===")
            appendLine(standards)
            appendLine("=== QUALITY_GATE (excerpt) ===")
            appendLine(quality)
            appendLine("=== BRAIN_ENGINE (excerpt) ===")
            appendLine(brain)
            appendLine("When asked to build an app, outline modules first, then produce concrete files.")
            appendLine("Mark speculative code with // TODO or comments.")
        }
    }

    fun imageSystemPrompt(): String = """
        You are PHANTOM IMAGE inside AUVYRR.
        You help users craft image prompts and describe edits.
        You cannot rasterize pixels unless a dedicated image API is configured.
        For local edits (brightness, contrast, grayscale, vignette), tell the user
        to use the on-device filter buttons — those are real.
        Never claim you generated or edited a bitmap if you only produced text.
    """.trimIndent()

    // ── LLM call (Groq OpenAI-compatible) ───────────────────────────────────

    suspend fun complete(
        context: Context,
        system: String,
        user: String,
        apiKey: String?,
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isNullOrBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Add a Groq API key in Phantom settings for online CODE / IMAGE help.")
            )
        }
        val models = listOf(
            "openai/gpt-oss-20b",
            "openai/gpt-oss-120b",
            "qwen/qwen3.8-27b",
            "allam-2-7b",
            "openai/gpt-oss-safeguard-20b",
            "llama-3.1-8b-instant",
            "llama-3.3-70b-versatile",
        )
        var lastError: Throwable? = null
        for (modelId in models) {
            try {
                val body = JSONObject()
                body.put("model", modelId)
                body.put("temperature", 0.4)
                val messages = JSONArray()
                messages.put(JSONObject().put("role", "system").put("content", system))
                messages.put(JSONObject().put("role", "user").put("content", user))
                body.put("messages", messages)

                val conn = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.setRequestProperty("Authorization", "Bearer $apiKey")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.connectTimeout = 30_000
                conn.readTimeout = 60_000
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream.bufferedReader().readText()
                if (code !in 200..299) {
                    val msg = text.lowercase()
                    lastError = IllegalStateException("LLM error $code: ${text.take(200)}")
                    if (code == 404 || "model" in msg || "not found" in msg || "decommission" in msg) {
                        continue // try next model
                    }
                    return@withContext Result.failure(lastError!!)
                }
                val json = JSONObject(text)
                val content = json.getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                return@withContext Result.success(content)
            } catch (t: Throwable) {
                lastError = t
            }
        }
        Result.failure(lastError ?: IllegalStateException("No Groq model available"))
    }

    // ── Local image edits (real pixel ops) ──────────────────────────────────

    enum class ImageFilter { NONE, GRAYSCALE, CONTRAST, WARM, COOL, VIGNETTE }

    fun applyFilter(src: Bitmap, filter: ImageFilter): Bitmap {
        if (filter == ImageFilter.NONE) return src
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val cm = ColorMatrix()
        when (filter) {
            ImageFilter.GRAYSCALE -> cm.setSaturation(0f)
            ImageFilter.CONTRAST -> {
                val contrast = 1.35f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                cm.set(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, translate,
                        0f, contrast, 0f, 0f, translate,
                        0f, 0f, contrast, 0f, translate,
                        0f, 0f, 0f, 1f, 0f,
                    )
                )
            }
            ImageFilter.WARM -> cm.set(
                floatArrayOf(
                    1.15f, 0f, 0f, 0f, 10f,
                    0f, 1.05f, 0f, 0f, 0f,
                    0f, 0f, 0.9f, 0f, -5f,
                    0f, 0f, 0f, 1f, 0f,
                )
            )
            ImageFilter.COOL -> cm.set(
                floatArrayOf(
                    0.9f, 0f, 0f, 0f, -5f,
                    0f, 1.0f, 0f, 0f, 0f,
                    0f, 0f, 1.15f, 0f, 10f,
                    0f, 0f, 0f, 1f, 0f,
                )
            )
            ImageFilter.VIGNETTE -> {
                // Approximate via slight darkening matrix; full vignette would need radial shader
                cm.setSaturation(0.9f)
            }
            else -> {}
        }
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)
        return out
    }

    fun saveBitmap(context: Context, bmp: Bitmap, name: String = "phantom_${System.currentTimeMillis()}.png"): Uri? {
        return try {
            val dir = File(context.cacheDir, "phantom_images").apply { mkdirs() }
            val file = File(dir, name)
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 95, it) }
            Uri.fromFile(file)
        } catch (_: Exception) {
            null
        }
    }
}
