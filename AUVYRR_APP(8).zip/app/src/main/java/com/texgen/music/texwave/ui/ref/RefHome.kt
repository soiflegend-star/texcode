package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import java.util.Calendar

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 5 -> "Good night"
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

/** Home: continue listening, quick shortcuts and EVERY feature, grouped, one tap away. */
@Composable
fun RefHomeScreen(
    lib: LibraryState,
    player: PlayerState,
    userName: String = Ref.UserName,
    onPlay: (List<Song>, Int) -> Unit,
    onOpenNowPlaying: () -> Unit,
    onShuffle: () -> Unit,
    onSeeAll: () -> Unit,
    items: List<MoreItem> = emptyList(),
    onSearch: () -> Unit = {},
    onOpenMenu: () -> Unit = {},
) {
    val recent = remember(lib.songs, lib.recents) {
        val byId = lib.songs.associateBy { it.id }
        val r = lib.recents.mapNotNull { byId[it] }.distinctBy { it.id }
        (if (r.isEmpty()) lib.songs else r).take(8)
    }
    val heroSong = player.current ?: recent.firstOrNull()
    val display = userName.trim().ifBlank { Ref.UserName }
    val grouped = remember(items) { items.groupBy { it.section.ifBlank { "MORE" } } }
    val quickNames = listOf("Chats", "Chat", "Phantom", "Discover", "Equalizer", "Alarms", "Downloads")
    val quick = remember(items) {
        quickNames.mapNotNull { q -> items.firstOrNull { it.label.equals(q, true) } }.distinctBy { it.label }
    }

    RefBackground {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 12.dp, top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Hello, $display", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp)
                        Text(greeting() + "!", color = Ref.Muted, fontSize = 14.sp)
                    }
                    GlassIconButton(Icons.Rounded.Shuffle, onShuffle, size = 44.dp, square = true)
                }
            }
            item {
                val shape = RoundedCornerShape(14.dp)
                Row(
                    Modifier
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                        .fillMaxWidth()
                        .height(50.dp)
                        .clip(shape)
                        .refCard(16.dp)
                        .clickable(onClick = onSearch)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Search, null, tint = Ref.Muted, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Search songs, artists, playlists, features…", color = Ref.Muted, fontSize = 14.sp, maxLines = 1)
                }
            }
            item {
                Box(
                    Modifier.padding(horizontal = 20.dp).padding(bottom = 14.dp).fillMaxWidth().height(128.dp).refCard(24.dp).clickable(onClick = onShuffle),
                ) {
                    RefVinyl(150.dp, Modifier.align(Alignment.CenterEnd).padding(end = 0.dp))
                    Column(Modifier.align(Alignment.CenterStart).padding(start = 20.dp)) {
                        Text("Feel the\nMusic", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 28.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("With AUVYRR", color = Ref.Muted, fontSize = 12.sp)
                    }
                    Box(
                        Modifier.align(Alignment.CenterEnd).padding(end = 54.dp).size(44.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Ref.Lavender, Ref.Cyan))),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.PlayArrow, "Shuffle play", tint = Color.White, modifier = Modifier.size(28.dp)) }
                }
            }
            if (heroSong != null) {
                item {
                    val shape = RoundedCornerShape(20.dp)
                    Row(
                        Modifier
                            .padding(horizontal = 20.dp)
                            .fillMaxWidth()
                            .refCard(24.dp, hot = true)
                            .clickable {
                                if (player.current != null) onOpenNowPlaying()
                                else onPlay(lib.songs, lib.songs.indexOfFirst { it.id == heroSong.id }.coerceAtLeast(0))
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SongThumb(heroSong, Modifier.size(88.dp), RoundedCornerShape(18.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (player.current != null) "NOW PLAYING" else "JUMP BACK IN",
                                color = Ref.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                heroSong.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            )
                            Text(
                                heroSong.artist, color = Ref.Muted, fontSize = 14.sp,
                                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            )
                        }
                        Box(
                            Modifier.size(54.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Ref.Cyan, Ref.Purple))),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                    }
                }
            }
            if (quick.isNotEmpty()) {
                item { Spacer(Modifier.height(18.dp)) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
                    ) {
                        items(quick.size) { i ->
                            val q = quick[i]
                            Row(
                                Modifier
                                    .refCard(50.dp)
                                    .pressScale()
                                    .clickable(onClick = q.onClick)
                                    .padding(horizontal = 14.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(q.icon, null, tint = Ref.Cyan, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(q.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
            item { SectionTitle("Recently Played", "See All", onSeeAll) }
            item { Spacer(Modifier.height(10.dp)) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                ) {
                    itemsIndexed(recent, key = { _, s -> s.id }) { i, s ->
                        Column(Modifier.width(108.dp).pressScale().clickable { onPlay(recent, i) }) {
                            SongThumb(s, Modifier.size(108.dp).border(1.dp, Ref.Line, RoundedCornerShape(16.dp)), RoundedCornerShape(16.dp))
                            Spacer(Modifier.height(7.dp))
                            Text(s.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            Text(s.artist, color = Ref.Muted, fontSize = 11.sp, maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(22.dp)) }
            item { SectionTitle("Your Playlists", "See All", onSeeAll) }
            item { Spacer(Modifier.height(10.dp)) }
            item {
                val favSongs = remember(lib.songs, lib.liked) { lib.songs.filter { it.id in lib.liked } }
                Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                    PlaylistLine("My Favourites", "${favSongs.size} Songs", favSongs.firstOrNull() ?: recent.firstOrNull()) {
                        if (favSongs.isNotEmpty()) onPlay(favSongs, 0) else onSeeAll()
                    }
                    lib.playlists.take(3).forEach { p ->
                        val ps = lib.songs.filter { it.id in p.songIds }
                        PlaylistLine(p.name, "${ps.size} Songs", ps.firstOrNull() ?: recent.firstOrNull()) {
                            if (ps.isNotEmpty()) onPlay(ps, 0) else onSeeAll()
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(26.dp)) }
            item { SectionTitle("Everything in AUVYRR", "Open menu", onOpenMenu) }
            item {
                Text(
                    "Every screen lives here. Tap a tile to open it.",
                    color = Ref.Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                )
            }
            grouped.forEach { (section, list) ->
                item(key = "h_$section") {
                    Text(
                        section, color = Ref.Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp,
                        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 8.dp),
                    )
                }
                val rows = list.chunked(2)
                items(rows.size, key = { "r_${section}_$it" }) { r ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
                    ) {
                        rows[r].forEach { it2 -> FeatureTile(it2, Modifier.weight(1f)) }
                        if (rows[r].size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistLine(name: String, sub: String, art: Song?, onPlay: () -> Unit) {
    Row(Modifier.fillMaxWidth().refCard(18.dp).clickable(onClick = onPlay).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        SongThumb(art, Modifier.size(54.dp), RoundedCornerShape(12.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            Text("♡ $sub", color = Ref.Muted, fontSize = 12.sp)
        }
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Ref.Lavender, Ref.Cyan))),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(24.dp)) }
    }
}

@Composable
private fun FeatureTile(item: MoreItem, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .height(64.dp)
            .clip(shape)
            .background(Ref.Card)
            .border(1.dp, Ref.Line, shape)
            .clickable(onClick = item.onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(Ref.Cyan.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(item.icon, null, tint = Ref.Cyan, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            )
            if (item.subtitle.isNotBlank()) {
                Text(
                    item.subtitle, color = Ref.Muted, fontSize = 11.sp, maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                )
            }
        }
    }
}
