package com.texgen.music.texwave.ui.screens.universe

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

private val SCText = Color(0xFFF5F7FF)
private val SCMuted = Color(0xFF8D94A8)
private val SCBlack = Color(0xFF020308)
private val SCCyan = Tx.Accent2

/** Live astronomical catalogue module. SIMBAD is a dynamic literature cross-identification service; Gaia is the massive astrometric source backend. */
data class CatalogStar(val id: String, val ra: String, val dec: String, val objectType: String, val spectralType: String, val parallaxMas: String)

private class StarCatalogRepository {
    private val http = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).build()
    private val simbad = "https://simbad.cfa.harvard.edu/simbad/sim-tap/sync"

    suspend fun search(query: String, limit: Int = 100): List<CatalogStar> = withContext(Dispatchers.IO) {
        val clean = query.trim().replace("'", "''")
        val where = if (clean.isBlank()) {
            "otype_txt LIKE 'Star%'"
        } else {
            "otype_txt LIKE 'Star%' AND (main_id LIKE '%$clean%' OR sp_type LIKE '%$clean%')"
        }
        val adql = "SELECT TOP $limit main_id,ra,dec,otype_txt,sp_type,plx_value FROM basic WHERE $where ORDER BY main_id"
        val url = simbad.toHttpUrl().newBuilder().addQueryParameter("request", "doQuery").addQueryParameter("lang", "adql").addQueryParameter("format", "csv").addQueryParameter("query", adql).build()
        val request = Request.Builder().url(url).header("User-Agent", "AUVYRR-CosmicExplorer/2.0").build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext emptyList()
            parseCsv(response.body?.string().orEmpty())
        }
    }

    private fun parseCsv(text: String): List<CatalogStar> {
        val rows = text.lines().filter { it.isNotBlank() && !it.startsWith("#") }
        if (rows.size < 2) return emptyList()
        fun split(line: String) = line.split(',').map { it.trim().trim('"') }
        val header = split(rows.first()).map { it.lowercase() }
        fun idx(vararg names: String): Int = names.firstNotNullOfOrNull { n -> header.indexOf(n).takeIf { it >= 0 } } ?: -1
        val iId=idx("main_id"); val iRa=idx("ra"); val iDec=idx("dec"); val iType=idx("otype_txt"); val iSp=idx("sp_type"); val iPlx=idx("plx_value")
        return rows.drop(1).mapNotNull { line ->
            val c=split(line); if (iId !in c.indices) return@mapNotNull null
            CatalogStar(c[iId], c.getOrNull(iRa).orEmpty(), c.getOrNull(iDec).orEmpty(), c.getOrNull(iType).orEmpty(), c.getOrNull(iSp).orEmpty(), c.getOrNull(iPlx).orEmpty())
        }
    }
}

private fun catalogOnline(context: Context): Boolean {
    val cm=context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val n=cm.activeNetwork ?: return false
    val c=cm.getNetworkCapabilities(n) ?: return false
    return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}

@Composable
fun StarCatalogScreen(onBack: () -> Unit, onOpenStar: (String) -> Unit) {
    val context=androidx.compose.ui.platform.LocalContext.current
    val repo=remember { StarCatalogRepository() }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<CatalogStar>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(catalogOnline(context)) }
    var loadedOnce by remember { mutableStateOf(false) }

    LaunchedEffect(query, online) {
        if (!online) { results=emptyList(); return@LaunchedEffect }
        if (query.trim().length < 2 && loadedOnce) return@LaunchedEffect
        delay(if (query.isBlank()) 100 else 400)
        loading=true
        results=repo.search(query)
        loadedOnce=true
        loading=false
    }

    Column(Modifier.fillMaxSize().background(SCBlack)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack){Icon(Icons.Rounded.ArrowBack,null,tint=SCText)}
            Column(Modifier.weight(1f)){Text("STAR CATALOG",color=SCText,fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("Live astronomical object discovery",color=SCMuted,fontSize=11.sp)}
            Icon(if(online) Icons.Rounded.Cloud else Icons.Rounded.CloudOff,null,tint=if(online) SCCyan else Color(0xFFFF7777),modifier=Modifier.size(20.dp))
        }
        Row(Modifier.padding(horizontal=14.dp,vertical=6.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF11141D)).border(1.dp,Color.White.copy(.08f),RoundedCornerShape(18.dp)).padding(12.dp),verticalAlignment=Alignment.CenterVertically){
            Icon(Icons.Rounded.Search,null,tint=SCCyan,modifier=Modifier.size(19.dp));Spacer(Modifier.width(8.dp));BasicTextField(value=query,onValueChange={query=it},singleLine=true,textStyle=androidx.compose.ui.text.TextStyle(color=SCText,fontSize=14.sp),modifier=Modifier.weight(1f),decorationBox={inner->if(query.isEmpty())Text("Search any known star by name or spectral type…",color=SCMuted,fontSize=13.sp);inner()});if(loading)Text("QUERYING",color=SCCyan,fontSize=9.sp,fontWeight=FontWeight.Bold)
        }
        Row(Modifier.padding(horizontal=14.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Rounded.Public,null,tint=SCCyan,modifier=Modifier.size(16.dp));Spacer(Modifier.width(6.dp));Text("LIVE INDEX · SIMBAD / Gaia-compatible architecture",color=SCMuted,fontSize=10.sp)}
        if(!online){
            Row(Modifier.padding(14.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x18FF6B6B)).padding(12.dp)){Icon(Icons.Rounded.CloudOff,null,tint=Color(0xFFFF8888),modifier=Modifier.size(18.dp));Spacer(Modifier.width(8.dp));Text("OFFLINE — the live star index is unavailable. The local Cosmic Explorer catalogue remains usable.",color=Color(0xFFFFB0B0),fontSize=11.sp)}
        } else if(results.isEmpty() && !loading){
            Text("Type a star name, catalogue identifier, or spectral class. Leave the field empty to browse a live sample of the star index.",color=SCMuted,fontSize=12.sp,modifier=Modifier.padding(14.dp))
        }
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(results,key={it.id}){star->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF0D1018)).border(1.dp,Color.White.copy(.06f),RoundedCornerShape(14.dp)).clickable{onOpenStar(star.id)}.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){Text(star.id,color=SCText,fontSize=14.sp,fontWeight=FontWeight.SemiBold);Text("${star.objectType} · ${star.spectralType.ifBlank{"spectral class unavailable"}}",color=SCCyan,fontSize=10.sp);Text("RA ${star.ra}  ·  Dec ${star.dec}  ·  Parallax ${star.parallaxMas} mas",color=SCMuted,fontSize=9.sp)}
                    Text("3D",color=SCCyan,fontSize=9.sp,fontWeight=FontWeight.Bold)
                }
            }
        }
    }
}
