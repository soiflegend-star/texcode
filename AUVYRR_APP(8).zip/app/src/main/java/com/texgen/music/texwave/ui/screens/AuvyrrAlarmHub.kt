package com.texgen.music.texwave.ui.screens

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.HourglassEmpty
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.AlarmEngine
import com.texgen.music.texwave.data.AlarmRec
import com.texgen.music.texwave.data.AlarmStore
import com.texgen.music.texwave.data.Days
import com.texgen.music.texwave.ui.ref.DefaultAlarmTheme
import java.util.Calendar

/** AUVYRR alarm palette: AMOLED black, purple, cyan, a touch of magenta. */
internal object AV {
    val Bg = Color(0xFF000000)
    val Purple = Color(0xFF9B6BFF)
    val Cyan = Color(0xFF00E5FF)
    val Magenta = Color(0xFFFF00E6)
    val Glass = Color(0x1FFFFFFF)
    val Line = Color(0x33FFFFFF)
    val Sub = Color(0xFF9AA0B8)
}

internal fun Modifier.avGlass(radius: androidx.compose.ui.unit.Dp, hot: Boolean = false): Modifier {
    val sh = RoundedCornerShape(radius)
    return this.clip(sh)
        .background(Brush.linearGradient(listOf(Color(0x26FFFFFF), Color(0x0DFFFFFF))))
        .border(
            1.dp,
            if (hot) Brush.linearGradient(listOf(AV.Cyan, AV.Purple, AV.Magenta.copy(alpha = 0.7f)))
            else Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x14FFFFFF))),
            sh,
        )
}

internal fun alarmIcon(key: String, hour: Int): ImageVector = when (key) {
    "sun" -> Icons.Rounded.WbSunny
    "moon" -> Icons.Rounded.Bedtime
    "dumbbell" -> Icons.Rounded.FitnessCenter
    "work" -> Icons.Rounded.Work
    "bell" -> Icons.Rounded.Notifications
    else -> if (hour in 5..16) Icons.Rounded.WbSunny else Icons.Rounded.Bedtime
}

private fun soundTitle(a: AlarmRec): String = when {
    a.soundUri == "silent" -> "Voice only"
    a.soundUri.isNullOrBlank() -> "Default tone"
    else -> a.soundName.ifBlank { "Custom sound" }
}

private fun clockText(h: Int, m: Int, is24: Boolean): String =
    if (is24) "%02d:%02d".format(h, m) else "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "AM" else "PM")

private fun dayWord(trigger: Long): String {
    val now = Calendar.getInstance()
    val t = Calendar.getInstance().apply { timeInMillis = trigger }
    val diff = t.get(Calendar.DAY_OF_YEAR) - now.get(Calendar.DAY_OF_YEAR) + (t.get(Calendar.YEAR) - now.get(Calendar.YEAR)) * 365
    return when {
        diff <= 0 -> "Today"
        diff == 1 -> "Tomorrow"
        else -> Days.short[Days.bitOf(t.get(Calendar.DAY_OF_WEEK))]
    }
}

private fun mmss(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    return if (h > 0) "%d:%02d:%02d".format(h, (s % 3600) / 60, s % 60) else "%02d:%02d".format(s / 60, s % 60)
}

@Composable
fun AlarmScreen(onExit: () -> Unit = {}, onSleepTimer: () -> Unit = {}) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE) }
    val is24 = remember { android.text.format.DateFormat.is24HourFormat(context) }

    var tab by remember { mutableIntStateOf(0) }
    var alarms by remember { mutableStateOf(AlarmStore.load(context)) }
    var draft by remember { mutableStateOf<Draft?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            // alarms that fired while this screen is open update their stored state; reload cheaply
            alarms = AlarmStore.load(context)
            kotlinx.coroutines.delay(1000)
        }
    }

    // Android 13+: without notification permission the ringing screen cannot pop up. Ask once, up front.
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }

    BackHandler(enabled = draft != null) { draft = null }
    BackHandler(enabled = draft == null && tab != 0) { tab = 0 }
    BackHandler(enabled = draft == null && tab == 0) { onExit() }

    fun persist(next: List<AlarmRec>) { alarms = next; AlarmStore.save(context, next) }

    fun saveDraft(d: Draft) {
        val id = d.id ?: AlarmStore.nextId(alarms)
        val rec = AlarmRec(
            id = id, hour = d.hour, minute = d.minute, label = d.label.ifBlank { "AUVYRR Alarm" },
            days = d.days, enabled = true, trigger = 0L,
            soundUri = d.sound.ifBlank { null }, soundName = d.soundName, theme = d.theme,
            snooze = d.snooze, vibrate = d.vibrate, icon = d.icon,
        )
        if (d.id != null) AlarmEngine.cancel(context, id)
        AlarmEngine.ensureExactPermission(context)
        val armed = AlarmEngine.schedule(context, rec)
        persist(if (d.id != null) alarms.map { if (it.id == id) armed else it } else alarms + armed)
        draft = null
        Toast.makeText(context, "Alarm set for ${clockText(d.hour, d.minute, is24)} (${untilLabel(armed.trigger)})", Toast.LENGTH_SHORT).show()
    }

    fun newDraft(): Draft {
        val c = Calendar.getInstance()
        return Draft(
            null, (c.get(Calendar.HOUR_OF_DAY) + 1) % 24, 0, "", Days.ALL,
            prefs.getString("default_sound", "") ?: "",
            prefs.getString("default_sound_name", "") ?: "",
            prefs.getString("default_theme", DefaultAlarmTheme) ?: DefaultAlarmTheme,
        )
    }

    Box(Modifier.fillMaxSize().background(AV.Bg)) {
        // soft ambient glow
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(AV.Purple.copy(alpha = 0.22f), Color.Transparent),
                    center = Offset(300f, 300f), radius = 1100f,
                ),
            ),
        )
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { onExit() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Text("AUVYRR", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(40.dp))
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> AlarmTab(
                        alarms = alarms, now = now, is24 = is24,
                        onAdd = { AlarmEngine.ensureExactPermission(context); draft = newDraft() },
                        onEdit = { a -> draft = Draft(a.id, a.hour, a.minute, a.label, a.days, a.soundUri.orEmpty(), a.soundName, a.theme, a.snooze, a.vibrate, a.icon) },
                        onToggle = { a, on ->
                            if (on) {
                                AlarmEngine.ensureExactPermission(context)
                                val armed = AlarmEngine.schedule(context, a.copy(enabled = true))
                                persist(alarms.map { if (it.id == a.id) armed else it })
                            } else {
                                AlarmEngine.cancel(context, a.id)
                                persist(alarms.map { if (it.id == a.id) it.copy(enabled = false) else it })
                            }
                        },
                        onDelete = { a ->
                            AlarmEngine.cancel(context, a.id)
                            persist(alarms.filterNot { it.id == a.id })
                        },
                        onMaster = { on ->
                            if (!on) {
                                val ids = alarms.filter { it.enabled }.map { it.id }
                                prefs.edit().putString("paused_ids", ids.joinToString(",")).apply()
                                alarms.filter { it.enabled }.forEach { AlarmEngine.cancel(context, it.id) }
                                persist(alarms.map { it.copy(enabled = false) })
                            } else {
                                val ids = (prefs.getString("paused_ids", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }.toSet()
                                AlarmEngine.ensureExactPermission(context)
                                persist(alarms.map { if (it.id in ids) AlarmEngine.schedule(context, it.copy(enabled = true)) else it })
                                prefs.edit().remove("paused_ids").apply()
                            }
                        },
                    )
                    1 -> CountdownPanel(
                        title = "Timer", id = AlarmEngine.TIMER_ID, presets = listOf(1, 3, 5, 10, 15, 30),
                        icon = Icons.Rounded.HourglassEmpty, label = "Timer", now = now,
                        note = "Rings with the alarm sound even if AUVYRR is closed.",
                    )
                    2 -> StopwatchPanel(now)
                    3 -> CountdownPanel(
                        title = "Focus", id = AlarmEngine.FOCUS_ID, presets = listOf(10, 15, 25, 45, 60, 90),
                        icon = Icons.Rounded.SelfImprovement, label = "Focus session", now = now,
                        note = "Put the phone down and breathe. You'll be called back when the session ends.",
                        affirmations = true,
                    )
                    else -> SmartTab(alarms, now, is24, onSleepTimer) { rec ->
                        AlarmEngine.ensureExactPermission(context)
                        val armed = AlarmEngine.schedule(context, rec)
                        persist(alarms + armed)
                    }
                }
            }

            BottomBar(tab) { tab = it }
        }

        draft?.let { d ->
            AlarmEditor(
                d = d, prefs = prefs,
                onChange = { draft = it },
                onSave = { saveDraft(it) },
                onCancel = { draft = null },
            )
        }
    }
}

@Composable
private fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).avGlass(30.dp).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        @Composable
        fun item(i: Int, icon: ImageVector, name: String) {
            val sel = tab == i
            Column(Modifier.weight(1f).clickable { onTab(i) }.padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, name, tint = if (sel) AV.Cyan else AV.Sub, modifier = Modifier.size(24.dp))
                Text(name, color = if (sel) AV.Cyan else AV.Sub, fontSize = 11.sp)
            }
        }
        item(0, Icons.Rounded.Alarm, "Alarm")
        item(1, Icons.Rounded.HourglassEmpty, "Timer")
        Box(
            Modifier.weight(1f).clickable { onTab(4) },
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier.size(58.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(AV.Purple, AV.Cyan)))
                    .padding(2.dp).clip(CircleShape).background(Color.Black).padding(6.dp),
                contentAlignment = Alignment.Center,
            ) {
                Image(painterResource(R.drawable.auvyrr_logo), "AUVYRR", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
        }
        item(2, Icons.Rounded.Timer, "Stopwatch")
        item(3, Icons.Rounded.SelfImprovement, "Focus")
    }
}

// ---------------------------------------------------------------- Alarm tab

@Composable
private fun ClockDial(now: Long, is24: Boolean, modifier: Modifier = Modifier) {
    val c = Calendar.getInstance().apply { timeInMillis = now }
    val sec = c.get(Calendar.SECOND) + c.get(Calendar.MILLISECOND) / 1000f
    Box(modifier.size(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val r = size.minDimension / 2 - 12f
            // glow
            drawCircle(
                Brush.radialGradient(listOf(AV.Purple.copy(alpha = 0.35f), Color.Transparent), center, r * 1.15f),
                radius = r * 1.15f, center = center,
            )
            drawCircle(AV.Purple.copy(alpha = 0.35f), r, center, style = Stroke(2f))
            drawCircle(AV.Cyan.copy(alpha = 0.25f), r - 18f, center, style = Stroke(1.5f))
            drawCircle(AV.Magenta.copy(alpha = 0.18f), r - 34f, center, style = Stroke(1.5f))
            // 60 ticks
            for (i in 0 until 60) {
                val major = i % 5 == 0
                rotate(i * 6f, center) {
                    drawLine(
                        if (major) Color.White.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.25f),
                        Offset(center.x, center.y - r + 2f), Offset(center.x, center.y - r + if (major) 14f else 8f),
                        strokeWidth = if (major) 3f else 1.5f,
                    )
                }
            }
            // seconds sweep arc
            val sweep = (sec / 60f) * 360f
            rotate(-90f, center) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(AV.Purple, AV.Cyan, AV.Magenta, AV.Purple), center),
                    startAngle = 0f, sweepAngle = sweep.coerceAtLeast(1f), useCenter = false,
                    topLeft = Offset(center.x - r + 26f, center.y - r + 26f),
                    size = Size((r - 26f) * 2, (r - 26f) * 2),
                    style = Stroke(7f, cap = StrokeCap.Round),
                )
            }
            // seconds dot
            rotate(sweep, center) { drawCircle(AV.Cyan, 7f, Offset(center.x, center.y - r + 26f)) }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val h = c.get(Calendar.HOUR_OF_DAY); val m = c.get(Calendar.MINUTE)
            Text(
                if (is24) "%02d:%02d".format(h, m) else "%d:%02d".format(if (h % 12 == 0) 12 else h % 12, m),
                color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.Light,
            )
            Text(
                (if (is24) "" else (if (h < 12) "AM · " else "PM · ")) +
                    android.text.format.DateFormat.format("EEE, d MMM", c).toString().uppercase(),
                color = AV.Cyan, fontSize = 12.sp, letterSpacing = 2.sp,
            )
        }
    }
}

@Composable
private fun AlarmTab(
    alarms: List<AlarmRec>, now: Long, is24: Boolean,
    onAdd: () -> Unit, onEdit: (AlarmRec) -> Unit, onToggle: (AlarmRec, Boolean) -> Unit,
    onDelete: (AlarmRec) -> Unit, onMaster: (Boolean) -> Unit,
) {
    val next = alarms.filter { it.enabled }.minByOrNull { AlarmEngine.nextTrigger(it.hour, it.minute, it.days) }
    val nextAt = next?.let { AlarmEngine.nextTrigger(it.hour, it.minute, it.days) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        ClockDial(now, is24)
        Text("Rise. Create. Dominate.", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, letterSpacing = 3.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))

        // Alarm Enabled card
        Row(Modifier.fillMaxWidth().avGlass(22.dp, hot = true).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(AV.Purple.copy(alpha = 0.3f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Alarm, null, tint = AV.Cyan)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(if (next != null) "Alarm Enabled" else if (alarms.isEmpty()) "No alarms yet" else "Alarms off", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (next != null && nextAt != null) "Next: ${dayWord(nextAt)} ${clockText(next.hour, next.minute, is24)} · ${untilLabel(nextAt)}"
                    else "Tap + to create your first alarm",
                    color = AV.Sub, fontSize = 13.sp,
                )
            }
            Switch(
                checked = next != null, onCheckedChange = onMaster, enabled = alarms.isNotEmpty(),
                colors = SwitchDefaults.colors(checkedTrackColor = AV.Purple, checkedThumbColor = Color.White),
            )
        }

        Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Your Alarms", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(AV.Purple, AV.Cyan))).clickable(onClick = onAdd).padding(horizontal = 16.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Add, null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Add", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (alarms.isEmpty()) {
            Column(Modifier.fillMaxWidth().avGlass(20.dp).clickable(onClick = onAdd).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Nothing here yet", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("Create an alarm with your own sound, repeat days and snooze.", color = AV.Sub, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
            }
        }
        alarms.sortedWith(compareBy({ it.hour }, { it.minute })).forEach { a ->
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp).avGlass(20.dp).clickable { onEdit(a) }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(if (a.enabled) listOf(AV.Purple.copy(alpha = 0.55f), AV.Cyan.copy(alpha = 0.35f)) else listOf(AV.Glass, AV.Glass))),
                    contentAlignment = Alignment.Center,
                ) { Icon(alarmIcon(a.icon, a.hour), null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(clockText(a.hour, a.minute, is24), color = if (a.enabled) Color.White else AV.Sub, fontSize = 26.sp, fontWeight = FontWeight.Light)
                    Text(a.label + " · " + Days.summary(a.days), color = AV.Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(soundTitle(a) + " · snooze ${a.snooze}m" + if (a.vibrate) " · vibrate" else "", color = AV.Cyan.copy(alpha = 0.85f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Switch(
                    checked = a.enabled, onCheckedChange = { onToggle(a, it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = AV.Purple, checkedThumbColor = Color.White),
                )
                Icon(
                    Icons.Rounded.Delete, "Delete", tint = AV.Magenta.copy(alpha = 0.8f),
                    modifier = Modifier.padding(start = 6.dp).size(24.dp).clickable { onDelete(a) },
                )
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------------------------------------------------------------- Timer / Focus

private val Affirmations = listOf(
    "One thing at a time. This is enough.",
    "Breathe in slowly. Breathe out slower.",
    "You are building something real today.",
    "Quiet mind, steady hands.",
    "Start small. Stay with it.",
)

@Composable
private fun CountdownPanel(
    title: String, id: Int, presets: List<Int>, icon: ImageVector, label: String, now: Long,
    note: String, affirmations: Boolean = false,
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE) }
    var minutes by remember { mutableIntStateOf(presets[2]) }
    var tick by remember { mutableIntStateOf(0) }
    val end = prefs.getLong("cd_end_$id", 0L).also { tick.hashCode() }
    val running = end > now
    val total = prefs.getInt("cd_total_$id", minutes) * 60_000L
    val left = (end - now).coerceAtLeast(0)
    val frac = if (running && total > 0) (left.toFloat() / total).coerceIn(0f, 1f) else 1f

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(8.dp))
        Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension / 2 - 16f
                val tl = Offset(size.width / 2 - r, size.height / 2 - r)
                drawCircle(AV.Line, r, style = Stroke(10f))
                rotate(-90f) {
                    drawArc(
                        Brush.sweepGradient(listOf(AV.Purple, AV.Cyan, AV.Magenta, AV.Purple), Offset(size.width / 2, size.height / 2)),
                        0f, 360f * frac, false, tl, Size(r * 2, r * 2), style = Stroke(10f, cap = StrokeCap.Round),
                    )
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(icon, null, tint = AV.Cyan, modifier = Modifier.size(26.dp))
                Text(if (running) mmss(left) else mmss(minutes * 60_000L), color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Light)
                Text(if (running) "$title running" else "$title ready", color = AV.Sub, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        if (!running) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).avGlass(22.dp).clickable { minutes = (minutes - 1).coerceAtLeast(1) }, contentAlignment = Alignment.Center) { Text("−", color = Color.White, fontSize = 22.sp) }
                Text("$minutes min", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(horizontal = 22.dp))
                Box(Modifier.size(44.dp).avGlass(22.dp).clickable { minutes = (minutes + 1).coerceAtMost(600) }, contentAlignment = Alignment.Center) { Text("+", color = Color.White, fontSize = 22.sp) }
            }
            Spacer(Modifier.height(12.dp))
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets) { p -> AvChip("$p m", minutes == p) { minutes = p } }
            }
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(AV.Purple, AV.Cyan)))
                    .clickable {
                        AlarmEngine.ensureExactPermission(context)
                        AlarmEngine.startCountdown(context, id, minutes, label)
                        tick++
                    }.padding(horizontal = 40.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = Color.Black)
                Spacer(Modifier.width(6.dp))
                Text("Start", color = Color.Black, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.clip(RoundedCornerShape(50)).avGlass(50.dp).clickable { AlarmEngine.extendCountdown(context, id, 60_000L); tick++ }.padding(horizontal = 26.dp, vertical = 13.dp)) {
                    Text("+1 min", color = Color.White, fontSize = 16.sp)
                }
                Box(Modifier.clip(RoundedCornerShape(50)).background(AV.Magenta.copy(alpha = 0.85f)).clickable { AlarmEngine.cancelCountdown(context, id); tick++ }.padding(horizontal = 26.dp, vertical = 13.dp)) {
                    Text("Cancel", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (affirmations) {
            val line = Affirmations[((now / 20_000L) % Affirmations.size).toInt()]
            Text(line, color = AV.Cyan, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 22.dp, start = 12.dp, end = 12.dp))
        }
        Text(note, color = AV.Sub, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 14.dp, bottom = 20.dp))
    }
}

// ---------------------------------------------------------------- Stopwatch

@Composable
private fun StopwatchPanel(now: Long) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE) }
    var running by remember { mutableStateOf(prefs.getBoolean("sw_running", false)) }
    var base by remember { mutableLongStateOf(prefs.getLong("sw_base", 0L)) }      // accumulated ms
    var startedAt by remember { mutableLongStateOf(prefs.getLong("sw_start", 0L)) }
    val laps = remember { mutableStateListOf<Long>() }
    val elapsed = base + if (running) (now - startedAt).coerceAtLeast(0) else 0L

    fun save() { prefs.edit().putBoolean("sw_running", running).putLong("sw_base", base).putLong("sw_start", startedAt).apply() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp))
        val cs = (elapsed / 10) % 100
        Text(mmss(elapsed) + ".%02d".format(cs), color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).avGlass(28.dp).clickable(enabled = elapsed > 0) {
                running = false; base = 0; startedAt = 0; laps.clear(); save()
            }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Refresh, "Reset", tint = Color.White) }
            Box(
                Modifier.size(76.dp).clip(CircleShape).background(Brush.linearGradient(listOf(AV.Purple, AV.Cyan))).clickable {
                    if (running) { base += System.currentTimeMillis() - startedAt; running = false }
                    else { startedAt = System.currentTimeMillis(); running = true }
                    save()
                },
                contentAlignment = Alignment.Center,
            ) { Icon(if (running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (running) "Pause" else "Start", tint = Color.Black, modifier = Modifier.size(36.dp)) }
            Box(Modifier.size(56.dp).avGlass(28.dp).clickable(enabled = running) { laps.add(0, elapsed) }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Flag, "Lap", tint = Color.White)
            }
        }
        Spacer(Modifier.height(20.dp))
        laps.forEachIndexed { i, t ->
            val prev = laps.getOrNull(i + 1) ?: 0L
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).avGlass(14.dp).padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text("Lap ${laps.size - i}", color = AV.Sub, modifier = Modifier.weight(1f))
                Text("+" + mmss(t - prev), color = AV.Cyan, modifier = Modifier.padding(end = 18.dp))
                Text(mmss(t), color = Color.White)
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

// ---------------------------------------------------------------- Smart tab

@Composable
private fun SmartTab(alarms: List<AlarmRec>, now: Long, is24: Boolean, onSleepTimer: () -> Unit, onAddReminder: (AlarmRec) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE) }
    val routine = remember(now / 60_000L) { AlarmStore.routine(context) }
    val next = alarms.filter { it.enabled }.minByOrNull { AlarmEngine.nextTrigger(it.hour, it.minute, it.days) }
    val nextAt = next?.let { AlarmEngine.nextTrigger(it.hour, it.minute, it.days) }
    var recheck by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = AV.Cyan, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text("Smart", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }
        Text("Suggestions are worked out on your phone from your own alarms and wake history. No account, no API key, no internet needed.", color = AV.Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))

        // Routine
        Column(Modifier.fillMaxWidth().avGlass(22.dp, true).padding(16.dp)) {
            Text("Wake-up routine", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                Column { Text("${routine.streakDays}", color = AV.Cyan, fontSize = 30.sp, fontWeight = FontWeight.Light); Text("day streak", color = AV.Sub, fontSize = 12.sp) }
                Column { Text(routine.avgWake ?: "—", color = AV.Purple, fontSize = 30.sp, fontWeight = FontWeight.Light); Text("avg. wake (7d)", color = AV.Sub, fontSize = 12.sp) }
            }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                routine.last7.forEach { ok ->
                    Box(Modifier.size(26.dp).clip(CircleShape).background(if (ok) AV.Cyan.copy(alpha = 0.85f) else AV.Glass), contentAlignment = Alignment.Center) {
                        if (ok) Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    }
                }
            }
            Text("Counts days where you dismissed an alarm. Last 7 days, oldest first.", color = AV.Sub, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }

        // Tomorrow context
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().avGlass(22.dp).padding(16.dp)) {
            Text("Coming up", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (next != null && nextAt != null) "${dayWord(nextAt)} you wake at ${clockText(next.hour, next.minute, is24)} (${next.label}), ${untilLabel(nextAt)}."
                else "No alarm is set. Add one so tomorrow doesn't start by accident.",
                color = AV.Sub, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp),
            )
        }

        // Bedtime planner
        if (next != null && nextAt != null) {
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().avGlass(22.dp).padding(16.dp)) {
                Text("Bedtime planner", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("Sleep comes in ~90-minute cycles, plus about 15 minutes to fall asleep. To wake at ${clockText(next.hour, next.minute, is24)}, aim to be in bed at:", color = AV.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
                listOf(6, 5, 4).forEach { cycles ->
                    val bed = nextAt - (cycles * 90 + 15) * 60_000L
                    val bc = Calendar.getInstance().apply { timeInMillis = bed }
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(clockText(bc.get(Calendar.HOUR_OF_DAY), bc.get(Calendar.MINUTE), is24), color = if (cycles == 6) AV.Cyan else Color.White, fontSize = 20.sp, modifier = Modifier.width(110.dp))
                        Text("${cycles * 1.5}h sleep" + if (cycles == 6) " · best" else "", color = AV.Sub, fontSize = 13.sp)
                    }
                }
                val bed6 = nextAt - (6 * 90 + 15 + 30) * 60_000L   // wind-down 30 min before the 9h40 bedtime
                if (bed6 > now) {
                    val wc = Calendar.getInstance().apply { timeInMillis = bed6 }
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(AV.Purple, AV.Cyan))).clickable {
                            onAddReminder(
                                AlarmRec(
                                    id = AlarmStore.nextId(alarms), hour = wc.get(Calendar.HOUR_OF_DAY), minute = wc.get(Calendar.MINUTE),
                                    label = "Wind down", days = 0, enabled = true, trigger = 0L, soundUri = "", soundName = "",
                                    theme = DefaultAlarmTheme, snooze = 5, vibrate = false, icon = "moon",
                                ),
                            )
                            Toast.makeText(context, "Wind-down alarm added for ${clockText(wc.get(Calendar.HOUR_OF_DAY), wc.get(Calendar.MINUTE), is24)}", Toast.LENGTH_SHORT).show()
                        }.padding(horizontal = 20.dp, vertical = 11.dp),
                    ) { Text("Add wind-down alarm (${clockText(wc.get(Calendar.HOUR_OF_DAY), wc.get(Calendar.MINUTE), is24)})", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }

        // Rule-based tips
        val tips = buildList {
            if (alarms.isEmpty()) add("Create a first alarm — a fixed wake time is the strongest habit you can build.")
            val earliest = alarms.filter { it.enabled }.minByOrNull { it.hour * 60 + it.minute }
            if (earliest != null && earliest.hour < 5) add("Your earliest alarm is before 5:00. Make sure bedtime moves earlier too.")
            if (alarms.any { it.enabled && it.days == Days.WEEKDAYS } && alarms.none { it.enabled && (it.days and Days.WEEKEND) != 0 })
                add("Alarms only run Mon–Fri. Keeping weekend wake-ups within an hour of weekdays helps your rhythm.")
            if (alarms.any { it.enabled && it.snooze >= 15 }) add("A 15-minute snooze often means lighter sleep afterwards; 5–10 minutes works better.")
            val avg = routine.avgWake
            if (avg != null && next != null) {
                val (ah, am) = avg.split(":").map { it.toInt() }
                val diff = (ah * 60 + am) - (next.hour * 60 + next.minute)
                if (diff > 20) add("You usually dismiss about $diff min after your alarm time. Consider moving the alarm later, or placing the phone out of reach.")
            }
            if (routine.streakDays >= 3) add("${routine.streakDays}-day streak — keep it going.")
        }
        if (tips.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().avGlass(22.dp).padding(16.dp)) {
                Text("Suggestions", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                tips.forEach { Text("• $it", color = AV.Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            }
        }

        // Reliability
        Spacer(Modifier.height(14.dp))
        val exact = remember(recheck) { AlarmEngine.exactAllowed(context) }
        val battery = remember(recheck) {
            runCatching { (context.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(context.packageName) }.getOrDefault(true)
        }
        val notif = remember(recheck) {
            runCatching { (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled() }.getOrDefault(true)
        }
        Column(Modifier.fillMaxWidth().avGlass(22.dp).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, null, tint = AV.Cyan, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Alarm reliability", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("Re-check", color = AV.Cyan, fontSize = 13.sp, modifier = Modifier.clickable { recheck++ })
            }
            ReliRow("Exact alarms", exact, "Needed to ring on the exact minute.") {
                AlarmEngine.ensureExactPermission(context)
            }
            ReliRow("Notifications", notif, "Needed to show the ringing screen.") {
                runCatching { context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            val fsi = remember(recheck) {
                if (android.os.Build.VERSION.SDK_INT >= 34)
                    runCatching { (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).canUseFullScreenIntent() }.getOrDefault(true)
                else true
            }
            ReliRow("Full-screen alarm", fsi, "Lets the alarm screen open over the lock screen.") {
                runCatching {
                    context.startActivity(Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            ReliRow("Battery unrestricted", battery, "Some phones stop apps in the background; this keeps alarms on time.") {
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.onFailure {
                    runCatching { context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
            }
            Text("Alarms are re-armed automatically after a reboot, an app update, and time or timezone changes.", color = AV.Sub, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }

        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().avGlass(22.dp).clickable(onClick = onSleepTimer).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Bedtime, null, tint = AV.Purple, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Sleep timer", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("Fade out your music and stop playback", color = AV.Sub, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(14.dp))
        BriefingOptions(prefs)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ReliRow(name: String, ok: Boolean, hint: String, fix: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (ok) AV.Cyan else AV.Magenta))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 15.sp)
            Text(if (ok) "OK" else hint, color = AV.Sub, fontSize = 12.sp)
        }
        if (!ok) Text("Fix", color = AV.Cyan, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = fix).padding(8.dp))
    }
}
