package com.texgen.music.texwave.sonara.data.catalog

import com.texgen.music.texwave.sonara.data.Track

/**
 * On-device recommendation helpers using listening history and likes.
 * Not a cloud ML model — transparent, deterministic personalization
 * until a real recommendation service is connected.
 */
object RecommendationEngine {

    fun forYou(
        catalogue: List<Track>,
        likedIds: Set<String>,
        recentIds: List<String>,
        limit: Int = 20,
    ): List<Track> {
        if (catalogue.isEmpty()) return emptyList()
        val liked = catalogue.filter { it.id in likedIds }
        val recent = recentIds.mapNotNull { id -> catalogue.find { it.id == id } }
        val seedGenres = (liked + recent).mapNotNull { it.genre }.groupingBy { it }.eachCount()
        val seedArtists = (liked + recent).map { it.artist }.groupingBy { it }.eachCount()

        val scored = catalogue.map { t ->
            var score = 0.0
            t.genre?.let { g -> score += (seedGenres[g] ?: 0) * 3.0 }
            score += (seedArtists[t.artist] ?: 0) * 4.0
            if (t.id in likedIds) score -= 10 // already liked — deprioritize in "discover"
            if (t.id in recentIds.take(5)) score -= 5
            t to score
        }
        return scored.sortedByDescending { it.second }
            .map { it.first }
            .distinctBy { it.id }
            .take(limit)
            .ifEmpty { catalogue.shuffled().take(limit) }
    }

    fun radioFrom(seed: Track, catalogue: List<Track>, limit: Int = 40): List<Track> {
        val sameArtist = catalogue.filter { it.artist == seed.artist && it.id != seed.id }
        val sameGenre = catalogue.filter { it.genre == seed.genre && it.id != seed.id && it.artist != seed.artist }
        val rest = catalogue.filter { it.id != seed.id }
        return (listOf(seed) + sameArtist.shuffled() + sameGenre.shuffled() + rest.shuffled())
            .distinctBy { it.id }
            .take(limit)
    }

    fun trending(catalogue: List<Track>, limit: Int = 12): List<Track> {
        // Without live play counts, use a stable "editorial" ordering by year desc then title
        return catalogue.sortedWith(compareByDescending<Track> { it.year ?: 0 }.thenBy { it.title }).take(limit)
    }

    fun newReleases(catalogue: List<Track>, limit: Int = 12): List<Track> {
        return catalogue.sortedByDescending { it.year ?: 0 }.take(limit)
    }

    fun byGenre(catalogue: List<Track>, genre: String): List<Track> =
        catalogue.filter { it.genre.equals(genre, ignoreCase = true) }

    fun albumsFrom(catalogue: List<Track>): List<Pair<String, List<Track>>> {
        return catalogue
            .filter { it.album.isNotBlank() }
            .groupBy { "${it.artist}||${it.album}" }
            .map { (_, tracks) -> tracks.first().album to tracks.sortedBy { it.trackNumber ?: 0 } }
            .sortedBy { it.first }
    }

    fun artistsFrom(catalogue: List<Track>): List<Pair<String, List<Track>>> {
        return catalogue.groupBy { it.artist }
            .map { (name, tracks) -> name to tracks }
            .sortedBy { it.first }
    }

    fun similarTracks(seed: Track, catalogue: List<Track>, limit: Int = 15): List<Track> {
        return catalogue
            .filter { it.id != seed.id }
            .map { t ->
                var score = 0
                if (t.artist == seed.artist) score += 5
                if (t.genre != null && t.genre == seed.genre) score += 4
                if (t.album.isNotBlank() && t.album == seed.album) score += 3
                if (seed.year != null && t.year != null && kotlin.math.abs(t.year - seed.year) <= 2) score += 1
                t to score
            }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .map { it.first }
            .take(limit)
            .ifEmpty { catalogue.filter { it.id != seed.id }.shuffled().take(limit) }
    }

    fun discoverWeekly(catalogue: List<Track>, likedIds: Set<String>, recentIds: List<String>, limit: Int = 30): List<Track> {
        val base = forYou(catalogue, likedIds, recentIds, limit * 2)
        // Mix in some less familiar tracks from same genres
        val genres = (catalogue.filter { it.id in likedIds }.mapNotNull { it.genre }).toSet()
        val exploration = catalogue.filter { it.genre in genres && it.id !in likedIds && it.id !in recentIds.take(10) }
        return (base + exploration.shuffled()).distinctBy { it.id }.take(limit)
    }

    fun identityGenres(catalogue: List<Track>, likedIds: Set<String>, recentIds: List<String>): List<Pair<String, Int>> {
        val ids = likedIds + recentIds
        return catalogue.filter { it.id in ids }
            .mapNotNull { it.genre }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .map { it.key to it.value }
    }

    fun identityArtists(catalogue: List<Track>, likedIds: Set<String>, recentIds: List<String>): List<Pair<String, Int>> {
        val ids = likedIds + recentIds
        return catalogue.filter { it.id in ids }
            .map { it.artist }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .map { it.key to it.value }
    }

    fun phonkPlaylists(catalogue: List<Track>): List<Pair<String, List<Track>>> {
        val keys = listOf(
            "Drift Phonk" to "drift phonk",
            "Brazilian Phonk" to "brazilian phonk",
            "Aggressive Phonk" to "aggressive phonk",
            "Atmospheric Phonk" to "atmospheric phonk",
            "All Phonk" to "phonk",
        )
        return keys.mapNotNull { (label, key) ->
            val tracks = catalogue.filter {
                val g = it.genre?.lowercase() ?: ""
                if (key == "phonk") "phonk" in g else g == key
            }
            if (tracks.isEmpty()) null else label to tracks
        }
    }

}
