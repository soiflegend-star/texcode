package com.texgen.music.texwave.sonara.syntra

import kotlinx.serialization.Serializable

/**
 * SYNTRA integration layer — API synchronization contracts for Sonara.
 *
 * Independent of UI. Configure [SyntraConfig] when your Syntra gateway is live.
 * No hardcoded secrets. All calls fail closed when unconfigured.
 */

data class SyntraConfig(
    val baseUrl: String,
    val appId: String = "sonara-android-v1",
    val getAccessToken: suspend () -> String?,
)

@Serializable
data class SyntraEnvelope<T>(
    val ok: Boolean,
    val data: T? = null,
    val error: String? = null,
    val requestId: String? = null,
)

@Serializable
data class SyntraSyncCursor(
    val resource: String,
    val cursor: String? = null,
    val updatedSince: String? = null,
)

@Serializable
data class SyntraHealth(
    val status: String,
    val version: String? = null,
)

interface SyntraApi {
    suspend fun health(): SyntraResult<SyntraHealth>
    suspend fun syncCatalogue(cursor: SyntraSyncCursor?): SyntraResult<SyntraSyncCursor>
    suspend fun pushListeningEvents(eventsJson: String): SyntraResult<Unit>
    suspend fun validateEntitlement(userId: String, feature: String): SyntraResult<Boolean>
}

sealed class SyntraResult<out T> {
    data class Ok<T>(val value: T) : SyntraResult<T>()
    data class Unavailable(val reason: String) : SyntraResult<Nothing>()
    data class Error(val code: Int?, val message: String) : SyntraResult<Nothing>()
}

class SyntraClient(private val config: SyntraConfig?) : SyntraApi {

    private fun down() = SyntraResult.Unavailable(
        "Syntra is not configured. Set SyntraConfig.baseUrl and token provider."
    )

    override suspend fun health(): SyntraResult<SyntraHealth> {
        if (config == null || config.baseUrl.isBlank()) return down()
        return SyntraResult.Unavailable("Deploy Syntra health endpoint and inject HTTP client")
    }

    override suspend fun syncCatalogue(cursor: SyntraSyncCursor?): SyntraResult<SyntraSyncCursor> {
        if (config == null || config.baseUrl.isBlank()) return down()
        return SyntraResult.Unavailable("Deploy Syntra catalogue sync endpoint")
    }

    override suspend fun pushListeningEvents(eventsJson: String): SyntraResult<Unit> {
        if (config == null || config.baseUrl.isBlank()) return down()
        return SyntraResult.Unavailable("Deploy Syntra events endpoint")
    }

    override suspend fun validateEntitlement(userId: String, feature: String): SyntraResult<Boolean> {
        if (config == null || config.baseUrl.isBlank()) return down()
        return SyntraResult.Unavailable("Deploy Syntra entitlement endpoint")
    }
}

/**
 * Versioned API contract documentation constants for implementers.
 */
object SyntraContracts {
    const val API_VERSION = "1"
    const val HEADER_APP_ID = "x-sonara-app-id"
    const val HEADER_REQUEST_ID = "x-request-id"
    const val PATH_HEALTH = "/v1/health"
    const val PATH_CATALOGUE_SYNC = "/v1/sync/catalogue"
    const val PATH_EVENTS = "/v1/events/listening"
    const val PATH_ENTITLEMENT = "/v1/entitlements/validate"
}
