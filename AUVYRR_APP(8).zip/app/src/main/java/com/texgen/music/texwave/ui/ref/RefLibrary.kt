package com.texgen.music.texwave.ui.ref

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Playlist
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.catalog.OpenCatalogEngine
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable

private val deviceTabs = listOf("Songs", "Albums", "Artists", "Playlists")

/** Reference pill search field. */
@Composable
fun RefSearchField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    height: androidx.compose.ui.unit.Dp = 46.dp,
    textSize: androidx.compose.ui.unit.TextUnit = 14.sp,
) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF1B1B1D), Color(0xFF1B1B1D))))
            .border(1.2.dp, Brush.horizontalGradient(listOf(Ref.LineHi, Ref.Violet.copy(alpha = 0.6f), Ref.LineHi)), shape)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, null, tint = Color(0xFFCFD9FF), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = textSize),
            cursorBrush = SolidColor(Ref.Cyan),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(placeholder, color = Color(0xFF6F86C8), fontSize = textSize)
                    inner()
                }
            },
        )
    }
}

/**
 * Unified Library — On device + Online in one attractive screen.
 * Replaces the old split between local library and stream/online library.
 */
@Composable
fun RefLibraryScreen(
    lib: LibraryState,
    player: PlayerState,
    initialTab: Int = 0,
    startOnline: Boolean = false,
    onPlay: (List<Song>, Int) -> Unit,
    onMore: (Song) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onNewPlaylist: () -> Unit,
    onSearch: () -> Unit,
    onProfile: () -> Unit,
    onStream: (url: String, title: String, artist: String) -> Unit = { _, _, _ -> },
) {
    var source by rememberSaveable { mutableIntStateOf(if (startOnline) 1 else 0) } // 0 device, 1 online
    var tab by rememberSaveable { mutableIntStateOf(initialTab.coerceIn(0, 3)) }
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim().lowercase()

    // Online catalog state
    var onlineLoading by remember { mutableStateOf(false) }
    var onlineItems by remember { mutableStateOf<List<OpenCatalogEngine.AudioItem>>(emptyList()) }
    var onlineShelf by remember { mutableIntStateOf(0) }
    val shelves = OpenCatalogEngine.streamShelves

    LaunchedEffect(source, onlineShelf, query) {
        if (source != 1) return@LaunchedEffect
        onlineLoading = true
        try {
            onlineItems = if (query.isNotBlank()) {
                OpenCatalogEngine.searchAudioFast(query, 28)
            } else {
                OpenCatalogEngine.loadShelf(shelves[onlineShelf.coerceIn(0, shelves.lastIndex)], 16)
            }
        } catch (_: Exception) {
            onlineItems = emptyList()
        }
        onlineLoading = false
    }

    val songs = remember(lib.songs, q) {
        if (q.isEmpty()) lib.songs
        else com.texgen.music.texwave.data.SmartSearch.songs(lib.songs, q, lib.liked, lib.playCounts, emptySet(), 500)
    }
    val albums = remember(lib.songs, q) {
        lib.songs.groupBy { it.albumId }.values
            .map { it to it.first() }
            .filter { (_, f) -> q.isEmpty() || com.texgen.music.texwave.data.SmartSearch.albums(listOf(f), q).isNotEmpty() || com.texgen.music.texwave.data.SmartSearch.artists(listOf(f), q).isNotEmpty() }
            .sortedBy { it.second.album.lowercase() }
    }
    val artists = remember(lib.songs, q) {
        lib.songs.groupBy { it.artist }.entries
            .filter { q.isEmpty() || com.texgen.music.texwave.data.SmartSearch.artists(listOf(it.value.first()), q).isNotEmpty() }
            .sortedBy { it.key.lowercase() }
    }
    val playlists = remember(lib.playlists, q) {
        if (q.isEmpty()) lib.playlists else com.texgen.music.texwave.data.SmartSearch.playlists(lib.playlists, q)
    }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // Hero header
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF1A0B3A), Color(0xFF0B1B4A), Color(0xFF18181A)),
                        ),
                    )
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(Ref.Violet.copy(0.55f), Ref.Cyan.copy(0.45f), Ref.Magenta.copy(0.35f))),
                        RoundedCornerShape(24.dp),
                    )
                    .padding(horizontal = 18.dp, vertical = 16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Ref.Violet, Ref.Cyan))),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.LibraryMusic, null, tint = Color.White, modifier = Modifier.size(26.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Library", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (source == 0) "${lib.songs.size} songs on this device"
                            else "Stream & save open music",
                            color = Ref.Sub, fontSize = 13.sp,
                        )
                    }
                    IconCircle(Icons.Rounded.Search, onSearch)
                    Spacer(Modifier.width(8.dp))
                    IconCircle(Icons.Rounded.Person, onProfile)
                }
            }

            // Source switcher — On device | Online
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF131315))
                    .border(1.dp, Ref.Line.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                    .padding(4.dp),
            ) {
                listOf("On device" to Icons.Rounded.LibraryMusic, "Online" to Icons.Rounded.Cloud).forEachIndexed { i, (label, icon) ->
                    val on = source == i
                    Row(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (on) Brush.horizontalGradient(listOf(Ref.Violet.copy(0.55f), Ref.Cyan.copy(0.4f)))
                                else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)),
                            )
                            .pressable(0.97f) { source = i }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(icon, null, tint = if (on) Color.White else Ref.Sub, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            label,
                            color = if (on) Color.White else Ref.Sub,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium,
                            fontSize = 14.sp,
                        )
                    }
                }
            }

            AnimatedContent(
                targetState = source,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "libSource",
            ) { src ->
                Column(Modifier.fillMaxSize()) {
                    if (src == 0) {
                        // Device sub-tabs
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp, start = 12.dp, end = 12.dp)) {
                            deviceTabs.forEachIndexed { i, t ->
                                val on = i == tab
                                Column(
                                    Modifier.weight(1f).clickable { tab = i }.padding(vertical = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Text(
                                        t, fontSize = 15.sp,
                                        color = if (on) Ref.Lavender else Color.White.copy(alpha = 0.75f),
                                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Box(
                                        Modifier.height(2.5.dp).fillMaxWidth(0.75f)
                                            .background(
                                                if (on) Brush.horizontalGradient(listOf(Ref.Cyan, Ref.Blue))
                                                else SolidColor(Color.Transparent),
                                            ),
                                    )
                                }
                            }
                        }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Ref.Line.copy(alpha = 0.55f)))
                        RefSearchField(
                            value = query, onChange = { query = it },
                            placeholder = "Search songs, artists, albums...",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                            height = 44.dp, textSize = 13.sp,
                        )
                        LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 18.dp, end = 12.dp, bottom = 20.dp),
                        ) {
                            when (tab) {
                                0 -> itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                                    val playing = player.current?.id == s.id
                                    RefRow(
                                        title = s.title, subtitle = s.artist, card = false, thumbBorder = playing,
                                        modifier = Modifier.padding(vertical = 4.dp).appear(30 + (i % 12) * 20),
                                        onChevron = { onMore(s) },
                                        onClick = { onPlay(songs, i) },
                                    ) { SongThumb(s, Modifier.size(58.dp), RoundedCornerShape(14.dp)) }
                                }
                                1 -> itemsIndexed(albums, key = { _, a -> a.second.albumId }) { i, a ->
                                    val list = a.first
                                    RefRow(
                                        title = a.second.album,
                                        subtitle = "${a.second.artist} • ${list.size} songs",
                                        card = false,
                                        modifier = Modifier.padding(vertical = 4.dp).appear(30 + (i % 10) * 20),
                                        onClick = { onPlay(list, 0) },
                                    ) { SongThumb(a.second, Modifier.size(58.dp), RoundedCornerShape(14.dp)) }
                                }
                                2 -> itemsIndexed(artists, key = { _, a -> a.key }) { i, a ->
                                    RefRow(
                                        title = a.key, subtitle = "${a.value.size} songs", card = false,
                                        modifier = Modifier.padding(vertical = 4.dp).appear(30 + (i % 10) * 20),
                                        onClick = { onPlay(a.value, 0) },
                                    ) { InitialsAvatar(a.key, Modifier.size(58.dp)) }
                                }
                                else -> {
                                    item {
                                        RefRow(
                                            title = "New playlist", subtitle = "Create a collection", card = true,
                                            modifier = Modifier.padding(vertical = 6.dp).appear(40),
                                            onClick = onNewPlaylist,
                                        ) {
                                            Box(
                                                Modifier.size(58.dp).clip(RoundedCornerShape(14.dp))
                                                    .background(Brush.linearGradient(listOf(Ref.Violet, Ref.Cyan))),
                                                contentAlignment = Alignment.Center,
                                            ) {
                                                Text("+", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                    itemsIndexed(playlists, key = { _, pl -> pl.id }) { i, pl ->
                                        RefRow(
                                            title = pl.name,
                                            subtitle = "${pl.songIds.size} songs",
                                            card = false,
                                            modifier = Modifier.padding(vertical = 4.dp).appear(50 + i * 25),
                                            onClick = { onOpenPlaylist(pl) },
                                        ) {
                                            Box(
                                                Modifier.size(58.dp).clip(RoundedCornerShape(14.dp))
                                                    .background(Color(0xFF152040)),
                                                contentAlignment = Alignment.Center,
                                            ) {
                                                Icon(Icons.Rounded.LibraryMusic, null, tint = Ref.Cyan, modifier = Modifier.size(26.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // Online catalog
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            shelves.forEachIndexed { i, shelf ->
                                val on = onlineShelf == i && query.isBlank()
                                Box(
                                    Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(
                                            if (on) Brush.horizontalGradient(listOf(Ref.Violet, Ref.Cyan))
                                            else Brush.horizontalGradient(listOf(Color(0xFF1E1E20), Color(0xFF19191B))),
                                        )
                                        .border(1.dp, if (on) Color.Transparent else Ref.Line, RoundedCornerShape(20.dp))
                                        .pressable(0.96f) {
                                            query = ""
                                            onlineShelf = i
                                        }
                                        .padding(horizontal = 14.dp, vertical = 9.dp),
                                ) {
                                    Text(shelf.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        RefSearchField(
                            value = query, onChange = { query = it },
                            placeholder = "Search online catalog…",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                            height = 44.dp, textSize = 13.sp,
                        )
                        if (onlineLoading) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Ref.Cyan)
                            }
                        } else if (onlineItems.isEmpty()) {
                            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    "No tracks found. Try another mood or search.",
                                    color = Ref.Sub, fontSize = 14.sp,
                                )
                            }
                        } else {
                            LazyColumn(
                                Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 20.dp),
                            ) {
                                itemsIndexed(onlineItems, key = { _, it -> it.id }) { i, item ->
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 5.dp)
                                            .clip(RoundedCornerShape(18.dp))
                                            .background(Color(0xFF161618))
                                            .border(1.dp, Ref.Line.copy(0.45f), RoundedCornerShape(18.dp))
                                            .pressable(0.97f) {
                                                onStream(item.url, item.title, item.artist)
                                            }
                                            .padding(12.dp)
                                            .appear(30 + (i % 10) * 22),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Box(
                                            Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(Brush.linearGradient(listOf(Ref.Violet.copy(0.5f), Ref.Cyan.copy(0.35f)))),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(28.dp))
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                item.title, color = Color.White, fontSize = 15.sp,
                                                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                            )
                                            Text(
                                                item.artist, color = Ref.Sub, fontSize = 12.sp,
                                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                        Text("Play", color = Ref.Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
