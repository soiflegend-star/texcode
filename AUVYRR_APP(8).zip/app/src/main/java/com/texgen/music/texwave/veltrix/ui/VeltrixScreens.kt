package com.texgen.music.texwave.veltrix.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.veltrix.Veltrix
import com.texgen.music.texwave.veltrix.engine.VeltrixScheduler
import com.texgen.music.texwave.veltrix.model.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

/* Premium glass palette matching the reference mock */
private object Vx {
    val Bg = Color(0xFF050508)
    val Glass = Color(0xCC12121A)
    val GlassLight = Color(0x991A1A28)
    val GlassBorder = Color(0x33A78BFA)
    val GlassBorderSoft = Color(0x1AFFFFFF)
    val Violet = Color(0xFF8B5CF6)
    val VioletBright = Color(0xFFA78BFA)
    val VioletDeep = Color(0xFF6D28D9)
    val Glow = Color(0x668B5CF6)
    val Success = Color(0xFF22C55E)
    val SuccessSoft = Color(0x3322C55E)
    val Amber = Color(0xFFF59E0B)
    val Danger = Color(0xFFEF4444)
    val Text = Color(0xFFF8FAFC)
    val Muted = Color(0xFF94A3B8)
    val Dim = Color(0xFF64748B)
    val radius = 20.dp
    val radiusSm = 14.dp
    val radiusXs = 10.dp
}

private val glassBrush = Brush.verticalGradient(
    listOf(Color(0x22A78BFA), Color(0x0AFFFFFF), Color(0x00FFFFFF))
)

@Composable
fun VeltrixRoot(onClose: (() -> Unit)? = null, onOpenTrimEditor: (() -> Unit)? = null) {
    Veltrix.init(LocalContext.current)
    var tab by remember { mutableIntStateOf(0) }
    var editorId by remember { mutableStateOf<String?>(null) }
    var detailExecId by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = editorId != null || detailExecId != null || tab != 0) {
        if (editorId != null) editorId = null
        else if (detailExecId != null) detailExecId = null
        else tab = 0
    }

    when {
        editorId != null -> VeltrixEditor(automationId = editorId!!, onBack = { editorId = null })
        detailExecId != null -> VeltrixExecDetail(executionId = detailExecId!!, onBack = { detailExecId = null })
        else -> Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF0B0614), Vx.Bg, Color(0xFF06040C))
                    )
                )
        ) {
            // ambient glow
            Box(
                Modifier
                    .size(280.dp)
                    .offset((-40).dp, (-20).dp)
                    .background(
                        Brush.radialGradient(listOf(Color(0x338B5CF6), Color.Transparent))
                    )
            )

            Column(Modifier.fillMaxSize()) {
                // Top bar
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onClose != null) {
                        IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Rounded.Close, null, tint = Vx.Muted, modifier = Modifier.size(20.dp))
                        }
                    }
                    // Logo mark
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(listOf(Vx.Violet, Vx.VioletDeep))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("V", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "VELTRIX",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            letterSpacing = 2.sp,
                            color = Vx.Text
                        )
                        Text("Automation Engine", fontSize = 11.sp, color = Vx.Muted)
                    }
                    Icon(
                        Icons.Rounded.Settings,
                        null,
                        tint = Vx.Muted,
                        modifier = Modifier
                            .size(22.dp)
                            .clickable { tab = 4 }
                    )
                }

                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> VxHome(
                            onCreate = { editorId = "new" },
                            onOpen = { editorId = it },
                            onViewAll = { tab = 1 },
                            onActivity = { tab = 2 },
                            onOpenTrimEditor = onOpenTrimEditor
                        )
                        1 -> VxAutomations(onCreate = { editorId = "new" }, onOpen = { editorId = it })
                        2 -> VxActivity(onOpenDetail = { detailExecId = it })
                        3 -> VxFiles()
                        4 -> VxSettings()
                    }
                }

                // Glass bottom nav
                GlassBottomNav(selected = tab, onSelect = { tab = it })
            }
        }
    }
}

@Composable
private fun GlassBottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        Icons.Rounded.Home to "Home",
        Icons.Rounded.PlayArrow to "Automations",
        Icons.Rounded.BarChart to "Activity",
        Icons.Rounded.Folder to "Files",
        Icons.Rounded.Tune to "Settings"
    )
    Row(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xE6101018))
            .border(1.dp, Vx.GlassBorderSoft, RoundedCornerShape(24.dp))
            .padding(vertical = 6.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEachIndexed { i, (icon, label) ->
            val on = selected == i
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onSelect(i) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Icon(
                    icon,
                    null,
                    tint = if (on) Vx.VioletBright else Vx.Dim,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    label,
                    fontSize = 9.sp,
                    color = if (on) Vx.VioletBright else Vx.Dim,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}

/* ───────────── HOME ───────────── */

@Composable
private fun VxHome(
    onCreate: () -> Unit,
    onOpen: (String) -> Unit,
    onViewAll: () -> Unit,
    onActivity: () -> Unit,
    onOpenTrimEditor: (() -> Unit)? = null
) {
    val autos by Veltrix.store.automations.collectAsState()
    val execs by Veltrix.store.executions.collectAsState()
    val active = autos.count { it.status == VxAutomationStatus.ENABLED }
    val last = execs.firstOrNull()
    val lastTime = last?.let {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it.startedAt))
    } ?: "—"
    val running = execs.firstOrNull { it.status == VxRunStatus.RUNNING }
    val pulse = rememberInfiniteTransition(label = "p")
    val glow by pulse.animateFloat(
        0.5f, 1f,
        infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse),
        label = "g"
    )

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // CORE hero
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Vx.radius))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF1A0F2E), Color(0xFF0F0A18), Color(0xFF12101C))
                        )
                    )
                    .border(1.dp, Vx.GlassBorder, RoundedCornerShape(Vx.radius))
            ) {
                // soft radial glow
                Box(
                    Modifier
                        .matchParentSize()
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0x448B5CF6), Color.Transparent),
                                center = Offset(80f, 80f),
                                radius = 320f
                            )
                        )
                )
                Row(
                    Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // V emblem
                    Box(
                        Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0x558B5CF6), Color(0x228B5CF6), Color.Transparent)
                                )
                            )
                            .border(1.dp, Vx.GlassBorder, RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "V",
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            color = Vx.VioletBright
                        )
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "VELTRIX CORE",
                            fontSize = 11.sp,
                            letterSpacing = 2.sp,
                            color = Vx.Muted,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Vx.Success.copy(alpha = glow))
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "ONLINE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Vx.Success
                            )
                        }
                        Text(
                            "Automation Engine Active",
                            fontSize = 12.sp,
                            color = Vx.Muted
                        )
                        Spacer(Modifier.height(12.dp))
                        Row {
                            CoreStat(Icons.Rounded.Bolt, "$active", "Active Automations")
                            Spacer(Modifier.width(16.dp))
                            CoreStat(Icons.Rounded.Schedule, lastTime, "Last Execution")
                        }
                    }
                }
            }
        }

        // Status row
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusChip(
                    Modifier.weight(1f),
                    Icons.Rounded.AutoAwesome,
                    "Automations",
                    "${autos.size} saved",
                    Vx.Success
                )
                StatusChip(
                    Modifier.weight(1f),
                    Icons.Rounded.CalendarMonth,
                    "Scheduled",
                    "${autos.count { it.status == VxAutomationStatus.ENABLED && it.nodes.any { n -> n.kind == VxNodeKind.TRIGGER_TIME } }} timed",
                    Vx.VioletBright
                )
                StatusChip(
                    Modifier.weight(1f),
                    Icons.Rounded.BarChart,
                    "Total runs",
                    "${autos.sumOf { it.runCount }}",
                    Vx.VioletBright
                )
            }
        }

        // Automations header
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .width(3.dp)
                            .height(14.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Vx.VioletBright)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "AUTOMATIONS",
                        fontSize = 12.sp,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Vx.Text
                    )
                }
                Text(
                    "View All →",
                    fontSize = 12.sp,
                    color = Vx.VioletBright,
                    modifier = Modifier.clickable(onClick = onViewAll)
                )
            }
        }

        items(autos.take(4)) { a ->
            PremiumAutoCard(
                a = a,
                onOpen = { onOpen(a.id) },
                onToggle = null
            )
        }

        // Builder CTA
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Vx.radiusSm))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF1A1230), Color(0xFF12101C))
                        )
                    )
                    .border(1.dp, Vx.GlassBorder, RoundedCornerShape(Vx.radiusSm))
                    .clickable(onClick = onCreate)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x338B5CF6)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.AccountTree, null, tint = Vx.VioletBright, modifier = Modifier.size(26.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Automation Builder", fontWeight = FontWeight.SemiBold, color = Vx.Text)
                    Text("Create powerful workflows with visual logic", fontSize = 12.sp, color = Vx.Muted)
                }
                Box(
                    Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.horizontalGradient(listOf(Vx.Violet, Vx.VioletDeep))
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text("Build Now →", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                }
            }
        }

        if (onOpenTrimEditor != null) {
            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Vx.radiusSm))
                        .background(Color(0xCC101018))
                        .border(1.dp, Vx.GlassBorderSoft, RoundedCornerShape(Vx.radiusSm))
                        .clickable(onClick = onOpenTrimEditor)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Tune, null, tint = Vx.VioletBright, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Trim and edit songs", fontWeight = FontWeight.SemiBold, color = Vx.Text)
                        Text("Open the audio trimmer", fontSize = 12.sp, color = Vx.Muted)
                    }
                    Icon(Icons.Rounded.ArrowForward, null, tint = Vx.Muted, modifier = Modifier.size(18.dp))
                }
            }
        }

        // Live execution
        item {
            val live = running ?: execs.firstOrNull()
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Vx.radiusSm))
                    .background(Color(0xCC101018))
                    .border(1.dp, Vx.GlassBorderSoft, RoundedCornerShape(Vx.radiusSm))
                    .clickable(onClick = onActivity)
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.GraphicEq, null, tint = Vx.VioletBright, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "LIVE EXECUTION",
                        fontSize = 11.sp,
                        letterSpacing = 1.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Vx.Text,
                        modifier = Modifier.weight(1f)
                    )
                    if (live?.status == VxRunStatus.RUNNING) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(Vx.VioletBright.copy(alpha = glow)))
                            Spacer(Modifier.width(6.dp))
                            Text("Running…", fontSize = 11.sp, color = Vx.VioletBright)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (live == null) {
                    Text("No recent activity", color = Vx.Muted, fontSize = 13.sp)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // ring-ish progress
                        val progress = when (live.status) {
                            VxRunStatus.RUNNING -> 0.55f
                            VxRunStatus.SUCCESS -> 1f
                            else -> 0.3f
                        }
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(56.dp)) {
                            CircularProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxSize(),
                                color = Vx.VioletBright,
                                strokeWidth = 4.dp,
                                trackColor = Color(0x338B5CF6),
                            )
                            Text(
                                "${(progress * 100).toInt()}%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Vx.Text
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                live.logs.lastOrNull()?.message ?: live.automationName,
                                fontWeight = FontWeight.Medium,
                                color = Vx.Text,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(live.automationName, fontSize = 12.sp, color = Vx.Muted)
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                color = Vx.VioletBright,
                                trackColor = Color(0x338B5CF6)
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            LiveCheck("Engine ready", true)
                            LiveCheck("${live.logs.size} events", live.logs.isNotEmpty())
                            LiveCheck(
                                live.status.name.lowercase().replaceFirstChar { it.uppercase() },
                                live.status == VxRunStatus.SUCCESS || live.status == VxRunStatus.RUNNING
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
private fun CoreStat(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Vx.VioletBright, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Column {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Vx.Text)
            Text(label, fontSize = 9.sp, color = Vx.Dim)
        }
    }
}

@Composable
private fun StatusChip(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    valueColor: Color
) {
    Column(
        modifier
            .clip(RoundedCornerShape(Vx.radiusXs))
            .background(Color(0xCC14141E))
            .border(1.dp, Vx.GlassBorderSoft, RoundedCornerShape(Vx.radiusXs))
            .padding(10.dp)
    ) {
        Icon(icon, null, tint = Vx.VioletBright, modifier = Modifier.size(16.dp))
        Spacer(Modifier.height(6.dp))
        Text(title, fontSize = 10.sp, color = Vx.Dim, maxLines = 1)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = valueColor, maxLines = 1)
    }
}

@Composable
private fun LiveCheck(text: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 1.dp)) {
        Icon(
            if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
            null,
            tint = if (ok) Vx.Success else Vx.Dim,
            modifier = Modifier.size(12.dp)
        )
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 10.sp, color = Vx.Muted, maxLines = 1)
    }
}

@Composable
private fun PremiumAutoCard(
    a: VxAutomation,
    onOpen: () -> Unit,
    onToggle: (() -> Unit)?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled = a.status == VxAutomationStatus.ENABLED
    val trigger = a.nodes.firstOrNull { it.kind.name.startsWith("TRIGGER") }
    val action = a.nodes.firstOrNull { it.kind.name.startsWith("ACTION") }

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Vx.radiusSm))
            .background(Color(0xCC12121C))
            .border(1.dp, Vx.GlassBorderSoft, RoundedCornerShape(Vx.radiusSm))
            .clickable(onClick = onOpen)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.radialGradient(listOf(Color(0x558B5CF6), Color(0x228B5CF6)))
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = Vx.VioletBright, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    a.name,
                    fontWeight = FontWeight.SemiBold,
                    color = Vx.Text,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (enabled) Vx.SuccessSoft else Color(0x33F59E0B))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        if (enabled) "ACTIVE" else "OFF",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (enabled) Vx.Success else Vx.Amber
                    )
                }
            }
            if (a.description.isNotBlank()) {
                Text(a.description, fontSize = 11.sp, color = Vx.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(trigger?.title ?: "Trigger", fontSize = 10.sp, color = Vx.VioletBright)
                Text("  →  ", fontSize = 10.sp, color = Vx.Dim)
                Text(action?.title ?: "Action", fontSize = 10.sp, color = Vx.Muted)
            }
            a.lastRunAt?.let {
                Text(
                    "Last: " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it)),
                    fontSize = 10.sp,
                    color = Vx.Dim
                )
            }
        }
        Switch(
            checked = enabled,
            onCheckedChange = {
                scope.launch {
                    val st = if (it) VxAutomationStatus.ENABLED else VxAutomationStatus.DISABLED
                    Veltrix.store.saveAutomation(a.copy(status = st))
                    if (it) VeltrixScheduler.scheduleEnabled(context, Veltrix.store)
                    else VeltrixScheduler.cancel(context, a.id)
                }
                onToggle?.invoke()
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Vx.Violet,
                uncheckedTrackColor = Color(0xFF2A2A38)
            )
        )
    }
}

/* ───────────── AUTOMATIONS LIST ───────────── */

@Composable
private fun VxAutomations(onCreate: () -> Unit, onOpen: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val autos by Veltrix.store.automations.collectAsState()
    var running by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Automations", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Vx.Text)
            Box(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.horizontalGradient(listOf(Vx.Violet, Vx.VioletDeep)))
                    .clickable(onClick = onCreate)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text("+ New", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(autos, key = { it.id }) { a ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(Vx.radiusSm))
                        .background(Color(0xCC12121C))
                        .border(1.dp, Vx.GlassBorderSoft, RoundedCornerShape(Vx.radiusSm))
                        .padding(14.dp)
                ) {
                    PremiumAutoCard(a, onOpen = { onOpen(a.id) }, onToggle = null)
                    Row {
                        TextButton(onClick = {
                            scope.launch {
                                running = a.id
                                Veltrix.engine.run(a, "manual")
                                running = null
                            }
                        }, enabled = running != a.id) {
                            Text(if (running == a.id) "Running…" else "Run", color = Vx.VioletBright)
                        }
                        TextButton(onClick = { onOpen(a.id) }) {
                            Text("Edit", color = Vx.Text)
                        }
                        TextButton(onClick = {
                            scope.launch { Veltrix.store.deleteAutomation(a.id) }
                        }) {
                            Text("Delete", color = Vx.Danger)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

/* ───────────── ACTIVITY ───────────── */

@Composable
private fun VxActivity(onOpenDetail: (String) -> Unit) {
    val execs by Veltrix.store.executions.collectAsState()
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Activity", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Vx.Text, modifier = Modifier.padding(vertical = 8.dp))
        }
        items(execs) { e ->
            val c = when (e.status) {
                VxRunStatus.SUCCESS -> Vx.Success
                VxRunStatus.FAILED -> Vx.Danger
                VxRunStatus.RUNNING -> Vx.VioletBright
                else -> Vx.Muted
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(Vx.radiusSm))
                    .background(Color(0xCC12121C))
                    .border(1.dp, Vx.GlassBorderSoft, RoundedCornerShape(Vx.radiusSm))
                    .clickable { onOpenDetail(e.id) }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(c))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.automationName, fontWeight = FontWeight.Medium, color = Vx.Text, maxLines = 1)
                    Text(
                        SimpleDateFormat("MMM d · HH:mm", Locale.getDefault()).format(Date(e.startedAt)) +
                                " · ${e.trigger}",
                        fontSize = 11.sp,
                        color = Vx.Muted
                    )
                }
                Text(e.status.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = c)
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun VxFiles() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Files", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Vx.Text)
        GlassInfo("File actions", "Open app, open link, share text and clipboard steps are available in workflows. Folder and rename steps are not built yet.")
        GlassInfo("Activity", "Every step is logged under Activity.")
    }
}

@Composable
private fun VxSettings() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Vx.Text)
        GlassInfo("Engine", "Local Veltrix interpreter · JSON under app files")
        GlassInfo("Notifications", "Channel veltrix_notifications")
        GlassInfo("Scheduler", "AlarmManager + boot reschedule")
        GlassInfo("Theme", "Glass dark · violet identity")
    }
}

@Composable
private fun GlassInfo(title: String, body: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Vx.radiusSm))
            .background(Color(0xCC12121C))
            .border(1.dp, Vx.GlassBorderSoft, RoundedCornerShape(Vx.radiusSm))
            .padding(14.dp)
    ) {
        Text(title, fontWeight = FontWeight.SemiBold, color = Vx.Text)
        Spacer(Modifier.height(4.dp))
        Text(body, fontSize = 12.sp, color = Vx.Muted, lineHeight = 16.sp)
    }
}

/* ───────────── EDITOR ───────────── */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VeltrixEditor(automationId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var auto by remember { mutableStateOf<VxAutomation?>(null) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var selected by remember { mutableStateOf<String?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showCfg by remember { mutableStateOf(false) }
    var linkFrom by remember { mutableStateOf<String?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(automationId) {
        auto = if (automationId == "new") {
            val trig = VxNode(kind = VxNodeKind.TRIGGER_MANUAL, title = "Manual Trigger", x = 100f, y = 220f)
            VxAutomation(name = "New Automation", nodes = listOf(trig))
        } else Veltrix.store.getAutomation(automationId)
    }
    val a = auto ?: return
    fun update(t: (VxAutomation) -> VxAutomation) { auto = auto?.let(t) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0614), Vx.Bg)))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.45f, 2.2f)
                        offset += pan
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val map = a.nodes.associateBy { it.id }
                a.links.forEach { link ->
                    val from = map[link.fromId] ?: return@forEach
                    val to = map[link.toId] ?: return@forEach
                    val s = Offset((from.x + 148f) * scale + offset.x, (from.y + 32f) * scale + offset.y)
                    val e = Offset(to.x * scale + offset.x, (to.y + 32f) * scale + offset.y)
                    val path = Path().apply {
                        moveTo(s.x, s.y)
                        val mx = (s.x + e.x) / 2f
                        cubicTo(mx, s.y, mx, e.y, e.x, e.y)
                    }
                    drawPath(path, Vx.VioletBright.copy(alpha = 0.7f), style = Stroke(2.5f * scale, cap = StrokeCap.Round))
                }
            }
            a.nodes.forEach { node ->
                val edge = when {
                    node.kind.name.startsWith("TRIGGER") -> Vx.Success
                    node.kind == VxNodeKind.CONDITION -> Vx.Amber
                    else -> Vx.VioletBright
                }
                Box(
                    Modifier
                        .offset {
                            IntOffset(
                                (node.x * scale + offset.x).roundToInt(),
                                (node.y * scale + offset.y).roundToInt()
                            )
                        }
                        .width((156 * scale).dp)
                        .height((68 * scale).dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xEE161622))
                        .border(
                            if (selected == node.id) 1.5.dp else 1.dp,
                            if (selected == node.id) edge else Vx.GlassBorderSoft,
                            RoundedCornerShape(14.dp)
                        )
                        .pointerInput(node.id) {
                            detectTapGestures(
                                onTap = {
                                    if (linkFrom != null && linkFrom != node.id) {
                                        update { cur ->
                                            cur.copy(links = cur.links + VxLink(fromId = linkFrom!!, toId = node.id))
                                        }
                                        linkFrom = null
                                        toast = "Connected"
                                    } else {
                                        selected = node.id
                                        showCfg = true
                                    }
                                },
                                onLongPress = { linkFrom = node.id; toast = "Tap target to connect" }
                            )
                        }
                        .pointerInput(node.id) {
                            detectDragGestures { ch, amt ->
                                ch.consume()
                                update { cur ->
                                    cur.copy(nodes = cur.nodes.map {
                                        if (it.id == node.id) it.copy(x = it.x + amt.x / scale, y = it.y + amt.y / scale)
                                        else it
                                    })
                                }
                            }
                        }
                ) {
                    Box(Modifier.fillMaxHeight().width(3.dp).background(edge).align(Alignment.CenterStart))
                    Column(Modifier.padding(start = 14.dp, top = 12.dp, end = 10.dp)) {
                        Text(node.title, color = Vx.Text, fontWeight = FontWeight.Medium, fontSize = (13 * scale).sp, maxLines = 1)
                        Text(kindTitle(node.kind), color = edge, fontSize = (10 * scale).sp, maxLines = 1)
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(Color(0xEE101018))
                .statusBarsPadding()
                .border(1.dp, Vx.GlassBorderSoft)
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = Vx.Text) }
            OutlinedTextField(
                value = a.name,
                onValueChange = { n -> update { it.copy(name = n) } },
                singleLine = true,
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Vx.Text,
                    unfocusedTextColor = Vx.Text,
                    focusedBorderColor = Vx.Violet,
                    unfocusedBorderColor = Color.Transparent,
                    cursorColor = Vx.VioletBright
                )
            )
            IconButton(onClick = { showAdd = true }) { Icon(Icons.Rounded.Add, null, tint = Vx.VioletBright) }
            TextButton(onClick = {
                scope.launch {
                    Veltrix.store.saveAutomation(a)
                    if (a.status == VxAutomationStatus.ENABLED)
                        VeltrixScheduler.scheduleEnabled(context, Veltrix.store)
                    toast = "Saved"
                }
            }) { Text("Save", color = Vx.Text) }
            TextButton(onClick = {
                scope.launch {
                    Veltrix.store.saveAutomation(a)
                    Veltrix.engine.run(a, "manual")
                    toast = "Executed"
                }
            }) { Text("Run", color = Vx.Success) }
        }

        toast?.let {
            LaunchedEffect(it) { kotlinx.coroutines.delay(1600); toast = null }
            Text(
                it,
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 28.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xEE1A1A28))
                    .border(1.dp, Vx.GlassBorder, RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                color = Vx.Text,
                fontSize = 13.sp
            )
        }
    }

    if (showAdd) {
        ModalBottomSheet(onDismissRequest = { showAdd = false }, containerColor = Color(0xFF12121C)) {
            Text("Add node", Modifier.padding(20.dp), fontWeight = FontWeight.SemiBold, color = Vx.Text)
            LazyColumn {
                items(VxNodeKind.entries) { kind ->
                    ListItem(
                        headlineContent = { Text(kindTitle(kind), color = Vx.Text) },
                        modifier = Modifier.clickable {
                            val node = VxNode(
                                kind = kind,
                                title = kindTitle(kind),
                                x = 140f - offset.x / scale,
                                y = 300f - offset.y / scale,
                                configs = defaultConfigs(kind)
                            )
                            update { it.copy(nodes = it.nodes + node) }
                            selected = node.id
                            showAdd = false
                            showCfg = true
                        },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
                item { Spacer(Modifier.height(40.dp)) }
            }
        }
    }

    if (showCfg && selected != null) {
        val node = a.nodes.find { it.id == selected }
        if (node != null) {
            ModalBottomSheet(onDismissRequest = { showCfg = false }, containerColor = Color(0xFF12121C)) {
                Column(Modifier.padding(20.dp)) {
                    Text(kindTitle(node.kind), fontWeight = FontWeight.SemiBold, color = Vx.Text)
                    Spacer(Modifier.height(12.dp))
                    var title by remember(node.id) { mutableStateOf(node.title) }
                    OutlinedTextField(
                        value = title,
                        onValueChange = {
                            title = it
                            update { cur ->
                                cur.copy(nodes = cur.nodes.map { n -> if (n.id == node.id) n.copy(title = it) else n })
                            }
                        },
                        label = { Text("Title") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = cfgColors()
                    )
                    node.configs.forEach { cfg ->
                        var v by remember(node.id, cfg.key) { mutableStateOf(cfg.value) }
                        OutlinedTextField(
                            value = v,
                            onValueChange = { nv ->
                                v = nv
                                update { cur ->
                                    cur.copy(nodes = cur.nodes.map { n ->
                                        if (n.id != node.id) n
                                        else n.copy(configs = n.configs.map {
                                            if (it.key == cfg.key) it.copy(value = nv) else it
                                        })
                                    })
                                }
                            },
                            label = { Text(cfg.label) },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            colors = cfgColors()
                        )
                    }
                    Text("Long-press a node, then tap another to connect.", fontSize = 12.sp, color = Vx.Muted, modifier = Modifier.padding(vertical = 12.dp))
                    Button(
                        onClick = {
                            update { cur ->
                                cur.copy(
                                    nodes = cur.nodes.filter { it.id != node.id },
                                    links = cur.links.filter { it.fromId != node.id && it.toId != node.id }
                                )
                            }
                            showCfg = false
                            selected = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Vx.Danger),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Delete node") }
                    Spacer(Modifier.height(28.dp))
                }
            }
        }
    }
}

@Composable
fun VeltrixExecDetail(executionId: String, onBack: () -> Unit) {
    val execs by Veltrix.store.executions.collectAsState()
    val e = execs.find { it.id == executionId }
    Column(Modifier.fillMaxSize().background(Vx.Bg)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = Vx.Text) }
            Text("Execution", fontWeight = FontWeight.SemiBold, color = Vx.Text)
        }
        if (e == null) {
            Text("Not found", color = Vx.Muted, modifier = Modifier.padding(16.dp))
            return
        }
        LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text(e.automationName, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Vx.Text)
                Text("${e.status} · ${e.trigger}", color = Vx.Muted, fontSize = 13.sp)
            }
            items(e.logs) { line ->
                Text(
                    "${line.level}  ${line.message}",
                    fontSize = 12.sp,
                    color = if (line.level == "ERROR") Vx.Danger else Vx.Text,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xCC12121C))
                        .padding(10.dp)
                )
            }
        }
    }
}

@Composable
private fun cfgColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Vx.Violet,
    unfocusedBorderColor = Vx.GlassBorderSoft,
    focusedTextColor = Vx.Text,
    unfocusedTextColor = Vx.Text,
    focusedLabelColor = Vx.VioletBright,
    unfocusedLabelColor = Vx.Muted,
    cursorColor = Vx.VioletBright
)
