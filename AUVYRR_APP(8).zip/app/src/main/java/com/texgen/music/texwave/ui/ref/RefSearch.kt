package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.SmartSearch
import com.texgen.music.texwave.data.catalog.OpenCatalogEngine
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import kotlinx.coroutines.delay

private data class Cat(val label: String, val icon: ImageVector, val colors: List<Color>)

private val cats = listOf(
    Cat("Artists", Icons.Rounded.Person, listOf(Color(0xFFB04DFF), Color(0xFF14876A))),
    Cat("Songs", Icons.Rounded.MusicNote, listOf(Color(0xFF7B5CFF), Color(0xFF3A3FD8))),
    Cat("Albums", Icons.Rounded.Album, listOf(Color(0xFF1DB98A), Color(0xFF2BE4A4))),
    Cat("Playlists", Icons.Rounded.PlaylistPlay, listOf(Color(0xFF2BE4A4), Color(0xFF1AE0B0))),
)

private fun recents(ctx: android.content.Context): List<String> =
    ctx.getSharedPreferences("texwave_ui", android.content.Context.MODE_PRIVATE)
        .getString("recent_searches", "")?.split('\n')?.filter { it.isNotBlank() } ?: emptyList()

private fun saveRecent(ctx: android.content.Context, q: String) {
    val t = q.trim()
    if (t.length < 2) return
    val next = (listOf(t) + recents(ctx).filterNot { it.equals(t, true) }).take(8)
    ctx.getSharedPreferences("texwave_ui", android.content.Context.MODE_PRIVATE).edit().putString("recent_searches", next.joinToString("\n")).apply()
}

/** Reference screen 4 — Search (smart local search + online results). */
@Composable
fun RefSearchScreen(
    lib: LibraryState,
    player: PlayerState,
    onPlay: (List<Song>, Int) -> Unit,
    onMore: (Song) -> Unit,
    onOpenPlaylistId: (String) -> Unit,
    onStreamOnline: (url: String, title: String, artist: String) -> Unit = { _, _, _ -> },
    onOpenDiscover: () -> Unit = {},
) {
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var cat by rememberSaveable { mutableIntStateOf(-1) }
    var recent by remember { mutableStateOf(recents(context)) }
    val q = query.trim()

    val songHits = remember(lib.songs, q, lib.liked, lib.playCounts, lib.blacklist) {
        if (q.isEmpty()) emptyList() else SmartSearch.songs(lib.songs, q, lib.liked, lib.playCounts, lib.blacklist, 80)
    }
    val artistHits = remember(lib.songs, q) { if (q.isEmpty()) emptyList() else SmartSearch.artists(lib.songs, q, 10) }
    val albumHits = remember(lib.songs, q) { if (q.isEmpty()) emptyList() else SmartSearch.albums(lib.songs, q, 10) }
    val playlistHits = remember(lib.playlists, q) { if (q.isEmpty()) emptyList() else SmartSearch.playlists(lib.playlists, q) }
    val noLocal = q.isNotEmpty() && songHits.isEmpty() && artistHits.isEmpty() && albumHits.isEmpty() && playlistHits.isEmpty()
    val suggestion = remember(lib.songs, q, noLocal) { if (noLocal || (q.isNotEmpty() && songHits.size < 2)) SmartSearch.didYouMean(lib.songs, q) else null }

    // Online catalog results, debounced, so something useful appears even when the library has nothing
    var online by remember { mutableStateOf<List<OpenCatalogEngine.AudioItem>>(emptyList()) }
    var onlineBusy by remember { mutableStateOf(false) }
    LaunchedEffect(q) {
        online = emptyList()
        if (q.length < 3) return@LaunchedEffect
        delay(650)
        onlineBusy = true
        online = try { OpenCatalogEngine.searchAudioFast(q, 12) } catch (_: Exception) { emptyList() }
        onlineBusy = false
    }
    LaunchedEffect(q, songHits.size) { if (q.length >= 3 && songHits.isNotEmpty()) { delay(1500); saveRecent(context, q); recent = recents(context) } }

    val topArtists = remember(lib.songs, lib.playCounts) {
        lib.songs.groupBy { it.artist }.entries
            .sortedByDescending { e -> e.value.sumOf { lib.playCounts[it.id] ?: 0 } * 1000 + e.value.size }
            .map { it.key }.take(12)
    }

    RefBackground {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.weight(1f)) { ScreenTitle("Search") }
                    Icon(
                        Icons.Rounded.Tune, "Clear", tint = Color.White,
                        modifier = Modifier.size(24.dp).clickable { cat = -1; query = "" },
                    )
                }
            }
            item {
                RefSearchField(
                    value = query, onChange = { query = it }, placeholder = "Songs, artists, albums, lyrics words…",
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp), height = 52.dp, textSize = 16.sp,
                )
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    cats.forEachIndexed { i, c ->
                        val on = cat == i
                        NeonTile(
                            Modifier.weight(1f).height(78.dp).clickable { cat = if (on) -1 else i },
                            colors = if (on) listOf(Color.White, c.colors.last()) else c.colors,
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(c.icon, null, tint = if (on) Color(0xFF08080B) else Color.White, modifier = Modifier.size(26.dp))
                                Spacer(Modifier.height(4.dp))
                                Text(c.label, color = if (on) Color(0xFF08080B) else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            if (q.isEmpty()) {
                if (recent.isNotEmpty()) {
                    item { Spacer(Modifier.height(18.dp)); SectionTitle("Recent searches", "Clear") {
                        context.getSharedPreferences("texwave_ui", android.content.Context.MODE_PRIVATE).edit().remove("recent_searches").apply(); recent = emptyList()
                    } }
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(recent) { _, r -> Pill(r, Icons.Rounded.History) { query = r } }
                        }
                    }
                }
                item { Spacer(Modifier.height(14.dp)); SectionTitle("Trending Artists", null) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        itemsIndexed(topArtists) { i, name ->
                            Column(Modifier.width(76.dp).clickable { query = name }, horizontalAlignment = Alignment.CenterHorizontally) {
                                InitialsAvatar(
                                    name, Modifier.size(70.dp),
                                    ringColors = when (i % 4) {
                                        0 -> listOf(Ref.Violet, Ref.Purple)
                                        1 -> listOf(Ref.Blue, Ref.Cyan)
                                        2 -> listOf(Ref.Blue, Ref.Violet)
                                        else -> listOf(Ref.Cyan, Ref.Blue)
                                    },
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(name, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(10.dp)); SectionTitle("Recommended For You", null) }
                item { Spacer(Modifier.height(8.dp)) }
                val liked = lib.songs.filter { it.id in lib.liked }
                val byPlays = lib.songs.sortedByDescending { lib.playCounts[it.id] ?: 0 }.take(50)
                val recentSongs = lib.recents.mapNotNull { id -> lib.songs.firstOrNull { it.id == id } }
                val mixes = buildList<Triple<String, List<Song>, Int>> {
                    lib.playlists.forEach { p ->
                        add(Triple(p.name, p.songIds.mapNotNull { id -> lib.songs.firstOrNull { it.id == id } }, R.drawable.ref_pl_chill))
                    }
                    if (liked.isNotEmpty()) add(Triple("Liked Songs", liked, R.drawable.ref_pl_focus))
                    if (byPlays.isNotEmpty()) add(Triple("Most Played", byPlays, R.drawable.ref_pl_workout))
                    if (recentSongs.isNotEmpty()) add(Triple("Recently Played", recentSongs, R.drawable.ref_pl_chill))
                    if (lib.songs.isNotEmpty()) add(Triple("Shuffle Mix", lib.songs.shuffled(java.util.Random(42)).take(40), R.drawable.ref_pl_focus))
                }.take(6)
                itemsIndexed(mixes, key = { i, m -> "${i}_${m.first}" }) { i, m ->
                    val fb = intArrayOf(R.drawable.ref_pl_chill, R.drawable.ref_pl_focus, R.drawable.ref_pl_workout)[i % 3]
                    RefRow(
                        title = m.first, subtitle = "Playlist • ${m.second.size} songs",
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp),
                        onClick = { if (m.second.isNotEmpty()) onPlay(m.second, 0) },
                    ) { SongThumb(m.second.firstOrNull(), Modifier.size(62.dp), RoundedCornerShape(14.dp), fallback = fb) }
                }
            } else {
                if (suggestion != null) item {
                    Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                        Text("Did you mean ", color = Ref.Sub, fontSize = 14.sp)
                        Text(suggestion, color = Ref.Cyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { query = suggestion })
                        Text("?", color = Ref.Sub, fontSize = 14.sp)
                    }
                }
                // Top result
                val top = songHits.firstOrNull()
                if (top != null && (cat == -1 || cat == 1)) {
                    item {
                        val s = RoundedCornerShape(22.dp)
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp).clip(s)
                                .background(Brush.horizontalGradient(listOf(Color(0xFF1B1760), Color(0xFF1B1B1D))))
                                .border(1.2.dp, Brush.horizontalGradient(listOf(Ref.Violet, Ref.Cyan.copy(alpha = 0.6f))), s)
                                .clickable { saveRecent(context, q); onPlay(songHits, 0) }.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            SongThumb(top, Modifier.size(84.dp), RoundedCornerShape(16.dp), hiRes = 600)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("TOP RESULT", color = Ref.Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Text(top.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(top.artist, color = Ref.Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Box(Modifier.size(46.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Ref.Purple, Ref.Blue))), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                        }
                    }
                }
                if (artistHits.isNotEmpty() && (cat == -1 || cat == 0)) {
                    item { SectionTitle("Artists", null) }
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            itemsIndexed(artistHits) { _, name ->
                                Column(
                                    Modifier.width(80.dp).clickable {
                                        val l = lib.songs.filter { it.artist == name }; if (l.isNotEmpty()) { saveRecent(context, q); onPlay(l, 0) }
                                    },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    InitialsAvatar(name, Modifier.size(72.dp))
                                    Spacer(Modifier.height(6.dp))
                                    Text(name, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text("${lib.songs.count { it.artist == name }} songs", color = Ref.Muted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
                if (albumHits.isNotEmpty() && (cat == -1 || cat == 2)) {
                    item { SectionTitle("Albums", null) }
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            itemsIndexed(albumHits) { _, a ->
                                Column(
                                    Modifier.width(112.dp).clickable {
                                        val l = lib.songs.filter { it.albumId == a.albumId }.sortedBy { it.trackNumber }; if (l.isNotEmpty()) onPlay(l, 0)
                                    },
                                ) {
                                    SongThumb(a, Modifier.size(112.dp), RoundedCornerShape(18.dp), hiRes = 400)
                                    Text(a.album, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                                    Text(a.artist, color = Ref.Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
                if (playlistHits.isNotEmpty() && (cat == -1 || cat == 3)) {
                    item { SectionTitle("Playlists", null) }
                    itemsIndexed(playlistHits, key = { _, p -> "pl" + p.id }) { _, p ->
                        val first = lib.songs.firstOrNull { it.id == p.songIds.firstOrNull() }
                        RefRow(
                            title = p.name, subtitle = "Playlist • ${p.songIds.size} songs",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp),
                            onClick = { onOpenPlaylistId(p.id) },
                        ) { SongThumb(first, Modifier.size(62.dp), RoundedCornerShape(14.dp)) }
                    }
                }
                if (songHits.isNotEmpty() && (cat == -1 || cat == 1)) {
                    item { Spacer(Modifier.height(6.dp)); SectionTitle("Songs · ${songHits.size}", null) }
                    itemsIndexed(songHits, key = { _, s -> s.id }) { i, s ->
                        RefRow(
                            title = s.title, subtitle = s.artist + if (s.album.isNotBlank()) " · " + s.album else "",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp),
                            onChevron = { onMore(s) },
                            onClick = { saveRecent(context, q); onPlay(songHits, i) },
                        ) { SongThumb(s, Modifier.size(62.dp), RoundedCornerShape(14.dp)) }
                    }
                }
                if (noLocal) item {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Nothing on your phone for “$q”", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                        Text("Check the spelling, or try fewer words. Free online matches are below.", color = Ref.Sub, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                // Online
                if (online.isNotEmpty() || onlineBusy) {
                    item { Spacer(Modifier.height(10.dp)); SectionTitle("Free online", "Discover") { onOpenDiscover() } }
                    if (onlineBusy && online.isEmpty()) item { Text("Searching the free catalog…", color = Ref.Sub, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 22.dp, vertical = 8.dp)) }
                    itemsIndexed(online, key = { _, a -> "on_" + a.id }) { _, a ->
                        RefRow(
                            title = a.title, subtitle = a.artist + " · stream",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp),
                            onClick = { onStreamOnline(a.url, a.title, a.artist) },
                        ) {
                            Box(Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF242426)), contentAlignment = Alignment.Center) {
                                coil.compose.AsyncImage("https://archive.org/services/img/${a.id}", null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                Icon(Icons.Rounded.CloudDownload, null, tint = Color.White.copy(alpha = 0.0f), modifier = Modifier.size(1.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Pill(label: String, icon: ImageVector, onClick: () -> Unit) {
    val s = RoundedCornerShape(20.dp)
    Row(
        Modifier.clip(s).background(Color(0xFF1B1B1D)).border(1.dp, Ref.Line, s).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Ref.Sub, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color(0xFFDCE5FF), fontSize = 13.sp, maxLines = 1)
    }
}
