package com.texgen.music.texwave.sonara.data.xp

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.xpStore by preferencesDataStore("sonara_xp")

/**
 * Optional XP / achievements module — isolated from the music engine.
 * Prevents trivial farming by rate-limiting stream XP grants.
 */
class XpStore(private val context: Context) {

    private val xpKey = intPreferencesKey("xp")
    private val achievementsKey = stringSetPreferencesKey("achievements")
    private val lastStreamXpDayKey = intPreferencesKey("last_stream_xp_day")
    private val streamsTodayKey = intPreferencesKey("streams_today")

    val xp: Flow<Int> = context.xpStore.data.map { it[xpKey] ?: 0 }
    val achievements: Flow<Set<String>> = context.xpStore.data.map { it[achievementsKey] ?: emptySet() }

    fun levelFor(xp: Int): Int = (xp / 100) + 1
    fun rankFor(level: Int): String = when {
        level >= 50 -> "Legend"
        level >= 30 -> "Virtuoso"
        level >= 15 -> "Headliner"
        level >= 5 -> "Regular"
        else -> "Listener"
    }

    /** Grant XP for a completed stream segment; max 5 grants per calendar day. */
    suspend fun onStreamProgress(significant: Boolean = true) {
        if (!significant) return
        val day = (System.currentTimeMillis() / 86_400_000L).toInt()
        context.xpStore.edit { prefs ->
            val lastDay = prefs[lastStreamXpDayKey] ?: -1
            var count = prefs[streamsTodayKey] ?: 0
            if (lastDay != day) {
                count = 0
                prefs[lastStreamXpDayKey] = day
            }
            if (count >= 5) return@edit
            prefs[streamsTodayKey] = count + 1
            prefs[xpKey] = (prefs[xpKey] ?: 0) + 10
        }
    }

    suspend fun unlock(achievementId: String) {
        context.xpStore.edit { prefs ->
            val set = prefs[achievementsKey]?.toMutableSet() ?: mutableSetOf()
            set.add(achievementId)
            prefs[achievementsKey] = set
        }
    }

    suspend fun onFirstLike() = unlock("first_like")
    suspend fun onPlaylistCreated() = unlock("first_playlist")
}
