package com.texgen.music.texwave.data

import android.content.Context
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.SupabaseConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * SYNTRA gateway client: AUVYRR app -> SYNTRA (Supabase Edge Function) -> Groq.
 * The provider key lives only on the server. The app sends the signed-in user's Supabase JWT.
 * Nothing here ever asks the user for a key.
 */
class SyntraClient(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("auvyrr_syntra", Context.MODE_PRIVATE)

    private fun installationId(): String =
        prefs.getString("install_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("install_id", it).apply()
        }

    /** Plain text answer, or a failure whose message is safe to show the user. */
    suspend fun chat(
        messages: List<Pair<String, String>>,
        temperature: Double = 0.6,
        maxTokens: Int = 1024,
    ): Result<String> = withContext(Dispatchers.IO) {
        if (!NetworkGate.isOnline(app)) return@withContext Result.failure(IllegalStateException("No internet connection"))
        val token = runCatching { ChatRepository.get(app).accessToken() }.getOrNull()
        if (token.isNullOrBlank()) {
            return@withContext Result.failure(IllegalStateException("Sign in to AUVYRR to use online assistant features"))
        }
        try {
            val arr = JSONArray()
            messages.forEach { (r, c) -> if (c.isNotBlank()) arr.put(JSONObject().put("role", r).put("content", c)) }
            val body = JSONObject()
                .put("provider", "groq")
                .put("temperature", temperature)
                .put("max_tokens", maxTokens)
                .put("request_id", UUID.randomUUID().toString())
                .put("messages", arr)
            val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("apikey", SupabaseConfig.SUPABASE_ANON_KEY)
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-auvyrr-app-id", APP_KEY)
                setRequestProperty("x-installation-id", installationId())
                setRequestProperty("x-platform", "android")
                doOutput = true
                connectTimeout = 15_000
                readTimeout = 45_000
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() }.orEmpty()
            if (code in 200..299) {
                val content = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").optString("content", "")
                if (content.isBlank()) Result.failure(IllegalStateException("Empty answer from the assistant"))
                else Result.success(content)
            } else {
                val err = runCatching { JSONObject(text).optJSONObject("error") }.getOrNull()
                val c = err?.optString("code").orEmpty()
                Result.failure(IllegalStateException(friendly(code, c, err?.optInt("retry_after_seconds") ?: 0)))
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Assistant is unreachable right now"))
        }
    }

    private fun friendly(http: Int, code: String, retry: Int): String = when {
        http == 401 || code == "UNAUTHORIZED" -> "Please sign in again to use online assistant features"
        http == 403 || code == "FORBIDDEN" -> "This account can't use the online assistant"
        http == 429 || code == "RATE_LIMITED" -> "Too many requests. Try again" + if (retry > 0) " in ${retry}s" else " in a minute"
        http == 503 -> "The assistant is busy. Try again shortly"
        else -> "The assistant had a problem ($http). Try again shortly"
    }

    companion object {
        const val APP_KEY = "auvyrr-android-v1"
        val ENDPOINT: String get() = SupabaseConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/ai-router"
    }
}
