package com.texgen.music.texwave.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.TravelExplore
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Session-limited settings wheel — Chat + Library only.
 * Settings / tools only, not primary destinations.
 */
enum class WheelAction {
    UniverseLab,
    AppSettings,
    Profile,
    Equalizer,
    MusicEditor,
    Theme,
    Notifications,
    RescanLibrary,
    UiSounds,
    PhantomKey,
    PhantomCode,
    PhantomImage,
    Constellation,
    Alarms,
    Chat,
}

data class WheelItem(
    val action: WheelAction,
    val label: String,
    val icon: ImageVector,
)

val LibrarySettingsItems = listOf(
    WheelItem(WheelAction.UniverseLab, "Universe", Icons.Rounded.TravelExplore),
    WheelItem(WheelAction.Equalizer, "Equalizer", Icons.Rounded.Equalizer),
    WheelItem(WheelAction.MusicEditor, "Editor", Icons.Rounded.Tune),
    WheelItem(WheelAction.RescanLibrary, "Rescan", Icons.Rounded.Refresh),
    WheelItem(WheelAction.Theme, "Theme", Icons.Rounded.Palette),
    WheelItem(WheelAction.UiSounds, "Sounds", Icons.Rounded.VolumeUp),
    WheelItem(WheelAction.Alarms, "Alarms", Icons.Rounded.Notifications),
    WheelItem(WheelAction.Chat, "Chat", Icons.Rounded.Person),
    WheelItem(WheelAction.AppSettings, "Settings", Icons.Rounded.Settings),
    WheelItem(WheelAction.Profile, "Profile", Icons.Rounded.Person),
    WheelItem(WheelAction.Constellation, "Stars", Icons.Rounded.AutoAwesome),
)

val ChatSettingsItems = listOf(
    WheelItem(WheelAction.AppSettings, "Settings", Icons.Rounded.Settings),
    WheelItem(WheelAction.Profile, "Profile", Icons.Rounded.Person),
    WheelItem(WheelAction.Notifications, "Alerts", Icons.Rounded.Notifications),
    WheelItem(WheelAction.Theme, "Theme", Icons.Rounded.Palette),
    WheelItem(WheelAction.Alarms, "Alarms", Icons.Rounded.Notifications),
    WheelItem(WheelAction.PhantomKey, "API Key", Icons.Rounded.Key),
    WheelItem(WheelAction.PhantomCode, "Code", Icons.Rounded.Code),
    WheelItem(WheelAction.PhantomImage, "Images", Icons.Rounded.Image),
    WheelItem(WheelAction.UiSounds, "Sounds", Icons.Rounded.VolumeUp),
)

@Composable
fun ActionWheelOverlay(
    visible: Boolean,
    items: List<WheelItem>,
    title: String = "SETTINGS",
    onDismiss: () -> Unit,
    onSelect: (WheelAction) -> Unit,
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + scaleIn(initialScale = 0.94f),
        exit = fadeOut() + scaleOut(targetScale = 0.96f),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xCC0D0D0F))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss,
                )
                .statusBarsPadding()
        ) {
            Column(
                Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight(0.85f)
                    .width(96.dp)
                    .padding(end = 10.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xF21E1E20), Color(0xF2121214), Color(0xF21E1E20))
                        )
                    )
                    .border(
                        1.dp,
                        Brush.verticalGradient(
                            listOf(TexTokens.Cyan.copy(alpha = 0.5f), TexTokens.Violet.copy(alpha = 0.4f), TexTokens.Magenta.copy(alpha = 0.3f))
                        ),
                        RoundedCornerShape(28.dp),
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { },
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    title,
                    color = TexTokens.Cyan,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.padding(top = 14.dp, bottom = 2.dp),
                )
                Text(
                    "SLIDE",
                    color = TexTokens.TextSecondary,
                    fontSize = 8.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
                val listState = rememberLazyListState()
                var focused by remember { mutableIntStateOf(0) }
                val scope = rememberCoroutineScope()

                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .pointerInput(items.size) {
                            detectVerticalDragGestures { _, dragAmount ->
                                if (abs(dragAmount) > 8f) {
                                    val next = if (dragAmount < 0) {
                                        (focused + 1).coerceAtMost(items.lastIndex)
                                    } else {
                                        (focused - 1).coerceAtLeast(0)
                                    }
                                    if (next != focused) {
                                        focused = next
                                        scope.launch { listState.animateScrollToItem(next) }
                                    }
                                }
                            }
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp),
                ) {
                    itemsIndexed(items) { index, item ->
                        val selected = index == focused
                        val scale = if (selected) 1.1f else 0.9f
                        val alpha = if (selected) 1f else 0.5f
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .graphicsLayer { scaleX = scale; scaleY = scale; this.alpha = alpha }
                                .clickable {
                                    focused = index
                                    onSelect(item.action)
                                }
                                .padding(vertical = 6.dp, horizontal = 4.dp),
                        ) {
                            Box(
                                Modifier
                                    .size(if (selected) 46.dp else 38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (selected) TexTokens.Violet.copy(alpha = 0.35f)
                                        else Color(0x22FFFFFF)
                                    )
                                    .border(
                                        1.dp,
                                        if (selected) TexTokens.Cyan else Color(0x33FFFFFF),
                                        CircleShape,
                                    ),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    item.icon,
                                    contentDescription = item.label,
                                    tint = if (selected) TexTokens.Cyan else Color.White,
                                    modifier = Modifier.size(20.dp),
                                )
                            }
                            Spacer(Modifier.height(3.dp))
                            Text(
                                item.label,
                                color = if (selected) TexTokens.TextPrimary else TexTokens.TextSecondary,
                                fontSize = 9.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            )
                        }
                    }
                }
                Box(
                    Modifier
                        .padding(bottom = 12.dp)
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0x33FFFFFF))
                        .clickable(onClick = onDismiss),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.Close, null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun ActionWheelHandle(
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier
            .width(20.dp)
            .height(52.dp)
            .clip(RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp))
            .background(
                Brush.verticalGradient(
                    listOf(TexTokens.Violet.copy(alpha = 0.75f), TexTokens.Cyan.copy(alpha = 0.55f))
                )
            )
            .clickable(onClick = onOpen),
        contentAlignment = Alignment.Center,
    ) {
        Text("⚙", color = Color.White, fontSize = 12.sp)
    }
}
