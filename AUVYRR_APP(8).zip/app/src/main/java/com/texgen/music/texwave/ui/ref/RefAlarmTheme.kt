package com.texgen.music.texwave.ui.ref

import com.texgen.music.texwave.ui.theme.Tx
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import com.texgen.music.texwave.R
import java.io.File

/** Built-in alarm pictures. Key format: "preset:<id>" or an absolute file path for a gallery picture. */
data class AlarmPreset(val id: String, val label: String, @DrawableRes val res: Int)

val AlarmPresets = listOf(
    AlarmPreset("aurora", "Aurora", R.drawable.ref_splash_orb),
    AlarmPreset("city", "Neon City", R.drawable.ref_feed_img),
    AlarmPreset("sunset", "Rooftop", R.drawable.ref_reel_bg),
    AlarmPreset("wave", "Lost Wave", R.drawable.ref_np_art),
    AlarmPreset("portal", "Portal", R.drawable.ref_hero),
    AlarmPreset("phantom", "Phantom", R.drawable.ref_phantom_orb),
)

const val DefaultAlarmTheme = "preset:aurora"

fun alarmPresetFor(key: String?): AlarmPreset? =
    AlarmPresets.firstOrNull { "preset:" + it.id == key }

/** Full-bleed alarm picture with a dark scrim, used by the ring screen and the editor preview. */
@Composable
fun AlarmBackdrop(themeKey: String?, modifier: Modifier = Modifier.fillMaxSize(), scrim: Float = 0.55f) {
    val preset = alarmPresetFor(themeKey)
    Box(modifier) {
        when {
            preset != null -> Image(
                painterResource(preset.res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
            )
            !themeKey.isNullOrBlank() && themeKey.startsWith("/") -> AsyncImage(
                model = File(themeKey), contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
            else -> Image(
                painterResource(AlarmPresets.first().res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Tx.Bg.copy(alpha = scrim * 0.7f), Tx.Bg.copy(alpha = scrim), Tx.Bg.copy(alpha = 0.92f)),
                ),
            ),
        )
    }
}
