package com.texgen.music.texwave.sonara.data.remote

import com.texgen.music.texwave.data.chat.SupabaseConfig
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage

/**
 * Sonara's optional online catalogue backend.
 *
 * OFF by default: the music library comes from the bundled legal (CC / public-domain) seed + demo catalogue
 * and works with no server. To turn it on, apply the SQL migrations in backend/sonara/supabase/migrations to the Supabase
 * project and set [BACKEND_ENABLED] to true. It reuses AUVYRR's Supabase URL and public anon key.
 */
object SupabaseProvider {
    const val BACKEND_ENABLED = false

    val isConfigured: Boolean get() = BACKEND_ENABLED

    val client: SupabaseClient? by lazy {
        if (!BACKEND_ENABLED) return@lazy null
        createSupabaseClient(
            supabaseUrl = SupabaseConfig.SUPABASE_URL,
            supabaseKey = SupabaseConfig.SUPABASE_ANON_KEY,
        ) {
            install(Auth)
            install(Postgrest)
            install(Storage)
        }
    }
}
