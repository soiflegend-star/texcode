package com.texgen.music.texwave

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Catches any fatal crash, saves the stack trace to a file, and lets the next launch show it
 * (instead of the app silently closing again). After two crashes in a row the app starts in
 * SAFE MODE: no session restore, no background service, default notification.
 */
object CrashGuard {
    private const val FILE = "last_crash.txt"
    private const val PREFS = "texwave_crash_guard"

    /** True for this process when the previous launches crashed. */
    @Volatile var safeMode: Boolean = false

    fun install(app: Context) {
        val appCtx = app.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                File(appCtx.filesDir, FILE).writeText(
                    "AUVYRR crash report\n$stamp\nthread: ${thread.name}\n" +
                        "device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} · Android ${android.os.Build.VERSION.SDK_INT}\n\n$sw"
                )
                val p = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                p.edit().putInt("count", p.getInt("count", 0) + 1).commit()
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
        val p = appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        safeMode = p.getInt("count", 0) >= 1
    }

    /** Call once the UI has been up for a few seconds without crashing. */
    fun scheduleStable(app: Context) {
        val appCtx = app.applicationContext
        Handler(Looper.getMainLooper()).postDelayed({
            appCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("count", 0).apply()
            safeMode = false
        }, 8_000)
    }

    fun pendingReport(app: Context): String? = try {
        val f = File(app.filesDir, FILE)
        if (f.exists()) f.readText().take(12_000) else null
    } catch (_: Throwable) {
        null
    }

    fun clearReport(app: Context) {
        try { File(app.filesDir, FILE).delete() } catch (_: Throwable) {}
    }

    fun nonFatal(tag: String, t: Throwable) {
        Log.e("AUVYRR", "$tag: ${t.message}", t)
    }

    /** Wipes saved state that could keep crashing the app (session, notification extras). */
    fun resetRiskyState(app: Context) {
        val c = app.applicationContext
        try {
            c.getSharedPreferences("texwave_library", Context.MODE_PRIVATE).edit()
                .remove("session_id").remove("session_pos").remove("session_queue").remove("session_index").commit()
            c.getSharedPreferences("texwave_settings", Context.MODE_PRIVATE).edit()
                .putString("notif_style", "default").remove("notif_uri").putInt("notif_video_frames", 0)
                .putBoolean("wake_on", false).putBoolean("snow_overlay", false).commit()
        } catch (_: Throwable) {}
    }

    fun resetEverything(app: Context) {
        val c = app.applicationContext
        try {
            listOf("texwave_library", "texwave_settings", "texwave_phantom", "texwave_groq", PREFS).forEach {
                c.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit()
            }
            File(c.filesDir, "art").deleteRecursively()
            File(c.filesDir, "notif_video").deleteRecursively()
        } catch (_: Throwable) {}
    }
}
