package com.texgen.music.texwave.data.catalog

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Real catalog engine for open-license audio/video from Internet Archive.
 */
object OpenCatalogEngine {

    data class AudioItem(
        val id: String,
        val title: String,
        val artist: String,
        val fileName: String,
        val url: String,
        val license: String,
        val bytesHint: Long = 0L,
    )

    data class QualityOption(val label: String, val url: String, val height: Int = 0)

    data class VideoItem(
        val id: String,
        val title: String,
        val creator: String,
        val url: String,
        val license: String,
        val bytesHint: Long = 0L,
        val qualities: List<QualityOption> = emptyList(),
    ) {
        fun urlForQuality(label: String): String {
            if (label.equals("Auto", true)) return url
            return qualities.firstOrNull { it.label.equals(label, true) }?.url
                ?: qualities.maxByOrNull { it.height }?.url
                ?: url
        }
    }

    data class DownloadResult(
        val ok: Boolean,
        val path: String?,
        val downloadId: Long = -1L,
        val error: String? = null,
    )

    data class Shelf(val id: String, val title: String, val query: String)

    private val probeCache = ConcurrentHashMap<String, Boolean>()
    private val ioMutex = Mutex()

    val streamShelves: List<Shelf> = listOf(
        Shelf("focus", "Focus", "study focus concentration music"),
        Shelf("lofi", "Lo-Fi Beats", "lofi hip hop beats chill"),
        Shelf("jazz", "Jazz", "jazz instrumental classic"),
        Shelf("electronic", "Electronic", "electronic ambient synthesizer"),
        Shelf("classical", "Classical", "classical orchestra symphony"),
        Shelf("world", "World", "world music folk acoustic"),
        Shelf("sleep", "Sleep", "sleep ambient relaxation"),
        Shelf("guitar", "Guitar", "acoustic guitar instrumental"),
        Shelf("pop", "Pop", "pop hits upbeat"),
        Shelf("rock", "Rock", "rock guitar band"),
    )

    private fun httpJson(url: String, timeoutMs: Int = 10_000): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "AUVYRR/7.3 CatalogEngine")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (body.isBlank()) JSONObject() else JSONObject(body)
        } finally {
            c.disconnect()
        }
    }

    /** Fast reachability check. Fail-open on network errors so search still returns items. */
    fun probeUrl(url: String, minBytes: Long = 4_000L): Boolean {
        probeCache[url]?.let { return it }
        val ok = try {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 3_500
                readTimeout = 3_500
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "AUVYRR/7.3")
            }
            try {
                val code = c.responseCode
                val len = c.contentLengthLong
                // Many IA hosts omit Content-Length on HEAD — treat unknown length as OK
                code in 200..399 && (len <= 0 || len >= minBytes)
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            true // fail-open: keep the item; download will validate later
        }
        probeCache[url] = ok
        return ok
    }

    private fun licenseOk(license: String): Boolean {
        val l = license.lowercase()
        if (l.isBlank()) return true
        return listOf("publicdomain", "creative commons", "cc0", "cc-by", "cc by", "attribution").any { l.contains(it) } ||
            !listOf("all rights reserved", "copyrighted").any { l.contains(it) }
    }

    private fun encodePath(name: String): String =
        name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun resolveAudio(id: String): AudioItem? {
        val meta = httpJson("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}", 6_000)
        val metadata = meta.optJSONObject("metadata") ?: return null
        val license = metadata.optString("licenseurl", metadata.optString("license_url", ""))
        if (!licenseOk(license)) return null
        val files = meta.optJSONArray("files") ?: return null
        data class Cand(val name: String, val size: Long)
        val cands = mutableListOf<Cand>()
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name")
            if (name.contains("../")) continue
            val lower = name.lowercase()
            val okExt = lower.endsWith(".mp3") || lower.endsWith(".ogg") || lower.endsWith(".m4a") || lower.endsWith(".flac")
            if (!okExt) continue
            val size = f.optString("size").toLongOrNull() ?: Long.MAX_VALUE
            cands += Cand(name, size)
        }
        val pick = cands
            .sortedWith(
                compareBy<Cand> { c ->
                    when {
                        c.size in 500_000L..40_000_000L -> 0
                        c.size < 500_000L -> 1
                        else -> 2
                    }
                }.thenBy { it.size },
            )
            .firstOrNull() ?: return null
        val url = "https://archive.org/download/${URLEncoder.encode(id, "UTF-8")}/${encodePath(pick.name)}"
        return AudioItem(
            id = id,
            title = metadata.optString("title", id),
            artist = metadata.optString("creator", "Artist"),
            fileName = pick.name.substringAfterLast('/'),
            url = url,
            license = license,
            bytesHint = pick.size,
        )
    }

    private fun resolveVideo(id: String): VideoItem? {
        val meta = httpJson("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}", 5_000)
        val metadata = meta.optJSONObject("metadata") ?: return null
        val license = metadata.optString("licenseurl", metadata.optString("license_url", ""))
        if (!licenseOk(license)) return null
        val files = meta.optJSONArray("files") ?: return null
        data class Cand(val name: String, val size: Long, val height: Int)
        val cands = mutableListOf<Cand>()
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name")
            if (name.contains("../")) continue
            val okExt = name.endsWith(".mp4", true) || name.endsWith(".webm", true)
            if (!okExt) continue
            val size = f.optString("size").toLongOrNull() ?: Long.MAX_VALUE
            val lower = name.lowercase()
            val height = when {
                "1080" in lower || "1920" in lower -> 1080
                "720" in lower || "1280" in lower -> 720
                "480" in lower || "854" in lower -> 480
                "360" in lower || "640" in lower -> 360
                "240" in lower -> 240
                else -> when {
                    size > 80_000_000L -> 1080
                    size > 35_000_000L -> 720
                    size > 12_000_000L -> 480
                    size > 4_000_000L -> 360
                    else -> 240
                }
            }
            cands += Cand(name, size, height)
        }
        if (cands.isEmpty()) return null
        val pick = cands.sortedWith(
            compareBy<Cand> { c ->
                when {
                    c.height in 480..720 -> 0
                    c.height == 360 -> 1
                    c.height == 1080 -> 2
                    else -> 3
                }
            }.thenBy { it.size },
        ).first()
        val base = "https://archive.org/download/${URLEncoder.encode(id, "UTF-8")}/"
        val qualities = cands
            .groupBy { it.height }
            .map { (h, list) ->
                val best = list.minByOrNull { it.size } ?: list.first()
                QualityOption(
                    label = when (h) {
                        1080 -> "1080p"
                        720 -> "720p"
                        480 -> "480p"
                        360 -> "360p"
                        else -> "${h}p"
                    },
                    url = base + encodePath(best.name),
                    height = h,
                )
            }
            .sortedByDescending { it.height }
        return VideoItem(
            id = id,
            title = metadata.optString("title", id),
            creator = metadata.optString("creator", "Creator"),
            url = base + encodePath(pick.name),
            license = license,
            bytesHint = pick.size,
            qualities = qualities,
        )
    }


    /** Score how well title/artist match the user query (higher = better). */
    private fun relevanceScore(query: String, title: String, artist: String): Int {
        val terms = query.lowercase().split(Regex("\\s+")).filter { it.length >= 2 }
        if (terms.isEmpty()) return 0
        val t = title.lowercase()
        val a = artist.lowercase()
        var score = 0
        for (term in terms) {
            when {
                t == term || a == term -> score += 40
                t.startsWith(term) || a.startsWith(term) -> score += 25
                t.contains(term) -> score += 15
                a.contains(term) -> score += 12
            }
        }
        // Prefer track-like titles over long lectures/document dumps
        if (title.length in 3..80) score += 5
        if (title.length > 120) score -= 8
        return score
    }

    /**
     * Fast multi-source search: races several Archive query shapes in parallel and merges
     * by relevance. Designed for the Discover / download screens.
     */
    suspend fun searchAudioFast(query: String, limit: Int = 24): List<AudioItem> = withContext(Dispatchers.IO) {
        val raw = query.trim().ifBlank { "music" }
        coroutineScope {
            val jobs = listOf(
                async { runCatching { searchAudio(raw, limit) }.getOrDefault(emptyList()) },
                async { runCatching { searchAudio("$raw song", (limit / 2).coerceAtLeast(8)) }.getOrDefault(emptyList()) },
                async { runCatching { searchAudio("$raw music", (limit / 2).coerceAtLeast(8)) }.getOrDefault(emptyList()) },
            )
            val merged = linkedMapOf<String, AudioItem>()
            for (list in jobs.awaitAll()) {
                for (item in list) merged.putIfAbsent(item.id, item)
            }
            merged.values
                .sortedByDescending { relevanceScore(raw, it.title, it.artist) }
                .take(limit)
        }
    }

    /**
     * Fast multi-source reels/video search: several query variants in parallel.
     */
    suspend fun searchVideoFast(query: String, limit: Int = 12): List<VideoItem> = withContext(Dispatchers.IO) {
        val raw = query.trim().ifBlank { "short film animation" }
        coroutineScope {
            val variants = listOf(raw, "$raw short", "$raw reel", "$raw music video")
            val jobs = variants.map { q ->
                async { runCatching { searchVideo(q, (limit / 2).coerceAtLeast(6)) }.getOrDefault(emptyList()) }
            }
            val merged = linkedMapOf<String, VideoItem>()
            for (list in jobs.awaitAll()) {
                for (item in list) merged.putIfAbsent(item.id, item)
            }
            merged.values.take(limit)
        }
    }

    suspend fun searchAudio(query: String, limit: Int = 20): List<AudioItem> = withContext(Dispatchers.IO) {
        val raw = query.trim().ifBlank { "music" }
        // Bias Archive.org toward title/creator matches so results feel like a real music search
        val qCore = "($raw) AND mediatype:(audio) AND format:(VBR MP3 OR MP3 OR Ogg Vorbis OR Flac OR AAC)"
        val encoded = URLEncoder.encode(qCore, "UTF-8")
        val url =
            "https://archive.org/advancedsearch.php?q=$encoded&fl[]=identifier&fl[]=title&fl[]=creator&sort[]=downloads+desc&rows=${(limit * 4).coerceAtMost(80)}&page=1&output=json"
        var docs = runCatching { httpJson(url, 7_000) }.getOrElse { JSONObject() }
            .optJSONObject("response")?.optJSONArray("docs")
        if (docs == null || docs.length() == 0) {
            val fallback = URLEncoder.encode("($raw) AND mediatype:(audio)", "UTF-8")
            docs = runCatching {
                httpJson(
                    "https://archive.org/advancedsearch.php?q=$fallback&fl[]=identifier&fl[]=title&fl[]=creator&sort[]=downloads+desc&rows=${(limit * 4).coerceAtMost(80)}&page=1&output=json",
                    7_000,
                )
            }.getOrElse { JSONObject() }.optJSONObject("response")?.optJSONArray("docs")
                ?: return@withContext emptyList()
        }
        // Rank docs by title/creator relevance before resolving files (cheap, keeps results on-topic)
        val ranked = (0 until docs.length()).mapNotNull { i ->
            val o = docs.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("identifier").ifBlank { return@mapNotNull null }
            val title = o.optString("title").ifBlank { id }
            val creator = when (val c = o.opt("creator")) {
                is String -> c
                is org.json.JSONArray -> (0 until c.length()).mapNotNull { c.optString(it) }.firstOrNull().orEmpty()
                else -> ""
            }
            Triple(id, title, creator) to relevanceScore(raw, title, creator)
        }.sortedByDescending { it.second }.map { it.first }

        resolveAudioBatch(ranked, limit, raw)
    }

    private suspend fun resolveAudioBatch(
        ranked: List<Triple<String, String, String>>,
        limit: Int,
        query: String,
    ): List<AudioItem> {
        // Resolve only the top candidates in parallel — skip network probe for speed
        return coroutineScope {
            ranked.take(limit * 2).map { (id, _, _) ->
                async {
                    runCatching { resolveAudio(id) }.getOrNull()
                }
            }.awaitAll().filterNotNull()
                .distinctBy { it.id }
                .sortedByDescending { relevanceScore(query, it.title, it.artist) }
                .take(limit)
        }
    }

    private suspend fun resolveAudioBatch(docs: org.json.JSONArray, limit: Int): List<AudioItem> {
        val ids = (0 until docs.length()).mapNotNull { docs.optJSONObject(it)?.optString("identifier") }.filter { it.isNotBlank() }
        return resolveAudioBatch(ids.map { Triple(it, it, "") }, limit, "")
    }

    suspend fun searchVideo(query: String, limit: Int = 12): List<VideoItem> = withContext(Dispatchers.IO) {
        val q = query.trim().ifBlank { "short film animation" }
        // Prefer short-form friendly formats; rank by downloads for speed of popular hits
        val encoded = URLEncoder.encode(
            "($q) AND mediatype:(movies) AND format:(MPEG4 OR h.264 OR 512Kb MPEG4 OR h.264 IA)",
            "UTF-8",
        )
        val url =
            "https://archive.org/advancedsearch.php?q=$encoded&fl[]=identifier&fl[]=title&fl[]=creator&sort[]=downloads+desc&rows=${(limit * 3).coerceAtMost(36)}&page=1&output=json"
        var docs = runCatching { httpJson(url, 6_000) }.getOrElse { JSONObject() }
            .optJSONObject("response")?.optJSONArray("docs")
        if (docs == null || docs.length() == 0) {
            val fallback = URLEncoder.encode("($q) AND mediatype:(movies)", "UTF-8")
            docs = runCatching {
                httpJson(
                    "https://archive.org/advancedsearch.php?q=$fallback&fl[]=identifier&fl[]=title&fl[]=creator&sort[]=downloads+desc&rows=${(limit * 3).coerceAtMost(36)}&page=1&output=json",
                    6_000,
                )
            }.getOrElse { JSONObject() }.optJSONObject("response")?.optJSONArray("docs")
                ?: return@withContext emptyList()
        }
        val ranked = (0 until docs.length()).mapNotNull { i ->
            val o = docs.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("identifier").ifBlank { return@mapNotNull null }
            val title = o.optString("title").ifBlank { id }
            Triple(id, title, "") to relevanceScore(q, title, "")
        }.sortedByDescending { it.second }.map { it.first.first }

        coroutineScope {
            ranked.take(limit * 2).map { id ->
                async { runCatching { resolveVideo(id) }.getOrNull() }
            }.awaitAll().filterNotNull().distinctBy { it.id }.take(limit)
        }
    }

    suspend fun loadShelf(shelf: Shelf, limit: Int = 12): List<AudioItem> =
        searchAudio(shelf.query, limit = limit)

    suspend fun loadHomeShelves(perShelf: Int = 10): List<Pair<Shelf, List<AudioItem>>> = coroutineScope {
        streamShelves.map { shelf ->
            async {
                shelf to runCatching { loadShelf(shelf, perShelf) }.getOrDefault(emptyList())
            }
        }.awaitAll().filter { it.second.isNotEmpty() }
    }

    fun queryDmStatus(context: Context, id: Long): String {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val q = DownloadManager.Query().setFilterById(id)
        dm.query(q)?.use { c ->
            if (!c.moveToFirst()) return "UNKNOWN"
            val col = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            return when (if (col >= 0) c.getInt(col) else -1) {
                DownloadManager.STATUS_SUCCESSFUL -> "READY"
                DownloadManager.STATUS_FAILED -> "FAILED"
                DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PENDING, DownloadManager.STATUS_PAUSED -> "RUNNING"
                else -> "UNKNOWN"
            }
        }
        return "UNKNOWN"
    }

    fun resolveDmPath(context: Context, id: Long): String? {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val q = DownloadManager.Query().setFilterById(id)
        dm.query(q)?.use { c ->
            if (!c.moveToFirst()) return null
            val idx = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
            if (idx < 0) return null
            val uri = Uri.parse(c.getString(idx) ?: return null)
            if (uri.scheme == "file") return uri.path
            return uri.toString()
        }
        return null
    }

    suspend fun downloadAudio(context: Context, item: AudioItem): DownloadResult = withContext(Dispatchers.IO) {
        if (!probeUrl(item.url, 8_000L)) {
            return@withContext DownloadResult(false, null, error = "Source URL unreachable")
        }
        try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val req = DownloadManager.Request(Uri.parse(item.url))
                .setTitle(item.title)
                .setDescription("${item.artist} · AUVYRR")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setMimeType("audio/mpeg")
            val fileName = item.fileName.ifBlank { "${item.id}.mp3" }.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            try {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "AUVYRR/$fileName")
            } catch (_: Exception) {
                req.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MUSIC, fileName)
            }
            val id = dm.enqueue(req)
            val deadline = System.currentTimeMillis() + 180_000L
            while (System.currentTimeMillis() < deadline) {
                when (queryDmStatus(context, id)) {
                    "READY" -> {
                        val path = resolveDmPath(context, id)
                        if (path != null) return@withContext DownloadResult(true, path, id)
                        break
                    }
                    "FAILED" -> break
                    else -> kotlinx.coroutines.delay(1000)
                }
            }
        } catch (_: Exception) {
        }
        ioMutex.withLock {
            try {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
                val out = File(dir, item.fileName.ifBlank { "${item.id}.mp3" }.replace(Regex("[^a-zA-Z0-9._-]"), "_"))
                val c = (URL(item.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "AUVYRR/7.2")
                }
                try {
                    if (c.responseCode !in 200..299) {
                        return@withContext DownloadResult(false, null, error = "HTTP ${c.responseCode}")
                    }
                    c.inputStream.use { input ->
                        FileOutputStream(out).use { output -> input.copyTo(output) }
                    }
                    if (out.length() < 8_000L) {
                        out.delete()
                        return@withContext DownloadResult(false, null, error = "File too small")
                    }
                    DownloadResult(true, out.absolutePath)
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                DownloadResult(false, null, error = e.message ?: "Download failed")
            }
        }
    }
}
