package com.texgen.music.texwave.sonara.data.download

import android.content.Context
import com.texgen.music.texwave.sonara.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

data class DownloadProgress(
    val trackId: String,
    val fraction: Float,
    val status: Status,
    val localPath: String? = null,
    val error: String? = null,
) {
    enum class Status { IDLE, RUNNING, DONE, FAILED, CANCELLED }
}

/**
 * Writes actual audio files under app-private storage for tracks
 * that are explicitly downloadable. Not a YouTube bypass.
 */
class OfflineDownloadManager(
    private val context: Context,
    private val downloadStore: DownloadStore,
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val _progress = MutableStateFlow<Map<String, DownloadProgress>>(emptyMap())
    val progress: StateFlow<Map<String, DownloadProgress>> = _progress.asStateFlow()

    private fun dir(): File = File(context.filesDir, "offline_audio").also { if (!it.exists()) it.mkdirs() }

    fun localFile(trackId: String): File? {
        val f = File(dir(), "$trackId.audio")
        return f.takeIf { it.exists() && it.length() > 0 }
    }

    suspend fun download(track: Track): DownloadProgress = withContext(Dispatchers.IO) {
        if (!track.isDownloadable) {
            return@withContext DownloadProgress(track.id, 0f, DownloadProgress.Status.FAILED, error = "Not authorised for offline")
        }
        val url = track.streamUrl ?: return@withContext DownloadProgress(track.id, 0f, DownloadProgress.Status.FAILED, error = "No stream URL")
        publish(track.id, 0f, DownloadProgress.Status.RUNNING)
        try {
            val req = Request.Builder().url(url).header("User-Agent", "Sonara/1.5").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val p = DownloadProgress(track.id, 0f, DownloadProgress.Status.FAILED, error = "HTTP ${resp.code}")
                    set(p)
                    return@withContext p
                }
                val body = resp.body ?: throw IllegalStateException("empty body")
                val total = body.contentLength()
                val out = File(dir(), "${track.id}.audio")
                val tmp = File(dir(), "${track.id}.part")
                body.byteStream().use { input ->
                    tmp.outputStream().use { output ->
                        val buf = ByteArray(16 * 1024)
                        var readTotal = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n <= 0) break
                            output.write(buf, 0, n)
                            readTotal += n
                            val frac = if (total > 0) (readTotal.toFloat() / total).coerceIn(0f, 1f) else 0f
                            publish(track.id, frac, DownloadProgress.Status.RUNNING)
                        }
                    }
                }
                if (out.exists()) out.delete()
                tmp.renameTo(out)
                downloadStore.requestDownload(track.id)
                val done = DownloadProgress(track.id, 1f, DownloadProgress.Status.DONE, localPath = out.absolutePath)
                set(done)
                done
            }
        } catch (e: Exception) {
            val p = DownloadProgress(track.id, 0f, DownloadProgress.Status.FAILED, error = e.message)
            set(p)
            p
        }
    }

    suspend fun delete(trackId: String) {
        localFile(trackId)?.delete()
        downloadStore.removeDownload(trackId)
        set(DownloadProgress(trackId, 0f, DownloadProgress.Status.IDLE))
    }

    private fun publish(id: String, frac: Float, status: DownloadProgress.Status) {
        set(DownloadProgress(id, frac, status))
    }

    private fun set(p: DownloadProgress) {
        _progress.value = _progress.value.toMutableMap().apply { put(p.trackId, p) }
    }
}
