package com.texgen.music.texwave.veltrix.engine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.texgen.music.texwave.veltrix.data.VeltrixStore
import com.texgen.music.texwave.veltrix.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.UUID
import java.util.concurrent.TimeUnit

class VeltrixEngine(
    private val context: Context,
    private val store: VeltrixStore
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val channelId = "veltrix_notifications"

    init {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "Veltrix", NotificationManager.IMPORTANCE_DEFAULT)
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    suspend fun run(automation: VxAutomation, trigger: String = "manual"): VxExecution =
        withContext(Dispatchers.Default) {
            val vars = automation.variables.toMutableMap()
            vars.putAll(deviceSnapshot())
            val logs = mutableListOf<VxLogLine>()
            fun log(level: String, msg: String, nodeId: String? = null) {
                logs += VxLogLine(level = level, message = msg, nodeId = nodeId)
            }

            var exec = VxExecution(
                automationId = automation.id,
                automationName = automation.name,
                status = VxRunStatus.RUNNING,
                trigger = trigger
            )
            store.saveExecution(exec)
            log("INFO", "Started ($trigger)")

            try {
                val start = automation.nodes.find { it.kind.name.startsWith("TRIGGER_") }
                    ?: automation.nodes.firstOrNull()
                    ?: throw IllegalStateException("No trigger node")

                val visited = mutableSetOf<String>()
                executeFrom(start, automation, vars, logs, visited, 0)

                val failed = logs.any { it.level == "ERROR" }
                exec = exec.copy(
                    status = if (failed) VxRunStatus.FAILED else VxRunStatus.SUCCESS,
                    finishedAt = System.currentTimeMillis(),
                    logs = logs.toList(),
                    vars = vars.toMap(),
                    error = logs.lastOrNull { it.level == "ERROR" }?.message
                )
            } catch (e: Exception) {
                log("ERROR", e.message ?: "Fatal")
                exec = exec.copy(
                    status = VxRunStatus.FAILED,
                    finishedAt = System.currentTimeMillis(),
                    logs = logs.toList(),
                    vars = vars.toMap(),
                    error = e.message
                )
            }

            store.saveExecution(exec)
            store.updateStats(automation.id, exec.status == VxRunStatus.SUCCESS)
            exec
        }

    private suspend fun executeFrom(
        node: VxNode,
        auto: VxAutomation,
        vars: MutableMap<String, String>,
        logs: MutableList<VxLogLine>,
        visited: MutableSet<String>,
        depth: Int
    ) {
        if (depth > 100 || node.id in visited) return
        visited += node.id
        logs += VxLogLine(level = "INFO", message = "→ ${node.title}", nodeId = node.id)

        val branch = runNode(node, vars, logs)

        val outgoing = auto.links.filter { it.fromId == node.id }
        val nextLinks = when {
            branch == null -> outgoing
            else -> outgoing.filter { it.label.equals(branch, true) }.ifEmpty {
                if (branch == "true") outgoing.take(1) else outgoing.drop(1).take(1).ifEmpty { outgoing }
            }
        }
        for (link in nextLinks) {
            val next = auto.nodes.find { it.id == link.toId } ?: continue
            executeFrom(next, auto, vars, logs, visited.toMutableSet(), depth + 1)
        }
    }

    /** Returns branch label for conditions, null otherwise. */
    private suspend fun runNode(
        node: VxNode,
        vars: MutableMap<String, String>,
        logs: MutableList<VxLogLine>
    ): String? {
        return try {
            when (node.kind) {
                VxNodeKind.TRIGGER_MANUAL, VxNodeKind.TRIGGER_TIME, VxNodeKind.TRIGGER_BOOT,
                VxNodeKind.TRIGGER_BATTERY, VxNodeKind.TRIGGER_CHARGING, VxNodeKind.TRIGGER_NETWORK -> null

                VxNodeKind.ACTION_NOTIFICATION -> {
                    val title = interp(node.c("title").ifBlank { "Veltrix" }, vars)
                    val body = interp(node.c("body"), vars)
                    notify(title, body)
                    logs += VxLogLine(level = "INFO", message = "Notification: $title", nodeId = node.id)
                    null
                }

                VxNodeKind.ACTION_DELAY -> {
                    val ms = interp(node.c("ms"), vars).toLongOrNull() ?: 1000L
                    delay(ms.coerceIn(0, 60_000))
                    null
                }

                VxNodeKind.ACTION_OPEN_URL -> {
                    val url = interp(node.c("url"), vars)
                    withContext(Dispatchers.Main) {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                    null
                }

                VxNodeKind.ACTION_OPEN_APP -> {
                    val pkg = interp(node.c("package"), vars)
                    withContext(Dispatchers.Main) {
                        runCatching {
                            context.packageManager.getLaunchIntentForPackage(pkg)?.let {
                                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(it)
                            }
                        }
                    }
                    null
                }

                VxNodeKind.ACTION_HTTP -> {
                    val method = interp(node.c("method").ifBlank { "GET" }, vars).uppercase()
                    val url = interp(node.c("url"), vars)
                    val saveAs = node.c("saveAs").ifBlank { "http_body" }
                    if (url.isBlank()) {
                        logs += VxLogLine(level = "ERROR", message = "HTTP URL empty", nodeId = node.id)
                        return null
                    }
                    val rb = Request.Builder().url(url)
                    if (method in listOf("POST", "PUT", "PATCH")) {
                        rb.method(method, "".toRequestBody("application/json".toMediaType()))
                    }
                    val resp = withContext(Dispatchers.IO) { http.newCall(rb.build()).execute() }
                    val body = resp.body?.string() ?: ""
                    vars[saveAs] = body
                    vars["${saveAs}_code"] = resp.code.toString()
                    logs += VxLogLine(level = "INFO", message = "HTTP ${resp.code}", nodeId = node.id)
                    if (!resp.isSuccessful) {
                        logs += VxLogLine(level = "ERROR", message = "HTTP ${resp.code}", nodeId = node.id)
                    }
                    null
                }

                VxNodeKind.ACTION_SET_VAR -> {
                    val key = interp(node.c("key"), vars)
                    val value = interp(node.c("value"), vars)
                    if (key.isNotBlank()) vars[key] = value
                    null
                }

                VxNodeKind.ACTION_LOG -> {
                    logs += VxLogLine(
                        level = "INFO",
                        message = interp(node.c("message"), vars),
                        nodeId = node.id
                    )
                    null
                }

                VxNodeKind.ACTION_VIBRATE -> {
                    val ms = interp(node.c("ms"), vars).toLongOrNull() ?: 200L
                    vibrate(ms.coerceIn(10, 3000))
                    null
                }

                VxNodeKind.ACTION_SHARE -> {
                    val text = interp(node.c("text"), vars)
                    withContext(Dispatchers.Main) {
                        runCatching {
                            val i = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, text)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(
                                Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                    null
                }

                VxNodeKind.ACTION_CLIPBOARD -> {
                    val text = interp(node.c("text"), vars)
                    withContext(Dispatchers.Main) {
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("veltrix", text))
                    }
                    null
                }

                VxNodeKind.ACTION_DEVICE_INFO -> {
                    vars.putAll(deviceSnapshot())
                    logs += VxLogLine(
                        level = "INFO",
                        message = "battery=${vars["battery"]} charging=${vars["charging"]}",
                        nodeId = node.id
                    )
                    null
                }

                VxNodeKind.CONDITION -> {
                    val left = interp(node.c("left"), vars)
                    val op = node.c("operator").ifBlank { "==" }
                    val right = interp(node.c("right"), vars)
                    val result = compare(left, op, right)
                    logs += VxLogLine(
                        level = "INFO",
                        message = "Condition $left $op $right → $result",
                        nodeId = node.id
                    )
                    if (result) "true" else "false"
                }
            }
        } catch (e: Exception) {
            logs += VxLogLine(level = "ERROR", message = e.message ?: "node error", nodeId = node.id)
            null
        }
    }

    private fun interp(template: String, vars: Map<String, String>): String {
        var s = template
        Regex("""\{\{(\w+)\}\}""").findAll(template).forEach { m ->
            s = s.replace(m.value, vars[m.groupValues[1]] ?: "")
        }
        return s
    }

    private fun compare(left: String, op: String, right: String): Boolean {
        val ln = left.toDoubleOrNull()
        val rn = right.toDoubleOrNull()
        return when (op) {
            "==", "=" -> left == right
            "!=" -> left != right
            ">" -> if (ln != null && rn != null) ln > rn else left > right
            ">=" -> if (ln != null && rn != null) ln >= rn else left >= right
            "<" -> if (ln != null && rn != null) ln < rn else left < right
            "<=" -> if (ln != null && rn != null) ln <= rn else left <= right
            "contains" -> left.contains(right, ignoreCase = true)
            else -> left == right
        }
    }

    private fun deviceSnapshot(): Map<String, String> {
        val m = mutableMapOf<String, String>()
        try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            m["battery"] = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).toString()
            val st = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)
            m["charging"] = (st == BatteryManager.BATTERY_STATUS_CHARGING ||
                    st == BatteryManager.BATTERY_STATUS_FULL).toString()
        } catch (_: Exception) {}
        try {
            @Suppress("DEPRECATION")
            val ni = (context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).activeNetworkInfo
            m["network"] = if (ni?.isConnected == true) "connected" else "disconnected"
            m["network_type"] = ni?.typeName ?: "none"
        } catch (_: Exception) {}
        m["deviceModel"] = Build.MODEL
        m["time"] = System.currentTimeMillis().toString()
        return m
    }

    private fun notify(title: String, body: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }

    @Suppress("DEPRECATION")
    private fun vibrate(ms: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                else v.vibrate(ms)
            }
        } catch (_: Exception) {}
    }
}
