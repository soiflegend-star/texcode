package com.texgen.music.texwave.ui.screens.chat

import com.texgen.music.texwave.data.chat.FriendsStore

import com.texgen.music.texwave.data.VerifiedBadgeStore
import com.texgen.music.texwave.ui.components.VerifiedStarBadge

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.chat.ChatAuthState
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.avatarModel
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.launch

/**
 * Instagram-style profile editor: story-ring avatar, online status, editable
 * name / @username / bio, save + sign out.
 */
@Composable
fun ProfileScreen(
    repo: ChatRepository,
    onBack: () -> Unit,
    onSignedOut: () -> Unit,
) {
    val auth by repo.authState.collectAsState()
    val profile = (auth as? ChatAuthState.SignedIn)?.profile
    var displayName by remember(profile?.id) { mutableStateOf(profile?.displayName ?: "") }
    var username by remember(profile?.id) { mutableStateOf(profile?.username ?: "") }
    var bio by remember(profile?.id) { mutableStateOf(profile?.bio ?: "") }
    var avatarUrl by remember(profile?.id) { mutableStateOf(profile?.avatarModel) }
    var saving by remember { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val onlineIds by repo.onlineUserIds.collectAsState()
    val isOnline = profile != null && profile.id in onlineIds

    val pulse by rememberInfiniteTransition(label = "onlinePulse").animateFloat(
        0.85f, 1.15f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulse",
    )

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null || profile == null) return@rememberLauncherForActivityResult
        uploading = true
        error = null
        scope.launch {
            repo.uploadAvatar(uri)
                .onSuccess { url ->
                    avatarUrl = url
                    Toast.makeText(context, "Photo updated", Toast.LENGTH_SHORT).show()
                }
                .onFailure { error = it.message }
            uploading = false
        }
    }

    val igRing = Brush.sweepGradient(
        listOf(
            Color(0xFFF58529),
            Color(0xFFFEDA77),
            Color(0xFFDD2A7B),
            Color(0xFF8134AF),
            Color(0xFF515BD4),
            Color(0xFFF58529),
        )
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF050611), Color(0xFF0C1020), Color(0xFF050611))
                )
            )
            .statusBarsPadding(),
    ) {
        // Top bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, null, tint = Tx.Text)
            }
            Text(
                "Profile",
                color = Tx.Text,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = {
                scope.launch {
                    repo.signOut()
                    onSignedOut()
                }
            }) {
                Icon(Icons.Rounded.Logout, "Sign out", tint = Tx.Muted)
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(8.dp))

            // Avatar with Instagram story ring
            Box(contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(118.dp)
                        .border(3.dp, igRing, CircleShape)
                        .padding(5.dp)
                        .clip(CircleShape)
                        .background(Tx.SurfaceHigh)
                        .clickable(enabled = !uploading) { imagePicker.launch("image/*") },
                    contentAlignment = Alignment.Center,
                ) {
                    when {
                        uploading -> CircularProgressIndicator(
                            Modifier.size(28.dp),
                            strokeWidth = 2.dp,
                            color = Tx.Accent,
                        )
                        !avatarUrl.isNullOrBlank() -> AsyncImage(
                            model = avatarUrl,
                            contentDescription = "Avatar",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                        else -> Text(
                            (displayName.ifBlank { "U" }).take(1).uppercase(),
                            color = Tx.Accent,
                            fontSize = 40.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
                // Camera badge
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 4.dp, bottom = 4.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Tx.Accent, Tx.Accent2)))
                        .clickable(enabled = !uploading) { imagePicker.launch("image/*") },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Rounded.CameraAlt, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                }
                // Online pulse
                if (isOnline) {
                    Box(
                        Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 10.dp, bottom = 10.dp)
                            .size(18.dp)
                            .scale(pulse)
                            .clip(CircleShape)
                            .background(Color(0xFF050611))
                            .padding(2.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF22C55E)),
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            Text(
                displayName.ifBlank { "Your name" },
                color = Tx.Text,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                "${FriendsStore.count(LocalContext.current)} friends",
                color = Tx.Accent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 6.dp),
            )

            Text(
                "@${username.ifBlank { "username" }}",
                color = Tx.Muted,
                fontSize = 14.sp,
            )
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isOnline) Color(0xFF22C55E) else Tx.Muted.copy(alpha = 0.5f)),
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    if (isOnline) "Active now" else "Offline",
                    color = if (isOnline) Color(0xFF22C55E) else Tx.Muted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
            if (!bio.isBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    bio,
                    color = Tx.Text.copy(alpha = 0.85f),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
            }

            Spacer(Modifier.height(18.dp))

            // Mini tips strip
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Tx.SurfaceHigh.copy(alpha = 0.7f))
                    .border(1.dp, Tx.Outline.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                ProfileStat("Chat", "Live")
                Box(Modifier.width(1.dp).height(28.dp).background(Tx.Outline.copy(alpha = 0.4f)))
                ProfileStat("Status", if (isOnline) "Online" else "Away")
                Box(Modifier.width(1.dp).height(28.dp).background(Tx.Outline.copy(alpha = 0.4f)))
                ProfileStat("Seen", "✓✓")
            }

            Spacer(Modifier.height(22.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Edit, null, tint = Tx.Accent, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Edit profile", color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            }
            Spacer(Modifier.height(12.dp))

            val fieldColors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Tx.Accent,
                unfocusedBorderColor = Tx.Outline,
                focusedTextColor = Tx.Text,
                unfocusedTextColor = Tx.Text,
                cursorColor = Tx.Accent,
                focusedLabelColor = Tx.Accent,
                unfocusedLabelColor = Tx.Muted,
                focusedContainerColor = Tx.Surface.copy(alpha = 0.5f),
                unfocusedContainerColor = Tx.Surface.copy(alpha = 0.35f),
            )

            OutlinedTextField(
                value = displayName,
                onValueChange = { displayName = it.take(40) },
                label = { Text("Display name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors,
                leadingIcon = { Icon(Icons.Rounded.Person, null, tint = Tx.Muted, modifier = Modifier.size(20.dp)) },
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = username,
                onValueChange = {
                    username = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' }.take(24)
                },
                label = { Text("Username") },
                supportingText = {
                    Text("3–24 chars · unique · people find you by @username", color = Tx.Muted, fontSize = 11.sp)
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors,
                prefix = { Text("@", color = Tx.Muted, fontWeight = FontWeight.SemiBold) },
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it.take(150) },
                label = { Text("Bio") },
                supportingText = {
                    Text("${bio.length}/150", color = Tx.Muted, fontSize = 11.sp)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors,
                maxLines = 4,
                minLines = 2,
            )

            error?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, color = Tx.Danger, fontSize = 13.sp)
            }

            Spacer(Modifier.height(20.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        if (!saving && profile != null)
                            Brush.linearGradient(listOf(Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF)))
                        else Brush.linearGradient(listOf(Tx.SurfaceHigh, Tx.SurfaceHigh))
                    )
                    .clickable(
                        enabled = !saving && !uploading && profile != null &&
                            username.length >= 3 && displayName.isNotBlank(),
                    ) {
                        saving = true
                        error = null
                        scope.launch {
                            repo.updateProfile(
                                displayName = displayName.trim(),
                                username = username.trim(),
                                bio = FriendsStore.withCountInBio(bio.trim(), FriendsStore.count(context)),
                            ).onSuccess {
                                Toast.makeText(context, "Profile saved", Toast.LENGTH_SHORT).show()
                            }.onFailure { error = it.message }
                            saving = false
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (saving) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Save profile", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Friends find you by @username, display name, or exact email.\n" +
                    "Active status shows while AUVYRR is open on your phone.",
                color = Tx.Muted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 17.sp,
            )
        }
    }
}

@Composable
private fun ProfileStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(label, color = Tx.Muted, fontSize = 11.sp)
    }
}
