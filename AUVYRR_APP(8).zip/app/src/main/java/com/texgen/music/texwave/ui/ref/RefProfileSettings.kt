package com.texgen.music.texwave.ui.ref

import com.texgen.music.texwave.ui.theme.Tx
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material.icons.rounded.TravelExplore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.VerifiedBadgeStore
import com.texgen.music.texwave.data.chat.ChatAuthState
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.FriendsStore
import com.texgen.music.texwave.data.chat.SocialFeedRepository
import com.texgen.music.texwave.data.chat.SocialPost
import com.texgen.music.texwave.data.chat.avatarModel
import com.texgen.music.texwave.ui.components.VerifiedStarBadge

/** Reference screen 10 — Profile. */
@Composable
fun RefProfileScreen(
    repo: ChatRepository,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onSettings: () -> Unit,
    onHighlight: (String) -> Unit = {},
) {
    val context = LocalContext.current
    val auth by repo.authState.collectAsState()
    val profile = (auth as? ChatAuthState.SignedIn)?.profile
    var posts by remember { mutableStateOf<List<SocialPost>>(emptyList()) }

    LaunchedEffect(profile?.id) {
        if (profile == null) return@LaunchedEffect
        val feed = SocialFeedRepository.get(context)
        feed.feed().onSuccess { l -> posts = l.filter { it.user_id == profile.id && it.media_type == "image" } }
    }

    val name = profile?.displayName?.ifBlank { null } ?: Ref.UserName
    val handle = "@" + (profile?.username?.ifBlank { null } ?: "soif_")
    val bioRaw = FriendsStore.stripMarkers(profile?.bio).trim()
    val bio = bioRaw.ifBlank { "Builder  •  Dreamer  •  AUVYRR" }
    val friends = remember(auth) { FriendsStore.count(context) }
    val useRefPhoto = profile?.avatarModel == null && (profile == null || name.contains("soif", ignoreCase = true))
    val cells: List<Pair<String?, Int?>> = posts.map { Pair<String?, Int?>(it.media_url, null) }

    RefBackground {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 12.dp)) {
            item {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(28.dp).clickable(onClick = onBack))
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Rounded.Settings, "Settings", tint = Color.White, modifier = Modifier.size(28.dp).clickable(onClick = onSettings))
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    RingAvatar(
                        name, profile?.avatarModel, Modifier.size(130.dp),
                        fallbackRes = if (useRefPhoto) R.drawable.ref_profile_av else null,
                        ring = listOf(Ref.Violet, Ref.Purple, Ref.Magenta.copy(alpha = 0.7f)),
                    )
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(name, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                            Spacer(Modifier.width(8.dp))
                            if (profile == null || VerifiedBadgeStore.isProfileVerified(profile.bio)) VerifiedStarBadge(size = 22.dp)
                        }
                        Text(handle, color = Ref.Muted, fontSize = 16.sp)
                        Spacer(Modifier.height(18.dp))
                        Text(bio, color = Color(0xFFE6EBFF), fontSize = 14.sp)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 22.dp)) {
                    Stat(posts.size.toString(), "Posts", Modifier.weight(1f))
                    Stat(countLabel(friends), "Followers", Modifier.weight(1f))
                    Stat(countLabel(friends), "Following", Modifier.weight(1f))
                }
            }
            item {
                val s = RoundedCornerShape(28.dp)
                Box(
                    Modifier.padding(horizontal = 18.dp).fillMaxWidth().height(54.dp).clip(s)
                        .background(Color(0xFF091236))
                        .border(1.5.dp, Brush.horizontalGradient(listOf(Ref.Violet, Ref.Blue, Ref.Magenta.copy(alpha = 0.8f))), s)
                        .clickable(onClick = onEdit),
                    contentAlignment = Alignment.Center,
                ) { Text("Edit Profile", color = Ref.Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Highlight("Music", Icons.Rounded.MusicNote, listOf(Ref.Purple, Ref.Magenta)) { onHighlight("Music") }
                    Highlight("Life", Icons.Rounded.Spa, listOf(Ref.Violet, Ref.Purple)) { onHighlight("Life") }
                    Highlight("Goals", Icons.Rounded.TrackChanges, listOf(Ref.Cyan, Ref.Blue)) { onHighlight("Goals") }
                    Highlight("Aether", Icons.Rounded.AutoAwesome, listOf(Ref.Blue, Ref.Violet)) { onHighlight("Aether") }
                }
            }
            item {
                // Photos only — reels upload removed
                Column(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(Icons.Rounded.Dashboard, null, tint = Color.White, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.height(10.dp))
                    Box(
                        Modifier.fillMaxWidth().height(2.dp).background(
                            Brush.horizontalGradient(listOf(Ref.Violet, Ref.Magenta)),
                        ),
                    )
                }
            }
            if (cells.isEmpty()) {
                item {
                    Text(
                        "No posts yet — share your first photo from the Feed.",
                        color = Ref.Muted, fontSize = 14.sp, modifier = Modifier.padding(28.dp),
                    )
                }
            }
            val rows = cells.chunked(3)
            items(rows.size) { r ->
                Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    rows[r].forEach { (url, res) ->
                        Box(Modifier.weight(1f).aspectRatio(0.92f).clip(RoundedCornerShape(2.dp))) {
                            if (res != null) Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            if (url != null) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                    }
                    repeat(3 - rows[r].size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Ref.Muted, fontSize = 15.sp)
    }
}

@Composable
private fun Highlight(label: String, icon: ImageVector, colors: List<Color>, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        NeonTile(Modifier.size(76.dp), corner = 38.dp, colors = colors) {
            Icon(icon, null, tint = colors.first(), modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}

/** Reference screen 12 — Settings. Each row opens the matching detail page. */
@Composable
fun RefSettingsScreen(
    onAccount: () -> Unit,
    onNotifications: () -> Unit,
    onPrivacy: () -> Unit,
    onAppearance: () -> Unit,
    onMusicSettings: () -> Unit,
    onPhantom: () -> Unit,
) {
    val context = LocalContext.current
    var about by remember { mutableStateOf(false) }
    var storage by remember { mutableStateOf(false) }
    var cacheBytes by remember { mutableStateOf(0L) }
    fun measure(): Long = runCatching { context.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() } }.getOrDefault(0L)
    LaunchedEffect(storage) { if (storage) cacheBytes = measure() }
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "6.9.0"
    }
    val rows = listOf(
        Triple("Account", Icons.Rounded.Person, onAccount),
        Triple("Notifications", Icons.Rounded.Notifications, onNotifications),
        Triple("Privacy", Icons.Rounded.Lock, onPrivacy),
        Triple("Appearance", Icons.Rounded.Palette, onAppearance),
        Triple("Music Settings", Icons.Rounded.MusicNote, onMusicSettings),
        Triple("AI Phantom", Icons.Rounded.SmartToy, onPhantom),
        Triple("Storage & Cache", Icons.Rounded.Dashboard, { storage = true }),
        Triple("About", Icons.Rounded.Info, { about = true }),
    )
    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
            Text(
                "Settings", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 4.dp, top = 14.dp, bottom = 14.dp),
            )
            Row(
                Modifier.fillMaxWidth().refCard(18.dp, hot = true).padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(painterResource(R.drawable.ref_logo_orb), null, Modifier.size(70.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("AUVYRR", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text("Version $version", color = Ref.Muted, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(rows.size) { i ->
                    val (label, icon, action) = rows[i]
                    Row(
                        Modifier.fillMaxWidth().height(58.dp).refCard(16.dp).clickable(onClick = action).padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(18.dp))
                        Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Rounded.ChevronRight, null, tint = Color(0xFFBFD0FF), modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }
    if (storage) {
        AlertDialog(
            onDismissRequest = { storage = false },
            confirmButton = {
                TextButton(onClick = {
                    runCatching { context.cacheDir.listFiles()?.forEach { it.deleteRecursively() } }
                    cacheBytes = measure()
                    android.widget.Toast.makeText(context, "Cache cleared", android.widget.Toast.LENGTH_SHORT).show()
                }) { Text("Clear cache") }
            },
            dismissButton = { TextButton(onClick = { storage = false }) { Text("Close") } },
            title = { Text("Storage & Cache") },
            text = { Text("Temporary files: %.1f MB\nYour songs, playlists and chats are not affected.".format(cacheBytes / 1048576.0)) },
        )
    }
    if (about) {
        AlertDialog(
            onDismissRequest = { about = false },
            confirmButton = { TextButton(onClick = { about = false }) { Text("OK") } },
            title = { Text("AUVYRR") },
            text = { Text("Version $version\nMusic · Chat · Connect · Create\nBuilt for dreamers like you.", textAlign = TextAlign.Start) },
        )
    }
}

data class MoreItem(
    val label: String,
    val icon: ImageVector,
    val subtitle: String = "",
    val accent: Color = Tx.Accent,
    val section: String = "",
    val onClick: () -> Unit,
)

/** "All screens" panel opened from the bottom bar — every destination in the app, grouped and searchable. */
@Composable
fun RefMoreSheet(visible: Boolean, onDismiss: () -> Unit, items: List<MoreItem>) {
    var query by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier.fillMaxSize().background(Color(0xCC000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss),
            )
        }
        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            val s = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp)
            val q = query.trim().lowercase()
            val shown = if (q.isEmpty()) items else items.filter { (it.label + " " + it.subtitle + " " + it.section).lowercase().contains(q) }
            val grouped = shown.groupBy { it.section.ifBlank { "MORE" } }
            Column(
                Modifier.fillMaxWidth().fillMaxHeight(0.9f).clip(s)
                    .background(Brush.verticalGradient(listOf(Color(0xFF242426), Color(0xFF111113), Tx.Bg)))
                    .border(1.dp, Brush.horizontalGradient(listOf(Ref.Violet.copy(alpha = 0.7f), Ref.Cyan.copy(alpha = 0.6f))), s)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(top = 12.dp),
            ) {
                Box(Modifier.align(Alignment.CenterHorizontally).width(44.dp).height(4.dp).clip(CircleShape).background(Ref.LineHi))
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Everything in AUVYRR", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Text("${items.size} screens · tap any tile", color = Ref.Sub, fontSize = 13.sp)
                    }
                    Icon(Icons.Rounded.Close, "Close", tint = Color.White, modifier = Modifier.size(30.dp).clickable(onClick = onDismiss))
                }
                RefSearchField(
                    value = query, onChange = { query = it }, placeholder = "Find a screen...",
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp), height = 46.dp,
                )
                androidx.compose.foundation.lazy.LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 14.dp, end = 14.dp, bottom = 28.dp),
                ) {
                    if (grouped.isEmpty()) item {
                        Text("No screen matches \"$query\"", color = Ref.Sub, fontSize = 14.sp, modifier = Modifier.padding(24.dp))
                    }
                    grouped.forEach { (section, list) ->
                        item(key = "h_$section") {
                            Text(
                                section, color = Ref.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
                                modifier = Modifier.padding(start = 6.dp, top = 18.dp, bottom = 8.dp),
                            )
                        }
                        list.chunked(3).forEachIndexed { ri, row ->
                            item(key = "r_${section}_$ri") {
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    row.forEach { it -> MoreTile(it, Modifier.weight(1f)) { onDismiss(); it.onClick() } }
                                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MoreTile(item: MoreItem, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.height(112.dp).clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF111F52), Color(0xFF1B1B1D))))
            .border(1.dp, Brush.verticalGradient(listOf(item.accent.copy(alpha = 0.55f), Ref.Line)), shape)
            .clickable(onClick = onClick).padding(10.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(item.accent, item.accent.copy(alpha = 0.45f)))),
            contentAlignment = Alignment.Center,
        ) { Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
        Column {
            Text(item.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.subtitle, color = Ref.Sub, fontSize = 10.sp, lineHeight = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Default list for [RefMoreSheet]; icons live here so callers just supply actions. */
object MoreIcons {
    val Search = Icons.Rounded.Search
    val Feed = Icons.Rounded.Explore
    val Messages = Icons.Rounded.Chat
    val Groups = Icons.Rounded.Groups
    val Profile = Icons.Rounded.Person
    val Settings = Icons.Rounded.Settings
    val Equalizer = Icons.Rounded.Equalizer
    val Alarms = Icons.Rounded.Alarm
    val Downloads = Icons.Rounded.Download
    val Stream = Icons.Rounded.TravelExplore
    val All = Icons.Rounded.Dashboard
}
