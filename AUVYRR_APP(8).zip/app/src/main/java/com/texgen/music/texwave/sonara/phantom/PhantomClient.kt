package com.texgen.music.texwave.sonara.phantom

import com.texgen.music.texwave.sonara.data.Track
import kotlinx.serialization.Serializable

/**
 * PHANTOM integration layer — conversation / AI music intelligence.
 *
 * Sonara does NOT embed Phantom credentials or simulate AI answers.
 * When [PhantomConfig] is unset, all calls return [PhantomResult.Unavailable].
 *
 * Wire to your Phantom / SYNTRA gateway by setting baseUrl + auth header provider.
 */
data class PhantomConfig(
    val baseUrl: String,
    /** Suspend function that returns Authorization header value, e.g. "Bearer …" */
    val authHeaderProvider: (suspend () -> String?)? = null,
    val enabled: Boolean = true,
)

sealed class PhantomResult<out T> {
    data class Ok<T>(val value: T) : PhantomResult<T>()
    data class Unavailable(val reason: String) : PhantomResult<Nothing>()
    data class Error(val message: String) : PhantomResult<Nothing>()
}

@Serializable
data class PhantomPlaylistRequest(
    val mood: String? = null,
    val prompt: String? = null,
    val seedTrackIds: List<String> = emptyList(),
    val limit: Int = 20,
)

@Serializable
data class PhantomPlaylistResponse(
    val title: String,
    val trackIds: List<String>,
    val rationale: String? = null,
)

@Serializable
data class PhantomRecommendRequest(
    val recentTrackIds: List<String> = emptyList(),
    val likedTrackIds: List<String> = emptyList(),
    val limit: Int = 20,
)

interface PhantomApi {
    suspend fun recommend(request: PhantomRecommendRequest): PhantomResult<List<String>>
    suspend fun generatePlaylist(request: PhantomPlaylistRequest): PhantomResult<PhantomPlaylistResponse>
    suspend fun naturalLanguageSearch(query: String): PhantomResult<List<String>>
    suspend fun djContinue(currentTrackId: String, historyIds: List<String>): PhantomResult<String>
    suspend fun insights(listeningSummary: String): PhantomResult<String>
}

/**
 * HTTP-ready client. Performs no network I/O until config is valid.
 */
class PhantomClient(
    private val config: PhantomConfig?,
    private val httpPost: suspend (url: String, auth: String?, jsonBody: String) -> String = { _, _, _ ->
        error("HTTP transport not injected")
    },
) : PhantomApi {

    private fun unavailable() = PhantomResult.Unavailable(
        "Phantom is not configured. Set PhantomConfig.baseUrl and inject an HTTP transport."
    )

    override suspend fun recommend(request: PhantomRecommendRequest): PhantomResult<List<String>> {
        if (config == null || !config.enabled || config.baseUrl.isBlank()) return unavailable()
        return PhantomResult.Unavailable("Connect Phantom gateway endpoint /v1/recommend")
    }

    override suspend fun generatePlaylist(request: PhantomPlaylistRequest): PhantomResult<PhantomPlaylistResponse> {
        if (config == null || !config.enabled || config.baseUrl.isBlank()) return unavailable()
        return PhantomResult.Unavailable("Connect Phantom gateway endpoint /v1/playlist")
    }

    override suspend fun naturalLanguageSearch(query: String): PhantomResult<List<String>> {
        if (config == null || !config.enabled || config.baseUrl.isBlank()) return unavailable()
        return PhantomResult.Unavailable("Connect Phantom gateway endpoint /v1/nl-search")
    }

    override suspend fun djContinue(currentTrackId: String, historyIds: List<String>): PhantomResult<String> {
        if (config == null || !config.enabled || config.baseUrl.isBlank()) return unavailable()
        return PhantomResult.Unavailable("Connect Phantom gateway endpoint /v1/dj/next")
    }

    override suspend fun insights(listeningSummary: String): PhantomResult<String> {
        if (config == null || !config.enabled || config.baseUrl.isBlank()) return unavailable()
        return PhantomResult.Unavailable("Connect Phantom gateway endpoint /v1/insights")
    }
}

/** Local non-AI fallback used only for deterministic radio — not branded as Phantom. */
object LocalSmartRadio {
    fun nextTrackIds(seedId: String, catalogue: List<Track>, history: List<String>): List<String> {
        val seed = catalogue.find { it.id == seedId } ?: return emptyList()
        return catalogue
            .filter { it.id != seedId && it.id !in history.takeLast(10) }
            .sortedByDescending {
                var s = 0
                if (it.artist == seed.artist) s += 3
                if (it.genre == seed.genre) s += 2
                s
            }
            .map { it.id }
    }
}
