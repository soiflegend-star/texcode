package com.texgen.music.texwave.ui.ref

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.components.LocalCustomArt
import com.texgen.music.texwave.ui.theme.Tx
import java.io.File

/** Palette + shared constants sampled from the 12-screen AUVYRR reference. */
object Ref {
    // Everything below follows the selected app theme (Tx), so picking a theme recolours every screen.
    private fun mix(a: Color, b: Color, t: Float) = androidx.compose.ui.graphics.lerp(a, b, t)
    val Bg: Color get() = Tx.Bg
    val Bg2: Color get() = mix(Tx.Bg, Tx.Surface, 0.5f)
    val Card: Color get() = Tx.SurfaceHigh
    val CardHi: Color get() = mix(Tx.SurfaceHigh, Color.White, 0.06f)
    val Line: Color get() = mix(Tx.SurfaceHigh, Color.White, 0.14f)
    val LineHi: Color get() = mix(Tx.SurfaceHigh, Color.White, 0.22f)
    val Cyan: Color get() = Tx.Accent
    val Blue: Color get() = Tx.Accent2
    val Violet: Color get() = Tx.Accent
    val Purple: Color get() = mix(Tx.Accent2, Color.Black, 0.12f)
    val Magenta = Color(0xFFFF58D8)
    val Text = Color(0xFFF4F6FF)
    val Sub = Color(0xFF8A8F9C)
    val Muted = Color(0xFFA3A8B5)
    val Faint = Color(0xFF4A4E5A)
    val Lavender: Color get() = mix(Tx.Accent, Color.White, 0.55f)

    /** Name shown in "Good evening, X" and Phantom greeting. */
    const val UserName = "SOIF"
}

val RefThumbs = intArrayOf(
    R.drawable.ref_th_afterdark, R.drawable.ref_th_nights, R.drawable.ref_th_faded,
    R.drawable.ref_th_legends, R.drawable.ref_th_smells, R.drawable.ref_th_believer,
    R.drawable.ref_th_arcade, R.drawable.ref_pl_chill, R.drawable.ref_pl_focus, R.drawable.ref_pl_workout,
)

fun refThumbFor(key: String): Int = RefThumbs[(key.hashCode() and 0x7fffffff) % RefThumbs.size]

/** Dark navy gradient with a violet corner glow, like every reference screen. */
@Composable
fun RefBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier
            .fillMaxSize()
            .background(Ref.Bg)
            .drawBehind {
                // smoky glass look: accent glow top-right, softer glow bottom-left, two silk curves
                val c = Offset(size.width * 0.95f, size.height * 0.06f)
                drawCircle(
                    Brush.radialGradient(listOf(Ref.Cyan.copy(alpha = 0.30f), Color.Transparent), center = c, radius = size.width * 0.95f),
                    radius = size.width * 0.95f, center = c,
                )
                val c2 = Offset(0f, size.height * 0.95f)
                drawCircle(
                    Brush.radialGradient(listOf(Ref.Violet.copy(alpha = 0.18f), Color.Transparent), center = c2, radius = size.width * 0.85f),
                    radius = size.width * 0.85f, center = c2,
                )
                val silk = Color.White.copy(alpha = 0.06f)
                val p1 = Path().apply {
                    moveTo(-size.width * 0.1f, size.height * 0.28f)
                    cubicTo(size.width * 0.5f, size.height * 0.08f, size.width * 0.35f, size.height * 0.72f, size.width * 1.1f, size.height * 0.52f)
                }
                drawPath(p1, silk, style = Stroke(width = 2.dp.toPx()))
                val p2 = Path().apply {
                    moveTo(-size.width * 0.1f, size.height * 0.34f)
                    cubicTo(size.width * 0.55f, size.height * 0.16f, size.width * 0.4f, size.height * 0.78f, size.width * 1.1f, size.height * 0.6f)
                }
                drawPath(p2, silk, style = Stroke(width = 1.dp.toPx()))
                drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.35f)), startY = size.height * 0.6f))
            },
        content = content,
    )
}

/** Premium glass card: sheen, accent bloom and a gradient hairline edge. */
fun Modifier.refCard(radius: Dp = 16.dp, hot: Boolean = false): Modifier {
    val s = RoundedCornerShape(radius)
    return this
        .clip(s)
        .background(Ref.Bg.copy(alpha = 0.62f))
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f))))
        .drawBehind {
            if (hot) drawRect(
                Brush.radialGradient(
                    listOf(Ref.Violet.copy(alpha = 0.26f), Color.Transparent),
                    center = Offset(size.width * 0.92f, 0f), radius = size.width * 0.75f,
                ),
            )
            if (hot) drawRect(
                Brush.radialGradient(
                    listOf(Ref.Blue.copy(alpha = 0.14f), Color.Transparent),
                    center = Offset(0f, size.height), radius = size.width * 0.6f,
                ),
            )
        }
        .border(
            1.dp,
            Brush.linearGradient(
                if (hot) listOf(Ref.Cyan.copy(alpha = 0.85f), Ref.Violet.copy(alpha = 0.35f), Ref.Blue.copy(alpha = 0.7f))
                else listOf(Color.White.copy(alpha = 0.16f), Ref.Line.copy(alpha = 0.55f), Color.White.copy(alpha = 0.06f)),
            ),
            s,
        )
}

/** Gentle press-in feedback (scale to 0.96 while held). Put it before .clickable on the same element. */
fun Modifier.pressScale(): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val k by animateFloatAsState(if (pressed) 0.95f else 1f, tween(110), label = "press")
    this.graphicsLayer { scaleX = k; scaleY = k }
}

@Composable
fun RefImage(
    @DrawableRes id: Int,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(0.dp),
    scale: ContentScale = ContentScale.Crop,
    alignment: Alignment = Alignment.Center,
) {
    Image(
        painter = painterResource(id),
        contentDescription = null,
        modifier = modifier.clip(shape),
        contentScale = scale,
        alignment = alignment,
    )
}

/** Song cover: real album art when present, otherwise a reference-style cover.
 *  Crop fills the frame (no stretch / no letterbox). High-res decode keeps it sharp. */
@Composable
fun SongThumb(
    song: Song?,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    @DrawableRes fallback: Int? = null,
    artOverride: String? = null,
    hiRes: Int = 2560,
) {
    val custom = LocalCustomArt.current
    val raw = artOverride ?: song?.let { custom[it.id] } ?: song?.artUri
    val model: Any? = when {
        raw == null -> null
        raw.startsWith("/") -> File(raw)
        raw.startsWith("file:") -> File(android.net.Uri.parse(raw).path ?: raw)
        else -> raw
    }
    val fb = fallback ?: refThumbFor(song?.album ?: song?.title ?: "texwave")
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // Sharp art: pull the embedded cover (full resolution) instead of the tiny MediaStore thumbnail.
    val hi by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, song?.id, raw, hiRes) {
        value = if (song != null && artOverride == null && custom[song.id] == null) HiResArt.load(ctx, song, hiRes) else null
    }
    val coilModel = if (model != null) {
        coil.request.ImageRequest.Builder(ctx)
            .data(model)
            .size(coil.size.Size(hiRes, hiRes))
            .allowHardware(true)
            .crossfade(180)
            .build()
    } else null
    Box(
        modifier
            .clip(shape)
            .background(Color(0xFF101012)),
        contentAlignment = Alignment.Center,
    ) {
        Image(painterResource(fb), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (hi != null) {
            Image(
                bitmap = hi!!.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.High, modifier = Modifier.fillMaxSize(),
            )
        } else if (coilModel != null) {
            AsyncImage(
                model = coilModel,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.High,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/** In-memory cache of full-resolution cover art, keyed by song + size bucket. */
object HiResArt {
    private val cache = object : android.util.LruCache<String, android.graphics.Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: String, value: android.graphics.Bitmap) = value.byteCount
    }
    private val misses = java.util.Collections.synchronizedSet(HashSet<String>())

    suspend fun load(ctx: android.content.Context, song: Song, px: Int): android.graphics.Bitmap? {
        val key = "${song.id}@$px"
        cache.get(key)?.let { return it }
        if (key in misses || !song.contentUri.startsWith("content:")) return null
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val uri = android.net.Uri.parse(song.contentUri)
            var bmp: android.graphics.Bitmap? = null
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                bmp = runCatching { ctx.contentResolver.loadThumbnail(uri, android.util.Size(px, px), null) }.getOrNull()
            }
            if (bmp == null) {
                bmp = runCatching {
                    val r = android.media.MediaMetadataRetriever()
                    try {
                        r.setDataSource(ctx, uri)
                        r.embeddedPicture?.let { b ->
                            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            android.graphics.BitmapFactory.decodeByteArray(b, 0, b.size, o)
                            var sample = 1
                            while (o.outWidth / (sample * 2) >= px) sample *= 2
                            android.graphics.BitmapFactory.decodeByteArray(b, 0, b.size, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
                        }
                    } finally { runCatching { r.release() } }
                }.getOrNull()
            }
            if (bmp != null) cache.put(key, bmp) else misses.add(key)
            bmp
        }
    }
}

/** "AUVYRR" wide gradient wordmark. */
@Composable
fun RefWordmark(fontSize: TextUnit = 24.sp, modifier: Modifier = Modifier) {
    Text(
        "AUVYRR",
        modifier = modifier,
        style = TextStyle(
            brush = Brush.horizontalGradient(
                listOf(Color(0xFFFFFFFF), Ref.Lavender, Ref.Cyan, Color(0xFFFFFFFF)),
            ),
            fontSize = fontSize,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.SansSerif,
            letterSpacing = fontSize * 0.2f,
        ),
    )
}


@Composable
fun IconCircle(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0x1AFFFFFF))
            .border(1.dp, Color(0x22FFFFFF), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        color = Color.White,
        fontSize = 30.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = (-0.4).sp,
    )
}

@Composable
fun SectionTitle(title: String, action: String? = "See All", onAction: () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text(
                action, color = Ref.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(CircleShape).background(Ref.Cyan.copy(alpha = 0.12f))
                    .clickable(onClick = onAction).padding(horizontal = 12.dp, vertical = 5.dp),
            )
        }
    }
}

/** Standard list row: thumb + title + subtitle + chevron, inside a glow card. */
@Composable
fun RefRow(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    card: Boolean = true,
    thumbBorder: Boolean = false,
    chevron: Boolean = true,
    onChevron: (() -> Unit)? = null,
    onClick: () -> Unit,
    thumb: @Composable () -> Unit,
) {
    Row(
        modifier
            .let { if (card) it.refCard(18.dp) else it }
            .clickable(onClick = onClick)
            .padding(horizontal = if (card) 10.dp else 0.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.let {
                if (thumbBorder) it.border(1.5.dp, Ref.Cyan.copy(alpha = 0.85f), RoundedCornerShape(14.dp)) else it
            }
        ) { thumb() }
        Box(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            Text(subtitle, color = Ref.Sub, fontSize = 13.sp, maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
        if (chevron) {
            Box(
                Modifier
                    .size(36.dp)
                    .let { if (onChevron != null) it.clickable(onClick = onChevron) else it },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.ChevronRight, null, tint = Ref.Muted, modifier = Modifier.size(24.dp))
            }
        }
    }
}

/** Slowly rotating glowing ring used behind orbs. */
@Composable
fun GlowRing(modifier: Modifier = Modifier, strokeDp: Dp = 3.dp, speedMs: Int = 9000) {
    val t = rememberInfiniteTransition(label = "ring")
    val a by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(speedMs, easing = LinearEasing), RepeatMode.Restart),
        label = "ringA",
    )
    Canvas(modifier) {
        val sw = strokeDp.toPx()
        val brush = Brush.sweepGradient(
            listOf(Ref.Cyan, Ref.Blue, Ref.Violet, Ref.Magenta.copy(alpha = 0.7f), Ref.Blue, Ref.Cyan),
            center = center,
        )
        rotate(a) {
            drawCircle(brush, radius = size.minDimension / 2f - sw, style = Stroke(sw, cap = StrokeCap.Round))
        }
        drawCircle(
            Ref.Cyan.copy(alpha = 0.10f),
            radius = size.minDimension / 2f - sw * 0.2f,
            style = Stroke(sw * 3f),
        )
    }
}

/** Small round glass icon button (reference header buttons). */
@Composable
fun GlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 42.dp,
    tint: Color = Color.White,
    square: Boolean = false,
) {
    val shape: Shape = if (square) RoundedCornerShape(14.dp) else CircleShape
    Box(
        modifier
            .size(size)
            .clip(shape)
            .background(Brush.linearGradient(listOf(Ref.Purple.copy(alpha = 0.55f), Ref.CardHi)))
            .border(1.dp, Ref.Violet.copy(alpha = 0.5f), shape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

/** Gradient-bordered rounded square (search categories, highlights). */
@Composable
fun NeonTile(
    modifier: Modifier = Modifier,
    corner: Dp = 18.dp,
    colors: List<Color>,
    content: @Composable BoxScope.() -> Unit,
) {
    val s = RoundedCornerShape(corner)
    Box(
        modifier
            .clip(s)
            .background(Brush.verticalGradient(listOf(colors.first().copy(alpha = 0.16f), Ref.Card)))
            .border(1.5.dp, Brush.linearGradient(colors), s),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

/** Reference artist photos, matched by name only (never shown for other artists). */
fun artistPhotoRes(name: String): Int? {
    val n = name.lowercase()
    return when {
        "weeknd" in n -> R.drawable.ref_artist_weeknd
        "imagine dragons" in n -> R.drawable.ref_artist_dragons
        "alan walker" in n -> R.drawable.ref_artist_walker
        "arijit" in n -> R.drawable.ref_artist_arijit
        else -> null
    }
}

/** Round avatar: photo if known, otherwise gradient with initials. */
@Composable
fun InitialsAvatar(name: String, modifier: Modifier = Modifier, ringColors: List<Color> = listOf(Ref.Violet, Ref.Blue)) {
    val photo = artistPhotoRes(name)
    Box(
        modifier
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Ref.Purple.copy(alpha = 0.7f), Ref.Blue.copy(alpha = 0.5f))))
            .border(2.dp, Brush.linearGradient(ringColors), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (photo != null) {
            Image(painterResource(photo), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            val ini = name.trim().split(" ").filter { it.isNotEmpty() }.take(2)
                .joinToString("") { it.first().uppercase() }.ifEmpty { "T" }
            Text(ini, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        }
    }
}

/** Crisp typeface bundled with the app (Inter). */
val RefFont = androidx.compose.ui.text.font.FontFamily(
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_light, androidx.compose.ui.text.font.FontWeight.Light),
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_regular, androidx.compose.ui.text.font.FontWeight.Normal),
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_medium, androidx.compose.ui.text.font.FontWeight.Medium),
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_semibold, androidx.compose.ui.text.font.FontWeight.SemiBold),
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_bold, androidx.compose.ui.text.font.FontWeight.Bold),
)

/**
 * App-wide polish: the mockup was designed for a ~400dp canvas, so scale density down a touch on
 * narrower phones (sharper, less oversized UI) and apply the Inter typeface everywhere.
 */
@androidx.compose.runtime.Composable
fun RefPolish(content: @androidx.compose.runtime.Composable () -> Unit) {
    val d = androidx.compose.ui.platform.LocalDensity.current
    val widthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val k = (widthDp / 400f).coerceIn(0.86f, 1f)
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(d.density * k, d.fontScale.coerceAtMost(1.15f)),
    ) {
        androidx.compose.material3.ProvideTextStyle(
            androidx.compose.ui.text.TextStyle(fontFamily = RefFont, letterSpacing = 0.sp),
            content,
        )
    }
}


/** Vinyl record used by the "Feel the Music" banner. */
@Composable
fun RefVinyl(diameter: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier.size(diameter).drawBehind {
            val c = center
            val r = this.size.minDimension / 2f
            drawCircle(Color(0xFF0B0B10), r, c)
            for (i in 1..9) drawCircle(Color.White.copy(alpha = if (i % 3 == 0) 0.16f else 0.07f), r * (0.34f + i * 0.066f), c, style = Stroke(1.dp.toPx()))
            drawCircle(Brush.linearGradient(listOf(Ref.Lavender, Ref.Violet)), r * 0.3f, c)
            drawCircle(Color(0xFF0B0B10), r * 0.06f, c)
        },
    )
}
