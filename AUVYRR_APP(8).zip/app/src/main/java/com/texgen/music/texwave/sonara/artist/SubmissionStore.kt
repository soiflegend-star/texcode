package com.texgen.music.texwave.sonara.artist

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.texgen.music.texwave.sonara.rights.ContentSubmission
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

private val Context.submissionStore by preferencesDataStore("sonara_submissions")

/**
 * Local queue of music submissions for demo / offline-first capture.
 * When Supabase is configured, mirror rows to content_submissions (server is source of truth).
 */
class SubmissionStore(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val key = stringPreferencesKey("submissions_json")

    val submissions: Flow<List<ContentSubmission>> = context.submissionStore.data.map { prefs ->
        val raw = prefs[key] ?: return@map emptyList()
        try {
            json.decodeFromString(ListSerializer(ContentSubmission.serializer()), raw)
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun submit(submission: ContentSubmission) {
        context.submissionStore.edit { prefs ->
            val current = try {
                json.decodeFromString(
                    ListSerializer(ContentSubmission.serializer()),
                    prefs[key] ?: "[]"
                ).toMutableList()
            } catch (_: Exception) {
                mutableListOf()
            }
            current.add(0, submission.copy(id = "sub_${System.currentTimeMillis()}"))
            prefs[key] = json.encodeToString(ListSerializer(ContentSubmission.serializer()), current)
        }
    }

    suspend fun setStatus(id: String, status: String, notes: String? = null) {
        context.submissionStore.edit { prefs ->
            val current = try {
                json.decodeFromString(
                    ListSerializer(ContentSubmission.serializer()),
                    prefs[key] ?: "[]"
                ).toMutableList()
            } catch (_: Exception) {
                return@edit
            }
            val idx = current.indexOfFirst { it.id == id }
            if (idx >= 0) {
                current[idx] = current[idx].copy(status = status, reviewerNotes = notes)
                prefs[key] = json.encodeToString(ListSerializer(ContentSubmission.serializer()), current)
            }
        }
    }
}
