package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.texgen.music.texwave.brain.AutoCompanion
import com.texgen.music.texwave.brain.Persona
import com.texgen.music.texwave.util.VoskModelManager
import com.texgen.music.texwave.brain.Brain
import com.texgen.music.texwave.brain.BrainManager
import com.texgen.music.texwave.brain.PromptStyle
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.NetUtil
import kotlinx.coroutines.launch

/**
 * "Brains": download a small offline AI once, then AUVYRR can greet you in the morning,
 * talk with you and play music with no internet.
 */
@Composable
fun BrainScreen(onBack: () -> Unit, onAsk: suspend (String) -> String = { "" }) {
    val context = LocalContext.current
    val mgr = remember { BrainManager.get(context) }
    val states by mgr.states.collectAsState()
    val activeId by mgr.activeId.collectAsState()
    val customs by mgr.customs.collectAsState()
    val thinking by mgr.thinking.collectAsState()
    val scope = rememberCoroutineScope()

    var confirm by remember { mutableStateOf<Brain?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var testQ by remember { mutableStateOf("Good morning! Play something calm.") }
    var testA by remember { mutableStateOf<String?>(null) }

    val all = BrainManagerList(mgr, customs)
    // Best Brain for THIS phone, by memory: it must run reliably, not just fit.
    val ram = remember { mgr.totalRamGb() }
    val recId = when {
        ram >= 7.0 -> "atlas"
        ram >= 5.0 -> "atlas"
        ram >= 3.0 -> "spark"
        else -> "pico"
    }

    // ---- Ears (offline voice) + hands-free companion
    val vosk = remember { VoskModelManager.get(context) }
    val voskState by vosk.state.collectAsState()
    val askNow by rememberUpdatedState(onAsk)
    val companion = remember { AutoCompanion(context) { q -> askNow(q) } }
    DisposableEffect(Unit) { onDispose { companion.release() } }
    LaunchedEffect(Unit) {
        vosk.refresh()
        if (!vosk.isReady() && NetUtil.isOnline(context)) vosk.startDownload(VoskModelManager.ModelPack.SMALL)
    }
    val phase by companion.phase.collectAsState()
    val heard by companion.heard.collectAsState()
    val spoken by companion.reply.collectAsState()
    val cStatus by companion.status.collectAsState()
    val mood by companion.mood.collectAsState()
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) companion.start()
    }

    Box(Modifier.fillMaxSize().background(Tx.Bg)) {
        LazyColumn(
            Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Tx.Text)
                    }
                    Icon(Icons.Rounded.Psychology, null, tint = Tx.Accent, modifier = Modifier.padding(end = 8.dp))
                    Text("Brains", color = Tx.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    "Download a Brain once. After that AUVYRR can wake you up with a greeting, talk with you and play music — with zero internet.",
                    color = Tx.Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
                )
            }

            // ---- Active brain + test
            item {
                val active = mgr.find(activeId)?.takeIf { states[it.id]?.status == BrainManager.Status.INSTALLED }
                Card {
                    Text(
                        if (active != null) "Active Brain: ${active.name}" else "No Brain yet",
                        color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                    )
                    Text(
                        if (active != null) {
                            if (mgr.isBad(active.id)) "This Brain ran out of memory last time. Choose a smaller one."
                            else "Ready. Try it below — the first answer takes a little longer while it wakes up."
                        } else "Pick one below. Spark (0.55 GB) is the best place to start.",
                        color = Tx.Muted, fontSize = 12.sp,
                    )
                    if (active != null && !mgr.isBad(active.id)) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = testQ, onValueChange = { testQ = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            label = { Text("Ask your Brain") },
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                enabled = !thinking && testQ.isNotBlank(),
                                onClick = {
                                    testA = null
                                    scope.launch {
                                        val r = mgr.assist(testQ)
                                        testA = r.fold(
                                            onSuccess = { it.text },
                                            onFailure = { "⚠ ${it.message}" },
                                        )
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent),
                            ) { Text("Ask") }
                            if (thinking) {
                                Spacer(Modifier.width(12.dp))
                                CircularProgressIndicator(Modifier.height(20.dp).width(20.dp), strokeWidth = 2.dp, color = Tx.Accent)
                                Spacer(Modifier.width(8.dp))
                                Text("Thinking…", color = Tx.Muted, fontSize = 12.sp)
                            }
                        }
                        testA?.let {
                            Spacer(Modifier.height(8.dp))
                            Text(it, color = Tx.Text, fontSize = 14.sp)
                        }
                    }
                }
            }

            // ---- Talk (autonomous voice conversation)
            item {
                val online = NetUtil.isOnline(context)
                Card {
                    Text("Talk to AUVYRR", color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(
                        "Hands-free: just speak. It listens, understands your mood, answers out loud, and plays music. " +
                            if (online) "Online voice active." else "Offline voice active — no internet needed.",
                        color = Tx.Muted, fontSize = 12.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val running = phase != AutoCompanion.Phase.IDLE
                        Button(
                            onClick = {
                                if (running) companion.stop()
                                else if (companion.hasPermission()) companion.start()
                                else micLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = if (running) Tx.Danger else Tx.Accent),
                        ) {
                            Icon(if (running) Icons.Rounded.Stop else Icons.Rounded.Mic, null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (running) "Stop" else "Start talking")
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(
                            when (phase) {
                                AutoCompanion.Phase.LISTENING -> "Listening"
                                AutoCompanion.Phase.THINKING -> "Thinking"
                                AutoCompanion.Phase.SPEAKING -> "Speaking"
                                AutoCompanion.Phase.IDLE -> "Idle"
                            },
                            color = Tx.Accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                        )
                        if (mood != Persona.Mood.NEUTRAL) {
                            Spacer(Modifier.width(10.dp))
                            Text("mood: ${mood.name.lowercase()}", color = Tx.Muted, fontSize = 11.sp)
                        }
                    }
                    Text(cStatus, color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    if (heard.isNotBlank()) {
                        Text("You: $heard", color = Tx.Text, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    if (spoken.isNotBlank()) {
                        Text("AUVYRR: $spoken", color = Tx.Accent, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            // ---- Ears: offline voice recognition models (small to large)
            item {
                val using = vosk.inUse()
                Column(Modifier.padding(horizontal = 4.dp)) {
                    Text("Ears — voice recognition", color = Tx.Text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text(
                        if (using != null) "In use: ${using.label}. Voice works with no internet."
                        else "Download at least one so voice works anywhere. The 40 MB one is enough for commands.",
                        color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp),
                    )
                }
            }
            items(VoskModelManager.ModelPack.entries.toList(), key = { "ear_" + it.id }) { pack ->
                val installed = vosk.isPackReady(pack)
                val busy = voskState.downloading && voskState.activePack == pack.id
                val inUse = vosk.inUse() == pack
                val fits = vosk.fitsPhone(pack)
                val saved = vosk.partialBytes(pack)
                Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(pack.label, color = Tx.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        if (inUse) Tag("In use", Color(0xFF3DDC97))
                        Spacer(Modifier.weight(1f))
                        Text(pack.sizeHint, color = Tx.Accent, fontWeight = FontWeight.SemiBold)
                    }
                    Text(pack.blurb, color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                    Text("Phone memory: ${pack.minRamGb}+ GB", color = Tx.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                    if (!fits && !installed) {
                        Text("⚠ This phone does not have enough memory for this model.", color = Color(0xFFFFB74D), fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    when {
                        busy -> {
                            val dl = if (voskState.bytesTotal > 0) (voskState.bytesDownloaded * 100 / voskState.bytesTotal).toInt() else 0
                            val installing = voskState.progress >= 0.86f
                            LinearProgressIndicator(
                                progress = { if (installing) 1f else dl / 100f },
                                modifier = Modifier.fillMaxWidth(), color = Tx.Accent,
                            )
                            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    if (installing) "Installing…"
                                    else "$dl%  ·  ${voskState.bytesDownloaded / 1_000_000} / ${voskState.bytesTotal / 1_000_000} MB",
                                    color = Tx.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                )
                                if (!installing) TextButton(onClick = { vosk.pauseDownload() }) { Text("Pause", color = Tx.Accent) }
                            }
                        }
                        installed -> {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (!inUse && fits) {
                                    Button(
                                        onClick = { vosk.setActivePack(pack) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent),
                                    ) { Text("Use this") }
                                } else if (inUse) {
                                    Text("✓ Installed", color = Color(0xFF3DDC97), fontWeight = FontWeight.SemiBold)
                                }
                                TextButton(onClick = { vosk.deletePack(pack) }) { Text("Delete", color = Tx.Danger) }
                            }
                        }
                        else -> {
                            if (voskState.activePack == pack.id) {
                                voskState.error?.let { Text(it, color = Tx.Danger, fontSize = 11.sp) }
                            }
                            if (saved > 0) {
                                Text("${saved / 1_000_000} MB saved", color = Tx.Muted, fontSize = 11.sp)
                            }
                            Button(
                                enabled = fits && !voskState.downloading,
                                onClick = { vosk.startDownload(pack) },
                                colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent),
                            ) { Text(if (saved > 0) "Resume" else "Download ${pack.sizeHint}") }
                        }
                    }
                }
            }

            item {
                Text(
                    "Brains",
                    color = Tx.Text, fontWeight = FontWeight.Bold, fontSize = 20.sp,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp),
                )
            }

            items(all, key = { it.id }) { b ->
                val st = states[b.id] ?: BrainManager.Dl()
                BrainCard(
                    brain = b.copy(recommended = b.id == recId),
                    st = st,
                    active = b.id == activeId,
                    fits = mgr.fitsPhone(b),
                    bad = mgr.isBad(b.id),
                    onDownload = {
                        if (b.approxBytes > 800_000_000L && !NetUtil.isUnmetered(context)) confirm = b
                        else mgr.download(b)
                    },
                    onPause = { mgr.pause(b.id) },
                    onUse = { mgr.use(b.id) },
                    onDelete = { if (b.custom) mgr.removeCustom(b.id) else mgr.delete(b.id) },
                )
            }

            item {
                OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Add your own Brain (download link)", color = Tx.Accent)
                }
                Text(
                    "Bigger Brains are slower and need more phone memory; \"Start here\" marks the best fit for this phone. Only models that exist as verified phone-ready downloads are listed (up to 6.2 GB). Have a link to a larger one? Add it above.",
                    color = Tx.Muted, fontSize = 11.sp, modifier = Modifier.padding(8.dp),
                )
            }
        }
    }

    confirm?.let { b ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Big download on mobile data?") },
            text = { Text("${b.name} is ${b.sizeLabel}. You are not on an unmetered Wi-Fi connection. Download anyway?") },
            confirmButton = { TextButton(onClick = { mgr.download(b); confirm = null }) { Text("Download") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Wait for Wi-Fi") } },
        )
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var url by remember { mutableStateOf("") }
        var style by remember { mutableStateOf(PromptStyle.CHATML) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add your own Brain") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Paste a direct https link to a MediaPipe .task model file.", fontSize = 12.sp)
                    OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                    OutlinedTextField(url, { url = it }, label = { Text("Link") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PromptStyle.entries.forEach { s ->
                            FilterChip(selected = style == s, onClick = { style = s }, label = { Text(s.name.lowercase(), fontSize = 11.sp) })
                        }
                    }
                    err?.let { Text(it, color = Tx.Danger, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    mgr.addCustom(name, url, style).fold(
                        onSuccess = { mgr.download(it); showAdd = false },
                        onFailure = { err = it.message },
                    )
                }) { Text("Add and download") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } },
        )
    }
}

private fun BrainManagerList(mgr: BrainManager, @Suppress("UNUSED_PARAMETER") customs: List<Brain>): List<Brain> = mgr.allBrains()

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Tx.Surface)
            .border(1.dp, Tx.Outline, RoundedCornerShape(18.dp))
            .padding(14.dp),
    ) { content() }
}

@Composable
private fun BrainCard(
    brain: Brain,
    st: BrainManager.Dl,
    active: Boolean,
    fits: Boolean,
    bad: Boolean,
    onDownload: () -> Unit,
    onPause: () -> Unit,
    onUse: () -> Unit,
    onDelete: () -> Unit,
) {
    val border = if (active) Tx.Accent else Tx.Outline
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Tx.Surface)
            .border(if (active) 2.dp else 1.dp, border, RoundedCornerShape(18.dp))
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(brain.name, color = Tx.Text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            if (brain.recommended) Tag("Start here", Tx.Accent)
            if (active) Tag("Active", Color(0xFF3DDC97))
            Spacer(Modifier.weight(1f))
            Text(brain.sizeLabel, color = Tx.Accent, fontWeight = FontWeight.SemiBold)
        }
        Text(brain.tagline, color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        if (!brain.custom) {
            Text(
                "Speed: ${brain.speed}  ·  Smarts: ${brain.smarts}  ·  Phone memory: ${brain.minRamGb}+ GB",
                color = Tx.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
            )
        }
        if (!fits && !brain.custom) {
            Text("⚠ This phone may not have enough memory for ${brain.name}.", color = Color(0xFFFFB74D), fontSize = 11.sp)
        }
        if (bad) {
            Text("⚠ Ran out of memory last time — try a smaller Brain.", color = Tx.Danger, fontSize = 11.sp)
        }
        Spacer(Modifier.height(10.dp))

        when (st.status) {
            BrainManager.Status.DOWNLOADING -> {
                LinearProgressIndicator(
                    progress = { if (st.total > 0) st.percent / 100f else 0f },
                    modifier = Modifier.fillMaxWidth(), color = Tx.Accent,
                )
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        if (st.total > 0) "${st.percent}%  ·  ${st.bytes / 1_000_000} / ${st.total / 1_000_000} MB"
                        else "${st.bytes / 1_000_000} MB",
                        color = Tx.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    )
                    TextButton(onClick = onPause) { Text("Pause", color = Tx.Accent) }
                }
                st.error?.let { Text(it, color = Color(0xFFFFB74D), fontSize = 11.sp) }
            }
            BrainManager.Status.PAUSED, BrainManager.Status.ERROR -> {
                if (st.total > 0 || st.bytes > 0) {
                    LinearProgressIndicator(
                        progress = { if (st.total > 0) st.percent / 100f else 0f },
                        modifier = Modifier.fillMaxWidth(), color = Tx.Muted,
                    )
                    Text(
                        if (st.total > 0) "${st.percent}% saved" else "${st.bytes / 1_000_000} MB saved",
                        color = Tx.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp),
                    )
                }
                st.error?.let { Text(it, color = Tx.Danger, fontSize = 11.sp) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onDownload, colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent)) { Text("Resume") }
                    TextButton(onClick = onDelete) { Text("Cancel download", color = Tx.Danger) }
                }
            }
            BrainManager.Status.INSTALLED -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!active) {
                        Button(onClick = onUse, colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent)) { Text("Use this Brain") }
                    } else {
                        Text("✓ In use", color = Color(0xFF3DDC97), fontWeight = FontWeight.SemiBold)
                    }
                    TextButton(onClick = onDelete) { Text("Delete", color = Tx.Danger) }
                }
            }
            BrainManager.Status.NOT_INSTALLED -> {
                Button(onClick = onDownload, colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent)) {
                    Text("Download ${brain.sizeLabel}")
                }
            }
        }
    }
}

@Composable
private fun Tag(text: String, color: Color) {
    Text(
        text,
        color = color,
        fontSize = 10.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .padding(start = 8.dp)
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    )
}
