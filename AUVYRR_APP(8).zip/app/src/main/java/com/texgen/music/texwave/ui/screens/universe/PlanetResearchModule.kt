package com.texgen.music.texwave.ui.screens.universe

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

private val PRText = Color(0xFFF5F7FF)
private val PRMuted = Color(0xFF8D94A8)
private val PRBlack = Color(0xFF020308)
private val PRCard = Color(0xFF0D1018)
private val PRCyan = Tx.Accent2

/** Research-grade planet fetcher: NASA Exoplanet Archive + Wikimedia/Wikipedia enrichment, cached locally. */
data class ResearchPlanet(
    val name: String,
    val host: String,
    val radiusEarth: String,
    val massEarth: String,
    val orbitalPeriodDays: String,
    val semiMajorAu: String,
    val equilibriumTempK: String,
    val discoveryMethod: String,
    val discoveryYear: String,
    val facility: String,
    val ra: String,
    val dec: String,
    val stellarTempK: String,
    val stellarRadiusSun: String,
    val stellarMassSun: String,
    val eccentricity: String,
    val imageUrl: String,
    val imageSource: String,
    val summary: String,
    val confidence: String = "Measured/archived where available"
)

private class PlanetResearchRepository(private val context: Context) {
    private val http = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
    private val archive = "https://exoplanetarchive.ipac.caltech.edu/TAP/sync"
    private val cacheDir get() = File(context.cacheDir, "sonara_planet_research").apply { mkdirs() }

    suspend fun search(name: String): ResearchPlanet? = withContext(Dispatchers.IO) {
        val clean = name.trim().replace("'", "''")
        if (clean.isBlank()) return@withContext null
        val q = "SELECT TOP 1 pl_name,hostname,pl_rade,pl_masse,pl_orbper,pl_orbsmax,pl_eqt,discoverymethod,disc_year,disc_facility,ra,dec,st_teff,st_rad,st_mass,pl_orbeccen FROM pscomppars WHERE lower(pl_name)=lower('$clean') OR lower(hostname)=lower('$clean') OR lower(pl_name) LIKE lower('%$clean%') ORDER BY default_flag DESC"
        val url = "$archive?query=${URLEncoder.encode(q, "UTF-8")}&format=json"
        val response = http.newCall(Request.Builder().url(url).header("User-Agent", "AUVYRR-PlanetResearch/1.0").build()).execute()
        val body = response.use { if (!it.isSuccessful) return@withContext cached(name) else it.body?.string().orEmpty() }
        val arr = runCatching { org.json.JSONArray(body) }.getOrNull() ?: return@withContext cached(name)
        if (arr.length() == 0) return@withContext cached(name)
        val o = arr.getJSONObject(0)
        val planet = ResearchPlanet(
            name = s(o,"pl_name"), host=s(o,"hostname"), radiusEarth=s(o,"pl_rade"), massEarth=s(o,"pl_masse"),
            orbitalPeriodDays=s(o,"pl_orbper"), semiMajorAu=s(o,"pl_orbsmax"), equilibriumTempK=s(o,"pl_eqt"),
            discoveryMethod=s(o,"discoverymethod"), discoveryYear=s(o,"disc_year"), facility=s(o,"disc_facility"),
            ra=s(o,"ra"), dec=s(o,"dec"), stellarTempK=s(o,"st_teff"), stellarRadiusSun=s(o,"st_rad"),
            stellarMassSun=s(o,"st_mass"), eccentricity=s(o,"pl_orbeccen"), imageUrl="", imageSource="",
            summary="NASA Exoplanet Archive parameters retrieved live. Visual appearance is a scientific visualization derived from measured parameters, not a photograph.",
        )
        val enriched = enrichWikipedia(planet)
        save(enriched)
        enriched
    }

    suspend fun sync(planet: ResearchPlanet): ResearchPlanet = withContext(Dispatchers.IO) {
        val enriched = if (planet.imageUrl.isBlank() || planet.summary.startsWith("NASA Exoplanet Archive")) enrichWikipedia(planet) else planet
        if (enriched.imageUrl.isNotBlank()) runCatching { val f=File(cacheDir,key(enriched.name)+".jpg"); http.newCall(Request.Builder().url(enriched.imageUrl).header("User-Agent","AUVYRR-PlanetResearch/1.0").build()).execute().use { r -> if(r.isSuccessful) r.body?.bytes()?.let { f.writeBytes(it) } } }
        save(enriched)
        enriched
    }

    private fun enrichWikipedia(p: ResearchPlanet): ResearchPlanet {
        val title = URLEncoder.encode(p.name, "UTF-8")
        val req = Request.Builder().url("https://en.wikipedia.org/api/rest_v1/page/summary/$title").header("User-Agent","AUVYRR-PlanetResearch/1.0").build()
        val result = runCatching { http.newCall(req).execute().use { if (it.isSuccessful) it.body?.string().orEmpty() else "" } }.getOrDefault("")
        if (result.isBlank()) return p
        val o = runCatching { JSONObject(result) }.getOrNull() ?: return p
        val thumb = o.optJSONObject("thumbnail")?.optString("source").orEmpty()
        val extract = o.optString("extract").ifBlank { p.summary }
        return p.copy(imageUrl=thumb, imageSource="Wikipedia/Wikimedia", summary=extract)
    }

    private fun save(p: ResearchPlanet) { File(cacheDir, key(p.name)).writeText(JSONObject().apply { put("name",p.name);put("host",p.host);put("radius",p.radiusEarth);put("mass",p.massEarth);put("period",p.orbitalPeriodDays);put("a",p.semiMajorAu);put("teq",p.equilibriumTempK);put("method",p.discoveryMethod);put("year",p.discoveryYear);put("facility",p.facility);put("ra",p.ra);put("dec",p.dec);put("stTeff",p.stellarTempK);put("stRad",p.stellarRadiusSun);put("stMass",p.stellarMassSun);put("ecc",p.eccentricity);put("image",p.imageUrl);put("imageSource",p.imageSource);put("summary",p.summary) }.toString()) }
    private fun cached(name:String): ResearchPlanet? = runCatching { JSONObject(File(cacheDir,key(name)).readText()).let { o -> ResearchPlanet(o.optString("name"),o.optString("host"),o.optString("radius"),o.optString("mass"),o.optString("period"),o.optString("a"),o.optString("teq"),o.optString("method"),o.optString("year"),o.optString("facility"),o.optString("ra"),o.optString("dec"),o.optString("stTeff"),o.optString("stRad"),o.optString("stMass"),o.optString("ecc"),o.optString("image"),o.optString("imageSource"),o.optString("summary")) } }.getOrNull()
    private fun key(s:String)=s.lowercase().replace(Regex("[^a-z0-9]+"),"_")+".json"
    private fun s(o:JSONObject,k:String)=if(o.isNull(k)) "—" else o.optString(k,"—").takeIf{it!=""} ?: "—"
}

private fun researchOnline(context: Context): Boolean { val cm=context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false; val n=cm.activeNetwork ?: return false; val c=cm.getNetworkCapabilities(n) ?: return false; return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) }

@Composable
fun PlanetResearchScreen(onBack:(()->Unit)) {
    val context=LocalContext.current; val repo=remember{PlanetResearchRepository(context)}
    var query by remember{mutableStateOf("")}; var planet by remember{mutableStateOf<ResearchPlanet?>(null)}; var loading by remember{mutableStateOf(false)}; var syncing by remember{mutableStateOf(false)}; var online by remember{mutableStateOf(researchOnline(context))}; var message by remember{mutableStateOf("")}
    LaunchedEffect(Unit){ while(true){ online=researchOnline(context); delay(3000) } }
    Column(Modifier.fillMaxSize().background(PRBlack)){
        Row(Modifier.fillMaxWidth().padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Rounded.ArrowBack,null,tint=PRText)};Column(Modifier.weight(1f)){Text("PLANET RESEARCH",color=PRText,fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("Live science → instant local sync",color=PRMuted,fontSize=11.sp)};Icon(if(online)Icons.Rounded.Cloud else Icons.Rounded.CloudOff,null,tint=if(online)PRCyan else Color(0xFFFF7777),modifier=Modifier.size(20.dp))}
        Row(Modifier.padding(12.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF11141D)).padding(12.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Rounded.Search,null,tint=PRCyan,modifier=Modifier.size(19.dp));Spacer(Modifier.width(8.dp));BasicTextField(value=query,onValueChange={query=it},singleLine=true,textStyle=androidx.compose.ui.text.TextStyle(color=PRText,fontSize=14.sp),modifier=Modifier.weight(1f),decorationBox={inner->if(query.isEmpty())Text("Search a planet: Kepler-22 b, Proxima Centauri b…",color=PRMuted,fontSize=13.sp);inner()});Text("SEARCH",color=PRCyan,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.clickable{if(query.isNotBlank()){loading=true;message=""}})}
        LaunchedEffect(loading){if(loading){planet=repo.search(query);loading=false;if(planet==null)message=if(online)"No matching planet found in the archive." else "OFFLINE — no cached research package for this planet."}}
        if(!online) Text("OFFLINE — cached research packages remain available; live discovery data and new imagery require internet.",color=Color(0xFFFFB0B0),fontSize=11.sp,modifier=Modifier.padding(horizontal=14.dp,vertical=5.dp))
        planet?.let{p->
            LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
                item{Text(p.name,color=PRText,fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Host: ${p.host} · ${p.discoveryMethod} · ${p.discoveryYear}",color=PRCyan,fontSize=11.sp)}
                if(p.imageUrl.isNotBlank()) item{AsyncImage(model=p.imageUrl,contentDescription="Visual reference for ${p.name}",modifier=Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp)))}
                item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("Radius",p.radiusEarth,"R⊕");Stat("Mass",p.massEarth,"M⊕");Stat("Period",p.orbitalPeriodDays,"days");Stat("Tₑq",p.equilibriumTempK,"K")}}
                item{Section("RESEARCH DATA",listOf("Semi-major axis" to p.semiMajorAu,"Eccentricity" to p.eccentricity,"Host temperature" to p.stellarTempK,"Host radius" to p.stellarRadiusSun,"Host mass" to p.stellarMassSun,"Coordinates" to "${p.ra} / ${p.dec}","Discovery facility" to p.facility))}
                item{Section("SCIENTIFIC INTERPRETATION",listOf("Visual model" to "Generated from measured radius, temperature, stellar illumination and available classification; not direct imaging unless explicitly stated.","Evidence" to p.confidence,"Source" to "NASA Exoplanet Archive + ${if(p.imageSource.isBlank())"no image source" else p.imageSource}"))}
                item{Text("${p.summary}",color=PRMuted,fontSize=12.sp)}
                item{Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF101722)).clickable{syncing=true}.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(syncing)Icons.Rounded.Sync else Icons.Rounded.DownloadDone,null,tint=PRCyan);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(if(syncing)"SYNCING TO DEVICE…" else "SYNC TO DEVICE",color=PRText,fontSize=12.sp,fontWeight=FontWeight.Bold);Text("Cache research data and the available visual reference for instant offline reopening.",color=PRMuted,fontSize=10.sp)} } }
                item{if(syncing){LaunchedEffect(p.name){repo.sync(p);syncing=false;message="Synced locally — ready for instant offline reopen."}};if(message.isNotBlank())Text(message,color=PRCyan,fontSize=11.sp)}
            }
        } ?: Text(if(message.isBlank())"Enter a planet name to begin a live research fetch." else message,color=PRMuted,fontSize=12.sp,modifier=Modifier.padding(14.dp))
    }
}

@Composable private fun RowScope.Stat(a:String,b:String,c:String)=Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(PRCard).padding(10.dp)){Text(a,color=PRMuted,fontSize=9.sp);Text(if(b=="—")"—" else b,color=PRText,fontSize=13.sp,fontWeight=FontWeight.SemiBold);Text(c,color=PRCyan,fontSize=8.sp)}
@Composable private fun Section(title:String, rows:List<Pair<String,String>>)=Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PRCard).padding(12.dp)){Text(title,color=PRCyan,fontSize=10.sp,fontWeight=FontWeight.Bold);rows.forEach{(a,b)->Row(Modifier.fillMaxWidth().padding(top=8.dp)){Text(a,color=PRMuted,fontSize=10.sp,modifier=Modifier.weight(.42f));Text(b,color=PRText,fontSize=10.sp,modifier=Modifier.weight(.58f))}}}
