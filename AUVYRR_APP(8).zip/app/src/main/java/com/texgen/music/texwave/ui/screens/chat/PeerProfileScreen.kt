package com.texgen.music.texwave.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.chat.Profile
import com.texgen.music.texwave.data.chat.avatarModel
import com.texgen.music.texwave.data.chat.isUserOnline
import com.texgen.music.texwave.data.chat.lastSeenLabel
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.glassCard
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.glassShimmer
import com.texgen.music.texwave.ui.components.softFloat

@Composable
fun PeerProfileScreen(
    profile: Profile,
    onlineIds: Set<String>,
    recentlyActiveMs: Long = 0L,
    onBack: () -> Unit,
    onMessage: () -> Unit = onBack,
    onCall: () -> Unit = {},
) {
    val online = isUserOnline(profile.id, profile.lastSeenAt, onlineIds, recentlyActiveMs)
    val name = profile.displayName.ifBlank { profile.username }.ifBlank { "Member" }
    val handle = profile.username.takeIf { it.isNotBlank() }?.let { "@$it" } ?: ""

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(280.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Tx.Accent.copy(alpha = 0.35f), Tx.Accent2.copy(alpha = 0.12f), Color.Transparent),
                    ),
                ),
        )
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Text("PROFILE", color = Tx.Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(48.dp))
            }
            Spacer(Modifier.height(12.dp))
            ChatAvatar(
                name = name,
                imageUrl = profile.avatarModel,
                size = 112.dp,
                online = online,
            )
            Spacer(Modifier.height(16.dp))
            Text(name, color = Tx.Text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            if (handle.isNotBlank()) Text(handle, color = Tx.Muted, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                if (online) "● Active now" else lastSeenLabel(profile.lastSeenAt),
                color = if (online) Tx.Accent2 else Tx.Muted,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
            )
            profile.bio?.takeIf { it.isNotBlank() }?.let { bio ->
                Spacer(Modifier.height(16.dp))
                Text(
                    bio,
                    color = Tx.Text.copy(alpha = 0.9f),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x14FFFFFF))
                        .padding(14.dp),
                )
            }
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ProfileAction("Message", Icons.Rounded.Chat, Tx.Accent2, Modifier.weight(1f).appear(80), onMessage)
                ProfileAction("Call", Icons.Rounded.Call, Tx.Accent, Modifier.weight(1f).appear(140), onCall)
            }
            Spacer(Modifier.height(28.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .appear(120)
                    .softFloat(3f, 3600)
                    .glassCard(18)
                    .glassShimmer(18)
                    .padding(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.MusicNote, null, tint = Tx.Accent2, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Music identity", color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Share Resonance in chat to build a soundtrack together. Listening stays private until they share.",
                    color = Tx.Muted,
                    fontSize = 13.sp,
                )
            }
            Spacer(Modifier.height(16.dp))
            InfoRow("Status", if (online) "Present on AUVYRR" else "Away")
            Spacer(Modifier.height(48.dp))
        }
    }
}

@Composable
private fun ProfileAction(
    label: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0x44FFFFFF), accent.copy(alpha = 0.22f), Color(0x14FFFFFF))
                )
            )
            .border(1.dp, Brush.linearGradient(listOf(Color(0x66FFFFFF), accent.copy(alpha = 0.5f))), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = Tx.Muted, fontSize = 13.sp)
        Text(value, color = Tx.Text, fontSize = 13.sp)
    }
}
