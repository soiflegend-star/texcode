package com.texgen.music.texwave.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.AlarmStore
import com.texgen.music.texwave.data.AppTheme
import com.texgen.music.texwave.data.ThemeCatalog
import com.texgen.music.texwave.data.chat.ChatThemeStore
import com.texgen.music.texwave.ui.ref.AlarmPresets
import com.texgen.music.texwave.ui.ref.DefaultAlarmTheme
import com.texgen.music.texwave.ui.ref.Ref
import com.texgen.music.texwave.ui.ref.RefBackground
import com.texgen.music.texwave.ui.ref.refCard

private val ChatLooks = listOf(
    listOf(Color(0xFF000000), Color(0xFF0C0A18), Color(0xFF000000)),
    listOf(Color(0xFF000000), Color(0xFF0D0D12), Color(0xFF000000)),
    listOf(Color(0xFF1A0A08), Color(0xFF3D1A12), Color(0xFF0A0610)),
    listOf(Color(0xFF021018), Color(0xFF0A2A40), Color(0xFF020812)),
    listOf(Color(0xFF0A0618), Color(0xFF1A1040), Color(0xFF061820)),
)

/** One place to pick the look of the whole app, chats and alarms. */
@Composable
fun ThemesHubScreen(
    themeId: String,
    onSelectTheme: (String) -> Unit,
    onBack: () -> Unit,
    onOpenNotif: () -> Unit,
) {
    val context = LocalContext.current
    val alarmPrefs = remember { context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE) }
    var chatLook by remember { mutableIntStateOf(ChatThemeStore.defaultPreset(context)) }
    var alarmLook by remember { mutableStateOf(alarmPrefs.getString("default_theme", DefaultAlarmTheme) ?: DefaultAlarmTheme) }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(Color(0x14FFFFFF)).border(1.dp, Ref.Line, CircleShape).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Themes & looks", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Text("Changes apply instantly", color = Ref.Sub, fontSize = 12.sp)
                }
            }

            // ---- App theme
            SectionTitle("App theme", "Colours for every screen")
            ThemeCatalog.all.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { t -> ThemeCard(t, t.id == themeId, Modifier.weight(1f)) { onSelectTheme(t.id) } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            // ---- Chat look
            Spacer(Modifier.height(10.dp))
            SectionTitle("Chat look", "Default background for every chat. A look set inside a chat overrides it.")
            LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                itemsIndexed(ChatLooks) { i, colors ->
                    val sel = chatLook == i
                    val sh = RoundedCornerShape(18.dp)
                    Column(
                        Modifier.width(92.dp).clickable { chatLook = i; ChatThemeStore.setDefaultPreset(context, i) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(
                            Modifier.size(92.dp, 128.dp).clip(sh).background(Brush.verticalGradient(colors))
                                .border(if (sel) 2.dp else 1.dp, if (sel) Ref.Cyan else Ref.Line, sh),
                        ) {
                            // little bubbles so it reads as a chat
                            Box(Modifier.padding(10.dp).align(Alignment.TopStart).size(46.dp, 16.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x33FFFFFF)))
                            Box(Modifier.padding(10.dp).align(Alignment.CenterEnd).size(54.dp, 16.dp).clip(RoundedCornerShape(8.dp)).background(Brush.horizontalGradient(listOf(Ref.Purple, Ref.Cyan))))
                            if (sel) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).size(20.dp))
                        }
                        Text(ChatThemeStore.presetNames[i].substringBefore(" ("), color = if (sel) Color.White else Ref.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }

            // ---- Alarm picture
            Spacer(Modifier.height(22.dp))
            SectionTitle("Alarm picture", "Shown on the ringing screen. New alarms start with this one.")
            LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(AlarmPresets) { p ->
                    val key = "preset:" + p.id
                    val sel = alarmLook == key
                    val sh = RoundedCornerShape(18.dp)
                    Column(
                        Modifier.width(92.dp).clickable {
                            alarmLook = key
                            alarmPrefs.edit().putString("default_theme", key).apply()
                        },
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(Modifier.size(92.dp, 128.dp).clip(sh).border(if (sel) 2.dp else 1.dp, if (sel) Ref.Cyan else Ref.Line, sh)) {
                            Image(painterResource(p.res), p.label, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x99000000)))))
                            if (sel) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).size(20.dp))
                        }
                        Text(p.label, color = if (sel) Color.White else Ref.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 14.dp).clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(Ref.Purple, Ref.Cyan)))
                    .clickable {
                        val list = AlarmStore.load(context)
                        AlarmStore.save(context, list.map { it.copy(theme = alarmLook) })
                        Toast.makeText(context, if (list.isEmpty()) "No alarms yet. New ones will use this picture." else "Applied to ${list.size} alarm(s)", Toast.LENGTH_SHORT).show()
                    }
                    .padding(horizontal = 20.dp, vertical = 11.dp),
            ) { Text("Apply to all my alarms", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }

            // ---- Notification style
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).refCard(20.dp).clickable(onClick = onOpenNotif).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Notifications, null, tint = Ref.Cyan, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Notification style", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Text("Animated player notification looks", color = Ref.Sub, fontSize = 12.sp)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = Ref.Sub)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, sub: String) {
    Column(Modifier.padding(horizontal = 16.dp).padding(top = 8.dp, bottom = 12.dp)) {
        Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Text(sub, color = Ref.Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun ThemeCard(t: AppTheme, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val sh = RoundedCornerShape(20.dp)
    val bg = Color(t.background.toInt())
    val surface = Color(t.surface.toInt())
    val a1 = Color(t.primary.toInt())
    val a2 = Color(t.secondary.toInt())
    Column(
        modifier.clip(sh).background(Brush.verticalGradient(listOf(surface, bg)))
            .border(if (selected) 2.dp else 1.dp, if (selected) a1 else Color(0x22FFFFFF), sh)
            .clickable(onClick = onClick).padding(14.dp),
    ) {
        // mini player preview
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(Brush.linearGradient(listOf(a1, a2))))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Box(Modifier.fillMaxWidth(0.8f).height(7.dp).clip(CircleShape).background(Color(0x55FFFFFF)))
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth(0.5f).height(5.dp).clip(CircleShape).background(Color(0x33FFFFFF)))
            }
            if (selected) Box(Modifier.size(22.dp).clip(CircleShape).background(a1), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x22FFFFFF))) {
            Box(Modifier.fillMaxWidth(0.62f).height(6.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(a2, a1))))
        }
        Spacer(Modifier.height(12.dp))
        Text(t.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(t.description, color = Color(0xFF9AA0B8), fontSize = 11.sp, maxLines = 1)
    }
}
