package com.texgen.music.texwave.arena.data.supabase

/**
 * Thin boundary over the existing AUVYRR Supabase stack.
 * Arena never constructs its own GoTrue client or stores service-role keys.
 *
 * Wire this from AUVYRR by implementing with the shared `supabase` instance:
 *
 * ```
 * object TexwaveArenaClient : SupabaseArenaClient {
 *   override suspend fun <T> rpc(name: String, params: Map<String, Any?>): T = ...
 *   override suspend fun <T> from(table: String): PostgrestQueryBuilder = ...
 *   override fun currentUserId(): String? = supabase.auth.currentUserOrNull()?.id
 * }
 * ```
 */
interface SupabaseArenaClient {
    fun currentUserId(): String?
    fun currentUsername(): String?

    /** Call a SECURITY DEFINER RPC. Params are JSON-serializable. */
    suspend fun rpcRaw(function: String, params: Map<String, Any?> = emptyMap()): String

    /** Select rows as JSON array string from an arena_* table with optional filters. */
    suspend fun select(
        table: String,
        columns: String = "*",
        filters: Map<String, String> = emptyMap(),
        order: String? = null,
        limit: Int? = null,
        offset: Int? = null
    ): String
}
