package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Speaker
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.player.EqualizerController
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.ref.Ref
import com.texgen.music.texwave.ui.ref.RefBackground
import com.texgen.music.texwave.ui.ref.SongThumb
import com.texgen.music.texwave.ui.ref.refCard
import kotlinx.coroutines.delay

/**
 * Premium equalizer: drag the glowing nodes on the curve, pick a preset, add bass / surround / loudness.
 * Everything is live on the audio session of whatever is playing.
 */
@Composable
fun EqualizerScreen(
    eq: EqualizerController,
    onBack: () -> Unit,
    player: PlayerState? = null,
    onPrevious: () -> Unit = {},
    onToggle: () -> Unit = {},
    onNext: () -> Unit = {},
) {
    // The audio session only exists once something has played; keep trying so the controls become live.
    var attached by remember { mutableStateOf(eq.hasEffects) }
    LaunchedEffect(Unit) {
        while (true) {
            eq.ensureAttached()
            attached = eq.hasEffects
            delay(1200)
        }
    }
    var enabled by remember { mutableStateOf(eq.isEnabled()) }
    var preset by remember { mutableIntStateOf(-1) }
    val bandCount = eq.bandCount.coerceIn(3, 10)
    val range = eq.bandLevelRange
    val minL = range[0].toFloat()
    val maxL = range[1].toFloat()
    var levels by remember(attached, bandCount) { mutableStateOf(List(bandCount) { eq.getBandLevel(it).toFloat() }) }
    var bass by remember { mutableFloatStateOf(eq.bassStrength().toFloat()) }
    var virt by remember { mutableFloatStateOf(eq.virtStrength().toFloat()) }
    var loud by remember { mutableFloatStateOf(eq.loudGain().toFloat()) }

    fun turnOn() { if (!enabled) { enabled = true; eq.setEnabled(true) } }
    fun setBand(i: Int, v: Float) {
        val c = v.coerceIn(minL, maxL)
        levels = levels.toMutableList().also { it[i] = c }
        eq.setBandLevel(i, c.toInt()); turnOn(); preset = -1
    }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(bottom = 28.dp)) {
            // Header
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(Color(0x14FFFFFF)).border(1.dp, Ref.Line, CircleShape).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(22.dp)) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Equalizer", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (attached) "Live on your music" else "Play a song to activate", color = if (attached) Ref.Cyan else Ref.Muted, fontSize = 12.sp)
                }
                Switch(
                    checked = enabled, onCheckedChange = { enabled = it; eq.setEnabled(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Ref.Cyan, checkedThumbColor = Color.White, uncheckedTrackColor = Ref.Card, uncheckedBorderColor = Ref.Line),
                )
            }

            // Mini player
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).refCard(18.dp).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SongThumb(player?.current, Modifier.size(50.dp), RoundedCornerShape(12.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(player?.current?.title ?: "Nothing playing", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(player?.current?.artist ?: "Pick a song to hear the changes", color = Ref.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(42.dp).clickable(onClick = onPrevious).padding(8.dp))
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Ref.Cyan, Ref.Purple))).clickable(onClick = onToggle),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(if (player?.isPlaying == true) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(26.dp))
                }
                Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(42.dp).clickable(onClick = onNext).padding(8.dp))
            }

            // Presets
            Spacer(Modifier.height(18.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(EqualizerController.PRESET_NAMES) { index, name ->
                    val sel = preset == index
                    val sh = RoundedCornerShape(50)
                    Text(
                        name, color = if (sel) Color.White else Ref.Muted, fontSize = 14.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.clip(sh)
                            .background(if (sel) Brush.horizontalGradient(listOf(Ref.Cyan, Ref.Purple)) else Brush.horizontalGradient(listOf(Color(0x14FFFFFF), Color(0x0AFFFFFF))))
                            .border(1.dp, if (sel) Color.Transparent else Ref.Line, sh)
                            .clickable {
                                preset = index; eq.applyPreset(index); enabled = true
                                levels = List(bandCount) { eq.getBandLevel(it).toFloat() }
                            }
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                    )
                }
            }

            // Curve card
            Spacer(Modifier.height(18.dp))
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).refCard(24.dp, hot = enabled).padding(start = 8.dp, end = 14.dp, top = 16.dp, bottom = 14.dp)) {
                val mid = (minL + maxL) / 2f
                val half = (maxL - minL) / 2f
                val topDb = (maxL / 100).toInt()
                val botDb = (minL / 100).toInt()
                val graphH = 190.dp
                Row(Modifier.fillMaxWidth().height(graphH)) {
                    Column(Modifier.width(34.dp).height(graphH), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.End) {
                        Text("+${topDb}", color = Ref.Sub, fontSize = 10.sp)
                        Text("0", color = Ref.Sub, fontSize = 10.sp)
                        Text("$botDb", color = Ref.Sub, fontSize = 10.sp)
                    }
                    Spacer(Modifier.width(6.dp))
                    Canvas(
                        Modifier.weight(1f).height(graphH)
                            .pointerInput(bandCount, minL, maxL) {
                                detectTapGestures { o ->
                                    val i = ((o.x / size.width) * bandCount).toInt().coerceIn(0, bandCount - 1)
                                    setBand(i, maxL - (o.y / size.height).coerceIn(0f, 1f) * (maxL - minL))
                                }
                            }
                            .pointerInput(bandCount, minL, maxL) {
                                var active = 0
                                detectDragGestures(
                                    onDragStart = { o -> active = ((o.x / size.width) * bandCount).toInt().coerceIn(0, bandCount - 1) },
                                ) { change, _ ->
                                    change.consume()
                                    setBand(active, maxL - (change.position.y / size.height).coerceIn(0f, 1f) * (maxL - minL))
                                }
                            },
                    ) {
                        val w = size.width; val h = size.height
                        val dash = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 6.dp.toPx()))
                        for (k in 0..4) {
                            val y = h * k / 4f
                            drawLine(if (k == 2) Ref.LineHi else Ref.Line.copy(alpha = 0.7f), Offset(0f, y), Offset(w, y), 1.dp.toPx(), pathEffect = if (k == 2) null else dash)
                        }
                        for (i in 0 until bandCount) {
                            val x = w * (i + 0.5f) / bandCount
                            drawLine(Ref.Line.copy(alpha = 0.45f), Offset(x, 0f), Offset(x, h), 1.dp.toPx(), pathEffect = dash)
                        }
                        val pts = levels.mapIndexed { i, v ->
                            Offset(w * (i + 0.5f) / bandCount, h / 2f - ((v - mid) / half) * (h / 2f - 10.dp.toPx()))
                        }
                        if (pts.size > 1) {
                            val line = Path().apply {
                                moveTo(0f, pts.first().y); lineTo(pts.first().x, pts.first().y)
                                for (i in 1 until pts.size) {
                                    val a = pts[i - 1]; val b = pts[i]
                                    cubicTo((a.x + b.x) / 2, a.y, (a.x + b.x) / 2, b.y, b.x, b.y)
                                }
                                lineTo(w, pts.last().y)
                            }
                            val fill = Path().apply { addPath(line); lineTo(w, h); lineTo(0f, h); close() }
                            val on = enabled
                            drawPath(fill, Brush.verticalGradient(listOf(Ref.Cyan.copy(alpha = if (on) 0.34f else 0.12f), Color.Transparent)))
                            // glow underlay then crisp line
                            drawPath(line, Ref.Cyan.copy(alpha = if (on) 0.35f else 0.1f), style = Stroke(9.dp.toPx(), cap = StrokeCap.Round))
                            drawPath(line, Brush.horizontalGradient(listOf(Ref.Purple, Ref.Cyan, Ref.Lavender)), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                        }
                        pts.forEach { p ->
                            drawCircle(Ref.Cyan.copy(alpha = if (enabled) 0.28f else 0.1f), 13.dp.toPx(), p)
                            drawCircle(Color.White, 6.dp.toPx(), p)
                            drawCircle(if (enabled) Ref.Cyan else Ref.Faint, 3.5.dp.toPx(), p)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().padding(start = 40.dp)) {
                    for (i in 0 until bandCount) {
                        val f = eq.getCenterFreq(i)
                        val label = if (f >= 1000) (if (f % 1000 == 0) "${f / 1000}kHz" else "%.1fkHz".format(f / 1000f)) else "${f}Hz"
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(label, color = Ref.Sub, fontSize = 10.sp, maxLines = 1)
                            Text("${(levels.getOrElse(i) { 0f } / 100).let { if (it > 0) "+%.0f".format(it) else "%.0f".format(it) }} dB", color = if (enabled) Ref.Cyan else Ref.Faint, fontSize = 10.sp)
                        }
                    }
                }
            }

            // Boosters
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).refCard(24.dp).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Booster(Icons.Rounded.GraphicEq, "Bass Boost", bass / 1000f, "+${"%.0f".format(bass / 1000f * 12f)} dB", enabled) { bass = it * 1000f; eq.setBass(bass.toInt()); turnOn() }
                Booster(Icons.Rounded.Headphones, "Virtualizer", virt / 1000f, "+${"%.0f".format(virt / 1000f * 12f)} dB", enabled) { virt = it * 1000f; eq.setVirtualizer(virt.toInt()); turnOn() }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Speaker, null, tint = Ref.Cyan, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Loudness", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(if (loud > 0) "+${(loud / 100).toInt()} dB gain" else "Off", color = Ref.Sub, fontSize = 12.sp)
                    }
                    Switch(
                        checked = loud > 0f,
                        onCheckedChange = { on -> loud = if (on) 600f else 0f; eq.setLoudness(loud.toInt()); if (on) turnOn() },
                        colors = SwitchDefaults.colors(checkedTrackColor = Ref.Cyan, checkedThumbColor = Color.White, uncheckedTrackColor = Ref.Card, uncheckedBorderColor = Ref.Line),
                    )
                }
                if (loud > 0f) {
                    GlowSlider(loud / 1000f, enabled) { loud = it * 1000f; eq.setLoudness(loud.toInt()); turnOn() }
                }
            }
            Text(
                "Changes apply instantly and are remembered.", color = Ref.Faint, fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

@Composable
private fun Booster(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: Float, shown: String, active: Boolean, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Ref.Cyan, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(shown, color = Ref.Muted, fontSize = 14.sp)
        }
        Spacer(Modifier.height(10.dp))
        GlowSlider(value, active, onChange)
    }
}

/** Gradient track + glowing thumb. value is 0..1. */
@Composable
private fun GlowSlider(value: Float, active: Boolean, onChange: (Float) -> Unit) {
    Canvas(
        Modifier.fillMaxWidth().height(28.dp)
            .pointerInput(Unit) { detectTapGestures { o -> onChange((o.x / size.width).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectHorizontalDragGestures { c, _ -> c.consume(); onChange((c.position.x / size.width).coerceIn(0f, 1f)) } },
    ) {
        val cy = size.height / 2
        val pad = 10.dp.toPx()
        val w = size.width - pad * 2
        val x = pad + w * value.coerceIn(0f, 1f)
        drawLine(Ref.Line, Offset(pad, cy), Offset(pad + w, cy), 5.dp.toPx(), StrokeCap.Round)
        if (x > pad) drawLine(
            Brush.horizontalGradient(listOf(Ref.Purple, Ref.Cyan), startX = pad, endX = pad + w).takeIf { active } ?: Brush.horizontalGradient(listOf(Ref.Faint, Ref.Faint)),
            Offset(pad, cy), Offset(x, cy), 5.dp.toPx(), StrokeCap.Round,
        )
        drawCircle(Ref.Cyan.copy(alpha = if (active) 0.3f else 0.1f), 12.dp.toPx(), Offset(x, cy))
        drawCircle(Color.White, 7.dp.toPx(), Offset(x, cy))
    }
}
