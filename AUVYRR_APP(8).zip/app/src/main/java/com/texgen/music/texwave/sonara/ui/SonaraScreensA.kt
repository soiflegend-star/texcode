package com.texgen.music.texwave.sonara.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.sonara.data.Track
import com.texgen.music.texwave.sonara.data.catalog.RecommendationEngine
import kotlinx.coroutines.delay

internal typealias OpenList = (String, String, List<Track>) -> Unit

@Composable
internal fun Vinyl(diameter: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier.size(diameter).drawBehind {
            val c = center
            val r = this.size.minDimension / 2f
            drawCircle(Color(0xFF0B0B10), r, c)
            for (i in 1..9) drawCircle(Color.White.copy(alpha = if (i % 3 == 0) 0.16f else 0.07f), r * (0.34f + i * 0.066f), c, style = Stroke(1.dp.toPx()))
            drawCircle(Brush.linearGradient(listOf(SC.Accent2, SC.Accent)), r * 0.3f, c)
            drawCircle(Color(0xFF0B0B10), r * 0.06f, c)
        },
    )
}

// ───────────────────────────── HOME

@Composable
internal fun HomeScreen(
    vm: SonaraViewModel, s: SonaraUi, onExit: () -> Unit, onSearch: () -> Unit,
    open: OpenList, play: (Track, List<Track>) -> Unit,
) {
    val pb by vm.playback.collectAsState()
    val user by vm.user.collectAsState()
    val premium by vm.premiumDemo.collectAsState(initial = false)
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val greet = if (hour < 12) "Good morning!" else if (hour < 18) "Good afternoon!" else "Good evening!"
    val recents = s.recents.ifEmpty { vm.trending(s) }.take(10)
    val forYou = vm.forYou(s)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.statusBarsPadding().padding(18.dp, 14.dp, 12.dp, 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hello, ${user?.displayName?.substringBefore(' ') ?: "there"}" + if (premium) " 👑" else "",
                        color = SC.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(greet, color = SC.Sub, fontSize = 13.sp)
                }
                IconBtn(Icons.Filled.Close, "Close Sonara", onExit)
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp).glass(16.dp).clickable { onSearch() }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Search, null, tint = SC.Sub, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Search songs, artists...", color = SC.Sub, fontSize = 14.sp)
            }
        }
        if (s.loading && s.catalogue.isEmpty()) item {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = SC.Accent) }
        }
        item {
            Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp).height(132.dp).glass(22.dp)) {
                Vinyl(150.dp, Modifier.align(Alignment.CenterEnd).offset(x = 34.dp))
                Column(Modifier.align(Alignment.CenterStart).padding(start = 20.dp)) {
                    Text("Feel the\nMusic", color = SC.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 28.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("With AUVYRR", color = SC.Sub, fontSize = 12.sp)
                }
                Box(Modifier.align(Alignment.CenterEnd).padding(end = 38.dp)) {
                    RoundPlay({ if (forYou.isNotEmpty()) vm.playAll(forYou, 0) }, 44.dp)
                }
            }
        }
        item { SectionTitle("Recently Played", action = "See All") { open("Recently Played", "Playlist", recents) } }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(recents, key = { it.id }) { t -> SquareCard(t.title, t.artist, t.artworkUrl, t.id, 104.dp) { play(t, recents) } }
            }
        }
        item { SectionTitle("Your Playlists", action = "See All") { open("Liked Songs", "Playlist", s.liked) } }
        item {
            Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PlaylistCard("My Favourites", "${s.liked.size} Songs", s.liked.firstOrNull()?.artworkUrl, "fav",
                    onOpen = { open("Liked Songs", "Playlist", s.liked) }, onPlay = { vm.playAll(s.liked, 0) })
                s.playlists.take(3).forEach { p ->
                    val tr = p.trackIds.mapNotNull { s.byId(it) }
                    PlaylistCard(p.name, "${tr.size} Songs", tr.firstOrNull()?.artworkUrl, p.id,
                        onOpen = { open(p.name, "Playlist", tr) }, onPlay = { vm.playAll(tr, 0) })
                }
            }
        }
        rail("Made for you", forYou, open, play)
        s.onlineRows.forEach { (t, tr) -> rail(t, tr, open, play) }
        rail("Discover weekly", vm.discoverWeekly(s), open, play)
        rail("New releases", vm.newReleases(s), open, play)
        val artists = vm.artists(s)
        if (artists.isNotEmpty()) item {
            SectionTitle("Artists")
            LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(artists.take(15)) { (name, tr) ->
                    SquareCard(name, "Artist", tr.firstOrNull()?.artworkUrl, name, 88.dp, round = true) { open(name, "Artist", tr) }
                }
            }
        }
    }
}

private fun LazyListScope.rail(title: String, tracks: List<Track>, open: OpenList, play: (Track, List<Track>) -> Unit) {
    if (tracks.isEmpty()) return
    item {
        SectionTitle(title, action = "See All") { open(title, "Playlist", tracks) }
        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(tracks.take(15), key = { it.id }) { t -> SquareCard(t.title, t.artist, t.artworkUrl, t.id, 112.dp) { play(t, tracks) } }
        }
    }
}

@Composable
private fun PlaylistCard(name: String, sub: String, art: String?, seed: String, onOpen: () -> Unit, onPlay: () -> Unit) {
    Row(Modifier.fillMaxWidth().glass(18.dp).clickable { onOpen() }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Cover(art, seed, 54.dp, 12.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = SC.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("♡ $sub", color = SC.Sub, fontSize = 12.sp)
        }
        RoundPlay(onPlay, 38.dp)
    }
}

// ───────────────────────────── SEARCH

private val trendingDefaults = listOf("Phonk", "Lo-Fi", "Chill", "Workout", "Hip-Hop", "Electronic")

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SearchScreen(vm: SonaraViewModel, s: SonaraUi, open: OpenList, onMore: (Track) -> Unit) {
    var q by remember { mutableStateOf("") }
    val pb by vm.playback.collectAsState()
    LaunchedEffect(q) { delay(400); vm.searchOnline(q) }
    val results = remember(q, s.catalogue, s.local, s.onlineResults) { (vm.search(s, q) + s.onlineResults).distinctBy { it.id } }
    val trending = remember(s.onlineRows, s.catalogue) {
        (s.onlineRows.firstOrNull()?.second ?: vm.trending(s)).map { it.artist }.distinct().take(6) + trendingDefaults
    }.distinct().take(8)
    val artists = remember(s.all) { RecommendationEngine.artistsFrom(s.all).take(12) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Search", null)
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text("Search songs, artists...", color = SC.Sub) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = SC.Sub) },
            trailingIcon = { if (q.isNotEmpty()) Icon(Icons.Filled.Close, "Clear", tint = SC.Sub, modifier = Modifier.clickable { q = "" }) },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SC.CardHi.copy(alpha = 0.5f), unfocusedContainerColor = SC.CardHi.copy(alpha = 0.35f),
                focusedBorderColor = SC.Accent, unfocusedBorderColor = SC.Line,
                focusedTextColor = SC.Text, unfocusedTextColor = SC.Text, cursorColor = SC.Accent,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
        )
        Spacer(Modifier.height(6.dp))
        if (q.isBlank()) {
            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                item { SectionTitle("Trending Searches") }
                item {
                    FlowRow(Modifier.padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        trending.forEach { Chip(it, false) { q = it } }
                    }
                }
                if (artists.isNotEmpty()) item {
                    SectionTitle("Popular Artists")
                    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(artists) { (name, tr) -> SquareCard(name, "Artist", tr.firstOrNull()?.artworkUrl, name, 88.dp, round = true) { open(name, "Artist", tr) } }
                    }
                }
                item {
                    Text(
                        "Search finds full songs from Audius" +
                            (if (com.texgen.music.texwave.sonara.SonaraConfig.JAMENDO_CLIENT_ID.isNotBlank()) " and Jamendo" else "") +
                            ", plus 30-second previews of almost any song.",
                        color = SC.Sub, fontSize = 12.sp, modifier = Modifier.padding(18.dp, 18.dp, 18.dp, 0.dp),
                    )
                }
            }
        } else if (results.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
                if (s.searching) CircularProgressIndicator(color = SC.Accent) else Text("No results for \"$q\"", color = SC.Sub)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                if (s.searching) item { LinearProgressIndicator(color = SC.Accent, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)) }
                items(results, key = { it.id }) { t ->
                    TrackRow(t, t.id in s.likedIds, pb.currentTrack?.id == t.id, { vm.play(t, results) }, { vm.toggleLike(t.id) }, { onMore(t) })
                }
            }
        }
    }
}

// ───────────────────────────── LIBRARY

@Composable
internal fun LibraryScreen(vm: SonaraViewModel, s: SonaraUi, open: OpenList, onMore: (Track) -> Unit) {
    var section by remember { mutableStateOf("Songs") }
    var newDialog by remember { mutableStateOf(false) }
    val pb by vm.playback.collectAsState()
    val dl by vm.downloadIds.collectAsState(initial = emptySet())
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.checkLocalPermission() }

    Column(Modifier.fillMaxSize()) {
        TopBar("Your Library", null) { IconBtn(Icons.Filled.Add, "New playlist", { newDialog = true }) }
        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("Songs", "Artists", "Albums", "Genres")) { c -> Chip(c, section == c) { section = c } }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
            item { LibRow("My Favourites", "${s.liked.size} Songs", Icons.Filled.Favorite, true) { open("Liked Songs", "Playlist", s.liked) } }
            item { LibRow("Recently Played", "${s.recents.size} Songs", Icons.Filled.History) { open("Recently Played", "Playlist", s.recents) } }
            item { LibRow("Downloads", "${dl.size} Songs", Icons.Filled.Download) { open("Downloads", "Offline", s.all.filter { it.id in dl }) } }
            item {
                LibRow("On this phone", if (s.hasLocalPermission) "${s.local.size} Songs" else "Tap to allow access", Icons.Filled.PhoneAndroid) {
                    if (s.hasLocalPermission) open("On this phone", "Local files", s.local)
                    else permLauncher.launch(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
            item { Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp).height(1.dp).background(SC.Line)) }
            when (section) {
                "Songs" -> {
                    items(s.playlists, key = { "pl_" + it.id }) { p ->
                        val tr = p.trackIds.mapNotNull { s.byId(it) }
                        LibRow(p.name, "${tr.size} Songs", Icons.Filled.QueueMusic) { open(p.name, "Playlist", tr) }
                    }
                    val all = s.all.take(150)
                    items(all, key = { "t_" + it.id }) { t ->
                        TrackRow(t, t.id in s.likedIds, pb.currentTrack?.id == t.id, { vm.play(t, all) }, { vm.toggleLike(t.id) }, { onMore(t) })
                    }
                }
                "Artists" -> items(RecommendationEngine.artistsFrom(s.all), key = { "a_" + it.first }) { (name, tr) ->
                    LibRow(name, "${tr.size} Songs", Icons.Filled.Person) { open(name, "Artist", tr) }
                }
                "Albums" -> items(RecommendationEngine.albumsFrom(s.all), key = { "al_" + it.first }) { (name, tr) ->
                    LibRow(name, "${tr.firstOrNull()?.artist ?: ""} · ${tr.size} Songs", Icons.Filled.Album) { open(name, "Album", tr) }
                }
                else -> items(s.all.mapNotNull { it.genre?.takeIf { g -> g.isNotBlank() } }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.map { it.key }, key = { "g_" + it }) { g ->
                    LibRow(g, "Genre", Icons.Filled.MusicNote) { open(g, "Genre", s.all.filter { it.genre.equals(g, true) }) }
                }
            }
        }
    }
    if (newDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newDialog = false }, containerColor = SC.Card,
            title = { Text("New playlist", color = SC.Text) },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("My playlist") }) },
            confirmButton = { TextButton(onClick = { if (name.isNotBlank()) vm.createPlaylist(name.trim()); newDialog = false }) { Text("Create", color = SC.Accent2) } },
            dismissButton = { TextButton(onClick = { newDialog = false }) { Text("Cancel", color = SC.Sub) } },
        )
    }
}

@Composable
internal fun LibRow(title: String, sub: String, icon: ImageVector, hot: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(18.dp, 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(14.dp))
                .background(if (hot) Brush.linearGradient(listOf(SC.Accent2, SC.Accent)) else Brush.linearGradient(listOf(SC.CardHi, SC.CardHi)))
                .border(1.dp, SC.Line, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = if (hot) Color.White else SC.Text, modifier = Modifier.size(24.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = SC.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = SC.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Filled.MoreVert, null, tint = SC.Sub, modifier = Modifier.size(20.dp))
    }
}

// ───────────────────────────── COLLECTION / ALBUM

@Composable
internal fun CollectionScreen(vm: SonaraViewModel, s: SonaraUi, c: SRoute.Collection, onBack: () -> Unit, onMore: (Track) -> Unit) {
    val pb by vm.playback.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth()) { IconBtn(Icons.Filled.ArrowBack, "Back", onBack) }
                Spacer(Modifier.height(6.dp))
                Cover(c.tracks.firstOrNull()?.artworkUrl, c.title, 180.dp, 22.dp, Modifier.border(1.dp, SC.Line, RoundedCornerShape(22.dp)))
                Spacer(Modifier.height(14.dp))
                Text(c.title, color = SC.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${c.subtitle} · ${c.tracks.size} songs", color = SC.Sub, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Icon(Icons.Filled.Shuffle, "Shuffle", tint = SC.Text,
                        modifier = Modifier.size(46.dp).glass(23.dp).clickable { vm.shufflePlay(c.tracks) }.padding(12.dp))
                    RoundPlay({ vm.playAll(c.tracks, 0) }, 58.dp)
                }
            }
        }
        if (c.tracks.isEmpty()) item { Text("Nothing here yet.", color = SC.Sub, modifier = Modifier.padding(24.dp)) }
        itemsIndexed(c.tracks, key = { i, t -> "${t.id}#$i" }) { i, t ->
            TrackRow(t, t.id in s.likedIds, pb.currentTrack?.id == t.id, { vm.playAll(c.tracks, i) }, { vm.toggleLike(t.id) }, { onMore(t) }, index = i + 1)
        }
    }
}

// ───────────────────────────── ARTIST

@Composable
internal fun ArtistScreen(vm: SonaraViewModel, s: SonaraUi, a: SRoute.Artist, onBack: () -> Unit, open: OpenList, onMore: (Track) -> Unit) {
    val pb by vm.playback.collectAsState()
    val tracks = remember(a.name, s.all) { vm.byArtist(s, a.name).ifEmpty { a.tracks } }
    var tab by remember { mutableStateOf("Popular") }
    val following = SonaraPrefs.followed.contains(a.name)
    val albums = remember(tracks) { tracks.filter { it.album.isNotBlank() }.groupBy { it.album }.toList() }
    val singles = remember(tracks) { tracks.filter { it.album.isBlank() } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth()) { IconBtn(Icons.Filled.ArrowBack, "Back", onBack) }
                Box(Modifier.size(132.dp).border(2.dp, Brush.linearGradient(listOf(SC.Accent2, SC.Accent)), CircleShape).padding(5.dp)) {
                    Cover(tracks.firstOrNull()?.artworkUrl, a.name, 122.dp, 61.dp)
                }
                Spacer(Modifier.height(12.dp))
                Text(a.name, color = SC.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${tracks.size} songs in your library", color = SC.Sub, fontSize = 12.sp)
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(
                        Modifier.width(150.dp).height(44.dp).clip(RoundedCornerShape(22.dp))
                            .background(if (following) SC.Accent.copy(alpha = 0.22f) else SC.CardHi.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
                            .border(1.dp, if (following) SC.Accent else SC.Line, RoundedCornerShape(22.dp))
                            .clickable { SonaraPrefs.toggleFollow(a.name) },
                        contentAlignment = Alignment.Center,
                    ) { Text(if (following) "Following" else "Follow", color = SC.Text, fontWeight = FontWeight.SemiBold) }
                    RoundPlay({ vm.playAll(tracks, 0) }, 46.dp)
                }
            }
        }
        item {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Popular", "Albums", "Singles").forEach { Chip(it, tab == it) { tab = it } }
            }
        }
        when (tab) {
            "Albums" -> items(albums, key = { "al_" + it.first }) { (name, tr) ->
                LibRow(name, "${tr.size} Songs", Icons.Filled.Album) { open(name, "Album", tr) }
            }
            else -> {
                val list = if (tab == "Singles") singles else tracks
                itemsIndexed(list, key = { i, t -> "${t.id}#$i" }) { i, t ->
                    TrackRow(t, t.id in s.likedIds, pb.currentTrack?.id == t.id, { vm.playAll(list, i) }, { vm.toggleLike(t.id) }, { onMore(t) }, index = i + 1)
                }
            }
        }
    }
}
