package com.texgen.music.texwave.sonara.data.download

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.downloadStore by preferencesDataStore("sonara_downloads")

class DownloadStore(private val context: Context) {
    private val idsKey = stringSetPreferencesKey("download_ids")
    val downloadIds: Flow<Set<String>> =
        context.downloadStore.data.map { it[idsKey] ?: emptySet() }

    suspend fun requestDownload(trackId: String) {
        context.downloadStore.edit { prefs ->
            val set = prefs[idsKey]?.toMutableSet() ?: mutableSetOf()
            set.add(trackId)
            prefs[idsKey] = set
        }
    }

    suspend fun removeDownload(trackId: String) {
        context.downloadStore.edit { prefs ->
            val set = prefs[idsKey]?.toMutableSet() ?: mutableSetOf()
            set.remove(trackId)
            prefs[idsKey] = set
        }
    }
}
