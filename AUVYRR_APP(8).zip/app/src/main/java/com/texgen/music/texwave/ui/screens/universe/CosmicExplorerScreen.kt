package com.texgen.music.texwave.ui.screens.universe

import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

private val CxBg = Color(0xFF020308)
private val CxPanel = Color(0xE60A0F1A)
private val CxText = Color(0xFFF5F7FF)
private val CxMuted = Color(0xFF8D96AD)
private val CxCyan = Color(0xFF45D9FF)
private val CxViolet = Color(0xFF9B7CFF)
private val CxGreen = Color(0xFF46E7A2)
private val CxRed = Color(0xFFFF6B7A)

/** One entry of the built-in cosmos catalogue. */
data class CosmicBody(
    val name: String,
    val type: String,
    val subtitle: String,
    val description: String,
    val facts: List<Pair<String, String>>,
    val color: Color,
    val star: Boolean = false,
)

private val Catalogue = listOf(
    CosmicBody("Sun", "STAR", "G-type main-sequence star", "The star at the center of our Solar System, holding 99.8% of its mass.", listOf("Distance" to "1 AU", "Age" to "4.6 billion years", "Surface" to "~5,500 °C"), Color(0xFFFFC857), true),
    CosmicBody("Mercury", "PLANET", "Smallest world", "A fast, cratered rocky planet with extreme temperature swings.", listOf("Year" to "88 days", "Gravity" to "3.70 m/s²", "Moons" to "0"), Color(0xFFB7A99A)),
    CosmicBody("Venus", "PLANET", "Cloud-covered world", "A dense CO₂ atmosphere produces an extreme greenhouse environment.", listOf("Year" to "224.7 days", "Surface" to "~465 °C", "Moons" to "0"), Color(0xFFE8B36C)),
    CosmicBody("Earth", "PLANET", "Our home world", "A water-rich rocky planet with a nitrogen-oxygen atmosphere.", listOf("Year" to "365.25 days", "Gravity" to "9.81 m/s²", "Moons" to "1"), Color(0xFF4FA7FF)),
    CosmicBody("Mars", "PLANET", "The red planet", "A cold desert world marked by iron-rich dust and ancient valleys.", listOf("Year" to "687 days", "Gravity" to "3.71 m/s²", "Moons" to "2"), Color(0xFFD65F4A)),
    CosmicBody("Jupiter", "PLANET", "Gas giant", "The largest planet, with immense storms and a powerful magnetosphere.", listOf("Year" to "11.86 years", "Mass" to "318 Earths", "Moons" to "95+"), Color(0xFFD9A878)),
    CosmicBody("Saturn", "PLANET", "Ringed giant", "A hydrogen-helium giant surrounded by spectacular icy rings.", listOf("Year" to "29.45 years", "Rings" to "Thousands of bands", "Moons" to "140+"), Color(0xFFE4C78B)),
    CosmicBody("Uranus", "PLANET", "Ice giant", "A blue-green ice giant rotating almost on its side.", listOf("Year" to "84 years", "Tilt" to "97.8°", "Moons" to "27"), Color(0xFF8ED9E8)),
    CosmicBody("Neptune", "PLANET", "Windy ice giant", "A deep-blue outer planet with extreme winds.", listOf("Year" to "164.8 years", "Wind" to "~2,000 km/h", "Moons" to "14"), Color(0xFF5678E8)),
    CosmicBody("Pluto", "DWARF PLANET", "Kuiper-belt world", "An icy dwarf planet with mountains and glaciers.", listOf("Year" to "248 years", "Distance" to "~39 AU avg", "Moons" to "5"), Color(0xFFBFAE9B)),
    CosmicBody("Sirius", "STAR", "Brightest night-sky star", "A nearby binary system dominated by brilliant Sirius A.", listOf("Distance" to "8.6 ly", "Type" to "A-type", "System" to "Binary"), Color(0xFFDCEBFF), true),
    CosmicBody("Proxima Centauri", "STAR", "Nearest known star", "A nearby red dwarf in the Alpha Centauri system.", listOf("Distance" to "4.24 ly", "Type" to "Red dwarf", "Planets" to "At least 2"), Color(0xFFFF6A4A), true),
    CosmicBody("Betelgeuse", "STAR", "Red supergiant", "An enormous evolved star in Orion.", listOf("Distance" to "~640 ly", "Type" to "Red supergiant", "Constellation" to "Orion"), Color(0xFFFF7058), true),
    CosmicBody("Vega", "STAR", "Blue-white beacon", "A bright A-type star in Lyra.", listOf("Distance" to "25 ly", "Type" to "A-type", "Constellation" to "Lyra"), Color(0xFFB9D9FF), true),
    CosmicBody("Polaris", "STAR", "The North Star", "A multiple-star system close to the north celestial pole.", listOf("Distance" to "~447 ly", "Type" to "Cepheid", "Constellation" to "Ursa Minor"), Color(0xFFFFF1CF), true),
    CosmicBody("Rigel", "STAR", "Blue supergiant", "A brilliant blue-white supergiant in Orion.", listOf("Distance" to "~860 ly", "Type" to "Blue supergiant", "Constellation" to "Orion"), Color(0xFFB8D7FF), true),
    CosmicBody("Antares", "STAR", "Scorpius supergiant", "A huge red supergiant marking the heart of Scorpius.", listOf("Distance" to "~550 ly", "Type" to "Red supergiant", "Constellation" to "Scorpius"), Color(0xFFFF6655), true),
    CosmicBody("TRAPPIST-1", "STAR", "Ultra-cool red dwarf", "A compact system famous for seven Earth-sized planets.", listOf("Distance" to "39.5 ly", "Type" to "Ultra-cool dwarf", "Planets" to "7"), Color(0xFFFF795E), true),
    CosmicBody("Kepler-22 b", "EXOPLANET", "Super-Earth", "A confirmed exoplanet orbiting within its star's habitable zone.", listOf("Distance" to "~600 ly", "Orbit" to "290 days", "Class" to "Super-Earth"), Color(0xFF6FC8FF)),
    CosmicBody("Kepler-452 b", "EXOPLANET", "Earth-size world", "A super-Earth orbiting a Sun-like star.", listOf("Distance" to "~1,400 ly", "Orbit" to "385 days", "Class" to "Super-Earth"), Color(0xFF8C6CFF)),
    CosmicBody("Proxima Centauri b", "EXOPLANET", "Nearby exoplanet", "A planet orbiting the closest star to the Sun.", listOf("Distance" to "4.24 ly", "Orbit" to "11.2 days", "Host" to "Proxima Centauri"), Color(0xFFFF8A66)),
    CosmicBody("WASP-12 b", "EXOPLANET", "Ultra-hot Jupiter", "A gas giant on an extremely close orbit.", listOf("Distance" to "~1,400 ly", "Orbit" to "1.1 days", "Class" to "Hot Jupiter"), Color(0xFFFFA02F)),
    CosmicBody("TOI-700 d", "EXOPLANET", "Temperate exoplanet", "An Earth-size world orbiting a nearby red dwarf.", listOf("Distance" to "~100 ly", "Orbit" to "37.4 days", "Class" to "Earth-size"), Color(0xFF63C9A8)),
)

private val ExtraStars = listOf("Alpha Centauri A", "Arcturus", "Canopus", "Deneb", "Mu Cephei", "R136a1", "Pollux", "Castor", "Bellatrix", "Alnilam", "Alnitak", "Shaula")
private val ExtraWorlds = listOf("TRAPPIST-1e")
private val QuickNames = listOf("Sun", "Earth", "Mars", "Jupiter", "Saturn", "Neptune", "Sirius", "Betelgeuse", "Proxima Centauri", "TRAPPIST-1", "Kepler-22 b", "Polaris")

private fun bodyFor(name: String): CosmicBody {
    val hit = Catalogue.firstOrNull { it.name.equals(name, ignoreCase = true) }
    if (hit != null) return hit
    val isStar = ExtraStars.any { it.equals(name, ignoreCase = true) }
    return CosmicBody(
        name = name,
        type = if (isStar) "STAR" else "OBJECT",
        subtitle = if (isStar) "Named star" else "Deep-space object",
        description = "Detailed facts for this object load from the online encyclopedia when you are connected.",
        facts = emptyList(),
        color = CxCyan,
        star = isStar,
    )
}

private class OnlineInfo(val title: String, val description: String, val extract: String)

private class CosmicOnlineRepository {
    private val http = OkHttpClient.Builder().connectTimeout(7, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).build()

    suspend fun lookup(query: String): OnlineInfo? = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext null
        try {
            val key = URLEncoder.encode(query.trim().replace(' ', '_'), "UTF-8")
            val req = Request.Builder()
                .url("https://en.wikipedia.org/api/rest_v1/page/summary/$key")
                .header("User-Agent", "AUVYRR-CosmicExplorer/4.0")
                .build()
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) {
                    null
                } else {
                    val o = JSONObject(r.body?.string().orEmpty())
                    OnlineInfo(o.optString("title", query), o.optString("description", ""), o.optString("extract", ""))
                }
            }
        } catch (_: Throwable) {
            null
        }
    }
}

private fun isOnlineNow(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val n = cm.activeNetwork ?: return false
    val c = cm.getNetworkCapabilities(n) ?: return false
    return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
        c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
}

private fun saveToGallery(context: Context, file: File): Boolean {
    return try {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AUVYRR")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                false
            } else {
                val out = context.contentResolver.openOutputStream(uri)
                if (out == null) {
                    false
                } else {
                    out.use { o -> FileInputStream(file).use { i -> i.copyTo(o, 1 shl 20) } }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                    true
                }
            }
        } else {
            val dir = File(context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), "AUVYRR")
            dir.mkdirs()
            file.copyTo(File(dir, file.name), overwrite = true)
            true
        }
    } catch (_: Throwable) {
        false
    }
}

private enum class ExportSize(val label: String, val px: Int) {
    HD("1080p", 1920),
    QHD("2K", 2560),
    UHD("4K", 3840),
}

/**
 * Full-screen cosmos explorer: a live 3D solar system and deep-space view with search, quick access,
 * detail panel, core cutaway, quality selector and image export.
 * [initialQuery] opens straight on a named body (used by constellation stars).
 */
@Composable
fun CosmicExplorerScreen(onBack: () -> Unit, initialQuery: String? = null) {
    val context = LocalContext.current
    val repo = remember { CosmicOnlineRepository() }
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    var view by remember { mutableStateOf<Cosmic3DView?>(null) }
    var labels by remember { mutableStateOf<List<CosmicLabel>>(emptyList()) }
    var selected by remember { mutableStateOf(bodyFor(initialQuery?.takeIf { it.isNotBlank() } ?: "Earth")) }
    var query by remember { mutableStateOf("") }
    var online by remember { mutableStateOf(isOnlineNow(context)) }
    var info by remember { mutableStateOf<OnlineInfo?>(null) }
    var infoLoading by remember { mutableStateOf(false) }
    var core by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var orbits by remember { mutableStateOf(true) }
    var quality by remember { mutableStateOf(CosmicQuality.HIGH) }
    var exportSize by remember { mutableStateOf(ExportSize.QHD) }
    var exporting by remember { mutableStateOf(false) }
    var panelOpen by remember { mutableStateOf(true) }
    var showCatalog by remember { mutableStateOf(false) }
    var showResearch by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var focused by remember { mutableStateOf(!initialQuery.isNullOrBlank()) }

    BackHandler(enabled = showCatalog || showResearch) {
        showCatalog = false
        showResearch = false
    }

    LaunchedEffect(Unit) {
        while (true) {
            online = isOnlineNow(context)
            delay(3500)
        }
    }

    DisposableEffect(lifecycle, view) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) view?.onPause()
            if (event == Lifecycle.Event.ON_RESUME) view?.onResume()
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(selected.name, online) {
        info = null
        if (online) {
            infoLoading = true
            info = repo.lookup(selected.name)
            infoLoading = false
        }
    }

    LaunchedEffect(view) {
        val v = view
        if (v != null) {
            v.setQuality(quality)
            v.setCoreMode(core)
            v.setPaused(paused)
            v.setOrbits(orbits)
            if (focused) {
                delay(350)
                v.focusOn(selected.name)
            }
        }
    }

    fun choose(name: String) {
        selected = bodyFor(name)
        core = false
        view?.setCoreMode(false)
        focused = true
        view?.focusOn(name)
        panelOpen = true
    }

    fun runSearch() {
        val q = query.trim()
        if (q.length < 2) return
        val all = Catalogue.map { it.name } + ExtraStars + ExtraWorlds
        val match = all.firstOrNull { it.equals(q, ignoreCase = true) }
            ?: all.firstOrNull { it.contains(q, ignoreCase = true) }
        choose(match ?: q)
    }

    if (showCatalog) {
        StarCatalogScreen(
            onBack = { showCatalog = false },
            onOpenStar = { name ->
                showCatalog = false
                choose(name)
            },
        )
        return
    }
    if (showResearch) {
        PlanetResearchScreen(onBack = { showResearch = false })
        return
    }

    val suggestions = if (query.trim().length >= 2) {
        (Catalogue.map { it.name } + ExtraStars + ExtraWorlds)
            .filter { it.contains(query.trim(), ignoreCase = true) }
            .take(5)
    } else {
        emptyList()
    }

    Box(Modifier.fillMaxSize().background(CxBg)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                Cosmic3DView(ctx).also { v ->
                    v.onPick = { name -> choose(name) }
                    v.onLabels = { list -> labels = list }
                    view = v
                }
            },
        )

        // Name labels floating over the bodies.
        for (l in labels) {
            val isSel = l.name.equals(selected.name, ignoreCase = true)
            if (l.isStar && !isSel && l.radiusPx < 3f) continue
            Text(
                l.name,
                color = if (isSel) CxCyan else if (l.isStar) Color(0xFFFFE9B8) else CxText.copy(alpha = 0.85f),
                fontSize = if (isSel) 11.sp else 9.sp,
                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                modifier = Modifier.offset {
                    IntOffset((l.x - 30f).toInt(), (l.y + l.radiusPx.coerceIn(4f, 90f) + 4f).toInt())
                },
            )
        }

        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xCC020308), Color.Transparent, Color.Transparent, Color(0xDD020308)))))

        // ---------- top
        Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = CxText) }
                Column(Modifier.weight(1f)) {
                    Text("COSMIC EXPLORER", color = CxText, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Live 3D universe · ${quality.label}", color = CxCyan, fontSize = 10.sp, letterSpacing = 1.sp)
                }
                Row(
                    Modifier.clip(RoundedCornerShape(20.dp))
                        .background(if (online) Color(0x222FE8A0) else Color(0x22FF6677))
                        .padding(horizontal = 9.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(if (online) Icons.Rounded.Cloud else Icons.Rounded.CloudOff, null, tint = if (online) CxGreen else CxRed, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(if (online) "ONLINE" else "OFFLINE", color = if (online) CxGreen else CxRed, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 4.dp).height(48.dp)
                    .clip(RoundedCornerShape(16.dp)).background(CxPanel)
                    .border(1.dp, CxCyan.copy(alpha = 0.22f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Search, null, tint = CxCyan, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Search planets, stars, exoplanets…", color = CxMuted, fontSize = 13.sp)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = CxText, fontSize = 14.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { runSearch() }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (query.isNotEmpty()) {
                    Icon(
                        Icons.Rounded.Close, null, tint = CxMuted,
                        modifier = Modifier.size(18.dp).clickable { query = "" },
                    )
                }
            }
            if (suggestions.isNotEmpty()) {
                Column(
                    Modifier.fillMaxWidth().padding(top = 4.dp).clip(RoundedCornerShape(14.dp)).background(CxPanel),
                ) {
                    for (s in suggestions) {
                        Text(
                            s, color = CxText, fontSize = 13.sp,
                            modifier = Modifier.fillMaxWidth().clickable {
                                query = ""
                                choose(s)
                            }.padding(horizontal = 14.dp, vertical = 10.dp),
                        )
                    }
                }
            }
        }

        // ---------- right-hand controls
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SideButton(if (paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, if (paused) "PLAY" else "PAUSE", paused) {
                paused = !paused
                view?.setPaused(paused)
            }
            SideButton(Icons.Rounded.Public, "ORBITS", orbits) {
                orbits = !orbits
                view?.setOrbits(orbits)
            }
            SideButton(Icons.Rounded.Layers, "CORE", core) {
                core = !core
                view?.setCoreMode(core)
            }
            SideButton(Icons.Rounded.Tune, "QUALITY", showTools) { showTools = !showTools }
            SideButton(Icons.Rounded.Download, if (exporting) "…" else "SAVE", exporting) {
                if (!exporting) {
                    exporting = true
                    view?.exportImage(context, exportSize.px) { result ->
                        exporting = false
                        val f = result.getOrNull()
                        if (f == null) {
                            Toast.makeText(context, "Couldn't render: ${result.exceptionOrNull()?.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                        } else {
                            val ok = saveToGallery(context, f)
                            f.delete()
                            Toast.makeText(context, if (ok) "Saved to Pictures/AUVYRR (${exportSize.label})" else "Couldn't save the image", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }

        if (showTools) {
            Column(
                Modifier.align(Alignment.CenterEnd).padding(end = 76.dp)
                    .clip(RoundedCornerShape(16.dp)).background(CxPanel)
                    .border(1.dp, CxCyan.copy(alpha = 0.22f), RoundedCornerShape(16.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text("RENDER QUALITY", color = CxMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (q in CosmicQuality.values()) {
                        Chip(q.label, q == quality) {
                            quality = q
                            view?.setQuality(q)
                        }
                    }
                }
                Text("SAVE IMAGE SIZE", color = CxMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, modifier = Modifier.padding(top = 4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (s in ExportSize.values()) {
                        Chip(s.label, s == exportSize) { exportSize = s }
                    }
                }
            }
        }

        // ---------- bottom
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Chip("STAR CATALOG", false) { showCatalog = true } }
                item { Chip("PLANET RESEARCH", false) { showResearch = true } }
                items(QuickNames) { n ->
                    Chip(n, n.equals(selected.name, ignoreCase = true)) { choose(n) }
                }
            }
            DetailPanel(
                body = selected,
                info = info,
                loading = infoLoading,
                online = online,
                open = panelOpen,
                onToggle = { panelOpen = !panelOpen },
            )
        }
    }
}

@Composable
private fun SideButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.width(56.dp).clip(RoundedCornerShape(14.dp))
            .background(if (active) CxCyan.copy(alpha = 0.18f) else CxPanel)
            .border(1.dp, if (active) CxCyan.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = if (active) CxCyan else CxText, modifier = Modifier.size(20.dp))
        Text(label, color = if (active) CxCyan else CxMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun Chip(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(16.dp))
            .background(if (active) CxCyan.copy(alpha = 0.20f) else CxPanel)
            .border(1.dp, if (active) CxCyan.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Text(text, color = if (active) CxCyan else CxText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun DetailPanel(body: CosmicBody, info: OnlineInfo?, loading: Boolean, online: Boolean, open: Boolean, onToggle: () -> Unit) {
    Column(
        Modifier.padding(horizontal = 12.dp).fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.verticalGradient(listOf(body.color.copy(alpha = 0.16f), CxPanel)))
            .border(1.dp, body.color.copy(alpha = 0.32f), RoundedCornerShape(22.dp))
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable(onClick = onToggle)) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Brush.radialGradient(listOf(body.color, body.color.copy(alpha = 0.15f)))))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(body.name, color = CxText, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${body.type} · ${body.subtitle}", color = body.color, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
            Icon(if (open) Icons.Rounded.KeyboardArrowDown else Icons.Rounded.KeyboardArrowUp, null, tint = CxMuted)
        }
        if (open) {
            Column(Modifier.heightIn(max = 230.dp).verticalScroll(rememberScrollState())) {
                Spacer(Modifier.height(8.dp))
                Text(body.description, color = CxText.copy(alpha = 0.85f), fontSize = 12.sp, lineHeight = 17.sp)
                if (body.facts.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (f in body.facts) {
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.05f)).padding(8.dp),
                            ) {
                                Text(f.first.uppercase(), color = CxMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                                Text(f.second, color = CxText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = CxViolet, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("LIVE KNOWLEDGE", color = CxViolet, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                }
                val line = when {
                    info != null && info.extract.isNotBlank() -> info.extract
                    loading -> "Fetching from the online encyclopedia…"
                    !online -> "Offline — showing built-in facts only. Connect to the internet for full articles."
                    else -> "No online article found for this name."
                }
                Text(line, color = CxMuted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}
