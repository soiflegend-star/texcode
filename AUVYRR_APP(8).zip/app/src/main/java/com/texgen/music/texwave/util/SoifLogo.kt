package com.texgen.music.texwave.util

import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.ui.theme.Tx

/**
 * SOIF — the signature wordmark. Hand-built geometric, slanted letterforms with a
 * rising sound-bar tail, drawn as vector strokes so it is crisp at any size and works
 * both in Compose and on a plain Android [Canvas] (used for the notification artwork).
 */
object SoifLogo {
    const val PLAIN = "SOIF"

    /** Mathematical bold-script "SOIF" — a stylised, font-independent text version of the logo. */
    const val STYLED = "𝓢𝓞𝓘𝓕"

    fun text(styled: Boolean): String = if (styled) STYLED else PLAIN

    /** Logical drawing box. */
    const val WIDTH = 204f
    const val HEIGHT = 76f
    private const val STROKE = 7.5f
    private const val SLANT = -0.2f // negative = lean right

    private val letters: Path by lazy {
        Path().apply {
            // S
            moveTo(34f, 16f)
            cubicTo(30f, 8f, 22f, 6f, 18f, 6f)
            cubicTo(10f, 6f, 5f, 11f, 5f, 18f)
            cubicTo(5f, 34f, 35f, 30f, 35f, 48f)
            cubicTo(35f, 57f, 28f, 62f, 20f, 62f)
            cubicTo(11f, 62f, 6f, 57f, 5f, 50f)
            // O
            addOval(RectF(53f, 6f, 87f, 62f), Path.Direction.CW)
            // I (slab)
            moveTo(100f, 6f); lineTo(116f, 6f)
            moveTo(108f, 6f); lineTo(108f, 62f)
            moveTo(100f, 62f); lineTo(116f, 62f)
            // F
            moveTo(136f, 62f); lineTo(136f, 6f); lineTo(166f, 6f)
            moveTo(136f, 32f); lineTo(158f, 32f)
        }
    }

    private val bars: Path by lazy {
        Path().apply {
            moveTo(178f, 44f); lineTo(178f, 62f)
            moveTo(187f, 32f); lineTo(187f, 62f)
            moveTo(196f, 20f); lineTo(196f, 62f)
        }
    }

    /**
     * Draws the logo centred on ([cx], [cy]) with the given overall [width] in pixels.
     * [glow] adds a soft halo and needs a software canvas (a Bitmap canvas is fine).
     */
    fun draw(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        width: Float,
        color1: Int,
        color2: Int,
        glow: Boolean = false,
        alpha: Int = 255,
    ) {
        // AUVYRR mark: an "A" with an orbit ring, drawn as vector strokes (unit box 100 x 100).
        val side = width * 0.55f
        val k = side / 100f
        val ox = cx - side / 2f
        val oy = cy - side / 2f
        fun px(x: Float) = ox + x * k
        fun py(y: Float) = oy + y * k
        val leg = Path().apply {
            moveTo(px(20f), py(90f)); lineTo(px(50f), py(10f)); lineTo(px(80f), py(90f))
        }
        val ring = Path().apply {
            moveTo(px(6f), py(70f)); cubicTo(px(34f), py(58f), px(68f), py(44f), px(96f), py(34f))
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            this.alpha = alpha
        }
        val shader = LinearGradient(ox, oy, ox + side, oy + side, color1, color2, Shader.TileMode.CLAMP)
        if (glow) {
            val halo = Paint(paint).apply {
                this.shader = shader
                this.alpha = (alpha * 0.55f).toInt()
                strokeWidth = 17f * k
                maskFilter = BlurMaskFilter(10f * k, BlurMaskFilter.Blur.NORMAL)
            }
            canvas.drawPath(leg, halo)
            canvas.drawPath(ring, halo)
        }
        paint.shader = shader
        paint.strokeWidth = 11f * k
        canvas.drawPath(leg, paint)
        paint.strokeWidth = 7f * k
        canvas.drawPath(ring, paint)
    }
}

/** The SOIF wordmark as a composable, tinted with the live theme colours. */
@Composable
fun SoifLogoMark(modifier: Modifier = Modifier, height: Dp = 26.dp) {
    val c1 = Tx.Accent.toArgb()
    val c2 = Tx.Accent2.toArgb()
    ComposeCanvas(
        modifier
            .height(height)
            .aspectRatio(SoifLogo.WIDTH / SoifLogo.HEIGHT)
    ) {
        drawIntoCanvas { canvas ->
            SoifLogo.draw(
                canvas = canvas.nativeCanvas,
                cx = size.width / 2f,
                cy = size.height / 2f,
                width = size.height / 0.55f,
                color1 = c1,
                color2 = c2,
            )
        }
    }
}
