package com.texgen.music.texwave.sonara.data.catalog

import android.content.Context
import com.texgen.music.texwave.sonara.data.Track
import com.texgen.music.texwave.sonara.data.TrackSource
import com.texgen.music.texwave.sonara.data.remote.SupabaseProvider
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import org.json.JSONObject

/**
 * Online music catalogue.
 * Priority: Supabase published tracks → assets/catalogue_seed.json (ingested legal CC) → DemoCatalogue
 */
class CatalogueRepository(private val context: Context? = null) {

    @Serializable
    data class TrackRow(
        val id: String,
        val title: String,
        @SerialName("artist_name") val artistName: String,
        @SerialName("album_name") val albumName: String? = null,
        @SerialName("duration_ms") val durationMs: Long? = null,
        @SerialName("artwork_url") val artworkUrl: String? = null,
        @SerialName("external_stream_url") val externalStreamUrl: String? = null,
        val genre: String? = null,
        val year: Int? = null,
        @SerialName("is_downloadable") val isDownloadable: Boolean? = false,
        val status: String? = null,
    )

    suspend fun fetchPublished(limit: Int = 200): List<Track> = withContext(Dispatchers.IO) {
        val client = SupabaseProvider.client
        if (client != null) {
            try {
                val rows = client.from("tracks").select {
                    filter { eq("status", "published") }
                }.decodeList<TrackRow>()
                if (rows.isNotEmpty()) {
                    return@withContext rows.map { it.toTrack() }.take(limit)
                }
            } catch (_: Exception) { }
        }
        val seeded = loadAssetSeed()
        val demo = DemoCatalogue.tracks
        (seeded + demo).distinctBy { it.streamUrl ?: it.id }.take(limit)
    }

    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val all = fetchPublished(500)
        val q = query.trim().lowercase()
        all.filter {
            it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q) ||
                (it.genre?.lowercase()?.contains(q) == true)
        }
    }

    suspend fun resolveStreamUrl(track: Track): String? = withContext(Dispatchers.IO) {
        track.streamUrl
    }

    fun phonkTracks(all: List<Track>): List<Track> =
        all.filter { it.genre?.lowercase()?.contains("phonk") == true }

    private fun loadAssetSeed(): List<Track> {
        val ctx = context ?: return emptyList()
        return try {
            ctx.assets.open("sonara_catalogue_seed.json").bufferedReader().use { reader ->
                val root = JSONObject(reader.readText())
                val arr = root.getJSONArray("tracks")
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(
                            Track(
                                id = o.getString("id"),
                                title = o.getString("title"),
                                artist = o.getString("artist"),
                                album = o.optString("album", ""),
                                durationMs = o.optLong("durationMs", 0L),
                                artworkUrl = o.optString("artworkUrl", null).takeIf { !it.isNullOrBlank() },
                                streamUrl = o.optString("streamUrl", null),
                                source = TrackSource.CATALOGUE,
                                genre = o.optString("genre", "Electronic"),
                                year = if (o.has("year") && !o.isNull("year")) o.optInt("year") else null,
                                isDownloadable = o.optBoolean("isDownloadable", true),
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun TrackRow.toTrack() = Track(
        id = id,
        title = title,
        artist = artistName,
        album = albumName ?: "",
        durationMs = durationMs ?: 0L,
        artworkUrl = artworkUrl,
        streamUrl = externalStreamUrl,
        source = TrackSource.CATALOGUE,
        genre = genre,
        year = year,
        isDownloadable = isDownloadable == true,
    )
}
