package com.texgen.music.texwave.sonara.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.texgen.music.texwave.R
import com.texgen.music.texwave.sonara.data.Track
import kotlinx.coroutines.delay

internal sealed interface SRoute {
    data class Collection(val title: String, val subtitle: String, val tracks: List<Track>) : SRoute
    data class Artist(val name: String, val tracks: List<Track>) : SRoute
    data class Page(val kind: String) : SRoute
    object NowPlaying : SRoute
    object Queue : SRoute
    object Lyrics : SRoute
}

private enum class STab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    HOME("Home", Icons.Filled.Home), SEARCH("Search", Icons.Filled.Search),
    LIBRARY("Library", Icons.Filled.LibraryMusic), PROFILE("Profile", Icons.Filled.Person),
}

/**
 * KT Sonara music module hosted inside AUVYRR. [onPlay] fires when Sonara starts playback
 * so the host can pause its own player (never two engines at once).
 */
@Composable
fun SonaraModule(onExit: () -> Unit, onPlay: () -> Unit = {}) {
    val ctx = LocalContext.current
    SonaraPrefs.init(ctx)
    SonaraPrefs.systemDark = isSystemInDarkTheme()

    val vm: SonaraViewModel = viewModel()
    val s by vm.ui.collectAsState()
    val pb by vm.playback.collectAsState()
    var tab by remember { mutableStateOf(STab.HOME) }
    val stack = remember { mutableStateListOf<SRoute>() }
    var more by remember { mutableStateOf<Track?>(null) }
    var quick by remember { mutableStateOf(false) }
    var splash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) { delay(1700); splash = false }
    LaunchedEffect(pb.isPlaying) {
        if (pb.isPlaying) onPlay()
        while (pb.isPlaying) { vm.tick(); delay(500) }
    }

    BackHandler(enabled = quick) { quick = false }
    BackHandler(enabled = !quick && stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }
    BackHandler(enabled = !quick && stack.isEmpty() && tab != STab.HOME) { tab = STab.HOME }
    BackHandler(enabled = !quick && stack.isEmpty() && tab == STab.HOME) { onExit() }

    val open: OpenList = { title, sub, tracks ->
        if (sub == "Artist") stack.add(SRoute.Artist(title, tracks)) else stack.add(SRoute.Collection(title, sub, tracks))
    }
    val current = pb.currentTrack
    val tint = if (SonaraPrefs.dynamic && current != null) seedColor(current.id) else null

    Box(Modifier.fillMaxSize()) {
        SonaraBackdrop(tint = tint) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        STab.HOME -> HomeScreen(vm, s, onExit, onSearch = { tab = STab.SEARCH }, open = open) { t, q -> vm.play(t, q) }
                        STab.SEARCH -> SearchScreen(vm, s, open) { more = it }
                        STab.LIBRARY -> LibraryScreen(vm, s, open) { more = it }
                        STab.PROFILE -> SettingsHome(vm) { stack.add(SRoute.Page(it)) }
                    }
                }
                if (current != null) MiniPlayer(
                    current, pb.isPlaying, pb.positionMs, pb.durationMs, s.likedIds.contains(current.id),
                    onOpen = { stack.add(SRoute.NowPlaying) }, onToggle = { vm.togglePlayPause() }, onLike = { vm.toggleLike(current.id) },
                )
                BottomNav(tab) { tab = it; stack.clear() }
            }
        }

        val top = stack.lastOrNull()
        if (top != null) SonaraBackdrop(tint = tint) {
            when (top) {
                is SRoute.Collection -> CollectionScreen(vm, s, top, onBack = { stack.removeAt(stack.lastIndex) }) { more = it }
                is SRoute.Artist -> ArtistScreen(vm, s, top, onBack = { stack.removeAt(stack.lastIndex) }, open = open) { more = it }
                is SRoute.NowPlaying -> NowPlayingScreen(vm, s, onClose = { stack.removeAt(stack.lastIndex) }, onQuick = { quick = true }, onLyrics = { stack.add(SRoute.Lyrics) })
                is SRoute.Queue -> QueueScreen(vm, s) { stack.removeAt(stack.lastIndex) }
                is SRoute.Lyrics -> LyricsScreen(current) { stack.removeAt(stack.lastIndex) }
                is SRoute.Page -> {
                    val back = { stack.removeAt(stack.lastIndex); Unit }
                    when (top.kind) {
                        "appearance" -> AppearanceScreen(back)
                        "playback" -> PlaybackScreen(vm, back)
                        "account" -> AccountScreen(vm, back)
                        else -> InfoScreen(top.kind, back)
                    }
                }
            }
        }
        if (quick) QuickPanel(vm, s, onClose = { quick = false }, onQueue = { stack.add(SRoute.Queue) }, onLyrics = { stack.add(SRoute.Lyrics) })
        more?.let { t -> MoreDialog(vm, s, t, onArtist = { n -> stack.add(SRoute.Artist(n, vm.byArtist(s, n))) }) { more = null } }
        if (splash) SplashScreen()
    }
}

@Composable
private fun SplashScreen() {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(1500, easing = LinearEasing)) }
    SonaraBackdrop(Modifier.clickable(enabled = false) {}) {
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            Image(painterResource(R.drawable.auvyrr_logo_clear), "AUVYRR", Modifier.size(132.dp))
            Spacer(Modifier.height(10.dp))
            Text("AUVYRR", color = SC.Text, fontSize = 30.sp, letterSpacing = 9.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.height(6.dp))
            Text("More Than a Player", color = SC.Sub, fontSize = 12.sp, letterSpacing = 3.sp)
            Spacer(Modifier.weight(1f))
            Text("Powered by", color = SC.Sub, fontSize = 11.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, null, tint = SC.Accent2, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text("KT Sonara", color = SC.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.width(120.dp).height(3.dp).clip(CircleShape).background(SC.Line)) {
                Box(Modifier.fillMaxWidth(p.value).fillMaxHeight().background(Brush.horizontalGradient(listOf(SC.Accent2, SC.Accent))))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BottomNav(tab: STab, onTab: (STab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp).glass(26.dp).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceAround,
    ) {
        STab.values().forEach { t ->
            val on = t == tab
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                    .background(if (on) SC.Accent.copy(alpha = 0.22f) else Color.Transparent)
                    .clickable { onTab(t) }.padding(vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(t.icon, t.label, tint = if (on) SC.Accent2 else SC.Sub, modifier = Modifier.size(22.dp))
                Text(t.label, color = if (on) SC.Text else SC.Sub, fontSize = 10.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    t: Track, playing: Boolean, pos: Long, dur: Long, liked: Boolean,
    onOpen: () -> Unit, onToggle: () -> Unit, onLike: () -> Unit,
) {
    Column(Modifier.padding(horizontal = 14.dp).glass(18.dp).clickable { onOpen() }) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(t.artworkUrl, t.id, 44.dp, 10.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(t.title, color = SC.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, color = SC.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like", tint = if (liked) SC.Accent else SC.Sub,
                modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onLike() }.padding(9.dp))
            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", tint = SC.Text,
                modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onToggle() }.padding(6.dp))
        }
        val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
        Box(Modifier.fillMaxWidth().height(2.dp).background(SC.Line)) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(SC.Accent))
        }
    }
}
