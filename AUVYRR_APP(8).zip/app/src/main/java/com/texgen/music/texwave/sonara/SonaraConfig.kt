package com.texgen.music.texwave.sonara

/**
 * Optional keys for the online catalogue. Everything works with these empty:
 * - Audius streams full tracks from independent artists (no key needed for basic use).
 * - iTunes gives 30-second previews of almost any commercial song (no key).
 * - Jamendo (free CC music, 600k+ tracks) switches on once you paste a free client id
 *   from developer.jamendo.com.
 */
object SonaraConfig {
    const val APP_NAME = "AUVYRR"
    const val JAMENDO_CLIENT_ID = ""
    const val AUDIUS_API_KEY = ""
}
