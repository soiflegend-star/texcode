package com.texgen.music.texwave.data

import java.text.Normalizer
import kotlin.math.max

/**
 * Forgiving local search. Handles accents, punctuation, "the", "&"/"and", typos (edit distance),
 * word-prefix matches ("bohem rhap"), "title by artist" / "artist - title", file names and
 * partial word orders, then ranks by how well and how completely the query matched.
 */
object SmartSearch {
    data class Hit<T>(val item: T, val score: Double)

    private val diacritics = Regex("\\p{Mn}+")
    private val junk = Regex("[^a-z0-9 ]+")
    private val spaces = Regex("\\s+")
    private val filler = setOf("the", "a", "an", "of", "and", "song", "songs", "play", "official", "video", "audio", "lyrics", "feat", "ft", "by", "from")

    fun norm(s: String): String {
        val d = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(diacritics, "")
        return d.replace("&", " and ").replace(junk, " ").replace(spaces, " ").trim()
    }

    fun tokens(s: String): List<String> = norm(s).split(' ').filter { it.isNotEmpty() }

    /** Optimal-string-alignment distance, bounded so long strings stay cheap. */
    private fun dist(a: String, b: String, limit: Int): Int {
        if (kotlin.math.abs(a.length - b.length) > limit) return limit + 1
        var prev2 = IntArray(b.length + 1)
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) v = minOf(v, prev2[j - 2] + 1)
                cur[j] = v
                if (v < rowMin) rowMin = v
            }
            if (rowMin > limit) return limit + 1
            prev2 = prev; prev = cur
        }
        return prev[b.length]
    }

    /** Score one query token against a field's words; 0 if no match. */
    private fun tokenScore(tok: String, words: List<String>, whole: String): Double {
        var best = 0.0
        for (w in words) {
            val s = when {
                w == tok -> 10.0
                w.startsWith(tok) -> 8.0 + (tok.length.toDouble() / w.length) * 1.5
                tok.length >= 3 && w.contains(tok) -> 4.5
                tok.length >= 4 && dist(tok, w, if (tok.length >= 8) 2 else 1) <= (if (tok.length >= 8) 2 else 1) -> 6.0
                tok.length >= 5 && w.length > tok.length && dist(tok, w.take(tok.length), 1) <= 1 -> 5.0
                else -> 0.0
            }
            if (s > best) best = s
        }
        if (best == 0.0 && tok.length >= 3 && whole.replace(" ", "").contains(tok)) best = 3.0
        return best
    }

    private class Doc(val title: String, val artist: String, val album: String, val file: String) {
        val tw = title.split(' ').filter { it.isNotEmpty() }
        val aw = artist.split(' ').filter { it.isNotEmpty() }
        val bw = album.split(' ').filter { it.isNotEmpty() }
        val fw = file.split(' ').filter { it.isNotEmpty() }
    }

    private fun docOf(s: Song) = Doc(
        norm(s.title), norm(s.artist), norm(s.album),
        norm(s.path.substringAfterLast('/').substringBeforeLast('.')),
    )

    fun songs(
        all: List<Song>, query: String, liked: Set<Long> = emptySet(), plays: Map<Long, Int> = emptyMap(),
        blacklist: Set<Long> = emptySet(), limit: Int = 60,
    ): List<Song> {
        val qn = norm(query)
        if (qn.isEmpty()) return emptyList()
        var toks = qn.split(' ').filter { it !in filler }.ifEmpty { qn.split(' ') }
        // "title by artist"
        val byParts = Regex("\\s+by\\s+").split(query.lowercase(), 2).takeIf { it.size == 2 }?.map { norm(it) }
        // "artist - title"
        val dashParts = Regex("\\s[-–—]\\s").split(query.lowercase(), 2).takeIf { it.size == 2 }?.map { norm(it) }
        val ranked = ArrayList<Hit<Song>>()
        for (song in all) {
            if (song.id in blacklist) continue
            val d = docOf(song)
            val whole = d.title + " " + d.artist + " " + d.album
            var score = 0.0
            var matched = 0
            for (t in toks) {
                val ts = tokenScore(t, d.tw, d.title) * 1.6
                val ars = tokenScore(t, d.aw, d.artist) * 1.25
                val bs = tokenScore(t, d.bw, d.album) * 0.6
                val fs = tokenScore(t, d.fw, d.file) * 0.7
                val m = max(max(ts, ars), max(bs, fs))
                if (m > 0) { matched++; score += m + (ts + ars + bs + fs - m) * 0.1 }
            }
            if (matched == 0) continue
            val frac = matched.toDouble() / toks.size
            score *= (0.35 + 0.65 * frac)
            if (matched == toks.size) score += 14.0
            if (d.title == qn) score += 90.0
            else if (d.title.startsWith(qn)) score += 45.0
            else if (qn in d.title) score += 28.0
            if (d.artist == qn) score += 55.0 else if (qn in d.artist) score += 20.0
            if (qn in whole) score += 12.0
            byParts?.let { (t, a) ->
                if (t.isNotEmpty() && t in d.title) score += 30.0
                if (a.isNotEmpty() && a in d.artist) score += 30.0
            }
            dashParts?.let { (x, y) ->
                if (x in d.artist && y in d.title) score += 45.0
                if (y in d.artist && x in d.title) score += 45.0
            }
            if (song.id in liked) score += 3.0
            score += (plays[song.id] ?: 0).coerceAtMost(30) * 0.15
            // too weak: single fuzzy token among many unmatched ones
            if (frac < 0.5 && toks.size > 2) continue
            ranked.add(Hit(song, score))
        }
        if (ranked.isEmpty()) return emptyList()
        val top = ranked.maxOf { it.score }
        // drop long tails far below the best hit
        return ranked.filter { it.score >= top * 0.18 }.sortedByDescending { it.score }.map { it.item }.distinctBy { it.id }.take(limit)
    }

    fun artists(all: List<Song>, query: String, limit: Int = 8): List<String> {
        val toks = tokens(query).filter { it !in filler }.ifEmpty { tokens(query) }
        if (toks.isEmpty()) return emptyList()
        return all.map { it.artist }.distinct().mapNotNull { name ->
            val n = norm(name); val w = n.split(' ').filter { it.isNotEmpty() }
            var total = 0.0; var matched = 0
            for (t in toks) { val s = tokenScore(t, w, n); if (s > 0) { matched++; total += s } }
            if (matched == toks.size) name to total + (if (n == norm(query)) 40.0 else 0.0) else null
        }.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    fun albums(all: List<Song>, query: String, limit: Int = 8): List<Song> {
        val toks = tokens(query).filter { it !in filler }.ifEmpty { tokens(query) }
        if (toks.isEmpty()) return emptyList()
        return all.groupBy { it.albumId to it.album }.values.mapNotNull { g ->
            val s = g.first(); val n = norm(s.album); val w = n.split(' ').filter { it.isNotEmpty() }
            var total = 0.0; var matched = 0
            for (t in toks) { val x = tokenScore(t, w, n); if (x > 0) { matched++; total += x } }
            if (matched == toks.size && s.album.isNotBlank()) s to total else null
        }.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    fun playlists(all: List<Playlist>, query: String): List<Playlist> {
        val toks = tokens(query)
        if (toks.isEmpty()) return emptyList()
        return all.filter { p ->
            val n = norm(p.name); val w = n.split(' ').filter { it.isNotEmpty() }
            toks.all { tokenScore(it, w, n) > 0 }
        }
    }

    /** A better spelling to offer when nothing matched. */
    fun didYouMean(all: List<Song>, query: String): String? {
        val q = norm(query)
        if (q.length < 4) return null
        val pool = LinkedHashSet<String>()
        all.forEach { pool.add(norm(it.title)); pool.add(norm(it.artist)) }
        var best: String? = null; var bd = Int.MAX_VALUE
        for (c in pool) {
            if (c.isEmpty()) continue
            val lim = max(2, q.length / 4)
            val d = dist(q, c.take(max(q.length, 1) + 2), lim)
            if (d <= lim && d < bd) { bd = d; best = c }
        }
        return best?.takeIf { it != q }
    }
}
