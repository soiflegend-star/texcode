package com.texgen.music.texwave.data.chat

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.texgen.music.texwave.MainActivity
import com.texgen.music.texwave.R

/**
 * Local notifications for chat messages and calls.
 * Requires POST_NOTIFICATIONS on Android 13+ and a live realtime inbox subscription.
 */
object ChatNotifier {
    private const val CHANNEL_MSG = "texwave_chat_messages_v2"
    private const val CHANNEL_CALL = "texwave_chat_calls_v2"
    private var notifId = 4200

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val mgr = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (mgr.getNotificationChannel(CHANNEL_MSG) == null) {
            mgr.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_MSG,
                    "Chat messages",
                    NotificationManager.IMPORTANCE_HIGH,
                ).apply {
                    description = "New AUVYRR chat messages"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 250, 150, 250)
                    enableLights(true)
                    setShowBadge(true)
                    val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    setSound(
                        sound,
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                },
            )
        }
        if (mgr.getNotificationChannel(CHANNEL_CALL) == null) {
            mgr.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_CALL,
                    "Incoming calls",
                    NotificationManager.IMPORTANCE_HIGH,
                ).apply {
                    description = "AUVYRR voice and video calls"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 500)
                    setSound(
                        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                },
            )
        }
    }

    /** Android fixes sound/vibration per channel, so each combination the user can pick gets its own channel. */
    private fun messageChannel(context: Context, sound: Boolean, vibrate: Boolean): String {
        val id = "texwave_msg_v3_s${if (sound) 1 else 0}v${if (vibrate) 1 else 0}"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (mgr.getNotificationChannel(id) == null) {
                mgr.createNotificationChannel(
                    NotificationChannel(
                        id,
                        "Chat messages" + (if (!sound && !vibrate) " (silent)" else if (!sound) " (no sound)" else if (!vibrate) " (no vibration)" else ""),
                        if (!sound && !vibrate) NotificationManager.IMPORTANCE_LOW else NotificationManager.IMPORTANCE_HIGH,
                    ).apply {
                        description = "New AUVYRR chat messages"
                        enableVibration(vibrate)
                        if (vibrate) vibrationPattern = longArrayOf(0, 250, 150, 250)
                        setShowBadge(true)
                        if (sound) {
                            setSound(
                                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build(),
                            )
                        } else setSound(null, null)
                    },
                )
            }
        }
        return id
    }

    /** Posts a sample so the user can see exactly how their settings look. */
    fun sendTest(context: Context) {
        notifyNewMessage(context, "texwave_test", "This is how your message alerts look and sound.", "AUVYRR · test", force = true)
    }

    fun notifyNewMessage(
        context: Context,
        conversationId: String,
        preview: String,
        title: String = "New message",
        force: Boolean = false,
    ) {
        if (!force && !NotifPrefs.messages(context)) return
        val quiet = !force && NotifPrefs.inQuietHours(context)
        val wantSound = NotifPrefs.sound(context) && !quiet
        val wantVibrate = NotifPrefs.vibrate(context) && !quiet
        val shownPreview = if (NotifPrefs.preview(context)) preview else "New message"
        val channel = messageChannel(context, wantSound, wantVibrate)
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("open_chat", conversationId)
        }
        val pi = PendingIntent.getActivity(
            context,
            conversationId.hashCode() and 0x7FFFFFFF,
            open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        var defaults = 0
        if (wantSound) defaults = defaults or NotificationCompat.DEFAULT_SOUND
        if (wantVibrate) defaults = defaults or NotificationCompat.DEFAULT_VIBRATE
        val n = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle(title)
            .setContentText(shownPreview)
            .setStyle(NotificationCompat.BigTextStyle().bigText(shownPreview))
            .setPriority(if (!wantSound && !wantVibrate) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(if (NotifPrefs.hideOnLockScreen(context)) NotificationCompat.VISIBILITY_PRIVATE else NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setDefaults(defaults)
            .setOnlyAlertOnce(false)
            .setGroup("texwave_chat")
            .build()
        // One notification slot per conversation (updates preview text)
        val id = 5000 + (conversationId.hashCode() and 0x0FFF)
        post(context, id, n)
    }

    fun notifyIncomingCall(
        context: Context,
        conversationId: String,
        callerName: String,
        video: Boolean,
        room: String,
    ) {
        if (!NotifPrefs.calls(context)) return
        ensureChannel(context)
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("open_chat", conversationId)
            putExtra("join_call_room", room)
            putExtra("join_call_video", video)
            putExtra("join_call_from", callerName)
        }
        val pi = PendingIntent.getActivity(
            context,
            (conversationId + room).hashCode() and 0x7FFFFFFF,
            open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val kind = if (video) "Video call" else "Voice call"
        val n = NotificationCompat.Builder(context, CHANNEL_CALL)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle("$kind from $callerName")
            .setContentText("Tap to join")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setFullScreenIntent(pi, true)
            .build()
        post(context, notifId++, n)
    }

    private fun post(context: Context, id: Int, n: android.app.Notification) {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                val ok = androidx.core.content.ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS,
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (!ok) {
                    android.util.Log.w("ChatNotifier", "POST_NOTIFICATIONS not granted")
                    return
                }
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(id, n)
        } catch (e: SecurityException) {
            android.util.Log.w("ChatNotifier", "SecurityException", e)
        } catch (e: Exception) {
            android.util.Log.w("ChatNotifier", "notify failed", e)
        }
    }
}
