package com.texgen.music.texwave.arena.ui.battle

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.WarriorProfile
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import com.texgen.music.texwave.arena.ui.warrior.WarriorAvatar
import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * Arcade-style fight presentation.
 * Outcome should be supplied by server in production; local demo uses rating-weighted roll.
 * Not a real-world combat tutorial.
 */
@Composable
fun MatchmakingScreen(
    me: WarriorProfile,
    onMatched: (opponentName: String, opponentLevel: Int, didWin: Boolean) -> Unit,
    onClose: () -> Unit
) {
    var searching by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Find a ranked opponent near your level") }

    Column(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF05070F), Color(0xFF12081F), Color(0xFF05070F)))
            )
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("CHAMPIONSHIP", color = ArenaColors.Cyan, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, fontSize = 12.sp)
        Text("Ranked Matchmaking", color = ArenaColors.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Matchmaking prefers similar level & rating. Beginners are not paired with Ultimate S.",
            color = ArenaColors.Muted,
            fontSize = 12.sp
        )
        Spacer(Modifier.height(24.dp))
        WarriorAvatar(me.loadout, me.rank, me.level, size = 100)
        Text("You · Lv ${me.level} · ${me.rank.displayName}", color = ArenaColors.Text)
        Text("Rating ${me.competitiveRating}", color = ArenaColors.Muted)
        Spacer(Modifier.height(24.dp))
        Text(status, color = ArenaColors.Cyan)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                searching = true
                status = "Searching Synergy Arena…"
            },
            enabled = !searching,
            colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Violet)
        ) { Text(if (searching) "Searching…" else "Find Opponent") }
        Button(onClick = onClose) { Text("Back") }

        LaunchedEffect(searching) {
            if (!searching) return@LaunchedEffect
            delay(1800)
            // Local placeholder opponent within ±8 levels — real system uses server RPC
            val oppLv = (me.level + Random.nextInt(-5, 6)).coerceIn(1, 100)
            val oppRating = me.competitiveRating + Random.nextInt(-80, 81)
            val winChance = 0.5 + (me.competitiveRating - oppRating) / 400.0
            val didWin = Random.nextDouble() < winChance.coerceIn(0.25, 0.75)
            status = "Opponent found · Lv $oppLv"
            delay(600)
            onMatched("Rival_$oppLv", oppLv, didWin)
        }
    }
}

@Composable
fun ChampionshipArenaScreen(
    me: WarriorProfile,
    opponentName: String,
    opponentLevel: Int,
    didWin: Boolean,
    onFinished: () -> Unit
) {
    var round by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf("ENTRANCE") }
    var myHp by remember { mutableStateOf(1f) }
    var oppHp by remember { mutableStateOf(1f) }

    LaunchedEffect(Unit) {
        phase = "ENTRANCE"
        delay(1500)
        for (r in 1..3) {
            round = r
            phase = "ROUND $r"
            delay(800)
            phase = "FIGHT"
            // animate bars toward outcome
            val targetMy = if (didWin) listOf(0.7f, 0.45f, 0.2f)[r - 1] else listOf(0.55f, 0.3f, 0.05f)[r - 1]
            val targetOpp = if (didWin) listOf(0.55f, 0.3f, 0.05f)[r - 1] else listOf(0.7f, 0.45f, 0.2f)[r - 1]
            myHp = targetMy
            oppHp = targetOpp
            delay(1600)
        }
        phase = if (didWin) "VICTORY" else "DEFEAT"
    }

    val myAnim by animateFloatAsState(myHp, tween(900), label = "my")
    val oppAnim by animateFloatAsState(oppHp, tween(900), label = "opp")

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0A0E1A), Color(0xFF1A0A2E), Color(0xFF0A1520), Color(0xFF05070F))
                )
            )
    ) {
        Column(
            Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("SYNERGY STADIUM", color = ArenaColors.Cyan, letterSpacing = 2.sp, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(phase, color = ArenaColors.Text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            if (round > 0 && phase.startsWith("FIGHT") || phase.startsWith("ROUND")) {
                Text("Round $round / 3", color = ArenaColors.Muted)
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    WarriorAvatar(me.loadout, me.rank, me.level, size = 90)
                    Text(me.username, color = ArenaColors.Text, fontSize = 13.sp)
                    LinearProgressIndicator(progress = { myAnim }, modifier = Modifier.fillMaxWidth(0.35f).height(8.dp), color = ArenaColors.Cyan)
                }
                Text("VS", color = ArenaColors.Magenta, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    WarriorAvatar(me.loadout.copy(), me.rank, opponentLevel, size = 90)
                    Text(opponentName, color = ArenaColors.Text, fontSize = 13.sp)
                    LinearProgressIndicator(progress = { oppAnim }, modifier = Modifier.fillMaxWidth(0.35f).height(8.dp), color = ArenaColors.Violet)
                }
            }
            Spacer(Modifier.weight(1f))
            if (phase == "VICTORY" || phase == "DEFEAT") {
                Column(Modifier.arenaGlassCard(18).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(phase, color = if (didWin) ArenaColors.RankGold else ArenaColors.Magenta, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Arcade simulation · server must confirm ranked results in production",
                        color = ArenaColors.Muted,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = onFinished,
                        colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Cyan, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp)
                    ) { Text("Continue") }
                }
            }
        }
    }
}
