package com.texgen.music.texwave.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.catalog.OpenCatalogEngine
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private data class SavedTrack(
    val item: OpenCatalogEngine.AudioItem,
    val downloadId: Long = -1L,
    val localPath: String? = null,
) {
    fun json() = JSONObject()
        .put("id", item.id)
        .put("title", item.title)
        .put("artist", item.artist)
        .put("fileName", item.fileName)
        .put("url", item.url)
        .put("license", item.license)
        .put("downloadId", downloadId)
        .put("localPath", localPath ?: "")

    companion object {
        fun from(o: JSONObject): SavedTrack {
            val item = OpenCatalogEngine.AudioItem(
                id = o.optString("id"),
                title = o.optString("title"),
                artist = o.optString("artist"),
                fileName = o.optString("fileName"),
                url = o.optString("url"),
                license = o.optString("license"),
            )
            return SavedTrack(item, o.optLong("downloadId", -1L), o.optString("localPath").ifBlank { null })
        }
    }
}

private fun prefs(ctx: android.content.Context) =
    ctx.getSharedPreferences("texwave_offline_engine_v1", android.content.Context.MODE_PRIVATE)

private fun loadSaved(ctx: android.content.Context): List<SavedTrack> {
    val raw = prefs(ctx).getString("tracks", "[]") ?: "[]"
    return try {
        val a = JSONArray(raw)
        (0 until a.length()).mapNotNull { runCatching { SavedTrack.from(a.getJSONObject(it)) }.getOrNull() }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun saveSaved(ctx: android.content.Context, list: List<SavedTrack>) {
    val a = JSONArray()
    list.distinctBy { it.item.id }.forEach { a.put(it.json()) }
    prefs(ctx).edit().putString("tracks", a.toString()).apply()
}

@Composable
fun OfflineMusicScreen(
    onPlayDownloaded: (path: String, title: String, artist: String) -> Unit,
    onBack: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("lofi") }
    var results by remember { mutableStateOf<List<OpenCatalogEngine.AudioItem>>(emptyList()) }
    var saved by remember { mutableStateOf(loadSaved(context)) }
    var loading by remember { mutableStateOf(false) }
    var busyId by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    fun search(q: String) {
        loading = true
        error = null
        scope.launch {
            try {
                results = OpenCatalogEngine.searchAudio(q, limit = 20)
                if (results.isEmpty()) error = "No reachable open tracks. Try: lofi, piano, jazz, ambient"
            } catch (e: Exception) {
                error = e.message ?: "Search failed"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { search(query) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding()
            .padding(horizontal = 16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            if (onBack != null) IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, null, tint = Color.White)
            }
            Icon(Icons.Rounded.CloudDownload, null, tint = Tx.Accent2, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Downloads", color = Tx.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text("Verified open audio · real engine", color = Tx.Muted, fontSize = 12.sp)
            }
            IconButton(onClick = { search(query) }) {
                Icon(Icons.Rounded.Refresh, null, tint = Tx.Accent2)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Search…") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Tx.Accent2,
                    unfocusedBorderColor = Tx.Outline,
                    focusedTextColor = Tx.Text,
                    unfocusedTextColor = Tx.Text,
                    cursorColor = Tx.Accent2,
                ),
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { search(query) }, colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent)) {
                Icon(Icons.Rounded.Search, null, modifier = Modifier.size(18.dp))
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp), color = Tx.Accent2)
        error?.let { Text(it, color = Tx.Danger, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)) }

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (saved.isNotEmpty()) {
                item { Text("ON DEVICE", color = Tx.Muted, fontSize = 11.sp, letterSpacing = 1.2.sp, modifier = Modifier.padding(top = 8.dp)) }
                items(saved, key = { "s-${it.item.id}" }) { st ->
                    EngineRow(
                        title = st.item.title,
                        subtitle = st.item.artist,
                        trailing = if (busyId == st.item.id) "…" else "PLAY",
                        busy = busyId == st.item.id,
                        onClick = {
                            val path = st.localPath
                                ?: st.downloadId.takeIf { it >= 0 }?.let { OpenCatalogEngine.resolveDmPath(context, it) }
                            if (path != null) onPlayDownloaded(path, st.item.title, st.item.artist)
                            else Toast.makeText(context, "File missing — re-download", Toast.LENGTH_SHORT).show()
                        },
                    )
                }
            }
            item { Text("CATALOG (probed)", color = Tx.Muted, fontSize = 11.sp, letterSpacing = 1.2.sp, modifier = Modifier.padding(top = 12.dp)) }
            items(results, key = { it.id }) { item ->
                EngineRow(
                    title = item.title,
                    subtitle = item.artist,
                    trailing = if (busyId == item.id) "…" else "GET",
                    busy = busyId == item.id,
                    onClick = {
                        if (busyId != null) return@EngineRow
                        busyId = item.id
                        scope.launch {
                            val res = OpenCatalogEngine.downloadAudio(context, item)
                            busyId = null
                            if (res.ok && res.path != null) {
                                val st = SavedTrack(item, res.downloadId, res.path)
                                val next = (loadSaved(context) + st).distinctBy { it.item.id }
                                saveSaved(context, next)
                                saved = next
                                Toast.makeText(context, "Ready · ${item.title}", Toast.LENGTH_SHORT).show()
                                onPlayDownloaded(res.path, item.title, item.artist)
                            } else {
                                Toast.makeText(context, res.error ?: "Download failed", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                )
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}

@Composable
private fun EngineRow(
    title: String,
    subtitle: String,
    trailing: String,
    busy: Boolean,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xE6161618))
            .border(1.dp, Brush.linearGradient(listOf(Tx.Accent.copy(alpha = 0.4f), Tx.Accent2.copy(alpha = 0.35f))), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(Tx.SurfaceHigh), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.MusicNote, null, tint = Tx.Accent2)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Tx.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Tx.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Tx.Accent2, strokeWidth = 2.dp)
        else when (trailing) {
            "PLAY" -> Icon(Icons.Rounded.PlayArrow, null, tint = Tx.Accent2)
            else -> Icon(Icons.Rounded.CloudDownload, null, tint = Tx.Accent)
        }
        if (trailing == "PLAY") Icon(Icons.Rounded.DownloadDone, null, tint = Color(0xFF4ADE80), modifier = Modifier.size(16.dp).padding(start = 4.dp))
    }
}
