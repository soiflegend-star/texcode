package com.texgen.music.texwave.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.YoutubeDiscover
import com.texgen.music.texwave.ui.components.Artwork
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.seedColors

/**
 * Full similar-songs experience:
 * - Local library neighbors (playable)
 * - YouTube discoveries with real thumbnails when online
 * - Tap YouTube card → opens the video (or search fallback)
 */
@Composable
fun SimilarSongsScreen(
    seed: Song,
    localSimilar: List<Song>,
    onPlayLocal: (Song) -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var yt by remember { mutableStateOf<List<YoutubeDiscover.VideoHit>>(emptyList()) }
    val pulse = rememberInfiniteTransition(label = "sim").animateFloat(
        0.4f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "p",
    )

    LaunchedEffect(seed.id) {
        loading = true
        yt = YoutubeDiscover.searchSimilar(seed.title, seed.artist, limit = 12)
        loading = false
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF09090B))
            .statusBarsPadding(),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("Similar to", color = Color(0xFF8A93B0), fontSize = 11.sp, letterSpacing = 1.sp)
                Text(
                    seed.title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 17.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = {
                YoutubeDiscover.openYoutubeSearch(ctx, "${seed.title} ${seed.artist}")
            }) {
                Icon(Icons.Rounded.Search, "Search YouTube", tint = Color(0xFFFF4D4D))
            }
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Text(
                    "FROM YOUR LIBRARY",
                    color = Color(0xFF6B7392),
                    fontSize = 10.sp,
                    letterSpacing = 1.6.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
            if (localSimilar.isEmpty()) {
                item {
                    Text(
                        "Not enough neighbors yet — play more music and this constellation grows.",
                        color = Color(0xFF8A93B0),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }
            } else {
                itemsIndexed(localSimilar.take(16)) { i, s ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x12FFFFFF))
                            .clickable { onPlayLocal(s) }
                            .padding(10.dp)
                            .appear(i * 40),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Artwork(s, Modifier.size(48.dp), corner = 10.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.title, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.artist, color = Color(0xFF8A93B0), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Icon(Icons.Rounded.PlayArrow, null, tint = Tx.Accent2, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp))
                        Icon(
                            Icons.Rounded.OpenInNew,
                            "YouTube",
                            tint = Color(0xFFFF4444),
                            modifier = Modifier
                                .size(22.dp)
                                .clickable {
                                    YoutubeDiscover.openYoutubeSearch(ctx, "${s.title} ${s.artist}")
                                },
                        )
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "ON YOUTUBE",
                        color = Color(0xFF6B7392),
                        fontSize = 10.sp,
                        letterSpacing = 1.6.sp,
                        modifier = Modifier.weight(1f),
                    )
                    if (loading) {
                        CircularProgressIndicator(
                            Modifier.size(14.dp),
                            color = Color(0xFFFF4D4D),
                            strokeWidth = 2.dp,
                        )
                    }
                }
            }

            item {
                if (!loading && yt.isEmpty()) {
                    Text(
                        "Could not reach YouTube discovery. Tap Search to open YouTube.",
                        color = Color(0xFF8A93B0),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }

            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((((yt.size + 1) / 2) * 170).coerceAtLeast(170).dp),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    userScrollEnabled = false,
                ) {
                    items(yt) { hit ->
                        YoutubeVideoCard(hit, pulse.value) {
                            if (hit.videoId.startsWith("search")) {
                                YoutubeDiscover.openYoutubeSearch(ctx, "${hit.title} ${hit.author}")
                            } else {
                                YoutubeDiscover.openVideo(ctx, hit)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun YoutubeVideoCard(
    hit: YoutubeDiscover.VideoHit,
    pulse: Float,
    onClick: () -> Unit,
) {
    val colors = remember(hit.title) { seedColors(hit.title) }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF141416))
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 10f)
                .background(
                    Brush.linearGradient(listOf(colors.first.copy(alpha = 0.55f * pulse), colors.second.copy(alpha = 0.4f))),
                ),
        ) {
            if (hit.thumbnailUrl.isNotBlank()) {
                AsyncImage(
                    model = hit.thumbnailUrl,
                    contentDescription = hit.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xAA000000))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            ) {
                Text(
                    hit.durationLabel.ifBlank { "YT" },
                    color = Color.White,
                    fontSize = 10.sp,
                )
            }
            Icon(
                Icons.Rounded.OpenInNew,
                null,
                tint = Color(0xFFFF4444).copy(alpha = 0.9f),
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp).size(20.dp),
            )
        }
        Text(
            hit.title,
            color = Color.White,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
        )
        Text(
            hit.author.ifBlank { "YouTube" },
            color = Color(0xFF8A93B0),
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 8.dp, end = 8.dp, bottom = 8.dp),
        )
    }
}

/**
 * Ultra-thin strip for Now Playing — auto similar tracks + open full screen + YouTube.
 */
@Composable
fun SimilarStrip(
    seed: Song?,
    neighbors: List<Song>,
    onPlay: (Song) -> Unit,
    onOpenFull: () -> Unit,
    onYoutube: (Song) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (seed == null) return
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xCC121214))
            .border(1.dp, Color(0x443DE0FF), RoundedCornerShape(16.dp))
            .padding(vertical = 8.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "SIMILAR",
                color = Color(0xFFB0B8D0),
                fontSize = 11.sp,
                letterSpacing = 1.6.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            Text(
                "See all · YouTube",
                color = Color(0xFF5CEEFF),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onOpenFull)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(neighbors.take(12)) { s ->
                Row(
                    Modifier
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x28FFFFFF))
                        .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(12.dp))
                        .clickable { onPlay(s) }
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Artwork(s, Modifier.size(34.dp), corner = 8.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        s.title,
                        color = Color(0xFFF2F4FF),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.width(100.dp),
                    )
                    Icon(
                        Icons.Rounded.OpenInNew,
                        null,
                        tint = Color(0xFFFF6666),
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { onYoutube(s) },
                    )
                }
            }
            item {
                Box(
                    Modifier
                        .height(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x22FF4444))
                        .clickable(onClick = onOpenFull)
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("More", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}
