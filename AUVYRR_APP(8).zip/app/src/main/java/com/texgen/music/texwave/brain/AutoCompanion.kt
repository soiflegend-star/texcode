package com.texgen.music.texwave.brain

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.texgen.music.texwave.util.NetUtil
import com.texgen.music.texwave.util.SpeechOut
import com.texgen.music.texwave.util.VoiceInput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * The autonomous loop that joins ears, brain and voice:
 *
 *   listen (online or offline) -> read the mood -> answer (rules / Brain / online AI) -> speak -> listen again
 *
 * It keeps going hands-free until the user taps stop, or after a few quiet rounds.
 * [answer] is supplied by the app (it already knows how to play music and reach the Brain or Groq).
 */
class AutoCompanion(
    context: Context,
    private val answer: suspend (String) -> String,
) {
    enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val voice = VoiceInput(app)
    private var speech: SpeechOut? = null
    private var job: Job? = null

    private var running = false
    private var quietRounds = 0
    private var round = 0

    private val _phase = MutableStateFlow(Phase.IDLE)
    val phase: StateFlow<Phase> = _phase.asStateFlow()
    private val _heard = MutableStateFlow("")
    val heard: StateFlow<String> = _heard.asStateFlow()
    private val _reply = MutableStateFlow("")
    val reply: StateFlow<String> = _reply.asStateFlow()
    private val _status = MutableStateFlow("Tap the mic and just talk.")
    val status: StateFlow<String> = _status.asStateFlow()
    private val _mood = MutableStateFlow(Persona.Mood.NEUTRAL)
    val mood: StateFlow<Persona.Mood> = _mood.asStateFlow()

    val isRunning: Boolean get() = running

    fun hasPermission() = voice.hasPermission()

    fun start() {
        if (running) return
        if (!voice.hasPermission()) {
            _status.value = "Microphone permission is needed."
            return
        }
        running = true
        quietRounds = 0
        if (speech == null) speech = SpeechOut(app)
        listen()
    }

    fun stop(message: String = "Stopped. Tap the mic to talk again.") {
        running = false
        round++
        job?.cancel()
        voice.stop()
        speech?.stop()
        _phase.value = Phase.IDLE
        _status.value = message
    }

    fun release() {
        stop("")
        voice.release()
        speech?.shutdown()
        speech = null
    }

    private fun listen() {
        if (!running) return
        val my = ++round
        _phase.value = Phase.LISTENING
        _heard.value = ""
        val online = NetUtil.isOnline(app)
        _status.value = if (online) "Listening…" else "Listening (offline voice)…"
        voice.start(
            preferOffline = !online,
            onPartial = { if (round == my) _heard.value = it },
            onResult = { text -> if (round == my) handle(text, my) },
            onError = { err ->
                if (round != my || !running) return@start
                if (err.contains("permission", true)) { stop("Microphone permission is needed."); return@start }
                quietRounds++
                if (quietRounds >= 3) {
                    stop("Paused — I didn't hear anything. Tap the mic to continue.")
                } else {
                    _status.value = err
                    main.postDelayed({ if (running && round == my) listen() }, 700)
                }
            },
        )
    }

    private fun handle(text: String, my: Int) {
        quietRounds = 0
        _heard.value = text
        _phase.value = Phase.THINKING
        _status.value = "Thinking…"
        val mood = Persona.moodFor(text)
        _mood.value = mood
        job?.cancel()
        job = scope.launch {
            val reply = try {
                answer(text)
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) throw t
                "I couldn't process that. Please try again."
            }
            if (!running || round != my) return@launch
            _reply.value = reply
            _phase.value = Phase.SPEAKING
            _status.value = "Speaking…"
            var finished = false
            val next = {
                if (!finished) {
                    finished = true
                    if (running && round == my) main.postDelayed({ if (running && round == my) listen() }, 450)
                }
                Unit
            }
            val s = speech
            if (s == null) next() else {
                Persona.speakFor(s, reply, text, onDone = next)
                // Safety net if the voice engine never reports completion
                main.postDelayed({ next() }, (reply.length * 90L).coerceIn(4_000L, 40_000L) + 3_000L)
            }
        }
    }
}
