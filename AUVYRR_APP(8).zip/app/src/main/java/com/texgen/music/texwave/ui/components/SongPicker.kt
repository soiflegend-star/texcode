package com.texgen.music.texwave.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.texgen.music.texwave.data.SmartSearch
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.theme.Tx

/** The user's music library, available to any screen that wants to attach a song to something. */
val LocalLibrary = compositionLocalOf<LibraryState?> { null }

/** Plays one library song. Provided by MusicApp. */
val LocalPlaySong = compositionLocalOf<(Song) -> Unit> { {} }

/**
 * A song attached to a post or story is stored as one line of the caption:  "♪ Title — Artist".
 * Everyone's app can read it back, no database change needed.
 */
object SongTag {
    data class Parsed(val text: String, val title: String?, val artist: String)

    fun encode(text: String, song: Song?): String = buildString {
        if (song != null) {
            append("♪ ").append(song.title.trim())
            if (song.artist.isNotBlank() && !song.artist.contains("unknown", true)) append(" — ").append(song.artist.trim())
            append('\n')
        }
        append(text.trim())
    }.trim()

    fun parse(caption: String?): Parsed {
        val raw = caption.orEmpty()
        val line = raw.lineSequence().firstOrNull { it.startsWith("♪ ") }
            ?: return Parsed(raw.trim(), null, "")
        val body = line.removePrefix("♪ ").trim()
        val parts = body.split(" — ", limit = 2)
        val rest = raw.lineSequence().filterNot { it == line }.joinToString("\n").trim()
        return Parsed(rest, parts[0], parts.getOrElse(1) { "" })
    }
}

/** Search-and-pick dialog over the user's own songs. */
@Composable
fun SongPickerDialog(onDismiss: () -> Unit, onPick: (Song) -> Unit) {
    val lib = LocalLibrary.current
    var query by remember { mutableStateOf("") }
    val songs = remember(lib, query) {
        val l = lib ?: return@remember emptyList<Song>()
        if (query.isBlank()) {
            val byId = l.songs.associateBy { it.id }
            val recent = l.recents.mapNotNull { byId[it] }.distinctBy { it.id }
            (recent + l.songs).distinctBy { it.id }.take(80)
        } else SmartSearch.songs(l.songs, query, l.liked, l.playCounts, l.blacklist, 60)
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(top = 48.dp)
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Tx.Surface)
                .padding(16.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Choose a song", color = Tx.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Icon(
                    Icons.Rounded.Close, "Close", tint = Tx.Text,
                    modifier = Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onDismiss).padding(4.dp),
                )
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Tx.Muted) },
                placeholder = { Text("Search your library", color = Tx.Muted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Tx.Text, unfocusedTextColor = Tx.Text,
                    focusedBorderColor = Tx.Accent, unfocusedBorderColor = Tx.Outline,
                ),
            )
            Spacer(Modifier.height(8.dp))
            if (songs.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(
                        if (lib == null || lib.songs.isEmpty()) "Your library is empty — add songs and rescan."
                        else "No songs match “$query”",
                        color = Tx.Muted, fontSize = 14.sp,
                    )
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
                    items(songs, key = { it.id }) { s ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onPick(s) }
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Artwork(s, Modifier.size(46.dp), corner = 10.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.title, color = Tx.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.artist, color = Tx.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Small "♪ Title — Artist" pill. Tap plays it when it is in the viewer's own library. */
@Composable
fun SongChip(title: String, artist: String, modifier: Modifier = Modifier, onClear: (() -> Unit)? = null, playable: Boolean = true) {
    val lib = LocalLibrary.current
    val play = LocalPlaySong.current
    val context = LocalContext.current
    Row(
        modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Color(0x33000000))
            .background(Tx.Accent.copy(alpha = 0.18f))
            .clickable(enabled = playable) {
                val l = lib
                val hit = l?.let { SmartSearch.songs(it.songs, "$title $artist".trim(), it.liked, it.playCounts, it.blacklist, 1).firstOrNull() }
                if (hit != null) play(hit)
                else Toast.makeText(context, "“$title” isn't in your library", Toast.LENGTH_SHORT).show()
            }
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (playable) Icons.Rounded.PlayArrow else Icons.Rounded.MusicNote, null, tint = Tx.Accent, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(
            if (artist.isBlank()) title else "$title · $artist",
            color = Tx.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        if (onClear != null) {
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Rounded.Close, "Remove song", tint = Tx.Muted, modifier = Modifier.size(18.dp).clickable(onClick = onClear))
        }
    }
}

