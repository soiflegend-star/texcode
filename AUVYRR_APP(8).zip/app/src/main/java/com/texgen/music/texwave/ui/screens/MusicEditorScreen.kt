package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.background
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.data.MusicEditor
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.components.Artwork
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.formatDuration
import kotlinx.coroutines.launch

@Composable
fun MusicEditorScreen(
    songs: List<Song>,
    onBack: () -> Unit,
    onExported: () -> Unit,
) {
    var selected by remember { mutableStateOf<Song?>(null) }
    val song = selected

    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = {
                if (song != null) selected = null else onBack()
            }) {
                Icon(Icons.Rounded.ArrowBack, "Back", tint = Tx.Text)
            }
            Text(
                if (song == null) "Music Editor" else "Trim · ${song.title}",
                color = Tx.Text,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        if (song == null) {
            Text(
                "Select a track to trim. Edited files are saved to Music/AUVYRR and appear after a library scan.",
                color = Tx.Muted,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(songs, key = { it.id }) { s ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Tx.Surface)
                            .clickable { selected = s }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Artwork(s, Modifier.size(48.dp), corner = 10.dp, iconSize = 20.dp)
                        Column(Modifier.weight(1f)) {
                            Text(
                                s.title,
                                color = Tx.Text,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                "${s.artist} · ${formatDuration(s.durationMs)}",
                                color = Tx.Muted,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Icon(Icons.Rounded.ContentCut, null, tint = Tx.Accent2, modifier = Modifier.size(20.dp))
                    }
                }
            }
        } else {
            TrimEditor(song = song, onDone = { selected = null; onExported() })
        }
    }
}

@Composable
private fun TrimEditor(song: Song, onDone: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val duration = song.durationMs.coerceAtLeast(1L).toFloat()
    var start by remember { mutableFloatStateOf(0f) }
    var end by remember { mutableFloatStateOf(duration) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(song.contentUri) {
        val real = MusicEditor.getDurationMs(context, song.contentUri)
        if (real > 0) {
            end = real.toFloat()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Artwork(song, Modifier.size(72.dp), corner = 14.dp, iconSize = 28.dp)
            Column {
                Text(song.title, color = Tx.Text, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                Text(song.artist, color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Tx.Surface)
                .padding(16.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Start  ${formatDuration(start.toLong())}", color = Tx.Muted, style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = start.coerceIn(0f, end - 500f),
                    onValueChange = { start = it.coerceIn(0f, end - 500f) },
                    valueRange = 0f..duration,
                    colors = SliderDefaults.colors(
                        thumbColor = Tx.Accent2,
                        activeTrackColor = Tx.Accent,
                        inactiveTrackColor = Tx.Outline,
                    ),
                )
                Text("End  ${formatDuration(end.toLong())}", color = Tx.Muted, style = MaterialTheme.typography.labelSmall)
                Slider(
                    value = end.coerceIn(start + 500f, duration),
                    onValueChange = { end = it.coerceIn(start + 500f, duration) },
                    valueRange = 0f..duration,
                    colors = SliderDefaults.colors(
                        thumbColor = Tx.Accent2,
                        activeTrackColor = Tx.Accent,
                        inactiveTrackColor = Tx.Outline,
                    ),
                )
                Text(
                    "Clip length: ${formatDuration((end - start).toLong())}",
                    color = Tx.Text,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        status?.let {
            Text(it, color = if (it.startsWith("Saved")) Tx.Accent2 else Tx.Muted, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.weight(1f))

        Button(
            onClick = {
                if (busy) return@Button
                busy = true
                status = "Exporting…"
                scope.launch {
                    val result = MusicEditor.trim(
                        context = context,
                        sourceUri = song.contentUri,
                        startMs = start.toLong(),
                        endMs = end.toLong(),
                        outputName = "${song.title}_edit",
                    )
                    busy = false
                    status = result.message
                    if (result.success) onDone()
                }
            },
            enabled = !busy && (end - start) >= 500f,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent),
        ) {
            if (busy) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Tx.Text, strokeWidth = 2.dp)
            } else {
                Icon(Icons.Rounded.Check, null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(8.dp))
                Text("Export trimmed track")
            }
        }
    }
}
