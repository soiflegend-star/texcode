package com.texgen.music.texwave.sonara.player

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.texgen.music.texwave.MainActivity
import java.io.File

/**
 * Sonara Media3 playback host.
 * HTTP redirects, buffering, audio focus, MediaSession (notification / lock screen).
 */
@UnstableApi
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private var player: ExoPlayer? = null
    private var errorRetries = 0

    private val playerListener = object : Player.Listener {
        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            Companion.audioSessionId = audioSessionId
        }

        override fun onPlayerError(error: PlaybackException) {
            // Retry transient network / source errors a few times
            val transient = error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                || error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                || error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS
                || error.errorCode == PlaybackException.ERROR_CODE_TIMEOUT
            if (transient && errorRetries < 2) {
                errorRetries++
                player?.prepare()
                player?.play()
            } else {
                errorRetries = 0
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) errorRetries = 0
        }
    }

    override fun onCreate() {
        super.onCreate()

        // Reuse a bounded disk cache: repeat plays and revisits start from local bytes.
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Sonara/1.0 (Android; Media3)")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(5_000)
            .setReadTimeoutMs(15_000)
            .setDefaultRequestProperties(mapOf("Accept-Encoding" to "identity"))

        val cacheDataSourceFactory = CacheDataSource.Factory()
            .setCache(mediaCache())
            .setUpstreamDataSourceFactory(httpFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs */ 8_000,
                /* maxBufferMs */ 45_000,
                /* bufferForPlaybackMs */ 650,
                /* bufferForPlaybackAfterRebufferMs */ 1_500
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val exo = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(cacheDataSourceFactory))
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()

        exo.addListener(playerListener)
        audioSessionId = exo.audioSessionId
        player = exo

        val sessionActivity = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, exo)
            .setId("sonara_session")
            .setSessionActivity(sessionActivity)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        mediaSession?.run {
            player?.removeListener(playerListener)
            player?.release()
            release()
            mediaSession = null
        }
        player = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var audioSessionId: Int = C.AUDIO_SESSION_ID_UNSET
            private set

        @Volatile
        private var sharedMediaCache: SimpleCache? = null

        private fun PlaybackService.mediaCache(): SimpleCache = synchronized(PlaybackService::class.java) {
            sharedMediaCache ?: SimpleCache(
                File(cacheDir, "sonara_stream_cache"),
                LeastRecentlyUsedCacheEvictor(256L * 1024L * 1024L),
                StandaloneDatabaseProvider(applicationContext)
            ).also { sharedMediaCache = it }
        }
    }
}
