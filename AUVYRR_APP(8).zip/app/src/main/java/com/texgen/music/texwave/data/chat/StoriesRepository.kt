package com.texgen.music.texwave.data.chat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.rpc
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.storage.storage
import io.github.jan.supabase.storage.upload
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.ByteArrayOutputStream
import java.util.UUID

@Serializable
data class Story(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("media_url") val mediaUrl: String,
    @SerialName("caption") val caption: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("expires_at") val expiresAt: String? = null,
)

@Serializable
data class StoryWithAuthor(
    val id: String,
    @SerialName("user_id") val userId: String,
    @SerialName("media_url") val mediaUrl: String,
    @SerialName("caption") val caption: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("expires_at") val expiresAt: String? = null,
    val username: String? = null,
    @SerialName("display_name") val displayName: String? = null,
    @SerialName("avatar_url") val avatarUrl: String? = null,
)

/**
 * 24h Stories — requires stories table + stories bucket (see CREATE_STORIES_AND_CHAT.sql).
 */
class StoriesRepository(private val chat: ChatRepository) {
    private val tag = "StoriesRepo"

    /** Everyone's live stories, with author names. Falls back to the plain table if the RPC is missing. */
    suspend fun listActive(): Result<List<StoryWithAuthor>> = withContext(Dispatchers.IO) {
        runCatching {
            try {
                chat.rawClient().postgrest.rpc("list_active_stories").decodeList<StoryWithAuthor>()
            } catch (e: Exception) {
                Log.w(tag, "list_active_stories rpc failed, using table", e)
                chat.rawClient().from("stories")
                    .select {
                        filter { gt("expires_at", java.time.Instant.now().toString()) }
                        order("created_at", Order.DESCENDING)
                        limit(80)
                    }
                    .decodeList<Story>()
                    .map {
                        StoryWithAuthor(
                            id = it.id, userId = it.userId, mediaUrl = it.mediaUrl, caption = it.caption,
                            createdAt = it.createdAt, expiresAt = it.expiresAt,
                        )
                    }
            }
        }.onFailure { Log.w(tag, "list stories", it) }
    }

    fun myUserId(): String? = runCatching { chat.rawCurrentUserId() }.getOrNull()

    suspend fun delete(storyId: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            chat.rawClient().from("stories").delete { filter { eq("id", storyId) } }
            Unit
        }
    }

    suspend fun publish(context: Context, uri: Uri, caption: String?): Result<Story> =
        withContext(Dispatchers.IO) {
            runCatching {
                val me = chat.rawCurrentUserId()
                val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                val isVideo = mime.startsWith("video/")
                val bytes: ByteArray
                val ext: String
                if (isVideo) {
                    bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: error("Cannot read video")
                    require(bytes.size <= 10_485_760) { "Video max 10 MB for stories" }
                    ext = "mp4"
                } else {
                    bytes = compress(context, uri)
                    ext = "jpg"
                }
                val path = "$me/${UUID.randomUUID()}.$ext"
                chat.rawClient().storage.from("stories").upload(path, bytes, upsert = true)
                val url = "${SupabaseConfig.SUPABASE_URL.trimEnd('/')}/storage/v1/object/public/stories/$path"
                chat.rawClient().from("stories").insert(
                    kotlinx.serialization.json.buildJsonObject {
                        put("user_id", me)
                        put("media_url", url)
                        put("caption", caption?.take(120) ?: "")
                    }
                ) { select() }.decodeSingle<Story>()
            }
        }

    private fun compress(context: Context, uri: Uri): ByteArray {
        val input = context.contentResolver.openInputStream(uri) ?: error("Cannot read image")
        val bmp = BitmapFactory.decodeStream(input) ?: error("Bad image")
        val max = 1080
        val scale = minOf(1f, max.toFloat() / maxOf(bmp.width, bmp.height))
        val w = (bmp.width * scale).toInt().coerceAtLeast(1)
        val h = (bmp.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return out.toByteArray()
    }
}

