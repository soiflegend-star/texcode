package com.texgen.music.texwave.veltrix

import android.content.Context
import com.texgen.music.texwave.veltrix.data.VeltrixStore
import com.texgen.music.texwave.veltrix.engine.VeltrixEngine
import com.texgen.music.texwave.veltrix.engine.VeltrixScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Veltrix entry point for AUVYRR / SONARA (TexWave).
 *
 * Call [init] once from Application.onCreate (or first time Veltrix UI opens).
 * Show UI with [com.texgen.music.texwave.veltrix.ui.VeltrixRoot].
 */
object Veltrix {
    lateinit var store: VeltrixStore
        private set
    lateinit var engine: VeltrixEngine
        private set

    @Volatile
    private var ready = false

    fun init(context: Context) {
        if (ready) return
        val app = context.applicationContext
        store = VeltrixStore(app)
        engine = VeltrixEngine(app, store)
        ready = true
        CoroutineScope(Dispatchers.IO).launch {
            store.load()
            VeltrixScheduler.scheduleEnabled(app, store)
        }
    }

    fun isReady(): Boolean = ready
}
