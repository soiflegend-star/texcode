package com.texgen.music.texwave.ui.screens

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.AlarmEngine
import com.texgen.music.texwave.data.Days
import com.texgen.music.texwave.ui.ref.AlarmBackdrop
import com.texgen.music.texwave.ui.ref.AlarmPresets
import com.texgen.music.texwave.ui.ref.DefaultAlarmTheme
import java.io.File
import java.util.Calendar

internal data class Draft(
    val id: Int?,
    val hour: Int,
    val minute: Int,
    val label: String,
    val days: Int,
    val sound: String,
    val soundName: String,
    val theme: String,
    val snooze: Int = 5,
    val vibrate: Boolean = true,
    val icon: String = "auto",
)

internal fun untilLabel(trigger: Long): String {
    val m = ((trigger - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0)
    val h = m / 60
    return when {
        h >= 24 -> "in ${h / 24}d ${h % 24}h"
        h > 0 -> "in ${h}h ${m % 60}m"
        else -> "in ${m}m"
    }
}
@Composable
internal fun AlarmEditor(d: Draft, prefs: android.content.SharedPreferences, onChange: (Draft) -> Unit, onSave: (Draft) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current

    val songPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        onChange(d.copy(sound = uri.toString(), soundName = uri.lastPathSegment?.substringAfterLast('/') ?: "My song"))
    }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        @Suppress("DEPRECATION")
        val uri = r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        if (uri != null) {
            val name = runCatching { RingtoneManager.getRingtone(context, uri).getTitle(context) }.getOrDefault("Ringtone")
            onChange(d.copy(sound = uri.toString(), soundName = name))
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            val out = File(context.filesDir, "alarm_theme_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
            onChange(d.copy(theme = out.absolutePath))
        }.onFailure { Toast.makeText(context, "Could not load that picture", Toast.LENGTH_SHORT).show() }
    }

    Box(Modifier.fillMaxSize().background(AV.Bg).clickable(enabled = false) { }) {
        AlarmBackdrop(d.theme, scrim = 0.75f)
        Column(
            Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
        ) {
            Text(if (d.id == null) "New alarm" else "Edit alarm", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(16.dp))

            // Time
            Column(
                Modifier.fillMaxWidth().avGlass(24.dp, true).clickable {
                    TimePickerDialog(context, { _, h, m -> onChange(d.copy(hour = h, minute = m)) }, d.hour, d.minute, true).show()
                }.padding(vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("%02d:%02d".format(d.hour, d.minute), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
                Text("Tap to change time · " + untilLabel(AlarmEngine.nextTrigger(d.hour, d.minute, d.days)), color = AV.Cyan, fontSize = 13.sp)
            }

            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = d.label, onValueChange = { onChange(d.copy(label = it.take(40))) },
                singleLine = true, placeholder = { Text("Label (optional)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
            )
            Spacer(Modifier.height(14.dp))
            Text("Repeat", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Once" to 0, "Every day" to Days.ALL, "Weekdays" to Days.WEEKDAYS, "Weekend" to Days.WEEKEND)) { (name, mask) ->
                    AvChip(name, d.days == mask) { onChange(d.copy(days = mask)) }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for (i in 0..6) {
                    val on = d.days and (1 shl i) != 0
                    Box(
                        Modifier.size(40.dp).clip(CircleShape)
                            .background(if (on) AV.Purple else AV.Glass)
                            .border(1.dp, if (on) AV.Cyan.copy(alpha = 0.8f) else AV.Line, CircleShape)
                            .clickable { onChange(d.copy(days = d.days xor (1 shl i))) },
                        contentAlignment = Alignment.Center,
                    ) { Text(Days.letters[i], color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Snooze", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 15).forEach { m -> AvChip("$m min", d.snooze == m) { onChange(d.copy(snooze = m)) } }
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Vibration", color = Color.White, fontSize = 16.sp)
                    Text("Phone vibrates while the alarm rings", color = AV.Sub, fontSize = 12.sp)
                }
                Switch(
                    checked = d.vibrate, onCheckedChange = { onChange(d.copy(vibrate = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = AV.Purple, checkedThumbColor = Color.White),
                )
            }

            Spacer(Modifier.height(14.dp))
            Text("Icon", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(listOf("auto", "sun", "moon", "dumbbell", "bell", "work")) { k ->
                    val sel = d.icon == k
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (sel) AV.Purple.copy(alpha = 0.35f) else AV.Glass)
                            .border(if (sel) 2.dp else 1.dp, if (sel) AV.Cyan else AV.Line, RoundedCornerShape(16.dp))
                            .clickable { onChange(d.copy(icon = k)) },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (k == "auto") Icon(Icons.Rounded.AutoAwesome, "Auto", tint = if (sel) AV.Cyan else Color.White, modifier = Modifier.size(26.dp))
                        else Icon(alarmIcon(k, d.hour), k, tint = if (sel) AV.Cyan else Color.White, modifier = Modifier.size(26.dp))
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Text("Wake-up sound", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            SoundOption(
                Icons.Rounded.AutoAwesome, "Phantom voice only", "Silent alarm — Phantom talks you awake",
                selected = d.sound == "silent",
            ) { onChange(d.copy(sound = "silent", soundName = "Phantom voice only")) }
            SoundOption(
                Icons.Rounded.VolumeUp, "Default alarm tone", "Your phone's alarm sound",
                selected = d.sound.isBlank(),
            ) { onChange(d.copy(sound = "", soundName = "")) }
            SoundOption(
                Icons.Rounded.Notifications, "System ringtone", if (d.sound.isNotBlank() && d.sound != "silent" && d.soundName.isNotBlank()) d.soundName else "Choose from your phone's list",
                selected = false,
            ) {
                val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Alarm sound")
                }
                ringtonePicker.launch(i)
            }
            SoundOption(
                Icons.Rounded.MusicNote, "My song", "Pick any audio file from your phone",
                selected = false,
            ) { songPicker.launch("audio/*") }
            if (d.sound.isNotBlank() && d.sound != "silent") {
                Text("Selected: ${d.soundName.ifBlank { "Custom sound" }}", color = AV.Cyan, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp, top = 4.dp))
            }

            Spacer(Modifier.height(18.dp))
            Text("Alarm picture", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Shown full-screen when the alarm rings", color = AV.Sub, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(AlarmPresets, key = { it.id }) { p ->
                    val sel = d.theme == "preset:" + p.id
                    val s = RoundedCornerShape(18.dp)
                    Column(Modifier.width(86.dp).clickable { onChange(d.copy(theme = "preset:" + p.id)) }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(86.dp, 112.dp).clip(s)
                                .border(if (sel) 2.5.dp else 1.dp, if (sel) AV.Cyan else AV.Line, s),
                        ) {
                            androidx.compose.foundation.Image(painterResource(p.res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            if (sel) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp).background(AV.Cyan, CircleShape))
                        }
                        Text(p.label, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                item {
                    val custom = d.theme.startsWith("/")
                    val s = RoundedCornerShape(18.dp)
                    Column(Modifier.width(86.dp).clickable { imagePicker.launch("image/*") }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(86.dp, 112.dp).clip(s).background(AV.Glass)
                                .border(if (custom) 2.5.dp else 1.dp, if (custom) AV.Cyan else AV.Purple.copy(alpha = 0.6f), s),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (custom) AlarmBackdrop(d.theme, scrim = 0.1f)
                            Icon(Icons.Rounded.Image, null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        Text("My photo", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier.weight(1f).height(54.dp).avGlass(27.dp).clickable(onClick = onCancel),
                    contentAlignment = Alignment.Center,
                ) { Text("Cancel", color = Color.White, fontSize = 16.sp) }
                Box(
                    Modifier.weight(1.4f).height(54.dp).clip(RoundedCornerShape(27.dp))
                        .background(Brush.horizontalGradient(listOf(AV.Purple, AV.Cyan)))
                        .clickable {
                            prefs.edit().putString("default_sound", d.sound).putString("default_sound_name", d.soundName).putString("default_theme", d.theme).apply()
                            onSave(d)
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("Save alarm", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
internal fun SoundOption(icon: ImageVector, title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).avGlass(18.dp, selected).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = if (selected) AV.Cyan else Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = AV.Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (selected) Icon(Icons.Rounded.Check, null, tint = AV.Cyan, modifier = Modifier.size(22.dp))
    }
}

@Composable
internal fun BriefingOptions(prefs: android.content.SharedPreferences) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().avGlass(20.dp).padding(14.dp)) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = AV.Purple, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Phantom morning briefing", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("What Phantom says when the alarm rings", color = AV.Sub, fontSize = 12.sp)
            }
            Text(if (open) "Hide" else "Edit", color = AV.Cyan, fontSize = 14.sp)
        }
        if (open) {
            var city by remember { mutableStateOf(prefs.getString("briefing_city", "Delhi") ?: "Delhi") }
            OutlinedTextField(
                value = city, onValueChange = { city = it; prefs.edit().putString("briefing_city", it.trim()).apply() },
                label = { Text("City for weather") }, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp), shape = RoundedCornerShape(16.dp),
            )
            listOf(
                "say_greeting" to "Greeting", "say_time" to "Time & day", "say_label" to "Alarm label",
                "say_weather" to "Weather", "say_battery" to "Battery",
            ).forEach { (key, name) ->
                var on by remember { mutableStateOf(prefs.getBoolean(key, true)) }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = Color(0xFFDCE5FF), fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = on, onCheckedChange = { on = it; prefs.edit().putBoolean(key, it).apply() },
                        colors = SwitchDefaults.colors(checkedTrackColor = AV.Purple, checkedThumbColor = Color.White),
                    )
                }
            }
        }
    }
}

@Composable
internal fun AvChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val sh = RoundedCornerShape(50)
    Box(
        Modifier.clip(sh)
            .background(if (selected) AV.Purple.copy(alpha = 0.4f) else AV.Glass)
            .border(1.dp, if (selected) AV.Cyan else AV.Line, sh)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp),
    ) { Text(text, color = Color.White, fontSize = 14.sp) }
}
