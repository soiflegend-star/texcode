package com.texgen.music.texwave.brain

import com.texgen.music.texwave.util.SpeechOut
import java.util.Calendar
import java.util.Locale

/**
 * AUVYRR's voice character: a serious, high-end hi-fi system — composed, exact, never chatty —
 * that quietly adapts its tone to the mood it hears in the user's words.
 */
object Persona {
    enum class Mood { NEUTRAL, TIRED, SAD, STRESSED, ANGRY, HAPPY, CONFUSED }

    @Volatile private var lastMood = Mood.NEUTRAL
    @Volatile private var lastAt = 0L

    private val rules: List<Pair<Mood, Regex>> = listOf(
        Mood.ANGRY to Regex("\\b(angry|furious|pissed|hate|annoyed|annoying|irritated|fed up|mad at)\\b"),
        Mood.STRESSED to Regex("\\b(stress|stressed|anxious|anxiety|overwhelm|overwhelmed|panic|worried|nervous|deadline|pressure)\\b"),
        Mood.SAD to Regex("\\b(sad|down|lonely|depress|depressed|cry|crying|bad day|heartbroken|miss (her|him|them|you)|hurt)\\b"),
        Mood.TIRED to Regex("\\b(tired|sleepy|exhausted|drained|no energy|can'?t sleep|cannot sleep|insomnia|yawn|lazy)\\b"),
        Mood.CONFUSED to Regex("\\b(confused|don'?t understand|do not understand|what do you mean|not sure how|lost)\\b"),
        Mood.HAPPY to Regex("\\b(happy|great|awesome|amazing|excited|love it|fantastic|party|celebrate|good mood|wonderful|yay)\\b"),
    )

    /** Mood from the words; a calm follow-up keeps the previous mood for ten minutes. */
    fun moodFor(text: String): Mood {
        val t = text.lowercase(Locale.getDefault())
        val hit = rules.firstOrNull { it.second.containsMatchIn(t) }?.first
        val now = System.currentTimeMillis()
        val mood = when {
            hit != null -> hit
            now - lastAt < 10 * 60_000L -> lastMood
            else -> Mood.NEUTRAL
        }
        lastMood = mood
        if (hit != null) lastAt = now
        return mood
    }

    fun currentMood(): Mood = lastMood

    /** How the character behaves for each mood (used in every AI prompt). */
    fun styleFor(mood: Mood): String = when (mood) {
        Mood.TIRED -> "The user sounds tired. Speak softly and briefly, one idea at a time, no energy or excitement. Offer something gentle (slow music, rest)."
        Mood.SAD -> "The user sounds low. Be steady, warm and composed. Acknowledge it in one short sentence, never cheerful or dramatic, never dismissive. Offer calm music if it fits."
        Mood.STRESSED -> "The user sounds stressed. Be very calm, grounding and extremely concise. Short clear sentences. Offer one simple next step or calming music."
        Mood.ANGRY -> "The user sounds frustrated. Stay level and respectful, do not argue or apologise excessively. Be brief and solve the problem directly."
        Mood.HAPPY -> "The user sounds happy. Match the lift with a little more warmth and pace, still precise and refined, no exclamation marks."
        Mood.CONFUSED -> "The user is confused. Explain plainly in short clear steps, no jargon."
        Mood.NEUTRAL -> "Speak with calm, precise authority."
    }

    /** The core character, shared by every on-device and online answer. */
    fun voiceDirective(mood: Mood): String =
        "You are AUVYRR, a high-end hi-fi audio system with a serious, refined, composed voice. " +
            "Be exact and concise, like a studio instrument: no slang, no emojis, no exclamation marks, no filler or small talk padding. " +
            "Never state facts you cannot know; if unsure, say so plainly. " + styleFor(mood)

    fun speechPitch(mood: Mood): Float = when (mood) {
        Mood.TIRED, Mood.SAD -> 0.94f
        Mood.STRESSED, Mood.ANGRY -> 0.97f
        Mood.HAPPY -> 1.05f
        else -> 1.0f
    }

    fun speechRate(mood: Mood): Float = when (mood) {
        Mood.TIRED, Mood.SAD -> 0.88f
        Mood.STRESSED -> 0.9f
        Mood.ANGRY -> 0.93f
        Mood.HAPPY -> 1.0f
        else -> 0.95f
    }

    /** Speak a reply in the voice that fits the user's mood. */
    fun speakFor(speech: SpeechOut, reply: String, userText: String, onDone: (() -> Unit)? = null) {
        val m = moodFor(userText)
        speech.speakStyled(reply, speechPitch(m), speechRate(m), onDone)
    }

    // ------------------------------------------------------------------ internet awareness

    private val needsNet = Regex(
        "\\b(weather|forecast|rain(ing)?|temperature|news|headlines?|score|who won|stock|share price|price of|bitcoin|crypto|" +
            "exchange rate|traffic|translate|wikipedia|google|search (the )?(web|internet|online)|look (it )?up|latest|" +
            "trending|what'?s happening|live (match|score)|today'?s (news|match))\\b",
    )
    private val localCommand = Regex("^(play|pause|resume|stop|next|previous|skip|volume|shuffle|repeat)\\b")

    /** True when the question can only be answered with live internet data. */
    fun needsInternet(q: String): Boolean {
        val t = q.lowercase(Locale.getDefault()).trim()
        if (localCommand.containsMatchIn(t)) return false
        return needsNet.containsMatchIn(t)
    }

    fun noInternetReply(q: String, mood: Mood): String {
        val t = q.lowercase(Locale.getDefault())
        val what = when {
            Regex("weather|forecast|rain|temperature").containsMatchIn(t) -> "the weather"
            Regex("news|headline").containsMatchIn(t) -> "the news"
            Regex("score|match|who won").containsMatchIn(t) -> "live scores"
            Regex("stock|price|bitcoin|crypto|exchange").containsMatchIn(t) -> "live prices"
            Regex("translate").containsMatchIn(t) -> "translations"
            else -> "that"
        }
        val lead = when (mood) {
            Mood.SAD, Mood.TIRED, Mood.STRESSED -> "I'm sorry. "
            else -> ""
        }
        return lead + "There is no internet connection right now, so I can't check $what. " +
            "Music, your alarms and conversation are fully available offline. Ask me again once you're connected."
    }

    // ------------------------------------------------------------------ truthful greeting

    private val offlineLines = listOf(
        "A new day. A new start.",
        "Fresh day, clean slate. Make it yours.",
        "A new morning, a new beginning.",
        "Today is a new page. Begin it well.",
    )

    /**
     * Only verifiable facts: the real time of day, the real time, the real date, and the alarm's own name.
     * No weather, news or claims that were not measured. Offline adds a short, fixed motivational line.
     */
    fun greeting(label: String, online: Boolean, extraTruth: String? = null): String {
        val c = Calendar.getInstance()
        val hour = c.get(Calendar.HOUR_OF_DAY)
        val salute = when {
            hour < 5 -> "Good night"
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        val h12 = c.get(Calendar.HOUR).let { if (it == 0) 12 else it }
        val ampm = if (c.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"
        val min = c.get(Calendar.MINUTE)
        val time = if (min == 0) "$h12 $ampm" else "$h12:%02d $ampm".format(min)
        val day = c.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()).orEmpty()
        val month = c.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault()).orEmpty()
        val dateText = "$day, $month ${c.get(Calendar.DAY_OF_MONTH)}"
        val tag = if (label.isNotBlank() && label != "AUVYRR Alarm") " Your alarm: $label." else ""
        val core = "$salute. It's $time, $dateText.$tag"
        return when {
            !extraTruth.isNullOrBlank() && online -> "$core $extraTruth"
            hour < 12 -> "$core ${offlineLines[(c.get(Calendar.DAY_OF_YEAR)) % offlineLines.size]}"
            else -> core
        }
    }
}
