package com.texgen.music.texwave.data.chat

/**
 * AUVYRR Chat — Supabase client configuration.
 * Project URL + publishable/anon key for client use only.
 * Never put service_role / secret keys here.
 */
object SupabaseConfig {
    const val SUPABASE_URL = "https://ascwhsyyznwgchexboug.supabase.co"
    const val SUPABASE_ANON_KEY = "sb_publishable_dbg8KLLzWJhMzU2tSiC2zQ_fC7lx4Rn"

    const val MAX_FILE_BYTES = 50L * 1024 * 1024
    /** Big videos are cut into parts of this size (safely under the 50 MB storage limit). */
    const val CHUNK_BYTES = 40L * 1024 * 1024
    /** Largest video that can be sent in parts. */
    const val MAX_CHUNKED_BYTES = 500L * 1024 * 1024
    const val STORAGE_BUCKET = "chat-files"
    /** Public bucket for profile photos (created by CREATE_STORAGE_BUCKETS.sql). */
    const val AVATAR_BUCKET = "avatars"
    /** Public bucket for community photo posts. App falls back to avatars if this is missing. */
    const val SOCIAL_MEDIA_BUCKET = "social-media"

    val isConfigured: Boolean
        get() = SUPABASE_ANON_KEY.isNotBlank()
                && !SUPABASE_ANON_KEY.contains("YOUR_ANON")
}
