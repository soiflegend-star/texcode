package com.texgen.music.texwave.veltrix.model

import kotlinx.serialization.Serializable
import java.util.UUID

enum class VxNodeKind {
    TRIGGER_MANUAL,
    TRIGGER_TIME,
    TRIGGER_BOOT,
    TRIGGER_BATTERY,
    TRIGGER_CHARGING,
    TRIGGER_NETWORK,
    ACTION_NOTIFICATION,
    ACTION_DELAY,
    ACTION_OPEN_URL,
    ACTION_OPEN_APP,
    ACTION_HTTP,
    ACTION_SET_VAR,
    ACTION_LOG,
    ACTION_VIBRATE,
    ACTION_SHARE,
    ACTION_CLIPBOARD,
    ACTION_DEVICE_INFO,
    CONDITION
}

enum class VxAutomationStatus { DRAFT, ENABLED, DISABLED }

enum class VxRunStatus { RUNNING, SUCCESS, FAILED, CANCELLED }

@Serializable
data class VxConfig(val key: String, val value: String = "", val label: String = key)

@Serializable
data class VxNode(
    val id: String = UUID.randomUUID().toString(),
    val kind: VxNodeKind,
    val title: String,
    val x: Float = 80f,
    val y: Float = 120f,
    val configs: List<VxConfig> = emptyList()
) {
    fun c(key: String): String = configs.find { it.key == key }?.value ?: ""
}

@Serializable
data class VxLink(
    val id: String = UUID.randomUUID().toString(),
    val fromId: String,
    val toId: String,
    val label: String = "" // "true" / "false" for conditions
)

@Serializable
data class VxAutomation(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val status: VxAutomationStatus = VxAutomationStatus.DRAFT,
    val nodes: List<VxNode> = emptyList(),
    val links: List<VxLink> = emptyList(),
    val variables: Map<String, String> = emptyMap(),
    val favorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val lastRunAt: Long? = null,
    val runCount: Int = 0,
    val successCount: Int = 0,
    val failureCount: Int = 0
)

@Serializable
data class VxLogLine(
    val time: Long = System.currentTimeMillis(),
    val level: String,
    val nodeId: String? = null,
    val message: String
)

@Serializable
data class VxExecution(
    val id: String = UUID.randomUUID().toString(),
    val automationId: String,
    val automationName: String,
    val status: VxRunStatus = VxRunStatus.RUNNING,
    val trigger: String = "manual",
    val startedAt: Long = System.currentTimeMillis(),
    val finishedAt: Long? = null,
    val logs: List<VxLogLine> = emptyList(),
    val error: String? = null,
    val vars: Map<String, String> = emptyMap()
)

fun defaultConfigs(kind: VxNodeKind): List<VxConfig> = when (kind) {
    VxNodeKind.TRIGGER_TIME -> listOf(
        VxConfig("hour", "8", "Hour (0-23)"),
        VxConfig("minute", "0", "Minute"),
        VxConfig("repeatDaily", "true", "Repeat daily")
    )
    VxNodeKind.TRIGGER_BATTERY -> listOf(
        VxConfig("operator", "<", "Operator (<, >, ==)"),
        VxConfig("level", "20", "Battery %")
    )
    VxNodeKind.TRIGGER_CHARGING -> listOf(VxConfig("state", "connected", "connected / disconnected"))
    VxNodeKind.TRIGGER_NETWORK -> listOf(VxConfig("state", "connected", "connected / disconnected"))
    VxNodeKind.ACTION_NOTIFICATION -> listOf(
        VxConfig("title", "Veltrix", "Title"),
        VxConfig("body", "Automation ran", "Body")
    )
    VxNodeKind.ACTION_DELAY -> listOf(VxConfig("ms", "1000", "Milliseconds"))
    VxNodeKind.ACTION_OPEN_URL -> listOf(VxConfig("url", "https://", "URL"))
    VxNodeKind.ACTION_OPEN_APP -> listOf(VxConfig("package", "", "Package name"))
    VxNodeKind.ACTION_HTTP -> listOf(
        VxConfig("method", "GET", "Method"),
        VxConfig("url", "https://", "URL"),
        VxConfig("saveAs", "http_body", "Save as variable")
    )
    VxNodeKind.ACTION_SET_VAR -> listOf(
        VxConfig("key", "myVar", "Variable"),
        VxConfig("value", "", "Value")
    )
    VxNodeKind.ACTION_LOG -> listOf(VxConfig("message", "", "Message"))
    VxNodeKind.ACTION_VIBRATE -> listOf(VxConfig("ms", "200", "Milliseconds"))
    VxNodeKind.ACTION_SHARE -> listOf(VxConfig("text", "", "Text"))
    VxNodeKind.ACTION_CLIPBOARD -> listOf(VxConfig("text", "", "Text to copy"))
    VxNodeKind.CONDITION -> listOf(
        VxConfig("left", "{{battery}}", "Left"),
        VxConfig("operator", "<", "Operator"),
        VxConfig("right", "20", "Right")
    )
    else -> emptyList()
}

fun kindTitle(kind: VxNodeKind): String = when (kind) {
    VxNodeKind.TRIGGER_MANUAL -> "Manual Trigger"
    VxNodeKind.TRIGGER_TIME -> "Time / Schedule"
    VxNodeKind.TRIGGER_BOOT -> "Device Boot"
    VxNodeKind.TRIGGER_BATTERY -> "Battery Level"
    VxNodeKind.TRIGGER_CHARGING -> "Charging State"
    VxNodeKind.TRIGGER_NETWORK -> "Network State"
    VxNodeKind.ACTION_NOTIFICATION -> "Notification"
    VxNodeKind.ACTION_DELAY -> "Delay"
    VxNodeKind.ACTION_OPEN_URL -> "Open URL"
    VxNodeKind.ACTION_OPEN_APP -> "Open App"
    VxNodeKind.ACTION_HTTP -> "HTTP Request"
    VxNodeKind.ACTION_SET_VAR -> "Set Variable"
    VxNodeKind.ACTION_LOG -> "Log"
    VxNodeKind.ACTION_VIBRATE -> "Vibrate"
    VxNodeKind.ACTION_SHARE -> "Share Text"
    VxNodeKind.ACTION_CLIPBOARD -> "Clipboard"
    VxNodeKind.ACTION_DEVICE_INFO -> "Device Info"
    VxNodeKind.CONDITION -> "Condition"
}
