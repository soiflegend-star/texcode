package com.texgen.music.texwave.sonara.data.cost

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.costStore by preferencesDataStore("sonara_cost_monitor")

/**
 * Free-tier cost / usage awareness.
 * Tracks approximate client-side counters so admins can see pressure before
 * infrastructure limits are hit. Server-side metrics remain authoritative.
 *
 * Does not call paid APIs. Does not auto-purchase anything.
 */
class CostMonitor(private val context: Context) {

    private val streamBytesKey = longPreferencesKey("est_stream_bytes")
    private val apiCallsKey = longPreferencesKey("api_calls")
    private val catalogueFetchesKey = longPreferencesKey("catalogue_fetches")
    private val searchCountKey = longPreferencesKey("searches")

    data class Snapshot(
        val estimatedStreamBytes: Long = 0,
        val apiCalls: Long = 0,
        val catalogueFetches: Long = 0,
        val searches: Long = 0,
        /** Soft thresholds for free-tier caution (illustrative, not provider-specific). */
        val streamBytesSoftLimit: Long = 5L * 1024 * 1024 * 1024, // 5 GB est.
        val apiCallsSoftLimit: Long = 50_000,
    ) {
        val streamUsageRatio: Float
            get() = if (streamBytesSoftLimit <= 0) 0f
            else (estimatedStreamBytes.toFloat() / streamBytesSoftLimit).coerceIn(0f, 2f)
        val apiUsageRatio: Float
            get() = if (apiCallsSoftLimit <= 0) 0f
            else (apiCalls.toFloat() / apiCallsSoftLimit).coerceIn(0f, 2f)
        val nearLimit: Boolean get() = streamUsageRatio >= 0.8f || apiUsageRatio >= 0.8f
        val estimatedStreamMb: Long get() = estimatedStreamBytes / (1024 * 1024)
    }

    val snapshot: Flow<Snapshot> = context.costStore.data.map { prefs ->
        Snapshot(
            estimatedStreamBytes = prefs[streamBytesKey] ?: 0L,
            apiCalls = prefs[apiCallsKey] ?: 0L,
            catalogueFetches = prefs[catalogueFetchesKey] ?: 0L,
            searches = prefs[searchCountKey] ?: 0L,
        )
    }

    suspend fun recordStreamProgress(bytesApprox: Long) {
        if (bytesApprox <= 0) return
        context.costStore.edit {
            it[streamBytesKey] = (it[streamBytesKey] ?: 0L) + bytesApprox
        }
    }

    suspend fun recordApiCall() {
        context.costStore.edit { it[apiCallsKey] = (it[apiCallsKey] ?: 0L) + 1 }
    }

    suspend fun recordCatalogueFetch() {
        context.costStore.edit {
            it[catalogueFetchesKey] = (it[catalogueFetchesKey] ?: 0L) + 1
            it[apiCallsKey] = (it[apiCallsKey] ?: 0L) + 1
        }
    }

    suspend fun recordSearch() {
        context.costStore.edit {
            it[searchCountKey] = (it[searchCountKey] ?: 0L) + 1
            it[apiCallsKey] = (it[apiCallsKey] ?: 0L) + 1
        }
    }
}
