package com.texgen.music.texwave.sonara.data.upload

import android.content.Context
import android.net.Uri
import com.texgen.music.texwave.sonara.data.remote.SupabaseProvider
import com.texgen.music.texwave.sonara.rights.ContentSubmission
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class UploadResult {
    data class Success(val storagePath: String, val submission: ContentSubmission) : UploadResult()
    data class Progress(val fraction: Float) : UploadResult()
    data class Failure(val message: String) : UploadResult()
    data class QueuedLocally(val submission: ContentSubmission, val reason: String) : UploadResult()
}

/**
 * Uploads real audio bytes to Supabase Storage when configured.
 * Falls back to local submission queue when Supabase is unavailable.
 */
class AudioUploadRepository(private val context: Context) {

    private val maxBytes = 40L * 1024 * 1024 // 40MB

    suspend fun upload(
        audioUri: Uri?,
        submission: ContentSubmission,
        onProgress: (Float) -> Unit = {},
    ): UploadResult = withContext(Dispatchers.IO) {
        val client = SupabaseProvider.client
        if (client == null || audioUri == null) {
            return@withContext UploadResult.QueuedLocally(
                submission,
                if (client == null) "Supabase not configured — metadata queued locally"
                else "No audio URI — metadata only"
            )
        }
        try {
            val bytes = context.contentResolver.openInputStream(audioUri)?.use { it.readBytes() }
                ?: return@withContext UploadResult.Failure("Cannot read audio file")
            if (bytes.size > maxBytes) {
                return@withContext UploadResult.Failure("File exceeds 40MB limit")
            }
            val mime = context.contentResolver.getType(audioUri) ?: "audio/mpeg"
            if (!mime.startsWith("audio/") && mime != "application/octet-stream") {
                return@withContext UploadResult.Failure("Unsupported MIME: $mime")
            }
            onProgress(0.1f)
            val path = "uploads/${submission.submitterId.ifBlank { "anon" }}/${UUID.randomUUID()}.audio"
            client.storage.from("music").upload(path, bytes, upsert = false)
            onProgress(1f)
            UploadResult.Success(path, submission.copy(status = "pending"))
        } catch (e: Exception) {
            UploadResult.Failure(e.message ?: "Upload failed")
        }
    }
}
