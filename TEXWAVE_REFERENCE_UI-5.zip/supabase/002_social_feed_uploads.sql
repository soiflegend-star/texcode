-- TEXWAVE social feed: user-uploaded photo/video posts, likes and comments.
-- Run in Supabase SQL Editor after the existing chat schema.
create extension if not exists pgcrypto;

create table if not exists public.social_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  media_url text not null,
  media_path text not null,
  media_type text not null check (media_type in ('image','video')),
  caption text not null default '' check (char_length(caption) <= 2200),
  download_allowed boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists social_posts_created_at_idx on public.social_posts(created_at desc);
create index if not exists social_posts_user_id_idx on public.social_posts(user_id, created_at desc);

create table if not exists public.social_post_likes (
  post_id uuid not null references public.social_posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);
create table if not exists public.social_post_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.social_posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);
create index if not exists social_post_comments_post_idx on public.social_post_comments(post_id, created_at asc);

alter table public.social_posts enable row level security;
alter table public.social_post_likes enable row level security;
alter table public.social_post_comments enable row level security;

drop policy if exists "social posts visible to signed in users" on public.social_posts;
create policy "social posts visible to signed in users" on public.social_posts for select to authenticated using (true);
drop policy if exists "users create own social posts" on public.social_posts;
create policy "users create own social posts" on public.social_posts for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "users update own social posts" on public.social_posts;
create policy "users update own social posts" on public.social_posts for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "users delete own social posts" on public.social_posts;
create policy "users delete own social posts" on public.social_posts for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "likes visible to signed in users" on public.social_post_likes;
create policy "likes visible to signed in users" on public.social_post_likes for select to authenticated using (true);
drop policy if exists "users like as themselves" on public.social_post_likes;
create policy "users like as themselves" on public.social_post_likes for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "users unlike themselves" on public.social_post_likes;
create policy "users unlike themselves" on public.social_post_likes for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "comments visible to signed in users" on public.social_post_comments;
create policy "comments visible to signed in users" on public.social_post_comments for select to authenticated using (true);
drop policy if exists "users create own comments" on public.social_post_comments;
create policy "users create own comments" on public.social_post_comments for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "users delete own comments" on public.social_post_comments;
create policy "users delete own comments" on public.social_post_comments for delete to authenticated using (auth.uid() = user_id);

-- Create the public media bucket and restrict uploads/updates/deletes to each owner's folder.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('social-media', 'social-media', true, 26214400,
  array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public = true, file_size_limit = 26214400,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif'];

drop policy if exists "social media public read" on storage.objects;
create policy "social media public read" on storage.objects for select using (bucket_id = 'social-media');
drop policy if exists "social media owner upload" on storage.objects;
create policy "social media owner upload" on storage.objects for insert to authenticated
with check (bucket_id = 'social-media' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "social media owner update" on storage.objects;
create policy "social media owner update" on storage.objects for update to authenticated
using (bucket_id = 'social-media' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'social-media' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "social media owner delete" on storage.objects;
create policy "social media owner delete" on storage.objects for delete to authenticated
using (bucket_id = 'social-media' and (storage.foldername(name))[1] = auth.uid()::text);
