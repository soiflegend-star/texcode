-- TEXWAVE: create storage buckets (run once in Supabase SQL Editor)
-- Fixes: "Bucket not found" for chat photos, avatars, and community photo posts

insert into storage.buckets (id, name, public, file_size_limit)
values ('chat-files', 'chat-files', false, 52428800)
on conflict (id) do update set file_size_limit = excluded.file_size_limit;

insert into storage.buckets (id, name, public, file_size_limit)
values ('avatars', 'avatars', true, 5242880)
on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit;

-- Community photo posts (images only — no reels/video upload)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'social-media',
  'social-media',
  true,
  26214400,
  array['image/jpeg','image/png','image/webp','image/gif']
)
on conflict (id) do update set
  public = true,
  file_size_limit = 26214400,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif'];

-- Policies for chat-files
drop policy if exists "Chat files: participants can upload" on storage.objects;
drop policy if exists "Chat files: participants can download" on storage.objects;
drop policy if exists "Chat files: owner can delete" on storage.objects;
drop policy if exists "Chat files authenticated upload" on storage.objects;
drop policy if exists "Chat files authenticated read" on storage.objects;

create policy "Chat files authenticated upload"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-files');

create policy "Chat files authenticated read"
  on storage.objects for select to authenticated
  using (bucket_id = 'chat-files');

create policy "Chat files: owner can delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'chat-files' and owner = auth.uid());

-- Avatars
drop policy if exists "Avatars: public read" on storage.objects;
drop policy if exists "Avatars: owner insert" on storage.objects;
drop policy if exists "Avatars: owner update" on storage.objects;
drop policy if exists "Avatars: owner delete" on storage.objects;

create policy "Avatars: public read"
  on storage.objects for select to public
  using (bucket_id = 'avatars');

create policy "Avatars: owner insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Avatars: owner update"
  on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Avatars: owner delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- Social media photos
drop policy if exists "social media public read" on storage.objects;
drop policy if exists "social media owner upload" on storage.objects;
drop policy if exists "social media owner update" on storage.objects;
drop policy if exists "social media owner delete" on storage.objects;

create policy "social media public read"
  on storage.objects for select using (bucket_id = 'social-media');

create policy "social media owner upload"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'social-media' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "social media owner update"
  on storage.objects for update to authenticated
  using (bucket_id = 'social-media' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'social-media' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "social media owner delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'social-media' and (storage.foldername(name))[1] = auth.uid()::text);

select id, name, public from storage.buckets where id in ('chat-files', 'avatars', 'social-media');
