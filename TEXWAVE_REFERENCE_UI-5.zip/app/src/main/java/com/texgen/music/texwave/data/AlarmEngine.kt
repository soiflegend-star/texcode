package com.texgen.music.texwave.data

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import com.texgen.music.texwave.AlarmRingActivity
import com.texgen.music.texwave.notification.TexwaveAlarmReceiver
import org.json.JSONArray
import java.util.Calendar

/**
 * Industrial alarm scheduler — dual-path (AlarmClock + exact while-idle),
 * boot reschedule, exact-alarm capability checks.
 */
object AlarmEngine {

    private const val PREFS = "texwave_alarms"

    fun ensureExactPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return try {
            if (am.canScheduleExactAlarms()) true
            else {
                runCatching {
                    context.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = android.net.Uri.parse("package:${context.packageName}")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        },
                    )
                }
                Toast.makeText(context, "Allow exact alarms for reliable wake-ups", Toast.LENGTH_LONG).show()
                false
            }
        } catch (_: Exception) {
            true
        }
    }

    fun nextTrigger(hour: Int, minute: Int): Long {
        return Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 2_000L) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }.timeInMillis
    }

    fun schedule(
        context: Context,
        id: Int,
        hour: Int,
        minute: Int,
        label: String,
        soundUri: String?,
        triggerAt: Long = nextTrigger(hour, minute),
    ) {
        ensureExactPermission(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fire = Intent(context, TexwaveAlarmReceiver::class.java).apply {
            action = "com.texgen.music.texwave.ALARM_FIRE"
            putExtra("alarm_id", id)
            putExtra("alarm_label", label)
            putExtra("alarm_sound", soundUri.orEmpty())
            // Explicit component so the system always delivers to us
            setClass(context, TexwaveAlarmReceiver::class.java)
        }
        val broadcast = PendingIntent.getBroadcast(
            context,
            id,
            fire,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        // Backup PendingIntent with different request code (survives some OEM cancel quirks)
        val backup = PendingIntent.getBroadcast(
            context,
            id + 90_000,
            Intent(fire),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val show = PendingIntent.getActivity(
            context,
            id + 50_000,
            Intent(context, AlarmRingActivity::class.java).apply {
                putExtra(AlarmRingActivity.EXTRA_ALARM_ID, id)
                putExtra(AlarmRingActivity.EXTRA_LABEL, label)
                putExtra(AlarmRingActivity.EXTRA_SOUND, soundUri.orEmpty())
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        // Path 1: AlarmClock (shows in system clock, highest reliability when allowed)
        runCatching {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), broadcast)
        }
        // Path 2: exact while-idle backup so Doze cannot silently drop the wake-up
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, backup)
            } else {
                @Suppress("DEPRECATION")
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, backup)
            }
        }.onFailure {
            runCatching { am.set(AlarmManager.RTC_WAKEUP, triggerAt, backup) }
        }
    }

    fun cancel(context: Context, id: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fire = Intent(context, TexwaveAlarmReceiver::class.java)
        listOf(id, id + 90_000).forEach { req ->
            val pi = PendingIntent.getBroadcast(
                context,
                req,
                fire,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            am.cancel(pi)
        }
    }

    fun rescheduleAll(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString("alarms", "[]")) }.getOrNull() ?: return
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (!o.optBoolean("enabled", true)) continue
            val id = o.optInt("id")
            val hour = o.optInt("hour")
            val minute = o.optInt("minute")
            val label = o.optString("label", "TEXWAVE Alarm")
            val sound = if (o.isNull("soundUri")) null else o.optString("soundUri", null)
            schedule(context, id, hour, minute, label, sound)
        }
    }
}
