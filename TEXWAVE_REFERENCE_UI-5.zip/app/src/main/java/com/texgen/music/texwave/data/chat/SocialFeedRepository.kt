package com.texgen.music.texwave.data.chat

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID

@Serializable
data class SocialPost(
    val id: String,
    val user_id: String,
    val media_url: String,
    val media_path: String,
    val media_type: String,
    val caption: String = "",
    val download_allowed: Boolean = true,
    val created_at: String = "",
)

@Serializable
data class SocialLike(val post_id: String, val user_id: String)

@Serializable
data class SocialComment(
    val id: String,
    val post_id: String,
    val user_id: String,
    val body: String,
    val created_at: String = "",
)

/** Uses the same authenticated Supabase client as chat; no second login/session is created. */
class SocialFeedRepository private constructor(private val context: Context) {
    private val chat = ChatRepository.get(context)
    private fun client() = chat.rawClient()
    fun myUserId(): String = chat.rawCurrentUserId()

    suspend fun feed(): Result<List<SocialPost>> = withContext(Dispatchers.IO) {
        runCatching {
            client().from("social_posts").select {
                order("created_at", Order.DESCENDING)
                limit(100)
            }.decodeList<SocialPost>()
        }
    }

    suspend fun publish(uri: Uri, caption: String, mediaType: String): Result<SocialPost> = withContext(Dispatchers.IO) {
        // Community is photo-only (no reel/video upload).
        require(mediaType == "image") { "Community posts are photos only." }
        publishImageBytes(
            bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Could not read the selected file."),
            caption = caption,
            mime = context.contentResolver.getType(uri) ?: "image/jpeg",
        )
    }

    /** Upload a JPEG/PNG as a community photo post.
     *  Tries public buckets in order so a missing "social-media" bucket does not block sharing. */
    suspend fun publishImageBytes(bytes: ByteArray, caption: String, mime: String = "image/jpeg"): Result<SocialPost> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(bytes.isNotEmpty() && bytes.size <= 25 * 1024 * 1024) { "Image must be under 25 MB." }
                require(mime.startsWith("image/")) { "Photos only — video/reel upload is disabled." }
                val userId = chat.rawCurrentUserId()
                require(userId.isNotBlank()) { "Sign in to share a photo." }
                val ext = when {
                    mime.contains("png") -> "png"
                    mime.contains("webp") -> "webp"
                    else -> "jpg"
                }
                val path = "$userId/${UUID.randomUUID()}.$ext"
                // Prefer dedicated social bucket; fall back to public avatars so posts still work.
                val buckets = listOf(
                    SupabaseConfig.SOCIAL_MEDIA_BUCKET,
                    SupabaseConfig.AVATAR_BUCKET,
                )
                var usedBucket: String? = null
                var lastError: Throwable? = null
                for (bucket in buckets) {
                    try {
                        client().storage.from(bucket).upload(path, bytes, upsert = false)
                        usedBucket = bucket
                        break
                    } catch (t: Throwable) {
                        lastError = t
                        val msg = (t.message ?: "").lowercase()
                        val missing = "bucket not found" in msg || "bucket_not_found" in msg ||
                            ("not found" in msg && "bucket" in msg)
                        if (!missing) throw t
                    }
                }
                if (usedBucket == null) {
                    throw lastError ?: IllegalStateException(
                        "Photo storage is not set up. Run CREATE_STORAGE_BUCKETS.sql in the Supabase SQL Editor.",
                    )
                }
                val publicUrl = "${SupabaseConfig.SUPABASE_URL}/storage/v1/object/public/$usedBucket/$path"
                client().from("social_posts").insert(buildJsonObject {
                    put("user_id", userId)
                    put("media_url", publicUrl)
                    put("media_path", path)
                    put("media_type", "image")
                    put("caption", caption.trim().take(2200))
                    put("download_allowed", true)
                }) { select() }.decodeSingle<SocialPost>()
            }
        }

    suspend fun likesFor(postId: String): Result<List<SocialLike>> = withContext(Dispatchers.IO) {
        runCatching { client().from("social_post_likes").select { filter { eq("post_id", postId) } }.decodeList<SocialLike>() }
    }

    suspend fun toggleLike(postId: String, currentlyLiked: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val me = chat.rawCurrentUserId()
            if (currentlyLiked) client().from("social_post_likes").delete { filter { eq("post_id", postId); eq("user_id", me) } }
            else client().from("social_post_likes").insert(buildJsonObject { put("post_id", postId); put("user_id", me) })
            Unit
        }
    }

    suspend fun commentsFor(postId: String): Result<List<SocialComment>> = withContext(Dispatchers.IO) {
        runCatching { client().from("social_post_comments").select { filter { eq("post_id", postId) }; order("created_at", Order.ASCENDING) }.decodeList<SocialComment>() }
    }

    suspend fun addComment(postId: String, body: String): Result<SocialComment> = withContext(Dispatchers.IO) {
        runCatching {
            val text = body.trim()
            require(text.isNotEmpty() && text.length <= 1000) { "Comment must be 1–1000 characters." }
            client().from("social_post_comments").insert(buildJsonObject {
                put("post_id", postId); put("user_id", chat.rawCurrentUserId()); put("body", text)
            }) { select() }.decodeSingle<SocialComment>()
        }
    }

    companion object {
        @Volatile private var instance: SocialFeedRepository? = null
        fun get(context: Context): SocialFeedRepository = instance ?: synchronized(this) {
            instance ?: SocialFeedRepository(context.applicationContext).also { instance = it }
        }
    }
}
