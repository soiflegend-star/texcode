package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.ui.theme.Tx
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.State
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.util.UiSound
import kotlin.math.abs
import kotlin.math.sin
import kotlinx.coroutines.delay

/** Returns a function that plays a UI sound (respects the user's sound toggle). */
@Composable
fun rememberUiSound(): (UiSound.Kind) -> Unit {
    val ctx = LocalContext.current
    return remember(ctx) { { kind: UiSound.Kind -> UiSound.play(ctx, kind) } }
}

/** Majestic entrance: fade + rise + slight scale bloom. */
fun Modifier.appear(delayMs: Int = 0, riseDp: Int = 18): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        a.animateTo(1f, tween(720, easing = FastOutSlowInEasing))
    }
    this.graphicsLayer {
        val v = a.value
        alpha = v
        translationY = (1f - v) * riseDp * density
        scaleX = 0.94f + 0.06f * v
        scaleY = 0.94f + 0.06f * v
    }
}

/** Staggered entrance for lists — each row rises a moment after the previous. */
fun Modifier.staggerAppear(index: Int, stepMs: Int = 48, riseDp: Int = 14): Modifier =
    appear(delayMs = (index * stepMs).coerceAtMost(720), riseDp = riseDp)

/** Soft breathing glow scale for icons / orbs. */
fun Modifier.neonBreath(active: Boolean = true): Modifier = composed {
    if (!active) return@composed this
    val t = rememberInfiniteTransition(label = "neonBreath")
    val s by t.animateFloat(
        0.97f, 1.04f,
        infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathS",
    )
    this.graphicsLayer { scaleX = s; scaleY = s }
}

/** Sweeping holographic border energy. */
fun Modifier.holographicBorder(
    shapeRadiusDp: Float = 20f,
    colors: List<Color> = listOf(Tx.Accent2, Tx.Accent, Tx.Accent3, Tx.Accent2),
): Modifier = composed {
    val t = rememberInfiniteTransition(label = "holo")
    val phase by t.animateFloat(
        0f, 1000f,
        infiniteRepeatable(tween(3500, easing = LinearEasing)),
        label = "holoPhase",
    )
    this.drawBehind {
        val r = shapeRadiusDp * density
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = colors.map { it.copy(alpha = 0.75f) },
                start = Offset(phase, 0f),
                end = Offset(phase + 400f, size.height),
            ),
            style = Stroke(width = 1.6f * density),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
        )
    }
}

/**
 * Clickable that squishes slightly while pressed (no ripple), for cards and glowing buttons.
 * Also gives a light haptic tick on tap (set [haptic] = false to silence it).
 */
fun Modifier.pressable(pressedScale: Float = 0.94f, haptic: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val feedback = androidx.compose.ui.platform.LocalHapticFeedback.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) pressedScale else 1f,
        spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "press",
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null) {
            if (haptic) runCatching {
                feedback.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
            }
            onClick()
        }
}

/** Slowly twinkling stars + drifting dust; drawn only (no recomposition) so it is cheap. */
@Composable
fun TwinkleField(modifier: Modifier = Modifier, count: Int = 36, tint: Color = Color(0xFFCFE8FF)) {
    val t = rememberInfiniteTransition(label = "twinkle")
    val phase = t.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "twinklePhase",
    )
    Canvas(modifier) {
        val p = phase.value
        for (i in 0 until count) {
            val x = ((i * 137 + 31) % 1000) / 1000f * size.width
            val baseY = ((i * 71 + 17) % 1000) / 1000f * size.height
            val y = baseY - ((p * (6 + i % 5) * 3f) % 14f) * density
            val a = 0.12f + 0.55f * (0.5f + 0.5f * sin(p * (1 + i % 3) + i))
            drawCircle(tint.copy(alpha = a), (0.6f + (i % 4) * 0.35f) * density, Offset(x, y))
        }
    }
}

/**
 * Majestic neon waveform matching the concept Now Playing screen.
 * Middle continuous line stays fixed (does not travel/wave).
 * Vertical bars move and react to music energy.
 */
@Composable
fun WaveBars(
    active: Boolean,
    modifier: Modifier = Modifier,
    bars: Int = 64,
    energyState: State<Float>? = null,
) {
    val baseEnergy by animateFloatAsState(
        if (active) 1f else 0.18f,
        tween(500, easing = FastOutSlowInEasing),
        label = "waveEnergy",
    )
    val t = rememberInfiniteTransition(label = "waveBars")
    // Phase drives the bars only — not the center line
    val phase = t.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(
            tween(if (active) 1400 else 3600, easing = LinearEasing),
            RepeatMode.Restart,
        ),
        label = "barPhase",
    )
    val breath = t.animateFloat(
        0.94f, 1.06f,
        infiniteRepeatable(
            tween(if (active) 2000 else 4000, easing = FastOutSlowInEasing),
            RepeatMode.Reverse,
        ),
        label = "lineBreath",
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (w <= 1f || h <= 1f) return@Canvas
        val live = (energyState?.value ?: 0.4f).coerceIn(0f, 1.5f)
        val energy = (baseEnergy * (0.5f + 0.65f * live)).coerceIn(0.15f, 1.5f)
        val p = phase.value
        val cy = h / 2f

        // FIXED middle continuous line — shape never scrolls, only soft amplitude breath
        fun waveY(nx: Float): Float {
            val amp = h * 0.28f * energy * breath.value
            return cy + (
                sin(nx * 9.5f) * 0.55f +
                sin(nx * 17f + 0.4f) * 0.28f +
                sin(nx * 4.2f - 0.2f) * 0.17f
            ) * amp
        }

        val wavePath = Path()
        var x = 0f
        while (x <= w) {
            val y = waveY(x / w)
            if (x == 0f) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
            x += 2f
        }
        drawPath(
            wavePath,
            Tx.Accent2.copy(alpha = 0.14f + 0.12f * energy),
            style = Stroke(width = 11f * density, cap = StrokeCap.Round),
        )
        drawPath(
            wavePath,
            Brush.horizontalGradient(
                listOf(Tx.Accent2, Color(0xFF7B6CFF), Tx.Accent3),
                0f, w,
            ),
            style = Stroke(width = 2.6f * density, cap = StrokeCap.Round),
        )

        // MOVING vertical bars — animate with phase + music energy
        val step = w / bars
        val brush = Brush.horizontalGradient(
            listOf(Tx.Accent2, Color(0xFF5B8CFF), Tx.Accent, Tx.Accent3),
            0f, w,
        )
        for (i in 0 until bars) {
            val u = i / (bars - 1f).coerceAtLeast(1f)
            val env = 0.2f + 0.8f * (1f - abs(u - 0.5f) * 1.65f).coerceIn(0f, 1f)
            val v = abs(sin(p * 2.2f + i * 0.45f)) * 0.5f +
                abs(sin(p * 3.1f - i * 0.28f)) * 0.35f +
                abs(sin(p * 1.4f + i * 0.61f)) * 0.15f
            val barH = (0.08f + v * env * energy) * h * 0.5f
            val bx = step * (i + 0.5f)
            drawLine(
                brush,
                Offset(bx, cy - barH),
                Offset(bx, cy + barH),
                strokeWidth = (step * 0.4f).coerceAtLeast(1.5f),
                cap = StrokeCap.Round,
                alpha = 0.88f,
            )
        }
    }
}




/** Animated specular sweep across a glass surface. */
fun Modifier.glassShimmer(cornerDp: Int = 18): Modifier = composed {
    val t = rememberInfiniteTransition(label = "glassShimmer")
    val x by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2800, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmerX",
    )
    this
        .clip(RoundedCornerShape(cornerDp.dp))
        .drawBehind {
            val w = size.width
            val h = size.height
            val band = w * 0.35f
            val left = -band + (w + band * 2f) * x
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.White.copy(alpha = 0.06f),
                        Color.White.copy(alpha = 0.16f),
                        Color.White.copy(alpha = 0.06f),
                        Color.Transparent,
                    ),
                    startX = left,
                    endX = left + band,
                ),
                size = size,
            )
        }
}

/** Soft float — for cards resting on glass. */
fun Modifier.softFloat(amplitudeDp: Float = 4f, durationMs: Int = 3200): Modifier = composed {
    val t = rememberInfiniteTransition(label = "softFloat")
    val y by t.animateFloat(
        -amplitudeDp, amplitudeDp,
        infiniteRepeatable(tween(durationMs, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "floatY",
    )
    this.graphicsLayer { translationY = y * density }
}
