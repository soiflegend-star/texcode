# Camera feature dependency note

```kotlin
// app/build.gradle.kts — additional to existing TEXWAVE deps
implementation("androidx.camera:camera-core:1.3.1")
implementation("androidx.camera:camera-camera2:1.3.1")
implementation("androidx.camera:camera-lifecycle:1.3.1")
implementation("androidx.camera:camera-view:1.3.1")
implementation("com.google.mediapipe:tasks-vision:0.10.14")
```

Asset: `pose_landmarker_lite.task` in `app/src/main/assets/`

minSdk 26 is compatible with CameraX 1.3 and MediaPipe Tasks 0.10.x.
