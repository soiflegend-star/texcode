# Online Multiplayer Championship Engine

## Combat model (fair)

Rounds use **STRIKE / GUARD / FEINT** (RPS).  
**Not** decided by lifetime push-up totals. Training XP and competitive rating are separate.

## Server RPCs (`004_online_matchmaking.sql`)

| RPC | Purpose |
|-----|---------|
| `arena_mm_enqueue` | Ranked queue; pairs rating±150, level±12 |
| `arena_mm_cancel_queue` | Leave queue |
| `arena_mm_invite` / `arena_mm_respond_invite` | Friend challenge → match |
| `arena_match_ready` | Both ready → ACTIVE |
| `arena_match_submit_action` | Submit round action; resolves when both in |
| `arena_match_finalize` | Internal — Elo + W/L + XP (not client-callable) |
| `arena_match_abandon` | Forfeit → opponent wins |

Clients have **no** INSERT/UPDATE on `arena_online_matches` or `arena_warriors` rating fields.

## Client

- `MatchRepository` / `SupabaseMatchRepository`
- `SimulatedMatchRepository` — UI only; **not** online
- `OnlineMatchScreen` — queue → ready → actions → result
- Realtime: subscribe to `arena_online_matches` with `id=eq.<matchId>` in TEXWAVE host (poll fallback included)

## What is required for “two devices complete a match”

1. Apply SQL 001–004  
2. `ArenaModule.initSupabase` + inject `SupabaseMatchRepository(client)`  
3. Enable Supabase Realtime on `arena_online_matches` and `arena_match_actions`  
4. Two authenticated users; both open Online matchmaking  
5. Verify `arena_warriors` rating and `arena_online_matches.status=COMPLETED` on server  

**This environment did not run two-account live tests.**

## Simulation vs online

| Mode | When |
|------|------|
| Simulation | Default `SimulatedMatchRepository` / local `arena_matchmaking` cinematic |
| Online | `SupabaseMatchRepository` after migrations + auth |

Do not market simulation as online multiplayer.
