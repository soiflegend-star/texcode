# Online match security report

## Static design

- Unauthenticated: all RPCs require `auth.uid()`  
- Player B cannot act on match unless `player_a|player_b`  
- Fake victory: no client path to set `winner_id`  
- Duplicate result: finalize is idempotent (`status = COMPLETED` early return)  
- Replay: actions primary key `(match_id, round, user_id)`  
- Rating: only `arena_match_finalize`  
- Abandon: scores forced then finalize  

## Runtime

**NOT EXECUTED** against live Supabase with two accounts in this audit environment.

Required host tests listed in ONLINE_MULTIPLAYER.md.
