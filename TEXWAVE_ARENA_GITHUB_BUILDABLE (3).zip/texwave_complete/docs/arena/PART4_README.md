# TEXWAVE ARENA — Part 4

**Scope delivered**

- Multi-scope leaderboards: All-time, Weekly, Monthly, Friends
- Distinct top-3 podium
- Current user rank always visible
- Squad detail (members, roles, contribution XP)
- Squad rankings list
- Create / leave squad (with ownership guard)
- Visiting leaderboard marks the “Check the ranks” daily mission complete

**Leaderboard**

| Scope | Metric | Reset |
|-------|--------|-------|
| All-time | Total XP | never |
| Weekly | Weekly XP | Monday 00:00 local |
| Monthly | Monthly XP | 1st of month |
| Friends | Total XP (friends + self) | — |

Demo population keeps boards full; your live XP from Parts 2–3 is injected so rank moves when you log activity.

**Squad system**

- Roles: Owner · Admin · Member  
- Owner cannot leave while other members remain (must transfer first — transfer UI in a later polish pass)  
- Contribution XP per member  
- Global squad ranking list  

**New files**

```
domain/LeaderboardEngine.kt
data/model/ArenaModels.kt          (Leaderboard*, Squad*)
data/repository/ArenaRepository.kt (observeLeaderboard, squad APIs)
ui/leaderboard/LeaderboardScreen.kt
ui/squads/SquadsScreen.kt
ui/navigation/ArenaNav.kt          (Ranks + Squads live)
```

**How to test**

1. Open **Ranks** → switch All-time / Weekly / Friends → see podium + your row  
2. Log more push-ups → refresh → your XP and rank update  
3. Open **Squads** → see Night Operators, members, rankings  
4. Leave squad → create a new one  

**Next: Part 5**

Achievements engine + share cards, Supabase schema / RLS, integration guide, final combined ZIP.
