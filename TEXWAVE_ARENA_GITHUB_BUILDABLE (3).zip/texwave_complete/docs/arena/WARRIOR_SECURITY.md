# Warrior / Match Security Notes

- Clients cannot INSERT into `arena_matches` (no policy).
- Warrior cosmetics saved only via `arena_save_warrior` RPC.
- Wins/losses/rating on `arena_warriors` have no client UPDATE policy.
- Matchmaking UI outcome is **presentation**; do not write rating from client.
- Future: edge function creates match, assigns opponent within rating band, finalizes result once, awards XP via `arena_apply_xp` only.
