# TEXWAVE ARENA — Part 1

**Scope of this part**

- Isolated `arena` package layout (ready for later merge into TEXWAVE)
- Arena design system extensions that reuse TEXWAVE `Tx` colors
- Core domain models (Player, Rank, ActivityType, etc.)
- Navigation graph for the 8 main sections
- Premium **Arena Home** dashboard (Compose)
- Local / in-memory repository stubs (real Supabase arrives in Part 5)
- Loading / empty / error states on Home

**Not in Part 1** (coming in later parts)

- Real activity logging & persistence
- XP calculation engine & anti-cheat
- Challenges, missions, leaderboards, squads, achievements
- Supabase tables, RLS, edge functions
- Camera recognition extension point

**How this will be combined later**

All five parts will live under `com.texgen.music.texwave.arena.*`.  
Part 5 will provide the final Gradle module integration guide and a single ZIP.

---

## Package layout (Part 1)

```
com.texgen.music.texwave.arena
├── data
│   ├── model/          # pure data classes
│   ├── local/          # Room / SharedPrefs stubs (empty for now)
│   └── repository/     # ArenaRepository interface + local impl
├── domain              # pure business helpers (XP formulas later)
└── ui
    ├── theme/          # ArenaTheme extensions
    ├── navigation/     # ArenaNav, routes, bottom bar
    ├── components/     # reusable Arena cards, progress rings, rank badges
    └── home/           # ArenaHomeScreen + ViewModel
```

## Design alignment

- Background: `Tx.Bg` / deep black
- Primary cyan: `Tx.Accent2` (`#00DDF5`)
- Violet: `Tx.Accent` (`#9B70FF`)
- Magenta accent: `Tx.Accent3`
- Glass cards, subtle glows, controlled neon — same language as the rest of TEXWAVE

## Running / testing Part 1

This is source only. After all parts are delivered we will drop the `arena` package into the real TEXWAVE project and wire a single entry point from the existing SideNav / bottom navigation.
