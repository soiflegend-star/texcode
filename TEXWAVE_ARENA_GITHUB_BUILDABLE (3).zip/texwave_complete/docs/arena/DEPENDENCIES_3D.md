# 3D / SceneView dependencies

Add to TEXWAVE `app/build.gradle.kts`:

```kotlin
implementation("io.github.sceneview:sceneview:2.2.1")
// SceneView pulls Filament. Align AGP/Kotlin with TEXWAVE pins.
```

Assets: see `app/src/main/assets/models/README_MODELS.md`

ProGuard (if minify): keep Filament / SceneView classes per library docs.
