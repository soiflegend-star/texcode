# Camera Push-Up Detection — Setup & Integration

## What is implemented

| Component | Status |
|-----------|--------|
| `PushUpDetectionEngine` state machine | **Implemented** — landmark elbow-angle DOWN→UP cycle |
| Automated engine tests | **PASS** (6/6 Python parity; JUnit source included) |
| MediaPipe Pose helper | **Implemented in source** — requires model asset + dependency |
| CameraX live preview + analysis | **Implemented in source** |
| Workout UI (count, timer, tracking HUD) | **Implemented** |
| XP submit | Uses existing `logActivity` / server RPC — **not** client self-award |
| `is_verified` | Remains **false** until a server evidence policy exists |
| Real-device test | **NOT performed** in this environment |
| APK build with MediaPipe | **NOT performed** (no Android SDK here) |

## Dependencies (add to TEXWAVE `app/build.gradle.kts`)

```kotlin
val camera = "1.3.1"
implementation("androidx.camera:camera-core:$camera")
implementation("androidx.camera:camera-camera2:$camera")
implementation("androidx.camera:camera-lifecycle:$camera")
implementation("androidx.camera:camera-view:$camera")
implementation("com.google.mediapipe:tasks-vision:0.10.14")
```

## Model asset (required)

Download MediaPipe **pose_landmarker_lite.task** from Google’s model site and place at:

```
app/src/main/assets/pose_landmarker_lite.task
```

Without this file, `PoseLandmarkerHelper.available == false` and the UI shows a clear error (manual log still works).

## Manifest (merge into TEXWAVE AndroidManifest)

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
```

Permission is requested only when opening the camera workout screen.

## Navigation

- Route: `arena_camera`
- Entry: Profile → **Camera**

## Privacy

- Pose runs **on-device**
- Frames are **not** uploaded by this code path
- Session submit sends **rep count + note** only through existing Arena repository RPC

## Security stance

Camera output is **client-side measurement**, not cryptographic proof.

- Submit uses `ActivitySource.MANUAL` today (server never trusts client `CAMERA_ASSISTED` until an evidence RPC exists)
- XP still only from `arena_award_activity_xp`
- Do not label UI as “Verified by server” solely because the camera counted

## Device testing checklist (you must run)

1. Install model asset + deps; assembleDebug  
2. Grant camera; open Profile → Camera  
3. Place phone so shoulders/elbows/hips visible  
4. Perform 5 push-ups; confirm count ≈ 5  
5. Cover lens mid-set → tracking loss message; recover  
6. Submit session → XP via server; history row appears  
7. Confirm `is_verified` stays false in DB  
