# TEXWAVE Integration Guide (post-audit)

## Required changes in TEXWAVE (host app)

1. **Copy** `com.texgen.music.texwave.arena` sources into `app/src/main/java/.../arena/`.
2. **SQL** — run in order on the existing Supabase project:
   - `supabase/001_arena_schema.sql`
   - `supabase/002_arena_rls_and_rpc.sql`
3. **Implement** `SupabaseArenaClient` using the shared Supabase client (same session as chat/auth).
4. **Startup** (after successful session):

```kotlin
ArenaModule.initSupabase(TexwaveArenaSupabaseClient(supabase))
```

5. **Navigation** — add one route:

```kotlin
composable("arena") { ArenaEntry(onClose = { navController.popBackStack() }) }
```

6. **Release guard** — assert `!ArenaModule.isDemo` in non-debug builds.
7. **Do not** add service-role key to the app.
8. **Do not** modify music/chat/feed modules for Arena.

## Client methods to implement

| Method | Maps to |
|--------|---------|
| `currentUserId()` | `auth.currentUserOrNull()?.id` |
| `currentUsername()` | metadata / profiles table already used by TEXWAVE |
| `rpcRaw(name, params)` | PostgREST `/rest/v1/rpc/{name}` |
| `select(table, ...)` | PostgREST GET with filters |

RPC names must match SQL exactly (`arena_award_activity_xp`, etc.).

## Verification before enabling for users

- [ ] `./gradlew :app:assembleDebug` succeeds with Arena sources  
- [ ] `./gradlew :app:testDebugUnitTest` runs `XpEngineTest`  
- [ ] Live SQL checklist in SECURITY_AUDIT.md all fail closed  
- [ ] Log activity → XP in `arena_xp_transactions` → rank moves  
- [ ] Second claim challenge returns error  
