# TEXWAVE ARENA — Part 2

**Scope delivered**

- Real XP & level progression engine (`XpEngine`)
- Manual activity logging with validation and soft safety limits
- Persistent-in-memory activity history + XP transaction log
- Full Player Profile screen
- Activity History screen
- Navigation wired for Profile, History, and Log Session

**XP rules (current)**

| Rule | Value |
|------|--------|
| Base XP | ~1 XP per rep (diminishing above 50) |
| Max reps / session | 200 |
| Max sessions / day | 12 |
| Max daily XP from activity | 350 |
| Min gap between sessions | 45 seconds |
| Level curve | mild polynomial (`100 * level^1.35`) |

Manual submissions are clearly labelled **self-reported**.  
Camera-assisted source multiplier is prepared but not active.

**New / updated files**

```
domain/XpEngine.kt
data/repository/ArenaRepository.kt   (extended)
ui/logging/LogActivityScreen.kt
ui/profile/ArenaProfileScreen.kt
ui/history/ActivityHistoryScreen.kt
ui/navigation/ArenaNav.kt            (Profile + History + Log wired)
```

**Still local**

All data lives in `LocalArenaRepository` (in-memory + seeded history).  
Part 5 will swap the repository implementation for Supabase while keeping the same interfaces.

**How to test**

1. Open Arena → Profile → “Log Session”
2. Enter a rep count (1–200) → Submit
3. Observe XP increase, level progress, and new row in History
4. Try rapid re-submit or >200 reps → validation errors appear

**Next: Part 3**

Challenges engine, daily missions with claim logic, reward processing.
