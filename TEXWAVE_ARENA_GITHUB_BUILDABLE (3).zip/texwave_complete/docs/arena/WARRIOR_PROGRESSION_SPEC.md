# Warrior Progression Spec

## Ranks

| Levels | Rank |
|--------|------|
| 1–29 | D Rank |
| 30–49 | C Rank |
| 50–69 | B Rank |
| 70–80 | A Rank |
| 81–89 | A+ Elite |
| 90–94 | S Rank Hunter |
| 95–99 | Legendary S |
| 100 | Ultimate S Rank |

## XP curve (level → next)

Nonlinear. Examples (approx):

- L1→2: ~92 XP  
- L30→31: ~900+ XP  
- L70→71: ~7500+ XP  
- L90→91: ~60k+ XP  
- L99→100: ~200k+ XP  

Total XP to reach L90 is many multiples of L50. Daily activity XP caps (existing server rules) block short-term grind to S Rank.

## Cosmetics

Unlock by min level / rank. S-tier items flagged legendary. Avatar is **cosmetic only**.

## Online fights

- UI: matchmaking + 3-round stadium presentation **implemented**  
- Server tables: `arena_matches`, `arena_warriors` **implemented**  
- Live ranked authority / netcode: **not live-verified** — client demo uses rating-weighted local outcome; production must complete match via edge function only  

## Asset inventory (procedural)

No binary 3D models shipped. Avatars use Compose procedural art + aura pulse. Replace with Lottie/3D later without changing domain APIs.
