# TEXWAVE ARENA — Security Audit

## Distinction

| Layer | Method | Result |
|---|---|---|
| Static SQL/RLS/RPC review | Manual inspection of migrations | Issues found & fixed (see below) |
| Runtime RLS with real roles | **Not executed** (no Supabase/Postgres) | Unknown until you run against a project |
| Penetration of live RPCs | **Not executed** | |

## Critical issue found (static) — FIXED

**`arena_profiles_update_safe`** previously allowed:

```sql
FOR UPDATE USING (auth.uid() = user_id)
```

without column restriction. An authenticated client could:

```http
PATCH /arena_profiles?user_id=eq.<self>
{ "total_xp": 999999, "level": 99 }
```

**Remediation in `002_arena_rls_and_rpc.sql`:**

- Removed general UPDATE policy on `arena_profiles`
- Added `arena_update_profile_display` (display_name / avatar only)
- Added `trg_arena_profiles_block_progression` trigger as defense in depth

**Runtime verification still required** after applying migrations.

## Static findings — remaining / residual risk

1. **SECURITY DEFINER ownership** — functions should be owned by a non-superuser role with tight table grants; default project owner may still be overly privileged. Verify with `\df+ arena_*` after apply.
2. **`search_path = public`** is set on DEFINER functions (good). Confirm no attacker-writable schema earlier in `search_path` for the owner role.
3. **`arena_activities_select_own`** only — good. Other users cannot read activity history.
4. **Leaderboard / profiles SELECT true** — usernames, levels, XP are public by design (competitive product). Accept or restrict.
5. **Challenge participants SELECT true** — exposes who joined; usually OK.
6. **Friends leaderboard** — not implemented in SQL RPC (only scopes in `arena_leaderboard`). Client must not invent friends ranks from local demo data in production mode.
7. **Camera verification** — SQL forces `MANUAL` + `is_verified=false`. Client `XpEngine` still has 1.25× for CAMERA; production repository must never send that path as trusted (Supabase repo maps camera → MANUAL).
8. **`client_request_id` unique** — good for idempotency; null ids can still double-submit if client omits key (RPC always generates one from app side).
9. **Squad invite unique index** — partial unique on PENDING; good.
10. **No rate limiting** beyond session gap / daily caps — rely on Supabase API limits / WAF for abuse.

## Checklist to run on your Supabase project (you must execute)

```sql
-- as authenticated user A
update arena_profiles set total_xp = 999999 where user_id = auth.uid(); -- must FAIL

-- as user A on user B
update arena_profiles set display_name = 'x' where user_id = '<B>'; -- must FAIL

insert into arena_xp_transactions(user_id, amount, reason)
  values (auth.uid(), 100, 'hack'); -- must FAIL (no insert policy)

select arena_award_activity_xp(20, 'CAMERA_ASSISTED', null, gen_random_uuid()::text);
-- must store source MANUAL, is_verified false

select arena_claim_challenge('<id>'); -- twice → second fails
```

Until these pass on a live project, **database security is not runtime-verified**.

## Camera detection addendum

- Client camera counts are **not** treated as verified proof.
- Submit path uses existing award RPC with non-verified activity.
- No video upload in default implementation.
- CAMERA permission is runtime-only on workout screen.
