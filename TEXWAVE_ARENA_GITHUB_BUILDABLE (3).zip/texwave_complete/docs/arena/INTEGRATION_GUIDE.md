# TEXWAVE ARENA — Production integration

## 1. Copy sources

```
app/src/main/java/com/texgen/music/texwave/arena/
```

into the TEXWAVE app module (same package namespace).

## 2. Supabase SQL (order matters)

1. `supabase/001_arena_schema.sql`
2. `supabase/002_arena_rls_and_rpc.sql`

## 3. Wire the shared Supabase client

Implement `SupabaseArenaClient` using the **existing** TEXWAVE Supabase instance (no second auth).

```kotlin
// Example — adapt to TEXWAVE's actual client types
class TexwaveArenaSupabaseClient(
    private val supabase: SupabaseClient
) : SupabaseArenaClient {
    override fun currentUserId(): String? =
        supabase.auth.currentUserOrNull()?.id

    override fun currentUsername(): String? =
        supabase.auth.currentUserOrNull()?.userMetadata?.get("username") as? String

    override suspend fun rpcRaw(function: String, params: Map<String, Any?>): String {
        // postgrest rpc → body string
        ...
    }

    override suspend fun select(...): String {
        // postgrest from(table).select()...
        ...
    }
}
```

## 4. Initialize once after login

```kotlin
ArenaModule.initSupabase(TexwaveArenaSupabaseClient(supabase))
```

For Compose previews / screenshot tests only:

```kotlin
ArenaModule.initLocalDemo()
```

## 5. Navigation

```kotlin
composable("arena") {
    ArenaEntry(onClose = { navController.popBackStack() })
}
```

## 6. Do not

- Put service-role keys in the APK
- Call `LocalArenaRepository()` from production UI
- Trust `CAMERA_ASSISTED` until a real model exists
- Grant clients UPDATE on `total_xp` / `level`

## 7. Dependencies (already in TEXWAVE)

- Compose BOM, Material3
- Supabase gotrue / postgrest / realtime (existing pins)
- kotlinx-serialization-json
- coroutines

No new mandatory libraries for Arena core.
