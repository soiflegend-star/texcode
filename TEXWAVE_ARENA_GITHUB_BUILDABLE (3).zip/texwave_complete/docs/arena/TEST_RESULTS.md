# TEXWAVE ARENA — Test Results

Environment: Linux sandbox, OpenJDK 21, **no Android SDK**, **no local Postgres/Supabase**.

## Summary table

| Test category | Status | Evidence |
|---|---|---|
| Kotlin compilation | **BLOCKED** | No Android SDK / `compileSdk`; `ANDROID_HOME` empty; no `android.jar` |
| Android APK build | **BLOCKED** | Same; cannot run `./gradlew :app:assembleDebug` |
| Dependency resolution | **BLOCKED** | Requires full TEXWAVE tree + network Gradle resolution against AGP |
| Unit tests (JUnit on device/JVM with Android deps) | **BLOCKED** | `XpEngineTest.kt` present but needs Android/JUnit classpath from host project |
| XP engine logic (Python parity suite) | **PASS** | 15/15 cases executed in this environment (see below) |
| Repository integration (live HTTP) | **NOT TESTED** | No Supabase credentials / network project |
| SQL security (executed against live DB) | **NOT TESTED** | No Postgres/Supabase local stack |
| RLS policies (static review) | **NOT TESTED** for runtime; static audit in SECURITY_AUDIT.md |
| RPC functions (executed) | **NOT TESTED** | No database |
| Challenge engine (live) | **NOT TESTED** | |
| Mission engine (live) | **NOT TESTED** | |
| Leaderboards (live) | **NOT TESTED** | |
| Squad permissions (live) | **NOT TESTED** | |
| TEXWAVE compatibility (compile-in) | **NOT TESTED** | Module not yet merged into full TEXWAVE APK build |

## XP engine — executed tests (PASS)

Mirrors `XpEngine` + SQL `arena_award_activity_xp` rules:

1. First valid activity (20) → 20 XP  
2. Multiple valid activities  
3. Zero reps → reject  
4. Negative reps → reject  
5. Extreme count (9999) → reject  
6. Diminishing returns (60 → 57)  
7. Daily session cap (12)  
8. Daily XP cap (350)  
9. Min gap 45s  
10. Level at 0 XP = 1  
11. Exact level-up boundary  
12. Monotonic level curve  
13. Import 0.8×  
14. Camera mult only in client engine (SQL forces MANUAL)  
15. Clamp to remaining daily XP  

Command: Python suite embedded in audit run (2026-11-02).

## Commands attempted for Android build

```text
echo $ANDROID_HOME          → empty
which sdkmanager            → not found
find / -name android.jar    → none
```

**Conclusion:** APK assembly cannot be claimed.

## What was fixed after audit (before this report)

- Profile `UPDATE` RLS allowed clients to set `total_xp` / `level` → **removed**; display-only RPC + trigger guard added  
- `ActionButton` / section chips not clickable → **fixed**  
- Local repo could set `isVerified` from camera source → **forced false**  
- Activity RPC did not update daily mission progress → **SQL updated**  
