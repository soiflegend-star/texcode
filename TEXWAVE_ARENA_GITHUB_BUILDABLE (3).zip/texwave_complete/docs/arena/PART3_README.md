# TEXWAVE ARENA — Part 3

**Scope delivered**

- Full challenge catalog (daily / weekly / monthly)
- Join challenges, automatic progress from logged activities
- Claim challenge XP (one-time, anti-double-claim)
- Daily missions with date-keyed progress and claim
- Mission kinds: activity volume, session count, “check leaderboard”
- Live updates on Home when progress or claims change

**Challenge rules**

| Challenge | Target | Period | XP |
|-----------|--------|--------|-----|
| Daily 20 | 20 push-ups | Daily | 25 |
| Daily 50 | 50 push-ups | Daily | 60 |
| Weekly Warrior | 300 push-ups | Weekly | 220 |
| Five Active Days | 5 active days | Weekly | 180 |
| November Global | 1000 push-ups | Monthly | 800 |

Progress is calculated only from activities recorded **after join** and **inside the challenge window**.

**Mission rules**

- Reset key = local calendar date (`yyyy-MM-dd`)
- Claim is allowed only when `progress >= target` and not already claimed
- “Check the ranks” mission completes when `markLeaderboardVisited()` is called (Part 4 will trigger this)

**Anti-abuse**

- Cannot join the same challenge twice
- Cannot claim incomplete or already-claimed rewards
- Challenge XP goes through the same XP transaction log as activity XP

**New files**

```
domain/ChallengeEngine.kt
data/model/ArenaModels.kt          (extended)
data/repository/ArenaRepository.kt (join / claim / observe)
ui/challenges/ChallengesScreen.kt
ui/missions/MissionsScreen.kt
ui/navigation/ArenaNav.kt          (Challenges + Missions live)
```

**How to test**

1. Open Challenges → see joined dailies with live progress from History
2. Log more push-ups (Profile → Log Session) → progress bars advance
3. When a bar hits 100%, Claim button appears → awards XP once
4. Open Missions → complete / claim daily missions the same way

**Next: Part 4**

Global + friends + squad leaderboards, podium, pagination, squad system.
