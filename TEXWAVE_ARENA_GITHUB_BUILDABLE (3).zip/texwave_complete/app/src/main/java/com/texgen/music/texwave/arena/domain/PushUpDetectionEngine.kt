package com.texgen.music.texwave.arena.domain

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * On-device push-up repetition detector driven by pose landmarks.
 *
 * Does NOT use time-based or camera-shake heuristics.
 * Counts only when a full DOWN → UP cycle is observed with sufficient confidence
 * and visibility of the critical joints.
 *
 * Landmark indices follow MediaPipe Pose (33 landmarks):
 * 11 L-shoulder, 12 R-shoulder, 13 L-elbow, 14 R-elbow,
 * 15 L-wrist, 16 R-wrist, 23 L-hip, 24 R-hip.
 */
class PushUpDetectionEngine(
    private val minLandmarkConfidence: Float = 0.55f,
    private val downElbowAngleDeg: Float = 95f,
    private val upElbowAngleDeg: Float = 150f,
    private val minBodyVisibilityJoints: Int = 6,
    private val cooldownFramesAfterRep: Int = 4
) {

    data class Landmark(
        val x: Float,
        val y: Float,
        val z: Float = 0f,
        val visibility: Float = 1f,
        val presence: Float = 1f
    )

    /**
     * Normalized image coordinates (0–1) for one frame.
     * Null entries mean the joint was not returned by the model.
     */
    data class PoseFrame(
        val leftShoulder: Landmark?,
        val rightShoulder: Landmark?,
        val leftElbow: Landmark?,
        val rightElbow: Landmark?,
        val leftWrist: Landmark?,
        val rightWrist: Landmark?,
        val leftHip: Landmark?,
        val rightHip: Landmark?,
        val timestampMs: Long = 0L
    )

    enum class Phase {
        IDLE,           // not tracking / insufficient visibility
        READY,          // plank-like high position acquired
        DESCENDING,     // moving toward bottom
        BOTTOM,         // elbow angle below down threshold
        ASCENDING,      // moving toward top
        LOCKOUT         // completed top; waiting to stabilize before next cycle
    }

    data class DetectionState(
        val phase: Phase = Phase.IDLE,
        val repCount: Int = 0,
        val trackingOk: Boolean = false,
        val averageElbowAngleDeg: Float? = null,
        val feedback: String = "Position yourself in frame",
        val lastRepTimestampMs: Long = 0L
    )

    private var phase: Phase = Phase.IDLE
    private var repCount: Int = 0
    private var cooldown: Int = 0
    private var lastAngle: Float? = null
    private var bottomReached: Boolean = false
    private var lastRepTs: Long = 0L

    fun reset() {
        phase = Phase.IDLE
        repCount = 0
        cooldown = 0
        lastAngle = null
        bottomReached = false
        lastRepTs = 0L
    }

    fun currentState(): DetectionState = DetectionState(
        phase = phase,
        repCount = repCount,
        trackingOk = phase != Phase.IDLE,
        averageElbowAngleDeg = lastAngle,
        feedback = feedbackFor(phase),
        lastRepTimestampMs = lastRepTs
    )

    /**
     * Ingest one pose frame. Returns updated detection state.
     */
    fun onPose(frame: PoseFrame): DetectionState {
        if (cooldown > 0) cooldown--

        val visibility = visibleCriticalCount(frame)
        if (visibility < minBodyVisibilityJoints) {
            phase = Phase.IDLE
            lastAngle = null
            bottomReached = false
            return currentState().copy(
                trackingOk = false,
                feedback = "Body not fully visible ($visibility/$minBodyVisibilityJoints joints)"
            )
        }

        val angle = averageElbowAngle(frame)
        if (angle == null) {
            phase = Phase.IDLE
            return currentState().copy(
                trackingOk = false,
                feedback = "Elbows not tracked confidently"
            )
        }
        lastAngle = angle

        // State machine
        when (phase) {
            Phase.IDLE, Phase.LOCKOUT -> {
                if (angle >= upElbowAngleDeg && cooldown == 0) {
                    phase = Phase.READY
                    bottomReached = false
                }
            }
            Phase.READY -> {
                if (angle < upElbowAngleDeg - 10f) {
                    phase = Phase.DESCENDING
                }
            }
            Phase.DESCENDING -> {
                if (angle <= downElbowAngleDeg) {
                    phase = Phase.BOTTOM
                    bottomReached = true
                } else if (angle >= upElbowAngleDeg) {
                    // went back up without reaching bottom
                    phase = Phase.READY
                    bottomReached = false
                }
            }
            Phase.BOTTOM -> {
                if (angle > downElbowAngleDeg + 8f) {
                    phase = Phase.ASCENDING
                }
            }
            Phase.ASCENDING -> {
                if (angle >= upElbowAngleDeg && bottomReached) {
                    // complete rep
                    repCount += 1
                    lastRepTs = frame.timestampMs
                    bottomReached = false
                    cooldown = cooldownFramesAfterRep
                    phase = Phase.LOCKOUT
                } else if (angle <= downElbowAngleDeg) {
                    phase = Phase.BOTTOM
                }
            }
        }

        return currentState()
    }

    private fun feedbackFor(p: Phase): String = when (p) {
        Phase.IDLE -> "Align body in camera view"
        Phase.READY -> "Ready — lower with control"
        Phase.DESCENDING -> "Descending…"
        Phase.BOTTOM -> "Push up"
        Phase.ASCENDING -> "Ascending…"
        Phase.LOCKOUT -> "Rep counted"
    }

    private fun visibleCriticalCount(frame: PoseFrame): Int {
        val joints = listOf(
            frame.leftShoulder, frame.rightShoulder,
            frame.leftElbow, frame.rightElbow,
            frame.leftWrist, frame.rightWrist,
            frame.leftHip, frame.rightHip
        )
        return joints.count { it != null && it.visibility >= minLandmarkConfidence && it.presence >= minLandmarkConfidence }
    }

    /**
     * Mean of left/right elbow angles (shoulder–elbow–wrist), degrees.
     * Returns null if neither side is confident.
     */
    fun averageElbowAngle(frame: PoseFrame): Float? {
        val left = elbowAngle(frame.leftShoulder, frame.leftElbow, frame.leftWrist)
        val right = elbowAngle(frame.rightShoulder, frame.rightElbow, frame.rightWrist)
        return when {
            left != null && right != null -> (left + right) / 2f
            left != null -> left
            right != null -> right
            else -> null
        }
    }

    private fun elbowAngle(shoulder: Landmark?, elbow: Landmark?, wrist: Landmark?): Float? {
        if (shoulder == null || elbow == null || wrist == null) return null
        if (shoulder.visibility < minLandmarkConfidence ||
            elbow.visibility < minLandmarkConfidence ||
            wrist.visibility < minLandmarkConfidence
        ) return null

        val ax = shoulder.x - elbow.x
        val ay = shoulder.y - elbow.y
        val bx = wrist.x - elbow.x
        val by = wrist.y - elbow.y
        val dot = ax * bx + ay * by
        val na = sqrt(ax * ax + ay * ay)
        val nb = sqrt(bx * bx + by * by)
        if (na < 1e-5f || nb < 1e-5f) return null
        val cos = (dot / (na * nb)).coerceIn(-1f, 1f)
        return Math.toDegrees(acos(cos.toDouble())).toFloat()
    }
}
