package com.texgen.music.texwave.arena.domain

import com.texgen.music.texwave.arena.data.model.ActivityType
import com.texgen.music.texwave.arena.data.model.ArenaActivity
import com.texgen.music.texwave.arena.data.model.ArenaChallenge
import com.texgen.music.texwave.arena.data.model.ArenaMission
import com.texgen.music.texwave.arena.data.model.ChallengeParticipation
import com.texgen.music.texwave.arena.data.model.ChallengePeriod
import com.texgen.music.texwave.arena.data.model.MissionProgress
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * Challenge & Daily Mission progress / reward rules.
 * Pure functions — easy to mirror server-side in Part 5.
 */
object ChallengeEngine {

    private val zone: ZoneId = ZoneId.systemDefault()

    fun todayKey(now: Instant = Instant.now()): String =
        LocalDate.ofInstant(now, zone).toString()

    // ------------------------------------------------------------------
    // Challenge progress from activities
    // ------------------------------------------------------------------

    fun computeChallengeProgress(
        challenge: ArenaChallenge,
        participation: ChallengeParticipation?,
        activities: List<ArenaActivity>
    ): Int {
        if (participation == null) return 0
        val relevant = activities.filter { act ->
            act.type == challenge.activityType &&
                !act.recordedAt.isBefore(challenge.startAt) &&
                act.recordedAt.isBefore(challenge.endAt) &&
                !act.recordedAt.isBefore(participation.joinedAt)
        }
        return relevant.sumOf { it.count }.coerceAtMost(challenge.targetCount)
    }

    fun isChallengeComplete(progress: Int, target: Int): Boolean =
        progress >= target

    // ------------------------------------------------------------------
    // Mission progress
    // ------------------------------------------------------------------

    fun computeMissionProgress(
        mission: ArenaMission,
        activitiesToday: List<ArenaActivity>,
        hasCheckedLeaderboard: Boolean = false
    ): Int {
        return when (mission.kind) {
            "activity" -> when {
                mission.title.contains("session", ignoreCase = true) ->
                    activitiesToday.size.coerceAtMost(mission.target)
                else ->
                    activitiesToday.sumOf { it.count }.coerceAtMost(mission.target)
            }
            "check" -> if (hasCheckedLeaderboard) mission.target else 0
            "social" -> 0 // placeholder until squad actions exist
            else -> 0
        }
    }

    // ------------------------------------------------------------------
    // Catalog of default challenges / missions (local seed)
    // ------------------------------------------------------------------

    fun defaultChallenges(now: Instant = Instant.now()): List<ArenaChallenge> {
        val startOfDay = LocalDate.ofInstant(now, zone).atStartOfDay(zone).toInstant()
        val endOfDay = startOfDay.plus(1, ChronoUnit.DAYS)
        val startOfWeek = startOfDay.minus(LocalDate.ofInstant(now, zone).dayOfWeek.value.toLong() - 1, ChronoUnit.DAYS)
        val endOfWeek = startOfWeek.plus(7, ChronoUnit.DAYS)
        val startOfMonth = LocalDate.ofInstant(now, zone).withDayOfMonth(1).atStartOfDay(zone).toInstant()
        val endOfMonth = startOfMonth.plus(32, ChronoUnit.DAYS) // approx; fine for local

        return listOf(
            ArenaChallenge(
                id = "ch-daily-20",
                title = "Daily 20",
                description = "Complete 20 push-ups today. Good for consistency.",
                difficulty = "Easy",
                period = ChallengePeriod.DAILY,
                targetCount = 20,
                startAt = startOfDay,
                endAt = endOfDay,
                xpReward = 25,
                participantCount = 18420
            ),
            ArenaChallenge(
                id = "ch-daily-50",
                title = "Daily 50",
                description = "Complete 50 push-ups today.",
                difficulty = "Medium",
                period = ChallengePeriod.DAILY,
                targetCount = 50,
                startAt = startOfDay,
                endAt = endOfDay,
                xpReward = 60,
                participantCount = 12840
            ),
            ArenaChallenge(
                id = "ch-week-300",
                title = "Weekly Warrior",
                description = "Reach 300 push-ups this week across any number of sessions.",
                difficulty = "Medium",
                period = ChallengePeriod.WEEKLY,
                targetCount = 300,
                startAt = startOfWeek,
                endAt = endOfWeek,
                xpReward = 220,
                participantCount = 5621
            ),
            ArenaChallenge(
                id = "ch-week-5days",
                title = "Five Active Days",
                description = "Log at least one session on 5 different days this week.",
                difficulty = "Hard",
                period = ChallengePeriod.WEEKLY,
                targetCount = 5, // interpreted as active days in progress logic later
                startAt = startOfWeek,
                endAt = endOfWeek,
                xpReward = 180,
                participantCount = 3102
            ),
            ArenaChallenge(
                id = "ch-month-1000",
                title = "November Global",
                description = "Accumulate 1 000 push-ups this month. Global competition.",
                difficulty = "Hard",
                period = ChallengePeriod.MONTHLY,
                targetCount = 1000,
                startAt = startOfMonth,
                endAt = endOfMonth,
                xpReward = 800,
                participantCount = 29103
            )
        )
    }

    fun defaultMissions(): List<ArenaMission> = listOf(
        ArenaMission(
            id = "m-log-session",
            title = "Log one session",
            description = "Record any push-up session today",
            target = 1,
            xpReward = 15,
            kind = "activity"
        ),
        ArenaMission(
            id = "m-20-reps",
            title = "Hit 20 push-ups",
            description = "Complete at least 20 reps today",
            target = 20,
            xpReward = 25,
            kind = "activity"
        ),
        ArenaMission(
            id = "m-check-ranks",
            title = "Check the ranks",
            description = "Visit the global leaderboard",
            target = 1,
            xpReward = 10,
            kind = "check"
        )
    )
}
