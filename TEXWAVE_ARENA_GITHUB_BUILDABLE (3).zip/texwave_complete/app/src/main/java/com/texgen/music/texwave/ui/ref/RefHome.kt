package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import java.util.Calendar

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 5 -> "Good night"
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

/** Reference screen 2 — Home. */
@Composable
fun RefHomeScreen(
    lib: LibraryState,
    player: PlayerState,
    userName: String = Ref.UserName,
    onPlay: (List<Song>, Int) -> Unit,
    onOpenNowPlaying: () -> Unit,
    onShuffle: () -> Unit,
    onSeeAll: () -> Unit,
) {
    val recent = remember(lib.songs, lib.recents) {
        val byId = lib.songs.associateBy { it.id }
        val r = lib.recents.mapNotNull { byId[it] }.distinctBy { it.id }
        (if (r.isEmpty()) lib.songs else r).take(10)
    }
    val heroSong = player.current ?: recent.firstOrNull()

    RefBackground {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 20.dp),
        ) {
            item {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.weight(1f)) { RefWordmark(26.sp) }
                    GlassIconButton(Icons.Rounded.Shuffle, onShuffle, size = 44.dp, square = true)
                }
            }
            item {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) {
                    val display = userName.trim().ifBlank { Ref.UserName }
                    Text("${greeting()}, $display", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (display.equals(Ref.UserName, true)) "Let the music guide your mind"
                        else "Welcome back — your wave is ready",
                        color = Color(0xFFE6EBFF), fontSize = 15.sp,
                    )
                }
            }
            item {
                val shape = RoundedCornerShape(24.dp)
                Box(
                    Modifier
                        .padding(horizontal = 20.dp)
                        .fillMaxWidth()
                        .aspectRatio(1.78f)
                        .clip(shape)
                        .border(1.5.dp, Brush.linearGradient(listOf(Ref.Violet, Ref.Blue, Ref.Magenta.copy(alpha = 0.8f))), shape)
                        .clickable {
                            if (player.current != null) onOpenNowPlaying()
                            else if (heroSong != null) onPlay(lib.songs, lib.songs.indexOfFirst { it.id == heroSong.id }.coerceAtLeast(0))
                        },
                ) {
                    RefImage(R.drawable.ref_hero, Modifier.fillMaxSize(), alignment = Alignment.TopCenter)
                    Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(96.dp)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6050A1B)))),
                    )
                    Column(Modifier.align(Alignment.BottomStart).padding(start = 18.dp, bottom = 16.dp, end = 80.dp)) {
                        Text(
                            heroSong?.title ?: "Lost in the Wave", color = Color.White, fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        )
                        Text(
                            heroSong?.artist ?: "TEXWAVE", color = Color(0xFFD5DBFF), fontSize = 14.sp,
                            maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        )
                    }
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 16.dp, bottom = 14.dp)
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Color(0xFF7B4DFF), Color(0xFF4B2CC4))))
                            .border(1.dp, Color(0x66FFFFFF), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
            item { SectionTitle("Recently Played", "See All", onSeeAll) }
            item { Spacer(Modifier.height(10.dp)) }
            itemsIndexed(recent, key = { _, s -> s.id }) { i, s ->
                RefRow(
                    title = s.title,
                    subtitle = s.artist,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 5.dp),
                    thumbBorder = i == 0,
                    onClick = { onPlay(recent, i) },
                ) {
                    SongThumb(s, Modifier.size(58.dp), RoundedCornerShape(14.dp))
                }
            }
        }
    }
}
