package com.texgen.music.texwave.arena.domain

/**
 * Fair arcade combat — independent of lifetime push-up totals.
 * STRIKE beats FEINT, FEINT beats GUARD, GUARD beats STRIKE.
 */
object MatchCombat {
    enum class Action { STRIKE, GUARD, FEINT }

    enum class RoundResult { A_WINS, B_WINS, DRAW }

    fun resolve(a: Action, b: Action): RoundResult = when {
        a == b -> RoundResult.DRAW
        a == Action.STRIKE && b == Action.FEINT -> RoundResult.A_WINS
        a == Action.FEINT && b == Action.GUARD -> RoundResult.A_WINS
        a == Action.GUARD && b == Action.STRIKE -> RoundResult.A_WINS
        else -> RoundResult.B_WINS
    }

    fun eloDelta(ratingA: Int, ratingB: Int, scoreA: Double, k: Int = 24): Int {
        val expected = 1.0 / (1.0 + Math.pow(10.0, (ratingB - ratingA) / 400.0))
        return (k * (scoreA - expected)).toInt().coerceIn(-50, 50)
    }
}
