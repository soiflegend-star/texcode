package com.texgen.music.texwave.arena.domain

import com.texgen.music.texwave.arena.data.model.ActivitySource
import com.texgen.music.texwave.arena.data.model.ActivityType
import com.texgen.music.texwave.arena.data.model.ArenaActivity
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import kotlin.math.min
import kotlin.math.pow

/**
 * Pure XP & level progression engine.
 *
 * Design goals:
 * - Meaningful progression (not infinite farming)
 * - Soft daily caps to discourage unsafe volume
 * - Clear distinction between manual and verified activity
 * - Deterministic so server-side validation can mirror it later
 */
object XpEngine {

    // ------------------------------------------------------------------
    // Level curve
    // ------------------------------------------------------------------

    /** XP required to go from (level) → (level+1). */
    fun xpRequiredForLevel(level: Int): Long {
        require(level >= 1)
        // Mild polynomial: early levels fast, later levels slower
        // L1→2 = 100, L10→11 ≈ 450, L25→26 ≈ 1 400, L50→51 ≈ 4 000
        return (100.0 * level.toDouble().pow(1.35)).toLong().coerceAtLeast(100L)
    }

    /** Total XP needed to reach a given level (from level 1). */
    fun totalXpToReachLevel(level: Int): Long {
        if (level <= 1) return 0L
        var total = 0L
        for (l in 1 until level) total += xpRequiredForLevel(l)
        return total
    }

    data class LevelInfo(
        val level: Int,
        val xpIntoCurrentLevel: Long,
        val xpRequiredForNextLevel: Long,
        val totalXp: Long
    )

    fun levelFromTotalXp(totalXp: Long): LevelInfo {
        var remaining = totalXp.coerceAtLeast(0L)
        var level = 1
        while (true) {
            val need = xpRequiredForLevel(level)
            if (remaining < need) {
                return LevelInfo(level, remaining, need, totalXp)
            }
            remaining -= need
            level++
            if (level > 200) { // hard safety ceiling
                return LevelInfo(200, 0L, xpRequiredForLevel(200), totalXp)
            }
        }
    }

    // ------------------------------------------------------------------
    // XP awards for activities
    // ------------------------------------------------------------------

    data class AwardResult(
        val xpAwarded: Long,
        val reason: String,
        val rejected: Boolean = false,
        val rejectReason: String? = null
    )

    /**
     * Soft limits (configurable later via remote config).
     * These exist to discourage extreme single-session numbers, not to claim medical advice.
     */
    const val MAX_REPS_PER_SESSION = 200
    const val MAX_SESSIONS_PER_DAY = 12
    const val MAX_DAILY_XP_FROM_ACTIVITY = 350L
    const val MIN_SECONDS_BETWEEN_SESSIONS = 45L

    fun calculateActivityXp(
        activity: ArenaActivity,
        recentActivitiesToday: List<ArenaActivity>,
        now: Instant = Instant.now()
    ): AwardResult {
        // --- basic validation ---
        if (activity.count <= 0) {
            return AwardResult(0, "invalid", rejected = true, rejectReason = "Count must be positive")
        }
        if (activity.count > MAX_REPS_PER_SESSION) {
            return AwardResult(0, "invalid", rejected = true,
                rejectReason = "Max $MAX_REPS_PER_SESSION reps per session (soft safety limit)")
        }
        if (recentActivitiesToday.size >= MAX_SESSIONS_PER_DAY) {
            return AwardResult(0, "daily_cap", rejected = true,
                rejectReason = "Daily session limit reached ($MAX_SESSIONS_PER_DAY)")
        }

        // rapid-fire protection
        val last = recentActivitiesToday.maxByOrNull { it.recordedAt }
        if (last != null) {
            val gap = java.time.Duration.between(last.recordedAt, now).seconds
            if (gap < MIN_SECONDS_BETWEEN_SESSIONS) {
                return AwardResult(0, "too_fast", rejected = true,
                    rejectReason = "Please wait ${MIN_SECONDS_BETWEEN_SESSIONS - gap}s before logging again")
            }
        }

        // base XP: 1 XP per rep, slight diminishing returns above 50
        val base = when {
            activity.count <= 50 -> activity.count.toLong()
            else -> 50L + ((activity.count - 50) * 0.7).toLong()
        }

        // source multiplier
        val sourceMult = when (activity.source) {
            ActivitySource.MANUAL -> 1.0
            ActivitySource.CAMERA_ASSISTED -> 1.25  // future verified
            ActivitySource.IMPORT -> 0.8
        }

        var xp = (base * sourceMult).toLong()

        // daily soft XP cap from pure activity
        val alreadyEarnedToday = recentActivitiesToday.sumOf { it.xpAwarded }
        val remainingCap = (MAX_DAILY_XP_FROM_ACTIVITY - alreadyEarnedToday).coerceAtLeast(0L)
        if (xp > remainingCap) {
            xp = remainingCap
        }

        if (xp <= 0L) {
            return AwardResult(0, "daily_xp_cap", rejected = true,
                rejectReason = "Daily activity XP cap reached")
        }

        val reason = when (activity.type) {
            ActivityType.PUSH_UPS -> "push_ups_${activity.count}"
        }

        return AwardResult(xp, reason)
    }

    // ------------------------------------------------------------------
    // Helpers for UI
    // ------------------------------------------------------------------

    fun previewXpForCount(count: Int, source: ActivitySource = ActivitySource.MANUAL): Long {
        val fake = ArenaActivity(
            userId = "preview",
            count = count.coerceIn(1, MAX_REPS_PER_SESSION),
            source = source
        )
        return calculateActivityXp(fake, emptyList()).xpAwarded
    }
}
