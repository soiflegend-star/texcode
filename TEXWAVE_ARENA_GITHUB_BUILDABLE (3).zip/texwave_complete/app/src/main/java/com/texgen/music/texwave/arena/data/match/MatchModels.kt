package com.texgen.music.texwave.arena.data.match

import androidx.compose.runtime.Immutable

@Immutable
data class OnlineMatch(
    val id: String,
    val playerA: String,
    val playerB: String,
    val status: String,
    val currentRound: Int,
    val scoreA: Int,
    val scoreB: Int,
    val ratingA: Int,
    val ratingB: Int,
    val aReady: Boolean,
    val bReady: Boolean,
    val winnerId: String? = null,
    val ratingDeltaA: Int? = null,
    val ratingDeltaB: Int? = null
)

@Immutable
data class QueueResult(
    val status: String, // QUEUED | MATCHED | ALREADY_IN_MATCH
    val matchId: String? = null,
    val opponentId: String? = null,
    val rating: Int? = null
)

@Immutable
data class ActionResult(
    val status: String,
    val round: Int? = null,
    val roundWinner: String? = null,
    val scoreA: Int? = null,
    val scoreB: Int? = null,
    val winnerId: String? = null,
    val nextRound: Int? = null
)
