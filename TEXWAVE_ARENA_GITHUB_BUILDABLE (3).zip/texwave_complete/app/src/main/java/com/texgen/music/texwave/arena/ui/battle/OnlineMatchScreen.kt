package com.texgen.music.texwave.arena.ui.battle

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.match.ActionResult
import com.texgen.music.texwave.arena.data.match.MatchRepository
import com.texgen.music.texwave.arena.data.match.OnlineMatch
import com.texgen.music.texwave.arena.data.match.QueueResult
import com.texgen.music.texwave.arena.data.match.SimulatedMatchRepository
import com.texgen.music.texwave.arena.domain.MatchCombat
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Online ranked flow UI.
 *
 * When [repository] is [SimulatedMatchRepository], the screen labels itself as simulation
 * and falls back to the local championship presentation path.
 * With [SupabaseMatchRepository], queue → match → ready → actions are server RPCs.
 *
 * Realtime: host app should subscribe to `arena_online_matches` filter id=eq.matchId
 * and refresh state; this screen also polls fetchMatch while ACTIVE.
 */
@Composable
fun OnlineMatchScreen(
    repository: MatchRepository = SimulatedMatchRepository(),
    onClose: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val isSim = repository is SimulatedMatchRepository

    var phase by remember { mutableStateOf("HUB") }
    var status by remember { mutableStateOf("") }
    var match by remember { mutableStateOf<OnlineMatch?>(null) }
    var lastAction by remember { mutableStateOf<ActionResult?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF05070F), Color(0xFF1A0A28), Color(0xFF05070F))
                )
            )
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            if (isSim) "CHAMPIONSHIP (SIMULATION)" else "CHAMPIONSHIP ONLINE",
            color = ArenaColors.Cyan,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            fontSize = 12.sp
        )
        if (isSim) {
            Text(
                "Not a live multiplayer match — wire SupabaseMatchRepository after SQL 004",
                color = ArenaColors.Magenta,
                fontSize = 11.sp
            )
        }
        Spacer(Modifier.height(12.dp))

        when (phase) {
            "HUB" -> {
                Text("Ranked matchmaking uses rating ±150 and level ±12 on the server.", color = ArenaColors.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        busy = true
                        scope.launch {
                            if (isSim) {
                                status = "Simulation: use local Find Opponent presentation"
                                phase = "SIM_HINT"
                                busy = false
                                return@launch
                            }
                            repository.enqueueRanked().fold(
                                onSuccess = { q: QueueResult ->
                                    status = q.status
                                    when (q.status) {
                                        "MATCHED", "ALREADY_IN_MATCH" -> {
                                            match = repository.fetchMatch(q.matchId!!).getOrNull()
                                            phase = "READY"
                                        }
                                        "QUEUED" -> {
                                            phase = "QUEUE"
                                            // poll for match
                                            repeat(30) {
                                                delay(2000)
                                                val again = repository.enqueueRanked().getOrNull()
                                                if (again?.status == "MATCHED") {
                                                    match = repository.fetchMatch(again.matchId!!).getOrNull()
                                                    phase = "READY"
                                                    return@launch
                                                }
                                            }
                                            status = "Timeout — try again"
                                            repository.cancelQueue()
                                            phase = "HUB"
                                        }
                                        else -> status = q.status
                                    }
                                },
                                onFailure = { status = it.message ?: "Queue failed"; phase = "HUB" }
                            )
                            busy = false
                        }
                    },
                    enabled = !busy,
                    colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Violet)
                ) { Text(if (busy) "Working…" else "Find Ranked Opponent") }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onClose) { Text("Back") }
            }
            "QUEUE" -> {
                Text("In queue…", color = ArenaColors.Text, fontSize = 20.sp)
                Text(status, color = ArenaColors.Muted)
                Button(onClick = {
                    scope.launch { repository.cancelQueue(); phase = "HUB" }
                }) { Text("Cancel") }
            }
            "READY" -> {
                val m = match
                Text("Match ready", color = ArenaColors.Text, fontSize = 20.sp)
                Text("ID ${m?.id?.take(8)}…", color = ArenaColors.Muted, fontSize = 11.sp)
                Text("Score ${m?.scoreA ?: 0} – ${m?.scoreB ?: 0} · Round ${m?.currentRound ?: 1}", color = ArenaColors.Cyan)
                Button(
                    onClick = {
                        scope.launch {
                            val id = match?.id ?: return@launch
                            repository.ready(id).onSuccess {
                                match = it
                                if (it.status == "ACTIVE") phase = "FIGHT"
                            }.onFailure { status = it.message ?: "Ready failed" }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Cyan, contentColor = Color.Black)
                ) { Text("I'm Ready") }
                Text(status, color = ArenaColors.Muted, fontSize = 12.sp)
            }
            "FIGHT" -> {
                Text("Round ${match?.currentRound ?: 1}", color = ArenaColors.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("${match?.scoreA ?: 0} – ${match?.scoreB ?: 0}", color = ArenaColors.Cyan, fontSize = 20.sp)
                Text("Pick an action (fair RPS — not based on push-ups)", color = ArenaColors.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    listOf("STRIKE", "GUARD", "FEINT").forEach { act ->
                        Button(
                            onClick = {
                                scope.launch {
                                    val id = match?.id ?: return@launch
                                    repository.submitAction(id, act).fold(
                                        onSuccess = { res ->
                                            lastAction = res
                                            status = res.status
                                            match = repository.fetchMatch(id).getOrNull() ?: match
                                            if (res.status == "COMPLETED" || match?.status == "COMPLETED") {
                                                phase = "RESULT"
                                            }
                                        },
                                        onFailure = { status = it.message ?: "Action failed" }
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Violet),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text(act) }
                    }
                }
                lastAction?.let {
                    Text("${it.status} · round winner ${it.roundWinner}", color = ArenaColors.Muted, fontSize = 12.sp)
                }
                Button(onClick = {
                    scope.launch {
                        match?.id?.let { repository.abandon(it) }
                        phase = "HUB"
                    }
                }) { Text("Abandon (forfeit)", color = ArenaColors.Magenta) }
            }
            "RESULT" -> {
                Column(Modifier.arenaGlassCard(18).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("MATCH COMPLETE", color = ArenaColors.RankGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Score ${match?.scoreA} – ${match?.scoreB}", color = ArenaColors.Text)
                    Text("Winner ${match?.winnerId?.take(8) ?: "Draw"}", color = ArenaColors.Cyan)
                    Text(
                        "Δ rating A ${match?.ratingDeltaA ?: "—"} · B ${match?.ratingDeltaB ?: "—"}",
                        color = ArenaColors.Muted,
                        fontSize = 12.sp
                    )
                    Text("Recorded by server RPC — client did not write rating", color = ArenaColors.Muted, fontSize = 10.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { phase = "HUB"; match = null }) { Text("Done") }
                }
            }
            "SIM_HINT" -> {
                Text(status, color = ArenaColors.Muted)
                Button(onClick = onClose) { Text("Open local presentation from Profile matchmaking route") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(status, color = ArenaColors.Muted, fontSize = 11.sp)
    }
}
