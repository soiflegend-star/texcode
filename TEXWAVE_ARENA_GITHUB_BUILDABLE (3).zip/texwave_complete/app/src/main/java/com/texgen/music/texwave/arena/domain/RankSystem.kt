package com.texgen.music.texwave.arena.domain

/**
 * Levels 1–100 with nonlinear XP and competitive ranks.
 * Curve is intentionally steep after 70 and extreme after 90.
 * Daily caps elsewhere prevent unsafe grinding incentives.
 */
object RankSystem {

    enum class RankTier(
        val displayName: String,
        val minLevel: Int,
        val maxLevel: Int,
        val accentHex: Long
    ) {
        D("D Rank", 1, 29, 0xFF8E9AB4),
        C("C Rank", 30, 49, 0xFF4FC3F7),
        B("B Rank", 50, 69, 0xFF7C4DFF),
        A("A Rank", 70, 80, 0xFFFF58D8),
        A_PLUS("A+ Elite", 81, 89, 0xFFFFAB00),
        S_HUNTER("S Rank Hunter", 90, 94, 0xFFFFD700),
        S_LEGENDARY("Legendary S", 95, 99, 0xFFFFE082),
        S_ULTIMATE("Ultimate S Rank", 100, 100, 0xFFFFF59D);

        companion object {
            fun forLevel(level: Int): RankTier {
                val L = level.coerceIn(1, 100)
                return entries.first { L in it.minLevel..it.maxLevel }
            }
        }
    }

    /**
     * XP required to go from [level] → level+1.
     * Mild early, steep mid, extreme late.
     */
    fun xpToAdvanceFrom(level: Int): Long {
        val L = level.coerceIn(1, 99)
        val base = when {
            L < 10 -> 80.0 + L * 12.0
            L < 30 -> 200.0 + (L - 10) * 35.0
            L < 50 -> 900.0 + (L - 30) * 90.0
            L < 70 -> 2800.0 + (L - 50) * 220.0
            L < 80 -> 7500.0 + (L - 70) * 900.0
            L < 90 -> 18000.0 + (L - 80) * 3500.0
            L < 95 -> 60000.0 + (L - 90) * 25000.0
            else -> 200000.0 + (L - 95) * 120000.0  // 95→100: exceptional
        }
        return base.toLong().coerceAtLeast(50L)
    }

    fun totalXpToReach(level: Int): Long {
        if (level <= 1) return 0L
        var sum = 0L
        for (l in 1 until level.coerceAtMost(100)) sum += xpToAdvanceFrom(l)
        return sum
    }

    data class Progress(
        val level: Int,
        val rank: RankTier,
        val xpIntoLevel: Long,
        val xpRequiredNext: Long,
        val totalXp: Long,
        val progressFraction: Float
    )

    fun progressFromTotalXp(totalXp: Long): Progress {
        var remaining = totalXp.coerceAtLeast(0L)
        var level = 1
        while (level < 100) {
            val need = xpToAdvanceFrom(level)
            if (remaining < need) {
                val frac = if (need <= 0) 1f else (remaining.toFloat() / need).coerceIn(0f, 1f)
                return Progress(level, RankTier.forLevel(level), remaining, need, totalXp, frac)
            }
            remaining -= need
            level++
        }
        return Progress(100, RankTier.S_ULTIMATE, 0L, 0L, totalXp, 1f)
    }

    /** Approximate lifetime accepted reps needed if ~1 XP/rep (illustrative; server rules differ). */
    fun illustrativeRepsForLevel(level: Int): Long = totalXpToReach(level)
}
