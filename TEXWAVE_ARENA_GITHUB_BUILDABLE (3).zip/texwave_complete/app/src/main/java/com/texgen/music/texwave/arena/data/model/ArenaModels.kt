package com.texgen.music.texwave.arena.data.model

import androidx.compose.runtime.Immutable
import java.time.Instant
import java.util.UUID

/**
 * Core domain models for TEXWAVE ARENA.
 * These are pure data classes — no Android / Supabase dependencies.
 * Designed so new activity types can be added without breaking existing code.
 */

enum class ActivityType {
    PUSH_UPS,
    // Future: SQUATS, PLANK, JUMPING_JACKS, CUSTOM
}

enum class ActivitySource {
    MANUAL,          // user typed the number
    CAMERA_ASSISTED, // future verified recognition
    IMPORT           // imported from external source
}

@Immutable
data class ArenaPlayer(
    val userId: String,
    val username: String,
    val displayName: String = username,
    val avatarUrl: String? = null,
    val level: Int = 1,
    val totalXp: Long = 0L,
    val xpIntoCurrentLevel: Long = 0L,
    val xpRequiredForNextLevel: Long = 100L,
    val globalRank: Int? = null,
    val weeklyRank: Int? = null,
    val monthlyRank: Int? = null,
    val totalPushUps: Long = 0L,
    val squadId: String? = null,
    val squadName: String? = null,
    val createdAt: Instant = Instant.now(),
    val updatedAt: Instant = Instant.now()
) {
    val progressFraction: Float
        get() = if (xpRequiredForNextLevel <= 0) 1f
                else (xpIntoCurrentLevel.toFloat() / xpRequiredForNextLevel).coerceIn(0f, 1f)
}

@Immutable
data class ArenaActivity(
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val type: ActivityType = ActivityType.PUSH_UPS,
    val count: Int,
    val source: ActivitySource = ActivitySource.MANUAL,
    val performedAt: Instant = Instant.now(),
    val recordedAt: Instant = Instant.now(),
    val note: String? = null,
    val xpAwarded: Long = 0L,
    val isVerified: Boolean = false // true only when camera / external verification exists
)

@Immutable
data class XpTransaction(
    val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val amount: Long,
    val reason: String,
    val activityId: String? = null,
    val challengeId: String? = null,
    val missionId: String? = null,
    val createdAt: Instant = Instant.now()
)

@Immutable
data class ArenaChallengeSummary(
    val id: String,
    val title: String,
    val description: String,
    val difficulty: String,          // "Easy" | "Medium" | "Hard" | "Elite"
    val progress: Int,
    val target: Int,
    val endsAt: Instant,
    val xpReward: Long,
    val participantCount: Int,
    val isJoined: Boolean = false,
    val isCompleted: Boolean = false
)

@Immutable
data class DailyMissionSummary(
    val id: String,
    val title: String,
    val description: String,
    val progress: Int,
    val target: Int,
    val xpReward: Long,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false
)

@Immutable
data class AchievementSummary(
    val id: String,
    val title: String,
    val description: String,
    val iconKey: String,
    val isUnlocked: Boolean,
    val unlockedAt: Instant? = null,
    val xpReward: Long = 0L
)

@Immutable
data class FriendActivity(
    val userId: String,
    val username: String,
    val avatarUrl: String?,
    val action: String,              // "completed 42 push-ups", "joined Weekly Warrior"
    val timestamp: Instant
)

@Immutable
data class SquadStatus(
    val squadId: String,
    val name: String,
    val memberCount: Int,
    val totalXp: Long,
    val rank: Int?,
    val userContributionXp: Long = 0L
)

/**
 * Snapshot used by Arena Home.
 * In later parts this will be assembled from real repositories.
 */
@Immutable
data class ArenaHomeState(
    val player: ArenaPlayer,
    val activeChallenges: List<ArenaChallengeSummary> = emptyList(),
    val dailyMissions: List<DailyMissionSummary> = emptyList(),
    val recentAchievements: List<AchievementSummary> = emptyList(),
    val friendsActivity: List<FriendActivity> = emptyList(),
    val squad: SquadStatus? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

// ---------------------------------------------------------------------------
// Full challenge & mission models (Part 3)
// ---------------------------------------------------------------------------

enum class ChallengePeriod {
    DAILY, WEEKLY, MONTHLY, SPECIAL
}

@Immutable
data class ArenaChallenge(
    val id: String,
    val title: String,
    val description: String,
    val difficulty: String,
    val period: ChallengePeriod,
    val activityType: ActivityType = ActivityType.PUSH_UPS,
    val targetCount: Int,
    val startAt: Instant,
    val endAt: Instant,
    val xpReward: Long,
    val participantCount: Int = 0,
    val isGlobal: Boolean = true
)

@Immutable
data class ChallengeParticipation(
    val challengeId: String,
    val userId: String,
    val joinedAt: Instant = Instant.now(),
    val progress: Int = 0,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false,
    val completedAt: Instant? = null,
    val claimedAt: Instant? = null
)

@Immutable
data class ArenaMission(
    val id: String,
    val title: String,
    val description: String,
    val target: Int,
    val xpReward: Long,
    /** "activity" | "social" | "check" — used for progress rules */
    val kind: String = "activity",
    val resetsDaily: Boolean = true
)

@Immutable
data class MissionProgress(
    val missionId: String,
    val userId: String,
    val dateKey: String,          // yyyy-MM-dd in app timezone
    val progress: Int = 0,
    val isCompleted: Boolean = false,
    val isClaimed: Boolean = false,
    val claimedAt: Instant? = null
)

// ---------------------------------------------------------------------------
// Leaderboard & Squad models (Part 4)
// ---------------------------------------------------------------------------

enum class LeaderboardScope {
    GLOBAL_ALL_TIME,
    GLOBAL_WEEKLY,
    GLOBAL_MONTHLY,
    GLOBAL_DAILY,
    FRIENDS,
    SQUAD
}

@Immutable
data class LeaderboardEntry(
    val rank: Int,
    val userId: String,
    val username: String,
    val displayName: String = username,
    val avatarUrl: String? = null,
    val level: Int,
    val xp: Long,
    val pushUps: Long = 0L,
    val isCurrentUser: Boolean = false
)

@Immutable
data class LeaderboardPage(
    val scope: LeaderboardScope,
    val entries: List<LeaderboardEntry>,
    val currentUserEntry: LeaderboardEntry?,
    val totalPlayers: Int,
    val periodLabel: String,
    val resetsAt: Instant? = null
)

enum class SquadRole {
    OWNER, ADMIN, MEMBER
}

@Immutable
data class ArenaSquad(
    val id: String,
    val name: String,
    val description: String = "",
    val avatarUrl: String? = null,
    val ownerId: String,
    val totalXp: Long = 0L,
    val level: Int = 1,
    val memberCount: Int = 0,
    val rank: Int? = null,
    val createdAt: Instant = Instant.now()
)

@Immutable
data class SquadMember(
    val userId: String,
    val username: String,
    val displayName: String = username,
    val role: SquadRole = SquadRole.MEMBER,
    val contributionXp: Long = 0L,
    val level: Int = 1,
    val joinedAt: Instant = Instant.now()
)

@Immutable
data class SquadDetail(
    val squad: ArenaSquad,
    val members: List<SquadMember>,
    val currentUserRole: SquadRole?
)
