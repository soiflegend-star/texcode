package com.texgen.music.texwave.arena.data.camera

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.texgen.music.texwave.arena.domain.PushUpDetectionEngine
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult

/**
 * Thin wrapper around MediaPipe Pose Landmarker (Tasks Vision).
 *
 * Model asset: `pose_landmarker_lite.task` must be placed in app assets
 * (download from Google MediaPipe model hub). Detection works on-device only;
 * frames are not uploaded.
 *
 * If the model or native library is missing, [available] is false and
 * callers must fall back to manual logging.
 */
class PoseLandmarkerHelper(
    context: Context,
    private val onError: (String) -> Unit = {}
) {
    var available: Boolean = false
        private set

    private var landmarker: PoseLandmarker? = null

    init {
        try {
            val base = BaseOptions.builder()
                .setModelAssetPath(MODEL_ASSET)
                .setDelegate(Delegate.CPU)
                .build()
            val options = PoseLandmarker.PoseLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumPoses(1)
                .setMinPoseDetectionConfidence(0.5f)
                .setMinPosePresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { result, _ -> /* delivered via detectAsync callback path */ }
                .setErrorListener { e -> onError(e.message ?: "Pose error") }
                .build()
            // LIVE_STREAM requires result listener; for simpler control we use IMAGE mode per-frame
            val imageOptions = PoseLandmarker.PoseLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.IMAGE)
                .setNumPoses(1)
                .setMinPoseDetectionConfidence(0.5f)
                .setMinPosePresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .build()
            landmarker = PoseLandmarker.createFromOptions(context, imageOptions)
            available = true
        } catch (t: Throwable) {
            available = false
            landmarker = null
            onError(
                "Pose model unavailable: ${t.message}. " +
                    "Add $MODEL_ASSET to assets and MediaPipe dependency."
            )
        }
    }

    fun detect(bitmap: Bitmap): PushUpDetectionEngine.PoseFrame? {
        val lm = landmarker ?: return null
        return try {
            val mpImage: MPImage = BitmapImageBuilder(bitmap).build()
            val result: PoseLandmarkerResult = lm.detect(mpImage)
            result.toPoseFrame()
        } catch (t: Throwable) {
            onError(t.message ?: "detect failed")
            null
        }
    }

    fun close() {
        try {
            landmarker?.close()
        } catch (_: Throwable) {
        }
        landmarker = null
        available = false
    }

    companion object {
        const val MODEL_ASSET = "pose_landmarker_lite.task"

        /** MediaPipe Pose landmark indices */
        const val L_SHOULDER = 11
        const val R_SHOULDER = 12
        const val L_ELBOW = 13
        const val R_ELBOW = 14
        const val L_WRIST = 15
        const val R_WRIST = 16
        const val L_HIP = 23
        const val R_HIP = 24
    }
}

fun PoseLandmarkerResult.toPoseFrame(): PushUpDetectionEngine.PoseFrame {
    val pose = landmarks().firstOrNull()
    fun at(i: Int): PushUpDetectionEngine.Landmark? {
        if (pose == null || i >= pose.size) return null
        val p = pose[i]
        // NormalizedLandmark: x,y,z; visibility may be on the landmark
        val vis = try {
            // tasks API exposes visibility() on NormalizedLandmark in recent versions
            p.visibility().orElse(1f)
        } catch (_: Throwable) {
            1f
        }
        return PushUpDetectionEngine.Landmark(
            x = p.x(),
            y = p.y(),
            z = p.z(),
            visibility = vis,
            presence = vis
        )
    }
    return PushUpDetectionEngine.PoseFrame(
        leftShoulder = at(PoseLandmarkerHelper.L_SHOULDER),
        rightShoulder = at(PoseLandmarkerHelper.R_SHOULDER),
        leftElbow = at(PoseLandmarkerHelper.L_ELBOW),
        rightElbow = at(PoseLandmarkerHelper.R_ELBOW),
        leftWrist = at(PoseLandmarkerHelper.L_WRIST),
        rightWrist = at(PoseLandmarkerHelper.R_WRIST),
        leftHip = at(PoseLandmarkerHelper.L_HIP),
        rightHip = at(PoseLandmarkerHelper.R_HIP),
        timestampMs = SystemClock.elapsedRealtime()
    )
}
