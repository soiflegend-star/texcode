package com.texgen.music.texwave.data.chat

import android.content.Context
import java.util.Calendar

/**
 * Light engagement helpers for chat: day streaks + last active day.
 * Transparent counters only — no guilt, no fake urgency.
 */
object ChatVibeStore {
    private const val PREFS = "texwave_chat_vibes_v1"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun dayKey(): String {
        val c = Calendar.getInstance()
        return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    private fun yesterdayKey(): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, -1)
        return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** Record that the user sent a message in this conversation today. Returns current streak. */
    fun markSent(ctx: Context, conversationId: String): Int {
        val p = prefs(ctx)
        val keyDay = "day_$conversationId"
        val keyStreak = "streak_$conversationId"
        val today = dayKey()
        val last = p.getString(keyDay, null)
        val streak = when {
            last == today -> p.getInt(keyStreak, 1).coerceAtLeast(1)
            last == yesterdayKey() -> p.getInt(keyStreak, 0) + 1
            else -> 1
        }
        p.edit().putString(keyDay, today).putInt(keyStreak, streak).apply()
        // global chat activity day
        val gLast = p.getString("g_day", null)
        val gStreak = when {
            gLast == today -> p.getInt("g_streak", 1).coerceAtLeast(1)
            gLast == yesterdayKey() -> p.getInt("g_streak", 0) + 1
            else -> 1
        }
        p.edit().putString("g_day", today).putInt("g_streak", gStreak).apply()
        return streak
    }

    fun streak(ctx: Context, conversationId: String): Int =
        prefs(ctx).getInt("streak_$conversationId", 0)

    fun globalStreak(ctx: Context): Int = prefs(ctx).getInt("g_streak", 0)
}
