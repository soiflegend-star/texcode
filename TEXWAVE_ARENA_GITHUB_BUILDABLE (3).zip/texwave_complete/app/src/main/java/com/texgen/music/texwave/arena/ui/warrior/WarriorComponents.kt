package com.texgen.music.texwave.arena.ui.warrior

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.WarriorGender
import com.texgen.music.texwave.arena.data.model.WarriorLoadout
import com.texgen.music.texwave.arena.data.model.WarriorProfile
import com.texgen.music.texwave.arena.domain.RankSystem
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard

@Composable
fun WarriorAvatar(
    loadout: WarriorLoadout,
    rank: RankSystem.RankTier,
    level: Int,
    modifier: Modifier = Modifier,
    size: Int = 140
) {
    val infinite = rememberInfiniteTransition(label = "aura")
    val pulse by infinite.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Reverse),
        label = "p"
    )
    val auraColor = when {
        rank.ordinal >= RankSystem.RankTier.S_HUNTER.ordinal -> ArenaColors.RankGold
        rank.ordinal >= RankSystem.RankTier.A.ordinal -> ArenaColors.Magenta
        rank.ordinal >= RankSystem.RankTier.B.ordinal -> ArenaColors.Violet
        else -> ArenaColors.Cyan
    }
    val bodyColor = if (loadout.gender == WarriorGender.GIRL)
        Color(0xFFE1BEE7) else Color(0xFF90CAF9)

    Box(modifier = modifier.size(size.dp), contentAlignment = Alignment.Center) {
        // Aura ring
        Box(
            Modifier
                .size((size * 0.95f).dp)
                .scale(pulse)
                .border(3.dp, auraColor.copy(alpha = 0.55f), CircleShape)
        )
        Box(
            Modifier
                .size((size * 0.78f).dp)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        listOf(bodyColor, auraColor.copy(alpha = 0.35f), ArenaColors.Surface)
                    )
                )
                .border(2.dp, Color.White.copy(alpha = 0.2f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (loadout.gender == WarriorGender.GIRL) "♀" else "♂",
                fontSize = (size / 3).sp,
                color = Color.White
            )
        }
        // Rank badge
        Text(
            rank.displayName,
            color = auraColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .background(ArenaColors.Bg.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun WarriorCard(profile: WarriorProfile, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxWidth()
            .arenaGlassCard(22)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        WarriorAvatar(profile.loadout, profile.rank, profile.level, size = 120)
        Spacer(Modifier.height(10.dp))
        Text(profile.username, color = ArenaColors.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Lv ${profile.level} · ${profile.rank.displayName}",
            color = ArenaColors.Cyan,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(Modifier.height(8.dp))
        // XP bar
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(ArenaColors.Outline.copy(alpha = 0.5f))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(profile.progressFraction.coerceIn(0.02f, 1f))
                    .height(8.dp)
                    .background(
                        Brush.horizontalGradient(listOf(ArenaColors.Violet, ArenaColors.Cyan))
                    )
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "${profile.xpIntoLevel} / ${profile.xpRequiredNext} XP",
            color = ArenaColors.Muted,
            fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Rating ${profile.competitiveRating} · ${profile.wins}W ${profile.losses}L · ${profile.totalAcceptedReps} reps",
            color = ArenaColors.Muted,
            fontSize = 11.sp
        )
        Text(
            "Avatar is cosmetic game progression — not a claim about your body.",
            color = ArenaColors.Muted.copy(alpha = 0.7f),
            fontSize = 10.sp
        )
    }
}
