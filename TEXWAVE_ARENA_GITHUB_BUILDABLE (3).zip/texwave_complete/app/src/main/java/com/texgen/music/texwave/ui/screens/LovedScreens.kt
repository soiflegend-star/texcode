package com.texgen.music.texwave.ui.screens
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable

import com.texgen.music.texwave.ui.theme.Tx
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.Timelapse
import androidx.compose.material.icons.rounded.WbTwilight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.Artwork
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.theme.seedColors
import kotlin.math.cos
import kotlin.math.sin

private val LBg = Color(0xFF05060C)
private val LText = Color(0xFFF0ECFF)
private val LMuted = Color(0xFF7A829E)
private val LCyan = Tx.Accent2
private val LViolet = Tx.Accent
private val LPink = Tx.Accent3

enum class LovedDest {
    TimeCapsuleRadio, HeartbeatRoom, LetterToSong, MidnightConfession,
    CoverStory, EchoChamber, SeasonOfYou, OneMoreMinute, RivalMix, FirstLight,
}

data class LovedItem(
    val dest: LovedDest,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
)

val LovedCatalog = listOf(
    LovedItem(LovedDest.TimeCapsuleRadio, "Time Capsule Radio", "Songs that feel like a chosen year", Icons.Rounded.Timelapse, LViolet),
    LovedItem(LovedDest.HeartbeatRoom, "Heartbeat Room", "A pulse that breathes with the mix", Icons.Rounded.Favorite, LPink),
    LovedItem(LovedDest.LetterToSong, "Letter to a Song", "Write what a track means to you", Icons.Rounded.AutoAwesome, LCyan),
    LovedItem(LovedDest.MidnightConfession, "Midnight Confession", "Rare and unplayed under night light", Icons.Rounded.NightsStay, LViolet),
    LovedItem(LovedDest.CoverStory, "Cover Story", "Your library as a wall of covers", Icons.Rounded.PhotoLibrary, LCyan),
    LovedItem(LovedDest.EchoChamber, "Echo Chamber", "Tracks that match this song’s shape", Icons.Rounded.Spa, LPink),
    LovedItem(LovedDest.SeasonOfYou, "Season of You", "Music for the season you’re in", Icons.Rounded.WbTwilight, LViolet),
    LovedItem(LovedDest.OneMoreMinute, "One More Minute", "Short tracks for tiny pockets of time", Icons.Rounded.Schedule, LCyan),
    LovedItem(LovedDest.RivalMix, "Rival Mix", "The emotional opposite of now", Icons.Rounded.LocalFireDepartment, LPink),
    LovedItem(LovedDest.FirstLight, "First Light", "A gentle morning landing sequence", Icons.Rounded.LightMode, LCyan),
)

@Composable
fun LovedShell(title: String, subtitle: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    val glow = rememberInfiniteTransition(label = "loved").animateFloat(
        0.25f, 0.7f, infiniteRepeatable(tween(2800), RepeatMode.Reverse), label = "g",
    )
    Box(Modifier.fillMaxSize().background(LBg)) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                Brush.radialGradient(
                    listOf(LViolet.copy(alpha = 0.22f * glow.value), Color.Transparent),
                    center = Offset(size.width * 0.2f, size.height * 0.15f),
                    radius = size.minDimension * 0.55f,
                ),
                radius = size.minDimension * 0.55f,
                center = Offset(size.width * 0.2f, size.height * 0.15f),
            )
            drawCircle(
                Brush.radialGradient(
                    listOf(LCyan.copy(alpha = 0.12f * glow.value), Color.Transparent),
                    center = Offset(size.width * 0.85f, size.height * 0.35f),
                    radius = size.minDimension * 0.4f,
                ),
                radius = size.minDimension * 0.4f,
                center = Offset(size.width * 0.85f, size.height * 0.35f),
            )
        }
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, "Back", tint = LText)
                }
                Column(Modifier.weight(1f)) {
                    Text(title, color = LText, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                    Text(subtitle, color = LMuted, fontSize = 12.sp)
                }
            }
            content()
        }
    }
}

@Composable
fun LovedHubScreen(onOpen: (LovedDest) -> Unit, onBack: () -> Unit) {
    LovedShell("Rooms I’d stay in", "Ten quiet places built from your music", onBack) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            itemsIndexed(LovedCatalog) { i, item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0x14FFFFFF))
                        .border(1.dp, item.accent.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                        .pressable(0.97f) { onOpen(item.dest) }
                        .padding(14.dp)
                        .appear(i * 45),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(item.accent.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(item.icon, null, tint = item.accent) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.title, color = LText, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                        Text(item.subtitle, color = LMuted, fontSize = 12.sp)
                    }
                }
            }
            item { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable
fun LovedRouter(
    dest: LovedDest,
    lib: LibraryState,
    seed: Song?,
    onPlay: (List<Song>, Int) -> Unit,
    onBack: () -> Unit,
) {
    when (dest) {
        LovedDest.TimeCapsuleRadio -> TimeCapsuleRadioScreen(lib, onPlay, onBack)
        LovedDest.HeartbeatRoom -> HeartbeatRoomScreen(lib, onPlay, onBack)
        LovedDest.LetterToSong -> LetterToSongScreen(lib, seed, onPlay, onBack)
        LovedDest.MidnightConfession -> MidnightConfessionScreen(lib, onPlay, onBack)
        LovedDest.CoverStory -> CoverStoryScreen(lib, onPlay, onBack)
        LovedDest.EchoChamber -> EchoChamberScreen(lib, seed, onPlay, onBack)
        LovedDest.SeasonOfYou -> SeasonOfYouScreen(lib, onPlay, onBack)
        LovedDest.OneMoreMinute -> OneMoreMinuteScreen(lib, onPlay, onBack)
        LovedDest.RivalMix -> RivalMixScreen(lib, seed, onPlay, onBack)
        LovedDest.FirstLight -> FirstLightScreen(lib, onPlay, onBack)
    }
}

@Composable
private fun PlayBar(label: String, list: List<Song>, onPlay: (List<Song>, Int) -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(LViolet.copy(alpha = 0.65f), LCyan.copy(alpha = 0.5f), LPink.copy(alpha = 0.45f))))
            .pressable(0.96f) { if (list.isNotEmpty()) onPlay(list, 0) }
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun LovedSongRow(title: String, subtitle: String, index: Int, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x14FFFFFF))
            .border(1.dp, LCyan.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp)
            .appear(30 + index * 30),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("${index + 1}", color = LCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = LText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotBlank()) Text(subtitle, color = LMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("▶", color = LPink, fontSize = 12.sp)
    }
}

/* 1 — Time Capsule Radio */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TimeCapsuleRadioScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val years = remember(lib) {
        listOf("Classic feel", "Early favorites", "Mid library", "Deep cuts", "Recent heat")
    }
    var idx by remember { mutableIntStateOf(0) }
    val slice = remember(lib, idx) {
        val n = lib.songs.size.coerceAtLeast(1)
        val start = (idx * n / years.size).coerceIn(0, n - 1)
        lib.songs.drop(start).take(20).ifEmpty { lib.songs.take(20) }
    }
    LovedShell("Time Capsule Radio", "Tune a year that never quite left", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                years.forEachIndexed { i, y ->
                    val on = i == idx
                    Text(
                        y,
                        color = if (on) LText else LMuted,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (on) LViolet.copy(alpha = 0.35f) else Color(0x14FFFFFF))
                            .clickable { idx = i }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            slice.take(8).forEach { s ->
                Text("${s.title} · ${s.artist}", color = LText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 3.dp))
            }
            PlayBar("Broadcast this capsule", slice, onPlay)
        }
    }
}

/* 2 — Heartbeat Room */
@Composable
fun HeartbeatRoomScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val beat = rememberInfiniteTransition(label = "hb").animateFloat(
        0.92f, 1.12f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "b",
    )
    val mix = remember(lib) {
        lib.songs.sortedByDescending { (lib.playCounts[it.id] ?: 0) + if (it.id in lib.liked) 4 else 0 }.take(18)
    }
    LovedShell("Heartbeat Room", "Everything expands with the pulse", onBack) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2, size.height * 0.38f)
                drawCircle(LPink.copy(0.2f * beat.value), size.minDimension * 0.28f * beat.value, c)
                drawCircle(LViolet.copy(alpha = 0.15f), size.minDimension * 0.18f * beat.value, c, style = Stroke(4f))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Text("♥", fontSize = 40.sp, modifier = Modifier.graphicsLayer { scaleX = beat.value; scaleY = beat.value })
                Spacer(Modifier.height(12.dp))
                Text("${mix.size} tracks in the chest", color = LMuted, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                PlayBar("Play the pulse", mix, onPlay)
            }
        }
    }
}

/* 3 — Letter to a Song */
@Composable
fun LetterToSongScreen(lib: LibraryState, seed: Song?, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val song = seed ?: lib.songs.firstOrNull()
    var letter by remember { mutableStateOf("") }
    var sealed by remember { mutableStateOf(false) }
    LovedShell("Letter to a Song", "Some tracks deserve words", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            if (song != null) {
                Text(song.title, color = LText, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Text(song.artist, color = LMuted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = letter,
                onValueChange = { letter = it; sealed = false },
                modifier = Modifier.fillMaxWidth().height(160.dp),
                placeholder = { Text("Dear song…", color = LMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = LText,
                    unfocusedTextColor = LText,
                    focusedBorderColor = LCyan,
                    unfocusedBorderColor = Color(0x33FFFFFF),
                ),
            )
            Spacer(Modifier.height(12.dp))
            PlayBar(if (sealed) "Letter sealed · Play the song" else "Seal letter & play", listOfNotNull(song)) { list, i ->
                sealed = true
                onPlay(list, i)
            }
            if (sealed && letter.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text("Sealed with ${letter.length} characters. Only you can read this on this device.", color = LMuted, fontSize = 12.sp)
            }
        }
    }
}

/* 4 — Midnight Confession */
@Composable
fun MidnightConfessionScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val rare = remember(lib) {
        lib.songs.filter { (lib.playCounts[it.id] ?: 0) <= 1 }.shuffled().take(24)
    }
    LovedShell("Midnight Confession", "Tracks that almost never speak", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("${rare.size} quiet voices", color = LCyan, fontSize = 12.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(10.dp))
            rare.take(12).forEach { s ->
                Text(s.title, color = LText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 3.dp))
            }
            PlayBar("Confess in order", rare, onPlay)
        }
    }
}

/* 5 — Cover Story */
@Composable
fun CoverStoryScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val covers = remember(lib) { lib.songs.distinctBy { it.album.ifBlank { it.id.toString() } }.take(40) }
    LovedShell("Cover Story", "A gallery of the art you already own", onBack) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(covers) { s ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onPlay(listOf(s), 0) },
                ) {
                    Artwork(s, Modifier.fillMaxSize(), corner = 12.dp)
                }
            }
        }
    }
}

/* 6 — Echo Chamber */
@Composable
fun EchoChamberScreen(lib: LibraryState, seed: Song?, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val base = seed ?: lib.songs.firstOrNull()
    val echoes = remember(lib, base) {
        if (base == null) emptyList()
        else {
            val dur = base.durationMs
            val artist = base.artist.lowercase()
            val album = base.album.lowercase()
            val titleWords = base.title.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 3 }.toSet()
            lib.songs.filter { it.id != base.id }
                .map { s ->
                    var score = 0.0
                    // Same artist / album = strong echo
                    if (s.artist.lowercase() == artist) score += 8.0
                    if (s.album.lowercase() == album && album.isNotBlank()) score += 5.0
                    // Similar length (shape of the song)
                    val dd = kotlin.math.abs(s.durationMs - dur).toDouble()
                    score += (1.0 - (dd / (dur + 1.0)).coerceIn(0.0, 1.0)) * 4.0
                    // Shared title words
                    val words = s.title.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 3 }
                    score += words.count { it in titleWords } * 1.6
                    if (s.id in lib.liked) score += 2.5
                    score += (lib.playCounts[s.id] ?: 0).coerceAtMost(12) * 0.15
                    s to score
                }
                .sortedByDescending { it.second }
                .map { it.first }
                .take(18)
        }
    }
    LovedShell("Echo Chamber", "Same shape, different soul", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(base?.let { "Echoes of “${it.title}”" } ?: "Play a song first", color = LMuted, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            echoes.forEachIndexed { i, s ->
                LovedSongRow(
                    title = s.title,
                    subtitle = "${s.artist} · ${s.durationMs / 1000}s",
                    index = i,
                    onClick = { onPlay(echoes, i) },
                )
            }
            PlayBar("Enter the chamber", echoes, onPlay)
        }
    }
}

/* 7 — Season of You */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SeasonOfYouScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val seasons = listOf("Spring thaw", "Summer heat", "Autumn return", "Winter quiet")
    var season by remember { mutableIntStateOf(0) }
    val mix = remember(lib, season) {
        val keys = when (season) {
            0 -> listOf("spring", "bloom", "morning", "light", "hope")
            1 -> listOf("summer", "sun", "heat", "night", "party", "drive")
            2 -> listOf("fall", "autumn", "leave", "gold", "return", "home")
            else -> listOf("winter", "cold", "snow", "quiet", "dark", "soft")
        }
        lib.songs.map { s ->
            val t = (s.title + " " + s.artist).lowercase()
            s to keys.count { k -> k in t } + if (s.id in lib.liked) 1 else 0
        }.sortedByDescending { it.second }.map { it.first }.take(18)
    }
    LovedShell("Season of You", "What the year would sound like", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                seasons.forEachIndexed { i, name ->
                    Text(
                        name,
                        color = if (i == season) LText else LMuted,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (i == season) LCyan.copy(alpha = 0.25f) else Color(0x14FFFFFF))
                            .clickable { season = i }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        fontSize = 12.sp,
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            mix.take(10).forEachIndexed { i, s ->
                LovedSongRow(title = s.title, subtitle = s.artist, index = i, onClick = { onPlay(mix, i) })
            }
            PlayBar("Play this season", mix, onPlay)
        }
    }
}

/* 8 — One More Minute */
@Composable
fun OneMoreMinuteScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val shorties = remember(lib) {
        lib.songs.filter { it.durationMs in 30_000..150_000 }.sortedBy { it.durationMs }.take(30)
    }
    LovedShell("One More Minute", "Tiny tracks for stolen seconds", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("${shorties.size} tracks under ~2:30", color = LMuted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            shorties.take(12).forEach { s ->
                Text("${s.title} · ${s.durationMs / 1000}s", color = LText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            PlayBar("Squeeze them in", shorties, onPlay)
        }
    }
}

/* 9 — Rival Mix */
@Composable
fun RivalMixScreen(lib: LibraryState, seed: Song?, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val softWords = listOf("soft", "slow", "calm", "rain", "lofi", "ambient", "piano", "quiet")
    val hardWords = listOf("fire", "bass", "power", "hype", "fast", "rage", "boss", "energy")
    val rivals = remember(lib, seed) {
        val t = ((seed?.title ?: "") + " " + (seed?.artist ?: "")).lowercase()
        val softSeed = softWords.any { it in t }
        val keys = if (softSeed) hardWords else softWords
        lib.songs.map { s ->
            val blob = (s.title + " " + s.artist).lowercase()
            s to keys.count { k -> k in blob }
        }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }.take(16)
            .ifEmpty { lib.songs.shuffled().take(12) }
    }
    LovedShell("Rival Mix", "The opposite energy of what you’re on", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(seed?.let { "Opposite of “${it.title}”" } ?: "A foil for your current taste", color = LMuted, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            rivals.take(10).forEach { Text(it.title, color = LText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            PlayBar("Face the rival", rivals, onPlay)
        }
    }
}

/* 10 — First Light */
@Composable
fun FirstLightScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val rise = rememberInfiniteTransition(label = "sun").animateFloat(
        0f, 1f, infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Reverse), label = "r",
    )
    val morning = remember(lib) {
        val keys = listOf("morning", "sun", "light", "wake", "soft", "calm", "hope", "begin")
        lib.songs.map { s ->
            val t = (s.title + " " + s.artist).lowercase()
            s to keys.count { k -> k in t } + if (s.id in lib.liked) 1 else 0
        }.sortedByDescending { it.second }.map { it.first }.take(15)
            .ifEmpty { lib.songs.take(12) }
    }
    LovedShell("First Light", "A landing sequence for waking up", onBack) {
        Box(Modifier.fillMaxSize()) {
            Canvas(Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2, size.height * (0.55f - 0.08f * rise.value))
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0x66FFB060), Color(0x33FF7A40), Color.Transparent),
                        c,
                        size.minDimension * (0.25f + 0.1f * rise.value),
                    ),
                    radius = size.minDimension * (0.25f + 0.1f * rise.value),
                    center = c,
                )
            }
            Column(
                Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(40.dp))
                Text("GOOD MORNING", color = LCyan, letterSpacing = 3.sp, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("Fifteen quiet rises from your library", color = LMuted, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                morning.take(6).forEach {
                    Text(it.title, color = LText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.height(16.dp))
                PlayBar("Begin first light", morning, onPlay)
            }
        }
    }
}
