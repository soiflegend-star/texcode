package com.texgen.music.texwave.ui.ref

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.catalog.OpenCatalogEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private const val PREFS = "texwave_offline_engine_v1"

private data class Saved(val id: String, val title: String, val artist: String, val path: String)

private fun loadSaved(ctx: Context): List<Saved> = runCatching {
    val a = JSONArray(ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("tracks", "[]"))
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        Saved(o.optString("id"), o.optString("title"), o.optString("artist"), o.optString("localPath"))
    }.filter { it.path.isNotBlank() }
}.getOrDefault(emptyList())

private fun writeSaved(ctx: Context, list: List<Saved>, extra: Map<String, JSONObject> = emptyMap()) {
    val arr = JSONArray()
    list.forEach { s ->
        arr.put(
            (extra[s.id] ?: JSONObject()).put("id", s.id).put("title", s.title).put("artist", s.artist).put("localPath", s.path),
        )
    }
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("tracks", arr.toString()).apply()
}

private fun thumb(id: String) = "https://archive.org/services/img/$id"

private fun pretty(bytes: Long): String = when {
    bytes <= 0 -> ""
    bytes > 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
    else -> "${bytes / 1000} KB"
}

/**
 * Dedicated "Discover & Download" page — a video-feed style layout over the free, legally
 * downloadable catalog (Internet Archive: public-domain / Creative-Commons audio and film).
 * Real progress, cancel, and downloaded files are added to the library automatically.
 */
@Composable
fun RefDiscoverScreen(
    onBack: () -> Unit,
    onStream: (url: String, title: String, artist: String) -> Unit,
    onPlayFile: (path: String, title: String, artist: String) -> Unit,
    onLibraryChanged: () -> Unit,
    startOnDownloads: Boolean = false,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(if (startOnDownloads) 1 else 0) }
    var videos by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var shelf by remember { mutableStateOf(0) }
    var audio by remember { mutableStateOf<List<OpenCatalogEngine.AudioItem>>(emptyList()) }
    var video by remember { mutableStateOf<List<OpenCatalogEngine.VideoItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var reload by remember { mutableStateOf(0) }
    var saved by remember { mutableStateOf(loadSaved(context)) }
    val progress = remember { mutableStateMapOf<String, Float>() }
    val dmIds = remember { mutableStateMapOf<String, Long>() }

    val shelves = OpenCatalogEngine.streamShelves

    LaunchedEffect(shelf, videos, reload) {
        if (query.isNotBlank()) return@LaunchedEffect
        loading = true; failed = false
        try {
            if (videos) video = OpenCatalogEngine.searchVideo(shelves[shelf].query, 12)
            else audio = OpenCatalogEngine.loadShelf(shelves[shelf], 16)
            failed = (if (videos) video else audio).isEmpty()
        } catch (_: Exception) { failed = true }
        loading = false
    }

    fun runSearch() {
        if (query.isBlank()) { reload++; return }
        scope.launch {
            loading = true; failed = false
            // Clear stale results so UI feels instant while the new search runs
            if (videos) video = emptyList() else audio = emptyList()
            try {
                if (videos) video = OpenCatalogEngine.searchVideoFast(query, 12)
                else audio = OpenCatalogEngine.searchAudioFast(query, 30)
                failed = (if (videos) video else audio).isEmpty()
            } catch (_: Exception) { failed = true }
            loading = false
        }
    }

    fun download(id: String, title: String, artist: String, url: String, fileName: String, isVideo: Boolean) {
        if (progress.containsKey(id)) return
        progress[id] = 0f
        scope.launch {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val safe = fileName.ifBlank { id + if (isVideo) ".mp4" else ".mp3" }.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(title).setDescription("$artist · TEXWAVE")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true).setAllowedOverRoaming(true)
            val publicDir = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_MUSIC
            try { req.setDestinationInExternalPublicDir(publicDir, "TEXWAVE/$safe") }
            catch (_: Exception) { req.setDestinationInExternalFilesDir(context, publicDir, safe) }
            val dmId = try { dm.enqueue(req) } catch (e: Exception) {
                progress.remove(id)
                Toast.makeText(context, "Could not start download", Toast.LENGTH_SHORT).show(); return@launch
            }
            dmIds[id] = dmId
            var ok = false
            while (dmIds.containsKey(id)) {
                val (status, got, total) = withContext(Dispatchers.IO) {
                    dm.query(DownloadManager.Query().setFilterById(dmId))?.use { c ->
                        if (!c.moveToFirst()) Triple(-1, 0L, 0L) else Triple(
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                            c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                            c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                        )
                    } ?: Triple(-1, 0L, 0L)
                }
                if (total > 0) progress[id] = (got.toFloat() / total).coerceIn(0f, 1f)
                if (status == DownloadManager.STATUS_SUCCESSFUL) { ok = true; break }
                if (status == DownloadManager.STATUS_FAILED || status == -1) break
                delay(500)
            }
            val cancelled = !dmIds.containsKey(id)
            dmIds.remove(id); progress.remove(id)
            if (ok) {
                val path = withContext(Dispatchers.IO) {
                    dm.query(DownloadManager.Query().setFilterById(dmId))?.use { c ->
                        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)) else null
                    }
                }?.let { u -> Uri.parse(u).let { if (it.scheme == "file") it.path else u } }
                if (path != null) {
                    val next = saved.filterNot { it.id == id } + Saved(id, title, artist, path)
                    saved = next; writeSaved(context, next)
                    if (!path.startsWith("content:")) MediaScannerConnection.scanFile(context, arrayOf(path), null, null)
                    onLibraryChanged()
                    Toast.makeText(context, "Saved: $title", Toast.LENGTH_SHORT).show()
                }
            } else if (!cancelled) {
                Toast.makeText(context, "Download failed — check your connection and try again", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun cancel(id: String) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dmIds.remove(id)?.let { runCatching { dm.remove(it) } }
        progress.remove(id)
    }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF0C1740)).border(1.dp, Ref.Line, CircleShape).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(14.dp))
                Box(Modifier.weight(1f)) { ScreenTitle("Discover") }
            }
            RefTabs(listOf("Explore", "Downloads (${saved.size})"), tab, { tab = it })

            if (tab == 0) {
                RefSearchField(
                    value = query, onChange = { query = it }, placeholder = "Search free music & films...",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), height = 48.dp, textSize = 15.sp,
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Music" to false, "Films" to true).forEach { (label, v) ->
                        val sel = videos == v
                        val s = RoundedCornerShape(18.dp)
                        Text(
                            label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                            modifier = Modifier.clip(s)
                                .background(if (sel) Brush.horizontalGradient(listOf(Ref.Purple, Ref.Blue)) else Brush.horizontalGradient(listOf(Color(0xFF0C1740), Color(0xFF0C1740))))
                                .clickable { videos = v; if (query.isNotBlank()) runSearch() }
                                .padding(horizontal = 18.dp, vertical = 8.dp),
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Search", color = Ref.Cyan, fontSize = 14.sp, modifier = Modifier.clickable { runSearch() }.padding(8.dp))
                }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(shelves.size) { i ->
                        val s = RoundedCornerShape(16.dp)
                        Text(
                            shelves[i].title, color = if (i == shelf && query.isBlank()) Color.White else Color(0xFFB9C6F5), fontSize = 13.sp,
                            modifier = Modifier.clip(s)
                                .background(if (i == shelf && query.isBlank()) Color(0xFF2B3A8C) else Color(0xFF0C1740))
                                .border(1.dp, Ref.Line, s)
                                .clickable { query = ""; shelf = i }
                                .padding(horizontal = 14.dp, vertical = 7.dp),
                        )
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        loading -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            NebulaOrb(Modifier.size(90.dp), energy = 2f)
                            Text("Finding tracks…", color = Ref.Sub, fontSize = 14.sp)
                        }
                        failed -> Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Nothing loaded", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Text("Check your internet connection or try another search.", color = Ref.Sub, fontSize = 14.sp)
                            Spacer(Modifier.height(14.dp))
                            Row(
                                Modifier.clip(RoundedCornerShape(22.dp)).background(Brush.horizontalGradient(listOf(Ref.Purple, Ref.Blue)))
                                    .clickable { if (query.isBlank()) reload++ else runSearch() }.padding(horizontal = 22.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Rounded.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Try again", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        else -> LazyColumn(
                            Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                            verticalArrangement = Arrangement.spacedBy(18.dp),
                        ) {
                            if (!videos) items(audio, key = { it.id }) { a ->
                                FeedCard(
                                    id = a.id, title = a.title, subtitle = a.artist + " · " + a.license, size = pretty(a.bytesHint),
                                    progress = progress[a.id], saved = saved.any { it.id == a.id }, actionLabel = "Play",
                                    onAction = { onStream(a.url, a.title, a.artist) },
                                    onDownload = { download(a.id, a.title, a.artist, a.url, a.fileName, false) },
                                    onCancel = { cancel(a.id) },
                                )
                            } else items(video, key = { it.id }) { v ->
                                FeedCard(
                                    id = v.id, title = v.title, subtitle = v.creator + " · " + v.license, size = pretty(v.bytesHint),
                                    progress = progress[v.id], saved = saved.any { it.id == v.id }, actionLabel = "Watch",
                                    onAction = {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(v.url), "video/*").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                            )
                                        }.onFailure { Toast.makeText(context, "No video player found", Toast.LENGTH_SHORT).show() }
                                    },
                                    onDownload = { download(v.id, v.title, v.creator, v.url, v.id + ".mp4", true) },
                                    onCancel = { cancel(v.id) },
                                )
                            }
                        }
                    }
                }
            } else {
                if (saved.isEmpty()) {
                    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.CloudDownload, null, tint = Ref.Violet, modifier = Modifier.size(56.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("No downloads yet", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text("Tap the download button on any track in Explore. Saved songs also appear in your Library.", color = Ref.Sub, fontSize = 14.sp)
                    }
                } else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 24.dp)) {
                    items(saved, key = { it.id }) { s ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 5.dp).refCard(18.dp).padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AsyncImage(
                                thumb(s.id), null, Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High,
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.artist, color = Ref.Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (!File(s.path).exists() && !s.path.startsWith("content:")) Text("File missing", color = Color(0xFFFF6D9B), fontSize = 12.sp)
                            }
                            Icon(
                                Icons.Rounded.PlayArrow, "Play", tint = Ref.Cyan,
                                modifier = Modifier.size(40.dp).clickable { onPlayFile(s.path, s.title, s.artist) }.padding(6.dp),
                            )
                            Icon(
                                Icons.Rounded.Delete, "Delete", tint = Color(0xFFFF6D9B),
                                modifier = Modifier.size(40.dp).clickable {
                                    runCatching { if (!s.path.startsWith("content:")) File(s.path).delete() }
                                    saved = saved.filterNot { it.id == s.id }; writeSaved(context, saved)
                                    onLibraryChanged()
                                }.padding(8.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedCard(
    id: String, title: String, subtitle: String, size: String, progress: Float?, saved: Boolean,
    actionLabel: String, onAction: () -> Unit, onDownload: () -> Unit, onCancel: () -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(shape).border(1.dp, Ref.Line, shape).clickable(onClick = onAction)) {
            AsyncImage(thumb(id), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC02040C)))))
            Box(
                Modifier.align(Alignment.Center).size(54.dp).clip(CircleShape).background(Color(0x99000000)).border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.PlayArrow, actionLabel, tint = Color.White, modifier = Modifier.size(32.dp)) }
            if (size.isNotBlank()) Text(
                size, color = Color.White, fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xCC000000)).padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(subtitle, color = Ref.Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(10.dp))
            val s = RoundedCornerShape(20.dp)
            when {
                progress != null -> Row(
                    Modifier.clip(s).background(Color(0xFF111B45)).border(1.dp, Ref.Line, s).clickable(onClick = onCancel).padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${(progress * 100).toInt()}%  ✕", color = Ref.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                saved -> Row(
                    Modifier.clip(s).background(Color(0xFF0E3A3A)).padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.DownloadDone, null, tint = Color(0xFF3DFFB0), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Saved", color = Color(0xFF3DFFB0), fontSize = 13.sp)
                }
                else -> Row(
                    Modifier.clip(s).background(Brush.horizontalGradient(listOf(Ref.Purple, Ref.Blue))).clickable(onClick = onDownload).padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.CloudDownload, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Download", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (progress != null) LinearProgressIndicator(
            progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(4.dp).clip(CircleShape),
            color = Ref.Cyan, trackColor = Color(0xFF0B1A5A),
        )
    }
}
