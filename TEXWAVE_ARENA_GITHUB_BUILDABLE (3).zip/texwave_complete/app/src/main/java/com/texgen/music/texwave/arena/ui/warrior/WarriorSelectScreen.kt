package com.texgen.music.texwave.arena.ui.warrior

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.CosmeticCatalog
import com.texgen.music.texwave.arena.data.model.CosmeticSlot
import com.texgen.music.texwave.arena.data.model.WarriorGender
import com.texgen.music.texwave.arena.data.model.WarriorLoadout
import com.texgen.music.texwave.arena.data.model.WarriorProfile
import com.texgen.music.texwave.arena.domain.RankSystem
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.ArenaColors.ScreenBg
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard

@Composable
fun WarriorSelectScreen(
    profile: WarriorProfile,
    onSave: (WarriorLoadout) -> Unit,
    onClose: () -> Unit
) {
    var loadout by remember { mutableStateOf(profile.loadout) }
    val unlocked = CosmeticCatalog.unlockedFor(profile.level, profile.rank, profile.unlockedCosmeticIds)

    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("WARRIOR FORGE", color = ArenaColors.Cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, fontSize = 12.sp)
        Text("Cosmetic identity only", color = ArenaColors.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        WarriorAvatar(loadout, profile.rank, profile.level, modifier = Modifier.align(Alignment.CenterHorizontally), size = 160)
        Spacer(Modifier.height(16.dp))

        Text("Gender", color = ArenaColors.Text, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GenderChip("Boy", loadout.gender == WarriorGender.BOY) {
                loadout = loadout.copy(gender = WarriorGender.BOY)
            }
            GenderChip("Girl", loadout.gender == WarriorGender.GIRL) {
                loadout = loadout.copy(gender = WarriorGender.GIRL)
            }
        }
        Spacer(Modifier.height(12.dp))

        SlotPicker("Outfit", CosmeticSlot.OUTFIT, unlocked, loadout.outfitId) {
            loadout = loadout.copy(outfitId = it)
        }
        SlotPicker("Aura", CosmeticSlot.AURA, unlocked, loadout.auraId) {
            loadout = loadout.copy(auraId = it)
        }
        SlotPicker("Armor", CosmeticSlot.ARMOR, unlocked, loadout.armorId) {
            loadout = loadout.copy(armorId = it)
        }
        SlotPicker("Gloves", CosmeticSlot.GLOVES, unlocked, loadout.glovesId) {
            loadout = loadout.copy(glovesId = it)
        }

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { onSave(loadout) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Cyan, contentColor = Color.Black)
        ) { Text("Save Warrior", fontWeight = FontWeight.Bold) }
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Close") }
    }
}

@Composable
private fun GenderChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label,
        color = if (selected) ArenaColors.Cyan else ArenaColors.Muted,
        modifier = Modifier
            .arenaGlassCard(12)
            .then(if (selected) Modifier.border(1.dp, ArenaColors.Cyan, RoundedCornerShape(12.dp)) else Modifier)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
private fun SlotPicker(
    title: String,
    slot: CosmeticSlot,
    unlocked: List<com.texgen.music.texwave.arena.data.model.CosmeticItem>,
    selectedId: String,
    onSelect: (String) -> Unit
) {
    Text(title, color = ArenaColors.Text, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 10.dp))
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        unlocked.filter { it.slot == slot }.forEach { item ->
            val sel = item.id == selectedId
            Row(
                Modifier
                    .fillMaxWidth()
                    .arenaGlassCard(12)
                    .clickable { onSelect(item.id) }
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(item.name, color = if (sel) ArenaColors.Cyan else ArenaColors.Text)
                if (item.isLegendary) Text("LEGENDARY", color = ArenaColors.RankGold, fontSize = 10.sp)
            }
        }
    }
}
