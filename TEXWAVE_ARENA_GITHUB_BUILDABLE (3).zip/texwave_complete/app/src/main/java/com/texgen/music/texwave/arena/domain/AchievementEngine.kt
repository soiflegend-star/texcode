package com.texgen.music.texwave.arena.domain

import com.texgen.music.texwave.arena.data.model.AchievementSummary
import com.texgen.music.texwave.arena.data.model.ArenaActivity
import com.texgen.music.texwave.arena.data.model.ArenaPlayer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Achievement definitions + unlock evaluation.
 * Pure logic — can be mirrored in a Supabase edge function later.
 */
object AchievementEngine {

    data class Def(
        val id: String,
        val title: String,
        val description: String,
        val iconKey: String,
        val xpReward: Long,
        val evaluate: (EvalContext) -> Boolean
    )

    data class EvalContext(
        val player: ArenaPlayer,
        val activities: List<ArenaActivity>,
        val challengesCompleted: Int,
        val hasSquad: Boolean
    )

    val catalog: List<Def> = listOf(
        Def(
            id = "first_session",
            title = "First Session",
            description = "Complete your first recorded session",
            iconKey = "first_session",
            xpReward = 20
        ) { ctx -> ctx.activities.isNotEmpty() },

        Def(
            id = "consistency_3",
            title = "Consistency",
            description = "Log activity on 3 different days",
            iconKey = "consistency",
            xpReward = 40
        ) { ctx ->
            val zone = ZoneId.systemDefault()
            ctx.activities
                .map { LocalDate.ofInstant(it.recordedAt, zone) }
                .toSet()
                .size >= 3
        },

        Def(
            id = "weekly_warrior",
            title = "Weekly Warrior",
            description = "Complete a weekly challenge",
            iconKey = "weekly",
            xpReward = 50
        ) { ctx -> ctx.challengesCompleted >= 1 },

        Def(
            id = "rising_player",
            title = "Rising Player",
            description = "Reach level 10",
            iconKey = "rising",
            xpReward = 50
        ) { ctx -> ctx.player.level >= 10 },

        Def(
            id = "centurion",
            title = "Centurion",
            description = "Log 100 total push-ups",
            iconKey = "centurion",
            xpReward = 30
        ) { ctx -> ctx.player.totalPushUps >= 100 },

        Def(
            id = "global_competitor",
            title = "Global Competitor",
            description = "Participate in a global challenge",
            iconKey = "global",
            xpReward = 35
        ) { ctx -> ctx.challengesCompleted >= 1 },

        Def(
            id = "squad_contributor",
            title = "Squad Contributor",
            description = "Contribute to a squad",
            iconKey = "squad",
            xpReward = 25
        ) { ctx -> ctx.hasSquad },

        Def(
            id = "level_25",
            title = "Veteran",
            description = "Reach level 25",
            iconKey = "veteran",
            xpReward = 120
        ) { ctx -> ctx.player.level >= 25 },

        Def(
            id = "thousand_reps",
            title = "Thousand Club",
            description = "Accumulate 1 000 push-ups",
            iconKey = "thousand",
            xpReward = 100
        ) { ctx -> ctx.player.totalPushUps >= 1000 }
    )

    fun evaluateAll(
        player: ArenaPlayer,
        activities: List<ArenaActivity>,
        challengesCompleted: Int,
        hasSquad: Boolean,
        alreadyUnlocked: Set<String>
    ): List<AchievementSummary> {
        val ctx = EvalContext(player, activities, challengesCompleted, hasSquad)
        val now = Instant.now()
        return catalog.map { def ->
            val unlocked = alreadyUnlocked.contains(def.id) || def.evaluate(ctx)
            AchievementSummary(
                id = def.id,
                title = def.title,
                description = def.description,
                iconKey = def.iconKey,
                isUnlocked = unlocked,
                unlockedAt = if (unlocked) now else null,
                xpReward = def.xpReward
            )
        }
    }

    /** Newly unlocked ids that were not in alreadyUnlocked */
    fun newlyUnlocked(
        player: ArenaPlayer,
        activities: List<ArenaActivity>,
        challengesCompleted: Int,
        hasSquad: Boolean,
        alreadyUnlocked: Set<String>
    ): List<Def> {
        val ctx = EvalContext(player, activities, challengesCompleted, hasSquad)
        return catalog.filter { it.id !in alreadyUnlocked && it.evaluate(ctx) }
    }
}
