package com.texgen.music.texwave.arena.data.repository

import com.texgen.music.texwave.arena.data.model.ActivitySource
import com.texgen.music.texwave.arena.data.model.ActivityType
import com.texgen.music.texwave.arena.data.model.ArenaActivity
import com.texgen.music.texwave.arena.data.model.ArenaChallenge
import com.texgen.music.texwave.arena.data.model.ArenaChallengeSummary
import com.texgen.music.texwave.arena.data.model.ArenaHomeState
import com.texgen.music.texwave.arena.data.model.ArenaMission
import com.texgen.music.texwave.arena.data.model.ArenaPlayer
import com.texgen.music.texwave.arena.data.model.ArenaSquad
import com.texgen.music.texwave.arena.data.model.ChallengeParticipation
import com.texgen.music.texwave.arena.data.model.ChallengePeriod
import com.texgen.music.texwave.arena.data.model.DailyMissionSummary
import com.texgen.music.texwave.arena.data.model.LeaderboardEntry
import com.texgen.music.texwave.arena.data.model.LeaderboardPage
import com.texgen.music.texwave.arena.data.model.LeaderboardScope
import com.texgen.music.texwave.arena.data.model.MissionProgress
import com.texgen.music.texwave.arena.data.model.SquadDetail
import com.texgen.music.texwave.arena.data.model.SquadMember
import com.texgen.music.texwave.arena.data.model.SquadRole
import com.texgen.music.texwave.arena.data.model.SquadStatus
import com.texgen.music.texwave.arena.data.model.XpTransaction
import com.texgen.music.texwave.arena.data.supabase.SupabaseArenaClient
import com.texgen.music.texwave.arena.domain.ChallengeEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.time.Instant
import java.util.UUID

/**
 * Production repository. All XP / claims / roles go through SECURITY DEFINER RPCs.
 * Table reads only. No client-side XP mutation.
 */
class SupabaseArenaRepository(
    private val client: SupabaseArenaClient
) : ArenaRepository {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val _home = MutableStateFlow(
        ArenaHomeState(player = emptyPlayer(), isLoading = true)
    )
    private val _player = MutableStateFlow(emptyPlayer())
    private val _activities = MutableStateFlow<List<ArenaActivity>>(emptyList())
    private val _transactions = MutableStateFlow<List<XpTransaction>>(emptyList())
    private val _challenges = MutableStateFlow<List<ChallengeView>>(emptyList())
    private val _missions = MutableStateFlow<List<MissionView>>(emptyList())
    private val _squadDetail = MutableStateFlow<SquadDetail?>(null)
    private val _squadRankings = MutableStateFlow<List<ArenaSquad>>(emptyList())
    private val leaderboardFlows =
        mutableMapOf<LeaderboardScope, MutableStateFlow<LeaderboardPage>>()

    private fun emptyPlayer() = ArenaPlayer(userId = "", username = "…")

    private fun requireUser(): String =
        client.currentUserId() ?: error("Not authenticated")

    override fun observeHomeState(): Flow<ArenaHomeState> = _home.asStateFlow()
    override fun observePlayer(): Flow<ArenaPlayer> = _player.asStateFlow()
    override fun observeActivities(): Flow<List<ArenaActivity>> = _activities.asStateFlow()
    override fun observeXpTransactions(): Flow<List<XpTransaction>> = _transactions.asStateFlow()
    override fun observeChallenges(): Flow<List<ChallengeView>> = _challenges.asStateFlow()
    override fun observeMissions(): Flow<List<MissionView>> = _missions.asStateFlow()
    override fun observeSquadDetail(): Flow<SquadDetail?> = _squadDetail.asStateFlow()
    override fun observeSquadRankings(): Flow<List<ArenaSquad>> = _squadRankings.asStateFlow()

    override fun observeLeaderboard(scope: LeaderboardScope): Flow<LeaderboardPage> {
        return leaderboardFlows.getOrPut(scope) {
            MutableStateFlow(
                LeaderboardPage(scope, emptyList(), null, 0, scope.name)
            )
        }.asStateFlow()
    }

    override suspend fun refreshHome() {
        _home.value = _home.value.copy(isLoading = true, error = null)
        try {
            ensureProfile()
            loadPlayer()
            loadActivities()
            loadChallenges()
            loadMissions()
            loadSquad()
            loadSquadRankings()
            LeaderboardScope.entries.forEach { loadLeaderboard(it) }
            rebuildHome()
        } catch (e: Exception) {
            _home.value = _home.value.copy(isLoading = false, error = e.message ?: "Load failed")
        }
    }

    override suspend fun logActivity(
        count: Int,
        type: ActivityType,
        source: ActivitySource,
        note: String?,
        performedAt: Instant
    ): Result<ArenaActivity> = runCatching {
        // Force unverified path until real camera recognition exists
        val safeSource = when (source) {
            ActivitySource.IMPORT -> "IMPORT"
            else -> "MANUAL"
        }
        val requestId = UUID.randomUUID().toString()
        val raw = client.rpcRaw(
            "arena_award_activity_xp",
            mapOf(
                "p_count" to count,
                "p_source" to safeSource,
                "p_note" to note,
                "p_client_request_id" to requestId,
                "p_performed_at" to performedAt.toString()
            )
        )
        val act = parseActivity(json.parseToJsonElement(raw).jsonObject)
        loadPlayer()
        loadActivities()
        loadChallenges()
        loadMissions()
        rebuildHome()
        act
    }

    override suspend fun joinChallenge(challengeId: String): Result<Unit> = runCatching {
        client.rpcRaw("arena_join_challenge", mapOf("p_challenge_id" to challengeId))
        loadChallenges()
        rebuildHome()
    }

    override suspend fun claimChallengeReward(challengeId: String): Result<Long> = runCatching {
        val raw = client.rpcRaw("arena_claim_challenge", mapOf("p_challenge_id" to challengeId))
        val xp = raw.trim().toLongOrNull() ?: 0L
        loadPlayer()
        loadChallenges()
        rebuildHome()
        xp
    }

    override suspend fun claimMissionReward(missionId: String): Result<Long> = runCatching {
        val raw = client.rpcRaw("arena_claim_mission", mapOf("p_mission_id" to missionId))
        val xp = raw.trim().toLongOrNull() ?: 0L
        loadPlayer()
        loadMissions()
        rebuildHome()
        xp
    }

    override suspend fun markLeaderboardVisited() {
        runCatching {
            client.rpcRaw("arena_mark_leaderboard_visited")
            loadMissions()
            rebuildHome()
        }
    }

    override suspend fun createSquad(name: String, description: String): Result<ArenaSquad> =
        runCatching {
            val raw = client.rpcRaw(
                "arena_create_squad",
                mapOf("p_name" to name, "p_description" to description)
            )
            val squad = parseSquad(json.parseToJsonElement(raw).jsonObject)
            loadPlayer()
            loadSquad()
            loadSquadRankings()
            rebuildHome()
            squad
        }

    override suspend fun leaveSquad(): Result<Unit> = runCatching {
        client.rpcRaw("arena_leave_squad")
        loadPlayer()
        loadSquad()
        rebuildHome()
    }

    // ------------------------------------------------------------------

    private suspend fun ensureProfile() {
        val username = client.currentUsername() ?: "player"
        client.rpcRaw(
            "arena_ensure_profile",
            mapOf("p_username" to username, "p_display_name" to username)
        )
    }

    private suspend fun loadPlayer() {
        val uid = requireUser()
        val raw = client.select(
            "arena_profiles",
            filters = mapOf("user_id" to "eq.$uid"),
            limit = 1
        )
        val arr = json.parseToJsonElement(raw).jsonArray
        if (arr.isNotEmpty()) {
            _player.value = parsePlayer(arr[0].jsonObject)
        }
    }

    private suspend fun loadActivities() {
        val uid = requireUser()
        val raw = client.select(
            "arena_activities",
            filters = mapOf("user_id" to "eq.$uid"),
            order = "recorded_at.desc",
            limit = 100
        )
        _activities.value = json.parseToJsonElement(raw).jsonArray.map {
            parseActivity(it.jsonObject)
        }
    }

    private suspend fun loadChallenges() {
        val uid = requireUser()
        val chalRaw = client.select("arena_challenges", order = "start_at.desc")
        val partRaw = client.select(
            "arena_challenge_participants",
            filters = mapOf("user_id" to "eq.$uid")
        )
        val parts = json.parseToJsonElement(partRaw).jsonArray
            .associate { o ->
                val obj = o.jsonObject
                obj.str("challenge_id") to ChallengeParticipation(
                    challengeId = obj.str("challenge_id"),
                    userId = obj.str("user_id"),
                    joinedAt = obj.instant("joined_at"),
                    progress = obj.int("progress"),
                    isCompleted = obj.bool("is_completed"),
                    isClaimed = obj.bool("is_claimed"),
                    completedAt = obj.instantOrNull("completed_at"),
                    claimedAt = obj.instantOrNull("claimed_at")
                )
            }
        _challenges.value = json.parseToJsonElement(chalRaw).jsonArray.map { el ->
            val o = el.jsonObject
            val ch = ArenaChallenge(
                id = o.str("id"),
                title = o.str("title"),
                description = o.str("description"),
                difficulty = o.str("difficulty"),
                period = runCatching { ChallengePeriod.valueOf(o.str("period")) }
                    .getOrDefault(ChallengePeriod.SPECIAL),
                targetCount = o.int("target_count"),
                startAt = o.instant("start_at"),
                endAt = o.instant("end_at"),
                xpReward = o.long("xp_reward"),
                isGlobal = o.bool("is_global")
            )
            val part = parts[ch.id]
            ChallengeView(
                challenge = ch,
                participation = part,
                progress = part?.progress ?: 0,
                isJoined = part != null,
                isCompleted = part?.isCompleted == true,
                isClaimed = part?.isClaimed == true
            )
        }
    }

    private suspend fun loadMissions() {
        val uid = requireUser()
        val today = java.time.LocalDate.now(java.time.ZoneOffset.UTC).toString()
        val defRaw = client.select("arena_daily_missions")
        val progRaw = client.select(
            "arena_mission_progress",
            filters = mapOf("user_id" to "eq.$uid", "date_key" to "eq.$today")
        )
        val progs = json.parseToJsonElement(progRaw).jsonArray.associate {
            val o = it.jsonObject
            o.str("mission_id") to MissionProgress(
                missionId = o.str("mission_id"),
                userId = o.str("user_id"),
                dateKey = o.str("date_key"),
                progress = o.int("progress"),
                isCompleted = o.bool("is_completed"),
                isClaimed = o.bool("is_claimed"),
                claimedAt = o.instantOrNull("claimed_at")
            )
        }
        _missions.value = json.parseToJsonElement(defRaw).jsonArray.map { el ->
            val o = el.jsonObject
            val m = ArenaMission(
                id = o.str("id"),
                title = o.str("title"),
                description = o.str("description"),
                target = o.int("target"),
                xpReward = o.long("xp_reward"),
                kind = o.str("kind")
            )
            val p = progs[m.id]
            MissionView(
                mission = m,
                progress = p,
                current = p?.progress ?: 0,
                isCompleted = p?.isCompleted == true || (p?.progress ?: 0) >= m.target,
                isClaimed = p?.isClaimed == true
            )
        }
    }

    private suspend fun loadSquad() {
        val player = _player.value
        if (player.squadId.isNullOrBlank()) {
            _squadDetail.value = null
            return
        }
        val squadRaw = client.select(
            "arena_squads",
            filters = mapOf("id" to "eq.${player.squadId}"),
            limit = 1
        )
        val memRaw = client.select(
            "arena_squad_members",
            filters = mapOf("squad_id" to "eq.${player.squadId}")
        )
        val arr = json.parseToJsonElement(squadRaw).jsonArray
        if (arr.isEmpty()) {
            _squadDetail.value = null
            return
        }
        val squad = parseSquad(arr[0].jsonObject)
        val members = json.parseToJsonElement(memRaw).jsonArray.map {
            val o = it.jsonObject
            SquadMember(
                userId = o.str("user_id"),
                username = o.str("user_id").take(8),
                role = runCatching { SquadRole.valueOf(o.str("role")) }.getOrDefault(SquadRole.MEMBER),
                contributionXp = o.long("contribution_xp"),
                joinedAt = o.instant("joined_at")
            )
        }.sortedByDescending { it.contributionXp }
        _squadDetail.value = SquadDetail(
            squad = squad.copy(memberCount = members.size),
            members = members,
            currentUserRole = members.find { it.userId == player.userId }?.role
        )
    }

    private suspend fun loadSquadRankings() {
        val raw = client.select("arena_squads", order = "total_xp.desc", limit = 50)
        _squadRankings.value = json.parseToJsonElement(raw).jsonArray.mapIndexed { i, el ->
            parseSquad(el.jsonObject).copy(rank = i + 1)
        }
    }

    private suspend fun loadLeaderboard(scope: LeaderboardScope) {
        val raw = client.rpcRaw(
            "arena_leaderboard",
            mapOf(
                "p_scope" to scope.name,
                "p_limit" to 50,
                "p_offset" to 0
            )
        )
        val uid = client.currentUserId()
        val entries = json.parseToJsonElement(raw).jsonArray.map { el ->
            val o = el.jsonObject
            LeaderboardEntry(
                rank = o.long("rank").toInt(),
                userId = o.str("user_id"),
                username = o.str("username"),
                displayName = o.str("display_name").ifBlank { o.str("username") },
                avatarUrl = o.strOrNull("avatar_url"),
                level = o.int("level"),
                xp = o.long("xp"),
                pushUps = o.long("push_ups"),
                isCurrentUser = o.str("user_id") == uid
            )
        }
        val me = entries.find { it.isCurrentUser }
        val flow = leaderboardFlows.getOrPut(scope) {
            MutableStateFlow(LeaderboardPage(scope, emptyList(), null, 0, scope.name))
        }
        flow.value = LeaderboardPage(
            scope = scope,
            entries = entries,
            currentUserEntry = me,
            totalPlayers = entries.size,
            periodLabel = scope.name
        )
    }

    private fun rebuildHome() {
        val player = _player.value
        val challenges = _challenges.value
        val missions = _missions.value
        val squad = _squadDetail.value
        _home.value = ArenaHomeState(
            player = player,
            activeChallenges = challenges.filter { it.isJoined && !it.isClaimed }.take(3).map {
                ArenaChallengeSummary(
                    id = it.challenge.id,
                    title = it.challenge.title,
                    description = it.challenge.description,
                    difficulty = it.challenge.difficulty,
                    progress = it.progress,
                    target = it.challenge.targetCount,
                    endsAt = it.challenge.endAt,
                    xpReward = it.challenge.xpReward,
                    participantCount = 0,
                    isJoined = true,
                    isCompleted = it.isCompleted
                )
            },
            dailyMissions = missions.map {
                DailyMissionSummary(
                    id = it.mission.id,
                    title = it.mission.title,
                    description = it.mission.description,
                    progress = it.current,
                    target = it.mission.target,
                    xpReward = it.mission.xpReward,
                    isCompleted = it.isCompleted,
                    isClaimed = it.isClaimed
                )
            },
            squad = squad?.let {
                SquadStatus(
                    squadId = it.squad.id,
                    name = it.squad.name,
                    memberCount = it.squad.memberCount,
                    totalXp = it.squad.totalXp,
                    rank = it.squad.rank,
                    userContributionXp = it.members.find { m -> m.userId == player.userId }?.contributionXp ?: 0
                )
            },
            isLoading = false,
            error = null
        )
    }

    // ---- JSON helpers ----

    private fun parsePlayer(o: JsonObject) = ArenaPlayer(
        userId = o.str("user_id"),
        username = o.str("username"),
        displayName = o.str("display_name").ifBlank { o.str("username") },
        avatarUrl = o.strOrNull("avatar_url"),
        level = o.int("level"),
        totalXp = o.long("total_xp"),
        xpIntoCurrentLevel = o.long("xp_into_level"),
        xpRequiredForNextLevel = o.long("xp_required_next"),
        totalPushUps = o.long("total_push_ups"),
        squadId = o.strOrNull("squad_id"),
        updatedAt = o.instantOrNull("updated_at") ?: Instant.now()
    )

    private fun parseActivity(o: JsonObject) = ArenaActivity(
        id = o.str("id"),
        userId = o.str("user_id"),
        type = ActivityType.PUSH_UPS,
        count = o.int("count"),
        source = when (o.str("source")) {
            "IMPORT" -> ActivitySource.IMPORT
            "CAMERA_ASSISTED" -> ActivitySource.MANUAL // never trust client-verified
            else -> ActivitySource.MANUAL
        },
        performedAt = o.instant("performed_at"),
        recordedAt = o.instant("recorded_at"),
        note = o.strOrNull("note"),
        xpAwarded = o.long("xp_awarded"),
        isVerified = false // camera not implemented
    )

    private fun parseSquad(o: JsonObject) = ArenaSquad(
        id = o.str("id"),
        name = o.str("name"),
        description = o.str("description"),
        ownerId = o.str("owner_id"),
        totalXp = o.long("total_xp"),
        level = o.int("level"),
        createdAt = o.instantOrNull("created_at") ?: Instant.now()
    )

    private fun JsonObject.str(key: String) =
        this[key]?.jsonPrimitive?.contentOrNull ?: ""

    private fun JsonObject.strOrNull(key: String) =
        this[key]?.jsonPrimitive?.contentOrNull

    private fun JsonObject.int(key: String) =
        this[key]?.jsonPrimitive?.intOrNull
            ?: this[key]?.jsonPrimitive?.contentOrNull?.toIntOrNull() ?: 0

    private fun JsonObject.long(key: String) =
        this[key]?.jsonPrimitive?.longOrNull
            ?: this[key]?.jsonPrimitive?.contentOrNull?.toLongOrNull() ?: 0L

    private fun JsonObject.bool(key: String) =
        this[key]?.jsonPrimitive?.booleanOrNull
            ?: (this[key]?.jsonPrimitive?.contentOrNull == "true")

    private fun JsonObject.instant(key: String): Instant =
        instantOrNull(key) ?: Instant.EPOCH

    private fun JsonObject.instantOrNull(key: String): Instant? =
        this[key]?.jsonPrimitive?.contentOrNull?.let {
            runCatching { Instant.parse(it) }.getOrNull()
        }
}
