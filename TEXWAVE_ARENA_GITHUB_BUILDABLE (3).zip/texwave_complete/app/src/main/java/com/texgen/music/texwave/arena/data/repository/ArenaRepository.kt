package com.texgen.music.texwave.arena.data.repository

import com.texgen.music.texwave.arena.data.model.AchievementSummary
import com.texgen.music.texwave.arena.data.model.ActivitySource
import com.texgen.music.texwave.arena.data.model.ActivityType
import com.texgen.music.texwave.arena.data.model.ArenaActivity
import com.texgen.music.texwave.arena.data.model.ArenaChallenge
import com.texgen.music.texwave.arena.data.model.ArenaChallengeSummary
import com.texgen.music.texwave.arena.data.model.ArenaHomeState
import com.texgen.music.texwave.arena.data.model.ArenaMission
import com.texgen.music.texwave.arena.data.model.ArenaPlayer
import com.texgen.music.texwave.arena.data.model.ChallengeParticipation
import com.texgen.music.texwave.arena.data.model.DailyMissionSummary
import com.texgen.music.texwave.arena.data.model.FriendActivity
import com.texgen.music.texwave.arena.data.model.MissionProgress
import com.texgen.music.texwave.arena.data.model.SquadStatus
import com.texgen.music.texwave.arena.data.model.XpTransaction
import com.texgen.music.texwave.arena.domain.ChallengeEngine
import com.texgen.music.texwave.arena.domain.XpEngine
import com.texgen.music.texwave.arena.data.model.ArenaSquad
import com.texgen.music.texwave.arena.data.model.LeaderboardPage
import com.texgen.music.texwave.arena.data.model.LeaderboardScope
import com.texgen.music.texwave.arena.data.model.SquadDetail
import com.texgen.music.texwave.arena.data.model.SquadMember
import com.texgen.music.texwave.arena.data.model.SquadRole
import com.texgen.music.texwave.arena.domain.LeaderboardEngine

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

interface ArenaRepository {
    fun observeHomeState(): Flow<ArenaHomeState>
    fun observePlayer(): Flow<ArenaPlayer>
    fun observeActivities(): Flow<List<ArenaActivity>>
    fun observeXpTransactions(): Flow<List<XpTransaction>>
    fun observeChallenges(): Flow<List<ChallengeView>>
    fun observeMissions(): Flow<List<MissionView>>

    suspend fun refreshHome()
    suspend fun logActivity(
        count: Int,
        type: ActivityType = ActivityType.PUSH_UPS,
        source: ActivitySource = ActivitySource.MANUAL,
        note: String? = null,
        performedAt: Instant = Instant.now()
    ): Result<ArenaActivity>

    suspend fun joinChallenge(challengeId: String): Result<Unit>
    suspend fun claimChallengeReward(challengeId: String): Result<Long>
    suspend fun claimMissionReward(missionId: String): Result<Long>
    suspend fun markLeaderboardVisited()

    fun observeLeaderboard(scope: LeaderboardScope): Flow<LeaderboardPage>
    fun observeSquadDetail(): Flow<SquadDetail?>
    fun observeSquadRankings(): Flow<List<ArenaSquad>>

    suspend fun createSquad(name: String, description: String): Result<ArenaSquad>
    suspend fun leaveSquad(): Result<Unit>
}


data class ChallengeView(
    val challenge: ArenaChallenge,
    val participation: ChallengeParticipation?,
    val progress: Int,
    val isJoined: Boolean,
    val isCompleted: Boolean,
    val isClaimed: Boolean
)

data class MissionView(
    val mission: ArenaMission,
    val progress: MissionProgress?,
    val current: Int,
    val isCompleted: Boolean,
    val isClaimed: Boolean
)

/**
 * DEMO ONLY — in-memory seed data for UI development and previews.
 * Never ship as the production default. Use [SupabaseArenaRepository] via [ArenaModule.initSupabase].
 * Demo leaderboard bots are synthetic and must not be shown as real competitors in production builds.
 */
class LocalArenaRepository : ArenaRepository {

    private val zone = ZoneId.systemDefault()

    private val activities = ConcurrentHashMap<String, ArenaActivity>()
    private val transactions = ConcurrentHashMap<String, XpTransaction>()
    private val participations = ConcurrentHashMap<String, ChallengeParticipation>()
    private val missionProgressMap = ConcurrentHashMap<String, MissionProgress>()

    private var hasCheckedLeaderboardToday = false

    private var player = ArenaPlayer(
        userId = "demo-user-001",
        username = "phantom_rider",
        displayName = "Phantom Rider",
        level = 12,
        totalXp = 4820L,
        xpIntoCurrentLevel = 320L,
        xpRequiredForNextLevel = 500L,
        globalRank = 1847,
        weeklyRank = 312,
        monthlyRank = 891,
        totalPushUps = 2140L,
        squadId = "squad-alpha",
        squadName = "Night Operators"
    )

    private val challengeCatalog by lazy { runCatching { ChallengeEngine.defaultChallenges() }.getOrDefault(emptyList()) }
    private val missionCatalog by lazy { runCatching { ChallengeEngine.defaultMissions() }.getOrDefault(emptyList()) }

    private val squadMembers = ConcurrentHashMap<String, SquadMember>()
    private var currentSquad: ArenaSquad? = ArenaSquad(
        id = "squad-alpha",
        name = "Night Operators",
        description = "Late-night grind unit. Consistency over volume.",
        ownerId = "demo-user-001",
        totalXp = 33270,
        level = 7,
        memberCount = 8,
        rank = 47
    )
    private val _squadDetail = MutableStateFlow<SquadDetail?>(null)
    private val _squadRankings = MutableStateFlow<List<ArenaSquad>>(emptyList())
    private val leaderboardFlows = ConcurrentHashMap<LeaderboardScope, MutableStateFlow<LeaderboardPage>>()


    private val _home = MutableStateFlow(buildHomeState(false))
    private val _player = MutableStateFlow(player)
    private val _activities = MutableStateFlow<List<ArenaActivity>>(emptyList())
    private val _transactions = MutableStateFlow<List<XpTransaction>>(emptyList())
    private val _challenges = MutableStateFlow<List<ChallengeView>>(emptyList())
    private val _missions = MutableStateFlow<List<MissionView>>(emptyList())

    init {
      try {
        listOf("ch-daily-20", "ch-daily-50", "ch-week-300").forEach { id ->
            participations[id] = ChallengeParticipation(
                challengeId = id,
                userId = player.userId,
                joinedAt = Instant.now().minus(2, ChronoUnit.HOURS)
            )
        }
        // squad members
        listOf(
            Triple("demo-user-001", "phantom_rider", SquadRole.OWNER),
            Triple("u2", "nova_lex", SquadRole.ADMIN),
            Triple("u3", "kai_storm", SquadRole.MEMBER),
            Triple("u4", "luna_v", SquadRole.MEMBER),
            Triple("u5", "apex_zero", SquadRole.MEMBER),
            Triple("u6", "shadow_rim", SquadRole.MEMBER),
            Triple("u7", "volt_9", SquadRole.MEMBER),
            Triple("u8", "iris_flux", SquadRole.MEMBER)
        ).forEachIndexed { i, (id, name, role) ->
            squadMembers[id] = SquadMember(
                userId = id, username = name, role = role,
                contributionXp = if (id == player.userId) player.totalXp else (1200L + i * 340),
                level = if (id == player.userId) player.level else 6 + i
            )
        }
        seedSquadRankings()
        refreshLeaderboards()
        refreshSquadDetail()
        seedHistory()
        publish()
      } catch (t: Throwable) {
        android.util.Log.e("Arena", "LocalArenaRepository init failed", t)
      }
    }

    override fun observeHomeState() = _home.asStateFlow()
    override fun observePlayer() = _player.asStateFlow()
    override fun observeActivities() = _activities.asStateFlow()
    override fun observeXpTransactions() = _transactions.asStateFlow()
    override fun observeChallenges() = _challenges.asStateFlow()
    override fun observeMissions() = _missions.asStateFlow()

    override suspend fun refreshHome() {
        _home.update { it.copy(isLoading = true) }
        delay(350)
        publish()
    }

    override suspend fun logActivity(
        count: Int,
        type: ActivityType,
        source: ActivitySource,
        note: String?,
        performedAt: Instant
    ): Result<ArenaActivity> {
        val now = Instant.now()
        val today = LocalDate.now(zone)
        val todayActs = activities.values.filter {
            it.userId == player.userId && LocalDate.ofInstant(it.recordedAt, zone) == today
        }

        val draft = ArenaActivity(
            id = UUID.randomUUID().toString(),
            userId = player.userId,
            type = type,
            count = count,
            source = source,
            performedAt = performedAt,
            recordedAt = now,
            note = note?.take(200),
            xpAwarded = 0L,
            isVerified = false // camera recognition not implemented; never mark verified
        )

        val award = XpEngine.calculateActivityXp(draft, todayActs, now)
        if (award.rejected) {
            return Result.failure(IllegalArgumentException(award.rejectReason ?: "Rejected"))
        }

        val final = draft.copy(xpAwarded = award.xpAwarded)
        activities[final.id] = final
        addXp(award.xpAwarded, award.reason, activityId = final.id)
        publish()
        return Result.success(final)
    }

    override suspend fun joinChallenge(challengeId: String): Result<Unit> {
        val ch = challengeCatalog.find { it.id == challengeId }
            ?: return Result.failure(IllegalArgumentException("Challenge not found"))
        if (Instant.now().isAfter(ch.endAt)) {
            return Result.failure(IllegalArgumentException("Challenge has ended"))
        }
        if (participations.containsKey(challengeId)) {
            return Result.failure(IllegalArgumentException("Already joined"))
        }
        participations[challengeId] = ChallengeParticipation(
            challengeId = challengeId,
            userId = player.userId
        )
        publish()
        return Result.success(Unit)
    }

    override suspend fun claimChallengeReward(challengeId: String): Result<Long> {
        val ch = challengeCatalog.find { it.id == challengeId }
            ?: return Result.failure(IllegalArgumentException("Challenge not found"))
        val part = participations[challengeId]
            ?: return Result.failure(IllegalArgumentException("Not joined"))
        if (part.isClaimed) {
            return Result.failure(IllegalArgumentException("Already claimed"))
        }
        val progress = ChallengeEngine.computeChallengeProgress(ch, part, activities.values.toList())
        if (!ChallengeEngine.isChallengeComplete(progress, ch.targetCount)) {
            return Result.failure(IllegalArgumentException("Challenge not completed yet"))
        }
        val now = Instant.now()
        participations[challengeId] = part.copy(
            progress = progress,
            isCompleted = true,
            isClaimed = true,
            completedAt = part.completedAt ?: now,
            claimedAt = now
        )
        addXp(ch.xpReward, "challenge_${ch.id}", challengeId = ch.id)
        publish()
        return Result.success(ch.xpReward)
    }

    override suspend fun claimMissionReward(missionId: String): Result<Long> {
        val mission = missionCatalog.find { it.id == missionId }
            ?: return Result.failure(IllegalArgumentException("Mission not found"))
        val dateKey = ChallengeEngine.todayKey()
        val key = "$missionId|$dateKey"
        val prog = missionProgressMap[key]
            ?: return Result.failure(IllegalArgumentException("No progress today"))
        if (prog.isClaimed) {
            return Result.failure(IllegalArgumentException("Already claimed"))
        }
        if (!prog.isCompleted && prog.progress < mission.target) {
            return Result.failure(IllegalArgumentException("Mission not completed"))
        }
        missionProgressMap[key] = prog.copy(isClaimed = true, claimedAt = Instant.now(), isCompleted = true)
        addXp(mission.xpReward, "mission_$missionId", missionId = missionId)
        publish()
        return Result.success(mission.xpReward)
    }

    override suspend fun markLeaderboardVisited() {
        hasCheckedLeaderboardToday = true
        publish()
    }

    private fun addXp(
        amount: Long,
        reason: String,
        activityId: String? = null,
        challengeId: String? = null,
        missionId: String? = null
    ) {
        if (amount <= 0) return
        val now = Instant.now()
        transactions[UUID.randomUUID().toString()] = XpTransaction(
            id = UUID.randomUUID().toString(),
            userId = player.userId,
            amount = amount,
            reason = reason,
            activityId = activityId,
            challengeId = challengeId,
            missionId = missionId,
            createdAt = now
        )
        val newTotal = player.totalXp + amount
        val levelInfo = XpEngine.levelFromTotalXp(newTotal)
        val pushUpsDelta = if (activityId != null) activities[activityId]?.count?.toLong() ?: 0L else 0L
        player = player.copy(
            totalXp = newTotal,
            level = levelInfo.level,
            xpIntoCurrentLevel = levelInfo.xpIntoCurrentLevel,
            xpRequiredForNextLevel = levelInfo.xpRequiredForNextLevel,
            totalPushUps = player.totalPushUps + pushUpsDelta,
            updatedAt = now
        )
    }

    private fun publish() {
        val sortedActs = activities.values.sortedByDescending { it.recordedAt }
        val sortedTx = transactions.values.sortedByDescending { it.createdAt }

        val challengeViews = challengeCatalog.map { ch ->
            val part = participations[ch.id]
            val progress = ChallengeEngine.computeChallengeProgress(ch, part, sortedActs)
            val completed = ChallengeEngine.isChallengeComplete(progress, ch.targetCount)
            if (part != null && completed && !part.isCompleted) {
                participations[ch.id] = part.copy(progress = progress, isCompleted = true, completedAt = Instant.now())
            }
            val finalPart = participations[ch.id]
            ChallengeView(
                challenge = ch,
                participation = finalPart,
                progress = progress,
                isJoined = finalPart != null,
                isCompleted = finalPart?.isCompleted == true || completed,
                isClaimed = finalPart?.isClaimed == true
            )
        }

        val dateKey = ChallengeEngine.todayKey()
        val todayActs = sortedActs.filter {
            LocalDate.ofInstant(it.recordedAt, zone) == LocalDate.now(zone)
        }
        val missionViews = missionCatalog.map { m ->
            val current = ChallengeEngine.computeMissionProgress(m, todayActs, hasCheckedLeaderboardToday)
            val key = "${m.id}|$dateKey"
            var prog = missionProgressMap[key]
            if (prog == null) {
                prog = MissionProgress(m.id, player.userId, dateKey, current, current >= m.target)
                missionProgressMap[key] = prog
            } else if (current > prog.progress) {
                prog = prog.copy(progress = current, isCompleted = current >= m.target)
                missionProgressMap[key] = prog
            }
            MissionView(
                mission = m,
                progress = prog,
                current = prog?.progress ?: current,
                isCompleted = (prog?.progress ?: 0) >= m.target,
                isClaimed = prog?.isClaimed == true
            )
        }

        _player.value = player
        _activities.value = sortedActs
        _transactions.value = sortedTx
        _challenges.value = challengeViews
        _missions.value = missionViews
        _home.value = buildHomeState(false, challengeViews, missionViews)
        refreshLeaderboards()
        refreshSquadDetail()
    }

    private fun buildHomeState(
        isLoading: Boolean,
        challenges: List<ChallengeView> = _challenges.value,
        missions: List<MissionView> = _missions.value
    ): ArenaHomeState {
        val now = Instant.now()
        return ArenaHomeState(
            player = player,
            activeChallenges = challenges.filter { it.isJoined && !it.isClaimed }.take(3).map {
                ArenaChallengeSummary(
                    id = it.challenge.id,
                    title = it.challenge.title,
                    description = it.challenge.description,
                    difficulty = it.challenge.difficulty,
                    progress = it.progress,
                    target = it.challenge.targetCount,
                    endsAt = it.challenge.endAt,
                    xpReward = it.challenge.xpReward,
                    participantCount = it.challenge.participantCount,
                    isJoined = true,
                    isCompleted = it.isCompleted
                )
            },
            dailyMissions = missions.map {
                DailyMissionSummary(
                    id = it.mission.id,
                    title = it.mission.title,
                    description = it.mission.description,
                    progress = it.current,
                    target = it.mission.target,
                    xpReward = it.mission.xpReward,
                    isCompleted = it.isCompleted,
                    isClaimed = it.isClaimed
                )
            },
            recentAchievements = listOf(
                AchievementSummary("a1", "First Session", "Logged your first activity", "first_session", activities.isNotEmpty(), activities.values.minByOrNull { it.recordedAt }?.recordedAt, 20),
                AchievementSummary("a2", "Rising Player", "Reached level 10", "rising", player.level >= 10, if (player.level >= 10) player.updatedAt else null, 50)
            ),
            friendsActivity = listOf(
                FriendActivity("u2", "nova_lex", null, "completed 45 push-ups", now.minus(18, ChronoUnit.MINUTES)),
                FriendActivity("u3", "kai_storm", null, "joined Weekly Warrior", now.minus(2, ChronoUnit.HOURS))
            ),
            squad = SquadStatus("squad-alpha", "Night Operators", 8, 28450 + player.totalXp, 47, player.totalXp),
            isLoading = isLoading,
            error = null
        )
    }


    override fun observeLeaderboard(scope: LeaderboardScope): Flow<LeaderboardPage> {
        return leaderboardFlows.getOrPut(scope) {
            MutableStateFlow(buildLeaderboard(scope))
        }.asStateFlow()
    }

    override fun observeSquadDetail(): Flow<SquadDetail?> = _squadDetail.asStateFlow()
    override fun observeSquadRankings(): Flow<List<ArenaSquad>> = _squadRankings.asStateFlow()

    override suspend fun createSquad(name: String, description: String): Result<ArenaSquad> {
        if (name.isBlank() || name.length > 24)
            return Result.failure(IllegalArgumentException("Name must be 1–24 characters"))
        if (currentSquad != null)
            return Result.failure(IllegalArgumentException("Leave your current squad first"))
        val squad = ArenaSquad(
            id = "squad-${UUID.randomUUID().toString().take(8)}",
            name = name.trim(),
            description = description.take(120),
            ownerId = player.userId,
            totalXp = player.totalXp,
            level = 1,
            memberCount = 1
        )
        currentSquad = squad
        squadMembers.clear()
        squadMembers[player.userId] = SquadMember(
            userId = player.userId, username = player.username,
            role = SquadRole.OWNER, contributionXp = player.totalXp, level = player.level
        )
        player = player.copy(squadId = squad.id, squadName = squad.name)
        refreshSquadDetail()
        publish()
        return Result.success(squad)
    }

    override suspend fun leaveSquad(): Result<Unit> {
        val squad = currentSquad ?: return Result.failure(IllegalArgumentException("Not in a squad"))
        if (squad.ownerId == player.userId && squadMembers.size > 1)
            return Result.failure(IllegalArgumentException("Transfer ownership before leaving"))
        currentSquad = null
        squadMembers.clear()
        player = player.copy(squadId = null, squadName = null)
        refreshSquadDetail()
        publish()
        return Result.success(Unit)
    }

    private fun buildLeaderboard(scope: LeaderboardScope): LeaderboardPage {
        val snaps = LeaderboardEngine.demoPlayers(
            player.userId, player.username, player.level, player.totalXp, player.totalPushUps
        )
        return LeaderboardEngine.buildPage(scope, snaps, player.userId, limit = 30)
    }

    private fun refreshLeaderboards() {
        LeaderboardScope.entries.forEach { scope ->
            val flow = leaderboardFlows.getOrPut(scope) { MutableStateFlow(buildLeaderboard(scope)) }
            flow.value = buildLeaderboard(scope)
        }
    }

    private fun refreshSquadDetail() {
        val squad = currentSquad
        _squadDetail.value = if (squad == null) null else {
            val members = squadMembers.values.sortedWith(
                compareByDescending<SquadMember> { it.contributionXp }.thenBy { it.username }
            )
            SquadDetail(
                squad = squad.copy(
                    totalXp = members.sumOf { it.contributionXp },
                    memberCount = members.size
                ),
                members = members,
                currentUserRole = squadMembers[player.userId]?.role
            )
        }
    }

    private fun seedSquadRankings() {
        _squadRankings.value = listOf(
            ArenaSquad("s1", "Iron Circuit", ownerId = "x", totalXp = 91200, level = 14, memberCount = 12, rank = 1),
            ArenaSquad("s2", "Void Runners", ownerId = "x", totalXp = 87450, level = 13, memberCount = 10, rank = 2),
            ArenaSquad("s3", "Pulse Collective", ownerId = "x", totalXp = 80110, level = 12, memberCount = 15, rank = 3),
            ArenaSquad("s4", "Neon Legion", ownerId = "x", totalXp = 72300, level = 11, memberCount = 9, rank = 4),
            ArenaSquad("s5", "Night Operators", ownerId = "demo-user-001", totalXp = 33270, level = 7, memberCount = 8, rank = 47),
            ArenaSquad("s6", "Gravity Crew", ownerId = "x", totalXp = 29800, level = 6, memberCount = 7, rank = 61)
        )
    }

    private fun seedHistory() {
        val now = Instant.now()
        listOf(30 to 3L, 45 to 2L, 20 to 1L, 50 to 5L, 15 to 4L).forEachIndexed { idx, (reps, daysAgo) ->
            val when_ = now.minus(daysAgo, ChronoUnit.DAYS).minus(idx.toLong() * 90, ChronoUnit.MINUTES)
            val id = "seed-$idx"
            val act = ArenaActivity(
                id = id, userId = player.userId, count = reps, source = ActivitySource.MANUAL,
                performedAt = when_, recordedAt = when_, note = if (idx == 0) "Morning set" else null,
                xpAwarded = XpEngine.previewXpForCount(reps)
            )
            activities[id] = act
            transactions[id] = XpTransaction("tx-$id", player.userId, act.xpAwarded, "push_ups_$reps", id, createdAt = when_)
        }
    }
}
