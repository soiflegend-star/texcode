package com.texgen.music.texwave.arena.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.ArenaChallengeSummary
import com.texgen.music.texwave.arena.data.model.ArenaPlayer
import com.texgen.music.texwave.arena.data.model.DailyMissionSummary
import com.texgen.music.texwave.arena.data.model.FriendActivity
import com.texgen.music.texwave.arena.data.model.SquadStatus
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.ArenaShapes
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import com.texgen.music.texwave.arena.ui.theme.arenaGlow
import com.texgen.music.texwave.arena.ui.theme.arenaHeroCard
import com.texgen.music.texwave.arena.ui.theme.arenaRing
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/* ------------------------------------------------------------------ */
/*  Player identity header                                            */
/* ------------------------------------------------------------------ */

@Composable
fun ArenaPlayerHeader(
    player: ArenaPlayer,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(
                Modifier
                    .arenaHeroCard(24)
                    .padding(18.dp)
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(72.dp)
                .arenaGlow(ArenaColors.GlowCyan, 42.dp)
                .arenaRing(ArenaColors.Cyan, 2.5.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            ArenaColors.Violet.copy(alpha = 0.85f),
                            ArenaColors.Cyan.copy(alpha = 0.55f),
                            ArenaColors.Magenta.copy(alpha = 0.35f)
                        )
                    )
                )
        ) {
            Text(
                text = player.username.take(1).uppercase(),
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = player.displayName,
                color = ArenaColors.Text,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "@${player.username}",
                    color = ArenaColors.Muted,
                    fontSize = 13.sp
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "LV ${player.level}",
                    color = ArenaColors.Cyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier
                        .clip(ArenaShapes.Pill)
                        .background(ArenaColors.Cyan.copy(alpha = 0.12f))
                        .border(1.dp, ArenaColors.Cyan.copy(alpha = 0.35f), ArenaShapes.Pill)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
            Spacer(Modifier.height(10.dp))
            XpProgressBar(
                progress = player.progressFraction,
                current = player.xpIntoCurrentLevel,
                required = player.xpRequiredForNextLevel
            )
        }
    }
}

@Composable
fun XpProgressBar(
    progress: Float,
    current: Long,
    required: Long,
    modifier: Modifier = Modifier
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(1100),
        label = "xp"
    )
    Column(modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(ArenaShapes.Progress)
                .background(ArenaColors.Outline.copy(alpha = 0.55f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animated.coerceIn(0.02f, 1f))
                    .height(8.dp)
                    .clip(ArenaShapes.Progress)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                ArenaColors.Violet,
                                ArenaColors.Cyan,
                                ArenaColors.Cyan.copy(alpha = 0.85f)
                            )
                        )
                    )
            )
        }
        Spacer(Modifier.height(5.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "$current / $required XP",
                color = ArenaColors.Muted,
                fontSize = 11.sp,
                letterSpacing = 0.2.sp
            )
            Text(
                text = "${(animated * 100).toInt()}%",
                color = ArenaColors.Cyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Rank chips                                                        */
/* ------------------------------------------------------------------ */

@Composable
fun RankChip(
    label: String,
    rank: Int?,
    icon: ImageVector = Icons.Filled.MilitaryTech,
    highlight: Color = ArenaColors.Cyan
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(ArenaShapes.Pill)
            .background(highlight.copy(alpha = 0.12f))
            .border(1.dp, highlight.copy(alpha = 0.35f), ArenaShapes.Pill)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Icon(icon, contentDescription = null, tint = highlight, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Text(
            text = if (rank != null) "$label #$rank" else "$label —",
            color = ArenaColors.Text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/* ------------------------------------------------------------------ */
/*  Stat cards                                                        */
/* ------------------------------------------------------------------ */

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String? = null,
    icon: ImageVector,
    accent: Color = ArenaColors.Cyan,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .arenaGlassCard(16)
            .padding(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(10.dp))
        Text(value, color = ArenaColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(title, color = ArenaColors.Muted, fontSize = 12.sp)
        if (subtitle != null) {
            Text(subtitle, color = accent.copy(alpha = 0.8f), fontSize = 11.sp)
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Challenge card (compact)                                          */
/* ------------------------------------------------------------------ */

@Composable
fun ChallengeCard(
    challenge: ArenaChallengeSummary,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val progress = if (challenge.target > 0)
        (challenge.progress.toFloat() / challenge.target).coerceIn(0f, 1f)
    else 0f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .arenaGlassCard(16)
            .padding(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = challenge.title,
                color = ArenaColors.Text,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            DifficultyBadge(challenge.difficulty)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = challenge.description,
            color = ArenaColors.Muted,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .clip(ArenaShapes.Progress),
            color = ArenaColors.Violet,
            trackColor = ArenaColors.Outline.copy(alpha = 0.5f),
            strokeCap = StrokeCap.Round
        )
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "${challenge.progress} / ${challenge.target}",
                color = ArenaColors.Muted,
                fontSize = 11.sp
            )
            Text(
                "+${challenge.xpReward} XP",
                color = ArenaColors.Cyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun DifficultyBadge(difficulty: String) {
    val color = when (difficulty.lowercase()) {
        "easy" -> ArenaColors.Success
        "medium" -> ArenaColors.Warning
        "hard" -> ArenaColors.Magenta
        else -> ArenaColors.Violet
    }
    Text(
        text = difficulty.uppercase(),
        color = color,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(ArenaShapes.Pill)
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

/* ------------------------------------------------------------------ */
/*  Daily mission row                                                 */
/* ------------------------------------------------------------------ */

@Composable
fun MissionRow(mission: DailyMissionSummary) {
    val progress = if (mission.target > 0)
        (mission.progress.toFloat() / mission.target).coerceIn(0f, 1f)
    else 0f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(14)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(
                    if (mission.isCompleted) ArenaColors.Success.copy(alpha = 0.2f)
                    else ArenaColors.Violet.copy(alpha = 0.15f)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.Bolt,
                contentDescription = null,
                tint = if (mission.isCompleted) ArenaColors.Success else ArenaColors.Violet,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                mission.title,
                color = ArenaColors.Text,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .height(4.dp)
                    .clip(ArenaShapes.Progress),
                color = if (mission.isCompleted) ArenaColors.Success else ArenaColors.Cyan,
                trackColor = ArenaColors.Outline.copy(alpha = 0.5f),
                strokeCap = StrokeCap.Round
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            "+${mission.xpReward}",
            color = ArenaColors.Cyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/* ------------------------------------------------------------------ */
/*  Squad status card                                                 */
/* ------------------------------------------------------------------ */

@Composable
fun SquadStatusCard(squad: SquadStatus) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(16)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(ArenaColors.Violet.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Groups, null, tint = ArenaColors.Violet)
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(squad.name, color = ArenaColors.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "${squad.memberCount} members  ·  ${squad.totalXp} XP",
                color = ArenaColors.Muted,
                fontSize = 12.sp
            )
        }
        if (squad.rank != null) {
            RankChip("Squad", squad.rank, Icons.Filled.TrendingUp, ArenaColors.Violet)
        }
    }
}

/* ------------------------------------------------------------------ */
/*  Friend activity item                                              */
/* ------------------------------------------------------------------ */

@Composable
fun FriendActivityItem(item: FriendActivity) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(ArenaColors.SurfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            Text(
                item.username.take(1).uppercase(),
                color = ArenaColors.Cyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                "${item.username} ${item.action}",
                color = ArenaColors.Text,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                relativeTime(item.timestamp),
                color = ArenaColors.Muted,
                fontSize = 11.sp
            )
        }
    }
}

private fun relativeTime(instant: Instant): String {
    val duration = Duration.between(instant, Instant.now())
    return when {
        duration.toMinutes() < 1 -> "just now"
        duration.toMinutes() < 60 -> "${duration.toMinutes()}m ago"
        duration.toHours() < 24 -> "${duration.toHours()}h ago"
        else -> DateTimeFormatter.ofPattern("MMM d")
            .withZone(ZoneId.systemDefault())
            .format(instant)
    }
}

/* ------------------------------------------------------------------ */
/*  Section header                                                    */
/* ------------------------------------------------------------------ */

@Composable
fun SectionHeader(
    title: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(16.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(ArenaColors.Cyan, ArenaColors.Violet)
                        )
                    )
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = title,
                color = ArenaColors.Text,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.2.sp
            )
        }
        if (actionLabel != null && onAction != null) {
            Text(
                text = actionLabel,
                color = ArenaColors.Cyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.3.sp,
                modifier = Modifier
                    .clip(ArenaShapes.Pill)
                    .background(ArenaColors.Cyan.copy(alpha = 0.12f))
                    .border(1.dp, ArenaColors.Cyan.copy(alpha = 0.28f), ArenaShapes.Pill)
                    .clickable(onClick = onAction)
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            )
        }
    }
}
