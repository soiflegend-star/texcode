package com.texgen.music.texwave.arena.ui.history

import com.texgen.music.texwave.arena.data.repository.ArenaModule
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.ActivitySource
import com.texgen.music.texwave.arena.data.model.ArenaActivity
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun ActivityHistoryScreen(
    repository: ArenaRepository = ArenaModule.repository
) {
    val activities by repository.observeActivities().collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg)
    ) {
        Text(
            text = "ACTIVITY HISTORY",
            color = ArenaColors.Cyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )

        if (activities.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No sessions yet. Log your first set.", color = ArenaColors.Muted)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(activities, key = { it.id }) { activity ->
                    ActivityRow(activity)
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun ActivityRow(activity: ArenaActivity) {
    val formatter = DateTimeFormatter.ofPattern("MMM d, HH:mm")
        .withZone(ZoneId.systemDefault())

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(14)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(ArenaColors.Violet.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.FitnessCenter,
                contentDescription = null,
                tint = ArenaColors.Violet,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${activity.count} push-ups",
                    color = ArenaColors.Text,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (activity.isVerified) {
                    Spacer(Modifier.width(6.dp))
                    Icon(
                        Icons.Filled.Verified,
                        contentDescription = "Verified",
                        tint = ArenaColors.Cyan,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
            Text(
                formatter.format(activity.recordedAt),
                color = ArenaColors.Muted,
                fontSize = 12.sp
            )
            if (!activity.note.isNullOrBlank()) {
                Text(
                    activity.note,
                    color = ArenaColors.Muted,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
            Text(
                sourceLabel(activity.source),
                color = ArenaColors.Muted.copy(alpha = 0.7f),
                fontSize = 11.sp
            )
        }
        Text(
            "+${activity.xpAwarded} XP",
            color = ArenaColors.Cyan,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

private fun sourceLabel(source: ActivitySource): String = when (source) {
    ActivitySource.MANUAL -> "Self-reported"
    ActivitySource.CAMERA_ASSISTED -> "Camera-assisted"
    ActivitySource.IMPORT -> "Imported"
}
