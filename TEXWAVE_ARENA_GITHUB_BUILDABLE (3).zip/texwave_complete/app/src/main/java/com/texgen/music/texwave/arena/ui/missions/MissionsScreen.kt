package com.texgen.music.texwave.arena.ui.missions

import com.texgen.music.texwave.arena.data.repository.ArenaModule
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.data.repository.MissionView
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.ArenaShapes
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import kotlinx.coroutines.launch

@Composable
fun MissionsScreen(
    repository: ArenaRepository = ArenaModule.repository
) {
    val missions by repository.observeMissions().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var busyId by remember { mutableStateOf<String?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg)
    ) {
        Text(
            "DAILY MISSIONS",
            color = ArenaColors.Cyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
        Text(
            "Resets at midnight (device timezone). Rest-day friendly options included.",
            color = ArenaColors.Muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        if (toast != null) {
            Text(
                toast!!,
                color = ArenaColors.Success,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(missions, key = { it.mission.id }) { view ->
                MissionCard(
                    view = view,
                    isBusy = busyId == view.mission.id,
                    onClaim = {
                        busyId = view.mission.id
                        scope.launch {
                            repository.claimMissionReward(view.mission.id)
                                .onSuccess { xp -> toast = "Claimed +$xp XP" }
                                .onFailure { toast = it.message }
                            busyId = null
                        }
                    }
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MissionCard(
    view: MissionView,
    isBusy: Boolean,
    onClaim: () -> Unit
) {
    val m = view.mission
    val fraction = if (m.target > 0) (view.current.toFloat() / m.target).coerceIn(0f, 1f) else 0f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(16)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(
                    if (view.isCompleted) ArenaColors.Success.copy(alpha = 0.2f)
                    else ArenaColors.Violet.copy(alpha = 0.15f)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (view.isCompleted) Icons.Filled.CheckCircle else Icons.Filled.Bolt,
                contentDescription = null,
                tint = if (view.isCompleted) ArenaColors.Success else ArenaColors.Violet,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(m.title, color = ArenaColors.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(m.description, color = ArenaColors.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(ArenaShapes.Progress),
                color = if (view.isCompleted) ArenaColors.Success else ArenaColors.Cyan,
                trackColor = ArenaColors.Outline.copy(alpha = 0.5f),
                strokeCap = StrokeCap.Round
            )
            Spacer(Modifier.height(4.dp))
            Text("${view.current} / ${m.target}", color = ArenaColors.Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.width(10.dp))
        when {
            view.isClaimed -> {
                Text("Done", color = ArenaColors.Success, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            view.isCompleted -> {
                Button(
                    onClick = onClaim,
                    enabled = !isBusy,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ArenaColors.Cyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    if (isBusy) {
                        CircularProgressIndicator(Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                    } else {
                        Text("+${m.xpReward}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
            else -> {
                Text("+${m.xpReward}", color = ArenaColors.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
