package com.texgen.music.texwave.arena.ui.logging

import com.texgen.music.texwave.arena.data.repository.ArenaModule
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.ActivitySource
import com.texgen.music.texwave.arena.data.model.ActivityType
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.domain.XpEngine
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import kotlinx.coroutines.launch

/**
 * Manual activity logging screen.
 * Clearly labelled as self-reported. Camera verification is a future extension.
 */
@Composable
fun LogActivityScreen(
    onClose: () -> Unit,
    onLogged: () -> Unit = {},
    repository: ArenaRepository = ArenaModule.repository
) {
    var countText by remember { mutableStateOf("20") }
    var note by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var successXp by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    val count = countText.toIntOrNull() ?: 0
    val previewXp = if (count in 1..XpEngine.MAX_REPS_PER_SESSION)
        XpEngine.previewXpForCount(count) else 0L

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Log Session",
                color = ArenaColors.Text,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, "Close", tint = ArenaColors.Muted)
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "Self-reported push-ups. Not independently verified.",
            color = ArenaColors.Muted,
            fontSize = 13.sp
        )

        Spacer(Modifier.height(24.dp))

        // Big number input
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .arenaGlassCard(20)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Filled.FitnessCenter,
                contentDescription = null,
                tint = ArenaColors.Cyan,
                modifier = Modifier.size(32.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text("Push-ups completed", color = ArenaColors.Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = countText,
                onValueChange = {
                    if (it.length <= 3 && it.all { c -> c.isDigit() }) {
                        countText = it
                        error = null
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = ArenaColors.Text
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ArenaColors.Cyan,
                    unfocusedBorderColor = ArenaColors.Outline,
                    focusedTextColor = ArenaColors.Text,
                    unfocusedTextColor = ArenaColors.Text,
                    cursorColor = ArenaColors.Cyan
                ),
                modifier = Modifier.fillMaxWidth(0.5f)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = if (previewXp > 0) "+$previewXp XP (estimate)" else "Enter 1–${XpEngine.MAX_REPS_PER_SESSION}",
                color = ArenaColors.Cyan,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = note,
            onValueChange = { if (it.length <= 120) note = it },
            label = { Text("Optional note") },
            placeholder = { Text("e.g. Morning set, felt strong") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ArenaColors.Cyan,
                unfocusedBorderColor = ArenaColors.Outline,
                focusedLabelColor = ArenaColors.Cyan,
                unfocusedLabelColor = ArenaColors.Muted,
                focusedTextColor = ArenaColors.Text,
                unfocusedTextColor = ArenaColors.Text,
                cursorColor = ArenaColors.Cyan
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        // Soft limits notice
        Text(
            "Soft limits: max ${XpEngine.MAX_REPS_PER_SESSION} reps / session, " +
                "${XpEngine.MAX_SESSIONS_PER_DAY} sessions / day, " +
                "${XpEngine.MAX_DAILY_XP_FROM_ACTIVITY} XP / day from activity.",
            color = ArenaColors.Muted,
            fontSize = 11.sp,
            lineHeight = 16.sp
        )

        if (error != null) {
            Spacer(Modifier.height(12.dp))
            Text(error!!, color = ArenaColors.Magenta, fontSize = 13.sp)
        }

        if (successXp > 0) {
            Spacer(Modifier.height(12.dp))
            Text(
                "Logged! +$successXp XP awarded",
                color = ArenaColors.Success,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(Modifier.height(28.dp))

        Button(
            onClick = {
                if (count !in 1..XpEngine.MAX_REPS_PER_SESSION) {
                    error = "Enter a number between 1 and ${XpEngine.MAX_REPS_PER_SESSION}"
                    return@Button
                }
                isSubmitting = true
                error = null
                scope.launch {
                    val result = repository.logActivity(
                        count = count,
                        type = ActivityType.PUSH_UPS,
                        source = ActivitySource.MANUAL,
                        note = note.ifBlank { null }
                    )
                    isSubmitting = false
                    result.fold(
                        onSuccess = {
                            successXp = it.xpAwarded.toInt()
                            onLogged()
                        },
                        onFailure = {
                            error = it.message ?: "Could not log session"
                        }
                    )
                }
            },
            enabled = !isSubmitting,
            colors = ButtonDefaults.buttonColors(
                containerColor = ArenaColors.Cyan,
                contentColor = Color.Black
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            if (isSubmitting) {
                CircularProgressIndicator(
                    color = Color.Black,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(22.dp)
                )
            } else {
                Text("Submit Session", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
    }
}
