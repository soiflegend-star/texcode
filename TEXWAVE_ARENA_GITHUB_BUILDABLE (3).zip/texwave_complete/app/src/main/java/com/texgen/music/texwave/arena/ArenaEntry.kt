package com.texgen.music.texwave.arena

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.repository.ArenaModule
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.ui.navigation.ArenaRoot
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Arena entry — **staged boot** so the host does not compose everything at once.
 *
 * Phase 0: splash / spinner only
 * Phase 1: ensure repository (background)
 * Phase 2: mount [ArenaRoot] (Home only via NavHost start destination)
 * Phase 3: soft refreshHome (does not block UI)
 */
@Composable
fun ArenaEntry(
    modifier: Modifier = Modifier,
    onClose: (() -> Unit)? = null,
    repository: ArenaRepository? = null
) {
    var phase by remember { mutableIntStateOf(0) }
    var bootError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(repository) {
        bootError = null
        phase = 0
        // Let the first frame paint (avoids burst with SideNav animation)
        delay(48)

        try {
            withContext(Dispatchers.Default) {
                if (repository != null) {
                    ArenaModule.init(repository)
                } else {
                    runCatching { ArenaModule.initLocalDemo() }
                }
            }
            phase = 1
            delay(32)
            phase = 2
            // Refresh after Home is allowed to compose — never block first paint
            delay(120)
            runCatching {
                withContext(Dispatchers.IO) {
                    ArenaModule.repository.refreshHome()
                }
            }.onFailure {
                // Non-fatal: Home can still show demo/last state
                android.util.Log.w("Arena", "refreshHome: ${it.message}")
            }
            phase = 3
        } catch (t: Throwable) {
            bootError = t.message ?: t::class.java.simpleName
            android.util.Log.e("Arena", "boot failed", t)
        }
    }

    when {
        bootError != null -> {
            Box(
                modifier
                    .fillMaxSize()
                    .background(Color(0xFF03050A))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Arena failed to open", color = ArenaColors.Magenta, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(bootError ?: "", color = ArenaColors.Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "Retry",
                        color = ArenaColors.Cyan,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(ArenaColors.Cyan.copy(alpha = 0.15f))
                            .clickable {
                                bootError = null
                                phase = 0
                            }
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                    )
                    if (onClose != null) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Close",
                            color = ArenaColors.Text,
                            modifier = Modifier.clickable { onClose() }.padding(12.dp)
                        )
                    }
                }
            }
        }
        phase < 2 -> {
            Box(
                modifier
                    .fillMaxSize()
                    .background(Color(0xFF03050A)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = ArenaColors.Cyan)
                    Spacer(Modifier.height(16.dp))
                    Text("Entering Arena…", color = ArenaColors.Muted, fontSize = 13.sp)
                }
            }
        }
        else -> {
            // Only now mount navigation graph (startDestination = Home only)
            ArenaRoot(
                modifier = modifier,
                onClose = onClose
            )
        }
    }
}
