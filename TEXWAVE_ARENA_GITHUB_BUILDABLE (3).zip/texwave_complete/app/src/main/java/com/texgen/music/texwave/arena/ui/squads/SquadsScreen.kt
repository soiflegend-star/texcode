package com.texgen.music.texwave.arena.ui.squads

import com.texgen.music.texwave.arena.data.repository.ArenaModule
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.ArenaSquad
import com.texgen.music.texwave.arena.data.model.SquadDetail
import com.texgen.music.texwave.arena.data.model.SquadMember
import com.texgen.music.texwave.arena.data.model.SquadRole
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import kotlinx.coroutines.launch

@Composable
fun SquadsScreen(
    repository: ArenaRepository = ArenaModule.repository
) {
    val detail by repository.observeSquadDetail().collectAsState(initial = null)
    val rankings by repository.observeSquadRankings().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var showCreate by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg)
    ) {
        Text(
            "SQUADS",
            color = ArenaColors.Cyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
        if (message != null) {
            Text(message!!, color = ArenaColors.Cyan, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (detail != null) {
                item { YourSquadCard(detail!!) }
                item {
                    Text("Members", color = ArenaColors.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
                items(detail!!.members, key = { it.userId }) { member ->
                    MemberRow(member)
                }
                item {
                    TextButton(onClick = {
                        scope.launch {
                            repository.leaveSquad()
                                .onSuccess { message = "Left squad" }
                                .onFailure { message = it.message }
                        }
                    }) {
                        Text("Leave squad", color = ArenaColors.Magenta)
                    }
                }
            } else {
                item {
                    Column(Modifier.arenaGlassCard(16).padding(16.dp)) {
                        Text("You're not in a squad", color = ArenaColors.Text, fontWeight = FontWeight.Medium)
                        Text("Create one or wait for an invite (invites arrive in a later pass).", color = ArenaColors.Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { showCreate = true },
                            colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Violet)
                        ) {
                            Text("Create squad")
                        }
                    }
                }
                if (showCreate) {
                    item {
                        CreateSquadForm(
                            onCancel = { showCreate = false },
                            onCreate = { name, desc ->
                                scope.launch {
                                    repository.createSquad(name, desc)
                                        .onSuccess {
                                            message = "Squad created"
                                            showCreate = false
                                        }
                                        .onFailure { message = it.message }
                                }
                            }
                        )
                    }
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                Text("Squad Rankings", color = ArenaColors.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            items(rankings, key = { it.id }) { squad ->
                SquadRankRow(squad)
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun YourSquadCard(detail: SquadDetail) {
    val s = detail.squad
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(18)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ArenaColors.Violet.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Groups, null, tint = ArenaColors.Violet)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.name, color = ArenaColors.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(s.description, color = ArenaColors.Muted, fontSize = 12.sp, maxLines = 2)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Meta("Members", "${s.memberCount}")
            Meta("Total XP", format(s.totalXp))
            Meta("Level", "${s.level}")
            Meta("Rank", s.rank?.let { "#$it" } ?: "—")
        }
        if (detail.currentUserRole != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                "Your role: ${detail.currentUserRole.name.lowercase().replaceFirstChar { it.uppercase() }}",
                color = ArenaColors.Cyan,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun Meta(label: String, value: String) {
    Column {
        Text(value, color = ArenaColors.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(label, color = ArenaColors.Muted, fontSize = 11.sp)
    }
}

@Composable
private fun MemberRow(member: SquadMember) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(12)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(ArenaColors.SurfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            Text(member.username.take(1).uppercase(), color = ArenaColors.Cyan, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(member.username, color = ArenaColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                if (member.role == SquadRole.OWNER) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Filled.Star, null, tint = ArenaColors.RankGold, modifier = Modifier.size(14.dp))
                }
            }
            Text(
                member.role.name.lowercase().replaceFirstChar { it.uppercase() } + " · Lv ${member.level}",
                color = ArenaColors.Muted,
                fontSize = 12.sp
            )
        }
        Text(format(member.contributionXp) + " XP", color = ArenaColors.Cyan, fontSize = 13.sp)
    }
}

@Composable
private fun SquadRankRow(squad: ArenaSquad) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(12)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "#${squad.rank ?: "—"}",
            color = ArenaColors.Muted,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.width(40.dp)
        )
        Column(Modifier.weight(1f)) {
            Text(squad.name, color = ArenaColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text("${squad.memberCount} members · Lv ${squad.level}", color = ArenaColors.Muted, fontSize = 12.sp)
        }
        Text(format(squad.totalXp), color = ArenaColors.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CreateSquadForm(onCancel: () -> Unit, onCreate: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    Column(Modifier.arenaGlassCard(16).padding(16.dp)) {
        Text("Create squad", color = ArenaColors.Text, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { if (it.length <= 24) name = it },
            label = { Text("Name") },
            singleLine = true,
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = desc,
            onValueChange = { if (it.length <= 120) desc = it },
            label = { Text("Description") },
            colors = fieldColors(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = onCancel) { Text("Cancel", color = ArenaColors.Muted) }
            Button(
                onClick = { onCreate(name, desc) },
                colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Cyan, contentColor = Color.Black)
            ) { Text("Create") }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = ArenaColors.Cyan,
    unfocusedBorderColor = ArenaColors.Outline,
    focusedLabelColor = ArenaColors.Cyan,
    unfocusedLabelColor = ArenaColors.Muted,
    focusedTextColor = ArenaColors.Text,
    unfocusedTextColor = ArenaColors.Text,
    cursorColor = ArenaColors.Cyan
)

private fun format(v: Long): String = when {
    v >= 1_000_000 -> String.format("%.1fM", v / 1_000_000.0)
    v >= 1_000 -> String.format("%.1fK", v / 1_000.0)
    else -> v.toString()
}
