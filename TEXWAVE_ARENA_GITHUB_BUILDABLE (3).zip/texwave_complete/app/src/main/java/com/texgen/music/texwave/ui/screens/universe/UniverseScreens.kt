package com.texgen.music.texwave.ui.screens.universe

import com.texgen.music.texwave.ui.theme.Tx
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Nightlife
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.TravelExplore
import androidx.compose.material.icons.rounded.WbTwilight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.drawText
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import com.texgen.music.texwave.ui.components.MajesticEnergyField
import com.texgen.music.texwave.ui.components.holographicBorder
import com.texgen.music.texwave.ui.components.neonBreath
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val UBlack = Color(0xFF000000)
private val UCyan = Tx.Accent2
private val UViolet = Tx.Accent
private val UPink = Tx.Accent3
private val UMuted = Color(0xFF7A829E)
private val UText = Color(0xFFF0ECFF)

enum class UniverseDest {
    Hub,
    MemoryCinema,
    EmotionalGps,
    TwinRoom,
    SharedPulse,
    SongAutopsy,
    TimeCapsule,
    Sanctuary,
    WorldFrequency,
    IdentitySoundtrack,
    RepairSession,
    DreamMode,
    ResonanceLab,
    // New ritual screens
    EmotionalWeather,
    MemoryAnchors,
    GhostQueue,
    LivingSongs,
    TheUnplayed,
}

data class UniverseItem(
    val dest: UniverseDest,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val session: String,
)

val UniverseCatalog = listOf(
    UniverseItem(UniverseDest.EmotionalGps, "Mood map", "Pick a feeling · get a path of songs", Icons.Rounded.Map, UCyan, "HOME"),
    UniverseItem(UniverseDest.MemoryCinema, "Memory story", "Your most-played songs as chapters", Icons.Rounded.Movie, UViolet, "PHANTOM"),
    UniverseItem(UniverseDest.TwinRoom, "Quiet room", "A calm space that stays with the music", Icons.Rounded.Psychology, UPink, "PHANTOM"),
    UniverseItem(UniverseDest.SharedPulse, "Shared mix", "Build a queue with someone else", Icons.Rounded.Share, UCyan, "CHAT"),
    UniverseItem(UniverseDest.SongAutopsy, "Song details", "See what this track means for you", Icons.Rounded.Science, UViolet, "PLAYER"),
    UniverseItem(UniverseDest.TimeCapsule, "Time capsule", "Save a song for your future self", Icons.Rounded.Timer, UPink, "CHAT"),
    UniverseItem(UniverseDest.Sanctuary, "Simple shuffle", "Only rules you set · no suggestions", Icons.Rounded.Lock, UCyan, "LIBRARY"),
    UniverseItem(UniverseDest.WorldFrequency, "World mood", "Ride a soft global feeling wave", Icons.Rounded.Public, UViolet, "HOME"),
    UniverseItem(UniverseDest.IdentitySoundtrack, "Your soundtrack", "Songs for different versions of you", Icons.Rounded.AutoAwesome, UPink, "PHANTOM"),
    UniverseItem(UniverseDest.RepairSession, "Make peace", "A short listening path to cool down", Icons.Rounded.SelfImprovement, UCyan, "CHAT"),
    UniverseItem(UniverseDest.DreamMode, "Morning start", "A gentle queue for waking up", Icons.Rounded.WbTwilight, UViolet, "ALARM"),
    UniverseItem(UniverseDest.ResonanceLab, "How people listen", "See patterns from your community", Icons.Rounded.TravelExplore, UPink, "LIBRARY"),
)

/** True when a universe screen is shown as a Library session (no own back bar / status padding). */
val LocalUniverseEmbedded = compositionLocalOf { false }

@Composable
fun UniverseShell(
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    content: @Composable () -> Unit,
) {
    val embedded = LocalUniverseEmbedded.current
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF07060F), Color(0xFF0C0A18), Color(0xFF05040C))))) {
        Column(Modifier.fillMaxSize().then(if (embedded) Modifier else Modifier.statusBarsPadding())) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (embedded) Spacer(Modifier.width(12.dp)) else IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, null, tint = UText, modifier = Modifier.neonBreath())
                }
                Column(Modifier.weight(1f).appear(40)) {
                    Text(title, color = UText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, color = UMuted, fontSize = 11.sp)
                }
            }
            content()
        }
    }
}

@Composable
fun UniverseHubScreen(
    onOpen: (UniverseDest) -> Unit,
    onBack: (() -> Unit)? = null,
) {
    com.texgen.music.texwave.ui.ref.CockpitGuide(com.texgen.music.texwave.ui.ref.Guides.hub) {
    Box(Modifier.fillMaxSize().background(UBlack).sonicAtmosphere()) {
    MajesticEnergyField(Modifier.fillMaxSize())
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, null, tint = UText)
            }
        }
        Text(
            "SPECIAL SCREENS",
            color = UCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            modifier = Modifier.appear(0),
        )
        Text(
            "Explore your music in new ways",
            color = UText,
            fontSize = 22.sp,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(top = 6.dp).appear(40),
        )
        Text(
            "Mood, memory, and sharing — all from your own library",
            color = UMuted,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 18.dp).appear(60),
        )
        UniverseCatalog.forEachIndexed { i, item ->
            HubCard(item, i) { onOpen(item.dest) }
        }
        Spacer(Modifier.height(32.dp))
    }
    }
    }
}

@Composable
private fun HubCard(item: UniverseItem, index: Int, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(item.accent.copy(alpha = 0.28f), Color(0xFF0A0C14), Color(0xFF05060A)),
                )
            )
            .holographicBorder(22f, listOf(item.accent, UCyan, UViolet, item.accent))
            .pressable(0.97f, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 16.dp)
            .appear(80 + index * 50),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(item.accent, UViolet))),
            contentAlignment = Alignment.Center,
        ) {
            Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Column(Modifier.padding(start = 14.dp).weight(1f)) {
            Text(item.title, color = UText, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(item.subtitle, color = UMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Text("Open", color = item.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/* -------------------- 1 Emotional GPS -------------------- */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmotionalGpsScreen(
    lib: LibraryState,
    onPlay: (List<Song>, Int) -> Unit,
    onBack: () -> Unit,
) {
    var dest by remember { mutableStateOf("Calm") }
    val destinations = listOf("Calm", "Focus", "Courage", "Release", "Joy", "Night")
    val route = remember(dest, lib.songs) {
        val keys = when (dest) {
            "Calm" -> listOf("calm", "soft", "piano", "ambient", "sleep", "rain")
            "Focus" -> listOf("focus", "study", "work", "instrumental", "lofi")
            "Courage" -> listOf("power", "rise", "strong", "anthem", "run")
            "Release" -> listOf("cry", "sad", "hurt", "alone", "broken")
            "Joy" -> listOf("happy", "dance", "party", "love", "summer")
            else -> listOf("night", "dark", "moon", "chill")
        }
        lib.songs.filter { s ->
            val blob = (s.title + s.album + s.artist).lowercase()
            keys.any { it in blob }
        }.ifEmpty { lib.songs.shuffled().take(24) }.take(24)
    }
    UniverseShell("Mood map", "Tap a feeling · we build a short path from your songs", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            GpsRadar(destinations, dest) { dest = it }
            Spacer(Modifier.height(16.dp))
            Text("How do you want to feel?", color = UMuted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            @OptIn(ExperimentalLayoutApi::class)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                destinations.forEach { d ->
                    val on = d == dest
                    Text(
                        d,
                        color = if (on) Color.White else UMuted,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (on) Brush.horizontalGradient(listOf(UCyan, UViolet)) else Brush.horizontalGradient(listOf(Color(0xFF12141C), Color(0xFF12141C))))
                            .pressable(0.94f) { dest = d }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Suggested path · ${route.size} songs", color = UText, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            route.take(10).forEachIndexed { i, s ->
                SessionSongRow(
                    title = s.title,
                    subtitle = s.artist,
                    index = i,
                    accent = UCyan,
                    onClick = { onPlay(route, i) },
                )
            }
            Spacer(Modifier.height(16.dp))
            PremiumButton("Play this path") {
                if (route.isNotEmpty()) onPlay(route, 0)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
@Composable
private fun GpsRadar(destinations: List<String>, selected: String, onSelect: (String) -> Unit) {
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "gps")
    val sweep by t.animateFloat(
        0f, 360f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(2800, easing = androidx.compose.animation.core.LinearEasing)),
        label = "sweep",
    )
    val ping by t.animateFloat(
        0f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(1800)),
        label = "ping",
    )
    val measurer = androidx.compose.ui.text.rememberTextMeasurer()
    Box(
        Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(28.dp))
            .background(Brush.radialGradient(listOf(Color(0xFF0E2A3A), Color(0xFF07101F), Color(0xFF05040C))))
            .border(1.dp, Color(0x5519D3F2), RoundedCornerShape(24.dp)),
    ) {
        androidx.compose.foundation.Canvas(
            Modifier.fillMaxSize().pointerInput(destinations) {
                detectTapGestures { tap ->
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val r = minOf(size.width, size.height) * 0.38f
                    var best: String? = null; var bd = Float.MAX_VALUE
                    destinations.forEachIndexed { i, d ->
                        val a = Math.toRadians((i * 360.0 / destinations.size) - 90.0)
                        val p = Offset(c.x + (kotlin.math.cos(a) * r).toFloat(), c.y + (kotlin.math.sin(a) * r).toFloat())
                        val dist = (p - tap).getDistance()
                        if (dist < bd) { bd = dist; best = d }
                    }
                    if (bd < 96.dp.toPx()) best?.let(onSelect)
                }
            },
        ) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val r = minOf(size.width, size.height) * 0.42f
            for (k in 1..4) drawCircle(Color(0x3319D3F2), r * k / 4f, c, style = Stroke(1.dp.toPx()))
            drawLine(Color(0x2219D3F2), Offset(c.x - r, c.y), Offset(c.x + r, c.y), 1.dp.toPx())
            drawLine(Color(0x2219D3F2), Offset(c.x, c.y - r), Offset(c.x, c.y + r), 1.dp.toPx())
            // sweep beam
            rotate(sweep, c) {
                drawArc(
                    Brush.sweepGradient(listOf(Color.Transparent, Color(0x5519D3F2)), c),
                    startAngle = -60f, sweepAngle = 60f, useCenter = true,
                    topLeft = Offset(c.x - r, c.y - r), size = androidx.compose.ui.geometry.Size(r * 2, r * 2),
                )
                drawLine(Color(0xCC19D3F2), c, Offset(c.x + r, c.y), 2.dp.toPx())
            }
            // you-are-here
            drawCircle(Color.White, 4.dp.toPx(), c)
            drawCircle(Color(0x6619D3F2), 4.dp.toPx() + 16.dp.toPx() * ping, c, style = Stroke(1.5.dp.toPx()))
            // destination blips
            destinations.forEachIndexed { i, d ->
                val a = Math.toRadians((i * 360.0 / destinations.size) - 90.0)
                val p = Offset(c.x + (kotlin.math.cos(a) * r * 0.9f).toFloat(), c.y + (kotlin.math.sin(a) * r * 0.9f).toFloat())
                val on = d == selected
                if (on) {
                    drawLine(Color(0x88FF58D8), c, p, 1.5.dp.toPx())
                    drawCircle(Color(0x44FF58D8), 14.dp.toPx() + 10.dp.toPx() * ping, p)
                }
                drawCircle(if (on) Color(0xFFFF58D8) else Color(0xFF19D3F2), if (on) 7.dp.toPx() else 5.dp.toPx(), p)
                val lay = measurer.measure(d, androidx.compose.ui.text.TextStyle(color = if (on) Color.White else Color(0xFF9FB4E8), fontSize = 11.sp))
                drawText(lay, topLeft = Offset(p.x - lay.size.width / 2f, p.y + 9.dp.toPx()))
            }
        }
        Text(
            "You · right now", color = Color(0xFF19D3F2), fontSize = 11.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.TopStart).padding(14.dp),
        )
        Text(
            "Going toward  " + selected, color = Color(0xFFFF58D8), fontSize = 11.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp),
        )
    }
}

/* -------------------- 2 Memory Cinema -------------------- */
@Composable
fun MemoryCinemaScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    // Chapters from play intensity — feels like a story, not a control panel
    val chapters = remember(lib.songs, lib.playCounts, lib.liked) {
        val ranked = lib.songs.sortedByDescending {
            (lib.playCounts[it.id] ?: 0) + if (it.id in lib.liked) 20 else 0
        }
        listOf(
            "Opening" to ranked.take(8),
            "The heavy part" to ranked.drop(8).take(8),
            "Late nights" to ranked.filter {
                val t = (it.title + it.album).lowercase()
                listOf("night", "sleep", "dream", "rain", "soft", "slow").any { k -> k in t }
            }.ifEmpty { ranked.shuffled().take(8) }.take(8),
            "Encore" to ranked.filter { it.id in lib.liked }.ifEmpty { ranked.takeLast(8) }.take(8),
        ).map { (name, tracks) -> name to tracks.distinctBy { it.id } }
    }
    var active by remember { mutableIntStateOf(0) }
    val reel = chapters.getOrNull(active)?.second.orEmpty()

    UniverseShell("Memory Cinema", "Your year in four short scenes", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text(
                "Four scenes made from what you actually play. Pick one and press play — it’s your story, not a gadget.",
                color = UMuted,
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(16.dp))
            chapters.forEachIndexed { i, (name, tracks) ->
                val on = i == active
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (on) Color(0x28A37CFF) else Color(0x14FFFFFF))
                        .border(1.dp, if (on) UViolet.copy(alpha = 0.55f) else Color(0x22FFFFFF), RoundedCornerShape(18.dp))
                        .clickable { active = i }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "${i + 1}",
                        color = if (on) UCyan else UMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(end = 12.dp),
                    )
                    Column(Modifier.weight(1f)) {
                        Text(name, color = UText, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "${tracks.size} tracks in this scene",
                            color = UMuted,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Scene preview", color = UMuted, fontSize = 11.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            reel.take(6).forEach { s ->
                Text("· ${s.title}", color = UText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 2.dp))
            }
            if (reel.isEmpty()) {
                Text("Play a few songs first — Cinema fills from your history.", color = UMuted, fontSize = 13.sp)
            }
            Spacer(Modifier.height(16.dp))
            PremiumButton("Play this scene") {
                if (reel.isNotEmpty()) onPlay(reel, 0)
            }
            Spacer(Modifier.height(10.dp))
            PremiumButton("Play whole film") {
                val all = chapters.flatMap { it.second }.distinctBy { it.id }
                if (all.isNotEmpty()) onPlay(all, 0)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/* -------------------- 3 Twin Room -------------------- */
@Composable
fun TwinRoomScreen(player: PlayerState, onBack: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "twin").animateFloat(
        0.9f, 1.1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "p",
    )
    UniverseShell("Phantom Twin Room", "A presence that listens with you", onBack) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2, size.height * 0.38f)
                drawCircle(Brush.radialGradient(listOf(UViolet.copy(alpha = 0.45f), Color.Transparent), c, size.minDimension * 0.35f * pulse.value), size.minDimension * 0.35f * pulse.value, c)
                drawCircle(Brush.radialGradient(listOf(UCyan.copy(alpha = 0.35f), Color.Transparent), c, size.minDimension * 0.22f), size.minDimension * 0.22f, c)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                Text("PHANTOM", color = UCyan, letterSpacing = 4.sp, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Text(
                    player.current?.let { "Listening with you to\n“${it.title}”" } ?: "No track yet · play something\nand I stay in the room",
                    color = UText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
                Spacer(Modifier.height(20.dp))
                Text(
                    "Created by SOIF STAR ⭐ · I hold the silence between songs.",
                    color = UMuted,
                    fontSize = 12.sp,
                )
            }
        }
    }
}

/* -------------------- 4 Shared Pulse -------------------- */
/**
 * Online-style Shared Pulse:
 * - Search / random / pick a twin
 * - Personality = liked + most-played tracks
 * - Auto mix: alternate top picks from you + them
 */
@Composable
fun SharedPulseScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    var phase by remember { mutableStateOf("idle") } // idle | searching | found | empty | linked
    var twinName by remember { mutableStateOf("—") }
    var status by remember { mutableStateOf("Pick Random or Select a twin to start.") }
    val myCore = remember(lib.songs, lib.liked, lib.playCounts) {
        val liked = lib.songs.filter { it.id in lib.liked }
        val top = lib.songs.sortedByDescending { lib.playCounts[it.id] ?: 0 }.take(12)
        (liked + top).distinctBy { it.id }.take(16)
    }
    // Simulated online directory of listener personas (names only — songs come from *your* library shape)
    val directory = remember {
        listOf(
            "Nova", "Kite", "Mira", "Ash", "Lumen", "Ryo", "Sable", "Echo", "Vesper", "Indigo"
        )
    }
    var twinPicks by remember { mutableStateOf<List<Song>>(emptyList()) }
    val joint = remember(myCore, twinPicks, phase) {
        if (phase != "linked" && phase != "found") emptyList()
        else {
            val a = myCore
            val b = twinPicks.ifEmpty {
                // Personality blend: reshuffle library biased by duration similarity to your core
                val avg = a.map { it.durationMs }.average().takeIf { !it.isNaN() } ?: 200_000.0
                lib.songs.sortedBy { kotlin.math.abs(it.durationMs - avg.toLong()) }.shuffled().take(12)
            }
            buildList {
                val n = maxOf(a.size, b.size).coerceAtMost(12)
                for (i in 0 until n) {
                    if (i < a.size) add(a[i])
                    if (i < b.size) add(b[i])
                }
            }.distinctBy { it.id }.take(20)
        }
    }

    fun startSearch(random: Boolean, chosen: String? = null) {
        phase = "searching"
        status = if (random) "Scanning for a pulse twin…" else "Linking with $chosen…"
        // lightweight async-ish delay via state flip in LaunchedEffect below
        twinName = chosen ?: directory.random()
    }

    LaunchedEffect(phase, twinName) {
        if (phase == "searching") {
            kotlinx.coroutines.delay(1400)
            // "Online" availability: ~70% chance someone is free
            val available = (twinName.hashCode() + lib.songs.size) % 10 > 2
            if (!available) {
                phase = "empty"
                status = "No one available right now. Try again or pick someone from Chat."
                twinPicks = emptyList()
            } else {
                // Build "their" personality from library slices different from yours
                val avg = myCore.map { it.durationMs }.average().takeIf { !it.isNaN() } ?: 180_000.0
                twinPicks = lib.songs
                    .filter { it.id !in myCore.map { s -> s.id }.toSet() }
                    .sortedBy { kotlin.math.abs(it.durationMs - avg.toLong()) }
                    .shuffled()
                    .take(12)
                phase = "found"
                status = "Matched with $twinName · personalities mixed"
            }
        }
    }

    UniverseShell("Shared Pulse", "Online twins · auto personality mix", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                PulseAvatar("YOU", UCyan)
                Text(
                    when (phase) {
                        "linked", "found" -> "◆ SYNCED ◆"
                        "searching" -> "··· searching ···"
                        "empty" -> "no signal"
                        else -> "offline"
                    },
                    color = when (phase) {
                        "linked", "found" -> UCyan
                        "searching" -> UPink
                        else -> UMuted
                    },
                    modifier = Modifier.align(Alignment.CenterVertically),
                    fontSize = 12.sp,
                )
                PulseAvatar(if (phase == "found" || phase == "linked") twinName else "THEM", UPink)
            }
            Spacer(Modifier.height(12.dp))
            Text(status, color = UMuted, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))

            when (phase) {
                "idle", "empty" -> {
                    PremiumButton("Random twin") { startSearch(random = true) }
                    Spacer(Modifier.height(10.dp))
                    Text("OR SELECT", color = UMuted, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    directory.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { name ->
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0x14FFFFFF))
                                        .border(1.dp, UCyan.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                                        .clickable { startSearch(random = false, chosen = name) }
                                        .padding(vertical = 12.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(name, color = UText, fontSize = 13.sp)
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(
                        "Tip: In Chat, open a friend and use Shared Pulse to invite them as your twin.",
                        color = UMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
                "searching" -> {
                    Text("Listening for heartbeats on the network…", color = UText, fontSize = 13.sp)
                }
                "found" -> {
                    Text("Personality mix ready · ${joint.size} tracks", color = UText, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    PremiumButton("Start shared pulse") {
                        phase = "linked"
                        if (joint.isNotEmpty()) onPlay(joint, 0)
                    }
                    Spacer(Modifier.height(8.dp))
                    PremiumButton("Leave / search again") {
                        phase = "idle"
                        twinPicks = emptyList()
                        status = "Pick Random or Select a twin to start."
                    }
                }
                "linked" -> {
                    Text("JOINT QUEUE · you ↔ $twinName", color = UMuted, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(6.dp))
                    joint.take(12).forEachIndexed { i, s ->
                        val side = if (i % 2 == 0) "YOU" else twinName.take(4)
                        Text("• [$side] ${s.title}", color = UText, fontSize = 13.sp, modifier = Modifier.padding(vertical = 2.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    PremiumButton("Play mixed pulse") { if (joint.isNotEmpty()) onPlay(joint, 0) }
                    Spacer(Modifier.height(8.dp))
                    PremiumButton("Unlink session") {
                        phase = "idle"
                        twinPicks = emptyList()
                        status = "Session closed. Find a new twin anytime."
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PulseAvatar(label: String, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(Brush.radialGradient(listOf(accent, Color(0xFF101018))), CircleShape).border(2.dp, accent, CircleShape), contentAlignment = Alignment.Center) {
            Text(label.take(1).uppercase(), color = Color.White, fontSize = 22.sp)
        }
        Text(label, color = accent, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
    }
}

/* -------------------- 5 Song Autopsy -------------------- */
@Composable
fun SongAutopsyScreen(player: PlayerState, lib: LibraryState, onBack: () -> Unit) {
    val song = player.current ?: lib.songs.firstOrNull()
    val plays = song?.let { lib.playCounts[it.id] ?: 0 } ?: 0
    val liked = song?.id in lib.liked
    UniverseShell("This song", "What it means in your library", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            if (song == null) {
                Text("Play any track — this page is about that one song.", color = UMuted)
            } else {
                Text(song.title, color = UText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text(song.artist, color = UCyan, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                AutopsyRow("Plays in your life", "$plays")
                AutopsyRow("Bond", if (liked) "Liked · kept close" else "Not yet favored")
                AutopsyRow("Duration", "${song.durationMs / 60000}:${((song.durationMs / 1000) % 60).toString().padStart(2, '0')}")
                Spacer(Modifier.height(12.dp))
                Text("How it usually feels over time", color = UMuted, fontSize = 11.sp)
                listOf("Starts soft or bold", "Builds", "The part you wait for", "Winds down").forEach {
                    Text("▸ $it", color = UText, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))
                }
                Spacer(Modifier.height(12.dp))
                Text("Note for you", color = UMuted, fontSize = 11.sp)
                Text(
                    if (plays > 5) "You come back to this one often — it’s part of your sound."
                    else "Still new to you. Try listening all the way through once.",
                    color = UText,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun AutopsyRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, color = UMuted, fontSize = 13.sp)
        Text(v, color = UText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/* -------------------- 6 Time Capsule -------------------- */
@Composable
fun TimeCapsuleScreen(lib: LibraryState, onBack: () -> Unit) {
    var sealed by remember { mutableStateOf(false) }
    val pick = lib.songs.firstOrNull { it.id in lib.liked } ?: lib.songs.firstOrNull()
    UniverseShell("Time Capsule Drop", "Lock meaning into a future unlock", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Box(
                Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(22.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF1A1020), Color(0xFF05060A))))
                    .border(1.dp, UPink.copy(alpha = 0.45f), RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Lock, null, tint = UPink, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text("TRACK", color = UMuted, fontSize = 10.sp, letterSpacing = 2.sp)
            Text(pick?.title ?: "No songs yet", color = UText, fontSize = 16.sp)
            Text(pick?.artist ?: "", color = UCyan, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            Text("Unlock: after 7 days · or on next shared listen", color = UMuted, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            PremiumButton(if (sealed) "Capsule sealed ⭐" else "Seal capsule") { sealed = true }
            if (sealed) {
                Text("Phantom will hold this until the condition is met.", color = UMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/* -------------------- 7 Sanctuary -------------------- */
@Composable
fun SanctuaryScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    var onlyLiked by remember { mutableStateOf(true) }
    var neverHeard by remember { mutableStateOf(false) }
    val pool = remember(onlyLiked, neverHeard, lib) {
        var s = lib.songs
        if (onlyLiked) s = s.filter { it.id in lib.liked }.ifEmpty { s }
        if (neverHeard) s = s.filter { (lib.playCounts[it.id] ?: 0) == 0 }.ifEmpty { s }
        s.shuffled()
    }
    UniverseShell("Anti-Algorithm Sanctuary", "Zero recommendation · only your rules", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("Phantom will not suggest. Only rules you set.", color = UMuted, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            RuleToggle("Only liked tracks", onlyLiked) { onlyLiked = it }
            RuleToggle("Prefer never played", neverHeard) { neverHeard = it }
            Spacer(Modifier.height(12.dp))
            Text("${pool.size} tracks inside the walls", color = UCyan, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            PremiumButton("Enter sanctuary shuffle") { if (pool.isNotEmpty()) onPlay(pool, 0) }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun RuleToggle(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF0C0E16)).clickable { onChange(!on) }.padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = UText, fontSize = 14.sp)
        Text(if (on) "ON" else "OFF", color = if (on) UCyan else UMuted, fontWeight = FontWeight.Bold)
    }
}

/* -------------------- 8 World Frequency -------------------- */
@Composable
fun WorldFrequencyScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val bands = listOf("Rising calm" to 0.62f, "Night pulse" to 0.78f, "Focus surge" to 0.45f, "Release wave" to 0.55f)
    UniverseShell("Live World Frequency", "Collective feeling · not charts", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            bands.forEach { (name, v) ->
                Text(name, color = UText, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
                LinearProgressIndicator(
                    progress = { v },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = UCyan,
                    trackColor = Color(0xFF1A1C28),
                )
            }
            Spacer(Modifier.height(18.dp))
            PremiumButton("Ride the global wave") {
                if (lib.songs.isNotEmpty()) onPlay(lib.songs.shuffled().take(30), 0)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/* -------------------- 9 Identity Soundtrack -------------------- */
@Composable
fun IdentitySoundtrackScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    var persona by remember { mutableStateOf("Exam week me") }
    val personas = listOf("Exam week me", "Train home", "3am version", "Main character")
    val score = remember(persona, lib) {
        when (persona) {
            "Exam week me" -> lib.songs.filter { "study" in (it.title + it.album).lowercase() || "focus" in it.title.lowercase() }
            "Train home" -> lib.songs.filter { "night" in (it.title + it.album).lowercase() || "home" in it.title.lowercase() }
            "3am version" -> lib.songs.filter { "dark" in (it.title + it.album).lowercase() || "alone" in it.title.lowercase() }
            else -> lib.songs.filter { it.id in lib.liked }
        }.ifEmpty { lib.songs.shuffled().take(12) }.take(12)
    }
    UniverseShell("Identity Soundtrack", "A character made of tracks", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            personas.forEach { p ->
                val on = p == persona
                Text(
                    p,
                    color = if (on) Color.White else UMuted,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                        .background(if (on) UViolet.copy(alpha = 0.35f) else Color(0xFF0C0E16))
                        .clickable { persona = p }.padding(12.dp),
                )
            }
            Spacer(Modifier.height(12.dp))
            score.forEachIndexed { i, s ->
                SessionSongRow(title = "★ ${s.title}", subtitle = s.artist, index = i, accent = UPink, onClick = { onPlay(score, i) })
            }
            Spacer(Modifier.height(12.dp))
            PremiumButton("Enter this identity") { if (score.isNotEmpty()) onPlay(score, 0) }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/* -------------------- 10 Repair Session -------------------- */
@Composable
fun RepairSessionScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    val picks = remember(lib) { lib.songs.filter { it.id in lib.liked }.ifEmpty { lib.songs }.take(6) }
    UniverseShell("Repair Session", "Conflict protocol through music", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("Step ${step + 1} of 4", color = UCyan, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            val label = when (step) {
                0 -> "Each of you chooses silence for 30s."
                1 -> "Pick three songs that say what you can't."
                2 -> "Play them interleaved · no talking over."
                else -> "Close on one shared track."
            }
            Text(label, color = UText, fontSize = 16.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.height(16.dp))
            if (step >= 1) picks.take(3).forEach { Text("• ${it.title}", color = UMuted, fontSize = 13.sp) }
            Spacer(Modifier.height(16.dp))
            PremiumButton(if (step < 3) "Next step" else "Play closing track") {
                if (step < 3) step++
                else if (picks.isNotEmpty()) onPlay(picks, 0)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/* -------------------- 11 Dream Mode -------------------- */
@Composable
fun DreamModeScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val morning = remember(lib) {
        val soft = listOf(
            "soft", "calm", "lofi", "morning", "chill", "acoustic", "sunrise", "piano",
            "ambient", "dream", "quiet", "peace", "warm", "slow", "light", "hope",
        )
        val harsh = listOf("metal", "scream", "rage", "drill", "phonk", "hardstyle", "death")
        lib.songs.map { s ->
            val bag = (s.title + " " + s.artist + " " + s.album).lowercase()
            var score = 0.0
            score += soft.count { it in bag } * 2.2
            score -= harsh.count { it in bag } * 3.5
            if (s.id in lib.liked) score += 3.0
            // Prefer mid-length gentle tracks for waking up
            score += when (s.durationMs) {
                in 120_000..280_000 -> 1.5
                in 90_000..360_000 -> 0.6
                else -> -0.4
            }
            score += (lib.playCounts[s.id] ?: 0).coerceAtMost(10) * 0.12
            // Avoid pure silence of unknown zero-play fillers unless needed
            if ((lib.playCounts[s.id] ?: 0) == 0 && s.id !in lib.liked) score -= 0.2
            s to score
        }.sortedByDescending { it.second }.map { it.first }.take(8)
    }
    UniverseShell("Phantom Dream Mode", "Overnight · morning landing sequence", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text("While you sleep, Phantom prepares:", color = UMuted, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            DreamLine("1", "One spoken line from SOIF STAR's Phantom")
            DreamLine("2", "Weather-aware first track")
            DreamLine("3", "One memory recall")
            DreamLine("4", "One tiny morning task")
            Spacer(Modifier.height(16.dp))
            Text("TOMORROW'S OPENING", color = UCyan, fontSize = 10.sp, letterSpacing = 2.sp)
            morning.forEachIndexed { i, s ->
                SessionSongRow(title = s.title, subtitle = s.artist, index = i, accent = UViolet, onClick = { onPlay(morning, i) })
            }
            Spacer(Modifier.height(14.dp))
            PremiumButton("Arm dream sequence") { if (morning.isNotEmpty()) onPlay(morning, 0) }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DreamLine(n: String, text: String) {
    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(UViolet.copy(alpha = 0.4f)), contentAlignment = Alignment.Center) {
            Text(n, color = UText, fontSize = 12.sp)
        }
        Text(text, color = UText, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
    }
}

/* -------------------- 12 Resonance Lab -------------------- */
@Composable
fun ResonanceLabScreen(lib: LibraryState, player: PlayerState, onBack: () -> Unit) {
    val song = player.current ?: lib.songs.maxByOrNull { lib.playCounts[it.id] ?: 0 }
    UniverseShell("Creator Resonance Lab", "How listening bodies shape a track", onBack) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            Text(song?.title ?: "No signal", color = UText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(song?.artist ?: "", color = UMuted, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            Text("RESONANCE DIAGRAM", color = UCyan, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            listOf("Loop density" to 0.7f, "Skip pressure 0:42" to 0.35f, "Night listens" to 0.55f, "Chat shares" to 0.4f).forEach { (n, v) ->
                Text(n, color = UMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                LinearProgressIndicator(progress = { v }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)), color = UPink, trackColor = Color(0xFF1A1C28))
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "This is meaning geometry — not industry charts. Built from your TEXWAVE life.",
                color = UText,
                fontSize = 13.sp,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SessionSongRow(
    title: String,
    subtitle: String = "",
    index: Int = 0,
    accent: Color = UCyan,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x14FFFFFF))
            .border(1.dp, accent.copy(alpha = 0.28f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp)
            .appear(30 + index * 35),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(accent.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center,
        ) {
            Text("${index + 1}", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = UText, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (subtitle.isNotBlank()) {
                Text(subtitle, color = UMuted, fontSize = 11.sp, maxLines = 1)
            }
        }
        Text("▶", color = accent, fontSize = 12.sp)
    }
}

@Composable
private fun PremiumButton(label: String, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "btn")
    val shift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "sh")
    Box(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(UCyan, UViolet, UPink, UCyan),
                    startX = shift * 400f,
                    endX = shift * 400f + 600f,
                )
            )
            .neonBreath()
            .pressable(0.96f, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun UniverseRouter(
    dest: UniverseDest,
    lib: LibraryState,
    player: PlayerState,
    onPlay: (List<Song>, Int) -> Unit,
    onBack: () -> Unit,
) {
    val item = UniverseCatalog.firstOrNull { it.dest == dest }
    val guide = if (dest == UniverseDest.EmotionalGps) com.texgen.music.texwave.ui.ref.Guides.gps
    else com.texgen.music.texwave.ui.ref.Guides.generic("u_" + dest.name, item?.title ?: "Universe", item?.subtitle ?: "")
    com.texgen.music.texwave.ui.ref.CockpitGuide(guide) {
    when (dest) {
        UniverseDest.Hub -> UniverseHubScreen(onOpen = {}, onBack = onBack) // replaced by parent
        UniverseDest.EmotionalGps -> EmotionalGpsScreen(lib, onPlay, onBack)
        UniverseDest.MemoryCinema -> MemoryCinemaScreen(lib, onPlay, onBack)
        UniverseDest.TwinRoom -> TwinRoomScreen(player, onBack)
        UniverseDest.SharedPulse -> SharedPulseScreen(lib, onPlay, onBack)
        UniverseDest.SongAutopsy -> SongAutopsyScreen(player, lib, onBack)
        UniverseDest.TimeCapsule -> TimeCapsuleScreen(lib, onBack)
        UniverseDest.Sanctuary -> SanctuaryScreen(lib, onPlay, onBack)
        UniverseDest.WorldFrequency -> WorldFrequencyScreen(lib, onPlay, onBack)
        UniverseDest.IdentitySoundtrack -> IdentitySoundtrackScreen(lib, onPlay, onBack)
        UniverseDest.RepairSession -> RepairSessionScreen(lib, onPlay, onBack)
        UniverseDest.DreamMode -> DreamModeScreen(lib, onPlay, onBack)
        UniverseDest.ResonanceLab -> ResonanceLabScreen(lib, player, onBack)
        UniverseDest.EmotionalWeather -> EmotionalWeatherScreen(lib, onPlay, onBack)
        UniverseDest.MemoryAnchors -> MemoryAnchorsScreen(lib, onPlay, onBack)
        UniverseDest.GhostQueue -> GhostQueueScreen(lib, player, onPlay, onBack)
        UniverseDest.LivingSongs -> LivingSongsScreen(lib, onPlay, onBack)
        UniverseDest.TheUnplayed -> TheUnplayedScreen(lib, onPlay, onBack)
    }
    }
}


/* -------------------- Emotional Weather -------------------- */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmotionalWeatherScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val weathers = listOf(
        "Clear Sky" to listOf(
            "calm", "bright", "hope", "sun", "sunny", "clear", "morning", "happy", "joy", "light", "sky"
        ),
        "Soft Rain" to listOf(
            "rain", "rainy", "drizzle", "soft", "slow", "mellow", "gentle", "chill", "lofi", "lo-fi",
            "sad", "melancholy", "tears", "quiet", "ambient", "piano", "ballad"
        ),
        "Thunder" to listOf(
            "thunder", "storm", "intense", "power", "powerful", "epic", "dark", "rage", "metal",
            "boss", "hard", "fire", "battle", "energy"
        ),
        "Fog" to listOf(
            "fog", "mist", "haze", "dream", "dreamy", "mysterious", "slow", "ambient", "echo",
            "reverb", "space", "void", "soft", " ethereal".trim()
        ),
        "Golden Hour" to listOf(
            "warm", "golden", "sunset", "sunrise", "nostalgia", "nostalgic", "evening", "glow",
            "soft", "acoustic", "memory", "summer", "orange"
        ),
    )
    var selected by remember { mutableStateOf(weathers[0]) }
    val matches = remember(selected, lib) {
        val keys = selected.second
        val neg = when (selected.first) {
            "Soft Rain" -> listOf("party", "club", "gym", "workout", "hype", "drill")
            "Thunder" -> listOf("lullaby", "kids", "lofi", "chillhop", "meditation")
            "Fog" -> listOf("party", "club", "workout", "gym")
            "Clear Sky" -> listOf("metal", "scream", "rage", "doom")
            else -> emptyList()
        }
        lib.songs.map { s ->
            val t = (s.title + " " + s.artist + " " + s.album).lowercase()
            var score = 0
            keys.forEach { k -> if (k in t) score += 3 }
            neg.forEach { k -> if (k in t) score -= 4 }
            score += ((lib.playCounts[s.id] ?: 0).coerceAtMost(15)) / 5
            if (s.id in lib.liked) score += 2
            s to score
        }
            .filter { it.second >= 2 }
            .sortedByDescending { it.second }
            .map { it.first }
            .ifEmpty {
                // fallback: prefer liked / frequently played rather than pure random
                lib.songs.sortedByDescending { (lib.playCounts[it.id] ?: 0) + if (it.id in lib.liked) 5 else 0 }.take(12)
            }
            .take(18)
    }
    UniverseShell("Emotional Weather", "Music that matches the sky inside you", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("HOW DOES THE AIR FEEL?", color = UCyan, fontSize = 11.sp, letterSpacing = 1.4.sp)
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                weathers.forEach { w ->
                    val active = w == selected
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (active) UViolet.copy(alpha = 0.35f) else Color(0xFF12121A))
                            .border(1.dp, if (active) UViolet else UMuted.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                            .pressable(0.94f) { selected = w }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(w.first, color = if (active) UText else UMuted, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            val weatherPulse = rememberInfiniteTransition(label = "weather")
            val weatherGlow by weatherPulse.animateFloat(
                0.25f, 0.55f,
                infiniteRepeatable(tween(1600), RepeatMode.Reverse),
                label = "wg",
            )
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF0A1628), Color(0xFF050510))))
                    .border(1.dp, UCyan.copy(alpha = weatherGlow), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(selected.first.uppercase(), color = UCyan, letterSpacing = 2.sp, fontSize = 13.sp)
                    Text("${matches.size} tracks · tap any to play", color = UMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
            Spacer(Modifier.height(16.dp))
            matches.take(10).forEachIndexed { i, s ->
                SessionSongRow(
                    title = s.title,
                    subtitle = s.artist,
                    index = i,
                    accent = UCyan,
                    onClick = { onPlay(matches, i) },
                )
            }
            Spacer(Modifier.height(16.dp))
            PremiumButton("Play this weather") { if (matches.isNotEmpty()) onPlay(matches, 0) }
            Spacer(Modifier.height(28.dp))
        }
    }
}

/* -------------------- Memory Anchors -------------------- */
@Composable
fun MemoryAnchorsScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    // Simple in-memory + remembered anchors for the session (persisted store can be added later)
    var anchors by remember {
        mutableStateOf(
            listOf(
                "First night in the new city" to lib.songs.getOrNull(0),
                "Rainy bus ride home" to lib.songs.getOrNull(1),
                "That 3 a.m. conversation" to lib.songs.getOrNull(2),
            ).filter { it.second != null }
        )
    }
    UniverseShell("Memory Anchors", "Songs locked to real moments", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("TAP A SONG IN YOUR LIBRARY TO CREATE AN ANCHOR LATER. FOR NOW THESE ARE ALIVE.", color = UMuted, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            anchors.forEach { (label, song) ->
                if (song != null) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0C0C14))
                            .border(1.dp, UPink.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                            .clickable { onPlay(listOf(song), 0) }
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(label, color = UPink, fontSize = 12.sp, letterSpacing = 0.5.sp)
                            Text(song.title, color = UText, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                            Text(song.artist, color = UMuted, fontSize = 12.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            PremiumButton("Play all anchors") {
                val list = anchors.mapNotNull { it.second }
                if (list.isNotEmpty()) onPlay(list, 0)
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

/* -------------------- Ghost Queue -------------------- */
@Composable
fun GhostQueueScreen(lib: LibraryState, player: PlayerState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val ghost = remember(lib, player.current) {
        val base = player.current?.let { cur ->
            lib.songs.filter { it.artist == cur.artist || (lib.playCounts[it.id] ?: 0) > 2 }.shuffled()
        } ?: lib.songs.shuffled()
        base.take(12)
    }
    UniverseShell("Ghost Queue", "The timeline you almost lived", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("While you pause, a parallel you keeps listening. Merge when ready.", color = UMuted, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            ghost.forEachIndexed { i, s ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (i == 0) UViolet.copy(alpha = 0.15f) else Color.Transparent)
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${i + 1}", color = UCyan, fontSize = 12.sp, modifier = Modifier.width(28.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, color = UText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.artist, color = UMuted, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            PremiumButton("Merge timelines · Play ghost queue") {
                if (ghost.isNotEmpty()) onPlay(ghost, 0)
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

/* -------------------- Living Songs -------------------- */
@Composable
fun LivingSongsScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val living = remember(lib) {
        lib.songs
            .map { s -> s to (lib.playCounts[s.id] ?: 0) }
            .sortedByDescending { it.second }
            .take(20)
    }
    UniverseShell("Living Songs", "Tracks that grow a soul with every play", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("The more you play them, the more they change. Lonely ones may call you later.", color = UMuted, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            living.forEach { (s, count) ->
                val level = when {
                    count >= 30 -> "Ancient"
                    count >= 12 -> "Awakened"
                    count >= 4 -> "Stirring"
                    else -> "Newborn"
                }
                val color = when (level) {
                    "Ancient" -> UPink
                    "Awakened" -> UViolet
                    "Stirring" -> UCyan
                    else -> UMuted
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onPlay(listOf(s), 0) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(s.title, color = UText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("$level · $count plays", color = color, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            PremiumButton("Play the eldest souls") {
                val list = living.map { it.first }
                if (list.isNotEmpty()) onPlay(list, 0)
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

/* -------------------- The Unplayed -------------------- */
@Composable
fun TheUnplayedScreen(lib: LibraryState, onPlay: (List<Song>, Int) -> Unit, onBack: () -> Unit) {
    val unplayed = remember(lib) {
        lib.songs.filter { (lib.playCounts[it.id] ?: 0) == 0 }.shuffled().take(30)
    }
    UniverseShell("The Unplayed", "Sacred tracks you have never finished", onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF1A0A12), Color(0xFF050208))))
                    .border(1.dp, UPink.copy(alpha = 0.45f), RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("NEVER TOUCHED", color = UPink, letterSpacing = 2.sp, fontSize = 12.sp)
                    Text("${unplayed.size} songs waiting in silence", color = UMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
            Spacer(Modifier.height(18.dp))
            if (unplayed.isEmpty()) {
                Text("Every song in your library has been heard. Beautiful.", color = UText, fontSize = 15.sp)
            } else {
                unplayed.take(15).forEach { s ->
                    Text("${s.title} · ${s.artist}", color = UText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 4.dp))
                }
                Spacer(Modifier.height(18.dp))
                PremiumButton("Begin the confession") { onPlay(unplayed, 0) }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}
