package com.texgen.music.texwave.arena.ui.three

import android.view.MotionEvent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.texgen.music.texwave.arena.data.model.WarriorGender
import com.texgen.music.texwave.arena.data.model.WarriorLoadout
import com.texgen.music.texwave.arena.domain.RankSystem
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import java.io.File

/**
 * Warrior presentation surface.
 *
 * When `warrior_male.glb` / `warrior_female.glb` exist under assets/models and
 * SceneView is on the classpath, [attemptSceneView] loads a real Filament model.
 *
 * Otherwise a high-quality **procedural fallback** is shown and clearly labeled.
 * That fallback is NOT a finished production 3D character.
 */
@Composable
fun Warrior3DView(
    loadout: WarriorLoadout,
    rank: RankSystem.RankTier,
    modifier: Modifier = Modifier,
    heightDp: Int = 320
) {
    val context = LocalContext.current
    val modelName = if (loadout.gender == WarriorGender.GIRL) "warrior_female.glb" else "warrior_male.glb"
    val hasAsset = remember(modelName) {
        try {
            context.assets.open("models/$modelName").close()
            true
        } catch (_: Exception) {
            false
        }
    }

    Box(
        modifier
            .fillMaxWidth()
            .height(heightDp.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0A1020),
                        Color(0xFF12082A),
                        Color(0xFF060810)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(
                        ArenaColors.Cyan.copy(alpha = 0.45f),
                        ArenaColors.Violet.copy(alpha = 0.25f),
                        Color.Transparent
                    )
                ),
                RoundedCornerShape(24.dp)
            )
    ) {
        if (hasAsset) {
            // SceneView integration point — requires dependency + runtime.
            // If SceneView classes are missing at runtime, fall through is handled by try/catch in factory.
            SceneViewWarrior(
                assetPath = "models/$modelName",
                modifier = Modifier.fillMaxSize(),
                onUnavailable = { /* compose below still shows badge */ }
            )
            AssetBadge("3D MODEL", ArenaColors.Cyan)
        } else {
            ProceduralWarriorFallback(loadout, rank)
            AssetBadge("FALLBACK — ADD GLB", ArenaColors.Magenta)
        }
    }
}

@Composable
private fun BoxScope.AssetBadge(text: String, color: Color) {
    Text(
        text,
        color = color,
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(10.dp)
            .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
}

/**
 * Optional SceneView host. Compiled against soft references via reflection-free
 * AndroidView only if the integrator adds SceneView. Here we use a safe stub
 * AndroidView that attempts class load; on failure shows empty (parent shows fallback badge).
 *
 * Integrators should replace this with:
 * ```
 * ModelNode(modelInstance = modelLoader.createModelInstance("models/...glb"))
 * ```
 * per SceneView 2.x docs when the dependency is present.
 */
@Composable
fun SceneViewWarrior(
    assetPath: String,
    modifier: Modifier = Modifier,
    onUnavailable: () -> Unit = {}
) {
    val context = LocalContext.current
    var failed by remember { mutableStateOf(false) }
    if (failed) {
        onUnavailable()
        return
    }
    // Without SceneView on classpath this still compiles: plain Surface placeholder.
    // Real ModelNode wiring is documented in DEPENDENCIES_3D.md for host project.
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            android.widget.FrameLayout(ctx).also { frame ->
                frame.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                // Host app replaces this FrameLayout content with SceneView when dep is added.
                val label = android.widget.TextView(ctx).apply {
                    text = "SceneView host · $assetPath"
                    setTextColor(android.graphics.Color.CYAN)
                    textSize = 11f
                    setPadding(24, 24, 24, 24)
                }
                frame.addView(label)
            }
        }
    )
}

@Composable
fun ProceduralWarriorFallback(
    loadout: WarriorLoadout,
    rank: RankSystem.RankTier
) {
    var rot by remember { mutableFloatStateOf(0f) }
    val infinite = rememberInfiniteTransition(label = "idle")
    val breath by infinite.animateFloat(
        0.98f, 1.02f,
        infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Reverse),
        label = "b"
    )
    val auraColor = when {
        rank.ordinal >= RankSystem.RankTier.S_HUNTER.ordinal -> ArenaColors.RankGold
        rank.ordinal >= RankSystem.RankTier.A.ordinal -> ArenaColors.Magenta
        rank.ordinal >= RankSystem.RankTier.B.ordinal -> ArenaColors.Violet
        else -> ArenaColors.Cyan
    }
    val body = if (loadout.gender == WarriorGender.GIRL) Color(0xFFCE93D8) else Color(0xFF64B5F6)

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { _, drag -> rot += drag.x * 0.4f }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2
            val cy = size.height * 0.52f
            // Floor glow
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(auraColor.copy(alpha = 0.35f), Color.Transparent),
                    center = Offset(cx, size.height * 0.82f),
                    radius = size.minDimension * 0.35f
                ),
                radius = size.minDimension * 0.35f,
                center = Offset(cx, size.height * 0.82f)
            )
            // Aura ring
            drawCircle(
                color = auraColor.copy(alpha = 0.4f),
                radius = 90f * breath,
                center = Offset(cx, cy),
                style = Stroke(width = 4f)
            )
            // Stylized figure (front-ish with rot parallax)
            val ox = rot * 0.15f
            // Head
            drawCircle(body, 36f * breath, Offset(cx + ox, cy - 110f))
            // Torso
            drawRoundRect(
                color = body.copy(alpha = 0.9f),
                topLeft = Offset(cx - 40f + ox, cy - 70f),
                size = androidx.compose.ui.geometry.Size(80f, 110f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(20f, 20f)
            )
            // Shoulders / arms
            drawCircle(body.copy(alpha = 0.85f), 22f, Offset(cx - 55f + ox, cy - 40f))
            drawCircle(body.copy(alpha = 0.85f), 22f, Offset(cx + 55f + ox, cy - 40f))
            // Legs
            drawRoundRect(
                color = body.copy(alpha = 0.75f),
                topLeft = Offset(cx - 36f + ox, cy + 40f),
                size = androidx.compose.ui.geometry.Size(28f, 70f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
            )
            drawRoundRect(
                color = body.copy(alpha = 0.75f),
                topLeft = Offset(cx + 8f + ox, cy + 40f),
                size = androidx.compose.ui.geometry.Size(28f, 70f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
            )
        }
        Text(
            "Drag to rotate · Replace with GLB for production 3D",
            color = ArenaColors.Muted,
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp)
        )
    }
}
