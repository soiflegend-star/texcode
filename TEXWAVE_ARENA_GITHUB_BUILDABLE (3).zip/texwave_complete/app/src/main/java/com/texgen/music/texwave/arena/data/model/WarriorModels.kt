package com.texgen.music.texwave.arena.data.model

import androidx.compose.runtime.Immutable
import com.texgen.music.texwave.arena.domain.RankSystem
import java.time.Instant

enum class WarriorGender { BOY, GIRL }

enum class CosmeticSlot {
    HAIR, FACE, OUTFIT, GLOVES, ARMOR, AURA, VICTORY_POSE, COLOR_THEME
}

@Immutable
data class CosmeticItem(
    val id: String,
    val slot: CosmeticSlot,
    val name: String,
    val minLevel: Int,
    val minRank: RankSystem.RankTier = RankSystem.RankTier.D,
    val isLegendary: Boolean = false
)

@Immutable
data class WarriorLoadout(
    val gender: WarriorGender = WarriorGender.BOY,
    val hairId: String = "hair_basic",
    val faceId: String = "face_basic",
    val outfitId: String = "outfit_trainee",
    val glovesId: String = "gloves_basic",
    val armorId: String = "armor_none",
    val auraId: String = "aura_none",
    val victoryPoseId: String = "pose_default",
    val colorThemeId: String = "theme_cyan"
)

@Immutable
data class WarriorProfile(
    val userId: String,
    val username: String,
    val loadout: WarriorLoadout = WarriorLoadout(),
    val level: Int = 1,
    val rank: RankSystem.RankTier = RankSystem.RankTier.D,
    val totalXp: Long = 0L,
    val xpIntoLevel: Long = 0L,
    val xpRequiredNext: Long = RankSystem.xpToAdvanceFrom(1),
    val totalAcceptedReps: Long = 0L,
    val competitiveRating: Int = 1000,
    val wins: Int = 0,
    val losses: Int = 0,
    val seasonWins: Int = 0,
    val seasonLosses: Int = 0,
    val unlockedCosmeticIds: Set<String> = setOf(
        "hair_basic", "face_basic", "outfit_trainee", "gloves_basic",
        "armor_none", "aura_none", "pose_default", "theme_cyan"
    ),
    val updatedAt: Instant = Instant.now()
) {
    val progressFraction: Float
        get() = if (xpRequiredNext <= 0) 1f
        else (xpIntoLevel.toFloat() / xpRequiredNext).coerceIn(0f, 1f)
}

@Immutable
data class MatchRecord(
    val id: String,
    val opponentId: String,
    val opponentName: String,
    val opponentLevel: Int,
    val didWin: Boolean,
    val ratingDelta: Int,
    val xpReward: Long,
    val playedAt: Instant
)

object CosmeticCatalog {
    val all: List<CosmeticItem> = listOf(
        CosmeticItem("hair_basic", CosmeticSlot.HAIR, "Trainee Cut", 1),
        CosmeticItem("hair_spike", CosmeticSlot.HAIR, "Spike Edge", 15),
        CosmeticItem("hair_legend", CosmeticSlot.HAIR, "Legend Flow", 90, RankSystem.RankTier.S_HUNTER, true),
        CosmeticItem("face_basic", CosmeticSlot.FACE, "Standard", 1),
        CosmeticItem("face_scar", CosmeticSlot.FACE, "Battle Mark", 40),
        CosmeticItem("outfit_trainee", CosmeticSlot.OUTFIT, "Trainee Gi", 1),
        CosmeticItem("outfit_striker", CosmeticSlot.OUTFIT, "Striker Suit", 30),
        CosmeticItem("outfit_elite", CosmeticSlot.OUTFIT, "Elite Armor Weave", 70),
        CosmeticItem("outfit_s_rank", CosmeticSlot.OUTFIT, "S-Rank Mantle", 90, RankSystem.RankTier.S_HUNTER, true),
        CosmeticItem("gloves_basic", CosmeticSlot.GLOVES, "Cloth Wraps", 1),
        CosmeticItem("gloves_impact", CosmeticSlot.GLOVES, "Impact Gauntlets", 50),
        CosmeticItem("armor_none", CosmeticSlot.ARMOR, "None", 1),
        CosmeticItem("armor_plate", CosmeticSlot.ARMOR, "Carbon Plate", 60),
        CosmeticItem("armor_mythic", CosmeticSlot.ARMOR, "Mythic Shell", 95, RankSystem.RankTier.S_LEGENDARY, true),
        CosmeticItem("aura_none", CosmeticSlot.AURA, "None", 1),
        CosmeticItem("aura_cyan", CosmeticSlot.AURA, "Cyan Pulse", 25),
        CosmeticItem("aura_violet", CosmeticSlot.AURA, "Violet Storm", 55),
        CosmeticItem("aura_gold", CosmeticSlot.AURA, "Gold Nova", 90, RankSystem.RankTier.S_HUNTER, true),
        CosmeticItem("pose_default", CosmeticSlot.VICTORY_POSE, "Default", 1),
        CosmeticItem("pose_champion", CosmeticSlot.VICTORY_POSE, "Champion Rise", 80),
        CosmeticItem("theme_cyan", CosmeticSlot.COLOR_THEME, "Cyan", 1),
        CosmeticItem("theme_magenta", CosmeticSlot.COLOR_THEME, "Magenta", 20),
        CosmeticItem("theme_gold", CosmeticSlot.COLOR_THEME, "Gold", 90, RankSystem.RankTier.S_HUNTER, true)
    )

    fun unlockedFor(level: Int, rank: RankSystem.RankTier, owned: Set<String>): List<CosmeticItem> =
        all.filter { it.id in owned || (level >= it.minLevel && rank.ordinal >= it.minRank.ordinal) }
}
