package com.texgen.music.texwave.ui.screens

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.texgen.music.texwave.data.catalog.OpenCatalogEngine
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.launch


/** Instagram-style local ranking: liked + more-watched clips surface first. */
private object ReelsRank {
    private const val PREFS = "texwave_reels_rank"
    fun likes(ctx: android.content.Context): MutableSet<String> =
        ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .getStringSet("likes", emptySet())?.toMutableSet() ?: mutableSetOf()
    fun saveLikes(ctx: android.content.Context, ids: Set<String>) {
        ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putStringSet("likes", ids).apply()
    }
    fun watchCount(ctx: android.content.Context, id: String): Int =
        ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getInt("w_$id", 0)
    fun bumpWatch(ctx: android.content.Context, id: String) {
        val p = ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        p.edit().putInt("w_$id", p.getInt("w_$id", 0) + 1).apply()
    }
    fun score(ctx: android.content.Context, id: String, liked: Set<String>): Int {
        var s = watchCount(ctx, id) * 3
        if (id in liked) s += 40
        return s
    }
    fun rank(ctx: android.content.Context, list: List<OpenCatalogEngine.VideoItem>, liked: Set<String>): List<OpenCatalogEngine.VideoItem> {
        if (list.isEmpty()) return list
        return list.sortedByDescending { score(ctx, it.id, liked) }
    }
}

// Instagram gradient accents
private val IgPink = Color(0xFFFF2D55)
private val IgPurple = Color(0xFFC13584)
private val IgOrange = Color(0xFFFCAF45)
private val IgBlue = Color(0xFF405DE6)
private val IgGrad = listOf(IgOrange, IgPink, IgPurple, IgBlue)

@Composable
fun ReelsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("short film animation nature") }
    var reels by remember { mutableStateOf<List<OpenCatalogEngine.VideoItem>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(false) }
    var dragAcc by remember { mutableFloatStateOf(0f) }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            playWhenReady = true
        }
    }

    fun load(q: String) {
        loading = true
        error = null
        scope.launch {
            try {
                val list = OpenCatalogEngine.searchVideoFast(q, limit = 14)
                val liked = ReelsRank.likes(context)
                // Liked + most-watched first (Instagram-style ranking)
                reels = ReelsRank.rank(context, list, liked)
                index = 0
                if (list.isEmpty()) error = "No reachable open clips. Try: animation, nature, train, jazz"
            } catch (e: Exception) {
                error = e.message ?: "Load failed"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        load(query)
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                buffering = playbackState == Player.STATE_BUFFERING
            }
            override fun onPlayerError(error: PlaybackException) {
                // Skip dead item
                if (index < reels.lastIndex) index++ else playing = false
            }
        })
    }

    var qualityLabel by remember { mutableStateOf("Auto") }
    val qualityCycle = listOf("Auto", "360p", "480p", "720p", "1080p")
    LaunchedEffect(index, reels, qualityLabel) {
        val cur = reels.getOrNull(index) ?: return@LaunchedEffect
        try {
            val stream = cur.urlForQuality(qualityLabel)
            player.setMediaItem(MediaItem.fromUri(stream))
            player.prepare()
            player.playWhenReady = playing
            player.volume = if (muted) 0f else 1f
        } catch (_: Exception) {
            if (index < reels.lastIndex) index++
        }
    }

    LaunchedEffect(playing) { player.playWhenReady = playing }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    DisposableEffect(Unit) {
        onDispose {
            player.stop()
            player.release()
        }
    }

    var showSearch by remember { mutableStateOf(false) }
    var likedClips by remember { mutableStateOf(ReelsRank.likes(context).toSet()) }
    var followed by remember { mutableStateOf(setOf<String>()) }
    var heartBurst by remember { mutableStateOf(false) }
    val heartScale = remember { Animatable(0f) }
    val scopeAnim = rememberCoroutineScope()
    fun toggleLike(id: String) {
        if (id == "none" || id.isBlank()) return
        val next = if (id in likedClips) likedClips - id else likedClips + id
        likedClips = next
        ReelsRank.saveLikes(context, next)
        if (id in next) {
            heartBurst = true
            scopeAnim.launch {
                heartScale.snapTo(0.4f)
                heartScale.animateTo(1.25f, spring(dampingRatio = 0.42f, stiffness = Spring.StiffnessMedium))
                heartScale.animateTo(1f, tween(180))
                delay(420)
                heartBurst = false
            }
        }
    }
    // Track watches — more watched ranks higher next load
    LaunchedEffect(index, reels) {
        val id = reels.getOrNull(index)?.id ?: return@LaunchedEffect
        delay(900) // count as a watch after ~1s engagement
        ReelsRank.bumpWatch(context, id)
    }
    val rc = com.texgen.music.texwave.ui.ref.Ref
    val cardShape = RoundedCornerShape(26.dp)
    val igBorder = Brush.linearGradient(IgGrad)

    com.texgen.music.texwave.ui.ref.RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 10.dp, top = 14.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Reels",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                    style = androidx.compose.ui.text.TextStyle(
                        brush = Brush.linearGradient(IgGrad),
                    ),
                )
                IconButton(onClick = { muted = !muted }) {
                    Icon(if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp, null, tint = Color.White)
                }
                IconButton(onClick = { showSearch = !showSearch }) { Icon(Icons.Rounded.Search, null, tint = Color.White) }
            }
            if (showSearch) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(18.dp)),
                        singleLine = true,
                        placeholder = { Text("Search open clips…") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = rc.Cyan,
                            unfocusedBorderColor = rc.Line,
                            focusedContainerColor = Color(0xCC090B13),
                            unfocusedContainerColor = Color(0xCC090B13),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = rc.Cyan,
                        ),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { load(query) }, colors = ButtonDefaults.buttonColors(containerColor = IgPink)) {
                        Icon(Icons.Rounded.Search, null, modifier = Modifier.size(18.dp))
                    }
                }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), color = IgPink, trackColor = IgPurple.copy(alpha = 0.25f))
            error?.let { Text(it, color = Tx.Danger, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) }

            Box(
                Modifier
                    .weight(1f)
                    .padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 10.dp)
                    .clip(cardShape)
                    .background(Color.Black),
            ) {
                if (reels.isNotEmpty()) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                useController = false
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                this.player = player
                                layoutParams = FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(reels, index) {
                                detectTapGestures(
                                    onDoubleTap = {
                                        val id = reels.getOrNull(index)?.id
                                        if (id != null) toggleLike(id)
                                    },
                                    onTap = { playing = !playing },
                                )
                            }
                            .pointerInput(reels, index) {
                                detectVerticalDragGestures(
                                    onDragEnd = {
                                        when {
                                            dragAcc < -80f && index < reels.lastIndex -> index++
                                            dragAcc > 80f && index > 0 -> index--
                                        }
                                        dragAcc = 0f
                                    },
                                    onVerticalDrag = { _, dy -> dragAcc += dy },
                                )
                            },
                        update = { it.player = player },
                    )
                } else {
                    com.texgen.music.texwave.ui.ref.RefImage(
                        com.texgen.music.texwave.R.drawable.ref_reel_bg, Modifier.fillMaxSize(),
                    )
                }
                Box(
                    Modifier.fillMaxWidth().height(230.dp).align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF005060B)))),
                )
                if (buffering) {
                    CircularProgressIndicator(Modifier.align(Alignment.Center), color = IgPink)
                }
                // Instagram-style floating heart on like / double-tap
                if (heartBurst) {
                    Icon(
                        Icons.Rounded.Favorite, null,
                        tint = IgPink,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(110.dp)
                            .graphicsLayer {
                                scaleX = heartScale.value
                                scaleY = heartScale.value
                                alpha = heartScale.value.coerceIn(0f, 1f)
                            },
                    )
                }
                val current = reels.getOrNull(index)
                val clipKey = current?.id ?: "none"
                val isLiked = clipKey in likedClips
                // Right action rail
                Column(
                    Modifier.align(Alignment.CenterEnd).padding(end = 12.dp, bottom = 70.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    val likeScale by animateFloatAsState(
                        if (isLiked) 1.15f else 1f,
                        spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium),
                        label = "likeScale",
                    )
                    IconButton(onClick = { toggleLike(clipKey) }) {
                        Icon(
                            if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                            tint = if (isLiked) IgPink else Color.White,
                            modifier = Modifier.size(40.dp).scale(likeScale),
                        )
                    }
                    Text(
                        "${(if (isLiked) 1 else 0) + ReelsRank.watchCount(context, clipKey)}",
                        color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(12.dp))
                    // Quality switch (YouTube/Instagram-style)
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x66000000))
                            .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                            .clickable {
                                val i = qualityCycle.indexOf(qualityLabel).let { if (it < 0) 0 else it }
                                qualityLabel = qualityCycle[(i + 1) % qualityCycle.size]
                            }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(qualityLabel, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("Quality", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                    Spacer(Modifier.height(14.dp))
                    IconButton(onClick = { if (index < reels.lastIndex) index++ }) {
                        Icon(Icons.Rounded.SkipNext, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                    Text("Next", color = Color.White, fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    IconButton(onClick = {
                        val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_TEXT, current?.url ?: "")
                        }
                        context.startActivity(
                            android.content.Intent.createChooser(send, "Share")
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }) {
                        Icon(Icons.Rounded.Share, null, tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                    Text("Share", color = Color.White, fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                    IconButton(onClick = { playing = !playing }) {
                        Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                }
                // Creator + caption
                if (current != null) {
                    Column(Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 76.dp, bottom = 18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            com.texgen.music.texwave.ui.ref.InitialsAvatar(
                                current.creator, Modifier.size(46.dp),
                                ringColors = listOf(rc.Violet, rc.Magenta),
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                current.creator, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                            )
                            Spacer(Modifier.width(12.dp))
                            val following = current.creator in followed
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Color(0x33000000))
                                    .border(1.5.dp, IgPink, RoundedCornerShape(20.dp))
                                    .clickable {
                                        followed = if (following) followed - current.creator else followed + current.creator
                                    }
                                    .padding(horizontal = 16.dp, vertical = 7.dp),
                            ) { Text(if (following) "Following" else "Follow", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(current.title, color = Color.White, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "#" + query.trim().replace(" ", "").ifEmpty { "vibes" } + " #music #aesthetic",
                            color = IgPink, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        )
                    }
                }
            }
        }
    }
}
