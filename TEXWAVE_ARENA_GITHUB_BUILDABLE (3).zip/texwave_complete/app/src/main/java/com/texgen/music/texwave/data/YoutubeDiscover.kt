package com.texgen.music.texwave.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Discover similar / related videos on YouTube without a Google API key.
 * Uses public Piped instances when online; always can open a YouTube search URL.
 */
object YoutubeDiscover {

    data class VideoHit(
        val videoId: String,
        val title: String,
        val author: String,
        val thumbnailUrl: String,
        val durationLabel: String = "",
    ) {
        val watchUrl: String get() = "https://www.youtube.com/watch?v=$videoId"
        val searchFallback: String get() = youtubeSearchUrl("$title $author")
    }

    fun youtubeSearchUrl(query: String): String =
        "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query.trim(), "UTF-8")

    fun openYoutubeSearch(context: Context, query: String) {
        openUrl(context, youtubeSearchUrl(query))
    }

    fun openVideo(context: Context, hit: VideoHit) {
        openUrl(context, hit.watchUrl)
    }

    fun openUrl(context: Context, url: String) {
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    private val pipedHosts = listOf(
        "https://pipedapi.kavin.rocks",
        "https://pipedapi.adminforge.de",
        "https://api.piped.private.coffee",
        "https://pipedapi.leptons.xyz",
        "https://pipedapi.nosebs.ru",
        "https://pipedapi.syncpundit.io",
    )

    /**
     * Search YouTube-like results via Piped. Returns up to [limit] video hits with thumbnails.
     */
    suspend fun searchSimilar(
        seedTitle: String,
        seedArtist: String,
        limit: Int = 12,
    ): List<VideoHit> = withContext(Dispatchers.IO) {
        val primary = "$seedTitle $seedArtist".trim()
        val out = linkedMapOf<String, VideoHit>()
        // Fast path: one strong query first
        for (h in searchOnce(primary, limit = limit)) {
            out.putIfAbsent(h.videoId, h)
        }
        // Only expand if we still need more results
        if (out.size < limit) {
            val extra = listOf(
                "$seedTitle $seedArtist official audio",
                "$seedArtist mix",
            )
            for (q in extra) {
                if (out.size >= limit) break
                for (h in searchOnce(q, limit = 6)) {
                    if (out.size >= limit) break
                    out.putIfAbsent(h.videoId, h)
                }
            }
        }
        // Guarantee at least synthetic search cards if network failed
        if (out.isEmpty()) {
            listOf(
                VideoHit("search1", seedTitle, seedArtist, "", "Search"),
                VideoHit("search2", "$seedTitle mix", seedArtist, "", "Search"),
                VideoHit("search3", "Songs like $seedTitle", seedArtist, "", "Search"),
                VideoHit("search4", "$seedArtist radio", seedArtist, "", "Search"),
                VideoHit("search5", "$seedTitle official", seedArtist, "", "Search"),
                VideoHit("search6", "$seedTitle live", seedArtist, "", "Search"),
                VideoHit("search7", "$seedTitle cover", seedArtist, "", "Search"),
                VideoHit("search8", "$seedTitle slowed", seedArtist, "", "Search"),
                VideoHit("search9", "$seedTitle lyrics", seedArtist, "", "Search"),
                VideoHit("search10", "Best of $seedArtist", seedArtist, "", "Search"),
            )
        } else out.values.take(limit)
    }

    private fun searchOnce(query: String, limit: Int): List<VideoHit> {
        for (host in pipedHosts) {
            val hits = runCatching { fetchPiped(host, query, limit) }.getOrNull()
            if (!hits.isNullOrEmpty()) return hits
        }
        return emptyList()
    }

    private fun fetchPiped(host: String, query: String, limit: Int): List<VideoHit> {
        val url = "$host/search?q=${URLEncoder.encode(query, "UTF-8")}&filter=videos"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 2_800
            readTimeout = 3_500
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Texwave/1.1")
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (conn.responseCode !in 200..299) error("piped ${conn.responseCode}")
            val body = conn.inputStream.bufferedReader().readText()
            val root = JSONObject(body)
            val items = root.optJSONArray("items") ?: JSONArray()
            val out = mutableListOf<VideoHit>()
            for (i in 0 until items.length()) {
                if (out.size >= limit) break
                val o = items.optJSONObject(i) ?: continue
                val type = o.optString("type", "stream")
                if (type != "stream" && type != "video") continue
                val id = o.optString("url", "").substringAfter("v=").substringAfter("/watch?v=")
                    .substringAfter("/shorts/").substringBefore("&").substringBefore("/")
                    .ifBlank { o.optString("id", "") }
                if (id.isBlank() || id.length < 6) continue
                val title = o.optString("title", "Video")
                val author = o.optString("uploaderName", o.optString("uploader", ""))
                val thumb = o.optJSONArray("thumbnails")?.let { arr ->
                    if (arr.length() > 0) arr.getJSONObject(arr.length() - 1).optString("url", "") else ""
                }.orEmpty().ifBlank {
                    o.optString("thumbnail", "https://i.ytimg.com/vi/$id/hqdefault.jpg")
                }.ifBlank { "https://i.ytimg.com/vi/$id/hqdefault.jpg" }
                val dur = o.optLong("duration", 0L).let { sec ->
                    if (sec <= 0) "" else "%d:%02d".format(sec / 60, sec % 60)
                }
                out += VideoHit(id, title, author, thumb, dur)
            }
            return out
        } finally {
            conn.disconnect()
        }
    }
}
