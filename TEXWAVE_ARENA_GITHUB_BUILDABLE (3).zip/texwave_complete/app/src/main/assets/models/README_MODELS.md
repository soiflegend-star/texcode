# 3D Warrior Assets (required for true 3D)

Place production-ready glTF binary models here:

- `warrior_male.glb` — male warrior, idle-capable
- `warrior_female.glb` — female warrior, idle-capable
- Optional variants: `armor_*.glb`, `aura_*.glb` as separate attachments

Recommended: < 5 MB each, mobile-optimized, Y-up, meters scale.

Until these files exist, `Warrior3DView` uses a labeled **procedural fallback** (not claimed as finished 3D characters).

Sources: create in Blender / purchase mobile-ready game characters with commercial license compatible with TEXWAVE.
