package com.texgen.music.texwave.arena.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class PushUpDetectionEngineTest {

    private lateinit var engine: PushUpDetectionEngine

    @Before
    fun setup() {
        engine = PushUpDetectionEngine(
            minLandmarkConfidence = 0.5f,
            downElbowAngleDeg = 95f,
            upElbowAngleDeg = 150f,
            minBodyVisibilityJoints = 6,
            cooldownFramesAfterRep = 2
        )
    }

    private fun lm(x: Float, y: Float, v: Float = 1f) =
        PushUpDetectionEngine.Landmark(x, y, visibility = v, presence = v)

    /** Synthetic arm: shoulder, elbow, wrist positions producing ~angleDeg at elbow. */
    private fun frameForElbowAngle(angleDeg: Float, visible: Boolean = true): PushUpDetectionEngine.PoseFrame {
        val vis = if (visible) 1f else 0.1f
        // Place elbow at origin-ish; shoulder and wrist at unit vectors with given angle
        val rad = Math.toRadians(angleDeg.toDouble())
        val sx = 0.3f
        val sy = 0.3f
        val ex = 0.4f
        val ey = 0.5f
        val wx = (ex + Math.cos(rad)).toFloat() * 0.15f + 0.35f
        val wy = (ey + Math.sin(rad)).toFloat() * 0.15f + 0.45f
        // Use geometry that averageElbowAngle can compute — simpler: build via known vectors
        // Shoulder above elbow, wrist at angle
        val shoulder = lm(0.40f, 0.30f, vis)
        val elbow = lm(0.40f, 0.50f, vis)
        // wrist relative to elbow
        val wx2 = 0.40f + 0.2f * Math.cos(Math.toRadians(angleDeg.toDouble() - 90)).toFloat()
        val wy2 = 0.50f + 0.2f * Math.sin(Math.toRadians(angleDeg.toDouble() - 90)).toFloat()
        val wrist = lm(wx2, wy2, vis)
        val hip = lm(0.40f, 0.70f, vis)
        return PushUpDetectionEngine.PoseFrame(
            leftShoulder = shoulder, rightShoulder = shoulder,
            leftElbow = elbow, rightElbow = elbow,
            leftWrist = wrist, rightWrist = wrist,
            leftHip = hip, rightHip = hip,
            timestampMs = System.currentTimeMillis()
        )
    }

    @Test
    fun incompleteMovement_noRep() {
        // high only
        engine.onPose(frameForElbowAngle(160f))
        engine.onPose(frameForElbowAngle(140f))
        engine.onPose(frameForElbowAngle(160f))
        assertEquals(0, engine.currentState().repCount)
    }

    @Test
    fun fullPushUp_countsOne() {
        // Ready (up) -> down -> bottom -> up
        val sequence = listOf(165f, 160f, 140f, 120f, 100f, 90f, 100f, 120f, 145f, 155f, 165f)
        sequence.forEach { engine.onPose(frameForElbowAngle(it)) }
        assertTrue("expected at least 1 rep, got ${engine.currentState().repCount}", engine.currentState().repCount >= 1)
    }

    @Test
    fun multipleReps() {
        repeat(3) {
            listOf(165f, 150f, 120f, 90f, 120f, 150f, 165f).forEach {
                engine.onPose(frameForElbowAngle(it))
            }
            // cooldown frames
            engine.onPose(frameForElbowAngle(165f))
            engine.onPose(frameForElbowAngle(165f))
        }
        assertTrue(engine.currentState().repCount >= 2)
    }

    @Test
    fun lowVisibility_resetsToIdle() {
        engine.onPose(frameForElbowAngle(165f))
        engine.onPose(frameForElbowAngle(90f, visible = false))
        assertEquals(PushUpDetectionEngine.Phase.IDLE, engine.currentState().phase)
    }

    @Test
    fun reset_clearsCount() {
        listOf(165f, 120f, 90f, 120f, 165f).forEach { engine.onPose(frameForElbowAngle(it)) }
        engine.reset()
        assertEquals(0, engine.currentState().repCount)
        assertEquals(PushUpDetectionEngine.Phase.IDLE, engine.currentState().phase)
    }
}
