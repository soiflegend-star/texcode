package com.texgen.music.texwave.arena.domain

import com.texgen.music.texwave.arena.data.model.ActivitySource
import com.texgen.music.texwave.arena.data.model.ArenaActivity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class XpEngineTest {

    @Test
    fun levelCurve_monotonicAndMatchesBaseline() {
        assertEquals(100L, XpEngine.xpRequiredForLevel(1))
        val l10 = XpEngine.xpRequiredForLevel(10)
        val l25 = XpEngine.xpRequiredForLevel(25)
        assertTrue(l10 > 100)
        assertTrue(l25 > l10)
    }

    @Test
    fun levelFromTotalXp_roundTrip() {
        val total = 5000L
        val info = XpEngine.levelFromTotalXp(total)
        assertTrue(info.level >= 1)
        assertTrue(info.xpIntoCurrentLevel < info.xpRequiredForNextLevel)
        assertEquals(total, info.totalXp)
    }

    @Test
    fun activityXp_rejectsZeroAndOverCap() {
        val zero = ArenaActivity(userId = "u", count = 0)
        assertTrue(XpEngine.calculateActivityXp(zero, emptyList()).rejected)

        val over = ArenaActivity(userId = "u", count = 500)
        assertTrue(XpEngine.calculateActivityXp(over, emptyList()).rejected)
    }

    @Test
    fun activityXp_awardsPositiveUnderLimits() {
        val act = ArenaActivity(userId = "u", count = 20, source = ActivitySource.MANUAL)
        val r = XpEngine.calculateActivityXp(act, emptyList())
        assertFalse(r.rejected)
        assertEquals(20L, r.xpAwarded)
    }

    @Test
    fun activityXp_diminishingAbove50() {
        val act = ArenaActivity(userId = "u", count = 60, source = ActivitySource.MANUAL)
        val r = XpEngine.calculateActivityXp(act, emptyList())
        assertFalse(r.rejected)
        // 50 + 10*0.7 = 57
        assertEquals(57L, r.xpAwarded)
    }

    @Test
    fun activityXp_dailySessionCap() {
        val now = Instant.now()
        val prior = (1..12).map {
            ArenaActivity(userId = "u", count = 10, recordedAt = now.minusSeconds(it * 120L), xpAwarded = 10)
        }
        val next = ArenaActivity(userId = "u", count = 10, recordedAt = now)
        val r = XpEngine.calculateActivityXp(next, prior, now)
        assertTrue(r.rejected)
    }
}
