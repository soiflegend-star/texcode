package com.texgen.music.texwave.arena.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MatchCombatTest {
    @Test fun strikeBeatsFeint() =
        assertEquals(MatchCombat.RoundResult.A_WINS, MatchCombat.resolve(MatchCombat.Action.STRIKE, MatchCombat.Action.FEINT))
    @Test fun feintBeatsGuard() =
        assertEquals(MatchCombat.RoundResult.A_WINS, MatchCombat.resolve(MatchCombat.Action.FEINT, MatchCombat.Action.GUARD))
    @Test fun guardBeatsStrike() =
        assertEquals(MatchCombat.RoundResult.A_WINS, MatchCombat.resolve(MatchCombat.Action.GUARD, MatchCombat.Action.STRIKE))
    @Test fun draw() =
        assertEquals(MatchCombat.RoundResult.DRAW, MatchCombat.resolve(MatchCombat.Action.STRIKE, MatchCombat.Action.STRIKE))
    @Test fun eloSymmetric() {
        val d = MatchCombat.eloDelta(1000, 1000, 1.0)
        assertTrue(d > 0)
        assertEquals(-d, MatchCombat.eloDelta(1000, 1000, 0.0))
    }
}
