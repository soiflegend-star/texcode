# Build TEXWAVE (+ Arena) from GitHub

## Requirements

- Android Studio Hedgehog+ or JDK 17
- Android SDK 34
- Network for first Gradle sync

## Steps

```bash
# 1. Clone / unzip this repo
cd texwave_complete   # or repo root

# 2. SDK path
cp local.properties.example local.properties
# edit sdk.dir=...

# 3. Build debug APK
./gradlew :app:assembleDebug

# APK:
# app/build/outputs/apk/debug/app-debug.apk
```

Windows: `gradlew.bat :app:assembleDebug`

## Arena entry

Side navigation → **Arena**

## Optional assets (runtime, not required to compile)

- `app/src/main/assets/pose_landmarker_lite.task` — MediaPipe pose
- `app/src/main/assets/models/warrior_*.glb` — 3D warriors

Without these, the app **compiles and runs**; camera pose / 3D show fallback UI.

## Supabase (runtime)

Apply `supabase/arena/001`–`004` after core TEXWAVE SQL.  
After login: `ArenaModule.initSupabase(yourClientAdapter)`.

Until then Arena uses local demo repository (labeled in code).

## CI sketch

```yaml
# .github/workflows/android.yml
# on: [push]
# jobs:
#   build:
#     runs-on: ubuntu-latest
#     steps:
#       - uses: actions/checkout@v4
#       - uses: actions/setup-java@v4
#         with: { distribution: temurin, java-version: 17 }
#       - uses: android-actions/setup-android@v3
#       - run: ./gradlew :app:assembleDebug
```
