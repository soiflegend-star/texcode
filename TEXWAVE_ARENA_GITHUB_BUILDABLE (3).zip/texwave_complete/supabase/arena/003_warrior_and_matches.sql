-- Warrior loadouts + ranked match skeleton (server-authoritative results)

create table if not exists public.arena_warriors (
  user_id uuid primary key references auth.users(id) on delete cascade,
  gender text not null default 'BOY' check (gender in ('BOY','GIRL')),
  hair_id text not null default 'hair_basic',
  face_id text not null default 'face_basic',
  outfit_id text not null default 'outfit_trainee',
  gloves_id text not null default 'gloves_basic',
  armor_id text not null default 'armor_none',
  aura_id text not null default 'aura_none',
  victory_pose_id text not null default 'pose_default',
  color_theme_id text not null default 'theme_cyan',
  unlocked_cosmetics text[] not null default array['hair_basic','face_basic','outfit_trainee','gloves_basic','armor_none','aura_none','pose_default','theme_cyan'],
  competitive_rating int not null default 1000,
  wins int not null default 0,
  losses int not null default 0,
  season_wins int not null default 0,
  season_losses int not null default 0,
  updated_at timestamptz not null default now()
);

alter table public.arena_warriors enable row level security;
drop policy if exists arena_warriors_select on public.arena_warriors;
create policy arena_warriors_select on public.arena_warriors for select using (true);
-- mutations via RPC only

create table if not exists public.arena_matches (
  id uuid primary key default gen_random_uuid(),
  player_a uuid not null references auth.users(id),
  player_b uuid not null references auth.users(id),
  winner_id uuid references auth.users(id),
  status text not null default 'PENDING' check (status in ('PENDING','ACTIVE','COMPLETED','CANCELLED')),
  rating_a int not null,
  rating_b int not null,
  rating_delta_a int,
  rating_delta_b int,
  xp_a bigint default 0,
  xp_b bigint default 0,
  client_request_id text,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  unique (player_a, client_request_id)
);

alter table public.arena_matches enable row level security;
drop policy if exists arena_matches_select on public.arena_matches;
create policy arena_matches_select on public.arena_matches
  for select using (auth.uid() = player_a or auth.uid() = player_b);

create or replace function public.arena_save_warrior(
  p_gender text,
  p_hair text, p_face text, p_outfit text, p_gloves text,
  p_armor text, p_aura text, p_pose text, p_theme text
) returns public.arena_warriors
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_row public.arena_warriors;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  insert into arena_warriors(user_id, gender, hair_id, face_id, outfit_id, gloves_id, armor_id, aura_id, victory_pose_id, color_theme_id)
  values (v_uid, p_gender, p_hair, p_face, p_outfit, p_gloves, p_armor, p_aura, p_pose, p_theme)
  on conflict (user_id) do update set
    gender = excluded.gender, hair_id = excluded.hair_id, face_id = excluded.face_id,
    outfit_id = excluded.outfit_id, gloves_id = excluded.gloves_id, armor_id = excluded.armor_id,
    aura_id = excluded.aura_id, victory_pose_id = excluded.victory_pose_id, color_theme_id = excluded.color_theme_id,
    updated_at = now()
  returning * into v_row;
  return v_row;
end;
$$;

revoke all on function public.arena_save_warrior from public;
grant execute on function public.arena_save_warrior to authenticated;

-- Ranked result must only be written by secure matchmaking service / future edge function.
-- Placeholder: clients cannot insert wins directly (no insert policy on arena_matches for authenticated).
