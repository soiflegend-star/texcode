-- TEXWAVE ARENA — Server-authoritative online matches
-- Clients never write wins/losses/ratings/outcomes directly.

-- ---------------------------------------------------------------------------
-- Queue
-- ---------------------------------------------------------------------------
create table if not exists public.arena_matchmaking_queue (
  user_id uuid primary key references auth.users(id) on delete cascade,
  rating int not null default 1000,
  level int not null default 1,
  mode text not null default 'RANKED' check (mode in ('RANKED','CASUAL')),
  joined_at timestamptz not null default now()
);

alter table public.arena_matchmaking_queue enable row level security;
drop policy if exists arena_mm_queue_select on public.arena_matchmaking_queue;
create policy arena_mm_queue_select on public.arena_matchmaking_queue
  for select using (auth.uid() = user_id);
-- insert/delete only via RPC

-- ---------------------------------------------------------------------------
-- Invites / private rooms
-- ---------------------------------------------------------------------------
create table if not exists public.arena_match_invites (
  id uuid primary key default gen_random_uuid(),
  from_user uuid not null references auth.users(id),
  to_user uuid not null references auth.users(id),
  status text not null default 'PENDING'
    check (status in ('PENDING','ACCEPTED','DECLINED','CANCELLED','EXPIRED')),
  room_code text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '5 minutes')
);

create index if not exists idx_arena_invites_to on public.arena_match_invites (to_user, status);
alter table public.arena_match_invites enable row level security;
drop policy if exists arena_invites_select on public.arena_match_invites;
create policy arena_invites_select on public.arena_match_invites
  for select using (auth.uid() = from_user or auth.uid() = to_user);

-- ---------------------------------------------------------------------------
-- Matches + rounds (authoritative)
-- ---------------------------------------------------------------------------
create table if not exists public.arena_online_matches (
  id uuid primary key default gen_random_uuid(),
  player_a uuid not null references auth.users(id),
  player_b uuid not null references auth.users(id),
  mode text not null default 'RANKED',
  status text not null default 'READY'
    check (status in ('READY','ACTIVE','COMPLETED','CANCELLED','ABANDONED')),
  current_round int not null default 1 check (current_round between 1 and 3),
  score_a int not null default 0,
  score_b int not null default 0,
  rating_a int not null,
  rating_b int not null,
  winner_id uuid references auth.users(id),
  rating_delta_a int,
  rating_delta_b int,
  xp_a bigint not null default 0,
  xp_b bigint not null default 0,
  a_ready boolean not null default false,
  b_ready boolean not null default false,
  round_deadline timestamptz,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz,
  constraint arena_online_matches_distinct check (player_a <> player_b)
);

create index if not exists idx_arena_online_matches_players
  on public.arena_online_matches (player_a, status);
create index if not exists idx_arena_online_matches_players_b
  on public.arena_online_matches (player_b, status);

alter table public.arena_online_matches enable row level security;
drop policy if exists arena_online_matches_select on public.arena_online_matches;
create policy arena_online_matches_select on public.arena_online_matches
  for select using (auth.uid() = player_a or auth.uid() = player_b);
-- no direct insert/update/delete for authenticated

create table if not exists public.arena_match_actions (
  match_id uuid not null references public.arena_online_matches(id) on delete cascade,
  round int not null check (round between 1 and 3),
  user_id uuid not null references auth.users(id),
  action text not null check (action in ('STRIKE','GUARD','FEINT')),
  created_at timestamptz not null default now(),
  primary key (match_id, round, user_id)
);

alter table public.arena_match_actions enable row level security;
drop policy if exists arena_match_actions_select on public.arena_match_actions;
create policy arena_match_actions_select on public.arena_match_actions
  for select using (
    exists (
      select 1 from public.arena_online_matches m
      where m.id = match_id and (m.player_a = auth.uid() or m.player_b = auth.uid())
    )
  );

-- ---------------------------------------------------------------------------
-- Elo helper
-- ---------------------------------------------------------------------------
create or replace function public.arena_elo_delta(r_a int, r_b int, score_a float, k int default 24)
returns int language sql immutable as $$
  select greatest(-50, least(50,
    round(k * (score_a - (1.0 / (1.0 + power(10.0, (r_b - r_a) / 400.0)))))::int
  ));
$$;

-- ---------------------------------------------------------------------------
-- Join ranked queue + try pair within rating band
-- ---------------------------------------------------------------------------
create or replace function public.arena_mm_enqueue(p_mode text default 'RANKED')
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_rating int;
  v_level int;
  v_opp uuid;
  v_opp_rating int;
  v_match uuid;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;

  select coalesce(w.competitive_rating, 1000), coalesce(p.level, 1)
    into v_rating, v_level
  from arena_profiles p
  left join arena_warriors w on w.user_id = p.user_id
  where p.user_id = v_uid;

  if v_rating is null then
    -- ensure minimal profile/warrior
    insert into arena_warriors(user_id) values (v_uid) on conflict do nothing;
    v_rating := 1000; v_level := 1;
  end if;

  -- already in active match?
  if exists (
    select 1 from arena_online_matches
    where status in ('READY','ACTIVE') and (player_a = v_uid or player_b = v_uid)
  ) then
    select id into v_match from arena_online_matches
    where status in ('READY','ACTIVE') and (player_a = v_uid or player_b = v_uid)
    limit 1;
    return jsonb_build_object('status','ALREADY_IN_MATCH','match_id', v_match);
  end if;

  insert into arena_matchmaking_queue(user_id, rating, level, mode)
  values (v_uid, v_rating, v_level, coalesce(p_mode,'RANKED'))
  on conflict (user_id) do update set rating = excluded.rating, level = excluded.level,
    mode = excluded.mode, joined_at = now();

  -- find opponent: rating within 150, level within 12, oldest first
  select q.user_id, q.rating into v_opp, v_opp_rating
  from arena_matchmaking_queue q
  where q.user_id <> v_uid
    and q.mode = coalesce(p_mode,'RANKED')
    and abs(q.rating - v_rating) <= 150
    and abs(q.level - v_level) <= 12
  order by q.joined_at asc
  limit 1
  for update skip locked;

  if v_opp is null then
    return jsonb_build_object('status','QUEUED','rating', v_rating);
  end if;

  delete from arena_matchmaking_queue where user_id in (v_uid, v_opp);

  insert into arena_online_matches(player_a, player_b, mode, status, rating_a, rating_b, round_deadline)
  values (v_uid, v_opp, coalesce(p_mode,'RANKED'), 'READY', v_rating, v_opp_rating, now() + interval '60 seconds')
  returning id into v_match;

  return jsonb_build_object('status','MATCHED','match_id', v_match, 'opponent_id', v_opp);
end;
$$;

create or replace function public.arena_mm_cancel_queue()
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  delete from arena_matchmaking_queue where user_id = auth.uid();
end;
$$;

-- ---------------------------------------------------------------------------
-- Friend invite
-- ---------------------------------------------------------------------------
create or replace function public.arena_mm_invite(p_to uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_id uuid;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  if p_to = v_uid then raise exception 'Cannot invite self'; end if;
  insert into arena_match_invites(from_user, to_user)
  values (v_uid, p_to) returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.arena_mm_respond_invite(p_invite uuid, p_accept boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_inv arena_match_invites%rowtype;
  v_match uuid;
  ra int; rb int;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select * into v_inv from arena_match_invites where id = p_invite for update;
  if not found or v_inv.to_user <> v_uid or v_inv.status <> 'PENDING' then
    raise exception 'Invalid invite';
  end if;
  if v_inv.expires_at < now() then
    update arena_match_invites set status = 'EXPIRED' where id = p_invite;
    raise exception 'Invite expired';
  end if;
  if not p_accept then
    update arena_match_invites set status = 'DECLINED' where id = p_invite;
    return jsonb_build_object('status','DECLINED');
  end if;
  update arena_match_invites set status = 'ACCEPTED' where id = p_invite;

  select coalesce(competitive_rating,1000) into ra from arena_warriors where user_id = v_inv.from_user;
  select coalesce(competitive_rating,1000) into rb from arena_warriors where user_id = v_uid;
  ra := coalesce(ra,1000); rb := coalesce(rb,1000);

  insert into arena_online_matches(player_a, player_b, mode, status, rating_a, rating_b, round_deadline)
  values (v_inv.from_user, v_uid, 'CASUAL', 'READY', ra, rb, now() + interval '60 seconds')
  returning id into v_match;

  return jsonb_build_object('status','MATCHED','match_id', v_match);
end;
$$;

-- ---------------------------------------------------------------------------
-- Ready up
-- ---------------------------------------------------------------------------
create or replace function public.arena_match_ready(p_match uuid)
returns public.arena_online_matches
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_m public.arena_online_matches;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select * into v_m from arena_online_matches where id = p_match for update;
  if not found then raise exception 'Match not found'; end if;
  if v_m.player_a <> v_uid and v_m.player_b <> v_uid then raise exception 'Not a participant'; end if;
  if v_m.status not in ('READY','ACTIVE') then raise exception 'Match not joinable'; end if;

  if v_m.player_a = v_uid then
    update arena_online_matches set a_ready = true where id = p_match;
  else
    update arena_online_matches set b_ready = true where id = p_match;
  end if;

  update arena_online_matches
  set status = case when a_ready and b_ready then 'ACTIVE' else status end,
      started_at = case when a_ready and b_ready and started_at is null then now() else started_at end,
      round_deadline = case when a_ready and b_ready then now() + interval '30 seconds' else round_deadline end
  where id = p_match;

  select * into v_m from arena_online_matches where id = p_match;
  return v_m;
end;
$$;

-- ---------------------------------------------------------------------------
-- Submit round action (STRIKE/GUARD/FEINT) — RPS-like, independent of push-up totals
-- ---------------------------------------------------------------------------
create or replace function public.arena_match_submit_action(p_match uuid, p_action text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_m public.arena_online_matches;
  v_round int;
  v_other uuid;
  v_other_action text;
  v_my_action text;
  winner_side text; -- 'A' 'B' 'DRAW'
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  if p_action not in ('STRIKE','GUARD','FEINT') then raise exception 'Invalid action'; end if;

  select * into v_m from arena_online_matches where id = p_match for update;
  if not found then raise exception 'Match not found'; end if;
  if v_m.status <> 'ACTIVE' then raise exception 'Match not active'; end if;
  if v_m.player_a <> v_uid and v_m.player_b <> v_uid then raise exception 'Not a participant'; end if;

  v_round := v_m.current_round;

  insert into arena_match_actions(match_id, round, user_id, action)
  values (p_match, v_round, v_uid, p_action)
  on conflict (match_id, round, user_id) do nothing;

  -- both actions present?
  select action into v_my_action from arena_match_actions
    where match_id = p_match and round = v_round and user_id = v_uid;
  v_other := case when v_m.player_a = v_uid then v_m.player_b else v_m.player_a end;
  select action into v_other_action from arena_match_actions
    where match_id = p_match and round = v_round and user_id = v_other;

  if v_other_action is null then
    return jsonb_build_object('status','WAITING_OPPONENT','round', v_round);
  end if;

  -- resolve: STRIKE beats FEINT, FEINT beats GUARD, GUARD beats STRIKE
  winner_side := case
    when v_my_action = v_other_action then 'DRAW'
    when (v_my_action = 'STRIKE' and v_other_action = 'FEINT')
      or (v_my_action = 'FEINT' and v_other_action = 'GUARD')
      or (v_my_action = 'GUARD' and v_other_action = 'STRIKE') then
        case when v_m.player_a = v_uid then 'A' else 'B' end
    else
        case when v_m.player_a = v_uid then 'B' else 'A' end
  end;

  if winner_side = 'A' then
    update arena_online_matches set score_a = score_a + 1 where id = p_match;
  elsif winner_side = 'B' then
    update arena_online_matches set score_b = score_b + 1 where id = p_match;
  end if;

  -- next round or finish
  select * into v_m from arena_online_matches where id = p_match;
  if v_m.current_round >= 3 or v_m.score_a >= 2 or v_m.score_b >= 2 then
    perform public.arena_match_finalize(p_match);
    select * into v_m from arena_online_matches where id = p_match;
    return jsonb_build_object(
      'status','COMPLETED','round', v_round, 'round_winner', winner_side,
      'score_a', v_m.score_a, 'score_b', v_m.score_b, 'winner_id', v_m.winner_id
    );
  else
    update arena_online_matches
      set current_round = current_round + 1,
          round_deadline = now() + interval '30 seconds'
      where id = p_match;
    return jsonb_build_object(
      'status','ROUND_RESOLVED','round', v_round, 'round_winner', winner_side,
      'score_a', v_m.score_a, 'score_b', v_m.score_b, 'next_round', v_m.current_round + 1
    );
  end if;
end;
$$;

-- ---------------------------------------------------------------------------
-- Finalize: ratings + XP (transactional, once)
-- ---------------------------------------------------------------------------
create or replace function public.arena_match_finalize(p_match uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_m public.arena_online_matches;
  da int; db int;
  score_a float;
  win uuid;
  xp_win bigint := 40;
  xp_loss bigint := 15;
begin
  select * into v_m from arena_online_matches where id = p_match for update;
  if not found or v_m.status = 'COMPLETED' then return; end if;

  if v_m.score_a > v_m.score_b then
    win := v_m.player_a; score_a := 1.0;
  elsif v_m.score_b > v_m.score_a then
    win := v_m.player_b; score_a := 0.0;
  else
    win := null; score_a := 0.5;
  end if;

  da := public.arena_elo_delta(v_m.rating_a, v_m.rating_b, score_a, 24);
  db := -da;

  update arena_online_matches set
    status = 'COMPLETED',
    winner_id = win,
    rating_delta_a = da,
    rating_delta_b = db,
    xp_a = case when win = player_a then xp_win when win is null then 25 else xp_loss end,
    xp_b = case when win = player_b then xp_win when win is null then 25 else xp_loss end,
    completed_at = now()
  where id = p_match and status <> 'COMPLETED';

  -- apply rating
  insert into arena_warriors(user_id) values (v_m.player_a) on conflict do nothing;
  insert into arena_warriors(user_id) values (v_m.player_b) on conflict do nothing;

  update arena_warriors set
    competitive_rating = greatest(100, competitive_rating + da),
    wins = wins + case when win = v_m.player_a then 1 else 0 end,
    losses = losses + case when win is not null and win <> v_m.player_a then 1 else 0 end,
    season_wins = season_wins + case when win = v_m.player_a then 1 else 0 end,
    season_losses = season_losses + case when win is not null and win <> v_m.player_a then 1 else 0 end
  where user_id = v_m.player_a;

  update arena_warriors set
    competitive_rating = greatest(100, competitive_rating + db),
    wins = wins + case when win = v_m.player_b then 1 else 0 end,
    losses = losses + case when win is not null and win <> v_m.player_b then 1 else 0 end,
    season_wins = season_wins + case when win = v_m.player_b then 1 else 0 end,
    season_losses = season_losses + case when win is not null and win <> v_m.player_b then 1 else 0 end
  where user_id = v_m.player_b;

  -- XP via internal applier if present
  begin
    perform public.arena_apply_xp(v_m.player_a,
      case when win = v_m.player_a then xp_win when win is null then 25 else xp_loss end,
      'match_' || p_match::text);
    perform public.arena_apply_xp(v_m.player_b,
      case when win = v_m.player_b then xp_win when win is null then 25 else xp_loss end,
      'match_' || p_match::text);
  exception when undefined_function then
    null;
  end;
end;
$$;

create or replace function public.arena_match_abandon(p_match uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_m public.arena_online_matches;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select * into v_m from arena_online_matches where id = p_match for update;
  if not found then raise exception 'Match not found'; end if;
  if v_m.player_a <> v_uid and v_m.player_b <> v_uid then raise exception 'Not a participant'; end if;
  if v_m.status in ('COMPLETED','CANCELLED','ABANDONED') then return; end if;

  -- abandoning player loses
  if v_m.player_a = v_uid then
    update arena_online_matches set score_b = greatest(score_b, 2), score_a = least(score_a, 1) where id = p_match;
  else
    update arena_online_matches set score_a = greatest(score_a, 2), score_b = least(score_b, 1) where id = p_match;
  end if;
  update arena_online_matches set status = 'ABANDONED' where id = p_match;
  perform public.arena_match_finalize(p_match);
end;
$$;

revoke all on function public.arena_mm_enqueue from public;
revoke all on function public.arena_mm_cancel_queue from public;
revoke all on function public.arena_mm_invite from public;
revoke all on function public.arena_mm_respond_invite from public;
revoke all on function public.arena_match_ready from public;
revoke all on function public.arena_match_submit_action from public;
revoke all on function public.arena_match_finalize from public;
revoke all on function public.arena_match_abandon from public;

grant execute on function public.arena_mm_enqueue to authenticated;
grant execute on function public.arena_mm_cancel_queue to authenticated;
grant execute on function public.arena_mm_invite to authenticated;
grant execute on function public.arena_mm_respond_invite to authenticated;
grant execute on function public.arena_match_ready to authenticated;
grant execute on function public.arena_match_submit_action to authenticated;
grant execute on function public.arena_match_abandon to authenticated;
-- finalize NOT granted to clients (only internal / called from submit)
