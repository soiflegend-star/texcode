-- TEXWAVE ARENA — RLS + authoritative RPCs (idempotent)
-- Clients MUST NOT write XP, levels, claims, or roles directly.

-- Enable RLS
alter table public.arena_profiles enable row level security;
alter table public.arena_activities enable row level security;
alter table public.arena_xp_transactions enable row level security;
alter table public.arena_challenges enable row level security;
alter table public.arena_challenge_participants enable row level security;
alter table public.arena_leaderboard_snapshots enable row level security;
alter table public.arena_squads enable row level security;
alter table public.arena_squad_members enable row level security;
alter table public.arena_squad_invites enable row level security;
alter table public.arena_achievements enable row level security;
alter table public.arena_user_achievements enable row level security;
alter table public.arena_daily_missions enable row level security;
alter table public.arena_mission_progress enable row level security;

-- Drop legacy permissive policies if re-run
do $$
declare r record;
begin
  for r in
    select policyname, tablename from pg_policies
    where schemaname = 'public' and tablename like 'arena_%'
  loop
    execute format('drop policy if exists %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;

-- READ policies
create policy arena_profiles_select on public.arena_profiles for select using (true);
create policy arena_activities_select_own on public.arena_activities for select using (auth.uid() = user_id);
create policy arena_xp_tx_select_own on public.arena_xp_transactions for select using (auth.uid() = user_id);
create policy arena_challenges_select on public.arena_challenges for select using (true);
create policy arena_chal_part_select on public.arena_challenge_participants for select using (true);
create policy arena_lb_select on public.arena_leaderboard_snapshots for select using (true);
create policy arena_squads_select on public.arena_squads for select using (true);
create policy arena_squad_members_select on public.arena_squad_members for select using (true);
create policy arena_squad_invites_select on public.arena_squad_invites
  for select using (auth.uid() = invitee_id or auth.uid() = inviter_id);
create policy arena_achievements_select on public.arena_achievements for select using (true);
create policy arena_user_ach_select on public.arena_user_achievements for select using (true);
create policy arena_missions_select on public.arena_daily_missions for select using (true);
create policy arena_mission_prog_select on public.arena_mission_progress for select using (auth.uid() = user_id);

-- NO direct insert/update/delete on XP-bearing tables for authenticated role.
-- All mutations go through SECURITY DEFINER functions below.

-- Profile: user may only set display fields on own row (not XP/level)
-- Clients must NOT update progression columns. Only display fields via RPC.
-- No general UPDATE policy on arena_profiles for authenticated.

create or replace function public.arena_update_profile_display(
  p_display_name text default null,
  p_avatar_url text default null
) returns public.arena_profiles
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_row public.arena_profiles;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  update arena_profiles set
    display_name = coalesce(p_display_name, display_name),
    avatar_url = coalesce(p_avatar_url, avatar_url),
    updated_at = now()
  where user_id = v_uid
  returning * into v_row;
  if not found then raise exception 'Profile missing'; end if;
  return v_row;
end;
$$;

revoke all on function public.arena_update_profile_display from public;
grant execute on function public.arena_update_profile_display to authenticated;

-- Hard guard: block direct changes to progression columns even if a policy is added later
create or replace function public.arena_profiles_block_progression_mutation()
returns trigger language plpgsql as $$
begin
  if tg_op = 'UPDATE' and current_user not in ('postgres', 'supabase_admin', 'service_role') then
    if new.total_xp is distinct from old.total_xp
       or new.level is distinct from old.level
       or new.xp_into_level is distinct from old.xp_into_level
       or new.xp_required_next is distinct from old.xp_required_next
       or new.total_push_ups is distinct from old.total_push_ups
       or new.weekly_xp is distinct from old.weekly_xp
       or new.monthly_xp is distinct from old.monthly_xp
       or new.daily_xp is distinct from old.daily_xp
       or new.squad_id is distinct from old.squad_id then
      -- Allow security definer functions running as owner; block table-owner client paths
      if session_user = 'authenticated' or current_setting('role', true) = 'authenticated' then
        raise exception 'Progression columns are server-managed';
      end if;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_arena_profiles_block_progression on public.arena_profiles;
create trigger trg_arena_profiles_block_progression
  before update on public.arena_profiles
  for each row execute function public.arena_profiles_block_progression_mutation();

-- Helper: level curve (mirrors XpEngine)
create or replace function public.arena_xp_required_for_level(p_level int)
returns bigint language sql immutable as $$
  select greatest(100, (100.0 * power(p_level::double precision, 1.35))::bigint);
$$;

create or replace function public.arena_recompute_level(p_total_xp bigint)
returns table(level int, xp_into bigint, xp_next bigint)
language plpgsql immutable as $$
declare
  rem bigint := greatest(p_total_xp, 0);
  lvl int := 1;
  need bigint;
begin
  loop
    need := public.arena_xp_required_for_level(lvl);
    if rem < need or lvl >= 200 then
      level := lvl; xp_into := rem; xp_next := need;
      return next;
      return;
    end if;
    rem := rem - need;
    lvl := lvl + 1;
  end loop;
end;
$$;

create or replace function public.arena_roll_period_stats(p_user uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  d date := (timezone('utc', now()))::date;
  w text := to_char(timezone('utc', now()), 'IYYY-IW');
  m text := to_char(timezone('utc', now()), 'YYYY-MM');
begin
  update arena_profiles set
    daily_xp = case when stats_day = d then daily_xp else 0 end,
    weekly_xp = case when stats_week = w then weekly_xp else 0 end,
    monthly_xp = case when stats_month = m then monthly_xp else 0 end,
    stats_day = d, stats_week = w, stats_month = m
  where user_id = p_user;
end;
$$;

create or replace function public.arena_apply_xp(
  p_user uuid,
  p_amount bigint,
  p_reason text,
  p_activity uuid default null,
  p_challenge uuid default null,
  p_mission text default null,
  p_achievement text default null
) returns void language plpgsql security definer set search_path = public as $$
declare
  li record;
  new_total bigint;
begin
  if p_amount is null or p_amount <= 0 then return; end if;
  perform public.arena_roll_period_stats(p_user);

  insert into arena_xp_transactions(user_id, amount, reason, activity_id, challenge_id, mission_id, achievement_id)
  values (p_user, p_amount, p_reason, p_activity, p_challenge, p_mission, p_achievement);

  update arena_profiles
  set total_xp = total_xp + p_amount,
      daily_xp = daily_xp + p_amount,
      weekly_xp = weekly_xp + p_amount,
      monthly_xp = monthly_xp + p_amount,
      updated_at = now()
  where user_id = p_user
  returning total_xp into new_total;

  select * into li from public.arena_recompute_level(new_total);
  update arena_profiles
  set level = li.level, xp_into_level = li.xp_into, xp_required_next = li.xp_next
  where user_id = p_user;

  -- squad contribution
  update arena_squad_members sm
  set contribution_xp = contribution_xp + p_amount
  where sm.user_id = p_user;

  update arena_squads s
  set total_xp = (select coalesce(sum(contribution_xp),0) from arena_squad_members where squad_id = s.id)
  where s.id = (select squad_id from arena_profiles where user_id = p_user);
end;
$$;

-- Ensure profile exists
create or replace function public.arena_ensure_profile(
  p_username text,
  p_display_name text default null,
  p_avatar text default null
) returns public.arena_profiles
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_row public.arena_profiles;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  insert into arena_profiles(user_id, username, display_name, avatar_url)
  values (v_uid, coalesce(nullif(p_username,''), 'player'), p_display_name, p_avatar)
  on conflict (user_id) do update
    set username = excluded.username,
        display_name = coalesce(excluded.display_name, arena_profiles.display_name),
        avatar_url = coalesce(excluded.avatar_url, arena_profiles.avatar_url),
        updated_at = now()
  returning * into v_row;
  return v_row;
end;
$$;

-- Authoritative activity log (NO client-set XP, NO verified flag for manual)
create or replace function public.arena_award_activity_xp(
  p_count int,
  p_source text default 'MANUAL',
  p_note text default null,
  p_client_request_id text default null,
  p_performed_at timestamptz default now()
) returns public.arena_activities
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_xp bigint;
  v_act public.arena_activities;
  v_today_count int;
  v_today_xp bigint;
  v_last timestamptz;
  v_src text;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  if p_count is null or p_count < 1 or p_count > 200 then
    raise exception 'Invalid count (1-200)';
  end if;

  -- Camera path is reserved; until real recognition ships, force MANUAL unverified
  v_src := 'MANUAL';
  if p_source is not null and upper(p_source) = 'IMPORT' then
    v_src := 'IMPORT';
  end if;

  select count(*), coalesce(sum(xp_awarded),0), max(recorded_at)
    into v_today_count, v_today_xp, v_last
  from arena_activities
  where user_id = v_uid and recorded_at::date = (timezone('utc', now()))::date;

  if v_today_count >= 12 then raise exception 'Daily session limit reached'; end if;
  if v_last is not null and extract(epoch from (now() - v_last)) < 45 then
    raise exception 'Please wait before logging again';
  end if;

  if p_count <= 50 then v_xp := p_count;
  else v_xp := 50 + ((p_count - 50) * 0.7)::bigint; end if;
  if v_src = 'IMPORT' then v_xp := (v_xp * 0.8)::bigint; end if;

  if v_today_xp >= 350 then raise exception 'Daily activity XP cap reached'; end if;
  if v_today_xp + v_xp > 350 then v_xp := greatest(0, 350 - v_today_xp); end if;
  if v_xp <= 0 then raise exception 'No XP available under daily cap'; end if;

  insert into arena_activities(
    user_id, count, source, note, xp_awarded, is_verified, client_request_id, performed_at
  ) values (
    v_uid, p_count, v_src, left(p_note, 200), v_xp, false, p_client_request_id, p_performed_at
  ) returning * into v_act;

  update arena_profiles set total_push_ups = total_push_ups + p_count where user_id = v_uid;
  perform public.arena_apply_xp(v_uid, v_xp, 'push_ups_' || p_count, v_act.id);

  -- daily mission progress (UTC day)
  insert into arena_mission_progress(user_id, mission_id, date_key, progress, is_completed)
  values
    (v_uid, 'm-log-session', (timezone('utc', now()))::date, 1, true),
    (v_uid, 'm-20-reps', (timezone('utc', now()))::date,
       least(20, (select coalesce(sum(count),0) from arena_activities
                  where user_id = v_uid and recorded_at::date = (timezone('utc', now()))::date)),
       (select coalesce(sum(count),0) from arena_activities
        where user_id = v_uid and recorded_at::date = (timezone('utc', now()))::date) >= 20)
  on conflict (user_id, mission_id, date_key) do update set
    progress = excluded.progress,
    is_completed = excluded.is_completed;

  -- refresh challenge progress for joined active challenges
  update arena_challenge_participants cp
  set progress = least(
      c.target_count,
      (select coalesce(sum(a.count),0) from arena_activities a
       where a.user_id = v_uid
         and a.recorded_at >= greatest(c.start_at, cp.joined_at)
         and a.recorded_at < c.end_at)
    ),
    is_completed = (
      least(
        c.target_count,
        (select coalesce(sum(a.count),0) from arena_activities a
         where a.user_id = v_uid
           and a.recorded_at >= greatest(c.start_at, cp.joined_at)
           and a.recorded_at < c.end_at)
      ) >= c.target_count
    ),
    completed_at = case when (
      least(
        c.target_count,
        (select coalesce(sum(a.count),0) from arena_activities a
         where a.user_id = v_uid
           and a.recorded_at >= greatest(c.start_at, cp.joined_at)
           and a.recorded_at < c.end_at)
      ) >= c.target_count
    ) then coalesce(cp.completed_at, now()) else cp.completed_at end
  from arena_challenges c
  where cp.challenge_id = c.id and cp.user_id = v_uid
    and now() < c.end_at and not cp.is_claimed;

  return v_act;
exception
  when unique_violation then
    raise exception 'Duplicate submission';
end;
$$;

create or replace function public.arena_join_challenge(p_challenge_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_end timestamptz;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select end_at into v_end from arena_challenges where id = p_challenge_id;
  if v_end is null then raise exception 'Challenge not found'; end if;
  if now() >= v_end then raise exception 'Challenge has ended'; end if;
  insert into arena_challenge_participants(challenge_id, user_id)
  values (p_challenge_id, v_uid)
  on conflict do nothing;
end;
$$;

create or replace function public.arena_claim_challenge(p_challenge_id uuid)
returns bigint language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_reward bigint;
  v_part arena_challenge_participants%rowtype;
  v_target int;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select * into v_part from arena_challenge_participants
    where challenge_id = p_challenge_id and user_id = v_uid for update;
  if not found then raise exception 'Not joined'; end if;
  if v_part.is_claimed then raise exception 'Already claimed'; end if;
  select target_count, xp_reward into v_target, v_reward from arena_challenges where id = p_challenge_id;
  if v_part.progress < v_target and not v_part.is_completed then
    raise exception 'Challenge not completed';
  end if;
  update arena_challenge_participants
    set is_claimed = true, is_completed = true, claimed_at = now(),
        completed_at = coalesce(completed_at, now())
    where challenge_id = p_challenge_id and user_id = v_uid and is_claimed = false;
  if not found then raise exception 'Already claimed'; end if;
  perform public.arena_apply_xp(v_uid, v_reward, 'challenge_' || p_challenge_id::text, null, p_challenge_id);
  return v_reward;
end;
$$;

create or replace function public.arena_claim_mission(p_mission_id text)
returns bigint language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_day date := (timezone('utc', now()))::date;
  v_prog arena_mission_progress%rowtype;
  v_reward bigint;
  v_target int;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select xp_reward, target into v_reward, v_target from arena_daily_missions where id = p_mission_id;
  if v_reward is null then raise exception 'Mission not found'; end if;
  select * into v_prog from arena_mission_progress
    where user_id = v_uid and mission_id = p_mission_id and date_key = v_day for update;
  if not found then raise exception 'No progress today'; end if;
  if v_prog.is_claimed then raise exception 'Already claimed'; end if;
  if v_prog.progress < v_target then raise exception 'Mission not completed'; end if;
  update arena_mission_progress
    set is_claimed = true, is_completed = true, claimed_at = now()
    where user_id = v_uid and mission_id = p_mission_id and date_key = v_day and is_claimed = false;
  if not found then raise exception 'Already claimed'; end if;
  perform public.arena_apply_xp(v_uid, v_reward, 'mission_' || p_mission_id, null, null, p_mission_id);
  return v_reward;
end;
$$;

create or replace function public.arena_mark_leaderboard_visited()
returns void language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_day date := (timezone('utc', now()))::date;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  insert into arena_mission_progress(user_id, mission_id, date_key, progress, is_completed)
  values (v_uid, 'm-check-ranks', v_day, 1, true)
  on conflict (user_id, mission_id, date_key) do update
    set progress = greatest(arena_mission_progress.progress, 1),
        is_completed = true;
end;
$$;

create or replace function public.arena_create_squad(p_name text, p_description text default '')
returns public.arena_squads
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_squad public.arena_squads;
  v_existing uuid;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  if p_name is null or char_length(trim(p_name)) < 1 or char_length(p_name) > 24 then
    raise exception 'Invalid squad name';
  end if;
  select squad_id into v_existing from arena_profiles where user_id = v_uid;
  if v_existing is not null then raise exception 'Already in a squad'; end if;

  insert into arena_squads(name, description, owner_id)
  values (trim(p_name), left(coalesce(p_description,''), 120), v_uid)
  returning * into v_squad;

  insert into arena_squad_members(squad_id, user_id, role)
  values (v_squad.id, v_uid, 'OWNER');

  update arena_profiles set squad_id = v_squad.id where user_id = v_uid;
  return v_squad;
end;
$$;

create or replace function public.arena_leave_squad()
returns void language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_squad uuid;
  v_role text;
  v_count int;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select squad_id into v_squad from arena_profiles where user_id = v_uid;
  if v_squad is null then raise exception 'Not in a squad'; end if;
  select role into v_role from arena_squad_members where squad_id = v_squad and user_id = v_uid;
  select count(*) into v_count from arena_squad_members where squad_id = v_squad;
  if v_role = 'OWNER' and v_count > 1 then
    raise exception 'Transfer ownership before leaving';
  end if;
  delete from arena_squad_members where squad_id = v_squad and user_id = v_uid;
  update arena_profiles set squad_id = null where user_id = v_uid;
  if v_count <= 1 then delete from arena_squads where id = v_squad; end if;
end;
$$;

create or replace function public.arena_invite_to_squad(p_invitee uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_squad uuid;
  v_role text;
  v_id uuid;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select squad_id into v_squad from arena_profiles where user_id = v_uid;
  if v_squad is null then raise exception 'Not in a squad'; end if;
  select role into v_role from arena_squad_members where squad_id = v_squad and user_id = v_uid;
  if v_role not in ('OWNER', 'ADMIN') then raise exception 'Insufficient permissions'; end if;
  insert into arena_squad_invites(squad_id, inviter_id, invitee_id)
  values (v_squad, v_uid, p_invitee) returning id into v_id;
  return v_id;
end;
$$;

create or replace function public.arena_accept_invite(p_invite_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_inv arena_squad_invites%rowtype;
  v_existing uuid;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select * into v_inv from arena_squad_invites where id = p_invite_id for update;
  if not found or v_inv.invitee_id <> v_uid or v_inv.status <> 'PENDING' then
    raise exception 'Invalid invite';
  end if;
  select squad_id into v_existing from arena_profiles where user_id = v_uid;
  if v_existing is not null then raise exception 'Already in a squad'; end if;
  insert into arena_squad_members(squad_id, user_id, role) values (v_inv.squad_id, v_uid, 'MEMBER');
  update arena_profiles set squad_id = v_inv.squad_id where user_id = v_uid;
  update arena_squad_invites set status = 'ACCEPTED' where id = p_invite_id;
end;
$$;

create or replace function public.arena_remove_member(p_member uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_squad uuid;
  v_role text;
  v_target_role text;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  select squad_id into v_squad from arena_profiles where user_id = v_uid;
  select role into v_role from arena_squad_members where squad_id = v_squad and user_id = v_uid;
  select role into v_target_role from arena_squad_members where squad_id = v_squad and user_id = p_member;
  if v_role not in ('OWNER', 'ADMIN') then raise exception 'Insufficient permissions'; end if;
  if v_target_role = 'OWNER' then raise exception 'Cannot remove owner'; end if;
  if v_role = 'ADMIN' and v_target_role = 'ADMIN' then raise exception 'Admins cannot remove admins'; end if;
  delete from arena_squad_members where squad_id = v_squad and user_id = p_member;
  update arena_profiles set squad_id = null where user_id = p_member and squad_id = v_squad;
end;
$$;

create or replace function public.arena_set_member_role(p_member uuid, p_role text)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_squad uuid;
  v_role text;
begin
  if v_uid is null then raise exception 'Not authenticated'; end if;
  if p_role not in ('ADMIN', 'MEMBER') then raise exception 'Invalid role'; end if;
  select squad_id into v_squad from arena_profiles where user_id = v_uid;
  select role into v_role from arena_squad_members where squad_id = v_squad and user_id = v_uid;
  if v_role <> 'OWNER' then raise exception 'Only owner can change roles'; end if;
  if p_member = v_uid then raise exception 'Cannot change own role this way'; end if;
  update arena_squad_members set role = p_role where squad_id = v_squad and user_id = p_member;
end;
$$;

-- Leaderboard page (server-side ranking)
create or replace function public.arena_leaderboard(
  p_scope text,
  p_limit int default 50,
  p_offset int default 0
) returns table(
  rank bigint,
  user_id uuid,
  username text,
  display_name text,
  avatar_url text,
  level int,
  xp bigint,
  push_ups bigint
) language plpgsql security definer set search_path = public stable as $$
begin
  if p_scope = 'GLOBAL_WEEKLY' then
    return query
      select row_number() over (order by p.weekly_xp desc, p.username),
             p.user_id, p.username, p.display_name, p.avatar_url, p.level, p.weekly_xp, p.total_push_ups
      from arena_profiles p order by p.weekly_xp desc, p.username
      limit greatest(p_limit,1) offset greatest(p_offset,0);
  elsif p_scope = 'GLOBAL_MONTHLY' then
    return query
      select row_number() over (order by p.monthly_xp desc, p.username),
             p.user_id, p.username, p.display_name, p.avatar_url, p.level, p.monthly_xp, p.total_push_ups
      from arena_profiles p order by p.monthly_xp desc, p.username
      limit greatest(p_limit,1) offset greatest(p_offset,0);
  elsif p_scope = 'GLOBAL_DAILY' then
    return query
      select row_number() over (order by p.daily_xp desc, p.username),
             p.user_id, p.username, p.display_name, p.avatar_url, p.level, p.daily_xp, p.total_push_ups
      from arena_profiles p order by p.daily_xp desc, p.username
      limit greatest(p_limit,1) offset greatest(p_offset,0);
  else
    return query
      select row_number() over (order by p.total_xp desc, p.username),
             p.user_id, p.username, p.display_name, p.avatar_url, p.level, p.total_xp, p.total_push_ups
      from arena_profiles p order by p.total_xp desc, p.username
      limit greatest(p_limit,1) offset greatest(p_offset,0);
  end if;
end;
$$;

-- Grants: execute RPCs only; no table writes for authenticated on sensitive tables
revoke all on function public.arena_award_activity_xp from public;
revoke all on function public.arena_apply_xp from public;
revoke all on function public.arena_claim_challenge from public;
revoke all on function public.arena_claim_mission from public;
revoke all on function public.arena_create_squad from public;
revoke all on function public.arena_leave_squad from public;
revoke all on function public.arena_invite_to_squad from public;
revoke all on function public.arena_accept_invite from public;
revoke all on function public.arena_remove_member from public;
revoke all on function public.arena_set_member_role from public;
revoke all on function public.arena_join_challenge from public;
revoke all on function public.arena_ensure_profile from public;
revoke all on function public.arena_mark_leaderboard_visited from public;
revoke all on function public.arena_leaderboard from public;

grant execute on function public.arena_award_activity_xp to authenticated;
grant execute on function public.arena_claim_challenge to authenticated;
grant execute on function public.arena_claim_mission to authenticated;
grant execute on function public.arena_create_squad to authenticated;
grant execute on function public.arena_leave_squad to authenticated;
grant execute on function public.arena_invite_to_squad to authenticated;
grant execute on function public.arena_accept_invite to authenticated;
grant execute on function public.arena_remove_member to authenticated;
grant execute on function public.arena_set_member_role to authenticated;
grant execute on function public.arena_join_challenge to authenticated;
grant execute on function public.arena_ensure_profile to authenticated;
grant execute on function public.arena_mark_leaderboard_visited to authenticated;
grant execute on function public.arena_leaderboard to authenticated;
-- arena_apply_xp NOT granted to authenticated — internal only
