-- TEXWAVE ARENA — Schema (idempotent)
create extension if not exists "pgcrypto";

create table if not exists public.arena_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  display_name text,
  avatar_url text,
  level int not null default 1 check (level >= 1 and level <= 200),
  total_xp bigint not null default 0 check (total_xp >= 0),
  xp_into_level bigint not null default 0 check (xp_into_level >= 0),
  xp_required_next bigint not null default 100 check (xp_required_next > 0),
  total_push_ups bigint not null default 0 check (total_push_ups >= 0),
  weekly_xp bigint not null default 0 check (weekly_xp >= 0),
  monthly_xp bigint not null default 0 check (monthly_xp >= 0),
  daily_xp bigint not null default 0 check (daily_xp >= 0),
  stats_day date not null default (timezone('utc', now()))::date,
  stats_week text not null default to_char(timezone('utc', now()), 'IYYY-IW'),
  stats_month text not null default to_char(timezone('utc', now()), 'YYYY-MM'),
  squad_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_arena_profiles_total_xp on public.arena_profiles (total_xp desc);
create index if not exists idx_arena_profiles_weekly_xp on public.arena_profiles (weekly_xp desc);
create index if not exists idx_arena_profiles_monthly_xp on public.arena_profiles (monthly_xp desc);
create index if not exists idx_arena_profiles_username on public.arena_profiles (username);

create table if not exists public.arena_activities (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  activity_type text not null default 'PUSH_UPS',
  count int not null check (count > 0 and count <= 200),
  source text not null default 'MANUAL' check (source in ('MANUAL', 'CAMERA_ASSISTED', 'IMPORT')),
  performed_at timestamptz not null default now(),
  recorded_at timestamptz not null default now(),
  note text,
  xp_awarded bigint not null default 0 check (xp_awarded >= 0),
  is_verified boolean not null default false,
  client_request_id text,
  constraint arena_activities_idempotent unique (user_id, client_request_id)
);

create index if not exists idx_arena_activities_user_recorded
  on public.arena_activities (user_id, recorded_at desc);

create table if not exists public.arena_xp_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount bigint not null check (amount > 0),
  reason text not null,
  activity_id uuid references public.arena_activities(id),
  challenge_id uuid,
  mission_id text,
  achievement_id text,
  created_at timestamptz not null default now()
);

create index if not exists idx_arena_xp_tx_user on public.arena_xp_transactions (user_id, created_at desc);

create table if not exists public.arena_challenges (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null,
  difficulty text not null,
  period text not null check (period in ('DAILY', 'WEEKLY', 'MONTHLY', 'SPECIAL')),
  activity_type text not null default 'PUSH_UPS',
  target_count int not null check (target_count > 0),
  start_at timestamptz not null,
  end_at timestamptz not null,
  xp_reward bigint not null default 0 check (xp_reward >= 0),
  is_global boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.arena_challenge_participants (
  challenge_id uuid not null references public.arena_challenges(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  progress int not null default 0,
  is_completed boolean not null default false,
  is_claimed boolean not null default false,
  completed_at timestamptz,
  claimed_at timestamptz,
  primary key (challenge_id, user_id)
);

create table if not exists public.arena_leaderboard_snapshots (
  id bigserial primary key,
  scope text not null,
  period_key text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  rank int not null,
  xp bigint not null,
  level int not null,
  push_ups bigint not null default 0,
  captured_at timestamptz not null default now(),
  unique (scope, period_key, user_id)
);

create index if not exists idx_arena_lb_scope_period_rank
  on public.arena_leaderboard_snapshots (scope, period_key, rank);

create table if not exists public.arena_squads (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 24),
  description text default '',
  avatar_url text,
  owner_id uuid not null references auth.users(id),
  total_xp bigint not null default 0,
  level int not null default 1,
  created_at timestamptz not null default now()
);

create table if not exists public.arena_squad_members (
  squad_id uuid not null references public.arena_squads(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'MEMBER' check (role in ('OWNER', 'ADMIN', 'MEMBER')),
  contribution_xp bigint not null default 0,
  joined_at timestamptz not null default now(),
  primary key (squad_id, user_id)
);

create table if not exists public.arena_squad_invites (
  id uuid primary key default gen_random_uuid(),
  squad_id uuid not null references public.arena_squads(id) on delete cascade,
  inviter_id uuid not null references auth.users(id),
  invitee_id uuid not null references auth.users(id),
  status text not null default 'PENDING' check (status in ('PENDING', 'ACCEPTED', 'DECLINED', 'REVOKED')),
  created_at timestamptz not null default now()
);

create unique index if not exists idx_arena_squad_invites_pending
  on public.arena_squad_invites (squad_id, invitee_id) where status = 'PENDING';

do $$ begin
  alter table public.arena_profiles drop constraint if exists fk_arena_profiles_squad;
  alter table public.arena_profiles
    add constraint fk_arena_profiles_squad
    foreign key (squad_id) references public.arena_squads(id) on delete set null;
exception when others then null;
end $$;

create table if not exists public.arena_achievements (
  id text primary key,
  title text not null,
  description text not null,
  icon_key text not null,
  xp_reward bigint not null default 0
);

create table if not exists public.arena_user_achievements (
  user_id uuid not null references auth.users(id) on delete cascade,
  achievement_id text not null references public.arena_achievements(id),
  unlocked_at timestamptz not null default now(),
  xp_claimed boolean not null default true,
  primary key (user_id, achievement_id)
);

create table if not exists public.arena_daily_missions (
  id text primary key,
  title text not null,
  description text not null,
  target int not null,
  xp_reward bigint not null,
  kind text not null default 'activity'
);

create table if not exists public.arena_mission_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  mission_id text not null references public.arena_daily_missions(id),
  date_key date not null,
  progress int not null default 0,
  is_completed boolean not null default false,
  is_claimed boolean not null default false,
  claimed_at timestamptz,
  primary key (user_id, mission_id, date_key)
);

insert into public.arena_achievements (id, title, description, icon_key, xp_reward) values
  ('first_session', 'First Session', 'Complete your first recorded session', 'first_session', 20),
  ('consistency_3', 'Consistency', 'Log activity on 3 different days', 'consistency', 40),
  ('weekly_warrior', 'Weekly Warrior', 'Complete a weekly challenge', 'weekly', 50),
  ('rising_player', 'Rising Player', 'Reach level 10', 'rising', 50),
  ('centurion', 'Centurion', 'Log 100 total push-ups', 'centurion', 30),
  ('global_competitor', 'Global Competitor', 'Participate in a global challenge', 'global', 35),
  ('squad_contributor', 'Squad Contributor', 'Contribute to a squad', 'squad', 25),
  ('level_25', 'Veteran', 'Reach level 25', 'veteran', 120),
  ('thousand_reps', 'Thousand Club', 'Accumulate 1 000 push-ups', 'thousand', 100)
on conflict (id) do nothing;

insert into public.arena_daily_missions (id, title, description, target, xp_reward, kind) values
  ('m-log-session', 'Log one session', 'Record any push-up session today', 1, 15, 'activity'),
  ('m-20-reps', 'Hit 20 push-ups', 'Complete at least 20 reps today', 20, 25, 'activity'),
  ('m-check-ranks', 'Check the ranks', 'Visit the global leaderboard', 1, 10, 'check')
on conflict (id) do nothing;
