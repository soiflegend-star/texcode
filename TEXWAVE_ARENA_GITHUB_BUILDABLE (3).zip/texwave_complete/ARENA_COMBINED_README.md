# TEXWAVE + ARENA (combined)

This archive is the **full TEXWAVE reference project** (~29 MB uncompressed source tree) with the Arena module merged in.

## Arena entry

Side navigation → **Arena** → `ArenaEntry`

## Added

- `app/src/main/java/com/texgen/music/texwave/arena/**`
- CameraX + MediaPipe + SceneView in `app/build.gradle.kts`
- CAMERA permission in manifest
- SQL: `supabase/arena/001`–`004`
- Docs: `docs/arena/`

## Still required on your machine

1. `./gradlew :app:assembleDebug` (Android SDK)
2. `pose_landmarker_lite.task` for camera pose
3. Optional warrior GLBs under `app/src/main/assets/models/`
4. Apply `supabase/arena/*.sql` and `ArenaModule.initSupabase` after login
