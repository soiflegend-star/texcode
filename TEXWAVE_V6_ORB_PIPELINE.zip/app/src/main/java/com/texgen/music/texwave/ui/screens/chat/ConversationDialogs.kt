package com.texgen.music.texwave.ui.screens.chat

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.chat.ChatMessageUi
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.ChatThemeStore
import com.texgen.music.texwave.data.chat.MemoryCapsuleStore
import com.texgen.music.texwave.data.chat.Message
import com.texgen.music.texwave.data.chat.Resonance
import com.texgen.music.texwave.data.chat.SharedSoundtrackStore
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun ResonancePickerDialog(
    librarySongs: List<Song>,
    conversationId: String,
    repo: ChatRepository,
    messages: androidx.compose.runtime.snapshots.SnapshotStateList<ChatMessageUi>,
    onDismiss: () -> Unit,
    onError: (String?) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var resonanceQuery = remember { androidx.compose.runtime.mutableStateOf("") }
    var resonanceMood = remember { androidx.compose.runtime.mutableStateOf(Resonance.moods.first()) }
    val filtered = remember(resonanceQuery.value, librarySongs) {
        val q = resonanceQuery.value.trim().lowercase()
        librarySongs.filter {
            q.isEmpty() || it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
        }.take(40)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Resonance") },
        text = {
            Column {
                Text("Share a song from your library with a mood.", color = Tx.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = resonanceQuery.value,
                    onValueChange = { resonanceQuery.value = it },
                    placeholder = { Text("Search library…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Text("Mood", color = Tx.Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    Resonance.moods.forEach { m ->
                        val sel = m == resonanceMood.value
                        Text(
                            m,
                            color = if (sel) Color.Black else Tx.Text,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(end = 6.dp, top = 6.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (sel) Tx.Accent else Tx.SurfaceHigh)
                                .clickable { resonanceMood.value = m }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Column(Modifier.height(220.dp)) {
                    filtered.forEach { song ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    // Do NOT dismiss first — that cancels rememberCoroutineScope
                                    scope.launch {
                                        try {
                                            val payload = Resonance.fromSong(song, resonanceMood.value)
                                            val localId = UUID.randomUUID().toString()
                                            val encoded = payload.encode()
                                            val local = ChatMessageUi(
                                                message = Message(
                                                    id = "local-$localId",
                                                    conversationId = conversationId,
                                                    senderId = "",
                                                    body = encoded,
                                                    clientMsgId = localId,
                                                ),
                                                isMine = true,
                                                isPending = true,
                                            )
                                            messages.add(local)
                                            SharedSoundtrackStore.add(context, conversationId, payload, true)
                                            // Prefer plain sendText — always reliable for Resonance cards
                                            val result = repo.sendText(conversationId, encoded, localId)
                                            result.fold(
                                                onSuccess = { m ->
                                                    val i = messages.indexOfFirst {
                                                        it.message.clientMsgId == localId || it.message.id == local.message.id
                                                    }
                                                    if (i >= 0) messages[i] = ChatMessageUi(message = m, isMine = true)
                                                    Toast.makeText(
                                                        context,
                                                        "Resonance sent · ${song.title}",
                                                        Toast.LENGTH_SHORT,
                                                    ).show()
                                                    onDismiss()
                                                },
                                                onFailure = { e ->
                                                    // One more try via sendResonance
                                                    repo.sendResonance(conversationId, payload, localId, audioUri = null)
                                                        .onSuccess { m ->
                                                            val i = messages.indexOfFirst {
                                                                it.message.clientMsgId == localId || it.message.id == local.message.id
                                                            }
                                                            if (i >= 0) messages[i] = ChatMessageUi(message = m, isMine = true)
                                                            Toast.makeText(context, "Resonance sent", Toast.LENGTH_SHORT).show()
                                                            onDismiss()
                                                        }
                                                        .onFailure { e2 ->
                                                            val i = messages.indexOfFirst {
                                                                it.message.clientMsgId == localId || it.message.id == local.message.id
                                                            }
                                                            if (i >= 0) messages[i] = messages[i].copy(isFailed = true, isPending = false)
                                                            Toast.makeText(
                                                                context,
                                                                e2.message ?: e.message ?: "Could not send Resonance",
                                                                Toast.LENGTH_LONG,
                                                            ).show()
                                                            onError(e2.message ?: e.message)
                                                        }
                                                },
                                            )
                                        } catch (e: Exception) {
                                            Toast.makeText(
                                                context,
                                                e.message ?: "Resonance error",
                                                Toast.LENGTH_LONG,
                                            ).show()
                                            onError(e.message)
                                        }
                                    }
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.MusicNote, null, tint = Tx.Accent, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(song.title, color = Tx.Text, fontSize = 14.sp, maxLines = 1)
                                Text(song.artist, color = Tx.Muted, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                    if (filtered.isEmpty()) {
                        Text(
                            if (librarySongs.isEmpty())
                                "No songs in library — go to Library tab and scan your device, then try again."
                            else "No matches",
                            color = Tx.Muted,
                            fontSize = 13.sp,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
fun SharedSoundtrackDialog(conversationId: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val tracks = remember { SharedSoundtrackStore.list(context, conversationId) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Shared soundtrack") },
        text = {
            Column {
                Text("Songs you exchanged in this chat.", color = Tx.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                if (tracks.isEmpty()) Text("Share a Resonance to start the playlist.", color = Tx.Muted)
                tracks.take(30).forEach { t ->
                    Text(
                        "♪ ${t.title} — ${t.artist}" + (t.mood?.let { " · $it" } ?: ""),
                        color = Tx.Text,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 4.dp),
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
fun MemoryCapsulesDialog(conversationId: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val caps = remember { MemoryCapsuleStore.list(context, conversationId) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Memory capsules") },
        text = {
            Column {
                Text("Moments you saved from this friendship.", color = Tx.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                if (caps.isEmpty()) Text("Tap “Save memory” on a Resonance to create one.", color = Tx.Muted)
                caps.forEach { c ->
                    Column(Modifier.padding(vertical = 6.dp)) {
                        Text(c.title, color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(
                            if (c.isOpen) c.body else "Opens later · sealed until the date you chose",
                            color = Tx.Muted,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}

@Composable
fun ThemePasswordDialog(
    password: String,
    onPasswordChange: (String) -> Unit,
    error: String?,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chat theme password") },
        text = {
            Column {
                Text("Enter the password to change this chat's theme.", color = Tx.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = onPasswordChange,
                    label = { Text("Password") },
                    singleLine = true,
                )
                error?.let { Text(it, color = Tx.Danger, fontSize = 12.sp) }
            }
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Unlock") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun ThemePickerDialog(
    theme: ChatThemeStore.Theme,
    onThemeChange: (ChatThemeStore.Theme) -> Unit,
    conversationId: String,
    onPickPhoto: () -> Unit,
    onDismiss: () -> Unit,
    onShare: (ChatThemeStore.Theme) -> Unit = {},
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chat theme") },
        text = {
            Column {
                ChatThemeStore.presetNames.forEachIndexed { i, name ->
                    if (i == 5) return@forEachIndexed
                    Text(
                        name,
                        color = if (theme.preset == i) Tx.Accent else Tx.Text,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val next = theme.copy(preset = i, backgroundUri = if (i == 5) theme.backgroundUri else null)
                                onThemeChange(next)
                                ChatThemeStore.set(context, conversationId, next)
                            }
                            .padding(vertical = 10.dp),
                    )
                }
                Text("Background fade", color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                androidx.compose.material3.Slider(
                    value = theme.dim,
                    onValueChange = {
                        val next = theme.copy(dim = it)
                        onThemeChange(next)
                        ChatThemeStore.set(context, conversationId, next)
                    },
                    valueRange = 0.2f..0.9f,
                )
                Text(
                    "Custom photo from gallery…",
                    color = Tx.Accent,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onPickPhoto)
                        .padding(vertical = 10.dp),
                )
                Text(
                    "Reset to default",
                    color = Tx.Muted,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            ChatThemeStore.clear(context, conversationId)
                            onThemeChange(ChatThemeStore.Theme())
                            onDismiss()
                        }
                        .padding(vertical = 10.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onShare(theme)
                onDismiss()
            }) { Text("Save & share") }
        },
    )
}
