package com.texgen.music.texwave.ui.screens.chat

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.ui.theme.Tx

/** Round avatar with animated story ring, photo or initial, and a pulsing green online dot. */
@Composable
fun ChatAvatar(
    name: String,
    imageUrl: String?,
    size: Dp,
    online: Boolean = false,
    isGroup: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val infinite = rememberInfiniteTransition(label = "av")
    val pulse by infinite.animateFloat(
        0.88f, 1.18f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "p",
    )
    val spin by infinite.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(if (online) 4000 else 9000, easing = LinearEasing)),
        label = "spin",
    )
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        // Spinning gradient ring
        Box(
            Modifier
                .size(size)
                .rotate(spin)
                .border(
                    width = 2.5.dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            Color(0xFFF58529),
                            Color(0xFFDD2A7B),
                            Color(0xFF8134AF),
                            Color(0xFF515BD4),
                            Color(0xFF5CE1FF),
                            Color(0xFFF58529),
                        )
                    ),
                    shape = CircleShape,
                ),
        )
        Box(
            Modifier
                .size(size - 6.dp)
                .clip(CircleShape)
                .background(Tx.SurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            if (!imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text(
                    if (isGroup) "G" else name.trim().take(1).uppercase().ifEmpty { "?" },
                    color = if (isGroup) Tx.Accent2 else Tx.Accent,
                    fontWeight = FontWeight.Bold,
                    fontSize = (size.value * 0.36f).sp,
                )
            }
        }
        if (online) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .size((size.value * 0.28f).dp)
                    .scale(pulse)
                    .clip(CircleShape)
                    .background(Tx.Bg)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF22C55E)),
            )
        }
    }
}
