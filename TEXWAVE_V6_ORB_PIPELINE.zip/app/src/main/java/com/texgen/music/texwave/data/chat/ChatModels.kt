package com.texgen.music.texwave.data.chat

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Profile(
    val id: String,
    val username: String,
    @SerialName("display_name") val displayName: String,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    val bio: String? = null,
    @SerialName("last_seen_at") val lastSeenAt: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
)

@Serializable
data class Conversation(
    val id: String,
    @SerialName("is_group") val isGroup: Boolean = false,
    val title: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
)

@Serializable
data class ConversationParticipant(
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("user_id") val userId: String,
    @SerialName("joined_at") val joinedAt: String? = null,
    @SerialName("last_read_at") val lastReadAt: String? = null,
)

@Serializable
data class Message(
    val id: String,
    @SerialName("conversation_id") val conversationId: String,
    @SerialName("sender_id") val senderId: String,
    val body: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("edited_at") val editedAt: String? = null,
    @SerialName("deleted_at") val deletedAt: String? = null,
    @SerialName("client_msg_id") val clientMsgId: String? = null,
)

@Serializable
data class Attachment(
    val id: String,
    @SerialName("message_id") val messageId: String,
    @SerialName("storage_path") val storagePath: String,
    @SerialName("original_name") val originalName: String,
    @SerialName("mime_type") val mimeType: String,
    @SerialName("size_bytes") val sizeBytes: Long,
    @SerialName("created_at") val createdAt: String? = null,
)

/** Broadcast payload used for the live "typing…" indicator. */
@Serializable
data class TypingEvent(
    @SerialName("user_id") val userId: String,
    val typing: Boolean,
)

/** Who is in a conversation (profiles) plus how far each of them has read. */
data class ConversationMembers(
    val profiles: List<Profile>,
    /** user id -> epoch millis of that user's last_read_at (0 = never read) */
    val readAt: Map<String, Long>,
)

/** UI-friendly conversation row */
data class ConversationPreview(
    val conversation: Conversation,
    val otherUser: Profile?,
    val lastMessage: Message?,
    val unreadCount: Int = 0,
)

/** Message + optional attachments for the chat UI */
data class ChatMessageUi(
    val message: Message,
    val attachments: List<Attachment> = emptyList(),
    val isMine: Boolean = false,
    val isPending: Boolean = false,
    val isFailed: Boolean = false,
)

sealed class ChatAuthState {
    data object Loading : ChatAuthState()
    data object SignedOut : ChatAuthState()
    data class SignedIn(val profile: Profile) : ChatAuthState()
    data class Error(val message: String) : ChatAuthState()
}

/** Parses Postgres/Realtime timestamps ("2026-10-18T06:40:12.123456+00:00") to epoch millis. 0 if unknown. */
fun parseIsoMillis(iso: String?): Long {
    if (iso.isNullOrBlank()) return 0L
    return try {
        java.time.OffsetDateTime.parse(iso).toInstant().toEpochMilli()
    } catch (_: Exception) {
        try {
            java.time.Instant.parse(iso).toEpochMilli()
        } catch (_: Exception) {
            try {
                java.time.LocalDateTime.parse(iso.take(23).removeSuffix("Z"))
                    .toInstant(java.time.ZoneOffset.UTC).toEpochMilli()
            } catch (_: Exception) { 0L }
        }
    }
}

/** Only real image URLs can be shown; old builds stored a bare storage path here. */
val Profile.avatarModel: String?
    get() = avatarUrl?.takeIf { it.startsWith("http") }

/** A person counts as "online" if the live presence says so, or their heartbeat is fresh. */
fun isUserOnline(userId: String, lastSeenAt: String?, online: Set<String>): Boolean {
    if (userId in online) return true
    val seen = parseIsoMillis(lastSeenAt)
    return seen > 0L && System.currentTimeMillis() - seen < 120_000L
}

/** "Last seen 5 min ago" / "Last seen today at 14:05" / "Last seen yesterday" / "Last seen 12 Oct". */
fun lastSeenLabel(lastSeenAt: String?): String {
    val ms = parseIsoMillis(lastSeenAt)
    if (ms <= 0L) return "Offline"
    val diff = System.currentTimeMillis() - ms
    val min = diff / 60_000L
    val cal = java.util.Calendar.getInstance()
    val then = java.util.Calendar.getInstance().apply { timeInMillis = ms }
    val sameDay = cal.get(java.util.Calendar.YEAR) == then.get(java.util.Calendar.YEAR) &&
        cal.get(java.util.Calendar.DAY_OF_YEAR) == then.get(java.util.Calendar.DAY_OF_YEAR)
    val hhmm = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ms))
    return when {
        min < 1 -> "Last seen just now"
        min < 60 -> "Last seen $min min ago"
        sameDay -> "Last seen today at $hhmm"
        diff < 48 * 3_600_000L && cal.get(java.util.Calendar.DAY_OF_YEAR) - then.get(java.util.Calendar.DAY_OF_YEAR) == 1 ->
            "Last seen yesterday at $hhmm"
        else -> "Last seen " + java.text.SimpleDateFormat("d MMM", java.util.Locale.getDefault()).format(java.util.Date(ms))
    }
}
