package com.texgen.music.texwave

import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlarmOff
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Snooze
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.GroqClient
import com.texgen.music.texwave.util.SpeechOut
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Full-screen alarm experience. Shows over lock screen, plays sound,
 * lets user snooze/dismiss, and talk to TEXWAVE like a human.
 */
class AlarmRingActivity : ComponentActivity() {

    companion object {
        const val EXTRA_ALARM_ID = "alarm_id"
        const val EXTRA_LABEL = "alarm_label"
        const val EXTRA_SOUND = "alarm_sound"
        const val EXTRA_BRIEFING = "alarm_briefing"

        /** Latest briefing written by the receiver so a already-open ring screen can pick it up. */
        @Volatile
        var pendingBriefing: String? = null

        @Volatile
        var activePlayer: MediaPlayer? = null

        fun stopAlarmSound() {
            runCatching {
                activePlayer?.stop()
                activePlayer?.release()
            }
            activePlayer = null
        }
    }

    private var speech: SpeechOut? = null
    private var vibrator: Vibrator? = null
    private var briefingSpoken = false
    private val liveBriefing = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen / turn screen on
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(KeyguardManager::class.java)
            km?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val alarmId = intent.getIntExtra(EXTRA_ALARM_ID, 0)
        val label = intent.getStringExtra(EXTRA_LABEL) ?: "TEXWAVE Alarm"
        val soundExtra = intent.getStringExtra(EXTRA_SOUND).orEmpty()
        val briefing = intent.getStringExtra(EXTRA_BRIEFING).orEmpty()
            .ifBlank { pendingBriefing.orEmpty() }
            .ifBlank { "Your TEXWAVE alarm is ringing. $label. Time to wake up." }
        liveBriefing.value = briefing
        pendingBriefing = briefing

        // Keep notification briefly so OEM full-screen paths can attach; cancel shortly after UI up
        window.decorView.postDelayed({
            try {
                (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(alarmId)
            } catch (_: Exception) {
            }
        }, 2500)

        startAlarmSound(soundExtra)
        startVibrate()

        speech = SpeechOut(this)
        // Immediate spoken fallback — do not wait only on delayed briefing
        window.decorView.postDelayed({
            val line = liveBriefing.value.ifBlank { "Your TEXWAVE alarm is ringing." }
            speech?.speak(line)
        }, 700)

        setContent {
            val currentBriefing by liveBriefing
            AlarmRingScreen(
                label = label,
                briefing = currentBriefing,
                onSnooze = { minutes ->
                    stopEverything()
                    scheduleSnooze(alarmId, label, soundExtra, minutes)
                    finish()
                },
                onDismiss = {
                    stopEverything()
                    finish()
                },
                onAsk = { question, onReply ->
                    handleAsk(question, onReply)
                },
                speak = { text -> speech?.speak(text) },
            )
        }

        // Speak briefing after a short delay so TTS is ready
        scheduleBriefingSpeak(briefing)

        // If receiver finishes weather after we opened, poll pending briefly
        window.decorView.postDelayed({
            val late = pendingBriefing
            if (!late.isNullOrBlank() && liveBriefing.value.isBlank()) {
                liveBriefing.value = late
                scheduleBriefingSpeak(late)
            }
        }, 1800)
        window.decorView.postDelayed({
            val late = pendingBriefing
            if (!late.isNullOrBlank() && liveBriefing.value != late) {
                liveBriefing.value = late
                scheduleBriefingSpeak(late)
            }
        }, 3500)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val briefing = intent.getStringExtra(EXTRA_BRIEFING).orEmpty()
            .ifBlank { pendingBriefing.orEmpty() }
        if (briefing.isNotBlank()) {
            liveBriefing.value = briefing
            scheduleBriefingSpeak(briefing)
        }
    }

    private fun scheduleBriefingSpeak(text: String) {
        if (text.isBlank()) return
        // Retry TTS — engine often needs 1–2s after Activity create
        val delays = longArrayOf(600L, 1400L, 2800L)
        delays.forEachIndexed { i, d ->
            window.decorView.postDelayed({
                if (i == 0 || !briefingSpoken) {
                    speech?.speak(text)
                    briefingSpoken = true
                }
            }, d)
        }
    }

    private fun startAlarmSound(soundExtra: String) {
        stopAlarmSound()
        val soundUri: Uri = when {
            soundExtra.isNotBlank() -> Uri.parse(soundExtra)
            else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: return
        }
        try {
            val mp = MediaPlayer().apply {
                setDataSource(this@AlarmRingActivity, soundUri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                )
                isLooping = true
                prepare()
                start()
            }
            activePlayer = mp
        } catch (_: Exception) {
            // fallback: system ringtone via notification already played
        }
    }

    private fun startVibrate() {
        try {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as? Vibrator
            }
            vibrator?.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 600, 300, 600, 300, 600), 0),
            )
        } catch (_: Exception) {
        }
    }

    private fun stopEverything() {
        stopAlarmSound()
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
        speech?.stop()
    }

    private fun scheduleSnooze(id: Int, label: String, sound: String, minutes: Int) {
        val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        val trigger = System.currentTimeMillis() + minutes * 60_000L
        val intent = Intent(this, com.texgen.music.texwave.notification.TexwaveAlarmReceiver::class.java).apply {
            putExtra("alarm_id", id)
            putExtra("alarm_label", "$label (snoozed)")
            putExtra("alarm_sound", sound)
        }
        val pi = android.app.PendingIntent.getBroadcast(
            this, id + 50_000, intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, trigger, pi)
            } else {
                am.setExact(android.app.AlarmManager.RTC_WAKEUP, trigger, pi)
            }
        } catch (_: Exception) {
            am.set(android.app.AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    private fun handleAsk(question: String, onReply: (String) -> Unit) {
        val client = GroqClient(this)
        val scope = kotlinx.coroutines.CoroutineScope(Dispatchers.Main)
        scope.launch {
            val reply = withContext(Dispatchers.IO) {
                if (client.hasKey()) {
                    client.chat(
                        system = """You are TEXWAVE, a warm, helpful morning companion inside an alarm clock.
Be concise (2-4 short sentences), friendly, and human. Current time context: alarm just rang.
Help with anything: weather chat, motivation, jokes, reminders, or just conversation.
Never say you are an AI unless asked.""",
                        user = question,
                        temperature = 0.7,
                        maxTokens = 220,
                    ).getOrElse { "I'm here with you. $it".take(120).ifBlank { "I'm listening — try again in a moment." } }
                } else {
                    // Offline fallback
                    when {
                        question.contains("weather", true) -> "I couldn't reach the sky right now, but the day is yours either way."
                        question.contains("time", true) -> {
                            val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Calendar.getInstance().time)
                            "It's $t. You've got this."
                        }
                        question.contains("joke", true) -> "Why did the alarm go to therapy? It had too many unresolved issues… every morning."
                        else -> "Good morning. I'm TEXWAVE — set a Groq key in Settings for full chat, or just breathe and start the day."
                    }
                }
            }
            onReply(reply)
            speech?.speak(reply)
        }
    }

    override fun onDestroy() {
        stopEverything()
        speech?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun AlarmRingScreen(
    label: String,
    briefing: String,
    onSnooze: (Int) -> Unit,
    onDismiss: () -> Unit,
    onAsk: (String, (String) -> Unit) -> Unit,
    speak: (String) -> Unit,
) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            tween(1400, easing = LinearEasing),
            RepeatMode.Reverse,
        ),
        label = "glow",
    )
    var input by remember { mutableStateOf("") }
    val chat = remember { mutableStateListOf<Pair<Boolean, String>>() } // true = user
    var thinking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val timeStr = remember {
        SimpleDateFormat("h:mm", Locale.getDefault()).format(Calendar.getInstance().time)
    }
    val amPm = remember {
        SimpleDateFormat("a", Locale.getDefault()).format(Calendar.getInstance().time)
    }
    val dateStr = remember {
        SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Calendar.getInstance().time)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF000000),
                        Color(0xFF05060E),
                        Color(0xFF0A0618),
                        Color(0xFF000000),
                    ),
                ),
            ),
    ) {
        // Soft ambient orbs
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 80.dp)
                .size(220.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF3DE0FF).copy(alpha = glow * 0.22f), Color.Transparent),
                    ),
                    CircleShape,
                ),
        )
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .padding(bottom = 120.dp, start = 20.dp)
                .size(160.dp)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF8B6CFF).copy(alpha = glow * 0.18f), Color.Transparent),
                    ),
                    CircleShape,
                ),
        )

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(28.dp))
            Text(
                "TEXWAVE",
                color = Color(0xFF3DE0FF).copy(alpha = 0.9f),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 3.sp,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                label,
                color = Color(0xFFE8ECF8),
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(36.dp))

            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    timeStr,
                    color = Color.White,
                    fontSize = 72.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-1).sp,
                )
                Text(
                    amPm,
                    color = Color(0xFF6B7390),
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 14.dp, start = 6.dp),
                )
            }
            Text(
                dateStr,
                color = Color(0xFF6B7390),
                fontSize = 15.sp,
            )

            if (briefing.isNotBlank() && chat.isEmpty()) {
                Spacer(Modifier.height(20.dp))
                Text(
                    briefing.take(160),
                    color = Color(0xFFB8C0D8),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp),
                )
            }

            // Chat transcript
            if (chat.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Column(
                    Modifier
                        .weight(1f, fill = false)
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x12FFFFFF))
                        .border(1.dp, Color(0x18FFFFFF), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    chat.forEach { (isUser, text) ->
                        Text(
                            text,
                            color = if (isUser) Color(0xFF3DE0FF) else Color(0xFFE8ECF8),
                            fontSize = 13.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = if (isUser) TextAlign.End else TextAlign.Start,
                        )
                    }
                    if (thinking) {
                        Text("TEXWAVE is thinking…", color = Color(0xFF6B7390), fontSize = 12.sp)
                    }
                }
            } else {
                Spacer(Modifier.weight(1f))
            }

            Spacer(Modifier.height(12.dp))

            // Ask TEXWAVE bar
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0x14FFFFFF))
                    .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(28.dp))
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(Color(0xFF3DE0FF)),
                    singleLine = true,
                    decorationBox = { inner ->
                        if (input.isEmpty()) {
                            Text("Ask TEXWAVE anything…", color = Color(0xFF6B7390), fontSize = 15.sp)
                        }
                        inner()
                    },
                )
                IconButton(
                    onClick = {
                        val q = input.trim()
                        if (q.isEmpty() || thinking) return@IconButton
                        chat.add(true to q)
                        input = ""
                        thinking = true
                        onAsk(q) { reply ->
                            thinking = false
                            chat.add(false to reply)
                        }
                    },
                ) {
                    Icon(Icons.Rounded.Send, contentDescription = "Send", tint = Color(0xFF3DE0FF))
                }
            }

            Spacer(Modifier.height(28.dp))

            // Snooze + Dismiss
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color(0x18FFFFFF))
                            .border(1.5.dp, Color(0xFF8B6CFF).copy(alpha = 0.6f), CircleShape)
                            .clickable { onSnooze(5) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Snooze, null, tint = Color(0xFF8B6CFF), modifier = Modifier.size(32.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Snooze 5m", color = Color(0xFFB8C0D8), fontSize = 13.sp)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .size(88.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0xFF3DE0FF).copy(alpha = 0.35f), Color(0xFF1A4A5A)),
                                ),
                            )
                            .border(2.dp, Color(0xFF3DE0FF).copy(alpha = 0.8f), CircleShape)
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.AlarmOff, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Stop", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color(0x18FFFFFF))
                            .border(1.5.dp, Color(0xFF6B7390), CircleShape)
                            .clickable { onSnooze(10) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("10", color = Color(0xFFE8ECF8), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Snooze 10m", color = Color(0xFFB8C0D8), fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(40.dp))
        }
    }
}
