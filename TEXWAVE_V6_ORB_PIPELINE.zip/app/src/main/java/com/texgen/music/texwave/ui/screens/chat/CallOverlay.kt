package com.texgen.music.texwave.ui.screens.chat

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.PhoneInTalk
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.VoiceCallEngine
import com.texgen.music.texwave.player.CallService
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val CallViolet = Color(0xFF8B5CFF)
private val CallMagenta = Color(0xFFFF3DCB)
private val CallCyan = Color(0xFF35E8FF)

/**
 * Full-screen, in-app voice call. Real-time audio runs through WebRTC ([VoiceCallEngine]);
 * nothing opens in a browser or another app.
 *
 * [onEnd] is called with `true` when a call-ended message should be posted to the chat.
 */
@Composable
fun CallOverlay(
    repo: ChatRepository,
    peerName: String,
    room: String,
    outgoing: Boolean,
    onEnd: (sendEndMessage: Boolean) -> Unit,
) {
    val context = LocalContext.current
    val engine = remember(room) { VoiceCallEngine(context, repo, room, isCaller = outgoing) }
    val state by engine.state.collectAsState()
    val remoteLevel by engine.remoteLevel.collectAsState()
    val localLevel by engine.localLevel.collectAsState()

    // incoming calls wait for the user to press Answer
    var answered by remember(room) { mutableStateOf(outgoing) }
    var started by remember(room) { mutableStateOf(false) }
    var muted by remember { mutableStateOf(false) }
    var speaker by remember { mutableStateOf(false) }
    var connectedAt by remember { mutableLongStateOf(0L) }
    var seconds by remember { mutableIntStateOf(0) }
    var dots by remember { mutableIntStateOf(0) }
    var ringPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var tone by remember { mutableStateOf<ToneGenerator?>(null) }
    var focusReq by remember { mutableStateOf<AudioFocusRequest?>(null) }

    fun stopRing() {
        try { ringPlayer?.stop(); ringPlayer?.release() } catch (_: Exception) {}
        ringPlayer = null
        try { tone?.stopTone(); tone?.release() } catch (_: Exception) {}
        tone = null
    }

    fun beginCall() {
        if (started) return
        started = true
        stopRing()
        // pause music players while the call is running
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .build()
            am.requestAudioFocus(req)
            focusReq = req
        } catch (_: Exception) {}
        CallService.start(context, peerName)
        engine.start()
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) beginCall()
        else {
            Toast.makeText(context, "Microphone permission is needed for calls", Toast.LENGTH_LONG).show()
            onEnd(true)
        }
    }

    fun requestAndStart() {
        val has = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (has) beginCall() else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    // ringing sounds
    LaunchedEffect(room) {
        if (outgoing) {
            requestAndStart()
        } else {
            try {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ringPlayer = MediaPlayer().apply {
                    setDataSource(context, uri)
                    isLooping = true
                    prepare()
                    start()
                }
            } catch (_: Exception) {}
        }
    }
    // soft ringback tone for the caller while waiting
    LaunchedEffect(state, outgoing) {
        if (outgoing && state == VoiceCallEngine.State.WAITING && tone == null) {
            try {
                tone = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 45).also {
                    it.startTone(ToneGenerator.TONE_SUP_RINGTONE)
                }
            } catch (_: Exception) {}
        }
        if (state == VoiceCallEngine.State.CONNECTED) {
            stopRing()
            if (connectedAt == 0L) connectedAt = System.currentTimeMillis()
        }
    }
    LaunchedEffect(connectedAt) {
        while (connectedAt != 0L) {
            seconds = ((System.currentTimeMillis() - connectedAt) / 1000).toInt()
            delay(500)
        }
    }
    LaunchedEffect(Unit) { while (true) { delay(420); dots = (dots + 1) % 4 } }

    // engine finished by itself (other side hung up / failed)
    LaunchedEffect(state) {
        if (state == VoiceCallEngine.State.ENDED || state == VoiceCallEngine.State.FAILED) {
            stopRing()
            delay(1300)
            onEnd(state == VoiceCallEngine.State.FAILED && outgoing)
        }
    }

    DisposableEffect(room) {
        onDispose {
            stopRing()
            engine.hangUp()
            CallService.stop(context)
            try {
                focusReq?.let {
                    (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(it)
                }
            } catch (_: Exception) {}
        }
    }

    fun hangUp() {
        stopRing()
        engine.hangUp()
        onEnd(true)
    }
    BackHandler { hangUp() }

    // ---------------- visuals ----------------
    val level by animateFloatAsState(
        targetValue = maxOf(remoteLevel, localLevel * 0.7f).coerceIn(0f, 1f).let { Math.sqrt(it.toDouble()).toFloat() },
        animationSpec = tween(110),
        label = "callLevel",
    )
    val infinite = rememberInfiniteTransition(label = "callFx")
    val drift by infinite.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift",
    )
    val wavePhase by infinite.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "wave",
    )
    val ring by infinite.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2800, easing = LinearEasing), RepeatMode.Restart),
        label = "ring",
    )
    val answerPulse by infinite.animateFloat(
        0.94f, 1.08f,
        infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "answerPulse",
    )

    val connected = state == VoiceCallEngine.State.CONNECTED || state == VoiceCallEngine.State.RECONNECTING
    val dotText = ".".repeat(dots)
    val statusText = when {
        state == VoiceCallEngine.State.ENDED -> engine.endReason.ifBlank { "Call ended" }
        state == VoiceCallEngine.State.FAILED -> engine.endReason.ifBlank { "Call failed" }
        state == VoiceCallEngine.State.RECONNECTING -> "Reconnecting$dotText"
        state == VoiceCallEngine.State.CONNECTED -> "%02d:%02d".format(seconds / 60, seconds % 60)
        !answered -> "Incoming voice call"
        outgoing && state == VoiceCallEngine.State.WAITING -> "Ringing$dotText"
        outgoing -> "Calling$dotText"
        else -> "Connecting$dotText"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF020108))
            // swallow touches so nothing behind the call is clickable
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
    ) {
        // animated aurora
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val boost = 0.55f + level * 0.9f
            fun orb(c: Color, cx: Float, cy: Float, r: Float, a: Float) {
                drawCircle(
                    Brush.radialGradient(
                        listOf(c.copy(alpha = (a * boost).coerceAtMost(0.6f)), Color.Transparent),
                        center = Offset(cx, cy), radius = r,
                    ),
                    radius = r, center = Offset(cx, cy),
                )
            }
            orb(CallViolet, w * (0.25f + 0.12f * sin(drift)), h * (0.22f + 0.05f * cos(drift)), w * 0.95f, 0.38f)
            orb(CallMagenta, w * (0.85f + 0.08f * cos(drift * 1.3f)), h * (0.55f + 0.06f * sin(drift)), w * 0.8f, 0.26f)
            orb(CallCyan, w * (0.4f + 0.15f * sin(drift * 0.7f)), h * (0.88f + 0.03f * cos(drift)), w * 0.85f, 0.2f)
            for (i in 0 until 46) {
                val x = ((i * 173 + 41) % 997) / 997f * w
                val y = ((i * 127 + 89) % 991) / 991f * h
                val tw = 0.1f + 0.25f * (0.5f + 0.5f * sin(drift * 3f + i * 1.7f))
                drawCircle(Color.White.copy(alpha = tw), (0.6f + (i % 3) * 0.5f) * density, Offset(x, y))
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "T E X W A V E   V O I C E",
                color = Color.White.copy(0.55f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.weight(1f))

            // avatar + reactive halo
            Box(Modifier.size(300.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = Offset(size.width / 2, size.height / 2)
                    val base = 62.dp.toPx()
                    // expanding sonar rings
                    for (k in 0 until 3) {
                        val p = (ring + k / 3f) % 1f
                        drawCircle(
                            color = CallViolet.copy(alpha = (1f - p) * (0.22f + level * 0.35f)),
                            radius = base + p * 88.dp.toPx(),
                            center = c,
                            style = Stroke(width = (2f + (1f - p) * 3f) * density),
                        )
                    }
                    // circular voice spectrum
                    val bars = 56
                    val r0 = base + 8.dp.toPx()
                    for (i in 0 until bars) {
                        val a = (i.toFloat() / bars) * 2f * PI.toFloat() - PI.toFloat() / 2
                        val shape = 0.5f + 0.5f * sin(wavePhase * 2f + i * 0.55f) * cos(wavePhase + i * 0.21f)
                        val idle = if (connected) 0.07f else 0.14f * (0.5f + 0.5f * sin(wavePhase + i * 0.4f))
                        val len = (3.dp.toPx() + (idle + level * shape) * 38.dp.toPx())
                        val t = i.toFloat() / bars
                        val col = if (t < 0.5f) lerp(CallCyan, CallViolet, t * 2) else lerp(CallViolet, CallMagenta, (t - 0.5f) * 2)
                        drawLine(
                            col.copy(alpha = 0.9f),
                            Offset(c.x + cos(a) * r0, c.y + sin(a) * r0),
                            Offset(c.x + cos(a) * (r0 + len), c.y + sin(a) * (r0 + len)),
                            strokeWidth = 3.dp.toPx(),
                            cap = StrokeCap.Round,
                        )
                    }
                }
                Box(
                    Modifier
                        .size(116.dp)
                        .scale(1f + level * 0.07f)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(CallCyan, CallViolet, CallMagenta)))
                        .border(2.dp, Color.White.copy(0.3f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        peerName.trim().take(1).uppercase().ifEmpty { "?" },
                        color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }

            Spacer(Modifier.height(6.dp))
            Text(
                peerName,
                color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, maxLines = 1,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                statusText,
                color = if (state == VoiceCallEngine.State.FAILED) Color(0xFFFF6B8A)
                else if (connected) CallCyan else Color.White.copy(0.7f),
                fontSize = if (state == VoiceCallEngine.State.CONNECTED) 22.sp else 16.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.weight(1.2f))

            if (!answered) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CallRoundButton(Icons.Rounded.CallEnd, "Decline", 74.dp, Brush.linearGradient(listOf(Color(0xFFFF3B6B), Color(0xFFB4123F)))) { hangUp() }
                    Box(Modifier.scale(answerPulse)) {
                        CallRoundButton(Icons.Rounded.Call, "Answer", 84.dp, Brush.linearGradient(listOf(Color(0xFF2EF2A0), Color(0xFF12B76A)))) {
                            answered = true
                            requestAndStart()
                        }
                    }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CallRoundButton(
                        if (muted) Icons.Rounded.MicOff else Icons.Rounded.Mic, "Mute", 62.dp,
                        if (muted) Brush.linearGradient(listOf(Color.White, Color(0xFFD8CCFF)))
                        else Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x1AFFFFFF))),
                        iconTint = if (muted) Color(0xFF1A0B3A) else Color.White,
                    ) { muted = !muted; engine.setMuted(muted) }
                    CallRoundButton(Icons.Rounded.CallEnd, "End call", 76.dp, Brush.linearGradient(listOf(Color(0xFFFF3B6B), Color(0xFFB4123F)))) { hangUp() }
                    CallRoundButton(
                        Icons.Rounded.VolumeUp, "Speaker", 62.dp,
                        if (speaker) Brush.linearGradient(listOf(CallCyan, CallViolet))
                        else Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x1AFFFFFF))),
                    ) { speaker = !speaker; engine.setSpeaker(speaker) }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.PhoneInTalk, null, tint = Color.White.copy(0.4f), modifier = Modifier.size(14.dp))
                    Text("Encrypted peer-to-peer audio", color = Color.White.copy(0.4f), fontSize = 11.sp)
                }
            }
        }
    }
}

private fun lerp(a: Color, b: Color, t: Float): Color = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = 1f,
)

@Composable
private fun CallRoundButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    size: androidx.compose.ui.unit.Dp,
    brush: Brush,
    iconTint: Color = Color.White,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(brush)
            .border(1.dp, Color.White.copy(0.18f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = iconTint, modifier = Modifier.size(size * 0.42f))
    }
}
