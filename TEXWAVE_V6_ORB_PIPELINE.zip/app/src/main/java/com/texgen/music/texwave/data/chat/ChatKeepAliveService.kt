package com.texgen.music.texwave.data.chat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.texgen.music.texwave.MainActivity
import com.texgen.music.texwave.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Lightweight foreground service so inbox realtime keeps running when the app is backgrounded.
 * Without this, Android may freeze the process and message notifications never fire.
 */
class ChatKeepAliveService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelfSafe()
            return START_NOT_STICKY
        }
        try {
            val n = buildNotif("Chat connected · waiting for messages")
            if (Build.VERSION.SDK_INT >= 29) {
                ServiceCompat.startForeground(
                    this, NOTIF_ID, n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
                )
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (_: Exception) {
            try { startForeground(NOTIF_ID, buildNotif("Chat connected")) } catch (_: Exception) {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        job?.cancel()
        job = scope.launch {
            while (isActive) {
                runCatching {
                    ChatRepository.get(applicationContext).ensureInboxAlive()
                }
                delay(25_000)
            }
        }
        return START_STICKY
    }

    private fun buildNotif(text: String): Notification {
        ensureChannel()
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle("TEXWAVE Chat")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Chat connection", NotificationManager.IMPORTANCE_MIN).apply {
                    description = "Keeps chat notifications working in the background"
                    setShowBadge(false)
                    setSound(null, null)
                },
            )
        }
    }

    private fun stopSelfSafe() {
        job?.cancel()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.texgen.music.texwave.CHAT_KEEPALIVE_STOP"
        private const val CHANNEL = "texwave_chat_keepalive"
        private const val NOTIF_ID = 4199

        fun start(context: Context) {
            val app = context.applicationContext
            val i = Intent(app, ChatKeepAliveService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i)
                else app.startService(i)
            } catch (e: Exception) {
                android.util.Log.e("ChatKeepAlive", "start failed", e)
            }
        }

        fun stop(context: Context) {
            val app = context.applicationContext
            try {
                app.startService(Intent(app, ChatKeepAliveService::class.java).setAction(ACTION_STOP))
            } catch (_: Exception) {
                try { app.stopService(Intent(app, ChatKeepAliveService::class.java)) } catch (_: Exception) {}
            }
        }
    }
}
