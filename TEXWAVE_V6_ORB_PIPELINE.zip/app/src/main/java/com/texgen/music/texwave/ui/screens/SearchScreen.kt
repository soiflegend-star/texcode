package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items as listItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Person
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.components.ScreenHeader
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.rememberUiSound
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import com.texgen.music.texwave.util.UiSound
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.border
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.EmptyState
import com.texgen.music.texwave.ui.components.SectionHeader
import com.texgen.music.texwave.ui.components.SongRow
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.seedColors
import com.texgen.music.texwave.util.songCount

@Composable
fun SearchScreen(
    lib: LibraryState,
    player: PlayerState,
    onPlay: (List<Song>, Int) -> Unit,
    onMore: (Song) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    val results = remember(lib.songs, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) emptyList()
        else lib.songs.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }
    }
    val artists = remember(lib.songs) {
        lib.songs.groupBy { it.artist }.entries.sortedByDescending { it.value.size }.take(30)
    }

    val artistHits = remember(lib.songs, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) emptyList()
        else lib.songs.groupBy { it.artist }.entries
            .filter { it.key.isNotBlank() && it.key.lowercase().contains(q) }
            .sortedByDescending { it.value.size }
            .take(4)
    }
    val sound = rememberUiSound()

    Column(Modifier.fillMaxSize().sonicAtmosphere()) {
        ScreenHeader("Search", "Find exactly what you\u2019re looking for.", Modifier.appear(0))
        TextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("Search music...", color = Tx.Muted) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Color(0xFF3DE0FF)) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { sound(UiSound.Kind.TAP); query = "" }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Tx.Muted)
                    }
                }
            },
            shape = RoundedCornerShape(18.dp),
            colors = TextFieldDefaults.colors(
                focusedTextColor = Tx.Text,
                unfocusedTextColor = Tx.Text,
                focusedContainerColor = Color(0xFF0B1230),
                unfocusedContainerColor = Color(0xFF0B1230),
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = Color(0xFF3DE0FF),
            ),
            modifier = Modifier
                .appear(80)
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .border(
                    1.dp,
                    Brush.horizontalGradient(listOf(Color(0x883DE0FF), Color(0x558A5CFF))),
                    RoundedCornerShape(18.dp),
                ),
        )
        Spacer(Modifier.height(8.dp))

        when {
            query.isBlank() -> {
                SectionHeader("Browse artists", Modifier.padding(top = 4.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(artists, key = { it.key }) { (artist, list) ->
                        val colors = remember(artist) { seedColors(artist) }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(1.7f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Brush.linearGradient(listOf(colors.first, colors.second)))
                                .clickable { sound(UiSound.Kind.SELECT); query = artist }
                                .padding(14.dp)
                        ) {
                            Column(Modifier.align(Alignment.BottomStart)) {
                                Text(artist, color = Color.White, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(songCount(list.size), color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            results.isEmpty() -> EmptyState(
                icon = Icons.Rounded.Search,
                title = "No results",
                message = "Nothing matched \"${query.trim()}\". Try a different spelling.",
            )

            else -> LazyColumn(contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
                listItems(artistHits, key = { "artist_" + it.key }) { (artist, list) ->
                    val colors = remember(artist) { seedColors(artist) }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { sound(UiSound.Kind.SELECT); query = artist }
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(colors.first, colors.second))),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Rounded.Person, null, tint = Color.White) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(artist, color = Tx.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Artist \u00b7 " + songCount(list.size), color = Tx.Muted, fontSize = 12.sp)
                        }
                        Icon(Icons.Rounded.ChevronRight, null, tint = Color(0xFF3DE0FF))
                    }
                }
                itemsIndexed(results, key = { _, s -> s.id }) { index, song ->
                    SongRow(
                        song = song,
                        isCurrent = player.current?.id == song.id,
                        isPlaying = player.isPlaying,
                        liked = song.id in lib.liked,
                        onClick = { onPlay(results, index) },
                        onMore = { onMore(song) },
                    )
                }
            }
        }
    }
}
