package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.delay

private const val INTRO_SECONDS = 5.6f

private class Star(val angle: Float, val offset: Float, val speed: Float, val hue: Int, val size: Float)
private class Dust(val arm: Int, val r: Float, val jitter: Float, val size: Float, val hue: Int, val phase: Float)

private fun starColor(h: Int): Color = when (h) {
    0 -> Color(0xFFFFFFFF)
    1 -> Color(0xFFBFA8FF)
    2 -> Color(0xFF8FEFFF)
    else -> Color(0xFFFF9EE6)
}

/**
 * Dark-universe intro: a warp-speed star tunnel drops into a slowly turning galaxy,
 * a shockwave reveals the Texwave emblem, then the title resolves. Tap to skip.
 * Fully procedural (no video file), 60 fps, ~5.6 seconds.
 */
@Composable
fun NebulaIntroScreen(onFinished: () -> Unit) {
    var t by remember { mutableFloatStateOf(0f) }
    val warp = remember {
        val r = Random(11)
        List(240) { Star(r.nextFloat() * 6.2832f, r.nextFloat(), 0.6f + r.nextFloat() * 0.9f, r.nextInt(4), 0.6f + r.nextFloat() * 1.6f) }
    }
    val galaxy = remember {
        val r = Random(5)
        List(520) { Dust(r.nextInt(3), r.nextFloat().pow(0.8f), (r.nextFloat() - 0.5f) * 0.35f, 0.5f + r.nextFloat() * 1.8f, r.nextInt(4), r.nextFloat() * 6.28f) }
    }

    LaunchedEffect(Unit) {
        var start = -1L
        while (t < INTRO_SECONDS) {
            androidx.compose.runtime.withFrameNanos { n ->
                if (start < 0) start = n
                t = (n - start) / 1_000_000_000f
            }
        }
        onFinished()
    }

    fun ease(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }
    fun seg(a: Float, b: Float): Float = ease((t - a) / (b - a))

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF010005))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onFinished() },
    ) {
        Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = seg(0f, 0.70f) }) {
            val w = size.width
            val h = size.height
            val c = Offset(w / 2f, h * 0.44f)
            val maxR = kotlin.math.hypot(w, h) * 0.62f
            val d = density

            // nebula clouds
            fun cloud(col: Color, x: Float, y: Float, r: Float, a: Float) = drawCircle(
                Brush.radialGradient(listOf(col.copy(alpha = a), col.copy(alpha = a * 0.3f), Color.Transparent), Offset(x, y), r),
                r, Offset(x, y),
            )
            val drift = t * 0.35f
            cloud(Color(0xFF6A3BFF), w * (0.30f + 0.06f * sin(drift)), h * 0.30f, w * 1.0f, 0.32f)
            cloud(Color(0xFFFF2FC2), w * (0.86f + 0.05f * cos(drift)), h * 0.52f, w * 0.75f, 0.20f)
            cloud(Color(0xFF1FD5FF), w * (0.40f + 0.08f * sin(drift * 0.8f)), h * 0.84f, w * 0.85f, 0.18f)
            cloud(Color(0xFF3A1B8F), c.x, c.y, w * 0.9f, 0.40f)

            // galaxy (flattened + tilted spiral) — visible once the warp slows down
            val gAlpha = seg(1.4f, 3.1f)
            if (gAlpha > 0f) {
                val rot = t * 0.55f
                val tilt = -0.38f
                val ct = cos(tilt); val st = sin(tilt)
                galaxy.forEach { s ->
                    val rr = s.r * w * 0.62f
                    val a = s.arm * 2.0944f + s.r * 5.2f - rot / (0.4f + s.r) * 0.6f + s.jitter
                    val x0 = cos(a) * rr
                    val y0 = sin(a) * rr * 0.42f
                    val px = c.x + x0 * ct - y0 * st
                    val py = c.y + x0 * st + y0 * ct
                    val tw = 0.45f + 0.55f * (0.5f + 0.5f * sin(t * 3f + s.phase))
                    drawCircle(starColor(s.hue).copy(alpha = gAlpha * tw * (1f - s.r * 0.45f)), s.size * d, Offset(px, py))
                }
                // bright galactic core
                val core = w * (0.20f + 0.015f * sin(t * 2.2f))
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFFFFFFFF).copy(alpha = 0.85f * gAlpha), Color(0xFFB79CFF).copy(alpha = 0.45f * gAlpha), Color.Transparent),
                        c, core,
                    ),
                    core, c,
                )
            }

            // warp stars
            val warpPower = (1f - seg(1.1f, 3.6f))
            val speed = 0.25f + warpPower * 2.6f
            warp.forEach { s ->
                val p = ((s.offset + t * speed * s.speed * 0.5f) % 1f)
                val r = p.pow(2.3f) * maxR
                val trail = r * (0.05f + 0.5f * warpPower * s.speed)
                val dir = Offset(cos(s.angle), sin(s.angle))
                val a = (p * 1.4f).coerceAtMost(1f) * (0.35f + 0.65f * (1f - seg(3.4f, 4.7f) * 0.7f))
                drawLine(
                    starColor(s.hue).copy(alpha = a),
                    Offset(c.x + dir.x * (r - trail), c.y + dir.y * (r - trail)),
                    Offset(c.x + dir.x * r, c.y + dir.y * r),
                    strokeWidth = (0.6f + p * 2.2f) * s.size * 0.6f * d,
                    cap = StrokeCap.Round,
                )
            }

            // shockwave ring when the emblem lands
            val sw = ((t - 1.95f) / 1.7f)
            if (sw in 0f..1f) {
                val rr = ease(sw) * w * 0.95f
                drawCircle(
                    Brush.sweepGradient(
                        listOf(Color(0xFF2FE6FF), Color(0xFFA37CFF), Color(0xFFFF3DCB), Color(0xFF2FE6FF)), c,
                    ),
                    radius = rr, center = c,
                    style = Stroke(width = (6f * (1f - sw) + 1f) * d),
                    alpha = (1f - sw) * 0.9f,
                )
            }
            // emblem glow
            val glow = seg(1.7f, 3.0f)
            if (glow > 0f) {
                val gr = w * (0.46f + 0.03f * sin(t * 2.6f))
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFF7B4DFF).copy(alpha = 0.55f * glow), Color(0xFF2FE6FF).copy(alpha = 0.10f * glow), Color.Transparent),
                        c, gr,
                    ),
                    gr, c,
                )
            }
            // vignette
            drawRect(
                Brush.radialGradient(
                    listOf(Color.Transparent, Color(0xCC000000)),
                    Offset(w / 2, h / 2), kotlin.math.hypot(w, h) * 0.55f,
                ),
            )
        }

        // emblem + title
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(0.44f))
            Image(
                painter = painterResource(R.drawable.intro_emblem),
                contentDescription = "Texwave",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(210.dp)
                    .graphicsLayer {
                        val a = seg(1.8f, 3.0f)
                        // overshoot a little for a "landing" feel
                        val s = 0.55f + 0.45f * a + 0.06f * sin(a * 3.1416f)
                        alpha = a
                        scaleX = s; scaleY = s
                    },
            )
            Spacer(Modifier.weight(0.56f))
        }
        Column(
            Modifier
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Bottom,
        ) {
            Text(
                "TEXWAVE",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF2FE6FF), Color(0xFFE8E0FF), Color(0xFFFF8AE6))),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 12.sp,
                    textAlign = TextAlign.Center,
                ),
                modifier = Modifier.graphicsLayer {
                    val a = seg(3.0f, 4.1f)
                    alpha = a
                    val s = 1.18f - 0.18f * a
                    scaleX = s; scaleY = s
                },
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Your music. Your memories. Your universe.",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 13.sp,
                letterSpacing = 1.sp,
                modifier = Modifier.graphicsLayer { alpha = seg(3.7f, 4.7f) },
            )
            Spacer(Modifier.height(56.dp))
        }
    }
}
