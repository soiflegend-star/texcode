package com.texgen.music.texwave.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.texgen.music.texwave.ui.components.Artwork
import com.texgen.music.texwave.ui.components.ScreenHeader
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable
import com.texgen.music.texwave.ui.components.rememberUiSound
import com.texgen.music.texwave.util.UiSound
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.SortMode
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.data.Playlist
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.EmptyState
import com.texgen.music.texwave.ui.components.NavCatalog
import com.texgen.music.texwave.ui.components.NavTarget
import com.texgen.music.texwave.ui.components.GhostButton
import com.texgen.music.texwave.ui.components.GradientButton
import com.texgen.music.texwave.ui.components.GradientTile
import com.texgen.music.texwave.ui.components.SongRow
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.songCount

@Composable
fun LibraryScreen(
    onOpenUniverse: () -> Unit = {},

    lib: LibraryState,
    player: PlayerState,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onMore: (Song) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onNewPlaylist: () -> Unit,
    onRescan: () -> Unit,
    onSettings: () -> Unit = {},
    onEqualizer: () -> Unit = {},
    onEditor: () -> Unit = {},
    onSort: (SortMode) -> Unit = {},
    onOpenConstellation: () -> Unit = {},
    onSearch: () -> Unit = {},
    onOpenProfile: () -> Unit = {},
    onOpenMenu: () -> Unit = {},
    onNavigate: (NavTarget) -> Unit = {},
    tabRequest: Pair<Int, Int> = 0 to 0,
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(tabRequest) { if (tabRequest.second > 0) tab = tabRequest.first }
    val liked = remember(lib.songs, lib.liked) { lib.songs.filter { it.id in lib.liked } }
    val sound = rememberUiSound()
    val ctx = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    var soundsOn by remember { mutableStateOf(UiSound.isEnabled(ctx)) }
    val albumN = remember(lib.songs) { lib.songs.map { it.album }.filter { it.isNotBlank() }.distinct().size }
    val artistN = remember(lib.songs) { lib.songs.map { it.artist }.filter { it.isNotBlank() }.distinct().size }
    val recentlyAdded = remember(lib.songs) { lib.songs.sortedByDescending { it.dateAdded }.take(15) }

    Column(Modifier.fillMaxSize().sonicAtmosphere()) {
        ScreenHeader("Library", "Orb · albums · rituals", Modifier.appear(0)) {
            IconButton(onClick = { sound(UiSound.Kind.TAP); onOpenProfile() }) {
                Icon(Icons.Rounded.Person, "My profile", tint = Color(0xFFB388FF))
            }
            IconButton(onClick = { sound(UiSound.Kind.TAP); onSearch() }) {
                Icon(Icons.Rounded.Search, "Search", tint = Color(0xFF3DE0FF))
            }
            IconButton(onClick = { sound(UiSound.Kind.TAP); onOpenMenu() }) {
                Icon(Icons.Rounded.Menu, "Menu", tint = Color(0xFF9AA2C2))
            }
        }

        // Premium segmented tabs — dark glass, cyan active
        Row(
            Modifier
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0x0EFFFFFF))
                .border(1.dp, Color(0x18FFFFFF), RoundedCornerShape(16.dp))
                .padding(3.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            (listOf(0 to "All", 1 to "Songs", 5 to "Constellation", 2 to "Albums", 3 to "Artists", 4 to "Playlists", 7 to "Liked", 6 to "Radar") + LibrarySessions.mapIndexed { k, d -> (10 + k) to d.second } + listOf(8 to "Explore")).forEach { (i, label) ->
                val sel = tab == i
                val scale by animateFloatAsState(
                    targetValue = if (sel) 1.02f else 1f,
                    animationSpec = spring(dampingRatio = 0.7f, stiffness = 400f),
                    label = "libraryTab$i",
                )
                Box(
                    Modifier
                        .graphicsLayer { scaleX = scale; scaleY = scale }
                        .clip(RoundedCornerShape(11.dp))
                        .then(
                            if (sel) Modifier
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color(0xFF152838), Color(0xFF1A2040), Color(0xFF221838))
                                    )
                                )
                                .border(1.dp, Color(0xFF2FE6FF).copy(alpha = 0.65f), RoundedCornerShape(11.dp))
                            else Modifier
                        )
                        .clickable {
                            if (i == 5) { sound(UiSound.Kind.SELECT); onOpenConstellation() }
                            else if (tab != i) { sound(UiSound.Kind.TAB); tab = i }
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                ) {
                    Text(
                        label,
                        color = if (sel) Color(0xFF3DE0FF) else Color(0xFF8A92B0),
                        fontSize = 13.sp,
                        fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))

        if (tab == 0) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                LibraryConstellation(
                    songs = lib.songs.size,
                    playlists = lib.playlists.size,
                    artists = artistN,
                    albums = albumN,
                    favorites = liked.size,
                    onNode = { target -> sound(UiSound.Kind.SELECT); tab = target },
                )
                Row(
                    Modifier.fillMaxWidth().padding(start = 18.dp, end = 16.dp, top = 4.dp).appear(450),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Recently Added", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).clickable { sound(UiSound.Kind.TAB); tab = 1 }.padding(start = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("View all", color = Color(0xFF3DE0FF), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Icon(Icons.Rounded.ChevronRight, null, tint = Color(0xFF3DE0FF), modifier = Modifier.size(16.dp))
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (recentlyAdded.isEmpty()) {
                    Text(
                        "No songs yet \u2014 use the menu to rescan your device.",
                        color = Tx.Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp),
                    )
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 18.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.appear(520),
                    ) {
                        itemsIndexed(recentlyAdded, key = { _, s -> s.id }) { index, song ->
                            Column(
                                Modifier
                                    .width(108.dp)
                                    .pressable(0.95f) { sound(UiSound.Kind.PLAY); onPlay(recentlyAdded, index) },
                            ) {
                                Box(
                                    Modifier
                                        .size(108.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .border(
                                            1.dp,
                                            Brush.linearGradient(listOf(Color(0x883DE0FF), Color(0x558A5CFF))),
                                            RoundedCornerShape(14.dp),
                                        ),
                                ) { Artwork(song, Modifier.fillMaxSize(), corner = 14.dp, iconSize = 34.dp) }
                                Spacer(Modifier.height(7.dp))
                                Text(song.title, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    song.artist.ifBlank { "Unknown artist" },
                                    color = Color(0xFF9AA2C2), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        } else {
            if (tab == 1) SortBar(lib.sortMode, lib.sortAsc, onSort)
            Spacer(Modifier.height(4.dp))
            when (tab) {
                1 -> SongList(lib.songs, lib, player, onPlay, onShuffle, onMore, "No songs found", "Use the menu above to rescan your device.", sectioned = true)
                2 -> SongList(
                    lib.songs.distinctBy { it.album.ifBlank { it.title } },
                    lib, player, onPlay, onShuffle, onMore,
                    "No albums found", "Scan your library to see albums.",
                )
                3 -> SongList(
                    lib.songs.distinctBy { it.artist.ifBlank { "Unknown" } },
                    lib, player, onPlay, onShuffle, onMore,
                    "No artists found", "Scan your library to see artists.",
                )
                4 -> PlaylistsTab(lib.playlists, onOpenPlaylist, onNewPlaylist)
                5 -> {
                    // Full constellation page inside Library — always visible, not buried
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        LibraryConstellation(
                            songs = lib.songs.size,
                            playlists = lib.playlists.size,
                            artists = lib.songs.map { it.artist }.distinct().size,
                            albums = lib.songs.map { it.album }.distinct().size,
                            favorites = liked.size,
                            onNode = { node ->
                                when (node) {
                                    1 -> tab = 1
                                    2 -> tab = 2
                                    3 -> tab = 3
                                    4 -> tab = 4
                                    7 -> tab = 7
                                    else -> tab = 0
                                }
                            },
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Open full stars map",
                            color = Color(0xFF3DE0FF),
                            fontSize = 13.sp,
                            modifier = Modifier
                                .padding(horizontal = 20.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onOpenConstellation() }
                                .padding(12.dp),
                        )
                        Spacer(Modifier.height(24.dp))
                    }
                }
                8 -> ExploreGrid(onNavigate)
                in 10 until (10 + LibrarySessions.size) -> androidx.compose.runtime.CompositionLocalProvider(
                    com.texgen.music.texwave.ui.screens.universe.LocalUniverseEmbedded provides true,
                ) {
                    com.texgen.music.texwave.ui.screens.universe.UniverseRouter(
                        dest = LibrarySessions[tab - 10].first,
                        lib = lib,
                        player = player,
                        onPlay = onPlay,
                        onBack = { tab = 0 },
                    )
                }
                6 -> PulseRadarScreen(
                    lib = lib,
                    player = player,
                    onPlay = onPlay,
                    onShuffle = onShuffle,
                    onEmotion = { /* emotion via play — Library may not pass emotion */ },
                )
                                else -> SongList(liked, lib, player, onPlay, onShuffle, onMore, "No liked songs yet", "Open a song's menu and choose \"Add to liked songs\" to see it here.")
            }
        }
    }
}

private class ConstNode(val label: String, val icon: ImageVector, val accent: Color, val fx: Float, val fy: Float, val target: Int)

/** Sonic constellation — brighter core, glass nodes, traveling energy on the links. */
@Composable
private fun LibraryConstellation(
    songs: Int, playlists: Int, artists: Int, albums: Int, favorites: Int,
    onNode: (Int) -> Unit,
) {
    val nodes = remember {
        listOf(
            ConstNode("Songs", Icons.Rounded.MusicNote, Color(0xFFB27CFF), 0.50f, 0.10f, 1),
            ConstNode("Playlists", Icons.Rounded.FormatListBulleted, Color(0xFF6C7CFF), 0.14f, 0.42f, 4),
            ConstNode("Artists", Icons.Rounded.Person, Color(0xFF3DB8FF), 0.86f, 0.40f, 3),
            ConstNode("Albums", Icons.Rounded.Album, Color(0xFF3DE0FF), 0.20f, 0.86f, 2),
            ConstNode("Favorites", Icons.Rounded.Favorite, Color(0xFFFF4FB0), 0.82f, 0.86f, 7),
        )
    }
    val counts = listOf(songs, playlists, artists, albums, favorites)
    val t = rememberInfiniteTransition(label = "constellation")
    val phase = t.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "flow")
    val phase2 = t.animateFloat(0f, 1f, infiniteRepeatable(tween(4800, easing = LinearEasing)), label = "flow2")
    val pulse = t.animateFloat(0.88f, 1.14f, infiniteRepeatable(tween(2400), androidx.compose.animation.core.RepeatMode.Reverse), label = "orb")
    val twinkle = t.animateFloat(0f, 1f, infiniteRepeatable(tween(2800, easing = LinearEasing)), label = "twinkle")

    val orbCore = ImageBitmap.imageResource(com.texgen.music.texwave.R.drawable.orb_core)
    val orbSwirl = ImageBitmap.imageResource(com.texgen.music.texwave.R.drawable.orb_swirl)
    val rot = t.animateFloat(0f, 360f, infiniteRepeatable(tween(28000, easing = LinearEasing)), label = "orbRot")

    BoxWithConstraints(Modifier.fillMaxWidth().height(360.dp)) {
        val w = maxWidth
        val h = maxHeight
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width * 0.5f, size.height * 0.50f)

            // Deep multi-layer nebula
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x558B5CFF), Color(0x338A5CFF), Color(0x148B5CFF), Color.Transparent),
                    c, size.width * 0.72f
                ),
                size.width * 0.72f, c,
            )
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x333DE0FF), Color.Transparent),
                    Offset(size.width * 0.28f, size.height * 0.28f),
                    size.width * 0.48f
                ),
                size.width * 0.48f,
                Offset(size.width * 0.28f, size.height * 0.28f),
            )
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x33E056A0), Color.Transparent),
                    Offset(size.width * 0.78f, size.height * 0.72f),
                    size.width * 0.42f
                ),
                size.width * 0.42f,
                Offset(size.width * 0.78f, size.height * 0.72f),
            )

            // Star field with soft twinkle
            for (s in 0 until 110) {
                val sx = ((s * 97 + 13) % 1000) / 1000f * size.width
                val sy = ((s * 53 + 29) % 1000) / 1000f * size.height
                val flicker = 0.55f + 0.45f * kotlin.math.sin((twinkle.value * 6.28f) + s * 0.7f)
                val a = (0.06f + (s % 7) * 0.035f) * flicker
                drawCircle(Color.White.copy(alpha = a.coerceIn(0.02f, 0.55f)), (0.45f + (s % 3) * 0.4f) * density, Offset(sx, sy))
            }

            // Links: soft glow + core line + dual traveling beads
            nodes.forEachIndexed { i, n ->
                val p = Offset(size.width * n.fx, size.height * n.fy)
                drawLine(n.accent.copy(alpha = 0.22f), c, p, strokeWidth = 7f * density)
                drawLine(
                    Brush.linearGradient(
                        listOf(Color(0xFFB27CFF).copy(alpha = 0.95f), n.accent, n.accent.copy(alpha = 0.55f)),
                        c, p,
                    ),
                    c, p, strokeWidth = 2.2f * density,
                )
                // primary bead
                val f1 = (phase.value + i * 0.17f) % 1f
                val d1 = Offset(c.x + (p.x - c.x) * f1, c.y + (p.y - c.y) * f1)
                drawCircle(n.accent.copy(alpha = 0.5f), 9f * density, d1)
                drawCircle(Color.White.copy(alpha = 0.95f), 2.8f * density, d1)
                // secondary bead (opposite phase)
                val f2 = (phase2.value + 0.55f + i * 0.13f) % 1f
                val d2b = Offset(c.x + (p.x - c.x) * f2, c.y + (p.y - c.y) * f2)
                drawCircle(n.accent.copy(alpha = 0.28f), 6f * density, d2b)
                drawCircle(Color.White.copy(alpha = 0.7f), 1.8f * density, d2b)
            }

            // Central orb — larger, brighter, more rings
            val orbR = 68f * density * (0.96f + 0.07f * (pulse.value - 0.88f) / 0.26f)
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0xCC9B6CFF), Color(0x663DE0FF), Color(0x333DE0FF), Color(0x148B5CFF), Color.Transparent),
                    c, orbR * 3.4f
                ),
                orbR * 3.4f, c,
            )
            // orbit rings
            drawCircle(Color(0x553DE0FF), orbR * 1.28f, c, style = Stroke(1.6f * density))
            drawCircle(Color(0x668B5CFF), orbR * 1.48f, c, style = Stroke(1.2f * density))
            drawCircle(Color(0x33E056A0), orbR * 1.68f, c, style = Stroke(0.9f * density))
            val d2 = (orbR * 2).toInt().coerceAtLeast(1)
            val off = androidx.compose.ui.unit.IntOffset((c.x - orbR).toInt(), (c.y - orbR).toInt())
            val sz = androidx.compose.ui.unit.IntSize(d2, d2)
            rotate(rot.value, c) {
                drawImage(orbCore, dstOffset = off, dstSize = sz, filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
            }
            rotate(-rot.value * 1.65f, c) {
                drawImage(
                    orbSwirl, dstOffset = off, dstSize = sz, alpha = 0.78f,
                    blendMode = androidx.compose.ui.graphics.BlendMode.Plus,
                    filterQuality = androidx.compose.ui.graphics.FilterQuality.High,
                )
            }
            val hl = Offset(c.x - orbR * 0.36f, c.y - orbR * 0.40f)
            drawCircle(
                Brush.radialGradient(listOf(Color.White.copy(alpha = 0.5f), Color.Transparent), hl, orbR * 0.55f),
                orbR * 0.55f, hl,
            )
            drawCircle(Color.White.copy(alpha = 0.4f), orbR, c, style = Stroke(1.3f * density))
            // orbiting beads on rings
            for (k in 0 until 5) {
                val ang = (rot.value * (if (k % 2 == 0) 1.4f else -1.15f) + k * 72f) * 0.0174533f
                val rr = orbR * (1.28f + 0.12f * (k % 3))
                val bp = Offset(c.x + kotlin.math.cos(ang) * rr, c.y + kotlin.math.sin(ang) * rr)
                val col = if (k % 2 == 0) Color(0x883DE0FF) else Color(0x88E056A0)
                drawCircle(col, 5.5f * density, bp)
                drawCircle(Color.White.copy(alpha = 0.9f), 2f * density, bp)
            }
        }
        nodes.forEachIndexed { i, n ->
            Column(
                Modifier
                    .offset(x = w * n.fx - 42.dp, y = h * n.fy - 36.dp)
                    .width(84.dp)
                    .appear(100 + i * 80)
                    .pressable(0.9f) { onNode(n.target) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(58.dp),
                ) {
                    // outer soft glow
                    Box(
                        Modifier
                            .size(58.dp)
                            .background(
                                Brush.radialGradient(
                                    listOf(n.accent.copy(alpha = 0.35f), n.accent.copy(alpha = 0.08f), Color.Transparent)
                                ),
                                CircleShape,
                            )
                    )
                    Box(
                        Modifier
                            .size(48.dp)
                            .shadow(12.dp, CircleShape, ambientColor = n.accent.copy(alpha = 0.55f), spotColor = n.accent.copy(alpha = 0.4f))
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        n.accent.copy(alpha = 0.85f),
                                        n.accent.copy(alpha = 0.35f),
                                        Color(0xFF0A1028),
                                    )
                                ),
                                CircleShape,
                            )
                            .border(
                                1.8.dp,
                                Brush.sweepGradient(
                                    listOf(
                                        n.accent,
                                        Color.White.copy(alpha = 0.55f),
                                        n.accent.copy(alpha = 0.7f),
                                        n.accent,
                                    )
                                ),
                                CircleShape,
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(n.icon, n.label, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
                Text(
                    n.label,
                    color = Color(0xFFE8ECFF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 2.dp),
                )
                Text(
                    counts[i].toString(),
                    color = n.accent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SongList(
    songs: List<Song>,
    lib: LibraryState,
    player: PlayerState,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onMore: (Song) -> Unit,
    emptyTitle: String,
    emptyMessage: String,
    sectioned: Boolean = false,
) {
    if (songs.isEmpty()) {
        EmptyState(
            icon = Icons.Rounded.Favorite,
            title = emptyTitle,
            message = emptyMessage,
        )
        return
    }
    val mode = lib.sortMode
    // (header, songs-with-global-index) in display order
    val sections: List<Pair<String, List<Pair<Int, Song>>>> = remember(songs, mode, sectioned) {
        val out = ArrayList<Pair<String, MutableList<Pair<Int, Song>>>>()
        if (sectioned) {
            songs.forEachIndexed { i, song ->
                val key = sectionKey(song, mode) ?: ""
                if (out.isEmpty() || out.last().first != key) out.add(key to ArrayList())
                out.last().second.add(i to song)
            }
        }
        out
    }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    // list index of each section header (index 0 is the Play / Shuffle row)
    val headerIndex = remember(sections) {
        val map = LinkedHashMap<String, Int>()
        var at = 1
        sections.forEach { (h, list) ->
            map[h] = at
            at += 1 + list.size
        }
        map
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(state = state, contentPadding = PaddingValues(bottom = 24.dp), modifier = Modifier.fillMaxSize()) {
            item(key = "actions") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    GradientButton("Play", Icons.Rounded.PlaylistPlay, { onPlay(songs, 0) })
                    GhostButton("Shuffle", Icons.Rounded.Shuffle, { onShuffle(songs) })
                }
            }
            if (!sectioned) {
                itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
                    SongRow(
                        song = song,
                        isCurrent = player.current?.id == song.id,
                        isPlaying = player.isPlaying,
                        liked = song.id in lib.liked,
                        onClick = { onPlay(songs, index) },
                        onMore = { onMore(song) },
                    )
                }
            } else {
                var headerKeyIndex = 0
                sections.forEach { (header, list) ->
                    if (header.isNotEmpty()) {
                        stickyHeader(key = "h_${headerKeyIndex++}_$header") {
                            Text(
                                header,
                                color = Tx.Accent2,
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Tx.Bg.copy(alpha = 0.96f))
                                    .padding(horizontal = 20.dp, vertical = 6.dp),
                            )
                        }
                    }
                    items(list, key = { it.second.id }) { (index, song) ->
                        SongRow(
                            song = song,
                            isCurrent = player.current?.id == song.id,
                            isPlaying = player.isPlaying,
                            liked = song.id in lib.liked,
                            onClick = { onPlay(songs, index) },
                            onMore = { onMore(song) },
                        )
                    }
                }
            }
        }

        if (sectioned && mode == SortMode.TITLE && headerIndex.size > 3) {
            AlphabetRail(
                letters = headerIndex.keys.toList(),
                modifier = Modifier.align(Alignment.CenterEnd),
                onPick = { letter ->
                    headerIndex[letter]?.let { idx -> scope.launch { state.scrollToItem(idx) } }
                },
            )
        }
    }
}

/** Header text for a song in the current sort mode; null = no sections. */
private fun sectionKey(song: Song, mode: SortMode): String? = when (mode) {
    SortMode.TITLE -> firstLetter(song.title)
    SortMode.ARTIST -> song.artist.ifBlank { "Unknown artist" }
    SortMode.ALBUM -> song.album.ifBlank { "Unknown album" }
    SortMode.DATE_ADDED -> dateBucket(song.dateAdded)
    SortMode.DURATION -> {
        val m = song.durationMs / 60_000L
        when {
            m < 2 -> "Under 2 min"
            m < 4 -> "2–4 min"
            m < 6 -> "4–6 min"
            m < 10 -> "6–10 min"
            else -> "10 min +"
        }
    }
    SortMode.MOST_PLAYED -> null
}

private fun firstLetter(title: String): String {
    val c = title.trim().firstOrNull() ?: return "#"
    return if (c.isLetter()) c.uppercaseChar().toString() else "#"
}

/** [addedSeconds] is MediaStore DATE_ADDED (epoch seconds). */
private fun dateBucket(addedSeconds: Long): String {
    if (addedSeconds <= 0L) return "Unknown date"
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = addedSeconds * 1000L }
    val dayNow = now.get(Calendar.YEAR) * 366 + now.get(Calendar.DAY_OF_YEAR)
    val dayThen = then.get(Calendar.YEAR) * 366 + then.get(Calendar.DAY_OF_YEAR)
    val diff = dayNow - dayThen
    return when {
        diff <= 0 -> "Today"
        diff == 1 -> "Yesterday"
        diff < 7 -> "This week"
        diff < 30 -> "This month"
        else -> SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(then.time)
    }
}

@Composable
private fun SortBar(mode: SortMode, asc: Boolean, onSort: (SortMode) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.SwapVert, null, tint = Tx.Muted, modifier = Modifier.size(18.dp))
        SortMode.values().forEach { m ->
            val active = m == mode
            FilterChip(
                selected = active,
                onClick = { onSort(m) },
                label = { Text(if (active) "${m.label} · ${directionLabel(m, asc)}" else m.label) },
                trailingIcon = if (active) {
                    { Icon(if (asc) Icons.Rounded.ArrowUpward else Icons.Rounded.ArrowDownward, null, modifier = Modifier.size(16.dp)) }
                } else null,
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = Tx.SurfaceHigh,
                    labelColor = Tx.Muted,
                    selectedContainerColor = Tx.Accent.copy(alpha = 0.85f),
                    selectedLabelColor = androidx.compose.ui.graphics.Color.White,
                    selectedTrailingIconColor = androidx.compose.ui.graphics.Color.White,
                ),
                border = null,
            )
        }
    }
}

private fun directionLabel(mode: SortMode, asc: Boolean): String = when (mode) {
    SortMode.DATE_ADDED -> if (asc) "Oldest" else "Newest"
    SortMode.DURATION -> if (asc) "Shortest" else "Longest"
    SortMode.TITLE -> if (asc) "A→Z" else "Z→A"
    SortMode.ARTIST, SortMode.ALBUM -> if (asc) "A→Z" else "Z→A"
    SortMode.MOST_PLAYED -> if (asc) "Least" else "Most"
}

@Composable
private fun AlphabetRail(letters: List<String>, modifier: Modifier, onPick: (String) -> Unit) {
    var height by remember { mutableIntStateOf(1) }
    var last by remember { mutableStateOf("") }
    fun pick(y: Float) {
        if (letters.isEmpty()) return
        val i = ((y / height) * letters.size).toInt().coerceIn(0, letters.lastIndex)
        val l = letters[i]
        if (l != last) { last = l; onPick(l) }
    }
    Column(
        modifier
            .padding(end = 2.dp)
            .onSizeChanged { height = it.height.coerceAtLeast(1) }
            .pointerInput(letters) { detectTapGestures { pick(it.y) } }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onDragStart = { pick(it.y) },
                    onVerticalDrag = { change, _ -> pick(change.position.y) },
                )
            }
            .padding(horizontal = 6.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        letters.forEach { l ->
            Text(l, color = Tx.Accent2, fontSize = 10.sp, lineHeight = 12.sp)
        }
    }
}

@Composable
private fun PlaylistsTab(
    playlists: List<Playlist>,
    onOpen: (Playlist) -> Unit,
    onNew: () -> Unit,
) {
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                GradientButton("New playlist", Icons.Rounded.Add, onNew)
            }
        }
        if (playlists.isEmpty()) {
            item {
                Text(
                    "No playlists yet. Create one, then add songs from any song's menu.",
                    color = Tx.Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
                )
            }
        }
        items(playlists, key = { it.id }) { p ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onOpen(p) }
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GradientTile(p.id, Icons.Rounded.PlaylistPlay, Modifier.size(60.dp), corner = 14.dp, iconSize = 28.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(p.name, color = Tx.Text, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(songCount(p.songIds.size), color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}


@Composable
private fun ConstellationNode(
    modifier: Modifier = Modifier,
    count: String,
    label: String,
    accent: Color,
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(Color(0x22101830))
                .border(1.5.dp, accent.copy(alpha = 0.75f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(count, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Tx.Muted, style = MaterialTheme.typography.labelSmall)
    }
}


/** Library "Explore" tab: a grid with every screen and tool in the app. */
@Composable
private fun ExploreGrid(onNavigate: (NavTarget) -> Unit) {
    val sections = remember { NavCatalog.groupBy { it.section } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp)) {
        sections.forEach { (title, items) ->
            Text(
                title, color = Color(0xFF3DE0FF), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 6.dp, top = 14.dp, bottom = 8.dp),
            )
            items.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { item ->
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Brush.linearGradient(listOf(item.accent.copy(0.22f), Color(0x0DFFFFFF))))
                                .border(1.dp, item.accent.copy(0.35f), RoundedCornerShape(18.dp))
                                .clickable { onNavigate(item.target) }
                                .padding(14.dp),
                        ) {
                            Icon(item.icon, null, tint = item.accent, modifier = Modifier.size(26.dp))
                            Spacer(Modifier.height(10.dp))
                            Text(item.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(item.subtitle, color = Color(0xFF8A92B0), fontSize = 11.sp, maxLines = 2)
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}


/** Library sessions: (destination, short tab label). Tab ids are 10 + index. */
val LibrarySessions = listOf(
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.MemoryCinema to "Cinema",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.EmotionalGps to "GPS",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.TwinRoom to "Twin",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.SharedPulse to "Pulse",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.SongAutopsy to "Autopsy",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.TimeCapsule to "Capsule",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.Sanctuary to "Sanctuary",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.WorldFrequency to "Frequency",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.IdentitySoundtrack to "Identity",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.RepairSession to "Repair",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.DreamMode to "Dream",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.ResonanceLab to "Lab",
    // New rituals
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.EmotionalWeather to "Weather",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.MemoryAnchors to "Anchors",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.GhostQueue to "Ghost",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.LivingSongs to "Living",
    com.texgen.music.texwave.ui.screens.universe.UniverseDest.TheUnplayed to "Unplayed",
)
