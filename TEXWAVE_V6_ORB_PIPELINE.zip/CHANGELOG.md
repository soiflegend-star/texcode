## Chat fix release
- Any email can sign up / log in (auto-confirm), profiles always exist, working search, live typing / seen / online status, avatar upload. See ../TEXWAVE_CHAT_FIX_NOTES.md.

## 6.9.0 — Full concept-board UI, motion and sound
- **Now Playing** rebuilt: glowing orbit rings around the circular cover, animated bar visualiser, glow seek bar with draggable dot, gradient play button that breathes, Lyrics pill, ⋮ menu (queue, sleep timer, speed, equalizer, editor, vinyl, cover image, settings).
- **Library**: board-style header with search, pill tabs, animated constellation (orb + pulsing links, tap a node to open that list) and a Recently Added row.
- **Phantom**: orb with an orbiting light, Memory Core card with count-up numbers, Listening Insights built from your own library/history, quote footer; all existing Phantom tools stay below.
- **Search**: glass search field with artist rows above song results.
- **Motion**: cross-fade between tabs, staggered fade/rise-in on every screen, press squish on cards and buttons, twinkling stars, pulsing hero ring, animated wave glyph.
- **Sound**: 7 built-in interface sounds (tap, tab, play, pause, select, open, like) via SoundPool; they never pause or duck your music. Toggle: Library ⋮ → "UI sounds".
- Not compiled in the authoring environment (no Gradle access) — build in Android Studio.

## 6.8.0 — Home screen matches the concept board
- Rebuilt Home (`ResonancePortalScreen`) to match the first screen of the design reference: TEXWAVE header with waveform glyph and Phantom orb, full-width hero artwork with greeting, gradient play button and Your Library pill, MoodWave illustrated cards, and a Recently Played card with live progress.
- New shared bottom bar (`TexNavBar`) with the glowing teal active pill; the global mini player is hidden on Home because Recently Played replaces it.
- New artwork: `home_hero.png`, `mood_rainy/unstoppable/focus/afterhours.png` (drawable-nodpi).
- Not compiled in the authoring environment (no Gradle access) — build in Android Studio.


## 6.2.1 — Resonance Universe visual pass

- Refined the home-screen sequence around the original TEXWAVE cosmic identity: arrival header, central resonance artwork, MoodWave, and real recently played tracks.
- Added a shared animated Sonic Atmosphere for Library and Phantom: restrained star twinkle, slowly moving nebula light, and layered cyan-to-violet resonance ribbons.
- Added a Phantom Memory Core summary card that displays actual local library totals (songs, liked tracks, and recent entries); it does not invent personal-memory counts.
- Refined the Now Playing artwork into a circular, luminous cover with a cyan/violet orbit border while preserving the existing playback controls and cover-image actions.
- Added a small spring animation to Library tab selection and retained existing home ripples, playback breathing, visualizer motion, Phantom pulse, and constellation shooting-star feedback.
- Preserved the existing app navigation, Media3 playback, library persistence, and Phantom feature handlers; no dummy songs or fake playback progress were added.
- Build verification could not complete in this environment because Gradle 8.5 could not be downloaded (network DNS unavailable). Run the Android build in Android Studio or an environment with Gradle access before installing.

## 6.1.4 — Crash protection
- Crash catcher: if the app ever crashes, the next launch shows the exact error (copyable) and offers Safe mode / Reset
- Last session is restored paused (no playback or notification service at launch)
- Notification build can no longer take the app down (falls back to a plain notification)
- Background loops are crash-isolated; library header keys made unique

## 5.5.0 — SOIF notification, sorting, Phantom tab
- **Library sorting**: Date added (default, newest first), Length, A–Z (with letter rail), Artist, Album, Most played; tap a chip again to flip direction; sticky section headers; choice is remembered
- **Phantom** is now a bottom tab (floating orb removed, chat button in the Phantom header)
- **Set image** button on the Now Playing cover (also long-press); images are copied into app storage so they persist; shown in the notification too
- **Notification rebuilt**: 5 working controls (-10s, previous, play/pause, next, +10s), SOIF stylised as the artist line, SOIF logo on the artwork, live preview in Settings
- **Animated notification styles** drawn per frame: wave, pulse, vinyl, particles, spectrum, galaxy, liquid, neon grid; **pick your own video** (frames are cut and played as the animation)
- **Smoothness**: playback position split into its own stream so only the seek bar redraws; draw-phase animations; fewer background loops
- Particles now work on Now Playing (toggle in Settings); beat-reactive visuals are opt-in
- Skip silence now actually applies to the player

## 5.0.0 — PHANTOM core + video fixes
- **Full storage scan**: dual-pass MediaStore (IS_MUSIC + any audio ≥3s) — fewer missing songs
- **Water-flow visualizer**: dots grow/shrink in a flowing wave, driven by music hardness
- Removed static lines above song title
- **Play button**: true circle with brand gradient + glow (fits cleanly)
- **Emotion Reactor**: Rainy Night, Unstoppable, Lost in Space, Let Me Think, Final Boss, Deep Focus, Night Drive
- **Infinite Mix**: energy-flow ordered session from your library
- **PHANTOM offline engine**: emotion feedback, Music DNA clusters, similar tracks, Memory Lane, sound profiles, Creator bookmarks
- Performance: lighter position ticks
- Notification custom image + themes still via Settings (gallery pickers)
- Groq API hooks ready — provide key when you want online intelligence

## 4.0.2
- Fixed audioSessionId expression-body compile error

## Build-fix follow-up (2026-10-11)
- Removed the unsupported `onEmotion` argument from the `MiniPlayer` call; mood playback remains connected through the existing MoodWave/Phantom controls.
- Adapted the Phantom `memoryFor` callback to return the saved memory text (`MemoryNote.note`) required by `PhantomScreen`.
- Re-ran the local Gradle build attempt. Build execution could not start because this environment cannot resolve `services.gradle.org` to download the Gradle 8.5 distribution; a successful compile remains unverified here.

## Stability patch — permission and media scan hardening
- Removed the automatic POST_NOTIFICATIONS permission prompt that followed audio permission during startup; optional permissions should be requested only when the user invokes the feature that needs them.
- Re-check audio permission after the system dialog and show a helpful message if it was denied.
- Hardened MediaStore scanning against provider-specific row failures and removed reliance on the deprecated DATA column.
- Constructed track content URIs from the queried MediaStore collection.
- Removed the unused READ_MEDIA_IMAGES manifest permission.
- Android build could not be verified in this environment because services.gradle.org could not be resolved.

## Permission/startup stability patch
- Deferred the first MediaStore scan briefly after audio permission is granted, allowing the Android permission sheet/activity transition to settle.
- Reduced library indexing from two full MediaStore queries to one query to lower startup CPU, memory, and provider load on large libraries and OEM Android builds.
- Kept the initial permission flow limited to audio access; microphone, notifications, and overlay access remain feature-specific.
- Build verification could not run in this environment because `services.gradle.org` was unreachable; this patch is source-level and still needs a build/runtime test on device.
