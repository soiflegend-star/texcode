package com.texgen.music.texwave.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.Tx

/** Space an overlay should leave at its bottom so the dock sits under it, not on top of it. */
val DockHeight: Dp = 86.dp

private class DockItem(
    val target: NavTarget,
    val label: String,
    val icon: ImageVector,
    val accent: Color,
    val hero: Boolean = false,
)

private val DockItems: List<DockItem> = listOf(
    DockItem(NavTarget.Home, "Home", Icons.Rounded.Home, Color(0xFF5CE1FF)),
    DockItem(NavTarget.Search, "Search", Icons.Rounded.Search, Color(0xFF5CE1FF)),
    DockItem(NavTarget.Library, "Library", Icons.Rounded.LibraryMusic, Color(0xFF9B5CFF)),
    DockItem(NavTarget.Voice, "Talk", Icons.Rounded.Mic, Color(0xFFFF58D8), hero = true),
    DockItem(NavTarget.Chats, "Chats", Icons.Rounded.Chat, Color(0xFF5CE1FF)),
    DockItem(NavTarget.Alarms, "Alarms", Icons.Rounded.Alarm, Color(0xFFFFC857)),
    DockItem(NavTarget.Stars, "Stars", Icons.Rounded.AutoAwesome, Color(0xFFB48CFF)),
    DockItem(NavTarget.Editor, "Editor", Icons.Rounded.Edit, Color(0xFF3DFFB0)),
    DockItem(NavTarget.Equalizer, "EQ", Icons.Rounded.Equalizer, Color(0xFF6C8CFF)),
    DockItem(NavTarget.Earbuds, "Earbuds", Icons.Rounded.Headphones, Color(0xFF9B5CFF)),
    DockItem(NavTarget.Phantom, "Phantom", Icons.Rounded.SmartToy, Color(0xFF9B5CFF)),
    DockItem(NavTarget.Brain, "Brains", Icons.Rounded.Psychology, Color(0xFF3DFFB0)),
    DockItem(NavTarget.Velocity, "Velocity", Icons.Rounded.SportsEsports, Color(0xFFFFC857)),
)

/**
 * AUVYRR dock: one floating glass capsule that holds every major feature. It scrolls sideways
 * (edges fade out so it is obvious there is more), keeps the selected feature in view, and the
 * Menu button on the right opens the full catalogue.
 */
@Composable
fun AuvyrrDock(
    selected: NavTarget?,
    onSelect: (NavTarget) -> Unit,
    onMenu: () -> Unit,
) {
    val sound = rememberUiSound()
    val listState = rememberLazyListState()
    LaunchedEffect(selected) {
        val i = DockItems.indexOfFirst { it.target == selected }
        if (i >= 0) listState.animateScrollToItem((i - 1).coerceAtLeast(0))
    }
    val sweep by rememberInfiniteTransition(label = "dockSweep").animateFloat(
        0f, 1200f,
        infiniteRepeatable(tween(3600, easing = LinearEasing), RepeatMode.Restart),
        label = "dockSweepX",
    )
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(70.dp)
                .shadow(24.dp, shape, ambientColor = Tx.Accent.copy(alpha = 0.25f), spotColor = Tx.Accent3.copy(alpha = 0.2f))
                .clip(shape)
                .background(Tx.Bg.copy(alpha = 0.94f))
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.02f))))
                .border(
                    1.dp,
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = 0.14f),
                            Tx.Accent.copy(alpha = 0.55f),
                            Tx.Accent2.copy(alpha = 0.45f),
                            Tx.Accent3.copy(alpha = 0.25f),
                            Color.White.copy(alpha = 0.08f),
                        ),
                        start = Offset(sweep, 0f),
                        end = Offset(sweep + 700f, 0f),
                        tileMode = TileMode.Repeated,
                    ),
                    shape,
                ),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LazyRow(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            Brush.horizontalGradient(
                                0f to Color.Transparent,
                                0.05f to Color.Black,
                                0.93f to Color.Black,
                                1f to Color.Transparent,
                            ),
                            blendMode = BlendMode.DstIn,
                        )
                    },
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                itemsIndexed(DockItems, key = { _, it -> it.target.name }) { _, item ->
                    DockButton(item, item.target == selected) {
                        if (item.target != selected) sound(com.texgen.music.texwave.util.UiSound.Kind.TAB)
                        onSelect(item.target)
                    }
                }
            }
            Box(
                Modifier
                    .padding(end = 8.dp)
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { onMenu() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.GridView, "Menu", tint = Color.White, modifier = Modifier.size(24.dp))
            }
        }
    }
}

@Composable
private fun DockButton(item: DockItem, on: Boolean, onClick: () -> Unit) {
    val t by animateFloatAsState(
        if (on) 1f else 0f,
        spring(dampingRatio = 0.55f, stiffness = 380f),
        label = "dockT",
    )
    val tint by animateColorAsState(
        if (on || item.hero) Color.White else Color(0xFF8B93A7),
        tween(220),
        label = "dockTint",
    )
    val labelColor by animateColorAsState(
        if (on) item.accent else Color(0xFF7C849A),
        tween(220),
        label = "dockLabel",
    )
    Column(
        Modifier
            .width(62.dp)
            .fillMaxHeight()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .width(46.dp)
                .height(32.dp)
                .graphicsLayer {
                    val s = 1f + 0.14f * t
                    scaleX = s
                    scaleY = s
                    translationY = -2.dp.toPx() * t
                }
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (item.hero) {
                        Brush.horizontalGradient(listOf(Tx.Accent.copy(alpha = 0.9f), item.accent.copy(alpha = 0.9f)))
                    } else {
                        Brush.horizontalGradient(
                            listOf(item.accent.copy(alpha = 0.30f * t), item.accent.copy(alpha = 0.12f * t)),
                        )
                    },
                )
                .border(
                    1.dp,
                    Brush.horizontalGradient(
                        listOf(item.accent.copy(alpha = 0.8f * t), item.accent.copy(alpha = 0.35f * t)),
                    ),
                    RoundedCornerShape(16.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(item.icon, item.label, tint = tint, modifier = Modifier.size(22.dp))
        }
        Text(
            item.label,
            color = labelColor,
            fontSize = 10.5.sp,
            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            modifier = Modifier.padding(top = 3.dp),
        )
    }
}
