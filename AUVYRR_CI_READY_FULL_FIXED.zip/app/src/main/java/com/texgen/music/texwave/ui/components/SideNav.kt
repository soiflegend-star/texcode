package com.texgen.music.texwave.ui.components

import com.texgen.music.texwave.ui.theme.Tx

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Biotech
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.WbTwilight
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.NearMe
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens

/** Everything the side navigation (and the Library "Explore" tab) can open. */
enum class NavTarget {
    Home, Search, Library, LibraryOrb, Stars, Radar, Explore, Downloads, Community,
    // Library sessions — keep these contiguous and in this order
    SesCinema, SesGps, SesTwin, SesPulse, SesAutopsy, SesCapsule, SesSanctuary,
    SesFrequency, SesIdentity, SesRepair, SesDream, SesLab,
    SesWeather, SesAnchors, SesGhost, SesLiving, SesUnplayed,
    LovedRooms,
    Chats, Phantom, PhantomChat, PhantomKey, PhantomCode, PhantomImage,
    Voice, Equalizer, Editor, Earbuds, Alarms, SleepTimer, Rescan, Theme, Sounds, Sonara, Brain,
    Profile, Settings, Notifications, NotifEditor,
    Arena, Velocity,
}

data class NavItem(
    val target: NavTarget,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val section: String,
)

private val Cyan = Tx.Accent2
private val Violet = Tx.Accent
private val Pink = Color(0xFFFF4FB0)
private val Mint = Color(0xFF3DFFB0)
private val Amber = Color(0xFFFFC857)
private val Blue = Color(0xFF6C8CFF)

val NavCatalog: List<NavItem> = listOf(
    // ── The main sessions ──
    NavItem(NavTarget.Home, "Home", "Mixes, moods and recents", Icons.Rounded.Home, Cyan, "CORE"),
    NavItem(NavTarget.Search, "Search", "Find any song or artist", Icons.Rounded.Search, Cyan, "CORE"),
    NavItem(NavTarget.Library, "Library", "On device + online music in one place", Icons.Rounded.LibraryMusic, Violet, "CORE"),
    NavItem(NavTarget.Chats, "Chats", "Messages, calls, groups", Icons.Rounded.Chat, Cyan, "CORE"),
    NavItem(NavTarget.Phantom, "Phantom", "Your AI companion", Icons.Rounded.SmartToy, Violet, "CORE"),
    NavItem(NavTarget.Voice, "Voice chat", "Talk to your offline Brain, hands-free", Icons.Rounded.Mic, Pink, "CORE"),
    NavItem(NavTarget.Brain, "Brains", "Download an offline Brain — talk and play music with no internet", Icons.Rounded.Psychology, Mint, "CORE"),
    NavItem(NavTarget.Alarms, "Alarms", "Wake up to your music", Icons.Rounded.Alarm, Amber, "DISCOVER"),
    NavItem(NavTarget.Stars, "Constellation", "Your songs as a star map", Icons.Rounded.AutoAwesome, Violet, "DISCOVER"),
    NavItem(NavTarget.Radar, "Pulse Radar", "Listening map and smart mixes", Icons.Rounded.TrackChanges, Mint, "DISCOVER"),
    NavItem(NavTarget.Explore, "Online in Library", "Opens Library → Online catalog", Icons.Rounded.Cloud, Amber, "DISCOVER"),
    NavItem(NavTarget.Community, "Community", "Photos, filters, songs — like and comment", Icons.Rounded.Image, Violet, "SOCIAL"),
    NavItem(NavTarget.Downloads, "Downloads", "Search and save music for offline", Icons.Rounded.CloudDownload, Mint, "SOCIAL"),
    // ── Library sessions ──
    NavItem(NavTarget.SesCinema, "Memory Cinema", "Your listening year as a film", Icons.Rounded.Movie, Pink, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesGps, "Emotional GPS", "Pick where you need to arrive", Icons.Rounded.NearMe, Cyan, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesTwin, "Twin Room", "Listen in sync with a twin", Icons.Rounded.People, Violet, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesPulse, "Shared Pulse", "Feel the same beat together", Icons.Rounded.Favorite, Pink, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesAutopsy, "Song Autopsy", "Break a song apart", Icons.Rounded.Science, Mint, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesCapsule, "Time Capsule", "Songs from your past", Icons.Rounded.HourglassBottom, Amber, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesSanctuary, "Sanctuary", "Rules only, no recommendations", Icons.Rounded.Lock, Cyan, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesFrequency, "World Frequency", "Global feeling heatmap", Icons.Rounded.Public, Violet, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesIdentity, "Identity Soundtrack", "Build a character in songs", Icons.Rounded.Face, Pink, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesRepair, "Repair Session", "Calm things down with music", Icons.Rounded.SelfImprovement, Cyan, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesDream, "Dream Mode", "Overnight landing sequence", Icons.Rounded.WbTwilight, Violet, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesLab, "Resonance Lab", "How your community listens", Icons.Rounded.Biotech, Pink, "LIBRARY SESSIONS"),
    // ── Rituals (new) ──
    NavItem(NavTarget.SesWeather, "Emotional Weather", "Music that matches the sky inside", Icons.Rounded.WbTwilight, Cyan, "RITUALS"),
    NavItem(NavTarget.SesAnchors, "Memory Anchors", "Songs locked to real moments", Icons.Rounded.HourglassBottom, Pink, "RITUALS"),
    NavItem(NavTarget.SesGhost, "Ghost Queue", "The timeline you almost lived", Icons.Rounded.People, Violet, "RITUALS"),
    NavItem(NavTarget.SesLiving, "Living Songs", "Tracks that grow a soul", Icons.Rounded.Favorite, Mint, "RITUALS"),
    NavItem(NavTarget.SesUnplayed, "The Unplayed", "Sacred tracks never finished", Icons.Rounded.Lock, Amber, "RITUALS"),
    NavItem(NavTarget.LovedRooms, "Rooms I’d stay in", "Ten screens made to feel human", Icons.Rounded.AutoAwesome, Pink, "RITUALS"),
    // ── Phantom ──
    NavItem(NavTarget.PhantomChat, "Phantom chat", "Talk with Phantom", Icons.Rounded.Chat, Violet, "PHANTOM"),
    NavItem(NavTarget.PhantomKey, "Phantom API key", "Add or change your key", Icons.Rounded.Key, Amber, "PHANTOM"),
    // ── Tools and settings (everything from the old 3-dot menu) ──
    NavItem(NavTarget.Sonara, "Sonara", "Stream, discover and build playlists", Icons.Rounded.LibraryMusic, Violet, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Equalizer, "Equalizer", "Bands, bass and presets", Icons.Rounded.Equalizer, Cyan, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Velocity, "Velocity", "Race your song in a 3D runner", Icons.Rounded.SportsEsports, Amber, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Earbuds, "Earbuds", "Connect, identify and sync your earbuds", Icons.Rounded.Headphones, Violet, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Editor, "Music editor", "Tags, artwork and online sync", Icons.Rounded.Tune, Violet, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Rescan, "Rescan library", "Look for new songs", Icons.Rounded.Refresh, Mint, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Sounds, "UI sounds", "Tap sounds on or off", Icons.Rounded.VolumeUp, Cyan, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.SleepTimer, "Sleep timer", "Stop playback later", Icons.Rounded.Bedtime, Blue, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Theme, "Player background", "Pick your own image", Icons.Rounded.Palette, Violet, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Profile, "My profile", "Edit profile, stats, cloud backup", Icons.Rounded.Person, Pink, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.NotifEditor, "Notification editor", "Sound, privacy & quiet hours for alerts", Icons.Rounded.Notifications, Amber, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Notifications, "Notifications", "Alerts and message settings", Icons.Rounded.Notifications, Amber, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Settings, "Settings", "Everything else", Icons.Rounded.Settings, Blue, "TOOLS AND SETTINGS"),
)

private sealed class Row2 {
    data class Header(val text: String) : Row2()
    data class Entry(val item: NavItem) : Row2()
}

/**
 * Side navigation — same look as the Chat sidebar. Shown first, closed with one tap
 * (X, the dark area, a swipe left, or Back), brought back with the edge handle.
 */
@Composable
fun SideNavDrawer(
    visible: Boolean,
    soundsOn: Boolean,
    selected: NavTarget?,
    onDismiss: () -> Unit,
    onSelect: (NavTarget) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    // Keep the drawer useful at a glance: core and social destinations are open;
    // deeper music rituals and tools stay grouped until requested or searched.
    var expandedSections by remember { mutableStateOf(setOf("CORE", "SOCIAL")) }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(tween(200)), exit = fadeOut(tween(180))) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x66000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        query = ""; onDismiss()
                    },
            )
        }
        AnimatedVisibility(
            visible = visible,
            enter = slideInHorizontally(tween(260)) { -it } + fadeIn(tween(220)),
            exit = slideOutHorizontally(tween(220)) { -it } + fadeOut(tween(180)),
            modifier = Modifier.align(Alignment.CenterStart),
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .width(248.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xF2161618),
                                Color(0xF50F0F11),
                                Color(0xF20B0B0D),
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            listOf(
                                Tx.Accent2.copy(alpha = 0.45f),
                                Tx.Accent.copy(alpha = 0.35f),
                                Tx.Accent3.copy(alpha = 0.25f),
                            )
                        ),
                        shape = RoundedCornerShape(topEnd = 22.dp, bottomEnd = 22.dp),
                    )
                    .clip(RoundedCornerShape(topEnd = 22.dp, bottomEnd = 22.dp))
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { _, dx -> if (dx < -18f) { query = ""; onDismiss() } }
                    }
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(bottom = 12.dp),
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("AUVYRR", color = Tx.Accent2, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 1.6.sp)
                        Text("Navigate", color = Color(0xFF8A82A8), fontSize = 11.sp)
                    }
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(0x22FFFFFF))
                            .clickable { query = ""; onDismiss() },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Close, "Close menu", tint = Color.White, modifier = Modifier.size(18.dp)) }
                }
                Box(
                    Modifier.fillMaxWidth().height(1.dp).padding(horizontal = 16.dp).background(
                        Brush.horizontalGradient(listOf(Color.Transparent, TexTokens.Violet.copy(alpha = 0.28f), Color.Transparent))
                    )
                )
                Row(
                    Modifier
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x0FFFFFFF))
                        .border(1.dp, Color(0x14FFFFFF), RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Search, null, tint = Color(0xFF8A8F9C), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Find a screen or setting", color = Color(0xFF6B7392), fontSize = 14.sp)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                            cursorBrush = SolidColor(TexTokens.Cyan),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                val rows = remember(query, expandedSections) {
                    val q = query.trim().lowercase()
                    val list = NavCatalog.filter {
                        q.isEmpty() || it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q)
                    }
                    buildList<Row2> {
                        val grouped = list.groupBy { it.section }
                        grouped.forEach { (section, entries) ->
                            add(Row2.Header(section))
                            if (q.isNotEmpty() || section in expandedSections) entries.forEach { add(Row2.Entry(it)) }
                        }
                    }
                }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    if (rows.isEmpty()) {
                        item { Text("Nothing matches \"$query\"", color = Color(0xFF8A8F9C), fontSize = 13.sp, modifier = Modifier.padding(16.dp)) }
                    }
                    items(rows) { r ->
                        when (r) {
                            is Row2.Header -> Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        if (query.isBlank()) expandedSections = if (r.text in expandedSections) expandedSections - r.text else expandedSections + r.text
                                    }
                                    .padding(start = 8.dp, end = 6.dp, top = 11.dp, bottom = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    r.text,
                                    color = Color(0xFF7D86A7),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.6.sp,
                                    modifier = Modifier.weight(1f),
                                )
                                if (query.isBlank()) Icon(
                                    if (r.text in expandedSections) Icons.Rounded.ExpandMore else Icons.Rounded.ChevronRight,
                                    contentDescription = if (r.text in expandedSections) "Collapse ${r.text}" else "Expand ${r.text}",
                                    tint = Color(0xFF7D86A7), modifier = Modifier.size(16.dp),
                                )
                            }
                            is Row2.Entry -> NavRow(r.item, r.item.target == selected, soundsOn) { query = ""; onSelect(r.item.target) }
                        }
                    }
                }
                Text(
                    "Tap the X to hide this menu",
                    color = TexTokens.TextSecondary.copy(alpha = 0.6f), fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun NavRow(item: NavItem, selected: Boolean, soundsOn: Boolean, onClick: () -> Unit) {
    val isSound = item.target == NavTarget.Sounds
    val icon = if (isSound && !soundsOn) Icons.Rounded.VolumeOff else item.icon
    val label = if (isSound) (if (soundsOn) "UI sounds: on" else "UI sounds: off") else item.title
    val shape = RoundedCornerShape(14.dp)
    val accent = item.accent
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                if (selected)
                    Brush.horizontalGradient(
                        listOf(accent.copy(alpha = 0.22f), Tx.Accent2.copy(alpha = 0.08f), Color.Transparent)
                    )
                else
                    Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
            )
            .then(
                if (selected) Modifier.border(
                    1.dp,
                    Brush.horizontalGradient(
                        listOf(accent.copy(alpha = 0.65f), Tx.Accent2.copy(alpha = 0.4f))
                    ),
                    shape,
                ) else Modifier
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(if (selected) accent.copy(alpha = 0.28f) else Color(0x14FFFFFF)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                label,
                tint = if (selected) accent else Color(0xFFB0B8D0),
                modifier = Modifier.size(17.dp),
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            label,
            color = if (selected) Color(0xFFF7F8FF) else Color(0xFFD8DCEB),
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            fontSize = 13.sp,
            maxLines = 1,
            modifier = Modifier.weight(1f),
        )
        if (selected) {
            Box(Modifier.size(5.dp).clip(CircleShape).background(accent))
        }
    }
}

/** Slim tab on the left edge. Tap it or drag it to the right to open the menu. */
@Composable
fun SideNavHandle(onOpen: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .width(18.dp)
            .height(64.dp)
            .clip(RoundedCornerShape(topEnd = 14.dp, bottomEnd = 14.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Violet.copy(alpha = 0.45f), Cyan.copy(alpha = 0.35f))
                )
            )
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Cyan.copy(alpha = 0.4f), Violet.copy(alpha = 0.25f))),
                RoundedCornerShape(topEnd = 14.dp, bottomEnd = 14.dp),
            )
            .pointerInput(Unit) { detectHorizontalDragGestures { _, dx -> if (dx > 10f) onOpen() } }
            .clickable(onClick = onOpen),
        contentAlignment = Alignment.Center,
    ) { Text("›", color = Color.White.copy(alpha = 0.9f), fontSize = 17.sp, fontWeight = FontWeight.Bold) }
}


/** Always-visible slim icon rail. Menu = expand the full drawer, chevron = hide the rail. */
@Composable
fun SideNavRail(
    selected: NavTarget?,
    soundsOn: Boolean,
    onSelect: (NavTarget) -> Unit,
    onExpand: () -> Unit,
    onHide: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxHeight()
            .width(RailWidth)
            .background(Brush.verticalGradient(listOf(Color(0xE6141416), Color(0xF00F0F11), Color(0xF0131315))))
            .border(width = 1.dp, color = Color(0x183DE0FF))
            .statusBarsPadding()
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.padding(top = 8.dp).size(42.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Cyan.copy(alpha = 0.35f), Violet.copy(alpha = 0.35f))))
                .clickable(onClick = onExpand),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Menu, "Open menu", tint = Color.White) }
        Spacer(Modifier.height(6.dp))
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Keep the always-visible rail focused on core destinations. The expanded drawer
            // remains searchable for the full feature catalog, so the rail never becomes noisy.
            val railTargets = listOf(
                NavTarget.Home, NavTarget.Search, NavTarget.Library, NavTarget.Chats,
                NavTarget.Phantom, NavTarget.Community, NavTarget.Downloads,
            )
            railTargets.forEachIndexed { index, target ->
                val item = NavCatalog.firstOrNull { it.target == target } ?: return@forEachIndexed
                if (index == 3) {
                    Box(Modifier.padding(vertical = 7.dp).width(26.dp).height(1.dp).background(
                        Brush.horizontalGradient(listOf(Color.Transparent, Cyan.copy(alpha = .65f), Violet.copy(alpha = .5f), Color.Transparent))))
                }
                val on = item.target == selected
                val icon = if (item.target == NavTarget.Sounds && !soundsOn) Icons.Rounded.VolumeOff else item.icon
                Box(
                    Modifier.padding(vertical = 3.dp).size(44.dp).clip(RoundedCornerShape(15.dp))
                        .background(if (on) Brush.linearGradient(listOf(item.accent.copy(alpha = .34f), Violet.copy(alpha = .18f))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                        .then(if (on) Modifier.border(1.dp, Brush.linearGradient(listOf(item.accent.copy(alpha = .85f), Cyan.copy(alpha = .5f))), RoundedCornerShape(15.dp)) else Modifier)
                        .clickable { onSelect(item.target) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (on) Box(Modifier.align(Alignment.CenterStart).width(3.dp).height(22.dp).clip(RoundedCornerShape(4.dp)).background(item.accent))
                    Icon(icon, item.title, tint = if (on) item.accent else Color(0xFF8A92B0), modifier = Modifier.size(22.dp))
                }
            }
        }
        Box(
            Modifier.padding(vertical = 8.dp).size(40.dp).clip(CircleShape)
                .background(Color(0x142BE4A4)).clickable(onClick = onExpand),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.AutoAwesome, "Explore all features", tint = Color(0xFF9AA2C2)) }
    }
}

val RailWidth = 56.dp
