package com.texgen.music.texwave.ui.screens

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.tagger.StoragePerm
import com.texgen.music.texwave.tagger.SyncProgress
import com.texgen.music.texwave.tagger.TagCandidate
import com.texgen.music.texwave.tagger.TagEdit
import com.texgen.music.texwave.tagger.TagLookup
import com.texgen.music.texwave.tagger.TagStore
import com.texgen.music.texwave.util.NetUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val TgBg = Color(0xFF07080D)
private val TgText = Color(0xFFF5F6FB)
private val TgMuted = Color(0xFFA0A5BB)
private val TgAccent = Color(0xFF8B7BFF)
private val TgAccent2 = Color(0xFF4FA3FF)
private val TgGood = Color(0xFF45E3A4)
private val TgWarn = Color(0xFFFFC46B)
private val TgBad = Color(0xFFFF7D8D)

/** Frosted-glass surface: translucent gradient fill with a bright rim light. */
private fun Modifier.glass(radius: Dp = 22.dp, strength: Float = 1f, tint: Color = Color.White): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .clip(shape)
        .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.17f * strength), tint.copy(alpha = 0.05f * strength))))
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.22f))),
            shape,
        )
}

/** Dark base with slowly drifting colour orbs, which is what the glass panels appear to float above. */
@Composable
private fun GlassBackdrop() {
    val t = rememberInfiniteTransition(label = "orbs")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(1f, 0f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Canvas(Modifier.fillMaxSize().background(TgBg)) {
        val w = size.width
        val h = size.height
        fun orb(c: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
        }
        orb(Color(0x667B5CFF), w * (0.15f + 0.25f * a), h * (0.12f + 0.08f * b), w * 0.85f)
        orb(Color(0x5538B6FF), w * (0.95f - 0.3f * b), h * (0.42f + 0.1f * a), w * 0.8f)
        orb(Color(0x44FF5CB8), w * (0.2f + 0.2f * b), h * (0.85f - 0.1f * a), w * 0.75f)
    }
}

/**
 * Tag editor: fixes titles, artists, albums and artwork for the songs on this device, writing them into the real
 * audio files once file access is allowed. Every song can be matched online with a preview first, or all songs can be
 * synced in one tap.
 */
@Composable
fun TagEditorScreen(songs: List<Song>, onBack: () -> Unit, onOpenTrim: () -> Unit = {}) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val edits by TagStore.edits.collectAsState()
    val progress by TagStore.progress.collectAsState()
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    var editingId by remember { mutableStateOf<Long?>(null) }
    var confirmAll by remember { mutableStateOf(false) }
    var forceAll by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var permOk by remember { mutableStateOf(StoragePerm.granted(context)) }
    var skippedGate by remember { mutableStateOf(false) }

    val legacyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permOk = StoragePerm.granted(context)
    }
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) permOk = StoragePerm.granted(context)
        }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }
    val askPermission: () -> Unit = {
        if (StoragePerm.needsSettingsPage()) StoragePerm.openSettings(context)
        else legacyLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    val editing = songs.firstOrNull { it.id == editingId }
    BackHandler(enabled = editing != null) { editingId = null }

    if (!permOk && !skippedGate) {
        Box(Modifier.fillMaxSize()) {
            GlassBackdrop()
            IconButton(onClick = onBack, modifier = Modifier.statusBarsPadding().padding(6.dp)) {
                Icon(Icons.Rounded.ArrowBack, null, tint = TgText)
            }
            Column(
                Modifier.align(Alignment.Center).padding(24.dp).fillMaxWidth().glass(30.dp).padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier.size(68.dp).clip(CircleShape).background(Brush.linearGradient(listOf(TgAccent, TgAccent2))),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Lock, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                Spacer(Modifier.height(18.dp))
                Text("Allow file access", color = TgText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "To save names and artwork into your real music files, AUVYRR needs permission to change files on your storage. Your songs themselves are never deleted or moved.",
                    color = TgMuted, fontSize = 13.sp, lineHeight = 19.sp,
                )
                Spacer(Modifier.height(22.dp))
                GlassButton("Allow access", Icons.Rounded.CheckCircle) { askPermission() }
                TextButton(onClick = { skippedGate = true }) {
                    Text("Not now, edit inside the app only", color = TgMuted, fontSize = 12.sp)
                }
            }
        }
        return
    }

    if (editing != null) {
        TagDetail(song = editing, fileAccess = permOk, onClose = { editingId = null })
        return
    }

    val taggedCount = songs.count { edits.containsKey(it.id) }
    val shown = run {
        val q = query.trim()
        val pool = if (q.isEmpty()) songs else com.texgen.music.texwave.data.SmartSearch.extremeSongs(songs, q, limit = 500)
        pool.filter { s ->
            when (filter) {
                1 -> !edits.containsKey(s.id)
                2 -> edits.containsKey(s.id)
                else -> true
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        GlassBackdrop()
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = TgText) }
                Column(Modifier.weight(1f)) {
                    Text("Tag Editor", color = TgText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("${songs.size} songs on this device", color = TgMuted, fontSize = 12.sp)
                }
                Row(
                    Modifier.glass(20.dp, 0.8f).clickable(onClick = onOpenTrim).padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.ContentCut, null, tint = TgText, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Trim", color = TgText, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (!permOk) {
                    item {
                        Row(
                            Modifier.fillMaxWidth().glass(18.dp, 0.9f, TgWarn).clickable { askPermission() }.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.Lock, null, tint = TgWarn, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("File access is off", color = TgText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("Tags only change inside the app. Tap to allow writing into the files.", color = TgMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
                item {
                    SyncCard(
                        total = songs.size,
                        tagged = taggedCount,
                        progress = progress,
                        onSync = { force ->
                            if (!NetUtil.isOnline(context)) {
                                Toast.makeText(context, "No internet connection", Toast.LENGTH_SHORT).show()
                            } else {
                                forceAll = force
                                confirmAll = true
                            }
                        },
                        onCancel = { TagStore.cancelSync() },
                        onDismiss = { TagStore.clearFinished() },
                        onReset = { confirmReset = true },
                    )
                }
                item {
                    Row(
                        Modifier.fillMaxWidth().height(48.dp).glass(16.dp, 0.8f).padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Rounded.Search, null, tint = TgMuted, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.weight(1f)) {
                            if (query.isEmpty()) Text("Search any song — fuzzy, typos, artist · title", color = TgMuted, fontSize = 14.sp)
                            BasicTextField(
                                value = query,
                                onValueChange = { query = it },
                                singleLine = true,
                                textStyle = TextStyle(color = TgText, fontSize = 14.sp),
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterPill("All", filter == 0) { filter = 0 }
                        FilterPill("Needs tags", filter == 1) { filter = 1 }
                        FilterPill("Tagged", filter == 2) { filter = 2 }
                    }
                }
                items(shown, key = { it.id }) { s ->
                    SongRow(s, edit = edits[s.id]) { editingId = s.id }
                }
                if (shown.isEmpty()) {
                    item {
                        Text(
                            if (songs.isEmpty()) "No songs found on this device." else "Nothing matches.",
                            color = TgMuted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 24.dp),
                        )
                    }
                }
            }
        }
    }

    if (confirmAll) {
        val n = if (forceAll) songs.size else songs.size - taggedCount
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            containerColor = Color(0xFF191B26),
            title = { Text("Sync $n songs?", color = TgText) },
            text = {
                Text(
                    if (permOk) "Titles, artists, albums and artwork are fetched from the internet and written into the audio files. Artwork is stored as small images, so it uses very little space."
                    else "Titles, artists, albums and artwork are fetched from the internet and saved inside the app. Allow file access first if you want them written into the audio files.",
                    color = TgMuted, fontSize = 13.sp,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmAll = false
                    TagStore.syncAll(context, songs, forceAll)
                }) { Text("Sync", color = TgAccent) }
            },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancel", color = TgMuted) } },
        )
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = Color(0xFF191B26),
            title = { Text("Reset all tags?", color = TgText) },
            text = {
                Text(
                    "Songs go back to the names and artwork the device has. Tags already written into audio files stay in those files.",
                    color = TgMuted, fontSize = 13.sp,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    TagStore.clearAll()
                }) { Text("Reset", color = TgBad) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel", color = TgMuted) } },
        )
    }
}

@Composable
private fun SyncCard(
    total: Int,
    tagged: Int,
    progress: SyncProgress,
    onSync: (Boolean) -> Unit,
    onCancel: () -> Unit,
    onDismiss: () -> Unit,
    onReset: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().glass(26.dp, 1.1f, TgAccent).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(TgAccent, TgAccent2))),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.AutoFixHigh, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Auto-tag everything", color = TgText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(
                    when {
                        progress.running -> "Syncing ${progress.done} of ${progress.total}"
                        progress.finished -> "Finished"
                        else -> "$tagged of $total songs tagged"
                    },
                    color = TgMuted, fontSize = 12.sp,
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        when {
            progress.running -> {
                val frac = if (progress.total > 0) progress.done.toFloat() / progress.total else 0f
                LinearProgressIndicator(
                    progress = { frac },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                    color = TgAccent, trackColor = Color(0x26FFFFFF),
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${progress.matched} matched · ${progress.written} saved to files · ${progress.skipped} not found",
                        color = TgMuted, fontSize = 11.sp, modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = onCancel) { Text("Stop", color = TgBad) }
                }
            }
            progress.finished -> {
                Text(
                    "${progress.matched} songs tagged, ${progress.written} written into the audio files, ${progress.skipped} had no confident match.",
                    color = TgText, fontSize = 13.sp, lineHeight = 18.sp,
                )
                Spacer(Modifier.height(12.dp))
                GlassButton("Done", null, onDismiss)
            }
            else -> {
                val all = tagged >= total && total > 0
                GlassButton(if (all) "Sync all again" else "Sync all songs", Icons.Rounded.Sync) { onSync(all) }
                if (tagged > 0) {
                    Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onReset) { Text("Reset all tags", color = TgMuted, fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(TgAccent, TgAccent2)))
            .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FilterPill(text: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.then(if (active) Modifier.glass(20.dp, 1.4f, TgAccent) else Modifier.glass(20.dp, 0.6f))
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 8.dp),
    ) {
        Text(text, color = if (active) Color.White else TgMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Art(model: String, size: Int, radius: Int = 14) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape(radius.dp)).background(Color(0x22FFFFFF)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.MusicNote, null, tint = TgMuted, modifier = Modifier.size((size / 3).dp))
        AsyncImage(model = model, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
    }
}

@Composable
private fun SongRow(song: Song, edit: TagEdit?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(20.dp, 0.75f).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Art(song.artUri, 54)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = TgText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                song.artist + if (song.album.isNotBlank()) " · " + song.album else "",
                color = TgMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        when {
            edit == null -> Icon(Icons.Rounded.ArrowForward, null, tint = TgMuted, modifier = Modifier.size(18.dp))
            edit.inFile -> Icon(Icons.Rounded.CheckCircle, null, tint = TgGood, modifier = Modifier.size(21.dp))
            else -> Icon(Icons.Rounded.CheckCircle, null, tint = TgWarn, modifier = Modifier.size(21.dp))
        }
    }
}

// ----------------------------------------------------------------------------------------- detail

@Composable
private fun TagDetail(song: Song, fileAccess: Boolean, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember(song.id) { mutableStateOf(song.title) }
    var artist by remember(song.id) { mutableStateOf(song.artist) }
    var album by remember(song.id) { mutableStateOf(song.album) }
    var year by remember(song.id) { mutableStateOf(if (song.year > 0) song.year.toString() else "") }
    var loading by remember(song.id) { mutableStateOf(true) }
    var offline by remember(song.id) { mutableStateOf(false) }
    var results by remember(song.id) { mutableStateOf<List<TagCandidate>>(emptyList()) }
    var picked by remember(song.id) { mutableStateOf<TagCandidate?>(null) }
    var saving by remember(song.id) { mutableStateOf(false) }

    LaunchedEffect(song.id) {
        loading = true
        if (!NetUtil.isOnline(context)) {
            offline = true
            loading = false
        } else {
            results = TagLookup.candidates(song)
            loading = false
        }
    }

    fun pick(c: TagCandidate) {
        picked = c
        title = c.title
        artist = c.artist
        album = c.album
        if (c.year > 0) year = c.year.toString()
    }

    val changes = ArrayList<Pair<String, Pair<String, String>>>()
    if (title.trim() != song.title) changes.add("Title" to (song.title to title.trim()))
    if (artist.trim() != song.artist) changes.add("Artist" to (song.artist to artist.trim()))
    if (album.trim() != song.album) changes.add("Album" to (song.album to album.trim()))
    val yearNow = year.trim().toIntOrNull() ?: 0
    if (yearNow != song.year) {
        changes.add("Year" to ((if (song.year > 0) song.year.toString() else "none") to (if (yearNow > 0) yearNow.toString() else "none")))
    }
    val artChanges = picked != null && picked?.artUrl.orEmpty().isNotBlank()
    val canSave = (changes.isNotEmpty() || artChanges) && !saving

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(TgBg))
        val backdrop = picked?.artUrl.orEmpty().ifBlank { song.artUri }
        AsyncImage(
            model = backdrop,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().blur(70.dp).alpha(0.55f),
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xAA07080D), Color(0xDD07080D)))))

        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.ArrowBack, null, tint = TgText) }
                Text("Edit tags", color = TgText, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (TagStore.isTagged(song.id)) {
                    TextButton(onClick = {
                        TagStore.clear(song.id)
                        onClose()
                    }) { Text("Reset", color = TgBad) }
                }
            }

            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Row(
                    Modifier.fillMaxWidth().glass(28.dp, 1f).padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Art(song.artUri, 128, 20)
                        Spacer(Modifier.height(10.dp))
                        Text("CURRENT", color = TgMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                    Icon(Icons.Rounded.ArrowForward, null, tint = if (picked != null) TgAccent else Color(0x33FFFFFF), modifier = Modifier.size(24.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val newArt = picked?.artUrl.orEmpty()
                        Art(if (newArt.isNotBlank()) newArt else song.artUri, 128, 20)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (picked != null) "NEW" else "NO CHANGE",
                            color = if (picked != null) TgAccent else TgMuted,
                            fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
                        )
                    }
                }

                if (changes.isNotEmpty()) {
                    Column(Modifier.fillMaxWidth().glass(22.dp, 0.8f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("WHAT WILL CHANGE", color = TgMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        for (c in changes) {
                            Column {
                                Text(c.first, color = TgMuted, fontSize = 11.sp)
                                Text(c.second.first, color = TgBad, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(c.second.second, color = TgGood, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }

                Text("ONLINE MATCHES", color = TgMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                when {
                    loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = TgAccent)
                        Spacer(Modifier.width(10.dp))
                        Text("Searching the internet…", color = TgMuted, fontSize = 13.sp)
                    }
                    offline -> Text("You are offline. Connect to the internet to find matches, or edit the details by hand.", color = TgMuted, fontSize = 13.sp)
                    results.isEmpty() -> Text("No match found. You can still edit the details by hand.", color = TgMuted, fontSize = 13.sp)
                    else -> LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(end = 8.dp)) {
                        items(results) { c ->
                            val on = picked === c
                            Column(
                                Modifier.width(152.dp)
                                    .then(if (on) Modifier.glass(20.dp, 1.5f, TgAccent) else Modifier.glass(20.dp, 0.7f))
                                    .clickable { pick(c) }.padding(11.dp),
                            ) {
                                Art(c.artUrl, 82, 14)
                                Spacer(Modifier.height(9.dp))
                                Text(c.title, color = TgText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(c.artist, color = TgMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${(c.score * 100).toInt().coerceIn(0, 100)}% match · ${c.source}",
                                    color = if (c.score >= TagLookup.CONFIDENT) TgGood else TgMuted, fontSize = 10.sp,
                                )
                            }
                        }
                    }
                }

                Text("DETAILS", color = TgMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                TagField("Title", title) { title = it }
                TagField("Artist", artist) { artist = it }
                TagField("Album", album) { album = it }
                TagField("Year", year, KeyboardType.Number) { year = it.filter { ch -> ch.isDigit() }.take(4) }
                Text(
                    if (fileAccess) "Saved into the audio file and shown across AUVYRR."
                    else "File access is off, so this only changes the tags inside AUVYRR.",
                    color = TgMuted, fontSize = 11.sp,
                )
                Spacer(Modifier.height(96.dp))
            }
        }

        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE07080D))))
                .navigationBarsPadding().padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 12.dp),
        ) {
            Row(
                Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(20.dp))
                    .background(if (canSave) Brush.horizontalGradient(listOf(TgAccent, TgAccent2)) else Brush.horizontalGradient(listOf(Color(0x33FFFFFF), Color(0x33FFFFFF))))
                    .border(1.dp, Color.White.copy(alpha = if (canSave) 0.4f else 0.12f), RoundedCornerShape(20.dp))
                    .clickable(enabled = canSave) {
                        saving = true
                        val c = picked
                        scope.launch {
                            val msg = withContext(Dispatchers.IO) {
                                val artName = if (c != null && c.artUrl.isNotBlank()) TagLookup.fetchArt(context, c.artUrl) else null
                                val keepArt = TagStore.edits.value[song.id]?.art.orEmpty()
                                TagStore.saveAndWrite(
                                    context, song,
                                    TagEdit(song.id, title.trim(), artist.trim(), album.trim(), year.trim().toIntOrNull() ?: 0, artName ?: keepArt, c != null),
                                )
                            }
                            saving = false
                            Toast.makeText(
                                context,
                                when {
                                    msg == null -> "Saved into the audio file"
                                    msg == "No file access" -> "Saved in the app. Allow file access to write into the file."
                                    else -> "Saved in the app only ($msg)"
                                },
                                Toast.LENGTH_LONG,
                            ).show()
                            onClose()
                        }
                    },
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (saving) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    Icon(Icons.Rounded.Sync, null, tint = if (canSave) Color.White else TgMuted, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (picked != null) "Sync from internet" else "Save changes",
                        color = if (canSave) Color.White else TgMuted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}

@Composable
private fun TagField(label: String, value: String, keyboard: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().glass(16.dp, 0.8f).padding(horizontal = 16.dp, vertical = 11.dp)) {
        Text(label, color = TgMuted, fontSize = 11.sp)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = TgText, fontSize = 15.sp),
            keyboardOptions = KeyboardOptions(keyboardType = keyboard),
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
        )
    }
}
