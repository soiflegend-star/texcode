package com.texgen.music.texwave.ui.screens.chat

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import com.texgen.music.texwave.data.chat.Attachment
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.SupabaseConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

internal fun isVideoAttachment(att: Attachment): Boolean =
    att.mimeType.startsWith("video/") ||
        att.originalName.endsWith(".mp4", true) ||
        att.originalName.endsWith(".mov", true) ||
        att.originalName.endsWith(".mkv", true) ||
        att.originalName.endsWith(".webm", true) ||
        att.originalName.endsWith(".3gp", true)

private fun sizeOf(context: Context, uri: Uri): Long {
    if (uri.scheme == "file") return File(uri.path ?: return 0L).length()
    return try {
        context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
    } catch (_: Exception) { 0L }
}

/**
 * Prepares a picked video for sending, like Instagram does: big clips are re-encoded to
 * 720p H.264 so they upload fast and fit under the storage limit. If anything goes wrong
 * the original is sent untouched.
 */
internal suspend fun prepareVideoForSend(context: Context, uri: Uri): Uri {
    val original = sizeOf(context, uri)
    // Small clips go as-is.
    if (original in 1..(8L * 1024 * 1024)) return uri
    val out = File(context.cacheDir, "send_${System.currentTimeMillis()}.mp4")
    val ok = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Boolean> { cont ->
            try {
                val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri))
                    .setEffects(Effects(emptyList(), listOf(Presentation.createForHeight(720))))
                    .build()
                val transformer = Transformer.Builder(context)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(true)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException,
                        ) {
                            if (cont.isActive) cont.resume(false)
                        }
                    })
                    .build()
                transformer.start(edited, out.absolutePath)
                cont.invokeOnCancellation { runCatching { transformer.cancel() } }
            } catch (_: Throwable) {
                if (cont.isActive) cont.resume(false)
            }
        }
    }
    if (ok && out.exists() && out.length() > 1000 && (original <= 0 || out.length() < original)) {
        return Uri.fromFile(out)
    }
    runCatching { out.delete() }
    require(original <= SupabaseConfig.MAX_FILE_BYTES) {
        "Video is too large (${original / (1024 * 1024)} MB). Max is ${SupabaseConfig.MAX_FILE_BYTES / (1024 * 1024)} MB."
    }
    return uri
}

private fun frameOf(path: String): Pair<Bitmap?, Long> {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(path)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        Pair(r.getFrameAtTime(300_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC), dur)
    } catch (_: Exception) {
        Pair(null, 0L)
    } finally {
        runCatching { r.release() }
    }
}

private fun fmtDur(ms: Long): String {
    val s = (ms / 1000).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

/** Instagram-style video message: poster frame, play button, duration badge, full-screen player. */
@Composable
internal fun ChatVideoBubble(att: Attachment, repo: ChatRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cacheFile = remember(att.id) { File(context.cacheDir, "vid_${att.id}.mp4") }
    var path by remember(att.id) { mutableStateOf(cacheFile.takeIf { it.exists() && it.length() > 1000 }?.absolutePath) }
    var poster by remember(att.id) { mutableStateOf<Bitmap?>(null) }
    var duration by remember(att.id) { mutableStateOf(0L) }
    var busy by remember(att.id) { mutableStateOf(false) }
    var playing by remember(att.id) { mutableStateOf(false) }

    LaunchedEffect(path) {
        val p = path ?: return@LaunchedEffect
        val (bmp, dur) = withContext(Dispatchers.IO) { frameOf(p) }
        poster = bmp
        duration = dur
    }

    fun open() {
        if (path != null) { playing = true; return }
        if (busy) return
        busy = true
        scope.launch {
            val res = repo.downloadAttachment(att)
            res.onSuccess { bytes ->
                withContext(Dispatchers.IO) { cacheFile.writeBytes(bytes) }
                path = cacheFile.absolutePath
                playing = true
            }.onFailure {
                Toast.makeText(context, it.message ?: "Could not load video", Toast.LENGTH_SHORT).show()
            }
            busy = false
        }
    }

    Box(
        Modifier
            .padding(top = 8.dp)
            .fillMaxWidth()
            .height(240.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0A0C14))
            .clickable { open() },
        contentAlignment = Alignment.Center,
    ) {
        val bmp = poster
        if (bmp != null) {
            Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Rounded.Videocam, null, tint = Color.White.copy(alpha = 0.25f), modifier = Modifier.size(56.dp))
        }
        Box(
            Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.55f))
                .border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (busy) {
                CircularProgressIndicator(Modifier.size(26.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                Icon(
                    if (path == null) Icons.Rounded.Download else Icons.Rounded.PlayArrow,
                    null, tint = Color.White, modifier = Modifier.size(32.dp),
                )
            }
        }
        Row(
            Modifier.align(Alignment.BottomStart).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                if (duration > 0) fmtDur(duration) else formatSize(att.sizeBytes),
                color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
    }
    if (playing) {
        path?.let { VideoPlayerDialog(it, att.originalName) { playing = false } }
    }
}

@Composable
internal fun VideoPlayerDialog(path: String, title: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val player = remember(path) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            repeatMode = Player.REPEAT_MODE_ONE
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                modifier = Modifier.fillMaxSize(),
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 36.dp, start = 12.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Rounded.Close, "Close", tint = Color.White,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .clickable(onClick = onDismiss)
                        .padding(6.dp),
                )
                Spacer(Modifier.size(12.dp))
                Text(title.take(30), color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
        }
    }
}
