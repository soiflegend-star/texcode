# TEXWAVE – 12-screen reference UI

New code: app/src/main/java/com/texgen/music/texwave/ui/ref/ (RefKit, RefChrome, RefHome, RefLibrary, RefSearch,
RefNowPlaying, RefPhantom, RefSplash, RefSocial, RefProfileSettings). Reels restyled in place. MusicApp.kt rewired.

Artwork (res/drawable-nodpi/ref_*.png) was cut from the reference image at its native ~190px/phone resolution.
To sharpen: replace any ref_*.png with a higher-res file of the same name.

Bottom bar: Home | Library | orb (Now Playing) | Phantom | More. "More" opens every other screen
(Search, Feed, Reels, Messages, Groups, Profile, Settings, Equalizer, Alarms, Downloads, Explore, Phantom Lab, All features).

NOT compiled: no Android SDK/Maven access in the build sandbox. Syntax-checked only. Build with ./gradlew assembleDebug.
Old screens kept: legacy Library sessions (More > All features), legacy Settings (rows in new Settings), MyProfile editor (Edit Profile), Phantom Lab.

## Button wiring (all real)
Home: shuffle, hero, rows. Library: tabs/filter/more/new playlist. Search: filters, See All, clear, mixes.
Now Playing: seek, transport, like, menu (queue, lyrics, EQ, speed, sleep, editor, cover).
Phantom: chips + input -> real assistant. Feed: like/comment/share/compose. Reels: like/next/share/follow.
Messages: live Supabase chats. Groups: real group chats + create. Profile: highlights navigate, Edit Profile.
Settings: Notifications/Appearance/Music/Phantom deep-link into real settings; Privacy opens Android app permissions;
Storage clears cache; About dialog.

## Polish pass
- Inter font bundled (res/font), applied app-wide via RefPolish; density scaled down on narrow phones (<400dp).
- Snow particle overlay removed.
- New NebulaOrb (Canvas) drives the splash (staged reveal) and the Phantom orb (faster while thinking).
- Feed / Profile grid / Groups show real data only, with empty states + create CTAs.
- Alarms: rewritten screen. Sound = Phantom voice only (silent) / default tone / system ringtone / own song.
  Per-alarm picture theme (6 presets or own photo) shown on the ring screen. Still uncompiled on Android — build in Android Studio.

## Phantom chat + previous/next
- Chat: wrap-content bubbles with tails, Phantom avatar, **bold**/bullet rendering, animated typing dots, tap-to-copy, retry on error, mic input, speak-replies toggle, new-chat button, history saved across restarts, quick-command chips (offline brain).
- Previous/Next now delegate to the real player (shuffle-aware, wraps); the old index math used a stale queueIndex and could jump to the wrong/last song.

## Round 4
- Alarm: new AlarmRingService (foreground service) owns sound/vibration + full-screen notification; backup double-fire removed; silent = Phantom only.
- Previous bug root cause: VM auto-resumed a song's old saved position on track change (a finished song reopened at its end). Removed.
- Discover page (RefDiscover.kt): YouTube-style feed over the free Internet Archive catalog (music + films), real download progress/cancel, Downloads tab, auto media-scan + library rescan. (No YouTube ripping — against YouTube ToS.)
- Images: full-res embedded cover art (HiResArt), FilterQuality.High everywhere, bundled placeholder art upscaled.
- Chat theme photos: shared via private-bucket token (sb:path) downloaded with the peer's session.
- Equalizer: custom vertical bands + response curve, bass boost / virtualizer / loudness, 13 presets, live prev/play/next strip, auto re-attach.
- Player theme: Now Playing menu -> Player theme (presets, album-art blur, gallery photo).
- Cockpit guide: "?" button + one-time briefing + HUD corners on Radar, Constellation, Universe hub & every Universe screen; Emotional GPS rebuilt as a live radar.

## Round 5
- Reels removed everywhere. New "All screens" sheet (More) lists every screen, searchable, grouped.
- Home: "Explore TEXWAVE" shelf of gradient tiles to jump to Discover, Radar, Constellation, Phantom, Equalizer, Alarms, Universe Lab, Feed.
- Premium cards: top sheen, colour bloom, gradient edge.
- Search: new SmartSearch engine (typo tolerance, accents, "title by artist", albums/artists/playlists, did-you-mean, recents, online results). Phantom play commands use it too.
- Not compiled on Android here; import/brace check only.

## Round 6 — Synergy Arena merged
- Arena module (36 files) from TEXWAVE_ARENA_GITHUB_BUILDABLE_4 merged into the UI-9 base and renamed "Synergy Arena" in all visible text.
- Entry: More -> All screens -> Synergy Arena (also in the side nav). Back button closes it.
- Fixed the 2 compile errors from the build log: missing `setValue` import in ArenaHomeScreen.kt, missing `background` import in MusicApp.kt.
- Added CameraX, MediaPipe, SceneView, navigation-compose deps, CAMERA permission, libc++ packaging fix.
- SQL for Arena: supabase/arena/001-004. Pose model `pose_landmarker_lite.task` and warrior GLBs are optional (see assets/models/README_MODELS.md).
- Not compiled on Android here; import/brace check only.
- Round 6b: added missing imports (fillMaxHeight, Icons.Rounded.Close) in RefProfileSettings.kt per second build log.
- Round 7: Chat tab in bottom bar; Video send (picker, 720p compress via media3-transformer, poster+duration bubble, fullscreen player).
- Round 8: New clean dark UI (neutral dark + mint accent), new splash, flat bottom bar Home/Search/Library/Chat/Menu, new Home with search bar, continue-listening card, quick chips and every feature as grouped tiles (single catalogue shared with Menu sheet).
- Round 9: Chat/user-search 'Tap to type' single line replaces flipping cards; Synergy Arena removed from menus (files kept); all feature screens recoloured to the new neutral+mint palette (default theme too); Mood map smarter path + note; empty-library state for universe screens; radar empty state + selection ring.
- Round 10: Notification editor (menu -> Tools & settings; NotifPrefs wired into ChatNotifier: messages/calls/sound/vibration/preview/lock-screen/quiet hours/test). Stories: composer with caption + song from library, live author names via list_active_stories RPC, grouped per person viewer with auto-advance, delete own. Photo posts: song picker from library, song chip shows on feed and plays if viewer has the song.
