package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.runtime.State
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.util.UiSound
import kotlin.math.abs
import kotlin.math.sin
import kotlinx.coroutines.delay

/** Returns a function that plays a UI sound (respects the user's sound toggle). */
@Composable
fun rememberUiSound(): (UiSound.Kind) -> Unit {
    val ctx = LocalContext.current
    return remember(ctx) { { kind: UiSound.Kind -> UiSound.play(ctx, kind) } }
}

/** Fade + rise-in on first composition, used to stagger sections when a screen opens. */
fun Modifier.appear(delayMs: Int = 0, riseDp: Int = 18): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        a.animateTo(1f, tween(560, easing = FastOutSlowInEasing))
    }
    this.graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * riseDp * density
    }
}

/** Clickable that squishes slightly while pressed (no ripple), for cards and glowing buttons. */
fun Modifier.pressable(pressedScale: Float = 0.94f, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) pressedScale else 1f,
        spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "press",
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** Slowly twinkling stars + drifting dust; drawn only (no recomposition) so it is cheap. */
@Composable
fun TwinkleField(modifier: Modifier = Modifier, count: Int = 36, tint: Color = Color(0xFFCFE8FF)) {
    val t = rememberInfiniteTransition(label = "twinkle")
    val phase = t.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "twinklePhase",
    )
    Canvas(modifier) {
        val p = phase.value
        for (i in 0 until count) {
            val x = ((i * 137 + 31) % 1000) / 1000f * size.width
            val baseY = ((i * 71 + 17) % 1000) / 1000f * size.height
            val y = baseY - ((p * (6 + i % 5) * 3f) % 14f) * density
            val a = 0.12f + 0.55f * (0.5f + 0.5f * sin(p * (1 + i % 3) + i))
            drawCircle(tint.copy(alpha = a), (0.6f + (i % 4) * 0.35f) * density, Offset(x, y))
        }
    }
}

/** Neon waveform that reacts to music energy. Continuous wave + bars, cyan → violet → pink. */
@Composable
fun WaveBars(
    active: Boolean,
    modifier: Modifier = Modifier,
    bars: Int = 56,
    energyState: State<Float>? = null,
) {
    val baseEnergy by animateFloatAsState(
        if (active) 1f else 0.12f,
        tween(500, easing = FastOutSlowInEasing),
        label = "waveEnergy",
    )
    val t = rememberInfiniteTransition(label = "waveBars")
    val phase = t.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(tween(if (active) 1800 else 4000, easing = LinearEasing), RepeatMode.Restart),
        label = "wavePhase",
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (w <= 1f || h <= 1f) return@Canvas
        val live = (energyState?.value ?: 0f).coerceIn(0f, 1.5f)
        val energy = (baseEnergy * (0.55f + 0.75f * live)).coerceIn(0.08f, 1.6f)
        val p = phase.value
        val cy = h / 2f

        // Continuous neon wave line (exact mockup style)
        val wavePath = Path()
        wavePath.moveTo(0f, cy)
        var x = 0f
        while (x <= w) {
            val nx = x / w
            val amp = (0.18f + 0.72f * energy) * h * 0.42f
            val y = cy + (
                sin(p * 2.2f + nx * 14f) * 0.55f +
                sin(p * 3.4f - nx * 9f) * 0.30f +
                sin(p * 1.1f + nx * 22f) * 0.15f
            ) * amp
            if (x == 0f) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
            x += 3f
        }
        // Glow under the wave
        drawPath(
            wavePath,
            Color(0xFF3DE0FF).copy(alpha = 0.18f + 0.22f * energy),
            style = Stroke(width = 8f * density, cap = StrokeCap.Round),
        )
        drawPath(
            wavePath,
            Brush.horizontalGradient(
                listOf(Color(0xFF3DE0FF), Color(0xFF7B6CFF), Color(0xFFE056A0)),
                0f, w,
            ),
            style = Stroke(width = 2.4f * density, cap = StrokeCap.Round),
        )

        // Vertical neon bars for extra energy
        val step = w / bars
        val brush = Brush.horizontalGradient(
            listOf(Color(0xFF3DE0FF), Color(0xFF5B8CFF), Color(0xFF9B6CFF), Color(0xFFE056A0)),
            0f, w,
        )
        for (i in 0 until bars) {
            val u = i / (bars - 1f)
            val env = 0.2f + 0.8f * (1f - abs(u - 0.5f) * 1.6f).coerceIn(0f, 1f)
            val v = abs(sin(p * 2.4f + i * 0.48f)) * 0.5f + abs(sin(p * 3.1f - i * 0.29f)) * 0.5f
            val barH = (0.06f + v * env * energy) * h * 0.48f
            val bx = step * (i + 0.5f)
            drawLine(brush, Offset(bx, cy - barH), Offset(bx, cy + barH), strokeWidth = step * 0.38f, cap = StrokeCap.Round)
        }
    }
}
