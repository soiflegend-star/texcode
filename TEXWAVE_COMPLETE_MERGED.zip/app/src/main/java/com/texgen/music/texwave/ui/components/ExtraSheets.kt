package com.texgen.music.texwave.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.LyricsEngine
import com.texgen.music.texwave.data.GroqClient
import com.texgen.music.texwave.ui.theme.Tx

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepTimerSheet(
    currentMinutes: Int?,
    onDismiss: () -> Unit,
    onSet: (Int?) -> Unit,
) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheet,
        containerColor = Tx.Surface,
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Timer, null, tint = Tx.Accent2)
                Text("Sleep timer", color = Tx.Text, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.height(16.dp))
            val options = listOf(5, 15, 30, 45, 60, 90)
            options.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { m ->
                        val selected = currentMinutes == m
                        Text(
                            "$m min",
                            color = if (selected) Tx.Accent2 else Tx.Text,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selected) Tx.Accent.copy(alpha = 0.25f) else Tx.SurfaceHigh)
                                .clickable { onSet(m); onDismiss() }
                                .padding(vertical = 14.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Text(
                "Turn off",
                color = Tx.Danger,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Tx.SurfaceHigh)
                    .clickable { onSet(null); onDismiss() }
                    .padding(vertical = 14.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpeedSheet(
    current: Float,
    onDismiss: () -> Unit,
    onSet: (Float) -> Unit,
) {
    var value by remember { mutableFloatStateOf(current) }
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheet,
        containerColor = Tx.Surface,
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("Playback speed", color = Tx.Text, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text("${"%.2f".format(value)}×", color = Tx.Accent2, style = MaterialTheme.typography.headlineMedium)
            Slider(
                value = value,
                onValueChange = { value = it },
                onValueChangeFinished = { onSet(value) },
                valueRange = 0.5f..2f,
                steps = 5,
                colors = SliderDefaults.colors(
                    thumbColor = Tx.Accent2,
                    activeTrackColor = Tx.Accent,
                    inactiveTrackColor = Tx.Outline,
                ),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                    Text(
                        "${s}×",
                        color = if (value == s) Tx.Accent2 else Tx.Muted,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { value = s; onSet(s) }
                            .padding(8.dp),
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsSheet(
    song: Song?,
    positionMs: Long = 0L,
    groqKeyAvailable: Boolean = false,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var data by remember { mutableStateOf<LyricsEngine.Lyrics?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()
    val groq = remember { GroqClient(context) }

    LaunchedEffect(song?.id) {
        if (song == null) return@LaunchedEffect
        loading = true
        error = null
        data = null
        LyricsEngine.load(context, song, groq.takeIf { it.hasKey() })
            .onSuccess { data = it }
            .onFailure {
                error = when {
                    groqKeyAvailable || groq.hasKey() ->
                        it.message ?: "Could not load or generate lyrics."
                    else ->
                        "No lyrics found. Add a Groq API key in PHANTOM for auto-generated lyrics."
                }
            }
        loading = false
    }

    val active = remember(data, positionMs) {
        data?.let { LyricsEngine.activeIndex(it, positionMs) } ?: -1
    }

    LaunchedEffect(active) {
        if (active >= 0) {
            runCatching { listState.animateScrollToItem(active.coerceAtLeast(0)) }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheet,
        containerColor = Tx.Surface,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
        ) {
            Text("Lyrics", color = Tx.Text, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(4.dp))
            Text(
                song?.let { "${it.title} · ${it.artist.ifBlank { "Unknown artist" }}" } ?: "",
                color = Tx.Muted,
                style = MaterialTheme.typography.bodySmall,
            )
            data?.let {
                Text(
                    when (it.source) {
                        "groq" -> "Generated with Groq · listening highlight"
                        "lrclib" -> if (it.synced) "Synced lyrics · listening" else "Lyrics · listening highlight"
                        else -> "Cached lyrics"
                    },
                    color = Tx.Accent2,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            Spacer(Modifier.height(16.dp))

            when {
                loading -> {
                    Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Tx.Accent2, strokeWidth = 2.dp)
                            Spacer(Modifier.height(10.dp))
                            Text(
                                if (groq.hasKey()) "Fetching lyrics / generating with Groq…"
                                else "Fetching lyrics…",
                                color = Tx.Muted,
                                fontSize = 12.sp,
                            )
                        }
                    }
                }
                data != null -> {
                    val lines = data!!.lines
                    if (lines.isNotEmpty()) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp),
                        ) {
                            itemsIndexed(lines) { i, line ->
                                val on = i == active
                                Text(
                                    line.text,
                                    color = if (on) Color.White else Color(0xFF8B93B0),
                                    fontSize = if (on) 18.sp else 15.sp,
                                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                                    lineHeight = 28.sp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                )
                            }
                        }
                    } else {
                        Text(
                            data!!.plain,
                            color = Color(0xFFE8ECFF),
                            style = MaterialTheme.typography.bodyLarge,
                            lineHeight = 28.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp)
                                .verticalScroll(rememberScrollState()),
                        )
                    }
                }
                else -> {
                    Text(
                        error ?: "No lyrics found.",
                        color = Tx.Muted,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
