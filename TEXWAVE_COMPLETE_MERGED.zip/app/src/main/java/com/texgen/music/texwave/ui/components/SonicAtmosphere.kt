package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import com.texgen.music.texwave.ui.theme.Tx
import kotlin.math.cos
import kotlin.math.sin

/**
 * TEXWAVE's living background: obsidian black with slowly drifting violet / cyan / magenta
 * aurora, twinkling stars and an occasional shooting star. Cheap enough to sit behind every screen.
 */
@Composable
fun Modifier.sonicAtmosphere(opaque: Boolean = true): Modifier {
    val motion = rememberInfiniteTransition(label = "texwaveAtmosphere")
    val phase by motion.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2.0).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 22000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "sonicAtmospherePhase",
    )
    val streak by motion.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 9000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "sonicStreak",
    )
    val a1 = Tx.Accent
    val a2 = Tx.Accent2
    val a3 = Tx.Accent3
    val bg = Tx.Bg
    return drawBehind {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@drawBehind
        if (opaque) {
            drawRect(
                Brush.verticalGradient(
                    colors = listOf(bg, Color(0xFF06030F), bg),
                    startY = 0f,
                    endY = h,
                )
            )
        }
        fun orb(c: Color, cx: Float, cy: Float, r: Float, a: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(c.copy(alpha = a), c.copy(alpha = a * 0.35f), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = r,
                ),
                radius = r,
                center = Offset(cx, cy),
            )
        }
        orb(a1, w * (0.18f + 0.10f * sin(phase)), h * (0.20f + 0.05f * cos(phase)), w * 0.95f, 0.22f)
        orb(a3, w * (0.92f + 0.06f * cos(phase * 1.3f)), h * (0.52f + 0.06f * sin(phase)), w * 0.70f, 0.13f)
        orb(a2, w * (0.45f + 0.14f * sin(phase * 0.7f)), h * (0.92f + 0.03f * cos(phase)), w * 0.80f, 0.12f)

        // stars
        for (i in 0 until 64) {
            val x = ((i * 173 + 41) % 997) / 997f * w
            val y = ((i * 127 + 89) % 991) / 991f * h
            val twinkle = 0.10f + 0.28f * (0.5f + 0.5f * sin(phase * 3f + i * 1.7f))
            drawCircle(Color(0xFFE6DEFF).copy(alpha = twinkle), (0.5f + (i % 4) * 0.3f) * density, Offset(x, y))
        }

        // shooting star (only during the first 22% of every cycle)
        if (streak < 0.22f) {
            val t = streak / 0.22f
            val dir = Offset(0.93f, 0.37f)
            val start = Offset(w * 0.05f, h * 0.04f)
            val travel = w * 1.1f
            val head = Offset(start.x + dir.x * travel * t, start.y + dir.y * travel * t)
            val fade = kotlin.math.sin(t * Math.PI.toFloat()).coerceIn(0f, 1f)
            drawComet(head, dir, w * 0.42f, fade, accent = a1)
        }
    }
}
