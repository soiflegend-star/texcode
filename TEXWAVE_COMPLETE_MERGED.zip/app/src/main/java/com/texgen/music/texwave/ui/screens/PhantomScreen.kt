package com.texgen.music.texwave.ui.screens

import androidx.compose.animation.core.animateIntAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Person
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.style.TextAlign
import com.texgen.music.texwave.ui.components.ScreenHeader
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable
import com.texgen.music.texwave.ui.components.rememberUiSound
import com.texgen.music.texwave.ui.theme.seedColors
import com.texgen.music.texwave.util.UiSound
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.texgen.music.texwave.R
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.AlchemistPreset
import com.texgen.music.texwave.data.EmotionMode
import com.texgen.music.texwave.data.FocusGoal
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import kotlinx.coroutines.launch

/**
 * PHANTOM hub — all 10 extraordinary features.
 * Universe + best-quality ranking require internet (and Groq key for full quality).
 */
@Composable
fun PhantomScreen(
    lib: LibraryState,
    player: PlayerState,
    online: Boolean,
    hasGroqKey: Boolean,
    onOpenChat: () -> Unit,
    onOpenProfile: () -> Unit = {},
    onPlayEmotion: (EmotionMode) -> Unit,
    onInfiniteMix: () -> Unit,
    onPlaySongs: (List<Song>, Int) -> Unit,
    onApplyAlchemist: (AlchemistPreset) -> Unit,
    onFocus: (FocusGoal, Int) -> Unit,
    onSoundDetective: suspend (Song) -> String,
    onDnaExplain: suspend () -> String,
    onUniverseExplain: suspend (Song, List<Song>) -> String,
    onNeighbors: (Song) -> List<Song>,
    onSaveMemory: (Long, String) -> Unit,
    memoryFor: (Long) -> String?,
    onSaveGroqKey: (String) -> Unit,
    onAddBookmark: () -> Unit,
    bookmarks: List<Long>,
) {
    val sound = rememberUiSound()
    var tab by remember { mutableStateOf(0) } // 0 hub, 1 universe, 2 detective, 3 memory, 4 key
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var keyInput by remember { mutableStateOf("") }
    val phantomPulse = rememberInfiniteTransition(label = "phantomPresence")
    val phantomScale by phantomPulse.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "phantomBreath",
    )

    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .padding(top = 8.dp),
    ) {
        ScreenHeader("Phantom", "Your memory. Your journey.", Modifier.appear(0)) {
            Icon(
                if (online) Icons.Rounded.Public else Icons.Rounded.CloudOff,
                null,
                tint = if (online) Color(0xFF3DE0FF) else Tx.Muted,
                modifier = Modifier.padding(end = 2.dp).size(18.dp),
            )
            IconButton(onClick = { sound(UiSound.Kind.SELECT); onOpenChat() }) {
                Icon(Icons.Rounded.Forum, "Chat with PHANTOM", tint = Color(0xFF3DE0FF))
            }
            IconButton(onClick = { sound(UiSound.Kind.SELECT); onOpenProfile() }) {
                Icon(Icons.Rounded.Person, "Your profile", tint = Color(0xFFB388FF))
            }
        }
        // glowing companion orb with an orbiting light
        val orbit = phantomPulse.animateFloat(
            0f, (2 * Math.PI).toFloat(),
            infiniteRepeatable(tween(7000, easing = LinearEasing)),
            label = "phantomOrbit",
        )
        Box(Modifier.fillMaxWidth().height(150.dp).appear(60), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(210.dp, 150.dp)) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val rx = size.width * 0.46f
                val ry = size.height * 0.30f
                val tilt = -0.35f
                fun pt(th: Float): Offset {
                    val x = rx * cos(th)
                    val y = ry * sin(th)
                    return Offset(c.x + x * cos(tilt) - y * sin(tilt), c.y + x * sin(tilt) + y * cos(tilt))
                }
                var prev = pt(0f)
                for (i in 1..72) {
                    val q = pt(i / 72f * 2f * Math.PI.toFloat())
                    drawLine(Color(0xFF6C7CFF).copy(alpha = 0.55f), prev, q, strokeWidth = 1.4f * density)
                    prev = q
                }
                val d = pt(orbit.value)
                drawCircle(Color(0xFF3DE0FF).copy(alpha = 0.28f), 9f * density, d)
                drawCircle(Color(0xFFBFF6FF), 3f * density, d)
            }
            Box(
                Modifier
                    .size(104.dp)
                    .scale(phantomScale)
                    .shadow(26.dp, CircleShape, ambientColor = Color(0xFF00E5FF).copy(alpha = 0.45f), spotColor = Color(0xFF9B6CFF).copy(alpha = 0.55f))
                    .clip(CircleShape)
                    .border(
                        2.dp,
                        Brush.sweepGradient(listOf(Color(0xFF00E5FF), Color(0xFF9B6CFF), Color(0xFFE056A0), Color(0xFF00E5FF))),
                        CircleShape,
                    )
                    .pressable(0.94f) { sound(UiSound.Kind.SELECT); onOpenChat() },
            ) {
                com.texgen.music.texwave.ui.components.PhantomAvatar(Modifier.fillMaxSize(), 104.dp)
            }
        }

        if (!online) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x3320C997))
                    .padding(14.dp),
            ) {
                Text(
                    "Offline mode active. PHANTOM still learns from your plays, skips, likes, and time of day — and aims to make you happy. Connect later for optional AI boost.",
                    color = Tx.Text,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        message?.let {
            Text(it, color = Tx.Accent2, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp), style = MaterialTheme.typography.bodySmall)
        }
        if (busy) {
            CircularProgressIndicator(Modifier.padding(16.dp).size(28.dp), color = Tx.Accent2, strokeWidth = 3.dp)
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            // Memory Core: real, locally available library facts; never fabricated memory counts.
            item {
                val shape = RoundedCornerShape(20.dp)
                Column(
                    Modifier
                        .appear(120)
                        .fillMaxWidth()
                        .clip(shape)
                        .background(Brush.linearGradient(listOf(Color(0xFF0B1B3E), Color(0xFF0C1030), Color(0xFF1A0F40))))
                        .border(1.2.dp, Brush.linearGradient(listOf(Color(0xFF3A8CFF), Color(0xFF8A5CFF), Color(0xFFB05CFF))), shape)
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                ) {
                    Text("Memory Core", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    Text("How well I know you", color = Tx.Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        MemoryStat(Modifier.weight(1f), lib.recents.distinct().size, "Total memories")
                        Box(Modifier.width(1.dp).height(34.dp).background(Color(0x22FFFFFF)))
                        MemoryStat(Modifier.weight(1f), lib.liked.size, "Confirmed")
                        Box(Modifier.width(1.dp).height(34.dp).background(Color(0x22FFFFFF)))
                        MemoryStat(Modifier.weight(1f), lib.playlists.size, "Pending")
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0E1E4A))
                            .pressable(0.97f) {
                                sound(UiSound.Kind.SELECT)
                                busy = true
                                scope.launch {
                                    message = onDnaExplain()
                                    busy = false
                                }
                            }
                            .padding(vertical = 11.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("View Details", color = Color(0xFF3DE0FF), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.Rounded.ArrowForward, null, tint = Color(0xFF3DE0FF), modifier = Modifier.size(16.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        if (player.current != null) "Now resonating \u00b7 ${player.current.title}" else "Ready when you are \u00b7 start a track to build your listening journey",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 11.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            // Listening Insights: derived only from the user's own library and play history.
            item {
                val shape = RoundedCornerShape(20.dp)
                val songsById = remember(lib.songs) { lib.songs.associateBy { it.id } }
                val topArtist = remember(lib.recents, lib.songs) {
                    val fromPlays = lib.recents.mapNotNull { songsById[it]?.artist }.filter { it.isNotBlank() && !it.startsWith("Unknown") }
                    (fromPlays.ifEmpty { lib.songs.map { it.artist }.filter { it.isNotBlank() && !it.startsWith("Unknown") } })
                        .groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: "\u2014"
                }
                val newest = remember(lib.songs) { lib.songs.maxByOrNull { it.dateAdded } }
                val moodNow = remember {
                    when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
                        in 5..11 -> "Fresh / Morning"
                        in 12..16 -> "Upbeat / Afternoon"
                        in 17..21 -> "Mellow / Evening"
                        else -> "Chill / Night"
                    }
                }
                Column(
                    Modifier
                        .appear(220)
                        .fillMaxWidth()
                        .clip(shape)
                        .background(Color(0xFF080C20))
                        .border(1.dp, Color(0x33FFFFFF), shape),
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Insights, null, tint = Color(0xFF8A9BFF), modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Listening Insights", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text("Based on your music history", color = Tx.Muted, fontSize = 11.sp)
                        }
                        Icon(Icons.Rounded.ChevronRight, null, tint = Color(0xFFB8C0E0))
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))
                    InsightRow("Top Artist", topArtist, topArtist)
                    InsightRow("Mood for now", moodNow, moodNow)
                    InsightRow("Recent Discovery", newest?.let { it.artist.ifBlank { it.title } } ?: "\u2014", newest?.title ?: "x")
                    Spacer(Modifier.height(6.dp))
                }
            }
            item {
                Text(
                    "\u201cEvery song you play\nadds a new layer to your story.\u201d\n\u2014 Phantom",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 12.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.appear(320).fillMaxWidth().padding(vertical = 6.dp),
                )
            }
            // 1 Emotion Reactor
            item {
                FeatureCard("1 · Emotion Reactor", "🎭", "Music that matches the moment") {
                    enumValues<EmotionMode>().toList().chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            row.forEach { mode ->
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .height(52.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Tx.SurfaceHigh)
                                        .clickable {
                                            busy = true
                                            onPlayEmotion(mode)
                                            busy = false
                                            message = "Playing ${mode.emoji} ${mode.label}"
                                        }
                                        .padding(10.dp),
                                    contentAlignment = Alignment.CenterStart,
                                ) {
                                    Text("${mode.emoji} ${mode.label}", color = Tx.Text, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
            }

            // 2 Music DNA
            item {
                FeatureCard("2 · Music DNA", "🧬", "Hidden structure of your taste") {
                    TextButton(
                        onClick = {
                            busy = true
                            scope.launch {
                                message = onDnaExplain()
                                busy = false
                            }
                        },
                    ) {
                        Text("Analyze my library", color = Tx.Accent2)
                    }
                }
            }

            // 3 Infinite Mix
            item {
                FeatureCard("3 · Infinite Mix", "⚡", "Session that evolves with energy flow") {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Tx.Brand)
                            .clickable {
                                onInfiniteMix()
                                message = "Infinite Mix started — shaped for right now"
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("∞ Start Infinite Mix", color = Color.White, style = MaterialTheme.typography.titleSmall)
                    }
                }
            }

            // 4 Track Alchemist
            item {
                FeatureCard("4 · Track Alchemist", "🪄", "Transform how a song feels") {
                    enumValues<AlchemistPreset>().toList().chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            row.forEach { p ->
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .height(44.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Tx.SurfaceHigh)
                                        .clickable {
                                            onApplyAlchemist(p)
                                            message = "Alchemist: ${p.emoji} ${p.label}"
                                        }
                                        .padding(8.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text("${p.emoji}", color = Tx.Text, style = MaterialTheme.typography.titleMedium)
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
            }

            // 5 Memory Lane
            item {
                FeatureCard("5 · Memory Lane", "🕰️", "Your personal soundtrack timeline") {
                    val cur = player.current
                    if (cur == null) {
                        Text("Play a song to attach a memory", color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
                    } else {
                        var note by remember(cur.id) { mutableStateOf(memoryFor(cur.id) ?: "") }
                        Text(cur.title, color = Tx.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            placeholder = { Text("What was happening?", color = Tx.Muted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Tx.Text,
                                unfocusedTextColor = Tx.Text,
                                focusedBorderColor = Tx.Accent,
                                unfocusedBorderColor = Tx.Outline,
                                cursorColor = Tx.Accent2,
                            ),
                        )
                        TextButton(onClick = {
                            onSaveMemory(cur.id, note)
                            message = "Memory saved"
                        }) { Text("Save memory", color = Tx.Accent2) }
                    }
                }
            }

            // 6 Focus Conductor
            item {
                FeatureCard("6 · Focus Conductor", "🧠", "Structured work sessions") {
                    enumValues<FocusGoal>().toList().forEach { goal ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Tx.SurfaceHigh)
                                .clickable {
                                    onFocus(goal, 1)
                                    message = "Focus: ${goal.label} (deep work stage)"
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(goal.label, color = Tx.Text, style = MaterialTheme.typography.bodyLarge)
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
            }

            // 7 Sound Detective
            item {
                FeatureCard("7 · Sound Detective", "🔬", "Understand what you hear") {
                    val cur = player.current
                    if (cur == null) {
                        Text("Play a track first", color = Tx.Muted)
                    } else {
                        TextButton(
                            onClick = {
                                busy = true
                                scope.launch {
                                    message = onSoundDetective(cur)
                                    busy = false
                                }
                            },
                        ) { Text("Analyze “${cur.title.take(28)}”", color = Tx.Accent2) }
                    }
                }
            }

            // 8 Local Music Universe
            item {
                FeatureCard("8 · Local Music Universe", "🌐", "Your library as a constellation") {
                    val seed = player.current ?: lib.songs.firstOrNull()
                    if (seed == null) {
                        Text("No songs in library", color = Tx.Muted)
                    } else {
                        val neighbors = remember(seed.id, lib.songs) { onNeighbors(seed) }
                        Text("Seed: ${seed.title}", color = Tx.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(8.dp))
                        neighbors.take(8).forEach { s ->
                            Text(
                                "★ ${s.title}",
                                color = Tx.Muted,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onPlaySongs(listOf(s) + neighbors, 0) }
                                    .padding(vertical = 4.dp),
                            )
                        }
                        TextButton(onClick = {
                            busy = true
                            scope.launch {
                                message = onUniverseExplain(seed, neighbors)
                                busy = false
                            }
                        }) { Text("Explain constellation", color = Tx.Accent2) }
                    }
                }
            }

            // 9 Personal Sound Signature
            item {
                FeatureCard("9 · Personal Sound Signature", "🎚️", "Profiles for how you listen") {
                    Text("Use Track Alchemist presets or Equalizer for signature tone.", color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
                    Text("Profiles: Neutral · Bass · Late night · Headphones · Speaker", color = Tx.Text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
                }
            }

            // 10 Creator Mode
            item {
                FeatureCard("10 · Creator Mode", "👑", "Bookmarks & listening sequences") {
                    val cur = player.current
                    if (cur == null) {
                        Text("Play a song to bookmark sections", color = Tx.Muted)
                    } else {
                        TextButton(onClick = {
                            onAddBookmark()
                            message = "Bookmark added at current position"
                        }) { Text("Bookmark current position", color = Tx.Accent2) }
                        if (bookmarks.isNotEmpty()) {
                            Text(
                                "Marks: " + bookmarks.joinToString { ms ->
                                    val s = ms / 1000
                                    "%d:%02d".format(s / 60, s % 60)
                                },
                                color = Tx.Muted,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }

            // API key
            item {
                FeatureCard("Groq API key", "🔑", "Required for best-quality PHANTOM") {
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("gsk_…", color = Tx.Muted) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Tx.Text,
                            unfocusedTextColor = Tx.Text,
                            focusedBorderColor = Tx.Accent,
                            unfocusedBorderColor = Tx.Outline,
                            cursorColor = Tx.Accent2,
                        ),
                    )
                    TextButton(onClick = {
                        onSaveGroqKey(keyInput)
                        message = if (keyInput.isNotBlank()) "API key saved on device" else "Key cleared"
                    }) { Text("Save key", color = Tx.Accent2) }
                    Text(
                        "Key stays on your phone. Used only for PHANTOM ranking & explanations.",
                        color = Tx.Muted,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@Composable
private fun MemoryStat(modifier: Modifier, value: Int, label: String) {
    val shown by animateIntAsState(value, tween(1100), label = "memoryCount")
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(shown.toString(), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
        Text(label, color = Color(0xFF6FD8F0), fontSize = 11.sp)
    }
}

@Composable
private fun InsightRow(label: String, value: String, seed: String) {
    val colors = remember(seed) { seedColors(seed) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(colors.first, colors.second))),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Person, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(value, color = Tx.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PhantomStat(modifier: Modifier = Modifier, value: String, label: String) {
    Column(
        modifier
            .clip(RoundedCornerShape(15.dp))
            .background(Color(0x2517DFFF))
            .padding(horizontal = 10.dp, vertical = 11.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = Color(0xFF72E9FF), style = MaterialTheme.typography.titleLarge)
        Text(label, color = Tx.Muted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun FeatureCard(
    title: String,
    emoji: String,
    subtitle: String,
    content: @Composable () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Tx.Surface)
            .padding(16.dp),
    ) {
        Text("$emoji  $title", color = Tx.Text, style = MaterialTheme.typography.titleMedium)
        Text(subtitle, color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        content()
    }
}
