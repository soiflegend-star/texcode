package com.texgen.music.texwave.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Automatic lyrics:
 *  1) LRCLIB synced/plain lyrics (free)
 *  2) If missing and Groq is active → AI-generated lyrics lines
 *  3) Timed lines for “listening” highlight while the song plays
 */
object LyricsEngine {

    data class Line(val timeMs: Long, val text: String)

    data class Lyrics(
        val songId: Long,
        val title: String,
        val artist: String,
        val plain: String,
        val lines: List<Line>,
        val source: String, // "lrclib" | "groq" | "cache"
        val synced: Boolean,
    )

    private val memory = ConcurrentHashMap<Long, Lyrics>()

    fun cached(songId: Long): Lyrics? = memory[songId]

    suspend fun load(
        context: Context,
        song: Song,
        groq: GroqClient?,
        forceRefresh: Boolean = false,
    ): Result<Lyrics> = withContext(Dispatchers.IO) {
        if (!forceRefresh) memory[song.id]?.let { return@withContext Result.success(it) }

        // 1) LRCLIB
        val fromNet = fetchLrclib(song).getOrNull()
        if (fromNet != null) {
            memory[song.id] = fromNet
            persist(context, fromNet)
            return@withContext Result.success(fromNet)
        }

        // disk cache
        loadDisk(context, song.id)?.let {
            memory[song.id] = it
            return@withContext Result.success(it)
        }

        // 2) Groq AI when key is active
        if (groq != null && groq.hasKey() && NetworkGate.isOnline(context)) {
            val ai = generateWithGroq(groq, song).getOrNull()
            if (ai != null) {
                memory[song.id] = ai
                persist(context, ai)
                return@withContext Result.success(ai)
            }
        }

        Result.failure(IllegalStateException("No lyrics found"))
    }

    /** Active line index while listening (playback position). */
    fun activeIndex(lyrics: Lyrics, positionMs: Long): Int {
        if (lyrics.lines.isEmpty()) return -1
        var idx = 0
        for (i in lyrics.lines.indices) {
            if (lyrics.lines[i].timeMs <= positionMs) idx = i else break
        }
        return idx
    }

    private fun fetchLrclib(song: Song): Result<Lyrics> = runCatching {
        val title = URLEncoder.encode(song.title, "UTF-8")
        val artist = URLEncoder.encode(song.artist.ifBlank { " " }, "UTF-8")
        val url = "https://lrclib.net/api/search?track_name=$title&artist_name=$artist"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 10_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Texwave/1.0")
        }
        if (conn.responseCode !in 200..299) error("lrclib ${conn.responseCode}")
        val body = conn.inputStream.bufferedReader().readText()
        val arr = JSONArray(body)
        var plain: String? = null
        var syncedRaw: String? = null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val synced = o.optString("syncedLyrics", "")
            val unsynced = o.optString("plainLyrics", "")
            if (synced.isNotBlank()) {
                syncedRaw = synced
                plain = stripLrc(synced)
                if (plain.isNotBlank()) break
            }
            if (unsynced.isNotBlank() && plain.isNullOrBlank()) {
                plain = unsynced.trim()
            }
        }
        val text = plain?.takeIf { it.isNotBlank() } ?: error("empty")
        val lines = if (!syncedRaw.isNullOrBlank()) {
            parseLrc(syncedRaw)
        } else {
            estimateTiming(text, song.durationMs)
        }
        Lyrics(
            songId = song.id,
            title = song.title,
            artist = song.artist,
            plain = text,
            lines = lines,
            source = "lrclib",
            synced = !syncedRaw.isNullOrBlank(),
        )
    }

    private suspend fun generateWithGroq(groq: GroqClient, song: Song): Result<Lyrics> {
        val system = """
            You write song lyrics for on-screen display in a music player.
            Return ONLY the lyrics, one line per verse/line, no timestamps, no commentary,
            no title headers, no markdown. Keep it between 12 and 40 lines.
            If you know the real lyrics for this track, prefer accurate lyrics.
            If unsure, write fitting atmospheric lyrics in the language of the title.
        """.trimIndent()
        val user = "Track: \"${song.title}\" by ${song.artist.ifBlank { "Unknown" }}. Album: ${song.album}."
        return groq.chat(system, user, maxTokens = 900, temperature = 0.5).mapCatching { raw ->
            val text = raw
                .lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("```") }
                .joinToString("\n")
                .trim()
            if (text.length < 20) error("too short")
            Lyrics(
                songId = song.id,
                title = song.title,
                artist = song.artist,
                plain = text,
                lines = estimateTiming(text, song.durationMs),
                source = "groq",
                synced = false,
            )
        }
    }

    private fun stripLrc(synced: String): String =
        synced.lines().joinToString("\n") { line ->
            line.replace(Regex("""\[\d{1,2}:\d{2}([.:]\d{1,3})?]"""), "").trim()
        }.trim()

    private fun parseLrc(synced: String): List<Line> {
        val out = mutableListOf<Line>()
        val re = Regex("""\[(\d{1,2}):(\d{2})([.:](\d{1,3}))?](.*)""")
        for (line in synced.lines()) {
            val m = re.find(line.trim()) ?: continue
            val min = m.groupValues[1].toLongOrNull() ?: continue
            val sec = m.groupValues[2].toLongOrNull() ?: continue
            val frac = m.groupValues[4]
            val ms = when {
                frac.isBlank() -> 0L
                frac.length == 1 -> frac.toLong() * 100
                frac.length == 2 -> frac.toLong() * 10
                else -> frac.take(3).toLong()
            }
            val text = m.groupValues[5].trim()
            if (text.isBlank()) continue
            out.add(Line(timeMs = min * 60_000 + sec * 1_000 + ms, text = text))
        }
        return out.ifEmpty { estimateTiming(stripLrc(synced), 0L) }
    }

    /** Spread plain lines across the song duration for listening highlight. */
    private fun estimateTiming(plain: String, durationMs: Long): List<Line> {
        val lines = plain.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val dur = durationMs.takeIf { it > 5_000 } ?: (lines.size * 3_500L)
        val step = (dur * 0.92 / lines.size).toLong().coerceAtLeast(1_500L)
        val start = (dur * 0.04).toLong()
        return lines.mapIndexed { i, t -> Line(start + i * step, t) }
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("texwave_lyrics_cache", Context.MODE_PRIVATE)

    private fun persist(ctx: Context, lyrics: Lyrics) {
        val j = JSONObject()
            .put("songId", lyrics.songId)
            .put("title", lyrics.title)
            .put("artist", lyrics.artist)
            .put("plain", lyrics.plain)
            .put("source", lyrics.source)
            .put("synced", lyrics.synced)
        val arr = JSONArray()
        lyrics.lines.forEach { arr.put(JSONObject().put("t", it.timeMs).put("x", it.text)) }
        j.put("lines", arr)
        prefs(ctx).edit().putString("s_${lyrics.songId}", j.toString()).apply()
    }

    private fun loadDisk(ctx: Context, songId: Long): Lyrics? = runCatching {
        val raw = prefs(ctx).getString("s_$songId", null) ?: return null
        val j = JSONObject(raw)
        val arr = j.getJSONArray("lines")
        val lines = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Line(o.getLong("t"), o.getString("x"))
        }
        Lyrics(
            songId = j.getLong("songId"),
            title = j.optString("title"),
            artist = j.optString("artist"),
            plain = j.optString("plain"),
            lines = lines,
            source = j.optString("source", "cache"),
            synced = j.optBoolean("synced"),
        )
    }.getOrNull()
}
