package com.texgen.music.texwave.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.texgen.music.texwave.data.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlayerState(
    val current: Song? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<Song> = emptyList(),
    val queueIndex: Int = -1,
    val speed: Float = 1f,
)

/**
 * Full music-session controller: queue, seek, speed, skip ±10s, clear queue,
 * play-similar helpers.
 */
class PlaybackConnection(context: Context) {
    private val appContext = context.applicationContext
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private val pending = mutableListOf<(MediaController) -> Unit>()
    private var songsById: Map<Long, Song> = emptyMap()

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    /** Playback position lives in its own flow so only the seek bar recomposes while it ticks. */
    private val _position = MutableStateFlow(0L)
    val position: StateFlow<Long> = _position.asStateFlow()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()
    }

    fun updateLibrary(songs: List<Song>) {
        songsById = songs.associateBy { it.id }
        sync()
    }

    fun audioSessionId(): Int = PlaybackService.audioSessionId

    fun connect() {
        if (future != null) return
        val token = SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
        val f = MediaController.Builder(appContext, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(listener)
                pending.forEach { it(c) }
                pending.clear()
                sync()
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(appContext))
    }

    fun release() {
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        future = null
    }

    private fun run(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending.add(block)
    }

    private fun toItem(song: Song): MediaItem = MediaItem.Builder()
        .setMediaId(song.id.toString())
        .setUri(song.contentUri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(Uri.parse(song.artUri))
                .build()
        )
        .build()

    // ---- Commands -------------------------------------------------------------------

    fun play(songs: List<Song>, startIndex: Int, shuffle: Boolean = false, startPositionMs: Long = 0L) = run { c ->
        if (songs.isEmpty()) return@run
        c.shuffleModeEnabled = shuffle
        c.setMediaItems(songs.map(::toItem), startIndex.coerceIn(0, songs.lastIndex), startPositionMs.coerceAtLeast(0L))
        c.prepare()
        c.play()
    }

    /** Loads a queue without starting playback (used to restore the last session). */
    fun load(songs: List<Song>, startIndex: Int, startPositionMs: Long) = run { c ->
        if (songs.isEmpty()) return@run
        c.setMediaItems(songs.map(::toItem), startIndex.coerceIn(0, songs.lastIndex), startPositionMs.coerceAtLeast(0L))
        c.prepare()
    }

    fun togglePlay() = run { c ->
        if (c.isPlaying) c.pause() else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun pause() = run { it.pause() }
    fun next() = run { c ->
        if (c.hasNextMediaItem()) c.seekToNextMediaItem()
        else if (c.mediaItemCount > 0) c.seekTo(0, 0L)
    }
    fun previous() = run { c ->
        // Always one-tap previous track (never restart current song first)
        val count = c.mediaItemCount
        if (count <= 0) return@run
        val idx = c.currentMediaItemIndex
        val target = when {
            idx > 0 -> idx - 1
            count > 1 -> count - 1  // wrap to last
            else -> 0
        }
        c.seekTo(target, 0L)
        c.play()
    }
    fun seekTo(ms: Long) = run { it.seekTo(ms) }
    fun skipTo(index: Int) = run { it.seekTo(index, 0L); it.play() }
    fun toggleShuffle() = run { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun seekBy(deltaMs: Long) = run { c ->
        val pos = (c.currentPosition + deltaMs).coerceAtLeast(0L)
        val dur = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: Long.MAX_VALUE
        c.seekTo(pos.coerceAtMost(dur))
    }

    fun cycleRepeat() = run {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun playNext(song: Song) = run { c ->
        if (c.mediaItemCount == 0) {
            c.setMediaItem(toItem(song)); c.prepare(); c.play()
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, toItem(song))
        }
    }

    fun addToQueue(song: Song) = run { c ->
        if (c.mediaItemCount == 0) {
            c.setMediaItem(toItem(song)); c.prepare(); c.play()
        } else {
            c.addMediaItem(toItem(song))
        }
    }

    fun removeFromQueue(index: Int) = run { c ->
        if (index in 0 until c.mediaItemCount) c.removeMediaItem(index)
    }

    fun clearQueue() = run { c ->
        val idx = c.currentMediaItemIndex
        if (idx < 0 || c.mediaItemCount <= 1) {
            c.clearMediaItems()
            return@run
        }
        // Keep only current
        val current = c.currentMediaItem ?: return@run
        val pos = c.currentPosition
        val playing = c.isPlaying
        c.setMediaItem(current, pos)
        c.prepare()
        if (playing) c.play()
    }

    fun setPlaybackSpeed(speed: Float) = run { c ->
        c.setPlaybackSpeed(speed.coerceIn(0.5f, 2f))
    }

    fun moveQueueItem(from: Int, to: Int) = run { c ->
        if (from in 0 until c.mediaItemCount && to in 0 until c.mediaItemCount) {
            c.moveMediaItem(from, to)
        }
    }

    // ---- State ----------------------------------------------------------------------

    fun tick() {
        val c = controller ?: return
        _position.value = c.currentPosition.coerceAtLeast(0L)
    }

    private fun fallbackSong(id: Long, item: MediaItem): Song = Song(
        id = id,
        title = item.mediaMetadata.title?.toString() ?: "Unknown title",
        artist = item.mediaMetadata.artist?.toString() ?: "Unknown artist",
        album = item.mediaMetadata.albumTitle?.toString() ?: "Unknown album",
        albumId = 0L,
        durationMs = 0L,
        dateAdded = 0L,
        contentUri = item.localConfiguration?.uri?.toString() ?: "",
    )

    private fun sync() {
        val c = controller ?: return
        // The queue MUST stay index-aligned with the player's own queue. Songs missing from the
        // library map (e.g. a freshly trimmed file) used to be skipped, which shifted every index
        // and made the title shown differ from the audio that was actually playing.
        val queue = ArrayList<Song>(c.mediaItemCount)
        for (i in 0 until c.mediaItemCount) {
            val item = c.getMediaItemAt(i)
            val id = item.mediaId.toLongOrNull() ?: -1L
            queue.add(songsById[id] ?: fallbackSong(id, item))
        }
        val curIdx = c.currentMediaItemIndex
        val song = queue.getOrNull(curIdx)
        val duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: song?.durationMs ?: 0L
        _position.value = c.currentPosition.coerceAtLeast(0L)
        _state.value = PlayerState(
            current = song,
            isPlaying = c.isPlaying,
            durationMs = duration,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            queue = queue,
            queueIndex = c.currentMediaItemIndex,
            speed = c.playbackParameters.speed,
        )
    }
}
