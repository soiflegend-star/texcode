package com.texgen.music.texwave.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.brain.BrainManager
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.SpeechOut
import com.texgen.music.texwave.util.VoiceInput
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

private enum class VState { IDLE, LISTENING, THINKING, SPEAKING }

private data class VMsg(val id: Long, val mine: Boolean, val text: String)

private class VoiceCtl {
    var listen: () -> Unit = {}
    var alive: Boolean = true
    var counter: Long = 1L
}

/**
 * Talk to your downloaded Brain by voice.
 *
 * Mic → speech-to-text (offline Vosk or the phone's service) → [onAsk] (the on-device Brain, with
 * the same music commands as Phantom) → spoken reply. In hands-free mode the mic re-opens by itself
 * after every answer, so it feels like a phone call with your AI.
 */
@Composable
fun VoiceChatScreen(
    onBack: () -> Unit,
    onOpenBrains: () -> Unit,
    onAsk: suspend (String, List<Pair<String, String>>) -> String,
) {
    val context = LocalContext.current
    val brain = remember { BrainManager.get(context) }
    val voice = remember { VoiceInput(context) }
    val speech = remember { SpeechOut(context) }
    val scope = rememberCoroutineScope()
    val ctl = remember { VoiceCtl() }
    val msgs = remember { mutableStateListOf<VMsg>() }
    var state by remember { mutableStateOf(VState.IDLE) }
    var partial by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var handsFree by remember { mutableStateOf(true) }
    val handsFreeNow by rememberUpdatedState(handsFree)
    val activeId by brain.activeId.collectAsState()
    val brainName = remember(activeId) { brain.activeBrain()?.name }
    val listState = rememberLazyListState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) ctl.listen() else error = "Microphone permission is needed to talk."
    }

    fun ask(text: String) {
        val hist = msgs.map { (if (it.mine) "user" else "assistant") to it.text }
        msgs.add(VMsg(ctl.counter++, true, text))
        partial = ""
        error = null
        state = VState.THINKING
        scope.launch {
            val reply = try {
                onAsk(text, hist)
            } catch (t: Throwable) {
                "Sorry, I could not answer that."
            }
            if (!ctl.alive) return@launch
            msgs.add(VMsg(ctl.counter++, false, reply))
            state = VState.SPEAKING
            speech.speakStyled(reply, 1.0f, 1.0f) {
                if (!ctl.alive) return@speakStyled
                state = VState.IDLE
                if (handsFreeNow) ctl.listen()
            }
        }
    }

    fun listen() {
        if (!ctl.alive) return
        if (!voice.hasPermission()) {
            permLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        speech.stop()
        error = null
        partial = ""
        state = VState.LISTENING
        voice.start(
            preferOffline = true,
            onPartial = { partial = it },
            onResult = { t ->
                if (t.isNotBlank()) ask(t) else state = VState.IDLE
            },
            onError = { e ->
                error = e
                state = VState.IDLE
            },
            onEnd = { if (state == VState.LISTENING) state = VState.IDLE },
        )
    }
    ctl.listen = { listen() }

    fun stopAll() {
        voice.stop()
        speech.stop()
        state = VState.IDLE
        partial = ""
    }

    DisposableEffect(Unit) {
        ctl.alive = true
        onDispose {
            ctl.alive = false
            voice.release()
            speech.shutdown()
        }
    }

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1)
    }

    val accent = Tx.Accent
    val accent2 = Tx.Accent2
    val label = when (state) {
        VState.IDLE -> "Tap the orb and talk"
        VState.LISTENING -> if (partial.isBlank()) "Listening…" else partial
        VState.THINKING -> "Thinking…"
        VState.SPEAKING -> "Speaking…"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Tx.Bg, Color(0xFF0B0716), Tx.Bg))),
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // ---- header
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.07f))
                        .clickable { stopAll(); onBack() },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Voice chat", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        brainName?.let { "Brain: $it" } ?: "No Brain installed",
                        color = if (brainName != null) Tx.Muted else Tx.Danger,
                        fontSize = 12.sp,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Hands-free", color = Tx.Muted, fontSize = 11.sp)
                    Switch(
                        checked = handsFree,
                        onCheckedChange = { handsFree = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = accent),
                    )
                }
            }

            if (brainName == null) {
                Box(
                    Modifier
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Tx.Danger.copy(alpha = 0.12f))
                        .border(1.dp, Tx.Danger.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                        .clickable { onOpenBrains() }
                        .padding(14.dp),
                ) {
                    Text(
                        "No offline Brain yet. Tap here to download one, then come back and talk. " +
                            "With internet and a Groq key, voice chat also works online.",
                        color = Color.White,
                        fontSize = 13.sp,
                    )
                }
            }

            // ---- transcript
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(msgs, key = { it.id }) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
                        Box(
                            Modifier
                                .widthIn(max = 300.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(
                                    if (m.mine) Brush.linearGradient(listOf(accent.copy(alpha = 0.85f), accent2.copy(alpha = 0.85f)))
                                    else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.09f), Color.White.copy(alpha = 0.05f))),
                                )
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                        ) { Text(m.text, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp) }
                    }
                }
            }

            // ---- orb + status
            Column(
                Modifier.fillMaxWidth().padding(bottom = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    label,
                    color = if (state == VState.LISTENING && partial.isNotBlank()) Color.White else Tx.Muted,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 3,
                    modifier = Modifier.padding(horizontal = 28.dp).height(60.dp),
                )
                error?.let {
                    Text(it, color = Tx.Danger, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 28.dp, vertical = 2.dp))
                }
                VoiceOrb(state = state, accent = accent, accent2 = accent2) {
                    when (state) {
                        VState.IDLE -> listen()
                        else -> stopAll()
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceOrb(state: VState, accent: Color, accent2: Color, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "orb")
    val phase by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    val energySpring by animateFloatAsState(
        when (state) {
            VState.IDLE -> 0.25f
            VState.LISTENING -> 0.9f
            VState.THINKING -> 0.55f
            VState.SPEAKING -> 1f
        },
        spring(dampingRatio = 0.6f, stiffness = 120f),
        label = "energy",
    )
    val energy = energySpring.coerceIn(0f, 1f)
    val core by animateColorAsState(
        when (state) {
            VState.LISTENING -> Tx.Accent3
            VState.SPEAKING -> accent2
            else -> accent
        },
        tween(400),
        label = "core",
    )
    Box(
        Modifier
            .size(190.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val base = size.minDimension * 0.26f
            // expanding rings
            for (i in 0 until 3) {
                val p = (phase + i / 3f) % 1f
                val r = base * (1.15f + p * (0.8f + energy * 0.6f))
                drawCircle(
                    color = core.copy(alpha = (1f - p) * 0.35f * (0.3f + energy)),
                    radius = r,
                    center = c,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx()),
                )
            }
            // soft glow
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(core.copy(alpha = 0.55f * energy + 0.1f), Color.Transparent),
                    center = c,
                    radius = base * 2.1f,
                ),
                radius = base * 2.1f,
                center = c,
            )
            // wobbling body
            val wob = 1f + 0.06f * energy * sin(phase * 2f * PI.toFloat() * 2f)
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.9f), core, accent2.copy(alpha = 0.9f)),
                    center = Offset(c.x - base * 0.25f, c.y - base * 0.3f),
                    radius = base * 1.5f,
                ),
                radius = base * wob,
                center = c,
            )
        }
        Icon(
            when (state) {
                VState.IDLE -> Icons.Rounded.Mic
                VState.LISTENING -> Icons.Rounded.GraphicEq
                VState.THINKING -> Icons.Rounded.Stop
                VState.SPEAKING -> Icons.Rounded.Stop
            },
            contentDescription = "Voice",
            tint = Color.White,
            modifier = Modifier.size(34.dp).graphicsLayer { alpha = 0.95f },
        )
    }
}
