package com.texgen.music.texwave.ui.screens.security

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.texgen.music.texwave.ui.theme.TexTokens

/** AUVYRR SECURITY CENTER — premium polish. Real permission visibility only. */
@Composable
fun AuvyrrSecurityCenter(
    onBack: () -> Unit = {},
    onOpenAppSettings: () -> Unit = {},
) {
    val context = LocalContext.current
    val permissionState = remember { computePermissionSnapshot(context) }
    val score = remember(permissionState) { computeSecurityScore(permissionState) }
    val scoreColor = when {
        score >= 80 -> TexTokens.Success
        score >= 50 -> Color(0xFFFFB020)
        else -> TexTokens.Danger
    }

    Box(Modifier.fillMaxSize().background(TexTokens.Bg)) {
        Box(
            Modifier.fillMaxWidth().height(220.dp).background(
                Brush.verticalGradient(listOf(scoreColor.copy(0.07f), Color.Transparent))
            )
        )
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.size(40.dp).clip(CircleShape).background(TexTokens.Elevated.copy(0.85f))
                ) {
                    Icon(Icons.Rounded.ArrowBack, null, tint = TexTokens.TextPrimary, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("SECURITY", color = TexTokens.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.4.sp)
                    Text("Privacy & Protection", color = TexTokens.TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp)
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                            .background(Brush.linearGradient(listOf(TexTokens.Elevated, Color(0xFF0A101C))))
                            .border(1.dp, scoreColor.copy(0.3f), RoundedCornerShape(22.dp))
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(72.dp).clip(CircleShape).background(scoreColor.copy(0.12f))
                                .border(1.5.dp, scoreColor.copy(0.35f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("$score", color = scoreColor, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(
                                when {
                                    score >= 80 -> "Strong posture"
                                    score >= 50 -> "Review recommended"
                                    else -> "Action needed"
                                },
                                color = TexTokens.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(3.dp))
                            Text("Based on permission state & storage model", color = TexTokens.TextSecondary, fontSize = 13.sp)
                        }
                    }
                }

                item { SectionLabel("PERMISSIONS") }
                items(permissionState.size) { idx -> PermissionRow(permissionState[idx]) }
                item { SectionLabel("DEVICE & APP") }
                item { InfoCard(Icons.Rounded.PhoneAndroid, "App target SDK", "34 (Android 14)", "Compiled against current platform") }
                item { InfoCard(Icons.Rounded.Lock, "Local data", "App-private storage", "Media & projects remain on-device by default") }
                item {
                    InfoCard(
                        Icons.Rounded.VpnKey, "Network",
                        if (Build.VERSION.SDK_INT >= 28) "Cleartext restricted by default" else "Legacy cleartext allowed",
                        "Uses network security config where present"
                    )
                }
                item { SectionLabel("RECOMMENDATIONS") }
                item {
                    RecommendationCard(
                        "Review microphone & notification access only when you use those features.",
                        "Open system settings", onOpenAppSettings
                    )
                }
                item { RecommendationCard("Keep the app updated. Security fixes ship with regular releases.", null, {}) }
                item {
                    Text(
                        "AUVYRR does not claim real-time malware scanning or system-level antivirus. " +
                            "This center shows only what the app can legitimately observe about its own permissions and storage posture.",
                        color = TexTokens.TextSecondary.copy(0.65f), fontSize = 12.sp, lineHeight = 16.sp,
                        modifier = Modifier.padding(top = 6.dp, bottom = 20.dp)
                    )
                }
            }
        }
    }
}

data class PermissionInfo(
    val name: String, val granted: Boolean, val dangerous: Boolean,
    val description: String, val icon: ImageVector
)

private fun computePermissionSnapshot(context: Context): List<PermissionInfo> {
    fun granted(perm: String) =
        ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
    return buildList {
        add(PermissionInfo(
            "Audio / Music library",
            if (Build.VERSION.SDK_INT >= 33) granted(Manifest.permission.READ_MEDIA_AUDIO)
            else granted(Manifest.permission.READ_EXTERNAL_STORAGE),
            true, "Required to build your local library", Icons.Rounded.LibraryMusic
        ))
        if (Build.VERSION.SDK_INT >= 33) {
            add(PermissionInfo("Notifications", granted(Manifest.permission.POST_NOTIFICATIONS), true, "Playback controls & alarms", Icons.Rounded.Notifications))
        }
        add(PermissionInfo("Microphone", granted(Manifest.permission.RECORD_AUDIO), true, "Voice features (on demand)", Icons.Rounded.Mic))
        add(PermissionInfo(
            "Bluetooth / Nearby devices",
            if (Build.VERSION.SDK_INT >= 31) granted(Manifest.permission.BLUETOOTH_CONNECT) else true,
            true, "Headphone / device protocol work", Icons.Rounded.Bluetooth
        ))
        add(PermissionInfo("Camera", granted(Manifest.permission.CAMERA), true, "Arena / optional capture", Icons.Rounded.CameraAlt))
    }
}

private fun computeSecurityScore(perms: List<PermissionInfo>): Int {
    var score = 70
    perms.forEach { p ->
        if (p.granted && p.dangerous) score += 4
        if (!p.granted && p.name.contains("Audio")) score -= 15
    }
    return score.coerceIn(0, 100)
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = TexTokens.TextSecondary.copy(0.85f), fontSize = 11.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 1.4.sp, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
}

@Composable
private fun PermissionRow(p: PermissionInfo) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(TexTokens.Surface)
            .border(1.dp, TexTokens.Outline, RoundedCornerShape(14.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(11.dp))
                .background(if (p.granted) TexTokens.Success.copy(0.12f) else TexTokens.TextSecondary.copy(0.08f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(p.icon, null, tint = if (p.granted) TexTokens.Success else TexTokens.TextSecondary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, color = TexTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(p.description, color = TexTokens.TextSecondary, fontSize = 12.sp)
        }
        Text(
            if (p.granted) "Granted" else "Not granted",
            color = if (p.granted) TexTokens.Success else TexTokens.TextSecondary,
            fontSize = 12.sp, fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun InfoCard(icon: ImageVector, title: String, value: String, subtitle: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(TexTokens.Surface)
            .border(1.dp, TexTokens.Outline, RoundedCornerShape(14.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = TexTokens.Cyan, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = TexTokens.TextSecondary, fontSize = 12.sp)
            Text(value, color = TexTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = TexTokens.TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun RecommendationCard(text: String, actionLabel: String?, onAction: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(TexTokens.Surface)
            .border(1.dp, TexTokens.Outline, RoundedCornerShape(14.dp)).padding(14.dp)
    ) {
        Text(text, color = TexTokens.TextPrimary, fontSize = 13.sp, lineHeight = 18.sp)
        if (actionLabel != null) {
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = onAction) {
                Text(actionLabel, color = TexTokens.Cyan, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}
