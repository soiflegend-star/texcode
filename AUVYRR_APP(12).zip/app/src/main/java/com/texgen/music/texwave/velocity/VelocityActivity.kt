package com.texgen.music.texwave.velocity

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * Full-screen host for the Velocity web game (assets/velocity). The AUVYRR player keeps
 * playing underneath; this screen only mirrors its state into the game and closes on request.
 */
class VelocityActivity : Activity() {
    private var web: WebView? = null
    private val ui = Handler(Looper.getMainLooper())
    private var lastTrackId: String? = null
    private var lastPlaying: Boolean? = null
    private var ticks = 0
    private var splash: android.widget.TextView? = null

    private val ticker = object : Runnable {
        override fun run() {
            val t = VelocityHost.track
            if (t != null) {
                if (t.id != lastTrackId) {
                    lastTrackId = t.id
                    lastPlaying = t.playing
                    pushNowPlaying()
                } else if (t.playing != lastPlaying || ticks % 2 == 0) {
                    lastPlaying = t.playing
                    pushPlayback(t.playing, VelocityHost.position())
                }
            }
            ticks++
            ui.postDelayed(this, 1000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        VelocityHost.activityOpen = true
        VelocityNotifier.dismiss(this)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.allowFileAccess = false
        w.setBackgroundColor(0xFF05070D.toInt())
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        w.addJavascriptInterface(HostApi(), "AuvyrrHost")
        w.loadUrl("https://appassets.androidplatform.net/velocity/index.html?host=android&maxTier=HIGH")
        web = w
        val sp = android.widget.TextView(this).apply {
            text = "VELOCITY\nloading your track…"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 18f
            gravity = android.view.Gravity.CENTER
            setBackgroundColor(0xFF05070D.toInt())
        }
        splash = sp
        setContentView(FrameLayout(this).apply { addView(w); addView(sp) })
        // never leave the splash stuck if the game is slow to report in
        ui.postDelayed({ hideSplash() }, 12_000)
        hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        ui.removeCallbacks(ticker)
        ui.postDelayed(ticker, 1000)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    /** game -> host. Events arrive as {"kind":"event","event":{"type":...}}. */
    inner class HostApi {
        @JavascriptInterface
        fun postMessage(json: String) {
            val type = runCatching { JSONObject(json).optJSONObject("event")?.optString("type") }.getOrNull() ?: return
            when (type) {
                "VELOCITY_OPENED" -> runOnUiThread { hideSplash(); lastTrackId = VelocityHost.track?.id; pushNowPlaying() }
                "RETURN_TO_PLAYER_REQUESTED", "VELOCITY_CLOSED" -> runOnUiThread { finish() }
            }
        }
    }

    private fun hideSplash() {
        splash?.let { (it.parent as? FrameLayout)?.removeView(it) }
        splash = null
    }

    private fun pushNowPlaying() {
        val t = VelocityHost.track ?: return
        send(
            "nowPlaying",
            JSONObject()
                .put("title", t.title)
                .put("artist", t.artist)
                .put("trackId", t.id)
                .put("durationMs", t.durationMs)
                .put("positionMs", VelocityHost.position())
                .put("playing", t.playing),
        )
    }

    private fun pushPlayback(playing: Boolean, positionMs: Long) =
        send("playbackState", JSONObject().put("playing", playing).put("positionMs", positionMs))

    private fun send(type: String, payload: JSONObject) {
        val cmd = JSONObject()
            .put("id", "h-" + System.nanoTime())
            .put("type", type)
            .put("timestamp", System.currentTimeMillis())
            .put("priority", "normal")
            .put("payload", payload)
        val msg = JSONObject().put("kind", "command").put("command", cmd).toString()
        web?.post {
            web?.evaluateJavascript("window.VelocityHost && window.VelocityHost.receive(${JSONObject.quote(msg)})", null)
        }
    }

    /** Back goes to the game, which owns the double-back rule (1st = pause + warn, 2nd = return to player). */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        send("hostBackPressed", JSONObject())
    }

    override fun onDestroy() {
        VelocityHost.activityOpen = false
        ui.removeCallbacks(ticker)
        web?.let { (it.parent as? FrameLayout)?.removeView(it); it.destroy() }
        web = null
        super.onDestroy()
    }
}
