package com.texgen.music.texwave.tagger

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.texgen.music.texwave.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.Normalizer
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

/** A possible match found on the internet. */
data class TagCandidate(
    val title: String,
    val artist: String,
    val album: String,
    val year: Int,
    val artUrl: String,
    val durationMs: Long,
    val score: Float,
    val source: String,
)

/**
 * Song finder for the tag editor. Searches Deezer, iTunes (US + India catalogues), MusicBrainz and
 * LRCLIB at the same time (all free, no key), with several guesses of what the song really is —
 * the tag title, the file name, "Artist - Title" in both orders, text before brackets — then scores
 * every result with fuzzy word matching and merges duplicates. When several services agree the
 * score goes up. [search] lets the user type any song name by hand.
 */
object TagLookup {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val pool = Executors.newFixedThreadPool(8) { r -> Thread(r, "taglookup").apply { isDaemon = true } }

    const val CONFIDENT = 0.62f

    private fun get(url: String): String? = try {
        val req = Request.Builder().url(url)
            .header("User-Agent", "AUVYRR-TagEditor/2.0 (https://auvyrr.app)")
            .build()
        http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
    } catch (_: Throwable) {
        null
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    // ------------------------------------------------------------------ text cleaning

    private val junk = Regex(
        "\\(.*?\\)|\\[.*?]|\\{.*?}|https?://\\S+|www\\.\\S+|" +
            "\\b[\\w-]+\\.(com|net|in|org|io|co|pk|me|fm|cc|info)\\b|" +
            "\\b(official|video|audio|lyrics?|lyrical|full song|full video|music video|visuali[sz]er|" +
            "hd|hq|4k|8k|remaster(ed)?|mp3|m4a|flac|wav|aac|ogg|opus|\\d{2,3}\\s?kbps|free download)\\b",
        RegexOption.IGNORE_CASE,
    )
    private val featCut = Regex("\\s+(ft\\.?|feat\\.?|featuring)\\s+.*$", RegexOption.IGNORE_CASE)

    /** Title/artist text with brackets, site names, quality tags and file noise removed. */
    fun clean(raw: String): String {
        var s = raw.replace('_', ' ')
        s = s.replace(Regex("\\.(mp3|m4a|flac|wav|aac|ogg|opus)$", RegexOption.IGNORE_CASE), "")
        s = junk.replace(s, " ")
        s = s.replace(Regex("^\\s*\\d{1,3}\\s*[.)\\-]\\s+"), "")
        s = s.replace(Regex("\\s+-\\s*$|^\\s*-\\s+"), " ")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun stripFeat(s: String): String = featCut.replace(s, "").trim()

    private fun norm(s: String): String {
        val d = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return d.replace("&", " and ").replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
    }

    private fun tokens(s: String): List<String> =
        norm(s).split(' ').filter { it.isNotEmpty() && (it.length > 1 || it[0].isDigit()) }

    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            val t = prev
            prev = cur
            cur = t
        }
        return prev[b.length]
    }

    private fun tokenSim(a: String, b: String): Float {
        if (a == b) return 1f
        val m = max(a.length, b.length)
        if (m < 4) return 0f
        val s = 1f - lev(a, b).toFloat() / m
        return if (s >= 0.75f) s else 0f
    }

    private fun overlap(a: List<String>, b: List<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        var ab = 0.0
        for (x in a) ab += b.maxOf { tokenSim(x, it).toDouble() }
        var ba = 0.0
        for (y in b) ba += a.maxOf { tokenSim(y, it).toDouble() }
        return ((ab + ba) / (a.size + b.size)).toFloat()
    }

    private fun containedIn(a: List<String>, b: List<String>): Boolean =
        a.isNotEmpty() && a.all { x -> b.any { tokenSim(x, it) >= 0.85f } }

    private fun unknownArtist(a: String): Boolean {
        val t = a.trim().lowercase()
        return t.isEmpty() || t == "<unknown>" || t == "unknown" || t == "unknown artist"
    }

    // ------------------------------------------------------------------ what could this song be?

    private class Hyp(val title: String, val artist: String, val weight: Float)

    private fun splitDash(text: String, weight: Float, out: MutableList<Hyp>, knownArtist: String) {
        val parts = text.split(Regex("\\s+[-–—|:]\\s+|\\s*[-–—]\\s+")).map { clean(it) }.filter { it.isNotBlank() }
        if (parts.size >= 2) {
            val a = parts[0]
            val b = parts.drop(1).joinToString(" ")
            out += Hyp(stripFeat(b), a, weight)          // "Artist - Title"
            out += Hyp(stripFeat(a), b, weight * 0.94f)  // "Title - Artist"
            out += Hyp(stripFeat(b), "", weight * 0.9f)
        } else if (parts.size == 1) {
            out += Hyp(stripFeat(parts[0]), knownArtist, weight)
        }
    }

    private fun hypotheses(song: Song): List<Hyp> {
        val known = if (unknownArtist(song.artist)) "" else clean(song.artist)
        val out = ArrayList<Hyp>()
        out += Hyp(stripFeat(clean(song.title)), known, 1f)
        // text before the first bracket / dash is often the real title
        val head = song.title.substringBefore('(').substringBefore('[').substringBefore(" - ").trim()
        if (head.isNotBlank() && head != song.title) out += Hyp(stripFeat(clean(head)), known, 0.97f)
        if (song.title.contains(" - ") || song.title.contains(" – ")) splitDash(song.title, 0.98f, out, known)
        val file = song.path.substringAfterLast('/').substringBeforeLast('.', "")
        if (file.isNotBlank() && norm(file) != norm(song.title)) splitDash(file, 0.96f, out, known)
        if (known.isNotBlank()) out += Hyp(stripFeat(clean(song.title)), "", 0.92f)
        val seen = HashSet<String>()
        return out.filter { it.title.isNotBlank() && seen.add(norm(it.title) + "|" + norm(it.artist)) }
    }

    private fun hypothesesFromText(text: String): List<Hyp> {
        val out = ArrayList<Hyp>()
        val t = clean(text)
        if (text.contains(" - ") || text.contains(" – ") || text.contains(" | ")) splitDash(text, 1f, out, "")
        out += Hyp(stripFeat(t), "", 0.98f)
        val seen = HashSet<String>()
        return out.filter { it.title.isNotBlank() && seen.add(norm(it.title) + "|" + norm(it.artist)) }
    }

    private fun queriesFor(h: List<Hyp>, max: Int): List<String> {
        val out = LinkedHashSet<String>()
        for (x in h) {
            if (x.artist.isNotBlank()) out += "${x.title} ${x.artist}".trim()
            out += x.title
        }
        return out.filter { it.isNotBlank() }.take(max)
    }

    // ------------------------------------------------------------------ scoring

    private class Raw(
        val title: String,
        val artist: String,
        val album: String,
        val year: Int,
        val artUrl: String,
        val durationMs: Long,
        val source: String,
    )

    private val lookalike = listOf(
        "karaoke", "cover", "tribute", "instrumental", "remix", "live", "slowed", "reverb", "lofi", "lo-fi",
        "8d", "acoustic", "sped up", "nightcore", "mashup", "unplugged", "version",
    )

    private fun hypScore(h: Hyp, r: Raw, refDur: Long, refAlbum: String): Float {
        val ht = tokens(h.title)
        val rt = tokens(r.title)
        var t = overlap(ht, rt)
        if (containedIn(ht, rt)) t = max(t, 0.9f)
        val a = if (h.artist.isBlank()) 0.5f else {
            val ha = tokens(h.artist)
            val ra = tokens(r.artist)
            var s = overlap(ha, ra)
            if (ha.any { x -> ra.any { tokenSim(x, it) >= 0.85f } }) s = max(s, 0.7f)
            if (containedIn(ha, ra)) s = max(s, 0.9f)
            s
        }
        val d = if (r.durationMs <= 0 || refDur <= 0) 0.5f else {
            val diff = abs(r.durationMs - refDur)
            when {
                diff <= 4000 -> 1f
                diff <= 12000 -> 0.6f
                diff <= 30000 -> 0.25f
                else -> 0f
            }
        }
        val alb = if (refAlbum.isBlank() || r.album.isBlank()) 0f
        else if (overlap(tokens(refAlbum), tokens(r.album)) > 0.6f) 1f else 0f
        var s = (t * 0.58f + a * 0.24f + d * 0.14f + alb * 0.04f) * h.weight
        val rl = r.title.lowercase()
        val hl = h.title.lowercase()
        if (lookalike.any { it in rl && it !in hl }) s *= 0.72f
        return s
    }

    private fun scoreOf(hyps: List<Hyp>, r: Raw, refDur: Long, refAlbum: String): Float =
        hyps.maxOfOrNull { hypScore(it, r, refDur, refAlbum) } ?: 0f

    // ------------------------------------------------------------------ sources

    private fun deezer(query: String): List<Raw> {
        val body = get("https://api.deezer.com/search?limit=10&q=" + enc(query)) ?: return emptyList()
        return try {
            val arr = JSONObject(body).optJSONArray("data") ?: return emptyList()
            val out = ArrayList<Raw>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val title = o.optString("title")
                if (title.isBlank()) continue
                val artist = o.optJSONObject("artist")?.optString("name").orEmpty()
                val alb = o.optJSONObject("album")
                val art = alb?.optString("cover_xl").orEmpty().ifBlank { alb?.optString("cover_big").orEmpty() }
                out += Raw(title, artist, alb?.optString("title").orEmpty(), 0, art, o.optLong("duration", 0L) * 1000L, "Deezer")
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun itunes(query: String, country: String): List<Raw> {
        val body = get(
            "https://itunes.apple.com/search?media=music&entity=song&limit=10&country=$country&term=" + enc(query),
        ) ?: return emptyList()
        return try {
            val arr = JSONObject(body).optJSONArray("results") ?: return emptyList()
            val out = ArrayList<Raw>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val title = o.optString("trackName")
                if (title.isBlank()) continue
                val art = o.optString("artworkUrl100").replace("100x100bb", "1000x1000bb")
                val year = o.optString("releaseDate").take(4).toIntOrNull() ?: 0
                out += Raw(
                    title, o.optString("artistName"), o.optString("collectionName"), year, art,
                    o.optLong("trackTimeMillis", 0L), "iTunes",
                )
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    @Volatile private var mbLast = 0L

    private fun musicBrainz(title: String, artist: String): List<Raw> {
        // MusicBrainz allows one request per second.
        synchronized(this) {
            val wait = 1100L - (System.currentTimeMillis() - mbLast)
            if (wait > 0) try { Thread.sleep(wait) } catch (_: InterruptedException) {}
            mbLast = System.currentTimeMillis()
        }
        val q = if (artist.isBlank()) "recording:\"$title\"" else "recording:\"$title\" AND artist:\"$artist\""
        val body = get("https://musicbrainz.org/ws/2/recording/?fmt=json&limit=8&query=" + enc(q)) ?: return emptyList()
        return try {
            val arr = JSONObject(body).optJSONArray("recordings") ?: return emptyList()
            val out = ArrayList<Raw>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val t = o.optString("title")
                if (t.isBlank()) continue
                val credit = o.optJSONArray("artist-credit")
                val names = ArrayList<String>()
                if (credit != null) for (k in 0 until credit.length()) {
                    credit.optJSONObject(k)?.optString("name")?.takeIf { it.isNotBlank() }?.let { names += it }
                }
                val rels = o.optJSONArray("releases")
                var album = ""
                var year = 0
                var art = ""
                if (rels != null && rels.length() > 0) {
                    val rel = rels.optJSONObject(0)
                    album = rel?.optString("title").orEmpty()
                    year = rel?.optString("date").orEmpty().take(4).toIntOrNull() ?: 0
                    val id = rel?.optString("id").orEmpty()
                    if (id.isNotBlank()) art = "https://coverartarchive.org/release/$id/front-500"
                }
                out += Raw(t, names.joinToString(", "), album, year, art, o.optLong("length", 0L), "MusicBrainz")
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun lrclib(query: String): List<Raw> {
        val body = get("https://lrclib.net/api/search?q=" + enc(query)) ?: return emptyList()
        return try {
            val arr = org.json.JSONArray(body)
            val out = ArrayList<Raw>()
            for (i in 0 until minOf(arr.length(), 8)) {
                val o = arr.optJSONObject(i) ?: continue
                val t = o.optString("trackName")
                if (t.isBlank()) continue
                out += Raw(
                    t, o.optString("artistName"), o.optString("albumName"), 0, "",
                    (o.optDouble("duration", 0.0) * 1000).toLong(), "LRCLIB",
                )
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun parallel(tasks: List<() -> List<Raw>>): List<Raw> {
        val fs = tasks.map { t ->
            pool.submit(Callable<List<Raw>> { try { t() } catch (_: Throwable) { emptyList() } })
        }
        return fs.flatMap { f -> try { f.get(18, TimeUnit.SECONDS) } catch (_: Throwable) { emptyList() } }
    }

    // ------------------------------------------------------------------ merge

    private fun firstArtist(a: String): String =
        norm(a.split(Regex("[,&;/]|\\s+(feat|ft|featuring|x|and)\\.?\\s+", RegexOption.IGNORE_CASE)).firstOrNull().orEmpty())

    private fun merge(raws: List<Raw>, hyps: List<Hyp>, refDur: Long, refAlbum: String): List<TagCandidate> {
        if (raws.isEmpty()) return emptyList()
        val scored = raws.map { it to scoreOf(hyps, it, refDur, refAlbum) }
        val groups = LinkedHashMap<String, MutableList<Pair<Raw, Float>>>()
        for (p in scored) {
            val key = norm(stripFeat(p.first.title)) + "|" + firstArtist(p.first.artist)
            groups.getOrPut(key) { ArrayList() }.add(p)
        }
        val out = ArrayList<TagCandidate>()
        for ((_, g) in groups) {
            val best = g.maxByOrNull { it.second }!!
            val sources = g.map { it.first.source }.distinct()
            val art = g.sortedByDescending { it.second }
                .map { it.first }
                .sortedBy { if (it.source == "MusicBrainz") 1 else 0 }
                .firstOrNull { it.artUrl.isNotBlank() }?.artUrl.orEmpty()
            val album = best.first.album.ifBlank { g.map { it.first.album }.firstOrNull { it.isNotBlank() }.orEmpty() }
            val year = best.first.year.takeIf { it > 0 } ?: g.map { it.first.year }.firstOrNull { it > 0 } ?: 0
            val dur = best.first.durationMs.takeIf { it > 0 } ?: g.map { it.first.durationMs }.firstOrNull { it > 0 } ?: 0L
            val agree = (sources.size - 1).coerceAtMost(2) * 0.03f
            out += TagCandidate(
                best.first.title, best.first.artist, album, year, art, dur,
                (best.second + agree).coerceAtMost(1f), sources.joinToString("+"),
            )
        }
        return out.sortedByDescending { it.score }
    }

    // ------------------------------------------------------------------ public API

    private fun tasksFor(queries: List<String>, hyps: List<Hyp>, deep: Boolean): List<() -> List<Raw>> {
        val t = ArrayList<() -> List<Raw>>()
        for (q in queries) {
            t += { deezer(q) }
            t += { itunes(q, "us") }
            t += { itunes(q, "in") }
        }
        if (deep) {
            queries.take(2).forEach { q -> t += { lrclib(q) } }
            hyps.take(2).forEach { h -> t += { musicBrainz(h.title, h.artist) } }
        }
        return t
    }

    /** Matches from every service, best first. Blocking: call from a background dispatcher. */
    fun candidatesBlocking(song: Song): List<TagCandidate> {
        val hyps = hypotheses(song)
        val queries = queriesFor(hyps, 4)
        if (queries.isEmpty()) return emptyList()
        val raws = parallel(tasksFor(queries, hyps, deep = true))
        return merge(raws, hyps, song.durationMs, if (song.album.isBlank()) "" else song.album).take(14)
    }

    suspend fun candidates(song: Song): List<TagCandidate> = withContext(Dispatchers.IO) { candidatesBlocking(song) }

    /** Free-text search for any song (the user types it). */
    fun searchBlocking(text: String): List<TagCandidate> {
        val hyps = hypothesesFromText(text)
        val queries = queriesFor(hyps, 3).ifEmpty { listOf(text.trim()) }.filter { it.isNotBlank() }
        if (queries.isEmpty()) return emptyList()
        val raws = parallel(tasksFor(queries, hyps, deep = true))
        return merge(raws, hyps, 0L, "").take(16)
    }

    suspend fun search(text: String): List<TagCandidate> = withContext(Dispatchers.IO) { searchBlocking(text) }

    /**
     * The best match if it is confident enough to apply without asking. Fast first pass (one query,
     * three catalogues); only if that is not convincing does it run the full search.
     */
    fun best(song: Song): TagCandidate? {
        val hyps = hypotheses(song)
        val queries = queriesFor(hyps, 4)
        if (queries.isEmpty()) return null
        val first = merge(parallel(tasksFor(queries.take(1), hyps, deep = false)), hyps, song.durationMs, song.album)
        val top1 = first.firstOrNull()
        if (top1 != null && top1.score >= CONFIDENT + 0.08f) return top1
        val all = merge(parallel(tasksFor(queries, hyps, deep = true)), hyps, song.durationMs, song.album)
        val top = all.firstOrNull()
        return if (top != null && top.score >= CONFIDENT) top else null
    }

    // ------------------------------------------------------------------ artwork (one small JPEG per album, shared)

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(20)

    /** Downloads, shrinks to 600 px and stores the artwork. Returns the file name, or null. */
    fun fetchArt(context: Context, url: String): String? {
        if (url.isBlank()) return null
        val name = sha(url) + ".jpg"
        val file = TagStore.artFile(name) ?: return null
        if (file.exists() && file.length() > 0) return name
        return try {
            val req = Request.Builder().url(url).header("User-Agent", "AUVYRR-TagEditor/2.0").build()
            val bytes = http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.bytes() else null } ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 600) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return null
            val scaled = if (bmp.width > 600) {
                Bitmap.createScaledBitmap(bmp, 600, (bmp.height * 600f / bmp.width).toInt().coerceAtLeast(1), true)
            } else bmp
            file.parentFile?.mkdirs()
            FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            if (scaled !== bmp) scaled.recycle()
            bmp.recycle()
            name
        } catch (_: Throwable) {
            null
        }
    }

    suspend fun fetchArtAsync(context: Context, url: String): String? = withContext(Dispatchers.IO) { fetchArt(context, url) }
}
