package com.texgen.music.texwave.tagger

import android.content.Context
import android.net.Uri
import com.texgen.music.texwave.data.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One song's tags that were fetched from the internet or typed by the user. */
data class TagEdit(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val year: Int,
    val art: String,
    val online: Boolean,
    /** True when the tags were also written into the audio file itself. */
    val inFile: Boolean = false,
    /** Audio file path; lets the tags survive a media rescan that assigns a new id. */
    val path: String = "",
)

data class SyncProgress(
    val running: Boolean = false,
    val done: Int = 0,
    val total: Int = 0,
    val matched: Int = 0,
    val skipped: Int = 0,
    val written: Int = 0,
    val finished: Boolean = false,
)

/**
 * Small, storage-friendly tag overrides. Only changed songs are stored (one tiny JSON file) and artwork is a
 * 600 px JPEG shared by every song of the same album. The audio files themselves are never touched.
 */
object TagStore {
    private var dir: File? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var syncJob: Job? = null

    private val _edits = MutableStateFlow<Map<Long, TagEdit>>(emptyMap())
    val edits: StateFlow<Map<Long, TagEdit>> = _edits.asStateFlow()

    private val _progress = MutableStateFlow(SyncProgress())
    val progress: StateFlow<SyncProgress> = _progress.asStateFlow()

    /** Called after any change so the library list can be rebuilt. */
    @Volatile var onChanged: (() -> Unit)? = null

    @Synchronized
    fun init(context: Context) {
        if (dir != null) return
        val d = File(context.applicationContext.filesDir, "tags")
        File(d, "art").mkdirs()
        dir = d
        try {
            val f = File(d, "tags.json")
            if (f.exists()) {
                val arr = JSONArray(f.readText())
                val m = HashMap<Long, TagEdit>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val e = TagEdit(
                        o.getLong("id"), o.optString("t"), o.optString("a"), o.optString("al"),
                        o.optInt("y", 0), o.optString("art"), o.optBoolean("on", false), o.optBoolean("f", false), o.optString("p"),
                    )
                    m[e.id] = e
                }
                _edits.value = m
            }
        } catch (_: Throwable) {
            _edits.value = emptyMap()
        }
    }

    fun artFile(name: String): File? {
        val d = dir ?: return null
        return if (name.isBlank()) null else File(File(d, "art"), name)
    }

    /** The song with its saved tags applied. */
    fun apply(s: Song): Song {
        val e = _edits.value[s.id] ?: byPath(s.path) ?: return s
        val art = artFile(e.art)
        return s.copy(
            title = e.title.ifBlank { s.title },
            artist = e.artist.ifBlank { s.artist },
            album = e.album.ifBlank { s.album },
            year = if (e.year > 0) e.year else s.year,
            artOverride = if (art != null && art.exists()) Uri.fromFile(art).toString() else "",
        )
    }

    private fun byPath(path: String): TagEdit? {
        if (path.isBlank()) return null
        return _edits.value.values.firstOrNull { it.path.isNotBlank() && it.path == path }
    }

    fun isTagged(id: Long): Boolean = _edits.value.containsKey(id)

    fun save(edit: TagEdit) {
        _edits.value = _edits.value + (edit.id to edit)
        persist()
        onChanged?.invoke()
    }

    /**
     * Saves the tags in the app and, when file access is allowed, into the audio file too.
     * Returns null when the file was written, otherwise the reason it was not (the tags still apply inside the app).
     */
    fun saveAndWrite(context: Context, song: Song, edit: TagEdit): String? {
        val art = artFile(edit.art)
        val err = TagWriter.write(context, song.path, edit.title, edit.artist, edit.album, edit.year, art)
        save(edit.copy(inFile = err == null, path = song.path))
        return err
    }

    fun clear(id: Long) {
        _edits.value = _edits.value - id
        persist()
        onChanged?.invoke()
        scope.launch { pruneArt() }
    }

    fun clearAll() {
        _edits.value = emptyMap()
        persist()
        onChanged?.invoke()
        scope.launch { pruneArt() }
    }

    @Synchronized
    private fun persist() {
        val d = dir ?: return
        try {
            val arr = JSONArray()
            for (e in _edits.value.values) {
                arr.put(
                    JSONObject().put("id", e.id).put("t", e.title).put("a", e.artist)
                        .put("al", e.album).put("y", e.year).put("art", e.art).put("on", e.online).put("f", e.inFile).put("p", e.path),
                )
            }
            File(d, "tags.json").writeText(arr.toString())
        } catch (_: Throwable) {
        }
    }

    /** Deletes artwork files no song uses any more. */
    private fun pruneArt() {
        val d = dir ?: return
        val used = _edits.value.values.map { it.art }.toSet()
        File(d, "art").listFiles()?.forEach { if (it.name !in used) it.delete() }
    }

    fun totalBytes(): Long {
        val d = dir ?: return 0L
        var n = 0L
        d.walkTopDown().forEach { if (it.isFile) n += it.length() }
        return n
    }

    // ------------------------------------------------------------------ sync everything

    fun cancelSync() {
        syncJob?.cancel()
        _progress.value = _progress.value.copy(running = false, finished = true)
    }

    fun clearFinished() {
        if (!_progress.value.running) _progress.value = SyncProgress()
    }

    /**
     * Looks every song up online and saves the best confident match. Runs in the background, so it keeps going
     * if the screen is closed. [force] also re-checks songs that were already tagged.
     */
    fun syncAll(context: Context, songs: List<Song>, force: Boolean) {
        if (_progress.value.running) return
        val app = context.applicationContext
        val todo = songs.filter { force || !isTagged(it.id) }
        if (todo.isEmpty()) {
            _progress.value = SyncProgress(finished = true)
            return
        }
        _progress.value = SyncProgress(running = true, total = todo.size)
        syncJob = scope.launch {
            val gate = Semaphore(3)
            var done = 0
            var matched = 0
            var skipped = 0
            var wrote = 0
            try {
                coroutineScope {
                    for (song in todo) {
                        launch {
                            gate.withPermit {
                                if (!isActive) return@withPermit
                                val hit = try { TagLookup.best(song) } catch (_: Throwable) { null }
                                var ok = false
                                var fileOk = false
                                if (hit != null) {
                                    val art = TagLookup.fetchArt(app, hit.artUrl)
                                    val err = saveAndWrite(
                                        app, song,
                                        TagEdit(song.id, hit.title, hit.artist, hit.album, hit.year, art ?: "", true),
                                    )
                                    fileOk = err == null
                                    ok = true
                                }
                                synchronized(this@TagStore) {
                                    done++
                                    if (ok) matched++ else skipped++
                                    if (fileOk) wrote++
                                    _progress.value = SyncProgress(true, done, todo.size, matched, skipped, wrote)
                                }
                                delay(120)
                            }
                        }
                    }
                }
            } finally {
                _progress.value = SyncProgress(false, done, todo.size, matched, skipped, wrote, true)
            }
        }
    }
}
