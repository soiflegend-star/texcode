package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import java.util.Calendar

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 5 -> "Good night"
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

/**
 * Home — clean, premium layout: big greeting, one hero card, shortcut chips for every major
 * feature, quick picks, carousels, artists, playlists and the full feature catalogue.
 */
@Composable
fun RefHomeScreen(
    lib: LibraryState,
    player: PlayerState,
    userName: String = Ref.UserName,
    onPlay: (List<Song>, Int) -> Unit,
    onOpenNowPlaying: () -> Unit,
    onShuffle: () -> Unit,
    onSeeAll: () -> Unit,
    items: List<MoreItem> = emptyList(),
    onSearch: () -> Unit = {},
    onOpenMenu: () -> Unit = {},
    position: androidx.compose.runtime.State<Long>? = null,
    onToggle: () -> Unit = {},
    onNext: () -> Unit = {},
    onPrevious: () -> Unit = {},
    onOpenLyrics: () -> Unit = {},
    onMoveQueue: (Int, Int) -> Unit = { _, _ -> },
    onRemoveQueue: (Int) -> Unit = {},
    onClearQueue: () -> Unit = {},
) {
    val recent = remember(lib.songs, lib.recents) {
        val byId = lib.songs.associateBy { it.id }
        val r = lib.recents.mapNotNull { byId[it] }.distinctBy { it.id }
        (if (r.isEmpty()) lib.songs else r).take(12)
    }
    val mostPlayed = remember(lib.songs, lib.playCounts) {
        lib.songs.filter { (lib.playCounts[it.id] ?: 0) > 0 }
            .sortedByDescending { lib.playCounts[it.id] ?: 0 }
            .take(12)
    }
    val artists = remember(lib.songs, lib.playCounts) {
        lib.songs.groupBy { it.artist.ifBlank { "Unknown" } }.entries
            .sortedByDescending { e -> e.value.sumOf { lib.playCounts[it.id] ?: 0 } * 1000 + e.value.size }
            .take(12)
            .map { it.key to it.value }
    }
    val heroSong = player.current ?: recent.firstOrNull()
    val display = userName.trim().ifBlank { Ref.UserName }
    val grouped = remember(items) { items.groupBy { it.section.ifBlank { "MORE" } } }
    val shortcuts = remember(items) {
        val byLabel = items.associateBy { it.label.lowercase() }
        listOf("voice chat", "constellation", "alarms", "music editor", "equalizer", "earbuds", "phantom", "brains", "velocity")
            .mapNotNull { byLabel[it] }
    }

    Box(Modifier.fillMaxSize().background(Ref.Bg)) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(440.dp)
                .background(Brush.verticalGradient(listOf(Ref.Violet.copy(alpha = 0.30f), Color.Transparent))),
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
            // ---------------------------------------------------------------- header
            item {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(start = 22.dp, end = 14.dp, top = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            greeting().uppercase(), color = Ref.Muted, fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold, letterSpacing = 1.8.sp,
                        )
                        Text(
                            display, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.8).sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    GlassIconButton(Icons.Rounded.Search, onSearch, size = 44.dp)
                    Spacer(Modifier.width(8.dp))
                    GlassIconButton(Icons.Rounded.Shuffle, onShuffle, size = 44.dp)
                }
            }

            // ---------------------------------------------------------------- hero
            if (heroSong != null) {
                item {
                    val isCurrent = player.current?.id == heroSong.id
                    Box(
                        Modifier
                            .padding(horizontal = 20.dp, vertical = 20.dp)
                            .fillMaxWidth()
                            .height(236.dp)
                            .clip(RoundedCornerShape(30.dp))
                            .pressScale()
                            .clickable {
                                if (player.current != null) onOpenNowPlaying()
                                else onPlay(lib.songs, lib.songs.indexOfFirst { it.id == heroSong.id }.coerceAtLeast(0))
                            },
                    ) {
                        SongThumb(heroSong, Modifier.fillMaxSize(), RoundedCornerShape(0.dp))
                        Box(
                            Modifier.fillMaxSize().background(
                                Brush.verticalGradient(0.30f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.88f)),
                            ),
                        )
                        Column(Modifier.align(Alignment.BottomStart).padding(start = 22.dp, bottom = 22.dp, end = 90.dp)) {
                            Text(
                                if (player.current != null) "NOW PLAYING" else "JUMP BACK IN",
                                color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp,
                                fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                heroSong.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold,
                                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 29.sp,
                            )
                            Text(
                                heroSong.artist, color = Color.White.copy(alpha = 0.78f), fontSize = 14.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Box(
                            Modifier
                                .align(Alignment.BottomEnd)
                                .padding(end = 20.dp, bottom = 20.dp)
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                                .clickable {
                                    if (isCurrent) onToggle()
                                    else onPlay(lib.songs, lib.songs.indexOfFirst { it.id == heroSong.id }.coerceAtLeast(0))
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (isCurrent && player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                "Play", tint = Color.Black, modifier = Modifier.size(34.dp),
                            )
                        }
                    }
                }
            }

            if (player.current != null && position != null) {
                item {
                    com.texgen.music.texwave.ui.components.HyperMusicCard(
                        player = player,
                        position = position,
                        onToggle = onToggle,
                        onNext = onNext,
                        onPrevious = onPrevious,
                        onOpenLyrics = onOpenLyrics,
                        onMove = onMoveQueue,
                        onRemove = onRemoveQueue,
                        onClear = onClearQueue,
                        modifier = Modifier.padding(horizontal = 20.dp).padding(bottom = 6.dp),
                    )
                }
            }

            // ---------------------------------------------------------------- feature shortcuts
            if (shortcuts.isNotEmpty()) {
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(shortcuts.size, key = { shortcuts[it].label }) { i ->
                            val q = shortcuts[i]
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(50.dp))
                                    .background(Color.White.copy(alpha = 0.07f))
                                    .pressScale()
                                    .clickable(onClick = q.onClick)
                                    .padding(start = 8.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    Modifier.size(30.dp).clip(CircleShape).background(q.accent.copy(alpha = 0.20f)),
                                    contentAlignment = Alignment.Center,
                                ) { Icon(q.icon, null, tint = q.accent, modifier = Modifier.size(17.dp)) }
                                Spacer(Modifier.width(9.dp))
                                Text(q.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                            }
                        }
                    }
                }
            }

            // ---------------------------------------------------------------- quick picks
            if (recent.isNotEmpty()) {
                item { Spacer(Modifier.height(26.dp)) }
                item { SectionTitle("Quick picks", null) }
                item { Spacer(Modifier.height(12.dp)) }
                val pairs = recent.take(8).chunked(2)
                items(pairs.size, key = { "qp_$it" }) { r ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        pairs[r].forEach { s ->
                            Row(
                                Modifier
                                    .weight(1f)
                                    .height(58.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color.White.copy(alpha = 0.07f))
                                    .pressScale()
                                    .clickable { onPlay(recent, recent.indexOfFirst { it.id == s.id }.coerceAtLeast(0)) },
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                SongThumb(s, Modifier.size(58.dp), RoundedCornerShape(0.dp))
                                Text(
                                    s.title, color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 16.sp,
                                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
                                )
                            }
                        }
                        if (pairs[r].size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            // ---------------------------------------------------------------- carousels
            if (recent.isNotEmpty()) {
                item { Spacer(Modifier.height(28.dp)) }
                item { SectionTitle("Jump back in", "See all", onSeeAll) }
                item { Spacer(Modifier.height(12.dp)) }
                item { CoverRow(recent, onPlay) }
            }
            if (mostPlayed.isNotEmpty()) {
                item { Spacer(Modifier.height(28.dp)) }
                item { SectionTitle("Most played", null) }
                item { Spacer(Modifier.height(12.dp)) }
                item { CoverRow(mostPlayed, onPlay) }
            }
            if (artists.size > 1) {
                item { Spacer(Modifier.height(28.dp)) }
                item { SectionTitle("Your artists", null) }
                item { Spacer(Modifier.height(12.dp)) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        items(artists.size, key = { "ar_${artists[it].first}" }) { i ->
                            val (name, songs) = artists[i]
                            Column(
                                Modifier.width(92.dp).pressScale().clickable { onPlay(songs, 0) },
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                SongThumb(songs.firstOrNull(), Modifier.size(92.dp), CircleShape)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                                )
                            }
                        }
                    }
                }
            }

            // ---------------------------------------------------------------- playlists
            item { Spacer(Modifier.height(28.dp)) }
            item { SectionTitle("Your playlists", "See all", onSeeAll) }
            item { Spacer(Modifier.height(12.dp)) }
            item {
                val favSongs = remember(lib.songs, lib.liked) { lib.songs.filter { it.id in lib.liked } }
                Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PlaylistLine("Favourites", "${favSongs.size} songs", favSongs.firstOrNull() ?: recent.firstOrNull()) {
                        if (favSongs.isNotEmpty()) onPlay(favSongs, 0) else onSeeAll()
                    }
                    lib.playlists.take(3).forEach { p ->
                        val ps = lib.songs.filter { it.id in p.songIds }
                        PlaylistLine(p.name, "${ps.size} songs", ps.firstOrNull() ?: recent.firstOrNull()) {
                            if (ps.isNotEmpty()) onPlay(ps, 0) else onSeeAll()
                        }
                    }
                }
            }

            // ---------------------------------------------------------------- everything
            item { Spacer(Modifier.height(32.dp)) }
            item { SectionTitle("Everything in AUVYRR", "Menu", onOpenMenu) }
            grouped.forEach { (section, list) ->
                item(key = "h_$section") {
                    Text(
                        section, color = Ref.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp,
                        modifier = Modifier.padding(start = 22.dp, end = 20.dp, top = 20.dp, bottom = 8.dp),
                    )
                }
                val rows = list.chunked(2)
                items(rows.size, key = { "r_${section}_$it" }) { r ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        rows[r].forEach { it2 -> FeatureTile(it2, Modifier.weight(1f)) }
                        if (rows[r].size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun CoverRow(songs: List<Song>, onPlay: (List<Song>, Int) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            Column(Modifier.width(138.dp).pressScale().clickable { onPlay(songs, i) }) {
                SongThumb(s, Modifier.size(138.dp), RoundedCornerShape(20.dp))
                Spacer(Modifier.height(9.dp))
                Text(
                    s.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    s.artist, color = Ref.Muted, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun PlaylistLine(name: String, sub: String, art: Song?, onPlay: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .pressScale()
            .clickable(onClick = onPlay)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SongThumb(art, Modifier.size(54.dp), RoundedCornerShape(12.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(sub, color = Ref.Muted, fontSize = 12.sp)
        }
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(24.dp)) }
    }
}

@Composable
private fun FeatureTile(item: MoreItem, modifier: Modifier = Modifier) {
    Row(
        modifier
            .height(66.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .pressScale()
            .clickable(onClick = item.onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(item.accent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) { Icon(item.icon, null, tint = item.accent, modifier = Modifier.size(21.dp)) }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Center) {
            Text(
                item.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            if (item.subtitle.isNotBlank()) {
                Text(
                    item.subtitle, color = Ref.Muted, fontSize = 11.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
