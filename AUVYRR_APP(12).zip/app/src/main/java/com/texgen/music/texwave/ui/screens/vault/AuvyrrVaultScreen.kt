package com.texgen.music.texwave.ui.screens.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens

/**
 * AUVYRR VAULT
 *
 * Coherent local organization surface for user-owned / AUVYRR-created data.
 * Respects Android scoped storage. Does not claim cloud encryption unless wired.
 */
@Composable
fun AuvyrrVaultScreen(
    projectCount: Int = 0,
    musicExportCount: Int = 0,
    discoveryCount: Int = 0,
    backupCount: Int = 0,
    onOpenCategory: (VaultCategory) -> Unit = {},
    onSearch: (String) -> Unit = {},
    onExportAll: () -> Unit = {},
    onBack: () -> Unit = {},
) {
    var query by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(TexTokens.Bg)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = TexTokens.space20, vertical = TexTokens.space16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(TexTokens.Elevated.copy(alpha = 0.85f))
            ) {
                Icon(Icons.Rounded.ArrowBack, null, tint = TexTokens.TextPrimary, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "VAULT",
                    color = TexTokens.Violet,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
                Text(
                    "Your data, organized",
                    color = TexTokens.TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            IconButton(onClick = onExportAll) {
                Icon(Icons.Rounded.IosShare, null, tint = TexTokens.TextSecondary)
            }
        }

        // Search
        OutlinedTextField(
            value = query,
            onValueChange = {
                query = it
                onSearch(it)
            },
            placeholder = { Text("Search projects, exports, discoveries…", color = TexTokens.TextSecondary) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = TexTokens.TextSecondary) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = TexTokens.Violet,
                unfocusedBorderColor = TexTokens.Outline,
                focusedContainerColor = TexTokens.Surface,
                unfocusedContainerColor = TexTokens.Surface,
                cursorColor = TexTokens.Violet,
                focusedTextColor = TexTokens.TextPrimary,
                unfocusedTextColor = TexTokens.TextPrimary
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = TexTokens.space20)
        )

        Spacer(Modifier.height(16.dp))

        LazyColumn(
            contentPadding = PaddingValues(
                horizontal = TexTokens.space20,
                bottom = 100.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "CATEGORIES",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp
                )
            }

            items(VaultCategory.entries) { cat ->
                val count = when (cat) {
                    VaultCategory.Projects -> projectCount
                    VaultCategory.MusicExports -> musicExportCount
                    VaultCategory.Discoveries -> discoveryCount
                    VaultCategory.Backups -> backupCount
                    VaultCategory.Documents -> 0
                    VaultCategory.Automation -> 0
                }
                CategoryRow(cat, count) { onOpenCategory(cat) }
            }

            item {
                Text(
                    "QUICK ACCESS",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        QuickChip("Recent projects", Icons.Rounded.History) {
                            onOpenCategory(VaultCategory.Projects)
                        }
                    }
                    item {
                        QuickChip("Exports", Icons.Rounded.FileDownload) {
                            onOpenCategory(VaultCategory.MusicExports)
                        }
                    }
                    item {
                        QuickChip("Cosmic finds", Icons.Rounded.Public) {
                            onOpenCategory(VaultCategory.Discoveries)
                        }
                    }
                }
            }

            item {
                Text(
                    "All vault content stays in app-private storage unless you explicitly export. " +
                        "Backups and restores use Android-safe file APIs.",
                    color = TexTokens.TextSecondary.copy(0.7f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 16.dp, bottom = 24.dp)
                )
            }
        }
    }
}

enum class VaultCategory(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color
) {
    Projects("Projects", "Music & creative work", Icons.Rounded.Folder, TexTokens.Magenta),
    MusicExports("Music exports", "Rendered tracks & stems", Icons.Rounded.AudioFile, TexTokens.Cyan),
    Discoveries("Saved discoveries", "Cosmic & research notes", Icons.Rounded.Public, Color(0xFF6B8AFF)),
    Backups("Backups", "Configuration & automation", Icons.Rounded.Backup, TexTokens.Violet),
    Documents("Documents", "Notes & research", Icons.Rounded.Description, Color(0xFF3DFFB0)),
    Automation("Automation", "Veltrix flow backups", Icons.Rounded.AutoAwesome, Color(0xFFFFB020)),
}

@Composable
private fun CategoryRow(cat: VaultCategory, count: Int, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(TexTokens.Surface)
            .border(1.dp, TexTokens.Outline, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(cat.accent.copy(0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(cat.icon, null, tint = cat.accent, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(cat.title, color = TexTokens.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(cat.subtitle, color = TexTokens.TextSecondary, fontSize = 12.sp)
        }
        Text(
            if (count > 0) "$count" else "—",
            color = TexTokens.TextSecondary,
            fontSize = 14.sp
        )
        Spacer(Modifier.width(6.dp))
        Icon(Icons.Rounded.ChevronRight, null, tint = TexTokens.TextSecondary, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun QuickChip(label: String, icon: ImageVector, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(TexTokens.Elevated)
            .border(1.dp, TexTokens.Outline, RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = TexTokens.Cyan, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = TexTokens.TextPrimary, fontSize = 13.sp)
    }
}
