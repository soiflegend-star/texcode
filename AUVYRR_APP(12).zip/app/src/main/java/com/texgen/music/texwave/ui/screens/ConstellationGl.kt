package com.texgen.music.texwave.ui.screens

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import androidx.compose.ui.geometry.Offset
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** Camera that sits inside the sky. [travel] flies forward along the view direction (real parallax). */
class SkyCam {
    @Volatile var yaw = 0f
    @Volatile var pitch = 0.1f
    @Volatile var travel = 0f
    val fovYDeg = 62f

    fun fwd(out: FloatArray) {
        out[0] = sin(yaw) * cos(pitch)
        out[1] = sin(pitch)
        out[2] = -cos(yaw) * cos(pitch)
    }

    /** Fills [vp] (4x4) and the camera basis used by the nebula pass. */
    fun matrices(aspect: Float, vp: FloatArray, right: FloatArray, up: FloatArray, f: FloatArray) {
        fwd(f)
        val ex = f[0] * travel
        val ey = f[1] * travel
        val ez = f[2] * travel
        val view = FloatArray(16)
        val proj = FloatArray(16)
        Matrix.setLookAtM(view, 0, ex, ey, ez, ex + f[0], ey + f[1], ez + f[2], 0f, 1f, 0f)
        Matrix.perspectiveM(proj, 0, fovYDeg, aspect, 0.2f, 400f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        // right = normalize(fwd x worldUp), up = right x fwd
        var rx = f[1] * 0f - f[2] * 1f
        var ry = f[2] * 0f - f[0] * 0f
        var rz = f[0] * 1f - f[1] * 0f
        val rl = sqrt(rx * rx + ry * ry + rz * rz).coerceAtLeast(1e-5f)
        rx /= rl; ry /= rl; rz /= rl
        right[0] = rx; right[1] = ry; right[2] = rz
        up[0] = ry * f[2] - rz * f[1]
        up[1] = rz * f[0] - rx * f[2]
        up[2] = rx * f[1] - ry * f[0]
    }

    /** Screen position of a world point and its view depth, or null when it is behind the camera. */
    fun project(x: Float, y: Float, z: Float, w: Float, h: Float, out: FloatArray): Offset? {
        val vp = FloatArray(16)
        val r = FloatArray(3); val u = FloatArray(3); val f = FloatArray(3)
        matrices(if (h > 0f) w / h else 1f, vp, r, u, f)
        return projectWith(vp, x, y, z, w, h, out)
    }

    companion object {
        fun projectWith(vp: FloatArray, x: Float, y: Float, z: Float, w: Float, h: Float, depth: FloatArray): Offset? {
            val cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
            val cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
            val cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
            if (cw <= 0.05f) return null
            depth[0] = cw
            return Offset((cx / cw * 0.5f + 0.5f) * w, (1f - (cy / cw * 0.5f + 0.5f)) * h)
        }
    }
}

/** Packed scene: points = x,y,z,size,r,g,b,phase ; lines = x,y,z,r,g,b,a per vertex. */
class SkyData(val points: FloatArray, val pointCount: Int, val lines: FloatArray, val lineVertexCount: Int)

class ConstellationGlView(context: Context, private val cam: SkyCam) : GLSurfaceView(context) {
    private val renderer = SkyRenderer()
    @Volatile private var pending: SkyData? = null
    @Volatile private var nebula = floatArrayOf(0.45f, 0.30f, 0.95f, 0.10f, 0.65f, 0.80f, 0.75f, 0.62f, 1.0f)
    @Volatile private var nebulaDirty = true

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        preserveEGLContextOnPause = true
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun setSky(d: SkyData) { pending = d }

    fun setNebula(c1: FloatArray, c2: FloatArray, c3: FloatArray) {
        nebula = floatArrayOf(c1[0], c1[1], c1[2], c2[0], c2[1], c2[2], c3[0], c3[1], c3[2])
        nebulaDirty = true
    }

    private inner class SkyRenderer : Renderer {
        private var w = 1
        private var h = 1
        private var progPoints = 0
        private var progLines = 0
        private var progBake = 0
        private var progSky = 0
        private val bufs = IntArray(3)       // 0 points, 1 lines, 2 quad
        private var pointCount = 0
        private var lineCount = 0
        private var tex = 0
        private var fbo = 0
        private var nebulaOk = false
        private var maxPoint = 64f
        private val t0 = System.nanoTime()
        private val vp = FloatArray(16)
        private val right = FloatArray(3)
        private val up = FloatArray(3)
        private val fwd = FloatArray(3)

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
            GLES20.glDisable(GLES20.GL_CULL_FACE)
            val range = FloatArray(2)
            GLES20.glGetFloatv(GLES20.GL_ALIASED_POINT_SIZE_RANGE, range, 0)
            maxPoint = if (range[1] > 8f) range[1].coerceAtMost(180f) else 64f
            progPoints = program(POINT_VS, POINT_FS)
            progLines = program(LINE_VS, LINE_FS)
            progBake = program(QUAD_VS, BAKE_FS)
            progSky = program(QUAD_VS, SKY_FS)
            GLES20.glGenBuffers(3, bufs, 0)
            val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[2])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, quad.size * 4, fb(quad), GLES20.GL_STATIC_DRAW)
            pointCount = 0
            lineCount = 0
            nebulaOk = false
            nebulaDirty = true
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            tex = t[0]
            val f = IntArray(1)
            GLES20.glGenFramebuffers(1, f, 0)
            fbo = f[0]
            pending?.let { upload(it) }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            w = width.coerceAtLeast(1)
            h = height.coerceAtLeast(1)
            GLES20.glViewport(0, 0, w, h)
        }

        private fun fb(a: FloatArray): FloatBuffer =
            ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { it.put(a); it.position(0) }

        private fun upload(d: SkyData) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, d.pointCount * 8 * 4, fb(d.points.copyOf(d.pointCount * 8)), GLES20.GL_STATIC_DRAW)
            pointCount = d.pointCount
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[1])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, d.lineVertexCount * 7 * 4, fb(d.lines.copyOf(d.lineVertexCount * 7)), GLES20.GL_STATIC_DRAW)
            lineCount = d.lineVertexCount
        }

        private fun bakeNebula() {
            nebulaOk = false
            if (tex == 0 || fbo == 0 || progBake == 0) return
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, TEX_W, TEX_H, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex, 0)
            if (GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER) == GLES20.GL_FRAMEBUFFER_COMPLETE) {
                GLES20.glViewport(0, 0, TEX_W, TEX_H)
                GLES20.glDisable(GLES20.GL_BLEND)
                GLES20.glUseProgram(progBake)
                val n = nebula
                GLES20.glUniform3f(GLES20.glGetUniformLocation(progBake, "uC1"), n[0], n[1], n[2])
                GLES20.glUniform3f(GLES20.glGetUniformLocation(progBake, "uC2"), n[3], n[4], n[5])
                GLES20.glUniform3f(GLES20.glGetUniformLocation(progBake, "uC3"), n[6], n[7], n[8])
                drawQuad(progBake)
                nebulaOk = true
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glViewport(0, 0, w, h)
        }

        private fun drawQuad(prog: Int) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[2])
            val loc = GLES20.glGetAttribLocation(prog, "aPos")
            GLES20.glEnableVertexAttribArray(loc)
            GLES20.glVertexAttribPointer(loc, 2, GLES20.GL_FLOAT, false, 8, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(loc)
        }

        override fun onDrawFrame(gl: GL10?) {
            pending?.let { pending = null; upload(it) }
            if (nebulaDirty) { nebulaDirty = false; bakeNebula() }

            GLES20.glClearColor(0.012f, 0.012f, 0.03f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            val time = (System.nanoTime() - t0) / 1e9f
            cam.matrices(w.toFloat() / h.toFloat(), vp, right, up, fwd)

            // 1) nebula + galactic band (baked once, sampled per pixel)
            if (nebulaOk && progSky != 0) {
                GLES20.glDisable(GLES20.GL_BLEND)
                GLES20.glUseProgram(progSky)
                val th = tan(Math.toRadians(cam.fovYDeg / 2.0)).toFloat()
                GLES20.glUniform3f(GLES20.glGetUniformLocation(progSky, "uRight"), right[0], right[1], right[2])
                GLES20.glUniform3f(GLES20.glGetUniformLocation(progSky, "uUp"), up[0], up[1], up[2])
                GLES20.glUniform3f(GLES20.glGetUniformLocation(progSky, "uFwd"), fwd[0], fwd[1], fwd[2])
                GLES20.glUniform2f(GLES20.glGetUniformLocation(progSky, "uTan"), th * w / h, th)
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
                GLES20.glUniform1i(GLES20.glGetUniformLocation(progSky, "uTex"), 0)
                drawQuad(progSky)
            }

            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE)

            // 2) constellation lines
            if (lineCount > 0 && progLines != 0) {
                GLES20.glUseProgram(progLines)
                GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(progLines, "uVP"), 1, false, vp, 0)
                GLES20.glLineWidth(2f)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[1])
                val aPos = GLES20.glGetAttribLocation(progLines, "aPos")
                val aCol = GLES20.glGetAttribLocation(progLines, "aColor")
                GLES20.glEnableVertexAttribArray(aPos)
                GLES20.glEnableVertexAttribArray(aCol)
                GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 28, 0)
                GLES20.glVertexAttribPointer(aCol, 4, GLES20.GL_FLOAT, false, 28, 12)
                GLES20.glDrawArrays(GLES20.GL_LINES, 0, lineCount)
                GLES20.glDisableVertexAttribArray(aPos)
                GLES20.glDisableVertexAttribArray(aCol)
            }

            // 3) stars
            if (pointCount > 0 && progPoints != 0) {
                GLES20.glUseProgram(progPoints)
                GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(progPoints, "uVP"), 1, false, vp, 0)
                GLES20.glUniform1f(GLES20.glGetUniformLocation(progPoints, "uScale"), h * 0.35f)
                GLES20.glUniform1f(GLES20.glGetUniformLocation(progPoints, "uMaxPt"), maxPoint)
                GLES20.glUniform1f(GLES20.glGetUniformLocation(progPoints, "uTime"), time)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bufs[0])
                val aPos = GLES20.glGetAttribLocation(progPoints, "aPos")
                val aSize = GLES20.glGetAttribLocation(progPoints, "aSize")
                val aCol = GLES20.glGetAttribLocation(progPoints, "aColor")
                val aPh = GLES20.glGetAttribLocation(progPoints, "aPhase")
                GLES20.glEnableVertexAttribArray(aPos)
                GLES20.glEnableVertexAttribArray(aSize)
                GLES20.glEnableVertexAttribArray(aCol)
                GLES20.glEnableVertexAttribArray(aPh)
                GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 32, 0)
                GLES20.glVertexAttribPointer(aSize, 1, GLES20.GL_FLOAT, false, 32, 12)
                GLES20.glVertexAttribPointer(aCol, 3, GLES20.GL_FLOAT, false, 32, 16)
                GLES20.glVertexAttribPointer(aPh, 1, GLES20.GL_FLOAT, false, 32, 28)
                GLES20.glDrawArrays(GLES20.GL_POINTS, 0, pointCount)
                GLES20.glDisableVertexAttribArray(aPos)
                GLES20.glDisableVertexAttribArray(aSize)
                GLES20.glDisableVertexAttribArray(aCol)
                GLES20.glDisableVertexAttribArray(aPh)
            }
        }

        private fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) { GLES20.glDeleteShader(s); return 0 }
            return s
        }

        /** Returns 0 on any failure so the screen degrades instead of crashing. */
        private fun program(vs: String, fs: String): Int {
            val v = shader(GLES20.GL_VERTEX_SHADER, vs)
            val f = shader(GLES20.GL_FRAGMENT_SHADER, fs)
            if (v == 0 || f == 0) return 0
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, v)
            GLES20.glAttachShader(p, f)
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            return if (ok[0] == 0) 0 else p
        }
    }

    companion object {
        private const val TEX_W = 1024
        private const val TEX_H = 512

        private const val POINT_VS = """
uniform mat4 uVP;
uniform float uScale;
uniform float uMaxPt;
uniform float uTime;
attribute vec3 aPos;
attribute float aSize;
attribute vec3 aColor;
attribute float aPhase;
varying vec3 vColor;
varying float vSpike;
varying float vA;
varying float vSmall;
void main() {
    vec4 p = uVP * vec4(aPos, 1.0);
    gl_Position = p;
    float tw = 0.86 + 0.14 * sin(uTime * 1.8 + aPhase * 6.2831);
    float ps = aSize * uScale / max(p.w, 0.5) * tw;
    vSpike = clamp((ps - 22.0) / 40.0, 0.0, 1.0);
    vA = clamp(ps / 1.8, 0.0, 1.0);
    vSmall = 1.0 - clamp((ps - 1.6) / 5.0, 0.0, 1.0);
    gl_PointSize = clamp(ps, 1.6, uMaxPt);
    vColor = aColor;
}
"""
        private const val POINT_FS = """
precision mediump float;
varying vec3 vColor;
varying float vSpike;
varying float vA;
varying float vSmall;
void main() {
    vec2 q = (gl_PointCoord - 0.5) * 2.0;
    float d = length(q);
    if (d > 1.0) discard;
    float core = exp(-d * d * 16.0);
    float halo = exp(-d * 3.4) * 0.42 * (1.0 - d);
    float sp = (exp(-abs(q.x) * 46.0) * exp(-abs(q.y) * 3.2) + exp(-abs(q.y) * 46.0) * exp(-abs(q.x) * 3.2)) * 0.75 * vSpike;
    float disc = vSmall * (1.0 - d * d * 0.5);
    vec3 c = vColor * (core * 0.6 + halo + sp + disc * 0.9) + vec3(1.0) * (core * 0.7 + disc * 0.25);
    gl_FragColor = vec4(c * vA, 1.0);
}
"""
        private const val LINE_VS = """
uniform mat4 uVP;
attribute vec3 aPos;
attribute vec4 aColor;
varying vec4 vColor;
void main() {
    gl_Position = uVP * vec4(aPos, 1.0);
    vColor = aColor;
}
"""
        private const val LINE_FS = """
precision mediump float;
varying vec4 vColor;
void main() {
    gl_FragColor = vec4(vColor.rgb * vColor.a, 1.0);
}
"""
        private const val QUAD_VS = """
attribute vec2 aPos;
varying vec2 vUv;
void main() {
    vUv = aPos;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""
        private const val BAKE_FS = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUv;
uniform vec3 uC1;
uniform vec3 uC2;
uniform vec3 uC3;
float hash(vec3 p) {
    p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}
float noise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
        mix(mix(hash(i), hash(i + vec3(1.0, 0.0, 0.0)), f.x), mix(hash(i + vec3(0.0, 1.0, 0.0)), hash(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
        mix(mix(hash(i + vec3(0.0, 0.0, 1.0)), hash(i + vec3(1.0, 0.0, 1.0)), f.x), mix(hash(i + vec3(0.0, 1.0, 1.0)), hash(i + vec3(1.0, 1.0, 1.0)), f.x), f.y),
        f.z);
}
float fbm(vec3 p) {
    float a = 0.5;
    float s = 0.0;
    for (int i = 0; i < 5; i++) {
        s += a * noise(p);
        p = p * 2.03 + vec3(1.7, 9.2, 3.1);
        a *= 0.5;
    }
    return s;
}
void main() {
    float lon = vUv.x * 3.14159265;
    float lat = vUv.y * 1.5707963;
    vec3 dir = vec3(cos(lat) * sin(lon), sin(lat), -cos(lat) * cos(lon));
    float n1 = fbm(dir * 2.2);
    float n2 = fbm(dir * 4.6 + 7.0);
    float dust = smoothstep(0.35, 0.8, fbm(dir * 7.0 + 3.0));
    float bandD = dot(dir, normalize(vec3(0.35, 0.82, 0.45)));
    float band = exp(-bandD * bandD * 9.0);
    float core = exp(-bandD * bandD * 60.0);
    vec3 col = uC1 * smoothstep(0.38, 0.85, n1) * 0.50
             + uC2 * smoothstep(0.42, 0.90, n2) * 0.36
             + uC3 * band * (0.30 + 0.70 * n1) * 0.50 * (1.0 - 0.65 * dust)
             + vec3(1.0, 0.92, 0.85) * core * (0.10 + 0.25 * n2) * (1.0 - 0.7 * dust);
    gl_FragColor = vec4(col, 1.0);
}
"""
        private const val SKY_FS = """
precision mediump float;
varying vec2 vUv;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec3 uFwd;
uniform vec2 uTan;
uniform sampler2D uTex;
void main() {
    vec3 dir = normalize(uFwd + vUv.x * uTan.x * uRight + vUv.y * uTan.y * uUp);
    float u = atan(dir.x, -dir.z) / 6.2831853 + 0.5;
    float v = asin(clamp(dir.y, -1.0, 1.0)) / 3.14159265 + 0.5;
    gl_FragColor = vec4(texture2D(uTex, vec2(u, v)).rgb * 0.62, 1.0);
}
"""
    }
}
