package com.texgen.music.texwave.ui.screens.lab

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens

/**
 * AUVYRR LAB
 *
 * Explicitly experimental / research environment.
 * Isolated from stable production paths.
 * All entries are clearly labeled.
 */
@Composable
fun AuvyrrLabScreen(
    onOpenProtocolExperiments: () -> Unit = {},
    onOpenDeviceDiagnostics: () -> Unit = {},
    onOpenPerformance: () -> Unit = {},
    onOpenAiExperiments: () -> Unit = {},
    onOpenLogs: () -> Unit = {},
    onBack: () -> Unit = {},
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(TexTokens.Bg)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = TexTokens.space20, vertical = TexTokens.space16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(TexTokens.Elevated.copy(alpha = 0.85f))
            ) {
                Icon(Icons.Rounded.ArrowBack, null, tint = TexTokens.TextPrimary, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "LAB",
                    color = Color(0xFFFFB020),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
                Text(
                    "Experimental zone",
                    color = TexTokens.TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Warning banner
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = TexTokens.space20)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFFFB020).copy(0.1f))
                .border(1.dp, Color(0xFFFFB020).copy(0.3f), RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Rounded.Warning, null, tint = Color(0xFFFFB020), modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    "Everything here is experimental. Features may be unstable, incomplete, or change without notice. Do not rely on Lab systems for production use.",
                    color = TexTokens.TextPrimary,
                    fontSize = 13.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        LazyColumn(
            contentPadding = PaddingValues(
                horizontal = TexTokens.space20,
                bottom = 100.dp
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    "EXPERIMENT AREAS",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp
                )
            }

            item {
                LabEntry(
                    icon = Icons.Rounded.BluetoothSearching,
                    title = "Protocol experiments",
                    subtitle = "Safe command testing, adapter research",
                    tag = "EXPERIMENTAL",
                    onClick = onOpenProtocolExperiments
                )
            }
            item {
                LabEntry(
                    icon = Icons.Rounded.BugReport,
                    title = "Device diagnostics",
                    subtitle = "Transport logs, capability probes",
                    tag = "EXPERIMENTAL",
                    onClick = onOpenDeviceDiagnostics
                )
            }
            item {
                LabEntry(
                    icon = Icons.Rounded.Speed,
                    title = "Performance bench",
                    subtitle = "Frame timing, memory, list scroll cost",
                    tag = "EXPERIMENTAL",
                    onClick = onOpenPerformance
                )
            }
            item {
                LabEntry(
                    icon = Icons.Rounded.Psychology,
                    title = "AI experiments",
                    subtitle = "Offline / on-device assistant probes",
                    tag = "EXPERIMENTAL",
                    onClick = onOpenAiExperiments
                )
            }
            item {
                LabEntry(
                    icon = Icons.Rounded.Article,
                    title = "Logs & traces",
                    subtitle = "Session logs, verification reports",
                    tag = "DEV",
                    onClick = onOpenLogs
                )
            }

            item {
                Text(
                    "Lab entries are isolated from the main navigation graph where possible. " +
                        "Stable product features live outside this screen.",
                    color = TexTokens.TextSecondary.copy(0.7f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 16.dp, bottom = 24.dp)
                )
            }
        }
    }
}

@Composable
private fun LabEntry(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tag: String,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(TexTokens.Surface)
            .border(1.dp, TexTokens.Outline, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFFFB020).copy(0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Color(0xFFFFB020), modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = TexTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(8.dp))
                Text(
                    tag,
                    color = Color(0xFFFFB020),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFFFB020).copy(0.15f))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                )
            }
            Text(subtitle, color = TexTokens.TextSecondary, fontSize = 12.sp)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = TexTokens.TextSecondary, modifier = Modifier.size(18.dp))
    }
}
