package com.texgen.music.texwave.notification

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import androidx.core.graphics.ColorUtils
import com.texgen.music.texwave.data.AppSettings
import kotlin.math.abs
import kotlin.math.sin

/** What the user chose in the Notification screen. */
data class GlassConfig(
    val enabled: Boolean = true,
    /** 0..100 how soft the blurred picture behind the card is. */
    val blur: Int = 70,
    /** 0..100 how strong the frosted layer is. */
    val frost: Int = 38,
    /** 0 = from the cover, 1 = app theme, 2 = dark smoke, 3 = light frost. */
    val tint: Int = 0,
    /** Show the sharp cover picture on top of the glass. */
    val showPic: Boolean = true,
)

object NotifGlassPrefs {
    private const val K_ON = "ng_enabled"
    private const val K_BLUR = "ng_blur"
    private const val K_FROST = "ng_frost"
    private const val K_TINT = "ng_tint"
    private const val K_PIC = "ng_pic"

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(AppSettings.PREFS_NAME, Context.MODE_PRIVATE)

    fun load(c: Context): GlassConfig {
        val p = prefs(c)
        return GlassConfig(
            enabled = p.getBoolean(K_ON, true),
            blur = p.getInt(K_BLUR, 70).coerceIn(0, 100),
            frost = p.getInt(K_FROST, 38).coerceIn(0, 100),
            tint = p.getInt(K_TINT, 0).coerceIn(0, 3),
            showPic = p.getBoolean(K_PIC, true),
        )
    }

    fun save(c: Context, g: GlassConfig) {
        prefs(c).edit()
            .putBoolean(K_ON, g.enabled)
            .putInt(K_BLUR, g.blur)
            .putInt(K_FROST, g.frost)
            .putInt(K_TINT, g.tint)
            .putBoolean(K_PIC, g.showPic)
            .apply()
    }
}

/**
 * Frosted-glass artwork for notifications: the cover is blurred into a soft glow, a frosted layer
 * and light reflections sit on top, and the sharp cover picture floats in the middle. Several
 * looks ([STYLES]) add their own light effect on top (aurora, bokeh, prism, neon rim, ice shine…).
 */
object NotifGlassArt {
    val STYLES: Set<String> = setOf(
        "glass", "glass_liquid", "glass_aurora", "glass_neon", "glass_ice", "glass_smoke", "glass_bokeh", "glass_prism",
    )

    // ---------------------------------------------------------------- blur

    private var blurSrc: Bitmap? = null
    private var blurAmount = -1
    private var blurOut: Bitmap? = null

    /** Soft blur of [src]: shrink hard, box-blur the tiny copy, scale back up smoothly. */
    @Synchronized
    fun blurred(src: Bitmap, amount: Int): Bitmap {
        val a = amount.coerceIn(0, 100)
        val cached = blurOut
        if (src === blurSrc && a == blurAmount && cached != null && !cached.isRecycled) return cached
        val tinySide = (56 - a * 0.46f).toInt().coerceAtLeast(8)
        val tiny = Bitmap.createScaledBitmap(src, tinySide, tinySide, true)
        val soft = boxBlur(tiny, 1 + a / 35)
        val side = src.width.coerceAtLeast(96)
        val mid = Bitmap.createScaledBitmap(soft, side / 3, side / 3, true)
        val out = Bitmap.createScaledBitmap(mid, side, side, true)
        blurSrc = src
        blurAmount = a
        blurOut = out
        return out
    }

    private fun boxBlur(src: Bitmap, r: Int): Bitmap {
        val w = src.width
        val h = src.height
        val a = IntArray(w * h)
        src.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h)
        pass(a, b, w, h, r, true)
        pass(b, a, w, h, r, false)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }

    private fun pass(inp: IntArray, out: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        for (l in 0 until lines) {
            for (i in 0 until len) {
                var sa = 0
                var sr = 0
                var sg = 0
                var sb = 0
                var n = 0
                for (k in -r..r) {
                    val j = i + k
                    if (j < 0 || j >= len) continue
                    val p = inp[if (horizontal) l * w + j else j * w + l]
                    sa += p ushr 24
                    sr += (p shr 16) and 255
                    sg += (p shr 8) and 255
                    sb += p and 255
                    n++
                }
                out[if (horizontal) l * w + i else i * w + l] =
                    ((sa / n) shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
            }
        }
    }

    // ---------------------------------------------------------------- colours

    private fun averageColor(bmp: Bitmap?, fallback: Int): Int {
        if (bmp == null) return fallback
        val tiny = Bitmap.createScaledBitmap(bmp, 1, 1, true)
        val px = tiny.getPixel(0, 0)
        if (tiny !== bmp) tiny.recycle()
        return px or Color.BLACK
    }

    /** The tint laid over the blurred picture (its alpha is the frost strength). Same for preview and real card. */
    fun tintColor(g: GlassConfig, accent: Int, base: Bitmap?): Int {
        val alpha = (40 + g.frost * 1.55f).toInt().coerceIn(30, 235)
        val color = when (g.tint) {
            1 -> ColorUtils.blendARGB(accent or Color.BLACK, Color.BLACK, 0.55f)
            2 -> 0xFF0A0B10.toInt()
            3 -> 0xFFF2F4FA.toInt()
            else -> ColorUtils.blendARGB(averageColor(base, accent), Color.BLACK, 0.45f)
        }
        return ColorUtils.setAlphaComponent(color, if (g.tint == 3) (alpha * 0.8f).toInt() else alpha)
    }

    fun isLight(g: GlassConfig) = g.tint == 3

    // ---------------------------------------------------------------- rounded pictures

    private fun gradientFor(seed: String, accent: Int, accent2: Int, s: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val hue = (abs(seed.hashCode()) % 360).toFloat()
        val c1 = if (seed.isBlank()) accent else Color.HSVToColor(floatArrayOf(hue, 0.6f, 0.9f))
        val c2 = if (seed.isBlank()) accent2 else Color.HSVToColor(floatArrayOf((hue + 50f) % 360f, 0.8f, 0.5f))
        p.shader = LinearGradient(0f, 0f, s, s, c1, c2, Shader.TileMode.CLAMP)
        return p
    }

    /** [src] (or a gradient) as a [px]-sized square with rounded corners and transparent outside. */
    fun roundedPicture(src: Bitmap?, px: Int, radiusFrac: Float, seed: String, accent: Int, accent2: Int): Bitmap {
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val s = px.toFloat()
        val r = s * radiusFrac
        val mask = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawRoundRect(RectF(0f, 0f, s, s), r, r, mask)
        mask.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        if (src != null) {
            c.drawBitmap(src, null, RectF(0f, 0f, s, s), mask)
        } else {
            val g = gradientFor(seed, accent, accent2, s)
            g.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            c.drawRect(0f, 0f, s, s, g)
        }
        return out
    }

    // ---------------------------------------------------------------- the artwork

    private fun rnd(i: Int, salt: Int): Float {
        var x = i * 374761393 + salt * 668265263
        x = (x xor (x ushr 13)) * 1274126177
        x = x xor (x ushr 16)
        return (x and 0xFFFFFF) / 16777215f
    }

    fun render(
        size: Int,
        style: String,
        frame: Int,
        base: Bitmap?,
        seed: String,
        accent: Int,
        accent2: Int,
        blur: Int,
        frost: Int,
        showPic: Boolean = true,
    ): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size.toFloat()
        val t = frame * 0.7f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // 1. soft blurred picture
        if (base != null) {
            c.drawBitmap(blurred(base, blur), null, RectF(0f, 0f, s, s), p)
        } else {
            c.drawRect(0f, 0f, s, s, gradientFor(seed, accent, accent2, s))
        }

        // 2. base tone of the glass
        val toneAlpha = when (style) {
            "glass_smoke" -> 0x88
            "glass_neon" -> 0x99
            "glass_ice" -> 0x10
            else -> 0x38
        }
        p.reset()
        p.color = ColorUtils.setAlphaComponent(if (style == "glass_ice") 0xFFBFE4FF.toInt() else Color.BLACK, toneAlpha)
        c.drawRect(0f, 0f, s, s, p)

        // 3. the look's own light effect
        when (style) {
            "glass_aurora" -> aurora(c, s, t, accent, accent2)
            "glass_bokeh" -> bokeh(c, s, t, accent, accent2)
            "glass_prism" -> prism(c, s, t)
            "glass_ice" -> streak(c, s, t)
            "glass_liquid" -> blobs(c, s, t, accent, accent2)
            "glass_neon" -> blobs(c, s, t * 0.6f, accent, accent2)
        }

        // 4. frosted layer + reflections
        val frostAlpha = (frost * 0.9f).toInt().coerceIn(0, 110) + if (style == "glass_ice") 36 else 0
        p.reset()
        p.color = ColorUtils.setAlphaComponent(Color.WHITE, frostAlpha.coerceIn(0, 150))
        c.drawRect(0f, 0f, s, s, p)
        p.reset()
        p.shader = LinearGradient(0f, 0f, 0f, s * 0.5f, 0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s * 0.5f, p)
        p.reset()
        p.color = 0x1AFFFFFF
        val gloss = Path().apply {
            moveTo(0f, 0f); lineTo(s * 0.62f, 0f); lineTo(0f, s * 0.62f); close()
        }
        c.drawPath(gloss, p)

        // 5. rim light
        val rim = Paint(Paint.ANTI_ALIAS_FLAG)
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = s * 0.012f
        if (style == "glass_neon") {
            val pulse = 0.65f + 0.35f * sin(t * 1.4f)
            val sweep = SweepGradient(s / 2f, s / 2f, intArrayOf(accent, accent2, accent), null)
            val m = android.graphics.Matrix().apply { postRotate(t * 24f, s / 2f, s / 2f) }
            sweep.setLocalMatrix(m)
            val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.style = Paint.Style.STROKE
                strokeWidth = s * 0.03f
                shader = sweep
                alpha = (200 * pulse).toInt()
                maskFilter = BlurMaskFilter(s * 0.03f, BlurMaskFilter.Blur.NORMAL)
            }
            c.drawRoundRect(RectF(s * 0.02f, s * 0.02f, s * 0.98f, s * 0.98f), s * 0.07f, s * 0.07f, glow)
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.style = Paint.Style.STROKE
                strokeWidth = s * 0.008f
                shader = sweep
            }
            c.drawRoundRect(RectF(s * 0.02f, s * 0.02f, s * 0.98f, s * 0.98f), s * 0.07f, s * 0.07f, line)
        } else {
            rim.shader = LinearGradient(0f, 0f, s, s, 0xAAFFFFFF.toInt(), 0x22FFFFFF, Shader.TileMode.CLAMP)
            c.drawRoundRect(RectF(s * 0.006f, s * 0.006f, s * 0.994f, s * 0.994f), s * 0.04f, s * 0.04f, rim)
        }

        // 6. the sharp cover picture, floating
        if (showPic) {
            val side = s * 0.58f
            val left = (s - side) / 2f
            val top = (s - side) / 2f - s * 0.015f
            val rad = side * 0.15f
            val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x88000000.toInt()
                maskFilter = BlurMaskFilter(s * 0.05f, BlurMaskFilter.Blur.NORMAL)
            }
            c.drawRoundRect(RectF(left, top + s * 0.03f, left + side, top + side + s * 0.03f), rad, rad, shadow)
            val pic = roundedPicture(base, side.toInt().coerceAtLeast(16), 0.15f, seed, accent, accent2)
            c.drawBitmap(pic, left, top, null)
            pic.recycle()
            val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(left, top, left + side, top + side, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
            }
            c.drawRoundRect(RectF(left, top, left + side, top + side), rad, rad, sheen)
            val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.style = Paint.Style.STROKE
                strokeWidth = s * 0.006f
                color = 0xA8FFFFFF.toInt()
            }
            c.drawRoundRect(RectF(left, top, left + side, top + side), rad, rad, edge)
        }
        return bmp
    }

    // ---------------------------------------------------------------- effects

    private fun aurora(c: Canvas, s: Float, t: Float, a1: Int, a2: Int) {
        for (i in 0 until 3) {
            val path = Path()
            val baseY = s * (0.28f + 0.2f * i)
            var x = 0f
            path.moveTo(0f, baseY)
            while (x <= s) {
                val y = baseY + sin(x / s * 6.283f * 1.3f + t * 0.8f + i * 2f) * s * 0.07f
                path.lineTo(x, y)
                x += s / 24f
            }
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = s * 0.11f
                shader = LinearGradient(0f, 0f, s, 0f, ColorUtils.setAlphaComponent(a1, 0x66), ColorUtils.setAlphaComponent(a2, 0x66), Shader.TileMode.CLAMP)
                maskFilter = BlurMaskFilter(s * 0.045f, BlurMaskFilter.Blur.NORMAL)
            }
            c.drawPath(path, p)
        }
    }

    private fun bokeh(c: Canvas, s: Float, t: Float, a1: Int, a2: Int) {
        for (i in 0 until 14) {
            val r = s * (0.03f + 0.06f * rnd(i, 1))
            val x = rnd(i, 2) * s
            val speed = 0.012f + 0.02f * rnd(i, 3)
            var y = (rnd(i, 4) * s - t * s * speed) % s
            if (y < 0) y += s
            val col = ColorUtils.blendARGB(Color.WHITE, if (i % 2 == 0) a1 else a2, 0.45f)
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ColorUtils.setAlphaComponent(col, 0x30) }
            c.drawCircle(x, y, r, fill)
            val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = s * 0.004f
                color = ColorUtils.setAlphaComponent(col, 0x66)
            }
            c.drawCircle(x, y, r, ring)
        }
    }

    private fun prism(c: Canvas, s: Float, t: Float) {
        c.save()
        c.rotate(-24f, s / 2f, s / 2f)
        val w = s * 0.34f
        val x = ((t * 0.045f) % 1.7f - 0.35f) * s
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                x, 0f, x + w, 0f,
                intArrayOf(0x00FF3B3B, 0x55FFC83B, 0x5560FF6B, 0x553BD4FF, 0x558B5CFF, 0x00FF58D8),
                null, Shader.TileMode.CLAMP,
            )
        }
        c.drawRect(x, -s * 0.3f, x + w, s * 1.3f, p)
        c.restore()
    }

    private fun streak(c: Canvas, s: Float, t: Float) {
        c.save()
        c.rotate(-24f, s / 2f, s / 2f)
        val w = s * 0.16f
        val x = ((t * 0.05f) % 1.8f - 0.4f) * s
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(x, 0f, x + w, 0f, intArrayOf(0x00FFFFFF, 0x99FFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        }
        c.drawRect(x, -s * 0.3f, x + w, s * 1.3f, p)
        c.restore()
    }

    private fun blobs(c: Canvas, s: Float, t: Float, a1: Int, a2: Int) {
        for (i in 0 until 3) {
            val cx = s * (0.5f + 0.34f * sin(t * 0.5f + i * 2.1f))
            val cy = s * (0.5f + 0.34f * sin(t * 0.37f + i * 1.7f + 1f))
            val r = s * 0.46f
            val col = if (i % 2 == 0) a1 else a2
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(cx, cy, r, ColorUtils.setAlphaComponent(col, 0x77), ColorUtils.setAlphaComponent(col, 0), Shader.TileMode.CLAMP)
            }
            c.drawCircle(cx, cy, r, p)
        }
    }
}
