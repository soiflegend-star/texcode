package com.texgen.music.texwave.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color as AColor
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader

private const val QUBRIX_HOST = "appassets.androidplatform.net"
private const val QUBRIX_URL = "https://$QUBRIX_HOST/qubrix/index.html"

/**
 * QUBRIX — the learning, practice, tests and revision app, running fully offline inside AUVYRR.
 * Its files are bundled in assets/qubrix and served through WebViewAssetLoader; progress is kept
 * in the WebView's own storage, on this phone only.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun QubrixScreen(onClose: () -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }

    BackHandler {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else onClose()
    }
    DisposableEffect(Unit) {
        onDispose {
            web?.let {
                it.stopLoading()
                it.destroy()
            }
            web = null
        }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize().background(Color(0xFF070817)).statusBarsPadding(),
        factory = { ctx ->
            val loader = WebViewAssetLoader.Builder()
                .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(ctx))
                .build()
            WebView(ctx).apply {
                setBackgroundColor(AColor.parseColor("#070817"))
                overScrollMode = WebView.OVER_SCROLL_NEVER
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                        loader.shouldInterceptRequest(request.url)

                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        if (request.url.host == QUBRIX_HOST) return false
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(request.url.toString())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Throwable) {
                        }
                        return true
                    }
                }
                loadUrl(QUBRIX_URL)
                web = this
            }
        },
    )
}
