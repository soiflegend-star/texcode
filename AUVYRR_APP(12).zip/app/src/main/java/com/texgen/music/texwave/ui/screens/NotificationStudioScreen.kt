package com.texgen.music.texwave.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.NotifCatalog
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.ThemeCatalog
import com.texgen.music.texwave.notification.GlassConfig
import com.texgen.music.texwave.notification.NotifArtRenderer
import com.texgen.music.texwave.notification.NotifGlassArt
import com.texgen.music.texwave.notification.NotifGlassPrefs
import com.texgen.music.texwave.notification.NotifMedia
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * "Notification" — design how the AUVYRR player notification looks: pick a look, then shape the
 * frosted glass (blur, frost, tint, cover picture). The card above is drawn from exactly the
 * same numbers the real notification uses, and every change reaches the live notification at once.
 */
@Composable
fun NotificationStudioScreen(
    song: Song?,
    themeId: String,
    styleId: String,
    onSelectStyle: (String) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val theme = ThemeCatalog.byId(themeId)
    val accent = theme.primary.toInt()
    val accent2 = theme.secondary.toInt()
    var g by remember { mutableStateOf(NotifGlassPrefs.load(context)) }
    var expanded by remember { mutableStateOf(true) }

    fun commit(next: GlassConfig) {
        g = next
        NotifGlassPrefs.save(context, next)
    }

    val base by produceState<Bitmap?>(null, song?.id) {
        value = withContext(Dispatchers.IO) {
            if (song == null) null
            else try {
                NotifMedia.loadSongArt(context, song.contentUri, song.albumId, 384, song.artOverride)
            } catch (_: Throwable) {
                null
            }
        }
    }
    val title = song?.title ?: "Midnight Drive"
    val artist = song?.artist ?: "Neon Valley"
    val styleNow = NotifCatalog.byId(styleId)

    Column(Modifier.fillMaxSize().background(Tx.Bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Tx.Text) }
            Column(Modifier.weight(1f)) {
                Text("Notification", color = Tx.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Design how your player notification looks", color = Tx.Muted, fontSize = 12.sp)
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        ) {
            // ---------------------------------------------------------------- live preview
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF1B1F2E), Color(0xFF0C0E16))))
                    .padding(14.dp),
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("PREVIEW", color = Tx.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, modifier = Modifier.weight(1f))
                        ModeChip("Compact", !expanded) { expanded = false }
                        Spacer(Modifier.width(6.dp))
                        ModeChip("Expanded", expanded) { expanded = true }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (g.enabled) {
                        GlassCardPreview(g, base, title, artist, accent, accent2, styleId, expanded)
                    } else {
                        PlainCardPreview(title, artist, expanded)
                    }
                }
            }

            // ---------------------------------------------------------------- looks
            SectionLabel("GLASS LOOKS")
            val glassLooks = remember { NotifCatalog.all.filter { it.id in NotifGlassArt.STYLES } }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(end = 8.dp)) {
                items(glassLooks, key = { it.id }) { st ->
                    LookTile(st.id, st.name, st.id == styleId, base, accent, accent2, g) { onSelectStyle(st.id) }
                }
            }
            SectionLabel("OTHER LOOKS")
            val otherLooks = remember { NotifCatalog.all.filter { it.id !in NotifGlassArt.STYLES && it.id != "custom" && it.id != "video" } }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(end = 8.dp)) {
                items(otherLooks, key = { it.id }) { st ->
                    LookTile(st.id, st.name, st.id == styleId, base, accent, accent2, g) { onSelectStyle(st.id) }
                }
            }
            Text(
                "Now: ${styleNow.name} — ${styleNow.description}",
                color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp),
            )

            // ---------------------------------------------------------------- glass controls
            SectionLabel("GLASS")
            ToggleRow("Frosted glass card", "A blurred, see-through card with your cover glowing behind it", g.enabled) { commit(g.copy(enabled = it)) }
            if (g.enabled) {
                ToggleRow("Show cover picture", "Keep the sharp cover visible on top of the glass", g.showPic) { commit(g.copy(showPic = it)) }
                SliderRow("Blur", "Soft focus of the picture behind the glass", g.blur) { v, done ->
                    g = g.copy(blur = v)
                    if (done) NotifGlassPrefs.save(context, g)
                }
                SliderRow("Frost", "How milky and thick the glass looks", g.frost) { v, done ->
                    g = g.copy(frost = v)
                    if (done) NotifGlassPrefs.save(context, g)
                }
                Text("GLASS TONE", color = Tx.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val tones = listOf("From cover", "Theme", "Smoke", "Light")
                    tones.forEachIndexed { i, label ->
                        val on = g.tint == i
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50.dp))
                                .background(if (on) Tx.Accent else Color.White.copy(alpha = 0.08f))
                                .clickable { commit(g.copy(tint = i)) }
                                .padding(horizontal = 14.dp, vertical = 9.dp),
                        ) {
                            Text(label, color = if (on) Color.Black else Tx.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            Text(
                "Changes reach the live notification straight away while music is playing. " +
                    "Your own image or video for the notification is still chosen in Settings.",
                color = Tx.Muted, fontSize = 12.sp, lineHeight = 17.sp,
                modifier = Modifier.padding(top = 20.dp, bottom = 40.dp),
            )
        }
    }
}

// ------------------------------------------------------------------------------------ pieces

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, color = Tx.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp,
        modifier = Modifier.padding(top = 22.dp, bottom = 10.dp),
    )
}

@Composable
private fun ModeChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50.dp))
            .background(if (on) Color.White.copy(alpha = 0.18f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 5.dp),
    ) { Text(label, color = if (on) Color.White else Tx.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun ToggleRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Tx.Surface)
            .clickable { onChange(!on) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Tx.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = Tx.Muted, fontSize = 12.sp)
        }
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Tx.Accent, checkedThumbColor = Color.Black),
        )
    }
}

@Composable
private fun SliderRow(title: String, sub: String, value: Int, onChange: (Int, Boolean) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Tx.Surface)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Tx.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(sub, color = Tx.Muted, fontSize = 12.sp)
            }
            Text("$value", color = Tx.Accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.toInt(), false) },
            onValueChangeFinished = { onChange(value, true) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(thumbColor = Tx.Accent, activeTrackColor = Tx.Accent),
        )
    }
}

/** One look in the gallery, drawn by the same renderer the notification uses. */
@Composable
private fun LookTile(
    id: String,
    name: String,
    selected: Boolean,
    base: Bitmap?,
    accent: Int,
    accent2: Int,
    g: GlassConfig,
    onClick: () -> Unit,
) {
    val img by produceState<Bitmap?>(null, id, base, g.blur, g.frost, g.showPic) {
        value = withContext(Dispatchers.Default) {
            try {
                NotifArtRenderer.render(
                    size = 200, style = id, frame = 2, base = base, videoFrame = null, seed = "AUVYRR $name",
                    accent = accent, accent2 = accent2, showLogo = false,
                    glassBlur = g.blur, glassFrost = g.frost, glassPic = g.showPic,
                )
            } catch (_: Throwable) {
                null
            }
        }
    }
    Column(
        Modifier.width(104.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(104.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White.copy(alpha = 0.06f))
                .border(
                    if (selected) 2.dp else 1.dp,
                    if (selected) Tx.Accent else Color.White.copy(alpha = 0.10f),
                    RoundedCornerShape(22.dp),
                ),
        ) {
            img?.let { Image(it.asImageBitmap(), name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Text(
            name, color = if (selected) Tx.Accent else Tx.Text, fontSize = 12.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp),
        )
    }
}

/** What the glass card looks like, built from the same numbers as the real notification. */
@Composable
private fun GlassCardPreview(
    g: GlassConfig,
    base: Bitmap?,
    title: String,
    artist: String,
    accent: Int,
    accent2: Int,
    styleId: String,
    expanded: Boolean,
) {
    val blurBg = remember(base, g.blur) { base?.let { NotifGlassArt.blurred(it, g.blur).asImageBitmap() } }
    val tint = Color(NotifGlassArt.tintColor(g, accent, base))
    val light = NotifGlassArt.isLight(g)
    val main = if (light) Color(0xFF12131A) else Color.White
    val sub = if (light) Color(0xB012131A) else Color(0xCCFFFFFF)
    val sharp = styleId in NotifGlassArt.STYLES || styleId == "default" || styleId == "custom"

    val frame by produceState<Bitmap?>(null, styleId, base, g.showPic, g.blur, g.frost) {
        var f = 0
        val animated = NotifCatalog.byId(styleId).isAnimated
        while (true) {
            value = withContext(Dispatchers.Default) {
                if (sharp) {
                    NotifGlassArt.roundedPicture(base, 192, 0.2f, title, accent, accent2)
                } else {
                    NotifGlassArt.roundedPicture(
                        NotifArtRenderer.render(192, styleId, f, base, null, title, accent, accent2, false), 192, 0.2f, title, accent, accent2,
                    )
                }
            }
            if (!animated || sharp) break
            delay(700)
            f++
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(if (expanded) 132.dp else 64.dp)
            .clip(RoundedCornerShape(24.dp))
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(24.dp)),
    ) {
        if (blurBg != null) {
            Image(blurBg, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(accent).copy(alpha = 0.6f), Color(accent2).copy(alpha = 0.4f)))))
        }
        Box(Modifier.fillMaxSize().background(tint))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.Transparent))))

        if (expanded) {
            Column(Modifier.fillMaxSize().padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 6.dp)) {
                Row(Modifier.fillMaxWidth().height(68.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (g.showPic) {
                        frame?.let { Image(it.asImageBitmap(), null, Modifier.size(68.dp)) }
                        Spacer(Modifier.width(14.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("AUVYRR", color = sub, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text(title, color = main, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(artist, color = sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    for (ic in listOf(Icons.Rounded.FastRewind, Icons.Rounded.SkipPrevious, Icons.Rounded.Pause, Icons.Rounded.SkipNext, Icons.Rounded.FastForward)) {
                        Icon(ic, null, tint = main, modifier = Modifier.width(48.dp).size(26.dp))
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (g.showPic) {
                    frame?.let { Image(it.asImageBitmap(), null, Modifier.size(48.dp)) }
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(title, color = main, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(artist, color = sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(Icons.Rounded.SkipPrevious, null, tint = main, modifier = Modifier.size(26.dp))
                Icon(Icons.Rounded.Pause, null, tint = main, modifier = Modifier.padding(horizontal = 6.dp).size(30.dp))
                Icon(Icons.Rounded.SkipNext, null, tint = main, modifier = Modifier.size(26.dp))
            }
        }
    }
}

@Composable
private fun PlainCardPreview(title: String, artist: String, expanded: Boolean) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(if (expanded) 132.dp else 64.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF0B0E16))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(Tx.Accent.copy(alpha = 0.25f)))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(artist, color = Tx.Muted, fontSize = 12.sp, maxLines = 1)
        }
    }
}
