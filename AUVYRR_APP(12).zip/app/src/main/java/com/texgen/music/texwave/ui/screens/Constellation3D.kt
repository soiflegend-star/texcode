package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.components.drawComet
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.seedColors
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private class SStar(val song: Song, val x: Float, val y: Float, val z: Float, val color: Color, val cluster: Int)
private class SCluster(val artist: String, val cx: Float, val cy: Float, val cz: Float, val members: List<Int>)
private class SFigStar(val name: String, val x: Float, val y: Float, val z: Float, val color: Color)
private class SFig(val title: String, val stars: List<SFigStar>)
private class SComet(val from: Offset, val to: Offset, val born: Float)

private class PointBuf {
    var a = FloatArray(8 * 4096)
    var n = 0
    fun put(x: Float, y: Float, z: Float, size: Float, r: Float, g: Float, b: Float, phase: Float) {
        if ((n + 1) * 8 > a.size) a = a.copyOf(a.size * 2)
        val o = n * 8
        a[o] = x; a[o + 1] = y; a[o + 2] = z; a[o + 3] = size
        a[o + 4] = r; a[o + 5] = g; a[o + 6] = b; a[o + 7] = phase
        n++
    }
}

private class LineBuf {
    var a = FloatArray(7 * 1024)
    var n = 0
    fun vert(x: Float, y: Float, z: Float, r: Float, g: Float, b: Float, al: Float) {
        if ((n + 1) * 7 > a.size) a = a.copyOf(a.size * 2)
        val o = n * 7
        a[o] = x; a[o + 1] = y; a[o + 2] = z; a[o + 3] = r; a[o + 4] = g; a[o + 5] = b; a[o + 6] = al
        n++
    }
    fun seg(a1: FloatArray, a2: FloatArray, r: Float, g: Float, b: Float, al: Float) {
        vert(a1[0], a1[1], a1[2], r, g, b, al)
        vert(a2[0], a2[1], a2[2], r, g, b, al)
    }
}

private class SkyBuild(
    val stars: List<SStar>,
    val clusters: List<SCluster>,
    val figs: List<SFig>,
    val data: SkyData,
    val startYaw: Float,
    val startPitch: Float,
)

private fun fibDir(k: Int, n: Int): FloatArray {
    // equator-biased Fibonacci sphere so the first houses sit in front of the camera
    val y = (1f - 2f * (k + 0.5f) / max(n, 1)) * 0.72f
    val r = sqrt(max(0f, 1f - y * y))
    val t = k * 2.3999632f
    return floatArrayOf(cos(t) * r, y, sin(t) * r)
}

private fun buildSky(songs: List<Song>): SkyBuild {
    val pts = PointBuf()
    val lines = LineBuf()

    // ---- far background: dust of stars + the galactic band ----
    val rb = Random(42)
    repeat(2600) {
        val u = rb.nextFloat() * 2f - 1f
        val th = rb.nextFloat() * 6.2831853f
        val rr = sqrt(1f - u * u)
        val d = 80f + rb.nextFloat() * 60f
        val tint = rb.nextFloat()
        val (r, g, b) = when {
            tint < 0.25f -> Triple(0.80f, 0.86f, 1.00f)
            tint < 0.60f -> Triple(0.95f, 0.94f, 1.00f)
            tint < 0.85f -> Triple(1.00f, 0.88f, 0.95f)
            else -> Triple(0.85f, 1.00f, 0.93f)
        }
        val br = 0.45f + rb.nextFloat() * 0.55f
        pts.put(cos(th) * rr * d, u * d, sin(th) * rr * d, 0.20f + rb.nextFloat() * rb.nextFloat() * 0.80f, r * br, g * br, b * br, rb.nextFloat())
    }
    val bn = floatArrayOf(0.35f, 0.82f, 0.45f)
    val bl = sqrt(bn[0] * bn[0] + bn[1] * bn[1] + bn[2] * bn[2])
    repeat(1500) {
        // random direction, then squash it toward the band plane
        var x = rb.nextFloat() * 2f - 1f
        var y = rb.nextFloat() * 2f - 1f
        var z = rb.nextFloat() * 2f - 1f
        val dot = (x * bn[0] + y * bn[1] + z * bn[2]) / bl
        val squash = 0.12f + rb.nextFloat() * 0.10f
        x -= bn[0] / bl * dot * (1f - squash)
        y -= bn[1] / bl * dot * (1f - squash)
        z -= bn[2] / bl * dot * (1f - squash)
        val l = sqrt(x * x + y * y + z * z).coerceAtLeast(1e-4f)
        val d = 95f + rb.nextFloat() * 40f
        val br = 0.30f + rb.nextFloat() * 0.45f
        pts.put(x / l * d, y / l * d, z / l * d, 0.14f + rb.nextFloat() * 0.34f, 0.85f * br, 0.82f * br, 1.0f * br, rb.nextFloat())
    }

    // ---- the real constellations, placed on a far sphere with their lines ----
    val figs = ArrayList<SFig>()
    val figDirs = listOf(
        floatArrayOf(0.88f, 0.10f, -0.46f),   // Orion
        floatArrayOf(-0.35f, 0.62f, -0.70f),  // Ursa Major
        floatArrayOf(-0.12f, 0.80f, -0.58f),  // Ursa Minor (Polaris)
        floatArrayOf(-0.80f, 0.45f, -0.40f),  // Cassiopeia
        floatArrayOf(0.20f, -0.45f, 0.87f),   // Scorpius
        floatArrayOf(0.55f, 0.60f, 0.58f),    // Lyra
        floatArrayOf(-0.75f, -0.30f, 0.58f),  // Canis Major (Sirius)
    )
    Figures.forEachIndexed { fi, f ->
        val d = figDirs[fi % figDirs.size]
        val dl = sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
        val dx = d[0] / dl; val dy = d[1] / dl; val dz = d[2] / dl
        // tangent frame
        var rx = dz; var ry = 0f; var rz = -dx
        val rl = sqrt(rx * rx + rz * rz).coerceAtLeast(1e-4f)
        rx /= rl; rz /= rl
        val ux = ry * dz - rz * dy
        val uy = rz * dx - rx * dz
        val uz = rx * dy - ry * dx
        val R = 60f
        val W = 80f * f.sx
        val H = 80f * f.sy * 1.4f
        val fstars = ArrayList<SFigStar>()
        val posList = ArrayList<FloatArray>()
        f.pts.forEach { p ->
            val ox = (p.x - 0.5f) * W
            val oy = (0.5f - p.y) * H
            val px = dx * R + rx * ox + ux * oy
            val py = dy * R + ry * ox + uy * oy
            val pz = dz * R + rz * ox + uz * oy
            posList.add(floatArrayOf(px, py, pz))
            fstars.add(SFigStar(p.name, px, py, pz, p.color))
            pts.put(px, py, pz, 2.6f + p.mag * 2.4f, p.color.red, p.color.green, p.color.blue, rb.nextFloat())
        }
        f.links.forEach { (a, b) -> lines.seg(posList[a], posList[b], 0.55f, 0.85f, 1.0f, 0.42f) }
        figs.add(SFig(f.title, fstars))
    }

    // ---- your songs: one house (constellation) per artist, in real 3D ----
    val pool = songs.take(160)
    val byArtist = pool.groupBy { it.artist }.entries.sortedByDescending { it.value.size }
    val stars = ArrayList<SStar>()
    val clusters = ArrayList<SCluster>()
    byArtist.forEachIndexed { k, (artist, list) ->
        val dir = fibDir(k, byArtist.size)
        val rnd = Random(artist.hashCode())
        val dist = 15f + rnd.nextFloat() * 9f
        val cx = dir[0] * dist; val cy = dir[1] * dist; val cz = dir[2] * dist
        val spread = 0.7f + 0.5f * sqrt(list.size.toFloat())
        val idx = ArrayList<Int>()
        list.forEach { s ->
            val ox = if (list.size == 1) 0f else (rnd.nextFloat() - 0.5f) * 2f * spread
            val oy = if (list.size == 1) 0f else (rnd.nextFloat() - 0.5f) * 2f * spread
            val oz = if (list.size == 1) 0f else (rnd.nextFloat() - 0.5f) * 2f * spread
            val (c1, _) = seedColors(s.album)
            val col = Color(0.55f + 0.45f * c1.red, 0.55f + 0.45f * c1.green, 0.65f + 0.35f * c1.blue)
            idx.add(stars.size)
            stars.add(SStar(s, cx + ox, cy + oy, cz + oz, col, k))
            val size = 1.25f + min(s.durationMs / 60_000f, 6f) * 0.15f
            pts.put(cx + ox, cy + oy, cz + oz, size, col.red, col.green, col.blue, rnd.nextFloat())
        }
        clusters.add(SCluster(artist, cx, cy, cz, idx))
        // join the stars into a chain (nearest neighbour), so each artist reads as a constellation
        if (idx.size >= 2) {
            val left = ArrayList(idx)
            var cur = left.removeAt(0)
            while (left.isNotEmpty()) {
                val a = stars[cur]
                var bi = 0
                var bd = Float.MAX_VALUE
                left.forEachIndexed { i, sj ->
                    val b = stars[sj]
                    val d2 = (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) + (a.z - b.z) * (a.z - b.z)
                    if (d2 < bd) { bd = d2; bi = i }
                }
                val nxt = left.removeAt(bi)
                val b = stars[nxt]
                lines.seg(floatArrayOf(a.x, a.y, a.z), floatArrayOf(b.x, b.y, b.z), a.color.red * 0.8f + 0.2f, a.color.green * 0.8f + 0.2f, a.color.blue * 0.8f + 0.2f, 0.34f)
                cur = nxt
            }
        }
    }

    // start looking at the biggest house
    var yaw = 0f
    var pitch = 0.12f
    clusters.firstOrNull()?.let { c ->
        val l = sqrt(c.cx * c.cx + c.cy * c.cy + c.cz * c.cz).coerceAtLeast(1e-3f)
        yaw = atan2(c.cx / l, -c.cz / l)
        pitch = asin((c.cy / l).coerceIn(-1f, 1f)).coerceIn(-0.5f, 0.5f)
    }
    return SkyBuild(stars, clusters, figs, SkyData(pts.a, pts.n, lines.a, lines.n), yaw, pitch)
}

/**
 * AUVYRR Constellation in real 3D. You float inside a night sky: every artist is a constellation of
 * glowing 3D stars (your songs), the real constellations hang on the far dome, and a procedural
 * nebula and Milky Way sit behind it all. Drag to look around, pinch to fly forward and back,
 * tap a star to play it, tap a real star to explore it.
 */
@OptIn(ExperimentalTextApi::class)
@Composable
fun ConstellationScreen(
    songs: List<Song>,
    onPlay: (Song) -> Unit,
    onOpenLibrary: () -> Unit,
    currentSongId: Long? = null,
    isPlaying: Boolean = false,
    onBack: () -> Unit = {},
    onExplore: (String?) -> Unit = {},
) {
    val exploreNow by rememberUpdatedState(onExplore)
    val playNow by rememberUpdatedState(onPlay)
    val textMeasurer = rememberTextMeasurer()
    val sky = remember(songs) { buildSky(songs) }
    val cam = remember { SkyCam() }
    remember(sky) {
        cam.yaw = sky.startYaw
        cam.pitch = sky.startPitch
        true
    }

    var clock by remember { mutableFloatStateOf(0f) }
    var touchedAt by remember { mutableFloatStateOf(-10f) }
    var selected by remember { mutableStateOf<SStar?>(null) }
    var viewW by remember { mutableFloatStateOf(1f) }
    var viewH by remember { mutableFloatStateOf(1f) }
    var comets by remember { mutableStateOf<List<SComet>>(emptyList()) }
    var bursts by remember { mutableStateOf<List<Pair<SStar, Float>>>(emptyList()) }
    var nextComet by remember { mutableFloatStateOf(2f) }
    var glView by remember { mutableStateOf<ConstellationGlView?>(null) }

    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
            last = now
            clock += dt
            if (clock - touchedAt > 3.5f) cam.yaw += 0.03f * dt   // slow drift while idle
            if (comets.isNotEmpty()) comets = comets.filter { clock - it.born < 1.2f }
            if (bursts.isNotEmpty()) bursts = bursts.filter { clock - it.second < 0.9f }
            if (clock > nextComet && viewW > 10f) {
                nextComet = clock + 4f + Random.nextFloat() * 5f
                val y0 = viewH * (0.08f + Random.nextFloat() * 0.4f)
                val from = Offset(viewW * (0.55f + Random.nextFloat() * 0.5f), y0)
                comets = comets + SComet(from, Offset(from.x - viewW * 0.9f, y0 + viewH * 0.3f), clock)
            }
        }
    }

    DisposableEffect(Unit) { onDispose { glView?.onPause() } }

    Box(Modifier.fillMaxSize().background(Color(0xFF030308))) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                ConstellationGlView(ctx, cam).also { v ->
                    v.setNebula(
                        floatArrayOf(Tx.Accent2.red * 0.9f, Tx.Accent2.green * 0.9f, Tx.Accent2.blue * 0.9f),
                        floatArrayOf(Tx.Accent.red * 0.8f, Tx.Accent.green * 0.8f, Tx.Accent.blue * 0.8f),
                        floatArrayOf(0.72f, 0.62f, 1.0f),
                    )
                    v.setSky(sky.data)
                    glView = v
                }
            },
            update = { it.setSky(sky.data) },
        )

        // labels, rings, comets and touch handling sit on top of the GL sky
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        touchedAt = clock
                        cam.yaw = cam.yaw - pan.x * 0.0042f
                        cam.pitch = (cam.pitch + pan.y * 0.0042f).coerceIn(-1.4f, 1.4f)
                        cam.travel = (cam.travel + (zoom - 1f) * 16f).coerceIn(0f, 15f)
                    }
                }
                .pointerInput(sky) {
                    detectTapGestures { off ->
                        touchedAt = clock
                        val vp = FloatArray(16)
                        val r = FloatArray(3); val u = FloatArray(3); val f = FloatArray(3)
                        cam.matrices(viewW / viewH, vp, r, u, f)
                        val dep = FloatArray(1)
                        var best: SStar? = null
                        var bestD = 44f * density
                        for (st in sky.stars) {
                            val p = SkyCam.projectWith(vp, st.x, st.y, st.z, viewW, viewH, dep) ?: continue
                            val d = (p - off).getDistance()
                            if (d < bestD) { bestD = d; best = st }
                        }
                        var figHit: String? = null
                        var figD = 34f * density
                        for (fg in sky.figs) for (fs in fg.stars) {
                            val p = SkyCam.projectWith(vp, fs.x, fs.y, fs.z, viewW, viewH, dep) ?: continue
                            val d = (p - off).getDistance()
                            if (d < figD) { figD = d; figHit = fs.name }
                        }
                        if (figHit != null && figD <= bestD) {
                            exploreNow(figHit)
                        } else {
                            best?.let { st ->
                                selected = st
                                bursts = bursts + (st to clock)
                                playNow(st.song)
                            }
                        }
                    }
                },
        ) {
            viewW = size.width
            viewH = size.height
            val w = size.width
            val h = size.height
            val d = density
            val t = clock // read so the overlay redraws every frame
            val vp = FloatArray(16)
            val rr = FloatArray(3); val uu = FloatArray(3); val ff = FloatArray(3)
            cam.matrices(w / h, vp, rr, uu, ff)
            val dep = FloatArray(1)

            // selection / now-playing rings follow their star in 3D
            for (st in sky.stars) {
                val isCur = st.song.id == currentSongId
                val isSel = selected?.song?.id == st.song.id
                if (!isCur && !isSel) continue
                val p = SkyCam.projectWith(vp, st.x, st.y, st.z, w, h, dep) ?: continue
                val base = (26f * d) / (dep[0] / 15f).coerceIn(0.5f, 4f)
                if (isCur) drawCircle(Tx.Accent2.copy(alpha = if (isPlaying) 0.85f else 0.45f), base * (0.85f + 0.12f * sin(t * 3.2f)), p, style = Stroke(1.6f * d))
                if (isSel) drawCircle(Color.White.copy(alpha = 0.85f), base * (1.25f + 0.08f * sin(t * 4f)), p, style = Stroke(1.3f * d))
            }

            // artist labels
            for (cl in sky.clusters) {
                val p = SkyCam.projectWith(vp, cl.cx, cl.cy, cl.cz, w, h, dep) ?: continue
                if (p.x < -80 || p.x > w + 80 || p.y < -40 || p.y > h + 40) continue
                val near = (1f - ((dep[0] - 6f) / 40f)).coerceIn(0.25f, 1f)
                val lay = textMeasurer.measure(
                    cl.artist.take(22),
                    TextStyle(color = Color.White.copy(alpha = (if (cl.members.size > 1) 0.7f else 0.45f) * near), fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.8.sp),
                    overflow = TextOverflow.Ellipsis, maxLines = 1,
                )
                val drop = (30f * d) / (dep[0] / 18f).coerceIn(0.6f, 3f)
                drawText(lay, topLeft = Offset(p.x - lay.size.width / 2f, p.y + drop))
            }

            // real constellation names and bright star names
            for (fg in sky.figs) {
                var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var any = false
                for (fs in fg.stars) {
                    val p = SkyCam.projectWith(vp, fs.x, fs.y, fs.z, w, h, dep) ?: continue
                    if (p.x < -40 || p.x > w + 40 || p.y < -40 || p.y > h + 40) continue
                    any = true
                    minX = min(minX, p.x); minY = min(minY, p.y)
                    val lay = textMeasurer.measure(fs.name, TextStyle(color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp), maxLines = 1)
                    drawText(lay, topLeft = Offset(p.x - lay.size.width / 2f, p.y + 20f * d))
                }
                if (any) {
                    val tl = textMeasurer.measure(fg.title, TextStyle(color = Color(0xFF9FE8FF).copy(alpha = 0.55f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp), maxLines = 1)
                    drawText(tl, topLeft = Offset(minX, minY - 22f * d))
                }
            }

            // tap bursts
            for ((st, born) in bursts) {
                val p = SkyCam.projectWith(vp, st.x, st.y, st.z, w, h, dep) ?: continue
                val a = ((t - born) / 0.9f).coerceIn(0f, 1f)
                drawCircle(st.color.copy(alpha = (1f - a) * 0.9f), 8f * d + a * 70f * d, p, style = Stroke((3f * (1f - a) + 0.6f) * d))
                drawCircle(Color.White.copy(alpha = (1f - a) * 0.6f), 4f * d + a * 34f * d, p, style = Stroke(1.2f * d))
            }

            // shooting stars
            for (c in comets) {
                val k = ((t - c.born) / 1.1f).coerceIn(0f, 1f)
                val head = Offset(c.from.x + (c.to.x - c.from.x) * k, c.from.y + (c.to.y - c.from.y) * k)
                val dx = c.to.x - c.from.x
                val dy = c.to.y - c.from.y
                val len = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                drawComet(head, Offset(dx / len, dy / len), min(len * 0.55f, w * 0.6f), sin(k * Math.PI.toFloat()).coerceIn(0f, 1f), accent = Color(0xFF8FF0CB))
            }
        }

        // header
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x22FFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape).clickable { onBack() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("CONSTELLATION", color = Color(0xFFB6F5DC), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.2.sp)
                Text("Your living sky", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
                Text(
                    "${sky.stars.size} stars · ${sky.clusters.size} houses · drag to look · pinch to fly",
                    color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, maxLines = 1,
                )
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x22FFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape).clickable { onOpenLibrary() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.LibraryMusic, "Library", tint = Color.White) }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x3345D9FF)).border(1.dp, Color(0x6645D9FF), CircleShape).clickable { onExplore(null) },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Public, "Explore the cosmos", tint = Color(0xFFBFF3FF)) }
        }

        val shown = selected?.song ?: sky.stars.firstOrNull { it.song.id == currentSongId }?.song
        if (shown != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xF2212123), Color(0xF0101012))))
                    .border(1.dp, Brush.horizontalGradient(listOf(Color(0xCC2BE4A4), Color(0x55FFFFFF), Color(0xCCB388FF))), RoundedCornerShape(22.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Tx.Accent2, Tx.Accent, Tx.Accent3))),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.PlayArrow, null, tint = Color.White) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(shown.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(shown.artist, color = Color(0xFF9FE8CB), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        val pulse = 0.5f + 0.5f * sin(clock * 2.4f)
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = if (shown != null) 108.dp else 28.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xE60E6E8F), Color(0xE65B3BD6))))
                .border(1.dp, Color.White.copy(alpha = 0.25f + 0.4f * pulse), RoundedCornerShape(26.dp))
                .clickable { onExplore(null) }
                .padding(horizontal = 22.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Public, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("EXPLORE THE COSMOS", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }

        if (sky.stars.isEmpty()) {
            Text("Scan your library to light the sky", color = Color.White.copy(alpha = 0.5f), modifier = Modifier.align(Alignment.Center))
        }
    }
}
