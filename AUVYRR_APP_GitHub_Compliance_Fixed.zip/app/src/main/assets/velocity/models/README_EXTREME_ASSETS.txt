NEXUS RUNNER EXTREME ASSET SYSTEM

Drop better assets without touching gameplay code.

Expected structure:
  models/<category>/<id>.glb
  models/<category>/<id>.high.glb
  models/<category>/<id>.ultra.glb
  models/<category>/<id>.extreme.glb

Categories:
  characters, buildings, obstacles, vehicles, props, landmarks, environment

The runtime automatically chooses the highest available variant. If an extreme asset is absent, it falls back to ULTRA/HIGH/STANDARD, then to the existing procedural fallback when the gameplay module provides one.

IMPORTANT:
A higher filename does not create detail by itself. Genuine extreme quality still requires a genuinely detailed GLB with high-quality geometry/PBR textures. The system is the pipeline that lets the project accept those assets consistently and safely.
