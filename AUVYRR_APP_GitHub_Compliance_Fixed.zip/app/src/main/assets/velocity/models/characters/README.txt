Drop character .glb files here, named by CharacterId:

  runner.glb
  acrobat.glb
  speedster.glb
  heavy.glb
  ninja.glb
  ... (see src/data/GameData.ts for full list)

See docs/GLB_CHARACTERS.md for export settings and animation names.

If a file is missing, the procedural character is used automatically.

2026-11-16 GLB catalog expansion
- Added eight high-detail GLB character catalog assets: ace, rio, kai, skye, zara, jett, aria, max.
- These catalog GLBs are static showcase assets; the gameplay-safe procedural rig remains the runtime fallback because the source project animation contract expects named clips.
