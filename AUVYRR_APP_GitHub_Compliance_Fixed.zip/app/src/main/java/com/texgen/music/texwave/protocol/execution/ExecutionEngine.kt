package com.texgen.music.texwave.protocol.execution

import com.texgen.music.texwave.protocol.adapter.DeviceAdapter
import com.texgen.music.texwave.protocol.models.*
import com.texgen.music.texwave.protocol.safety.SafetyGate
import com.texgen.music.texwave.protocol.transport.Transport
import com.texgen.music.texwave.protocol.verification.VerificationEngine

class ExecutionEngine(
    private val safetyGate: SafetyGate = SafetyGate(),
    private val verificationEngine: VerificationEngine = VerificationEngine()
) {
    data class ExecutionResult(
        val command: ProtocolCommand?,
        val observation: Observation?,
        val verification: VerificationResult?,
        val status: FeatureResultStatus,
        val message: String,
        val safetyDecision: SafetyGate.SafetyDecision? = null
    )

    fun execute(
        adapter: DeviceAdapter,
        transport: Transport,
        feature: String,
        operation: Operation,
        parameters: Map<String, Any> = emptyMap(),
        target: DeviceTarget = DeviceTarget.BOTH,
        evidenceStrength: Double = 0.5,
        userConfirmed: Boolean = false
    ): ExecutionResult {
        val command = adapter.buildCommand(feature, operation, parameters, target)
            ?: return ExecutionResult(null, null, null, FeatureResultStatus.DEVICE_UNSUPPORTED,
                "Adapter ${adapter.adapterId} does not support feature=$feature operation=$operation")

        val safety = safetyGate.evaluate(command, evidenceStrength, userConfirmed)
        if (!safety.allowed) {
            return ExecutionResult(command, null, null, FeatureResultStatus.UNSAFE_TO_EXECUTE, safety.reason, safety)
        }

        val beforeState = when (command.verificationMethod) {
            VerificationMethod.BEFORE_AFTER, VerificationMethod.STATE_READBACK -> transport.getObservedState()
            else -> null
        }

        if (!transport.isAvailable) {
            return ExecutionResult(command, null, null, FeatureResultStatus.TRANSPORT_UNAVAILABLE,
                "Transport ${transport.type} is not available")
        }

        val payload = parameters["payload"] as? ByteArray
            ?: (parameters["payloadHex"] as? String)?.let { hexToBytes(it) }
            ?: ByteArray(0)

        val response = when (command.operation) {
            Operation.GET, Operation.QUERY ->
                transport.read(command.serviceUuid, command.characteristicUuid, command.timeoutMs)
            Operation.SUBSCRIBE ->
                transport.subscribe(command.serviceUuid, command.characteristicUuid, command.timeoutMs)
            else ->
                transport.write(command.serviceUuid, command.characteristicUuid, payload, command.timeoutMs)
        }

        val parsed = adapter.parseResponse(command, response.rawPayload) ?: response.parsed
        val enriched = response.copy(parsed = parsed ?: response.parsed)

        val afterState = when (command.verificationMethod) {
            VerificationMethod.BEFORE_AFTER, VerificationMethod.STATE_READBACK -> transport.getObservedState()
            else -> null
        }

        val observation = Observation(
            commandId = command.commandId,
            response = enriched,
            beforeState = beforeState,
            afterState = afterState,
            systemObservations = transport.getObservedState()
        )

        val verification = verificationEngine.verify(command, observation)

        val status = when (verification.result) {
            VerificationResultStatus.VERIFIED_WORKING -> FeatureResultStatus.VERIFIED_WORKING
            VerificationResultStatus.VERIFIED_READ_ONLY -> FeatureResultStatus.VERIFIED_READ_ONLY
            VerificationResultStatus.PARTIALLY_SUPPORTED -> FeatureResultStatus.PARTIALLY_SUPPORTED
            VerificationResultStatus.NOT_VERIFIABLE -> FeatureResultStatus.NOT_VERIFIABLE
            VerificationResultStatus.COMMAND_SENT_UNVERIFIED -> FeatureResultStatus.COMMAND_SENT_UNVERIFIED
            VerificationResultStatus.VERIFICATION_FAILURE -> FeatureResultStatus.FAILED
            VerificationResultStatus.FAILED -> FeatureResultStatus.FAILED
            VerificationResultStatus.EXPERIMENTAL -> FeatureResultStatus.EXPERIMENTAL
        }

        return ExecutionResult(command, observation, verification, status, verification.notes ?: status.name, safety)
    }

    private fun hexToBytes(hex: String): ByteArray {
        val clean = hex.replace(" ", "").replace(":", "")
        return ByteArray(clean.length / 2) { i ->
            clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }
}
