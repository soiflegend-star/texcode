package com.texgen.music.texwave.earbuds

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.texgen.music.texwave.protocol.ProtocolManager
import com.texgen.music.texwave.protocol.identity.IdentityEngine
import com.texgen.music.texwave.protocol.models.CapabilityProfile
import com.texgen.music.texwave.protocol.models.DeviceIdentity
import com.texgen.music.texwave.protocol.models.DeviceTarget
import com.texgen.music.texwave.protocol.models.FeatureResultStatus
import com.texgen.music.texwave.protocol.models.Operation
import com.texgen.music.texwave.protocol.transport.BleGattTransport
import com.texgen.music.texwave.protocol.transport.GattServiceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Bridge between the AUVYRR protocol layer and the app.
 *
 * What is REAL here: bonded/connected earbud discovery, system battery value, BLE GATT connection,
 * standard Device Information + Battery services, identity scoring and a full GATT map.
 * What is NOT here: any vendor-specific protocol (ANC, EQ, touch gestures ...). Those need a
 * per-model adapter; without one the protocol layer reports PROTOCOL_UNKNOWN instead of pretending.
 */
@SuppressLint("MissingPermission")
object EarbudsHub {

    data class Bud(
        val address: String,
        val name: String,
        val connected: Boolean,
        val battery: Int?,
        val bleCapable: Boolean,
    )

    data class Probe(
        val reachedGatt: Boolean,
        val message: String,
        val identity: DeviceIdentity?,
        val capability: CapabilityProfile?,
        val info: Map<String, String>,
        val gattBattery: Int?,
        val services: List<GattServiceInfo>,
        val profiles: List<String> = emptyList(),
        val classicUuids: List<String> = emptyList(),
        val vendorHint: String? = null,
        val deviceClass: String = "",
    ) {
        fun dump(): String = buildString {
            appendLine("AUVYRR GATT map")
            identity?.let { appendLine("Device: ${it.bluetoothName} (${it.brand} ${it.model}, confidence ${"%.2f".format(it.confidence)})") }
            info.forEach { (k, v) -> appendLine("$k: $v") }
            appendLine("Device class: $deviceClass")
            appendLine("Profiles: ${profiles.joinToString()}")
            vendorHint?.let { appendLine("Vendor hint: $it") }
            appendLine("Classic service UUIDs: ${classicUuids.joinToString()}")
            appendLine("Services: ${services.size}")
            services.forEach { svc ->
                appendLine("- ${svc.uuid}")
                svc.characteristics.forEach { appendLine("    ${it.uuid} props=0x${Integer.toHexString(it.properties)}") }
            }
        }
    }

    val manager = ProtocolManager()
    private var transport: BleGattTransport? = null

    private const val DIS = "0000180a-0000-1000-8000-00805f9b34fb"
    private const val BAS = "0000180f-0000-1000-8000-00805f9b34fb"
    private const val BAT_LEVEL = "00002a19-0000-1000-8000-00805f9b34fb"
    private val disFields = linkedMapOf(
        "Manufacturer" to "00002a29-0000-1000-8000-00805f9b34fb",
        "Model" to "00002a24-0000-1000-8000-00805f9b34fb",
        "Firmware" to "00002a26-0000-1000-8000-00805f9b34fb",
        "Hardware" to "00002a27-0000-1000-8000-00805f9b34fb",
        "Software" to "00002a28-0000-1000-8000-00805f9b34fb",
    )

    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else emptyArray()

    fun hasPermission(ctx: Context): Boolean =
        requiredPermissions().all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

    private fun adapter(ctx: Context): BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun bluetoothOn(ctx: Context): Boolean = runCatching { adapter(ctx)?.isEnabled == true }.getOrDefault(false)

    private fun systemBattery(d: BluetoothDevice): Int? = runCatching {
        val v = BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as Int
        if (v in 0..100) v else null
    }.getOrNull()

    /** Bonded devices; "connected" = an Android audio output with the same name is active. */
    fun listBuds(ctx: Context): List<Bud> {
        if (!hasPermission(ctx)) return emptyList()
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val activeNames = runCatching {
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .filter {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                        it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        it.type == 26 || // TYPE_BLE_HEADSET (API 31)
                        it.type == AudioDeviceInfo.TYPE_HEARING_AID
                }
                .map { it.productName.toString() }
                .toSet()
        }.getOrDefault(emptySet())
        val bonded = runCatching { adapter(ctx)?.bondedDevices.orEmpty() }.getOrDefault(emptySet())
        return bonded
            .map { d ->
                val n = runCatching { d.name }.getOrNull() ?: d.address
                Bud(
                    address = d.address,
                    name = n,
                    connected = n in activeNames,
                    battery = systemBattery(d),
                    bleCapable = d.type == BluetoothDevice.DEVICE_TYPE_LE || d.type == BluetoothDevice.DEVICE_TYPE_DUAL,
                )
            }
            .sortedWith(compareByDescending<Bud> { it.connected }.thenBy { it.name.lowercase() })
    }

    private fun ascii(b: ByteArray?): String? =
        b?.takeIf { it.isNotEmpty() }?.toString(Charsets.UTF_8)?.trim { it <= ' ' }?.takeIf { it.isNotBlank() }

    /** Connects over BLE GATT, reads standard services, identifies the device from evidence. */
    private suspend fun probeGatt(ctx: Context, address: String): Probe = withContext(Dispatchers.IO) {
        release()
        val ad = adapter(ctx)
        if (ad == null || !hasPermission(ctx)) {
            return@withContext Probe(false, "Bluetooth permission is missing.", null, null, emptyMap(), null, emptyList())
        }
        val dev = runCatching { ad.getRemoteDevice(address) }.getOrNull()
            ?: return@withContext Probe(false, "Device not found.", null, null, emptyMap(), null, emptyList())
        val name = runCatching { dev.name }.getOrNull()

        val t = BleGattTransport(ctx.applicationContext, dev)
        val ok = runCatching { t.connect(address) }.getOrDefault(false)
        if (!ok) {
            runCatching { t.disconnect() }
            val id = manager.identify(
                IdentityEngine.RawDeviceEvidence(
                    bluetoothName = name, address = address, bondState = dev.bondState, type = dev.type,
                ),
            )
            return@withContext Probe(
                false,
                "No BLE GATT service reachable. Most earbuds are classic-Bluetooth only on this link, so ANC, EQ and gestures need a model-specific adapter (vendor protocol) that this build does not contain.",
                id, manager.resolveCapabilities(id), emptyMap(), null, emptyList(),
            )
        }
        transport = t
        val services = t.discoverServices()
        val info = linkedMapOf<String, String>()
        if (services.any { it.uuid.equals(DIS, true) }) {
            for ((label, uuid) in disFields) {
                val r = t.read(DIS, uuid, 3000)
                if (r.success) ascii(r.rawPayload)?.let { info[label] = it }
            }
        }
        var battery: Int? = null
        if (services.any { it.uuid.equals(BAS, true) }) {
            val r = t.read(BAS, BAT_LEVEL, 3000)
            if (r.success) battery = r.rawPayload?.firstOrNull()?.toInt()?.and(0xFF)?.takeIf { it in 0..100 }
        }
        val id = manager.identify(
            IdentityEngine.RawDeviceEvidence(
                bluetoothName = name,
                address = address,
                serviceUuids = services.map { it.uuid },
                systemModel = info["Model"],
                firmwareRevision = info["Firmware"],
                hardwareRevision = info["Hardware"],
                bondState = dev.bondState,
                type = dev.type,
            ),
        )
        manager.setTransport(t, connect = false)
        Probe(true, "Connected over BLE GATT.", id, manager.resolveCapabilities(id), info, battery, services)
    }

    data class ActivateResult(val ok: Boolean, val text: String)

    /** Runs a feature through the protocol layer. Without a device adapter this reports honestly. */
    suspend fun activate(feature: String, mode: String): ActivateResult = withContext(Dispatchers.Default) {
        val r = runCatching {
            manager.executeFeature(feature, Operation.SET, mapOf("mode" to mode), DeviceTarget.BOTH, userConfirmed = true)
        }.getOrElse { return@withContext ActivateResult(false, it.message ?: "Failed") }
        val ok = r.status == FeatureResultStatus.VERIFIED_WORKING
        val label = when (r.status) {
            FeatureResultStatus.VERIFIED_WORKING -> "Done and verified"
            FeatureResultStatus.PROTOCOL_UNKNOWN -> "No adapter for this earbud model yet"
            FeatureResultStatus.DEVICE_UNSUPPORTED -> "Not supported by this device"
            FeatureResultStatus.COMMAND_SENT_UNVERIFIED -> "Sent, but the earbuds did not confirm"
            else -> r.status.name.lowercase().replace('_', ' ')
        }
        ActivateResult(ok, label)
    }



    // ---- Classic Bluetooth (SDP) fetch: works for every earbud model -------------------------

    private val STD_BASE = "-0000-1000-8000-00805f9b34fb"
    private val PROFILE_NAMES = mapOf(
        "110b" to "A2DP audio", "110a" to "A2DP source", "110c" to "AVRCP target", "110e" to "AVRCP remote",
        "110f" to "AVRCP controller", "111e" to "Hands-free", "111f" to "Hands-free gateway",
        "1108" to "Headset", "1112" to "Headset gateway", "1124" to "HID", "1200" to "PnP info",
        "1203" to "Generic audio", "1800" to "Generic access", "180f" to "Battery service",
    )
    // Publicly documented vendor serial-port UUIDs: used only as an identification hint.
    private val VENDOR_UUIDS = mapOf(
        "96cc203e-5068-46ad-b32d-e316f5e069ba" to "Sony (headphone control service)",
        "2e73a4ad-332d-41fc-90e2-16bef06523f2" to "Samsung Galaxy Buds (control service)",
    )

    private fun shortId(u: String): String? {
        val l = u.lowercase()
        return if (l.endsWith(STD_BASE) && l.startsWith("0000")) l.substring(4, 8) else null
    }

    private fun classicInfo(ctx: Context, address: String): Probe {
        val dev = runCatching { adapter(ctx)?.getRemoteDevice(address) }.getOrNull()
            ?: return Probe(false, "", null, null, emptyMap(), null, emptyList())
        val uuids = runCatching { dev.uuids?.map { it.uuid.toString().lowercase() } }.getOrNull().orEmpty()
        val profiles = uuids.mapNotNull { shortId(it)?.let { id -> PROFILE_NAMES[id] } }.distinct()
        val custom = uuids.filter { shortId(it) == null }
        val vendor = custom.firstNotNullOfOrNull { VENDOR_UUIDS[it] }
        val cls = runCatching {
            dev.bluetoothClass?.let { "major=0x${Integer.toHexString(it.majorDeviceClass)} device=0x${Integer.toHexString(it.deviceClass)}" }
        }.getOrNull() ?: "unknown"
        return Probe(false, "", null, null, emptyMap(), null, emptyList(), profiles, custom, vendor, cls)
    }

    suspend fun probe(ctx: Context, address: String): Probe {
        val ble = probeGatt(ctx, address)
        val c = withContext(Dispatchers.IO) { classicInfo(ctx, address) }
        return ble.copy(profiles = c.profiles, classicUuids = c.classicUuids, vendorHint = c.vendorHint, deviceClass = c.deviceClass)
    }

    // ---- Raw RFCOMM session (any classic service the earbuds advertise) ----------------------

    private var rfcomm: android.bluetooth.BluetoothSocket? = null

    suspend fun rfcommOpen(ctx: Context, address: String, uuid: String): String = withContext(Dispatchers.IO) {
        rfcommClose()
        val ad = adapter(ctx) ?: return@withContext "Bluetooth unavailable"
        if (!hasPermission(ctx)) return@withContext "Bluetooth permission is missing."
        try {
            ad.cancelDiscovery()
            val sock = ad.getRemoteDevice(address).createRfcommSocketToServiceRecord(java.util.UUID.fromString(uuid))
            sock.connect()
            rfcomm = sock
            "Connected to $uuid"
        } catch (e: Exception) {
            "Could not open the service: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    /** Sends hex bytes and returns whatever the earbuds answer within about 1.5 seconds. */
    suspend fun rfcommSend(hexText: String): String = withContext(Dispatchers.IO) {
        val sock = rfcomm ?: return@withContext "Not connected"
        val clean = hexText.filter { it.isLetterOrDigit() }
        if (clean.isEmpty() || clean.length % 2 != 0 || !clean.all { it in "0123456789abcdefABCDEF" }) {
            return@withContext "Enter hex bytes, for example 01 0a"
        }
        try {
            val out = ByteArray(clean.length / 2) { i -> clean.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
            sock.outputStream.write(out)
            sock.outputStream.flush()
            val input = sock.inputStream
            val deadline = System.currentTimeMillis() + 1500
            val buf = java.io.ByteArrayOutputStream()
            while (System.currentTimeMillis() < deadline) {
                if (input.available() > 0) {
                    val tmp = ByteArray(256)
                    val n = input.read(tmp)
                    if (n > 0) buf.write(tmp, 0, n)
                } else Thread.sleep(40)
            }
            val resp = buf.toByteArray()
            "Sent ${out.size} bytes. " + if (resp.isEmpty()) "No reply." else "Reply: " + hex(resp)
        } catch (e: Exception) {
            "Failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    fun rfcommClose() {
        runCatching { rfcomm?.close() }
        rfcomm = null
    }

    // ---- System-level controls (real, work on any earbuds) ---------------------------------

    fun volume(ctx: Context): Pair<Int, Int> {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getStreamVolume(AudioManager.STREAM_MUSIC) to am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    }

    fun setVolume(ctx: Context, level: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        runCatching { am.setStreamVolume(AudioManager.STREAM_MUSIC, level, 0) }
    }

    /** Spatial audio state as reported by Android (read-only); null when the phone has no spatializer. */
    fun spatialStatus(ctx: Context): String? {
        if (Build.VERSION.SDK_INT < 32) return null
        return runCatching {
            val sp = (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).spatializer
            if (!sp.isAvailable) null else if (sp.isEnabled) "On" else "Off"
        }.getOrNull()
    }

    // ---- Generic GATT access (works for any characteristic the earbuds expose) -------------

    private fun hex(b: ByteArray?): String = b?.joinToString(" ") { "%02x".format(it) } ?: ""

    suspend fun readChar(service: String, characteristic: String): String = withContext(Dispatchers.IO) {
        val t = transport ?: return@withContext "Not connected"
        val r = t.read(service, characteristic, 4000)
        if (!r.success) return@withContext r.errorMessage ?: "Read failed"
        val raw = r.rawPayload
        val text = ascii(raw)?.takeIf { s -> s.all { c -> c.code in 32..126 } }
        hex(raw).ifEmpty { "(empty)" } + (text?.let { "  \"$it\"" } ?: "")
    }

    /** [hexText] like "01 0a ff". Returns a human readable result. */
    suspend fun writeChar(service: String, characteristic: String, hexText: String): String = withContext(Dispatchers.IO) {
        val t = transport ?: return@withContext "Not connected"
        val clean = hexText.filter { it.isLetterOrDigit() }
        if (clean.isEmpty() || clean.length % 2 != 0 || !clean.all { it in "0123456789abcdefABCDEF" }) {
            return@withContext "Enter hex bytes, for example 01 0a"
        }
        val bytes = ByteArray(clean.length / 2) { i -> clean.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        val r = t.write(service, characteristic, bytes, 4000)
        if (r.success) "Written (${bytes.size} bytes). The device accepted it; check the earbuds for any change." else (r.errorMessage ?: "Write failed")
    }

    fun connectedGatt(): Boolean = transport != null

    fun release() {
        rfcommClose()
        runCatching { transport?.disconnect() }
        transport = null
    }
}
