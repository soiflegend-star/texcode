package com.texgen.music.texwave.protocol.safety

import com.texgen.music.texwave.protocol.models.*

class SafetyGate {
    data class SafetyDecision(
        val allowed: Boolean,
        val requiresUserConfirmation: Boolean,
        val reason: String,
        val requiredEvidenceStrength: Double
    )

    fun evaluate(
        command: ProtocolCommand,
        evidenceStrength: Double = 0.0,
        userConfirmed: Boolean = false
    ): SafetyDecision {
        return when (command.safetyLevel) {
            SafetyLevel.SAFE_READ -> SafetyDecision(true, false, "SAFE_READ", 0.0)
            SafetyLevel.SAFE_CONTROL -> SafetyDecision(
                evidenceStrength >= 0.3 || command.evidenceRefs.isNotEmpty(),
                false,
                if (evidenceStrength >= 0.3) "SAFE_CONTROL" else "INSUFFICIENT_EVIDENCE_FOR_CONTROL",
                0.3
            )
            SafetyLevel.CAUTION -> {
                val ok = evidenceStrength >= 0.5
                SafetyDecision(ok, false, if (ok) "CAUTION_PASSED" else "CAUTION_BLOCKED_LOW_EVIDENCE", 0.5)
            }
            SafetyLevel.HIGH_IMPACT -> {
                val evidenceOk = evidenceStrength >= 0.7
                SafetyDecision(
                    evidenceOk && userConfirmed,
                    true,
                    when {
                        !evidenceOk -> "HIGH_IMPACT_BLOCKED_LOW_EVIDENCE"
                        !userConfirmed -> "HIGH_IMPACT_REQUIRES_USER_CONFIRMATION"
                        else -> "HIGH_IMPACT_ALLOWED"
                    },
                    0.7
                )
            }
            SafetyLevel.DESTRUCTIVE -> {
                val evidenceOk = evidenceStrength >= 0.85
                SafetyDecision(
                    evidenceOk && userConfirmed,
                    true,
                    when {
                        !evidenceOk -> "DESTRUCTIVE_BLOCKED_LOW_EVIDENCE"
                        !userConfirmed -> "DESTRUCTIVE_REQUIRES_USER_CONFIRMATION"
                        else -> "DESTRUCTIVE_ALLOWED_WITH_CONFIRMATION"
                    },
                    0.85
                )
            }
        }
    }
}
