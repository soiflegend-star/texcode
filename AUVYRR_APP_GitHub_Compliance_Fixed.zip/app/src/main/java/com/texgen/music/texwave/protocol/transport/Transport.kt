package com.texgen.music.texwave.protocol.transport

import com.texgen.music.texwave.protocol.models.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Transport abstraction.
 * Real Android implementations use BluetoothGatt / BluetoothSocket.
 * SimulatedTransport is for unit tests and CI only.
 */

interface Transport {
    val type: TransportType
    val isAvailable: Boolean
    fun connect(deviceAddress: String?): Boolean
    fun disconnect()
    fun write(
        serviceUuid: String?,
        characteristicUuid: String?,
        payload: ByteArray,
        timeoutMs: Long
    ): DeviceResponse
    fun read(
        serviceUuid: String?,
        characteristicUuid: String?,
        timeoutMs: Long
    ): DeviceResponse
    fun subscribe(
        serviceUuid: String?,
        characteristicUuid: String?,
        timeoutMs: Long
    ): DeviceResponse
    fun getObservedState(): Map<String, Any>
    fun discoverServices(timeoutMs: Long = 10000L): List<GattServiceInfo>
}

data class GattServiceInfo(
    val uuid: String,
    val characteristics: List<GattCharacteristicInfo> = emptyList()
)

data class GattCharacteristicInfo(
    val uuid: String,
    val properties: Int,
    val permissions: Int = 0
)

/**
 * Simulated transport — CI / unit tests only.
 * NEVER presented as real-device verification.
 */
class SimulatedTransport(
    private val initialState: MutableMap<String, Any> = mutableMapOf(
        "anc" to "OFF",
        "transparency" to "OFF",
        "battery_left" to 80,
        "battery_right" to 78,
        "battery_case" to 90,
        "volume" to 50,
        "playing" to false
    )
) : Transport {
    override val type: TransportType = TransportType.OTHER
    override var isAvailable: Boolean = true
        private set

    private var connected = false
    private val handlers = ConcurrentHashMap<String, (ByteArray) -> DeviceResponse>()

    fun registerHandler(key: String, handler: (ByteArray) -> DeviceResponse) {
        handlers[key] = handler
    }

    override fun connect(deviceAddress: String?): Boolean {
        connected = true
        return true
    }

    override fun disconnect() {
        connected = false
    }

    override fun write(
        serviceUuid: String?,
        characteristicUuid: String?,
        payload: ByteArray,
        timeoutMs: Long
    ): DeviceResponse {
        if (!connected) return DeviceResponse(false, errorMessage = "NOT_CONNECTED")
        val key = "${serviceUuid ?: ""}:${characteristicUuid ?: ""}"
        val handler = handlers[key]
        return if (handler != null) {
            handler(payload)
        } else {
            DeviceResponse(true, payload, mapOf("ack" to true, "simulated" to true))
        }
    }

    override fun read(
        serviceUuid: String?,
        characteristicUuid: String?,
        timeoutMs: Long
    ): DeviceResponse {
        if (!connected) return DeviceResponse(false, errorMessage = "NOT_CONNECTED")
        return DeviceResponse(true, null, getObservedState())
    }

    override fun subscribe(
        serviceUuid: String?,
        characteristicUuid: String?,
        timeoutMs: Long
    ): DeviceResponse = read(serviceUuid, characteristicUuid, timeoutMs)

    override fun getObservedState(): Map<String, Any> = initialState.toMap()

    override fun discoverServices(timeoutMs: Long): List<GattServiceInfo> {
        // Simulated standard services only (public UUIDs)
        return listOf(
            GattServiceInfo(
                uuid = "0000180f-0000-1000-8000-00805f9b34fb", // Battery Service
                characteristics = listOf(
                    GattCharacteristicInfo(
                        uuid = "00002a19-0000-1000-8000-00805f9b34fb", // Battery Level
                        properties = 0x12 // READ | NOTIFY
                    )
                )
            ),
            GattServiceInfo(
                uuid = "0000180a-0000-1000-8000-00805f9b34fb", // Device Information
                characteristics = listOf(
                    GattCharacteristicInfo("00002a29-0000-1000-8000-00805f9b34fb", 0x02), // Manufacturer
                    GattCharacteristicInfo("00002a24-0000-1000-8000-00805f9b34fb", 0x02), // Model Number
                    GattCharacteristicInfo("00002a26-0000-1000-8000-00805f9b34fb", 0x02)  // Firmware
                )
            )
        )
    }

    fun setState(key: String, value: Any) {
        initialState[key] = value
    }

    fun updateState(updates: Map<String, Any>) {
        initialState.putAll(updates)
    }
}
