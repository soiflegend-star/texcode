package com.texgen.music.texwave.velocity

import android.os.SystemClock

/**
 * Thread-safe mirror of what the AUVYRR player is doing, written by the UI layer (MusicApp)
 * and read by [VelocityActivity] / [VelocityNotifier].
 */
object VelocityHost {
    data class Track(
        val id: String,
        val title: String,
        val artist: String,
        val durationMs: Long,
        val playing: Boolean,
    )

    @Volatile var track: Track? = null
        private set
    @Volatile private var positionMs: Long = 0L
    @Volatile private var positionAt: Long = 0L
    @Volatile var activityOpen: Boolean = false

    fun updateTrack(t: Track?) { track = t }

    fun updatePosition(ms: Long) {
        positionMs = ms
        positionAt = SystemClock.elapsedRealtime()
    }

    /** Position extrapolated from the last known value while playing. */
    fun position(): Long {
        val t = track ?: return positionMs
        return if (t.playing) positionMs + (SystemClock.elapsedRealtime() - positionAt) else positionMs
    }
}
