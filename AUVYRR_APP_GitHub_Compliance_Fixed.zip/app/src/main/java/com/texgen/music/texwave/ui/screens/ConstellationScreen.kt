package com.texgen.music.texwave.ui.screens

import com.texgen.music.texwave.ui.theme.Tx
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.components.drawComet
import com.texgen.music.texwave.ui.theme.seedColors
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private class CStar(
    val song: Song,
    val x: Float,          // world coordinates (0..1000 wide)
    val y: Float,
    val size: Float,       // world radius
    val color: Color,
    val cluster: Int,
    val phase: Float,
)

private class CCluster(val artist: String, val cx: Float, val cy: Float, val members: List<Int>)

/** A real star of a real constellation. x,y are 0..1 inside the figure's box. */
private class CPt(val name: String, val x: Float, val y: Float, val mag: Float, val color: Color)

private class ConFig(
    val title: String,
    val ax: Float, val ay: Float, val sx: Float, val sy: Float,
    val pts: List<CPt>,
    val links: List<Pair<Int, Int>>,
)

private val StarBlue = Color(0xFFBBD4FF)
private val StarWhite = Color(0xFFF4F1FF)
private val StarRed = Color(0xFFFF8A6A)
private val StarGold = Color(0xFFFFE2A8)

private val Figures = listOf(
    ConFig(
        "ORION", 0.04f, 0.19f, 0.30f, 0.26f,
        listOf(
            CPt("Betelgeuse", 0.30f, 0.05f, 1.0f, StarRed),
            CPt("Bellatrix", 0.78f, 0.08f, 0.7f, StarBlue),
            CPt("Alnitak", 0.38f, 0.50f, 0.7f, StarBlue),
            CPt("Alnilam", 0.52f, 0.48f, 0.8f, StarBlue),
            CPt("Mintaka", 0.66f, 0.46f, 0.6f, StarBlue),
            CPt("Saiph", 0.26f, 0.96f, 0.55f, StarBlue),
            CPt("Rigel", 0.82f, 0.94f, 1.0f, StarBlue),
        ),
        listOf(0 to 1, 0 to 2, 1 to 4, 2 to 3, 3 to 4, 2 to 5, 4 to 6),
    ),
    ConFig(
        "URSA MAJOR", 0.50f, 0.085f, 0.46f, 0.20f,
        listOf(
            CPt("Alkaid", 0.00f, 0.20f, 0.7f, StarBlue),
            CPt("Mizar", 0.16f, 0.12f, 0.7f, StarWhite),
            CPt("Alioth", 0.32f, 0.18f, 0.8f, StarWhite),
            CPt("Megrez", 0.48f, 0.32f, 0.55f, StarWhite),
            CPt("Phecda", 0.50f, 0.78f, 0.65f, StarWhite),
            CPt("Merak", 0.84f, 0.82f, 0.7f, StarWhite),
            CPt("Dubhe", 0.86f, 0.36f, 0.8f, StarGold),
        ),
        listOf(0 to 1, 1 to 2, 2 to 3, 3 to 4, 4 to 5, 5 to 6, 6 to 3),
    ),
    ConFig(
        "URSA MINOR", 0.88f, 0.22f, 0.05f, 0.05f,
        listOf(CPt("Polaris", 0f, 0f, 1.0f, StarGold)),
        emptyList(),
    ),
    ConFig(
        "CASSIOPEIA", 0.05f, 0.065f, 0.26f, 0.08f,
        listOf(
            CPt("Caph", 0.00f, 0.50f, 0.6f, StarWhite),
            CPt("Schedar", 0.25f, 0.90f, 0.75f, StarGold),
            CPt("Gamma Cassiopeiae", 0.50f, 0.40f, 0.75f, StarBlue),
            CPt("Ruchbah", 0.75f, 0.85f, 0.6f, StarWhite),
            CPt("Segin", 1.00f, 0.10f, 0.55f, StarBlue),
        ),
        listOf(0 to 1, 1 to 2, 2 to 3, 3 to 4),
    ),
    ConFig(
        "SCORPIUS", 0.52f, 0.62f, 0.40f, 0.30f,
        listOf(
            CPt("Graffias", 0.05f, 0.10f, 0.55f, StarBlue),
            CPt("Dschubba", 0.12f, 0.28f, 0.7f, StarBlue),
            CPt("Antares", 0.30f, 0.50f, 1.0f, StarRed),
            CPt("Tau Scorpii", 0.38f, 0.64f, 0.55f, StarBlue),
            CPt("Epsilon Scorpii", 0.50f, 0.80f, 0.6f, StarGold),
            CPt("Sargas", 0.72f, 0.92f, 0.6f, StarWhite),
            CPt("Shaula", 0.94f, 0.72f, 0.8f, StarBlue),
        ),
        listOf(0 to 1, 1 to 2, 2 to 3, 3 to 4, 4 to 5, 5 to 6),
    ),
    ConFig(
        "LYRA", 0.68f, 0.39f, 0.15f, 0.12f,
        listOf(
            CPt("Vega", 0.30f, 0.00f, 1.0f, StarBlue),
            CPt("Zeta Lyrae", 0.10f, 0.45f, 0.5f, StarWhite),
            CPt("Sheliak", 0.20f, 0.95f, 0.55f, StarBlue),
            CPt("Sulafat", 0.78f, 0.90f, 0.55f, StarBlue),
            CPt("Delta Lyrae", 0.72f, 0.45f, 0.5f, StarRed),
        ),
        listOf(0 to 1, 0 to 4, 1 to 4, 4 to 3, 3 to 2, 2 to 1),
    ),
    ConFig(
        "CANIS MAJOR", 0.10f, 0.74f, 0.05f, 0.05f,
        listOf(CPt("Sirius", 0f, 0f, 1.0f, StarBlue)),
        emptyList(),
    ),
)

private class Comet(val from: Offset, val to: Offset, val born: Float, val dur: Float, val lands: Boolean, val accent: Color)

/**
 * AUVYRR Constellation — your library as a night sky.
 * Every artist is its own constellation (their songs are the stars, joined by glowing lines).
 * Drag to pan, pinch to zoom, tap a star: a comet streaks in, lands on it and the song plays.
 */
@OptIn(ExperimentalTextApi::class)
@Composable
fun ConstellationScreen(
    songs: List<Song>,
    onPlay: (Song) -> Unit,
    onOpenLibrary: () -> Unit,
    currentSongId: Long? = null,
    isPlaying: Boolean = false,
    onBack: () -> Unit = {},
    onExplore: (String?) -> Unit = {},
) {
    val exploreNow by rememberUpdatedState(onExplore)
    val textMeasurer = rememberTextMeasurer()

    // ---------- build the sky ----------
    val sky = remember(songs) {
        val pool = songs.take(160)
        val byArtist = pool.groupBy { it.artist }.entries.sortedByDescending { it.value.size }
        val stars = ArrayList<CStar>()
        val clusters = ArrayList<CCluster>()
        byArtist.forEachIndexed { k, (artist, list) ->
            val ang = k * 2.3999632f
            val rad = 150f * sqrt(k + 0.35f)
            val cx = 500f + rad * cos(ang)
            val cy = 700f + rad * sin(ang) * 1.25f
            val rnd = Random(artist.hashCode())
            val idx = ArrayList<Int>()
            val spread = 42f + 22f * sqrt(list.size.toFloat())
            list.forEachIndexed { j, s ->
                val a2 = j * 2.3999632f + rnd.nextFloat() * 0.8f
                val r2 = if (list.size == 1) 0f else spread * sqrt((j + 0.6f) / list.size) * (0.7f + rnd.nextFloat() * 0.5f)
                val (c1, _) = seedColors(s.album)
                val col = Color(
                    red = 0.55f + 0.45f * c1.red,
                    green = 0.55f + 0.45f * c1.green,
                    blue = 0.65f + 0.35f * c1.blue,
                )
                idx.add(stars.size)
                stars.add(
                    CStar(
                        s, cx + r2 * cos(a2), cy + r2 * sin(a2) * 0.85f,
                        3.2f + min(s.durationMs / 60_000f, 6f) * 0.75f,
                        col, k, rnd.nextFloat() * 6.28f,
                    )
                )
            }
            clusters.add(CCluster(artist, cx, cy, idx))
        }
        stars to clusters
    }
    val stars = sky.first
    val clusters = sky.second

    val bgStars = remember {
        val r = Random(42)
        List(800) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.25f + r.nextFloat() * 0.75f, r.nextFloat() * 6.28f, r.nextFloat()) }
    }

    // Milky-Way style band of tiny stars: t along the band, offset, size, phase, tint
    val band = remember {
        val r = Random(99)
        List(520) {
            val off = (r.nextFloat() + r.nextFloat() + r.nextFloat() - 1.5f) * 0.09f
            floatArrayOf(r.nextFloat(), off, 0.35f + r.nextFloat() * 0.9f, r.nextFloat() * 6.28f, r.nextFloat())
        }
    }

    // ---------- state ----------
    var clock by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var selected by remember { mutableStateOf<CStar?>(null) }
    var comets by remember { mutableStateOf<List<Comet>>(emptyList()) }
    var bursts by remember { mutableStateOf<List<Triple<Offset, Float, Color>>>(emptyList()) } // world pos, born, color
    var viewW by remember { mutableFloatStateOf(1f) }
    var viewH by remember { mutableFloatStateOf(1f) }
    var nextAmbient by remember { mutableFloatStateOf(1.5f) }

    // world -> screen
    fun baseScale(): Float = viewW / 1000f
    fun toScreen(x: Float, y: Float): Offset =
        Offset(viewW / 2f + (x - 500f) * baseScale() * zoom + pan.x, viewH / 2f + (y - 700f) * baseScale() * zoom + pan.y)

    fun figPos(f: ConFig, p: CPt): Offset {
        val zf = 1f + (zoom - 1f) * 0.25f
        val bx = viewW * (f.ax + p.x * f.sx)
        val by = viewH * (f.ay + p.y * f.sy)
        return Offset((bx - viewW / 2f) * zf + viewW / 2f + pan.x * 0.35f, (by - viewH / 2f) * zf + viewH / 2f + pan.y * 0.35f)
    }

    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            clock += ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
            last = now
            // when a landing comet arrives, spawn the impact burst (world coordinates)
            comets.forEach { c ->
                if (c.lands && clock - c.born >= c.dur && bursts.none { abs(it.second - c.born) < 0.001f }) {
                    val wx = 500f + (c.to.x - viewW / 2f - pan.x) / (baseScale() * zoom)
                    val wy = 700f + (c.to.y - viewH / 2f - pan.y) / (baseScale() * zoom)
                    bursts = bursts + Triple(Offset(wx, wy), c.born, c.accent)
                }
            }
            if (comets.isNotEmpty()) comets = comets.filter { clock - it.born < it.dur + 0.1f }
            if (bursts.isNotEmpty()) bursts = bursts.filter { clock - it.second < 0.9f }
            if (clock > nextAmbient && viewW > 10f) {
                nextAmbient = clock + 3.5f + Random.nextFloat() * 4f
                val y0 = viewH * (0.05f + Random.nextFloat() * 0.45f)
                val from = Offset(viewW * (0.55f + Random.nextFloat() * 0.5f), y0)
                val to = Offset(from.x - viewW * (0.9f + Random.nextFloat() * 0.4f), y0 + viewH * (0.25f + Random.nextFloat() * 0.2f))
                comets = comets + Comet(from, to, clock, 1.1f, false, Color(0xFF8FF0CB))
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF060608), Color(0xFF0C0C0E), Color(0xFF18181A), Color(0xFF0E0E10), Color(0xFF060608)))),
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { centroid, panChange, zoomChange, _ ->
                        val nz = (zoom * zoomChange).coerceIn(0.6f, 4.5f)
                        // keep the point under the fingers fixed while zooming
                        val k = nz / zoom
                        val cx = centroid.x - viewW / 2f
                        val cy = centroid.y - viewH / 2f
                        pan = Offset(cx - (cx - pan.x) * k + panChange.x, cy - (cy - pan.y) * k + panChange.y)
                        zoom = nz
                    }
                }
                .pointerInput(stars) {
                    detectTapGestures { off ->
                        var best: CStar? = null
                        var bestD = 40f * density
                        for (st in stars) {
                            val p = toScreen(st.x, st.y)
                            val d = sqrt((p.x - off.x).pow(2) + (p.y - off.y).pow(2))
                            if (d < bestD) { bestD = d; best = st }
                        }
                        var figHit: String? = null
                        var figD = 30f * density
                        for (f in Figures) {
                            for (fp in f.pts) {
                                val q = figPos(f, fp)
                                val dd = sqrt((q.x - off.x).pow(2) + (q.y - off.y).pow(2))
                                if (dd < figD) { figD = dd; figHit = fp.name }
                            }
                        }
                        if (figHit != null && figD <= bestD) {
                            exploreNow(figHit)
                            return@detectTapGestures
                        }
                        best?.let { st ->
                            selected = st
                            val target = toScreen(st.x, st.y)
                            // comet comes in from the top-right, lands on the star
                            val from = Offset(target.x + viewW * 0.75f, target.y - viewH * 0.42f)
                            comets = comets + Comet(from, target, clock, 0.75f, true, st.color)
                            onPlay(st.song)
                        }
                    }
                },
        ) {
            viewW = size.width
            viewH = size.height
            val w = size.width
            val h = size.height
            val d = density

            // nebula clouds (drift very slowly, shift a little with pan for depth)
            fun cloud(col: Color, fx: Float, fy: Float, rr: Float, a: Float, par: Float) {
                val c = Offset(w * fx + pan.x * par + 30f * sin(clock * 0.15f + fx * 5f), h * fy + pan.y * par + 24f * cos(clock * 0.12f + fy * 4f))
                drawCircle(Brush.radialGradient(listOf(col.copy(alpha = a), col.copy(alpha = a * 0.3f), Color.Transparent), c, rr), rr, c)
            }
            cloud(Tx.Accent2, 0.22f, 0.22f, w * 1.15f, 0.32f, 0.10f)
            cloud(Color(0xFFFF2FC2), 0.88f, 0.52f, w * 0.95f, 0.20f, 0.14f)
            cloud(Tx.Accent, 0.38f, 0.86f, w * 1.0f, 0.18f, 0.08f)
            cloud(Tx.Accent, 0.65f, 0.30f, w * 0.7f, 0.14f, 0.12f)
            cloud(Color(0xFF222224), 0.50f, 0.55f, w * 1.3f, 0.22f, 0.06f)
            cloud(Color(0xFF2FD0FF), 0.10f, 0.62f, w * 0.65f, 0.10f, 0.11f)
            cloud(Color(0xFF3DE0B8), 0.92f, 0.12f, w * 0.55f, 0.08f, 0.09f)
            for (i in 0..6) {
                val t = i / 6f
                cloud(Color(0xFFB9A4FF), -0.1f + 1.2f * t, 0.80f - 0.55f * t, w * 0.38f, 0.10f, 0.07f)
            }
            // the galactic band
            for (b in band) {
                val bx = w * (-0.1f + 1.2f * b[0]) + pan.x * 0.07f
                val by = h * (0.80f - 0.55f * b[0] + b[1]) + pan.y * 0.07f
                val twk = 0.5f + 0.5f * sin(clock * 0.9f + b[3])
                val tint = if (b[4] < 0.4f) Color(0xFFE6DDFF) else if (b[4] < 0.75f) Color(0xFFBFD6FF) else Color(0xFFFFD3EE)
                drawCircle(tint.copy(alpha = 0.18f + 0.30f * twk), b[2] * d, Offset(bx, by))
            }
            // soft galactic core glow
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x33FFFFFF), Color(0x228A5CFF), Color.Transparent),
                    Offset(w * 0.5f + pan.x * 0.04f, h * 0.42f + pan.y * 0.04f),
                    w * 0.42f,
                ),
                w * 0.42f,
                Offset(w * 0.5f + pan.x * 0.04f, h * 0.42f + pan.y * 0.04f),
            )

            // parallax background stars
            for (s in bgStars) {
                val par = 0.05f + s[4] * 0.25f
                var x = (s[0] * w + pan.x * par) % w; if (x < 0) x += w
                var y = (s[1] * h + pan.y * par) % h; if (y < 0) y += h
                val tw = 0.45f + 0.55f * (0.5f + 0.5f * sin(clock * (1f + s[4] * 1.5f) + s[3]))
                val col = when ((s[4] * 4).toInt()) {
                    0 -> Color(0xFFE9E2FF)
                    1 -> Color(0xFFB8D4FF)
                    2 -> Color(0xFFFFD6F0)
                    else -> Color(0xFFD5FBEC)
                }
                drawCircle(col.copy(alpha = 0.6f * tw * s[2]), (0.55f + s[4] * 1.1f) * d, Offset(x, y))
                if (s[2] > 0.92f && s[4] > 0.55f) {
                    val sp = 6f * d * tw
                    drawLine(col.copy(alpha = 0.35f * tw), Offset(x - sp, y), Offset(x + sp, y), strokeWidth = 0.8f * d)
                    drawLine(col.copy(alpha = 0.35f * tw), Offset(x, y - sp), Offset(x, y + sp), strokeWidth = 0.8f * d)
                }
            }

            // real constellations (tap a star to explore it)
            val zf = 1f + (zoom - 1f) * 0.25f
            for (f in Figures) {
                for (lk in f.links) {
                    val pa = figPos(f, f.pts[lk.first])
                    val pb = figPos(f, f.pts[lk.second])
                    drawLine(Color(0xFF7FD8FF).copy(alpha = 0.14f), pa, pb, strokeWidth = 3.4f * d, cap = StrokeCap.Round)
                    drawLine(Color(0xFFCFEFFF).copy(alpha = 0.5f), pa, pb, strokeWidth = 0.9f * d, cap = StrokeCap.Round)
                }
                var minX = Float.MAX_VALUE
                var minY = Float.MAX_VALUE
                for (fp in f.pts) {
                    val p = figPos(f, fp)
                    if (p.x < minX) minX = p.x
                    if (p.y < minY) minY = p.y
                    if (p.x < -40 || p.x > w + 40 || p.y < -40 || p.y > h + 40) continue
                    val tw = 0.8f + 0.2f * sin(clock * 1.7f + fp.x * 9f + fp.y * 5f)
                    val r = (1.5f + fp.mag * 2.1f) * d * zf * tw
                    val gr = r * 7f
                    drawCircle(Brush.radialGradient(listOf(fp.color.copy(alpha = 0.75f * tw), fp.color.copy(alpha = 0.14f), Color.Transparent), p, gr), gr, p)
                    val sp = r * 4.5f
                    drawLine(Color.White.copy(alpha = 0.6f * tw), Offset(p.x - sp, p.y), Offset(p.x + sp, p.y), strokeWidth = 0.9f * d, cap = StrokeCap.Round)
                    drawLine(Color.White.copy(alpha = 0.6f * tw), Offset(p.x, p.y - sp), Offset(p.x, p.y + sp), strokeWidth = 0.9f * d, cap = StrokeCap.Round)
                    drawCircle(Color.White, r * 0.6f, p)
                    drawCircle(fp.color.copy(alpha = 0.28f + 0.2f * tw), r * 3.0f, p, style = Stroke(1f * d))
                    if (zoom > 0.7f) {
                        val lay = textMeasurer.measure(
                            fp.name,
                            TextStyle(color = Color.White.copy(alpha = 0.72f), fontSize = 9.sp, fontWeight = FontWeight.Medium),
                            maxLines = 1,
                        )
                        drawText(lay, topLeft = Offset(p.x - lay.size.width / 2f, p.y + r * 3.4f + 2f * d))
                    }
                }
                if (minX < Float.MAX_VALUE) {
                    val tl = textMeasurer.measure(
                        f.title,
                        TextStyle(color = Color(0xFF9FE8FF).copy(alpha = 0.5f), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp),
                        maxLines = 1,
                    )
                    drawText(tl, topLeft = Offset(minX, minY - 22f * d))
                }
            }

            // constellation lines
            clusters.forEach { cl ->
                val m = cl.members
                if (m.size >= 2) {
                    val accent = stars[m[0]].color
                    for (i in 0 until m.size) {
                        val a = stars[m[i]]
                        val b = stars[m[(i + 1) % m.size]]
                        if (m.size == 2 && i == 1) break
                        val pa = toScreen(a.x, a.y)
                        val pb = toScreen(b.x, b.y)
                        val al = if (selected?.cluster == a.cluster) 0.55f else 0.22f
                        drawLine(accent.copy(alpha = al * 0.5f), pa, pb, strokeWidth = 3.6f * d, cap = StrokeCap.Round)
                        drawLine(Color.White.copy(alpha = al), pa, pb, strokeWidth = 1.1f * d, cap = StrokeCap.Round)
                    }
                }
            }

            // stars
            stars.forEach { st ->
                val p = toScreen(st.x, st.y)
                if (p.x < -60 || p.x > w + 60 || p.y < -60 || p.y > h + 60) return@forEach
                val tw = 0.78f + 0.22f * sin(clock * 2.1f + st.phase)
                val r = st.size * baseScale() * zoom * d * 0.55f * tw
                val isCur = st.song.id == currentSongId
                val isSel = selected?.song?.id == st.song.id
                val glowR = r * (if (isCur) 12f else if (isSel) 9f else 7f)
                drawCircle(
                    Brush.radialGradient(
                        listOf(st.color.copy(alpha = if (isCur) 0.9f else if (isSel) 0.7f else 0.5f * tw), st.color.copy(alpha = 0.12f), Color.Transparent),
                        p, glowR,
                    ),
                    glowR, p,
                )
                // diffraction spikes on the bigger stars
                if (st.size > 5.5f || isCur || isSel) {
                    val sp = r * (if (isCur) 7f else 4.2f)
                    drawLine(Color.White.copy(alpha = 0.55f * tw), Offset(p.x - sp, p.y), Offset(p.x + sp, p.y), strokeWidth = 1f * d, cap = StrokeCap.Round)
                    drawLine(Color.White.copy(alpha = 0.55f * tw), Offset(p.x, p.y - sp), Offset(p.x, p.y + sp), strokeWidth = 1f * d, cap = StrokeCap.Round)
                }
                drawCircle(Color.White.copy(alpha = 0.95f), r * 0.55f + 1f * d, p)
                drawCircle(st.color.copy(alpha = 0.9f), r, p, style = Stroke(1.2f * d))
                if (isCur) {
                    val pr = r * (2.2f + 0.8f * sin(clock * 3.2f))
                    drawCircle(Tx.Accent2.copy(alpha = if (isPlaying) 0.8f else 0.4f), pr, p, style = Stroke(1.6f * d))
                }
                if (isSel) {
                    val pr = r * (3.2f + 0.5f * sin(clock * 4f))
                    drawCircle(Color.White.copy(alpha = 0.85f), pr, p, style = Stroke(1.4f * d))
                }
            }

            // artist labels
            if (zoom > 0.75f) {
                clusters.forEach { cl ->
                    val p = toScreen(cl.cx, cl.cy)
                    if (p.x < -80 || p.x > w + 80 || p.y < -40 || p.y > h + 40) return@forEach
                    val label = cl.artist.take(22)
                    val layout = textMeasurer.measure(
                        label,
                        TextStyle(color = Color.White.copy(alpha = if (cl.members.size > 1) 0.62f else 0.38f), fontSize = (10f + zoom * 1.5f).sp, fontWeight = FontWeight.Medium, letterSpacing = 0.8.sp),
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 1,
                    )
                    val extra = (stars[cl.members.first()].size + 22f) * baseScale() * zoom * d * 0.7f
                    drawText(layout, topLeft = Offset(p.x - layout.size.width / 2f, p.y + extra))
                }
            }

            // landing bursts
            bursts.forEach { (wp, born, col) ->
                val a = ((clock - born) / 0.9f).coerceIn(0f, 1f)
                val p = toScreen(wp.x, wp.y)
                drawCircle(col.copy(alpha = (1f - a) * 0.9f), 8f * d + a * 70f * d, p, style = Stroke((3f * (1f - a) + 0.6f) * d))
                drawCircle(Color.White.copy(alpha = (1f - a) * 0.6f), 4f * d + a * 34f * d, p, style = Stroke(1.2f * d))
                for (k in 0 until 10) {
                    val ang = k * 0.6283f + born
                    val rr = a * 46f * d
                    drawCircle(Color.White.copy(alpha = (1f - a)), (1.6f * (1f - a) + 0.4f) * d, Offset(p.x + cos(ang) * rr, p.y + sin(ang) * rr))
                }
            }

            // comets (ambient + landing)
            comets.forEach { c ->
                val t = ((clock - c.born) / c.dur).coerceIn(0f, 1f)
                val e = if (c.lands) 1f - (1f - t).pow(2.4f) else t
                val head = Offset(c.from.x + (c.to.x - c.from.x) * e, c.from.y + (c.to.y - c.from.y) * e)
                val dx = c.to.x - c.from.x
                val dy = c.to.y - c.from.y
                val len = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                val dir = Offset(dx / len, dy / len)
                val fade = if (c.lands) (if (t < 0.9f) 1f else (1f - t) * 10f) else sin(t * Math.PI.toFloat())
                drawComet(head, dir, min(len * 0.55f, w * 0.6f) * (if (c.lands) (0.35f + 0.65f * (1f - t)) else 1f), fade.coerceIn(0f, 1f), accent = c.accent)
            }
        }

        // header
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x22FFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape).clickable { onBack() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("CONSTELLATION", color = Color(0xFFB6F5DC), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.2.sp)
                Text("Your living sky", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light)
                Text(
                    "${stars.size} stars · ${clusters.size} houses · pinch to travel",
                    color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, maxLines = 1,
                )
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x22FFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape).clickable { onOpenLibrary() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.LibraryMusic, "Library", tint = Color.White) }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x3345D9FF)).border(1.dp, Color(0x6645D9FF), CircleShape).clickable { onExplore(null) },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Public, "Explore the cosmos", tint = Color(0xFFBFF3FF)) }
        }

        // selected / now playing card
        val shown = selected?.song ?: stars.firstOrNull { it.song.id == currentSongId }?.song
        if (shown != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xF2212123), Color(0xF0101012))))
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(Color(0xCC2BE4A4), Color(0x55FFFFFF), Color(0xCCB388FF))),
                        RoundedCornerShape(22.dp),
                    )
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Tx.Accent2, Tx.Accent, Tx.Accent3))),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.PlayArrow, null, tint = Color.White) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(shown.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(shown.artist, color = Color(0xFF9FE8CB), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        // glowing explore button
        val pulse = 0.5f + 0.5f * sin(clock * 2.4f)
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = if (shown != null) 108.dp else 28.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xE60E6E8F), Color(0xE65B3BD6))))
                .border(1.dp, Color.White.copy(alpha = 0.25f + 0.4f * pulse), RoundedCornerShape(26.dp))
                .clickable { onExplore(null) }
                .padding(horizontal = 22.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Public, null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("EXPLORE THE COSMOS", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }

        if (stars.isEmpty()) {
            Text(
                "Scan your library to light the sky",
                color = Color.White.copy(alpha = 0.5f),
                modifier = Modifier.align(Alignment.Center),
            )
        }
    }
}
