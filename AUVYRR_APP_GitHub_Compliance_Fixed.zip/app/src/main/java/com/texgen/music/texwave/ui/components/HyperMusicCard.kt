package com.texgen.music.texwave.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.LyricsEngine
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.formatDuration
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/**
 * HyperCard (ported from AUVYRRMusicEngine): now playing + live lyric line + draggable
 * "Up next" sequence, bound to the app's own player state.
 */
@Composable
fun HyperMusicCard(
    player: PlayerState,
    position: State<Long>,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onOpenLyrics: () -> Unit,
    onMove: (from: Int, to: Int) -> Unit,
    onRemove: (index: Int) -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val song = player.current ?: return
    val upcoming: List<Song> = remember(player.queue, player.queueIndex) {
        if (player.queueIndex < 0) emptyList() else player.queue.drop(player.queueIndex + 1).take(12)
    }

    // Lyrics are fetched in the background when a song starts; poll until they appear.
    var lyrics by remember(song.id) { mutableStateOf(LyricsEngine.cached(song.id)) }
    LaunchedEffect(song.id) {
        var tries = 0
        while (lyrics == null && tries < 20) {
            delay(1500)
            lyrics = LyricsEngine.cached(song.id)
            tries++
        }
    }
    val liveLine by remember(lyrics) {
        derivedStateOf {
            val l = lyrics
            if (l != null && l.synced) {
                val i = LyricsEngine.activeIndex(l, position.value)
                if (i >= 0) l.lines[i].text else null
            } else null
        }
    }
    val progress by remember(player.durationMs) {
        derivedStateOf {
            if (player.durationMs > 0) (position.value.toFloat() / player.durationMs).coerceIn(0f, 1f) else 0f
        }
    }

    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0x24FFFFFF), Color(0x0AFFFFFF), Tx.Surface.copy(alpha = 0.7f))))
            .border(1.dp, Brush.linearGradient(listOf(Color(0x40FFFFFF), Tx.Accent.copy(alpha = 0.3f), Color(0x14FFFFFF))), shape)
            .padding(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("NOW PLAYING", color = Tx.Accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
            if (upcoming.isNotEmpty()) {
                Text(
                    "Clear",
                    color = Tx.Muted,
                    fontSize = 12.sp,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClear).padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Cover(song.artUri, 68.dp, 14.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = Tx.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist.ifBlank { "Unknown artist" }, color = Tx.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x33FFFFFF))) {
                    Box(Modifier.fillMaxWidth(progress).height(3.dp).background(Tx.Accent))
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatDuration(position.value), color = Tx.Muted, fontSize = 10.sp)
                    Text(formatDuration(player.durationMs), color = Tx.Muted, fontSize = 10.sp)
                }
            }
        }

        // Live lyric line (only shown when real timestamps exist, and it freezes on pause)
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x14FFFFFF))
                .clickable(onClick = onOpenLyrics)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                liveLine ?: if (lyrics == null) "Tap for lyrics" else "Tap to open lyrics",
                color = if (liveLine != null) Color.White else Tx.Muted,
                fontSize = 14.sp,
                fontWeight = if (liveLine != null) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Tx.Text, modifier = Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onPrevious))
            Spacer(Modifier.width(18.dp))
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Tx.Accent, Tx.Accent3))).clickable(onClick = onToggle),
                contentAlignment = Alignment.Center,
            ) {
                Icon(if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (player.isPlaying) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(18.dp))
            Icon(Icons.Rounded.SkipNext, "Next", tint = Tx.Text, modifier = Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onNext))
        }

        Spacer(Modifier.height(14.dp))
        Text("UP NEXT", color = Tx.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.1.sp)
        Spacer(Modifier.height(6.dp))
        if (upcoming.isEmpty()) {
            Text("Your sequence is empty", color = Tx.Muted.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(vertical = 14.dp))
        } else {
            SequenceList(
                upcoming = upcoming,
                absoluteStart = player.queueIndex + 1,
                onMove = onMove,
                onRemove = onRemove,
            )
        }
    }
}

@Composable
private fun Cover(uri: String, size: androidx.compose.ui.unit.Dp, corner: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(corner)).background(Tx.SurfaceHigh),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.MusicNote, null, tint = Tx.Muted, modifier = Modifier.size(size / 2))
        AsyncImage(model = uri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(size))
    }
}

@Composable
private fun SequenceList(
    upcoming: List<Song>,
    absoluteStart: Int,
    onMove: (Int, Int) -> Unit,
    onRemove: (Int) -> Unit,
) {
    var draggingIndex by remember { mutableIntStateOf(-1) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    val rowPx = with(LocalDensity.current) { 56.dp.toPx() }

    Column(Modifier.fillMaxWidth()) {
        upcoming.forEachIndexed { index, song ->
            val dragging = draggingIndex == index
            Row(
                Modifier
                    .fillMaxWidth()
                    .zIndex(if (dragging) 10f else 0f)
                    .offset { IntOffset(0, if (dragging) dragOffsetY.roundToInt() else 0) }
                    .graphicsLayer { alpha = if (dragging) 0.92f else 1f }
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (dragging) Color(0x26FFFFFF) else Color.Transparent)
                    .pointerInput(index, upcoming.size) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { draggingIndex = index; dragOffsetY = 0f },
                            onDragEnd = {
                                if (draggingIndex >= 0) {
                                    val delta = (dragOffsetY / rowPx).roundToInt()
                                    val target = (draggingIndex + delta).coerceIn(0, upcoming.lastIndex)
                                    if (target != draggingIndex) onMove(absoluteStart + draggingIndex, absoluteStart + target)
                                }
                                draggingIndex = -1
                                dragOffsetY = 0f
                            },
                            onDragCancel = { draggingIndex = -1; dragOffsetY = 0f },
                            onDrag = { change, amount ->
                                change.consume()
                                dragOffsetY += amount.y
                            },
                        )
                    }
                    .padding(vertical = 6.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("%02d".format(index + 1), color = Tx.Muted, fontSize = 11.sp, modifier = Modifier.width(26.dp))
                Cover(song.artUri, 40.dp, 8.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = Tx.Text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = Tx.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Icon(Icons.Rounded.DragHandle, "Hold and drag to reorder", tint = Tx.Muted.copy(alpha = 0.6f), modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Icon(
                    Icons.Rounded.Close, "Remove", tint = Tx.Muted,
                    modifier = Modifier.size(28.dp).clip(CircleShape).clickable { onRemove(absoluteStart + index) }.padding(6.dp),
                )
            }
        }
    }
}
