package com.texgen.music.texwave.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Lyrics pipeline:
 *  1) LRCLIB with strict title/artist matching (never first random hit)
 *  2) Disk cache only if title+artist still match this song
 *  3) Phantom (Groq) “hears” the track metadata and returns real lyrics when known
 * Timed lines for listening highlight while the song plays.
 */
object LyricsEngine {

    data class Line(val timeMs: Long, val text: String)

    data class Lyrics(
        val songId: Long,
        val title: String,
        val artist: String,
        val plain: String,
        val lines: List<Line>,
        val source: String, // "lrclib" | "groq" | "cache"
        val synced: Boolean,
    )

    private val memory = ConcurrentHashMap<Long, Lyrics>()

    fun cached(songId: Long): Lyrics? = memory[songId]

    fun clearCache(context: Context, songId: Long) {
        memory.remove(songId)
        prefs(context).edit().remove("s_$songId").apply()
    }

    suspend fun load(
        context: Context,
        song: Song,
        groq: GroqClient?,
        forceRefresh: Boolean = false,
    ): Result<Lyrics> = withContext(Dispatchers.IO) {
        if (forceRefresh) clearCache(context, song.id)

        if (!forceRefresh) {
            memory[song.id]?.let { cached ->
                if (matchesSong(cached, song)) return@withContext Result.success(cached)
                memory.remove(song.id)
            }
            loadDisk(context, song.id)?.let { disk ->
                if (matchesSong(disk, song)) {
                    memory[song.id] = disk
                    return@withContext Result.success(disk)
                } else {
                    prefs(context).edit().remove("s_${song.id}").apply()
                }
            }
        }

        // 1) LRCLIB: exact lookup with duration, then several cleaned searches
        val fromNet = runCatching { fetchLrclib(song) }.getOrNull()
        if (fromNet != null) {
            memory[song.id] = fromNet
            persist(context, fromNet)
            return@withContext Result.success(fromNet)
        }

        // 2) lyrics.ovh: plain text only (no timestamps exist there)
        val ovh = runCatching { fetchOvh(song) }.getOrNull()
        if (ovh != null) {
            memory[song.id] = ovh
            persist(context, ovh)
            return@withContext Result.success(ovh)
        }

        // 3) Phantom / Groq listens to the track identity and writes lyrics
        if (groq != null && groq.hasKey() && NetworkGate.isOnline(context)) {
            val ai = generateWithPhantom(groq, song).getOrNull()
            if (ai != null) {
                memory[song.id] = ai
                persist(context, ai)
                return@withContext Result.success(ai)
            }
        }

        Result.failure(IllegalStateException("No lyrics found for this track"))
    }

    /** Index of the line being sung at [positionMs]; -1 before the first line. Only meaningful for synced lyrics. */
    fun activeIndex(lyrics: Lyrics, positionMs: Long): Int {
        if (!lyrics.synced || lyrics.lines.isEmpty()) return -1
        var lo = 0
        var hi = lyrics.lines.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lyrics.lines[mid].timeMs <= positionMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }

    /** Rough follow-along for lyrics WITHOUT timestamps: purely proportional to progress. */
    fun approxIndex(lyrics: Lyrics, positionMs: Long, durationMs: Long): Int {
        val n = plainLines(lyrics).size
        if (n == 0 || durationMs <= 0L) return -1
        val start = durationMs * 0.05
        val span = durationMs * 0.88
        val f = ((positionMs - start) / span).coerceIn(0.0, 0.9999)
        return (f * n).toInt().coerceIn(0, n - 1)
    }

    fun plainLines(lyrics: Lyrics): List<String> =
        lyrics.plain.lines().map { it.trim() }.filter { it.isNotBlank() }

    private fun matchesSong(lyrics: Lyrics, song: Song): Boolean {
        val tScore = similarity(norm(lyrics.title), norm(song.title))
        val aScore = when {
            song.artist.isBlank() || lyrics.artist.isBlank() -> 0.7f
            else -> similarity(norm(lyrics.artist), norm(song.artist))
        }
        return tScore >= 0.78f && aScore >= 0.50f
    }

    private fun norm(s: String): String =
        s.lowercase()
            .replace("_", " ")
            .replace("-", " ")
            .replace(Regex("""\(.*?\)|\[.*?]|\{.*?}|official|lyrics|audio|video|hd|hq|remaster(ed)?|feat\.?|ft\.?|48k|ultraslowed|slowed|reverb|nightcore"""), " ")
            .replace(Regex("""[^a-z0-9\s]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

    /** Token Jaccard + containment blend for fuzzy title match. */
    private fun similarity(a: String, b: String): Float {
        if (a.isBlank() || b.isBlank()) return 0f
        if (a == b) return 1f
        if (a.contains(b) || b.contains(a)) return 0.9f
        val ta = a.split(" ").filter { it.length > 1 }.toSet()
        val tb = b.split(" ").filter { it.length > 1 }.toSet()
        if (ta.isEmpty() || tb.isEmpty()) return 0f
        val inter = ta.intersect(tb).size.toFloat()
        val union = ta.union(tb).size.toFloat()
        return inter / union
    }

    private fun http(url: String): String? {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 12_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "AUVYRR/1.0 (Android)")
        }
        try {
            if (conn.responseCode !in 200..299) return null
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    /** Removes "(Official Video)", "[HD]", file-name junk, etc. but keeps words. */
    private fun clean(s: String): String =
        s.replace("_", " ")
            .replace(Regex("""\(.*?\)|\[.*?]|\{.*?}"""), " ")
            .replace(Regex("""(?i)\b(official|lyrics?|audio|video|music video|hd|hq|4k|remaster(ed)?|visuali[sz]er)\b"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

    private class Cand(val score: Float, val plain: String, val syncedRaw: String?)

    private fun toCand(o: JSONObject, song: Song, wantTitle: String, wantArtist: String): Cand? {
        val tName = o.optString("trackName", o.optString("name", ""))
        val aName = o.optString("artistName", "")
        val tScore = similarity(wantTitle, norm(tName))
        val aScore = if (wantArtist.isBlank()) 0.6f else similarity(wantArtist, norm(aName))
        if (tScore < 0.7f) return null
        if (wantArtist.isNotBlank() && aScore < 0.4f) return null
        var synced = o.optString("syncedLyrics", "")
        val unsynced = o.optString("plainLyrics", "")
        val candDur = (o.optDouble("duration", 0.0) * 1000).toLong()
        // A timed version from a different edit would drift away from the audio: refuse it.
        var durScore = 0f
        if (candDur > 0 && song.durationMs > 0) {
            val diff = kotlin.math.abs(candDur - song.durationMs)
            if (diff > 7_000) synced = ""
            durScore = when {
                diff <= 2_000 -> 0.25f
                diff <= 5_000 -> 0.1f
                else -> -0.1f
            }
        }
        val plain = when {
            synced.isNotBlank() -> stripLrc(synced)
            unsynced.isNotBlank() -> unsynced.trim()
            else -> return null
        }
        if (plain.isBlank()) return null
        val score = tScore * 0.5f + aScore * 0.25f + durScore + (if (synced.isNotBlank()) 0.2f else 0f)
        return Cand(score, plain, synced.takeIf { it.isNotBlank() })
    }

    private fun fetchLrclib(song: Song): Lyrics? {
        val title = clean(song.title).ifBlank { song.title.trim() }
        val artist = clean(song.artist).takeUnless { it.startsWith("Unknown", true) || it == "<unknown>" } ?: ""
        val wantTitle = norm(title)
        val wantArtist = norm(artist)
        val cands = mutableListOf<Cand>()
        val durSec = (song.durationMs / 1000).toInt()

        // exact lookup (best possible match, carries duration)
        if (artist.isNotBlank() && durSec > 0) {
            val url = "https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}" +
                (if (song.album.isNotBlank()) "&album_name=${enc(clean(song.album))}" else "") +
                "&duration=$durSec"
            http(url)?.let { body ->
                runCatching { toCand(JSONObject(body), song, wantTitle, wantArtist) }.getOrNull()?.let { cands.add(it) }
            }
        }

        val searches = mutableListOf<String>()
        if (artist.isNotBlank()) searches.add("https://lrclib.net/api/search?track_name=${enc(title)}&artist_name=${enc(artist)}")
        searches.add("https://lrclib.net/api/search?q=${enc((artist + " " + title).trim())}")
        // "Artist - Title" style names where tags are missing
        val dash = title.split(" - ", limit = 2)
        if (dash.size == 2) {
            searches.add("https://lrclib.net/api/search?track_name=${enc(dash[1].trim())}&artist_name=${enc(dash[0].trim())}")
            searches.add("https://lrclib.net/api/search?track_name=${enc(dash[0].trim())}&artist_name=${enc(dash[1].trim())}")
        }
        for (u in searches) {
            if (cands.any { it.syncedRaw != null && it.score >= 1.0f }) break
            val body = runCatching { http(u) }.getOrNull() ?: continue
            val arr = runCatching { JSONArray(body) }.getOrNull() ?: continue
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val bt = if (dash.size == 2 && wantArtist.isBlank()) norm(dash[1]) else wantTitle
                val ba = if (dash.size == 2 && wantArtist.isBlank()) norm(dash[0]) else wantArtist
                val c = toCand(o, song, bt, ba) ?: toCand(o, song, wantTitle, wantArtist)
                if (c != null) cands.add(c)
            }
        }

        val best = cands.maxByOrNull { it.score } ?: return null
        if (best.score < 0.55f) return null
        val synced = !best.syncedRaw.isNullOrBlank()
        val lines = if (synced) parseLrc(best.syncedRaw!!) else emptyList()
        val ok = synced && lines.size >= 3
        return Lyrics(
            songId = song.id,
            title = song.title,
            artist = song.artist,
            plain = best.plain,
            lines = if (ok) lines else emptyList(),
            source = "lrclib",
            synced = ok,
        )
    }

    private fun fetchOvh(song: Song): Lyrics? {
        val artist = clean(song.artist)
        val title = clean(song.title)
        if (artist.isBlank() || artist.startsWith("Unknown", true) || title.isBlank()) return null
        val body = http("https://api.lyrics.ovh/v1/${enc(artist)}/${enc(title)}") ?: return null
        val text = JSONObject(body).optString("lyrics", "")
            .replace("\r", "").lines().joinToString("\n") { it.trim() }
            .replace(Regex("""\n{3,}"""), "\n\n").trim()
        if (text.length < 40) return null
        return Lyrics(song.id, song.title, song.artist, text, emptyList(), "ovh", false)
    }

    /**
     * Phantom “hears” the song (title, artist, album, duration) and returns
     * the real lyrics for THAT track only — never a different song.
     */
    private suspend fun generateWithPhantom(groq: GroqClient, song: Song): Result<Lyrics> {
        val durationSec = (song.durationMs / 1000).coerceAtLeast(30)
        val system = """
            You are PHANTOM inside AUVYRR. You listen carefully to the track identity
            the user is playing and return lyrics for THAT song only.

            Rules:
            You are PHANTOM, the lyric listener inside AUVYRR.
            Hard rules:
            1) Lyrics MUST belong to the EXACT title and artist given. Never substitute a cover, remix, or different song with a similar name.
            2) If you know the real lyrics with high confidence, output ONLY the lyrics — one line per sung line, in performance order.
            3) If the title/artist clearly identify a known commercial song, provide the standard published lyrics.
               Only if the track is truly unknown or ambiguous, output exactly one line:
               [PHANTOM] I could not verify the lyrics for this track.
               Never invent lyrics for a different song.
            4) No timestamps, no markdown, no title headers, no "Verse 1", no commentary.
            5) Prefer the original language of the recording.
            6) When real lyrics are known: between 8 and 80 lines. Include chorus repeats if they are sung.
            7) Never mix lyrics from two different songs.
        """.trimIndent()
        val user = buildString {
            appendLine("I am listening to this track right now.")
            appendLine("Title: \"${song.title}\"")
            appendLine("Artist: ${song.artist.ifBlank { "Unknown" }}")
            appendLine("Album: ${song.album.ifBlank { "Unknown" }}")
            appendLine("Duration: ${durationSec}s")
            appendLine("Hear this song and give me its lyrics only.")
        }
        return groq.chat(system, user, maxTokens = 1200, temperature = 0.2).mapCatching { raw ->
            val text = raw
                .lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("```") }
                .joinToString("\n")
                .trim()
            if (text.length < 12) error("too short")
            if (text.contains("[PHANTOM]", ignoreCase = true) &&
                text.lines().size <= 3
            ) {
                error("Phantom could not verify lyrics for this track")
            }
            // Guard: if model echoed a different obvious title pattern, reject
            Lyrics(
                songId = song.id,
                title = song.title,
                artist = song.artist,
                plain = text,
                lines = emptyList(),
                source = "groq",
                synced = false,
            )
        }
    }

    private fun stripLrc(synced: String): String =
        synced.lines().joinToString("\n") { line ->
            line.replace(Regex("""\[\d{1,3}:\d{2}([.:]\d{1,3})?]"""), "").trim()
        }.trim()

    private val TS = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")

    private fun parseLrc(synced: String): List<Line> {
        val out = mutableListOf<Line>()
        for (raw in synced.lines()) {
            val line = raw.trim()
            val stamps = TS.findAll(line).toList()
            if (stamps.isEmpty()) continue
            val text = line.substring(stamps.last().range.last + 1).trim()
            if (text.isBlank()) continue
            for (m in stamps) {
                val min = m.groupValues[1].toLongOrNull() ?: continue
                val sec = m.groupValues[2].toLongOrNull() ?: continue
                val frac = m.groupValues[3]
                val ms = when {
                    frac.isEmpty() -> 0L
                    frac.length == 1 -> frac.toLong() * 100
                    frac.length == 2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out.add(Line(timeMs = min * 60_000 + sec * 1_000 + ms, text = text))
            }
        }
        return out.sortedBy { it.timeMs }
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("texwave_lyrics_cache", Context.MODE_PRIVATE)

    private fun persist(ctx: Context, lyrics: Lyrics) {
        val j = JSONObject()
            .put("songId", lyrics.songId)
            .put("title", lyrics.title)
            .put("artist", lyrics.artist)
            .put("plain", lyrics.plain)
            .put("source", lyrics.source)
            .put("synced", lyrics.synced)
        val arr = JSONArray()
        lyrics.lines.forEach { arr.put(JSONObject().put("t", it.timeMs).put("x", it.text)) }
        j.put("lines", arr)
        prefs(ctx).edit().putString("s_${lyrics.songId}", j.toString()).apply()
    }

    private fun loadDisk(ctx: Context, songId: Long): Lyrics? = runCatching {
        val raw = prefs(ctx).getString("s_$songId", null) ?: return null
        val j = JSONObject(raw)
        val arr = j.getJSONArray("lines")
        val synced = j.optBoolean("synced")
        val lines = if (!synced) emptyList() else (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Line(o.getLong("t"), o.getString("x"))
        }
        Lyrics(
            songId = j.getLong("songId"),
            title = j.optString("title"),
            artist = j.optString("artist"),
            plain = j.optString("plain"),
            lines = lines,
            source = j.optString("source", "cache"),
            synced = synced,
        )
    }.getOrNull()
}
