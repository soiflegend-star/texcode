package com.texgen.music.texwave.protocol.discovery

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import com.texgen.music.texwave.protocol.identity.IdentityEngine
import com.texgen.music.texwave.protocol.models.DeviceIdentity
import com.texgen.music.texwave.protocol.transport.GattServiceInfo
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Device discovery using Android Bluetooth APIs.
 * Collects evidence only — never invents model names.
 *
 * Host must hold runtime BLUETOOTH_SCAN / BLUETOOTH_CONNECT (or legacy) permissions.
 */
@SuppressLint("MissingPermission")
class DeviceDiscovery(private val context: Context) {

    data class DiscoveredDevice(
        val device: BluetoothDevice,
        val name: String?,
        val address: String,
        val rssi: Int? = null,
        val manufacturerId: Int? = null,
        val manufacturerData: ByteArray? = null,
        val serviceUuids: List<String> = emptyList(),
        val bondState: Int,
        val type: Int
    )

    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val found = ConcurrentHashMap<String, DiscoveredDevice>()

    val isBluetoothEnabled: Boolean
        get() = adapter?.isEnabled == true

    /**
     * Return currently bonded devices (no scan required).
     */
    fun getBondedDevices(): List<DiscoveredDevice> {
        val a = adapter ?: return emptyList()
        return try {
            a.bondedDevices?.map { d ->
                DiscoveredDevice(
                    device = d,
                    name = d.name,
                    address = d.address,
                    bondState = d.bondState,
                    type = d.type
                )
            } ?: emptyList()
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    /**
     * Perform a time-bounded LE scan. Returns discovered devices with advertisement evidence.
     */
    fun scanLe(timeoutMs: Long = 8000L): List<DiscoveredDevice> {
        val a = adapter ?: return emptyList()
        val scanner = a.bluetoothLeScanner ?: return emptyList()
        found.clear()

        val latch = CountDownLatch(1)
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device ?: return
                val record = result.scanRecord
                val mfgId = record?.manufacturerSpecificData?.let { sparse ->
                    if (sparse.size() > 0) sparse.keyAt(0) else null
                }
                val mfgData = mfgId?.let { record.manufacturerSpecificData.get(it) }
                val uuids = record?.serviceUuids?.map { it.uuid.toString() } ?: emptyList()
                found[d.address] = DiscoveredDevice(
                    device = d,
                    name = d.name ?: record?.deviceName,
                    address = d.address,
                    rssi = result.rssi,
                    manufacturerId = mfgId,
                    manufacturerData = mfgData,
                    serviceUuids = uuids,
                    bondState = d.bondState,
                    type = d.type
                )
            }

            override fun onScanFailed(errorCode: Int) {
                latch.countDown()
            }
        }

        return try {
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()
            scanner.startScan(null, settings, callback)
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
            scanner.stopScan(callback)
            found.values.toList()
        } catch (e: SecurityException) {
            emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Build IdentityEngine evidence from a discovered device.
     */
    fun toEvidence(
        discovered: DiscoveredDevice,
        userClaimBrand: String? = null,
        userClaimModel: String? = null
    ): IdentityEngine.RawDeviceEvidence {
        return IdentityEngine.RawDeviceEvidence(
            bluetoothName = discovered.name,
            address = discovered.address,
            serviceUuids = discovered.serviceUuids,
            manufacturerId = discovered.manufacturerId,
            manufacturerData = discovered.manufacturerData,
            userClaimBrand = userClaimBrand,
            userClaimModel = userClaimModel,
            bondState = discovered.bondState,
            type = discovered.type
        )
    }
}
