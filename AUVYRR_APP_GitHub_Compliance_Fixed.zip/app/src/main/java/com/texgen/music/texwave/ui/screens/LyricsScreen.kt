package com.texgen.music.texwave.ui.screens

import android.content.Context
import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.GroqClient
import com.texgen.music.texwave.data.LyricsEngine
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.theme.Tx

private fun offsetPrefs(ctx: Context) =
    ctx.getSharedPreferences("texwave_lyrics_offset", Context.MODE_PRIVATE)

/**
 * Full-screen lyrics. Highlight is driven by the REAL player position, so it stops when
 * playback is paused, follows seeks and tracks speed changes. Only lyrics that carry real
 * timestamps are treated as synced; others are shown as plain text (optional approximate follow).
 */
@Composable
fun LyricsScreen(
    player: PlayerState,
    position: State<Long>,
    onClose: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
) {
    val context = LocalContext.current
    val song = player.current
    val groq = remember { GroqClient(context) }
    var data by remember { mutableStateOf<LyricsEngine.Lyrics?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var approx by remember { mutableStateOf(false) }
    var offsetMs by remember { mutableLongStateOf(0L) }
    val listState = rememberLazyListState()

    LaunchedEffect(song?.id, tick) {
        val s = song ?: return@LaunchedEffect
        loading = true
        error = null
        data = null
        offsetMs = runCatching { offsetPrefs(context).getLong("o_${s.id}", 0L) }.getOrDefault(0L)
        LyricsEngine.load(context, s, groq.takeIf { it.hasKey() }, forceRefresh = tick > 0)
            .onSuccess { data = it }
            .onFailure { error = "No lyrics found for this exact track. Check the song's title and artist tags (Tags editor) and retry." }
        loading = false
    }

    val d = data
    val syncedMode = d != null && d.synced && d.lines.isNotEmpty()
    val active by remember(d, offsetMs, approx, player.durationMs) {
        derivedStateOf {
            val dd = d
            when {
                dd == null -> -1
                dd.synced && dd.lines.isNotEmpty() -> LyricsEngine.activeIndex(dd, position.value + offsetMs)
                approx -> LyricsEngine.approxIndex(dd, position.value, player.durationMs)
                else -> -1
            }
        }
    }

    LaunchedEffect(active) {
        if (active >= 0) {
            val shift = -(listState.layoutInfo.viewportSize.height / 3)
            runCatching { listState.animateScrollToItem(active, shift) }
        }
    }

    Box(Modifier.fillMaxSize().background(Tx.Bg)) {
        if (song != null) {
            val blurMod = if (Build.VERSION.SDK_INT >= 31) Modifier.blur(48.dp) else Modifier
            AsyncImage(
                model = song.artUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().then(blurMod).alpha(0.38f),
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Tx.Bg.copy(alpha = 0.55f), Tx.Bg.copy(alpha = 0.82f), Tx.Bg)),
            ),
        )
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // Header
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(song?.title ?: "Nothing playing", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(song?.artist?.ifBlank { "Unknown artist" } ?: "", color = Tx.Muted, fontSize = 13.sp, maxLines = 1)
                }
                Text(
                    "Close",
                    color = Tx.Accent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClose).padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }

            // Status chips
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (d != null) {
                    val label = when {
                        syncedMode -> "Synced to the track"
                        d.source == "groq" -> "Phantom lyrics · no timestamps"
                        else -> "Plain lyrics · no timestamps"
                    }
                    Chip(label, if (syncedMode) Tx.Accent else Tx.Muted)
                    if (syncedMode && !player.isPlaying) Chip("Paused", Tx.Muted)
                }
                Spacer(Modifier.weight(1f))
                Chip("Retry", Tx.Accent2, enabled = !loading) { tick++ }
            }
            Spacer(Modifier.height(10.dp))

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    song == null -> Center("Play a song to see its lyrics.")
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Tx.Accent, strokeWidth = 2.dp)
                            Spacer(Modifier.height(12.dp))
                            Text("Searching the internet for these lyrics…", color = Tx.Muted, fontSize = 13.sp)
                        }
                    }
                    d == null -> Center(error ?: "No lyrics found.")
                    syncedMode -> LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 24.dp, vertical = 120.dp),
                    ) {
                        itemsIndexed(d.lines) { i, line ->
                            LyricRow(
                                text = line.text,
                                state = when {
                                    i == active -> 2
                                    active >= 0 && i < active -> 1
                                    else -> 0
                                },
                                dim = !player.isPlaying,
                                onClick = { onSeek((line.timeMs - offsetMs).coerceAtLeast(0L)) },
                            )
                        }
                    }
                    else -> {
                        val lines = remember(d) { LyricsEngine.plainLines(d) }
                        Column(Modifier.fillMaxSize()) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    "This version has no timing data, so it can't be matched exactly.",
                                    color = Tx.Muted, fontSize = 11.sp, modifier = Modifier.weight(1f),
                                )
                                Chip(if (approx) "Follow: ON" else "Follow (approx.)", if (approx) Tx.Accent else Tx.Muted) { approx = !approx }
                            }
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 24.dp, vertical = 40.dp),
                            ) {
                                itemsIndexed(lines) { i, t ->
                                    LyricRow(
                                        text = t,
                                        state = if (approx && i == active) 2 else 0,
                                        dim = !player.isPlaying,
                                        onClick = {},
                                        plain = !approx,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Controls
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (syncedMode && song != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Chip("−0.5s") { offsetMs -= 500; saveOffset(context, song.id, offsetMs) }
                        Text(
                            "Sync ${if (offsetMs >= 0) "+" else ""}${"%.1f".format(offsetMs / 1000f)}s",
                            color = Tx.Muted, fontSize = 12.sp,
                        )
                        Chip("+0.5s") { offsetMs += 500; saveOffset(context, song.id, offsetMs) }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onPrevious))
                    Box(
                        Modifier.size(58.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Tx.Accent, Tx.Accent3))).clickable(onClick = onToggle),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(if (player.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (player.isPlaying) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onNext))
                }
            }
        }
    }
}

private fun saveOffset(ctx: Context, id: Long, v: Long) {
    runCatching { offsetPrefs(ctx).edit().putLong("o_$id", v).apply() }
}

@Composable
private fun LyricRow(text: String, state: Int, dim: Boolean, onClick: () -> Unit, plain: Boolean = false) {
    val on = state == 2
    val color by animateColorAsState(
        when {
            plain -> Color(0xFFE3E7FA)
            on -> if (dim) Color(0xFFD9D2F5) else Color.White
            state == 1 -> Color(0x99B8BDD6)
            else -> Color(0x66B8BDD6)
        },
        label = "lyricColor",
    )
    val scale by animateFloatAsState(if (on) 1f else 0.9f, label = "lyricScale")
    Text(
        text,
        color = color,
        fontSize = if (plain) 17.sp else 24.sp,
        fontWeight = if (on) FontWeight.Bold else FontWeight.SemiBold,
        lineHeight = if (plain) 26.sp else 32.sp,
        textAlign = TextAlign.Start,
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale; transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f) }
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp),
    )
}

@Composable
private fun Chip(label: String, tint: Color = Tx.Accent, enabled: Boolean = true, onClick: (() -> Unit)? = null) {
    val base = Modifier.clip(RoundedCornerShape(50)).background(tint.copy(alpha = 0.16f))
    Text(
        label,
        color = if (enabled) tint else tint.copy(alpha = 0.4f),
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        modifier = (if (onClick != null && enabled) base.clickable(onClick = onClick) else base)
            .padding(horizontal = 12.dp, vertical = 6.dp),
    )
}

@Composable
private fun Center(msg: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(msg, color = Tx.Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
}
