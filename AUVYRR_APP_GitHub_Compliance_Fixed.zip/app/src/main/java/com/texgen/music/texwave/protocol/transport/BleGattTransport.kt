package com.texgen.music.texwave.protocol.transport

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.texgen.music.texwave.protocol.models.DeviceResponse
import com.texgen.music.texwave.protocol.models.TransportType
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Real Android BLE GATT transport.
 *
 * Requires:
 * - Context with BLUETOOTH_CONNECT / BLUETOOTH_SCAN (API 31+) or legacy permissions
 * - A bonded or scanned BluetoothDevice
 *
 * This class performs actual GATT connect / service discovery / read / write / notify.
 * It does NOT invent proprietary UUIDs or command bytes.
 *
 * Host app is responsible for:
 * - Requesting runtime permissions
 * - Obtaining BluetoothDevice (via scan or bonded list)
 * - Lifecycle (do not leak GATT across Activities without care)
 */
@SuppressLint("MissingPermission") // Permission checks are the host app's responsibility; we fail gracefully.
class BleGattTransport(
    private val context: Context,
    private val device: BluetoothDevice
) : Transport {

    override val type: TransportType = TransportType.BLE_GATT

    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager

    private var gatt: BluetoothGatt? = null
    private val connected = AtomicBoolean(false)
    private val servicesDiscovered = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val connectLatch = AtomicReference<CountDownLatch?>(null)
    private val opLatch = AtomicReference<CountDownLatch?>(null)
    private val lastResponse = AtomicReference<DeviceResponse?>(null)
    private val discoveredServices = AtomicReference<List<GattServiceInfo>>(emptyList())

    override val isAvailable: Boolean
        get() {
            val adapter = bluetoothManager?.adapter
            return adapter != null && adapter.isEnabled
        }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                connected.set(true)
                g.discoverServices()
            } else {
                connected.set(false)
                servicesDiscovered.set(false)
            }
            connectLatch.get()?.countDown()
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                servicesDiscovered.set(true)
                val list = g.services?.map { svc ->
                    GattServiceInfo(
                        uuid = svc.uuid.toString(),
                        characteristics = svc.characteristics?.map { ch ->
                            GattCharacteristicInfo(
                                uuid = ch.uuid.toString(),
                                properties = ch.properties,
                                permissions = ch.permissions
                            )
                        } ?: emptyList()
                    )
                } ?: emptyList()
                discoveredServices.set(list)
            }
            connectLatch.get()?.countDown()
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            val value = if (status == BluetoothGatt.GATT_SUCCESS) {
                if (Build.VERSION.SDK_INT >= 33) {
                    // API 33+ uses onCharacteristicRead with value parameter in newer signatures;
                    // fall back to deprecated getter for broader compatibility.
                    @Suppress("DEPRECATION")
                    characteristic.value
                } else {
                    @Suppress("DEPRECATION")
                    characteristic.value
                }
            } else null
            lastResponse.set(
                DeviceResponse(
                    success = status == BluetoothGatt.GATT_SUCCESS,
                    rawPayload = value,
                    parsed = value?.let { mapOf("hex" to it.joinToString("") { b -> "%02x".format(b) }) },
                    errorMessage = if (status != BluetoothGatt.GATT_SUCCESS) "GATT_READ_STATUS_$status" else null
                )
            )
            opLatch.get()?.countDown()
        }

        override fun onCharacteristicWrite(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            lastResponse.set(
                DeviceResponse(
                    success = status == BluetoothGatt.GATT_SUCCESS,
                    errorMessage = if (status != BluetoothGatt.GATT_SUCCESS) "GATT_WRITE_STATUS_$status" else null
                )
            )
            opLatch.get()?.countDown()
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            @Suppress("DEPRECATION")
            val value = characteristic.value
            lastResponse.set(
                DeviceResponse(
                    success = true,
                    rawPayload = value,
                    parsed = value?.let { mapOf("notify_hex" to it.joinToString("") { b -> "%02x".format(b) }) }
                )
            )
            opLatch.get()?.countDown()
        }
    }

    override fun connect(deviceAddress: String?): Boolean {
        if (!isAvailable) return false
        val latch = CountDownLatch(2) // connection + services
        connectLatch.set(latch)
        try {
            gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            } else {
                @Suppress("DEPRECATION")
                device.connectGatt(context, false, gattCallback)
            }
            val ok = latch.await(15, TimeUnit.SECONDS)
            return ok && connected.get() && servicesDiscovered.get()
        } catch (e: SecurityException) {
            return false
        } catch (e: Exception) {
            return false
        } finally {
            connectLatch.set(null)
        }
    }

    override fun disconnect() {
        try {
            gatt?.disconnect()
            gatt?.close()
        } catch (_: Exception) {
        }
        gatt = null
        connected.set(false)
        servicesDiscovered.set(false)
    }

    override fun write(
        serviceUuid: String?,
        characteristicUuid: String?,
        payload: ByteArray,
        timeoutMs: Long
    ): DeviceResponse {
        val g = gatt ?: return DeviceResponse(false, errorMessage = "GATT_NULL")
        if (!connected.get()) return DeviceResponse(false, errorMessage = "NOT_CONNECTED")
        if (serviceUuid == null || characteristicUuid == null) {
            return DeviceResponse(false, errorMessage = "UUID_REQUIRED")
        }
        val svc = g.getService(UUID.fromString(serviceUuid))
            ?: return DeviceResponse(false, errorMessage = "SERVICE_NOT_FOUND")
        val ch = svc.getCharacteristic(UUID.fromString(characteristicUuid))
            ?: return DeviceResponse(false, errorMessage = "CHARACTERISTIC_NOT_FOUND")

        val latch = CountDownLatch(1)
        opLatch.set(latch)
        lastResponse.set(null)
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                val result = g.writeCharacteristic(ch, payload, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
                if (result != BluetoothStatusCodes.SUCCESS) {
                    return DeviceResponse(false, errorMessage = "WRITE_REJECTED_$result")
                }
            } else {
                @Suppress("DEPRECATION")
                ch.value = payload
                @Suppress("DEPRECATION")
                ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                if (!g.writeCharacteristic(ch)) {
                    return DeviceResponse(false, errorMessage = "WRITE_REJECTED")
                }
            }
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
            return lastResponse.get() ?: DeviceResponse(false, errorMessage = "TIMEOUT")
        } catch (e: SecurityException) {
            return DeviceResponse(false, errorMessage = "PERMISSION_DENIED")
        } catch (e: Exception) {
            return DeviceResponse(false, errorMessage = e.message ?: "WRITE_EXCEPTION")
        } finally {
            opLatch.set(null)
        }
    }

    override fun read(
        serviceUuid: String?,
        characteristicUuid: String?,
        timeoutMs: Long
    ): DeviceResponse {
        val g = gatt ?: return DeviceResponse(false, errorMessage = "GATT_NULL")
        if (!connected.get()) return DeviceResponse(false, errorMessage = "NOT_CONNECTED")
        if (serviceUuid == null || characteristicUuid == null) {
            return DeviceResponse(false, errorMessage = "UUID_REQUIRED")
        }
        val svc = g.getService(UUID.fromString(serviceUuid))
            ?: return DeviceResponse(false, errorMessage = "SERVICE_NOT_FOUND")
        val ch = svc.getCharacteristic(UUID.fromString(characteristicUuid))
            ?: return DeviceResponse(false, errorMessage = "CHARACTERISTIC_NOT_FOUND")

        val latch = CountDownLatch(1)
        opLatch.set(latch)
        lastResponse.set(null)
        try {
            if (!g.readCharacteristic(ch)) {
                return DeviceResponse(false, errorMessage = "READ_REJECTED")
            }
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
            return lastResponse.get() ?: DeviceResponse(false, errorMessage = "TIMEOUT")
        } catch (e: SecurityException) {
            return DeviceResponse(false, errorMessage = "PERMISSION_DENIED")
        } catch (e: Exception) {
            return DeviceResponse(false, errorMessage = e.message ?: "READ_EXCEPTION")
        } finally {
            opLatch.set(null)
        }
    }

    override fun subscribe(
        serviceUuid: String?,
        characteristicUuid: String?,
        timeoutMs: Long
    ): DeviceResponse {
        val g = gatt ?: return DeviceResponse(false, errorMessage = "GATT_NULL")
        if (!connected.get()) return DeviceResponse(false, errorMessage = "NOT_CONNECTED")
        if (serviceUuid == null || characteristicUuid == null) {
            return DeviceResponse(false, errorMessage = "UUID_REQUIRED")
        }
        val svc = g.getService(UUID.fromString(serviceUuid))
            ?: return DeviceResponse(false, errorMessage = "SERVICE_NOT_FOUND")
        val ch = svc.getCharacteristic(UUID.fromString(characteristicUuid))
            ?: return DeviceResponse(false, errorMessage = "CHARACTERISTIC_NOT_FOUND")

        try {
            g.setCharacteristicNotification(ch, true)
            // CCCD write would go here for full subscription; host/adapter supplies known CCCD UUID when evidence exists.
            return DeviceResponse(true, parsed = mapOf("notification_enabled" to true))
        } catch (e: SecurityException) {
            return DeviceResponse(false, errorMessage = "PERMISSION_DENIED")
        } catch (e: Exception) {
            return DeviceResponse(false, errorMessage = e.message ?: "SUBSCRIBE_EXCEPTION")
        }
    }

    override fun getObservedState(): Map<String, Any> {
        return mapOf(
            "connected" to connected.get(),
            "services_discovered" to servicesDiscovered.get(),
            "service_count" to (discoveredServices.get()?.size ?: 0)
        )
    }

    override fun discoverServices(timeoutMs: Long): List<GattServiceInfo> {
        return discoveredServices.get() ?: emptyList()
    }
}
