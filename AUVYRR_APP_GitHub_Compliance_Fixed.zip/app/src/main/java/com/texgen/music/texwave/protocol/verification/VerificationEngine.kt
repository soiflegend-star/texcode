package com.texgen.music.texwave.protocol.verification

import com.texgen.music.texwave.protocol.models.*

class VerificationEngine {
    fun verify(
        command: ProtocolCommand,
        observation: Observation,
        claimedExpected: Map<String, Any>? = command.expectedResponse
    ): VerificationResult {
        val expected = claimedExpected ?: command.expectedResponse

        if (!observation.response.success) {
            return VerificationResult(
                commandId = command.commandId,
                feature = command.feature,
                expected = expected,
                observed = observation.response.parsed,
                result = VerificationResultStatus.FAILED,
                confidence = 0.9,
                adapterVersion = command.adapterVersion,
                notes = observation.response.errorMessage ?: "Device response indicated failure",
                evidenceRefs = command.evidenceRefs
            )
        }

        when (command.verificationMethod) {
            VerificationMethod.NONE_AVAILABLE -> {
                return VerificationResult(
                    commandId = command.commandId,
                    feature = command.feature,
                    expected = expected,
                    observed = observation.response.parsed,
                    result = VerificationResultStatus.NOT_VERIFIABLE,
                    confidence = 0.3,
                    adapterVersion = command.adapterVersion,
                    notes = "No verification method available. Command was sent.",
                    evidenceRefs = command.evidenceRefs
                )
            }
            VerificationMethod.EXPLICIT_RESPONSE -> {
                val parsed = observation.response.parsed
                if (expected == null) {
                    return VerificationResult(
                        commandId = command.commandId, feature = command.feature,
                        expected = null, observed = parsed,
                        result = VerificationResultStatus.COMMAND_SENT_UNVERIFIED,
                        confidence = 0.4, notes = "No expected response defined",
                        evidenceRefs = command.evidenceRefs
                    )
                }
                val match = mapsMatch(expected, parsed)
                return VerificationResult(
                    commandId = command.commandId, feature = command.feature,
                    expected = expected, observed = parsed,
                    result = if (match) VerificationResultStatus.VERIFIED_WORKING else VerificationResultStatus.VERIFICATION_FAILURE,
                    confidence = if (match) 0.85 else 0.7,
                    adapterVersion = command.adapterVersion,
                    notes = if (match) "Explicit response matched" else "Explicit response mismatch",
                    evidenceRefs = command.evidenceRefs
                )
            }
            VerificationMethod.STATE_READBACK, VerificationMethod.BEFORE_AFTER -> {
                val after = observation.afterState ?: observation.response.parsed
                val before = observation.beforeState
                if (expected == null && after == null) {
                    return VerificationResult(
                        commandId = command.commandId, feature = command.feature,
                        result = VerificationResultStatus.NOT_VERIFIABLE, confidence = 0.3,
                        notes = "No state readable", evidenceRefs = command.evidenceRefs
                    )
                }
                if (expected != null && after != null) {
                    val match = mapsMatch(expected, after)
                    return VerificationResult(
                        commandId = command.commandId, feature = command.feature,
                        expected = expected, observed = after,
                        result = if (match) VerificationResultStatus.VERIFIED_WORKING else VerificationResultStatus.VERIFICATION_FAILURE,
                        confidence = if (match) 0.9 else 0.75,
                        adapterVersion = command.adapterVersion,
                        notes = if (match) "State readback matched" else "State mismatch before=$before after=$after",
                        evidenceRefs = command.evidenceRefs
                    )
                }
                if (before != null && after != null && before != after) {
                    return VerificationResult(
                        commandId = command.commandId, feature = command.feature,
                        expected = expected, observed = after,
                        result = VerificationResultStatus.PARTIALLY_SUPPORTED, confidence = 0.6,
                        notes = "State changed; exact expected not defined",
                        evidenceRefs = command.evidenceRefs
                    )
                }
                return VerificationResult(
                    commandId = command.commandId, feature = command.feature,
                    expected = expected, observed = after,
                    result = VerificationResultStatus.COMMAND_SENT_UNVERIFIED, confidence = 0.4,
                    notes = "Command acknowledged but state verification inconclusive",
                    evidenceRefs = command.evidenceRefs
                )
            }
            VerificationMethod.GATT_NOTIFY, VerificationMethod.SYSTEM_OBSERVATION -> {
                val observed = observation.response.parsed ?: observation.systemObservations
                if (observed.isNotEmpty()) {
                    return VerificationResult(
                        commandId = command.commandId, feature = command.feature,
                        expected = expected, observed = observed,
                        result = if (expected != null && mapsMatch(expected, observed))
                            VerificationResultStatus.VERIFIED_WORKING
                        else VerificationResultStatus.PARTIALLY_SUPPORTED,
                        confidence = 0.7, adapterVersion = command.adapterVersion,
                        notes = "Notification / system observation received",
                        evidenceRefs = command.evidenceRefs
                    )
                }
                return VerificationResult(
                    commandId = command.commandId, feature = command.feature,
                    result = VerificationResultStatus.COMMAND_SENT_UNVERIFIED, confidence = 0.35,
                    notes = "No notification captured", evidenceRefs = command.evidenceRefs
                )
            }
        }
    }

    private fun mapsMatch(expected: Map<String, Any>?, observed: Map<String, Any>?): Boolean {
        if (expected == null || observed == null) return false
        return expected.all { (k, v) ->
            val ov = observed[k] ?: return@all false
            when {
                v is Number && ov is Number -> v.toDouble() == ov.toDouble()
                else -> v.toString().equals(ov.toString(), ignoreCase = true)
            }
        }
    }
}
