package com.texgen.music.texwave.protocol.adapter

import com.texgen.music.texwave.protocol.models.*
import java.time.Instant

/** EXPERIMENTAL test harness only. No proprietary claims. */
class SimulatedStandardAdapter(
    override val brand: String = "SIMULATED",
    override val model: String = "Test Buds",
    override val modelFamily: String? = "Test Family"
) : DeviceAdapter {
    override val adapterId = "sim-standard-v1"
    override val version = "1.0.0-sim"
    override val status = AdapterStatus.EXPERIMENTAL
    override val protocolId = "SIMULATED_STATE_PROTOCOL"
    override val supportedFeatures = setOf("ANC", "TRANSPARENCY", "BATTERY", "VOLUME", "PLAY_PAUSE")
    override val evidenceRefs = listOf("sim-test-only")
    override val knownLimitations = listOf(
        "Purely simulated. Never claim real-device verification.",
        "No proprietary UUIDs or packets."
    )
    override val firmwareRange: String? = null

    override fun buildCommand(
        feature: String,
        operation: Operation,
        parameters: Map<String, Any>,
        target: DeviceTarget
    ): ProtocolCommand? {
        val f = feature.uppercase()
        if (f !in supportedFeatures) return null
        val safety = when (f) {
            "BATTERY" -> SafetyLevel.SAFE_READ
            else -> SafetyLevel.SAFE_CONTROL
        }
        val verification = when (f) {
            "BATTERY" -> VerificationMethod.STATE_READBACK
            else -> VerificationMethod.BEFORE_AFTER
        }
        val expected = when {
            f == "ANC" && operation == Operation.SET ->
                mapOf("anc" to ((parameters["mode"] as? String)?.uppercase() ?: "ON"))
            f == "TRANSPARENCY" && operation == Operation.SET ->
                mapOf("transparency" to ((parameters["mode"] as? String)?.uppercase() ?: "ON"))
            f == "VOLUME" && operation == Operation.SET ->
                mapOf("volume" to ((parameters["level"] as? Number)?.toInt() ?: 50))
            f == "BATTERY" && operation == Operation.GET ->
                mapOf("battery_left" to 0, "battery_right" to 0)
            else -> null
        }
        return ProtocolCommand(
            feature = f,
            operation = operation,
            parameters = parameters,
            transport = TransportType.OTHER,
            protocolId = protocolId,
            target = target,
            safetyLevel = safety,
            expectedResponse = expected,
            verificationMethod = verification,
            evidenceRefs = evidenceRefs,
            adapterVersion = version,
            timeoutMs = 2000
        )
    }

    override fun parseResponse(command: ProtocolCommand, raw: ByteArray?): Map<String, Any>? = null

    override fun claimedCapabilities(identity: DeviceIdentity): CapabilityProfile {
        val features = supportedFeatures.associateWith { f ->
            FeatureCapability(
                support = FeatureSupport.SUPPORTED,
                control = if (f == "BATTERY") ControlStatus.NONE else ControlStatus.UNVERIFIED,
                read = if (f == "BATTERY") ReadStatus.UNVERIFIED else ReadStatus.NONE,
                status = FeatureResultStatus.EXPERIMENTAL,
                notes = "Simulated claim only",
                adapterId = adapterId
            )
        }
        return CapabilityProfile(identity, Instant.now(), adapterId, features)
    }
}
