package com.texgen.music.texwave.tagger

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.texgen.music.texwave.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max

/** A possible match found on the internet. */
data class TagCandidate(
    val title: String,
    val artist: String,
    val album: String,
    val year: Int,
    val artUrl: String,
    val durationMs: Long,
    val score: Float,
    val source: String,
)

/** Looks songs up on Deezer and iTunes (both free, no key) and returns scored matches. */
object TagLookup {
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    const val CONFIDENT = 0.62f

    private fun get(url: String): String? = try {
        val req = Request.Builder().url(url).header("User-Agent", "AUVYRR-TagEditor/1.0").build()
        http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
    } catch (_: Throwable) {
        null
    }

    // ---- cleaning

    private val noise = Regex(
        "\\(.*?\\)|\\[.*?]|official|video|audio|lyrics?|lyrical|full song|hd|hq|4k|remastered|ft\\.?|feat\\.?|\\.mp3|\\.m4a|\\.flac|\\.wav",
        RegexOption.IGNORE_CASE,
    )

    fun clean(raw: String): String {
        var s = raw.replace('_', ' ').replace('-', ' ')
        s = noise.replace(s, " ")
        s = s.replace(Regex("^\\s*\\d{1,3}[ .)]+"), "")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun tokens(s: String): Set<String> =
        clean(s).lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 1 }.toSet()

    private fun overlap(a: Set<String>, b: Set<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        val inter = a.intersect(b).size.toFloat()
        return inter / max(a.size, b.size).toFloat()
    }

    private fun unknownArtist(a: String): Boolean {
        val t = a.trim().lowercase()
        return t.isEmpty() || t == "<unknown>" || t == "unknown" || t == "unknown artist"
    }

    private fun score(song: Song, title: String, artist: String, durMs: Long): Float {
        val st = tokens(song.title)
        val tScore = max(overlap(st, tokens(title)), if (st.isNotEmpty() && tokens(title).containsAll(st)) 0.9f else 0f)
        val aScore = if (unknownArtist(song.artist)) 0.5f else {
            val sa = tokens(song.artist)
            val ta = tokens(artist)
            if (sa.isEmpty()) 0.5f else max(overlap(sa, ta), if (sa.any { it in ta }) 0.7f else 0f)
        }
        val dScore = if (durMs <= 0 || song.durationMs <= 0) 0.5f else {
            val d = abs(durMs - song.durationMs)
            when {
                d <= 4000 -> 1f
                d <= 12000 -> 0.6f
                d <= 30000 -> 0.25f
                else -> 0f
            }
        }
        return tScore * 0.6f + aScore * 0.25f + dScore * 0.15f
    }

    // ---- sources

    private fun deezer(song: Song, query: String): List<TagCandidate> {
        val body = get("https://api.deezer.com/search?limit=8&q=" + URLEncoder.encode(query, "UTF-8")) ?: return emptyList()
        return try {
            val arr = JSONObject(body).optJSONArray("data") ?: return emptyList()
            val out = ArrayList<TagCandidate>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val title = o.optString("title")
                val artist = o.optJSONObject("artist")?.optString("name").orEmpty()
                val alb = o.optJSONObject("album")
                val art = alb?.optString("cover_xl").orEmpty().ifBlank { alb?.optString("cover_big").orEmpty() }
                if (title.isBlank()) continue
                val dur = o.optLong("duration", 0L) * 1000L
                out += TagCandidate(title, artist, alb?.optString("title").orEmpty(), 0, art, dur, score(song, title, artist, dur), "Deezer")
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun itunes(song: Song, query: String): List<TagCandidate> {
        val body = get("https://itunes.apple.com/search?media=music&entity=song&limit=8&term=" + URLEncoder.encode(query, "UTF-8"))
            ?: return emptyList()
        return try {
            val arr = JSONObject(body).optJSONArray("results") ?: return emptyList()
            val out = ArrayList<TagCandidate>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val title = o.optString("trackName")
                if (title.isBlank()) continue
                val artist = o.optString("artistName")
                val art = o.optString("artworkUrl100").replace("100x100bb", "600x600bb")
                val dur = o.optLong("trackTimeMillis", 0L)
                val year = o.optString("releaseDate").take(4).toIntOrNull() ?: 0
                out += TagCandidate(title, artist, o.optString("collectionName"), year, art, dur, score(song, title, artist, dur), "iTunes")
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun queryFor(song: Song): String {
        val t = clean(song.title)
        return if (unknownArtist(song.artist)) t else "$t ${clean(song.artist)}"
    }

    /** Matches from both services, best first. Blocking: call from a background dispatcher. */
    fun candidatesBlocking(song: Song): List<TagCandidate> {
        val q = queryFor(song)
        if (q.isBlank()) return emptyList()
        val all = deezer(song, q) + itunes(song, q)
        // keep the best of each distinct title+artist
        val seen = HashSet<String>()
        return all.sortedByDescending { it.score }
            .filter { seen.add(it.title.lowercase() + "|" + it.artist.lowercase()) }
            .take(6)
    }

    suspend fun candidates(song: Song): List<TagCandidate> = withContext(Dispatchers.IO) { candidatesBlocking(song) }

    /** The best match if it is confident enough to apply without asking. */
    fun best(song: Song): TagCandidate? {
        val q = queryFor(song)
        if (q.isBlank()) return null
        var list = deezer(song, q)
        var top = list.maxByOrNull { it.score }
        if (top == null || top.score < CONFIDENT) {
            list = list + itunes(song, q)
            top = list.maxByOrNull { it.score }
        }
        return if (top != null && top.score >= CONFIDENT) top else null
    }

    // ---- artwork (one small JPEG per album, shared)

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(20)

    /** Downloads, shrinks to 600 px and stores the artwork. Returns the file name, or null. */
    fun fetchArt(context: Context, url: String): String? {
        if (url.isBlank()) return null
        val name = sha(url) + ".jpg"
        val file = TagStore.artFile(name) ?: return null
        if (file.exists() && file.length() > 0) return name
        return try {
            val req = Request.Builder().url(url).header("User-Agent", "AUVYRR-TagEditor/1.0").build()
            val bytes = http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.bytes() else null } ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 600) sample *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return null
            val scaled = if (bmp.width > 600) {
                Bitmap.createScaledBitmap(bmp, 600, (bmp.height * 600f / bmp.width).toInt().coerceAtLeast(1), true)
            } else bmp
            file.parentFile?.mkdirs()
            FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            if (scaled !== bmp) scaled.recycle()
            bmp.recycle()
            name
        } catch (_: Throwable) {
            null
        }
    }

    suspend fun fetchArtAsync(context: Context, url: String): String? = withContext(Dispatchers.IO) { fetchArt(context, url) }
}
