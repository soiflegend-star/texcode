package com.texgen.music.texwave.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.BroadcastReceiver
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.texgen.music.texwave.earbuds.EarbudsHub
import com.texgen.music.texwave.protocol.models.FeatureSupport
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.glassCard
import kotlinx.coroutines.launch

/** Feature rows shown for every device: what is really available vs. what needs a model adapter. */
private data class FeatureRow(val key: String, val label: String, val mode: String?)

private val FEATURES = listOf(
    FeatureRow("ANC", "Noise cancellation", "ON"),
    FeatureRow("TRANSPARENCY", "Transparency / ambient", "ON"),
    FeatureRow("EQ", "Earbud EQ presets", "DEFAULT"),
    FeatureRow("GESTURES", "Touch gestures", "DEFAULT"),
    FeatureRow("IN_EAR", "In-ear detection", "ON"),
    FeatureRow("FIND", "Find my buds", "ON"),
)

@Composable
fun EarbudsScreen(
    onBack: () -> Unit,
    isPlaying: Boolean = false,
    onToggle: () -> Unit = {},
    onNext: () -> Unit = {},
    onPrevious: () -> Unit = {},
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(EarbudsHub.hasPermission(context)) }
    var buds by remember { mutableStateOf(EarbudsHub.listBuds(context)) }
    var probing by remember { mutableStateOf<String?>(null) }
    var probe by remember { mutableStateOf<EarbudsHub.Probe?>(null) }
    var probedName by remember { mutableStateOf("") }
    val results = remember { mutableStateMapOf<String, String>() }
    val liveBattery = remember { mutableStateMapOf<String, Int>() }
    val charOut = remember { mutableStateMapOf<String, String>() }
    var writeTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var writeHex by remember { mutableStateOf("") }
    var showServices by remember { mutableStateOf(false) }
    var rfStatus by remember { mutableStateOf("") }
    var rfHex by remember { mutableStateOf("") }
    var rfAddress by remember { mutableStateOf("") }
    var probedAddress by remember { mutableStateOf("") }
    val vol0 = remember { EarbudsHub.volume(context) }
    var volume by remember { mutableStateOf(vol0.first.toFloat()) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = EarbudsHub.hasPermission(context)
        buds = EarbudsHub.listBuds(context)
    }

    // refresh list while the screen is open (connect/disconnect changes)
    LaunchedEffect(granted) {
        while (granted) {
            buds = EarbudsHub.listBuds(context)
            kotlinx.coroutines.delay(4000)
        }
    }

    // live battery pushes from the system
    DisposableEffect(granted) {
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                val dev = i?.getParcelableExtra<android.bluetooth.BluetoothDevice>("android.bluetooth.device.extra.DEVICE")
                val lvl = i?.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1) ?: -1
                if (dev != null && lvl in 0..100) liveBattery[dev.address] = lvl
            }
        }
        val reg = runCatching {
            ContextCompat.registerReceiver(
                context, rx, IntentFilter("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"),
                ContextCompat.RECEIVER_EXPORTED,
            )
        }.isSuccess
        onDispose { if (reg) runCatching { context.unregisterReceiver(rx) } }
    }
    DisposableEffect(Unit) { onDispose { EarbudsHub.release() } }

    Box(Modifier.fillMaxSize().background(Tx.Bg)) {
        LazyColumn(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Earbuds", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("Connect, identify and sync your earbuds", color = Tx.Muted, fontSize = 13.sp)
                    }
                    Text(
                        "Close", color = Tx.Accent, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onBack).padding(12.dp, 8.dp),
                    )
                }
            }

            if (granted && buds.any { it.connected }) {
                item {
                    Card {
                        Text("Controls", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Pill("Previous") { onPrevious() }
                            Pill(if (isPlaying) "Pause" else "Play") { onToggle() }
                            Pill("Next") { onNext() }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Earbud volume ${volume.toInt()}/${vol0.second}", color = Tx.Muted, fontSize = 12.sp)
                        androidx.compose.material3.Slider(
                            value = volume,
                            onValueChange = { volume = it; EarbudsHub.setVolume(context, it.toInt()) },
                            valueRange = 0f..vol0.second.toFloat().coerceAtLeast(1f),
                        )
                        EarbudsHub.spatialStatus(context)?.let {
                            Text("Spatial audio (system): $it", color = Tx.Muted, fontSize = 12.sp)
                        }
                    }
                }
            }

            if (!granted) {
                item {
                    Card {
                        Text("Bluetooth permission needed", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("Allow nearby devices so AUVYRR can see your paired earbuds.", color = Tx.Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        Pill("Allow") { permLauncher.launch(EarbudsHub.requiredPermissions()) }
                    }
                }
            } else if (!EarbudsHub.bluetoothOn(context)) {
                item { Card { Text("Bluetooth is off. Turn it on and connect your earbuds.", color = Tx.Muted, fontSize = 14.sp) } }
            } else if (buds.isEmpty()) {
                item { Card { Text("No paired devices found. Pair your earbuds in system Bluetooth settings first.", color = Tx.Muted, fontSize = 14.sp) } }
            } else {
                items(buds, key = { it.address }) { b ->
                    val bat = liveBattery[b.address] ?: b.battery
                    Card {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(b.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
                                Text(
                                    (if (b.connected) "Connected" else "Paired") + (bat?.let { " · battery $it%" } ?: ""),
                                    color = if (b.connected) Tx.Accent else Tx.Muted, fontSize = 12.sp,
                                )
                            }
                            if (probing == b.address) {
                                CircularProgressIndicator(color = Tx.Accent, strokeWidth = 2.dp, modifier = Modifier.height(22.dp))
                            } else {
                                Pill("Connect & scan") {
                                    probing = b.address
                                    probedName = b.name
                                    probedAddress = b.address
                                    results.clear()
                                    scope.launch {
                                        probe = EarbudsHub.probe(context, b.address)
                                        probing = null
                                    }
                                }
                            }
                        }
                    }
                }
            }

            probe?.let { p ->
                item {
                    Card {
                        Text(probedName, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(p.message, color = if (p.reachedGatt) Tx.Accent else Tx.Muted, fontSize = 13.sp)
                        p.identity?.let {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Identity: ${it.brand} ${it.model} · confidence ${(it.confidence * 100).toInt()}% · ${it.status.name.lowercase()}",
                                color = Tx.Muted, fontSize = 12.sp,
                            )
                        }
                        p.info.forEach { (k, v) -> Text("$k: $v", color = Tx.Muted, fontSize = 12.sp) }
                        p.gattBattery?.let { Text("Battery (GATT): $it%", color = Tx.Muted, fontSize = 12.sp) }
                        if (p.reachedGatt) {
                            Spacer(Modifier.height(10.dp))
                            Pill("Copy GATT map") {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("GATT map", p.dump()))
                                android.widget.Toast.makeText(context, "GATT map copied", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
                item {
                    Card {
                        Text("What this device advertises", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text("Profiles: " + (if (p.profiles.isEmpty()) "none reported" else p.profiles.joinToString(" · ")), color = Tx.Muted, fontSize = 12.sp)
                        Text("Class: ${p.deviceClass.ifEmpty { "unknown" }}", color = Tx.Muted, fontSize = 12.sp)
                        p.vendorHint?.let { Text("Recognised: $it", color = Tx.Accent, fontSize = 12.sp) }
                        if (p.classicUuids.isNotEmpty()) {
                            Text("Control services (${p.classicUuids.size}):", color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                            p.classicUuids.forEach { u ->
                                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(u, color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                    Pill("Open") {
                                        rfAddress = probedAddress
                                        rfStatus = "Connecting…"
                                        scope.launch { rfStatus = EarbudsHub.rfcommOpen(context, probedAddress, u) }
                                    }
                                }
                            }
                        } else {
                            Text("No extra control services found, so only standard audio controls exist for this model.", color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                        if (rfStatus.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text(rfStatus, color = Tx.Accent, fontSize = 12.sp)
                            if (rfAddress.isNotEmpty() && !rfStatus.startsWith("Could not") && rfStatus != "Connecting…" && rfStatus != "Not connected") {
                                androidx.compose.material3.OutlinedTextField(
                                    value = rfHex, onValueChange = { rfHex = it }, singleLine = true,
                                    label = { Text("Hex bytes to send") }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                )
                                Spacer(Modifier.height(6.dp))
                                Pill("Send") {
                                    val d = rfHex
                                    rfStatus = "Sending…"
                                    scope.launch { rfStatus = EarbudsHub.rfcommSend(d) }
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Pill("Copy full device report") {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("Device report", p.dump()))
                            android.widget.Toast.makeText(context, "Report copied", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                val supportedRows = FEATURES.filter { p.capability?.features?.get(it.key)?.support == FeatureSupport.SUPPORTED }
                val missing = FEATURES.filter { it !in supportedRows }
                if (supportedRows.isNotEmpty()) {
                    item { Text("EARBUD FEATURES", color = Tx.Muted, fontSize = 11.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.SemiBold) }
                    items(supportedRows, key = { it.key }) { f ->
                        Card {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(f.label, color = Color.White, fontWeight = FontWeight.Medium)
                                    Text(results[f.key] ?: "Ready", color = Tx.Muted, fontSize = 12.sp)
                                }
                                Pill("Activate") {
                                    results[f.key] = "Working…"
                                    scope.launch {
                                        val r = EarbudsHub.activate(f.key, f.mode ?: "ON")
                                        results[f.key] = r.text
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    Card {
                        Text("Not available on this device", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (missing.isEmpty()) "Nothing missing." else missing.joinToString(" · ") { it.label } +
                                "\nThese are not detected, so they are disabled instead of faked.",
                            color = Tx.Muted, fontSize = 12.sp, lineHeight = 17.sp,
                        )
                    }
                }
                if (p.reachedGatt) {
                    item {
                        Card {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Device services", color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text("${p.services.size} found. Read or write anything the earbuds expose.", color = Tx.Muted, fontSize = 12.sp)
                                }
                                Pill(if (showServices) "Hide" else "Show") { showServices = !showServices }
                            }
                        }
                    }
                    if (showServices) {
                        p.services.forEach { svc ->
                            item(key = "svc_" + svc.uuid) {
                                Text(svc.uuid, color = Tx.Accent, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                            }
                            items(svc.characteristics, key = { svc.uuid + it.uuid }) { ch ->
                                val k = svc.uuid + "/" + ch.uuid
                                val canRead = ch.properties and 0x02 != 0
                                val canWrite = ch.properties and 0x0C != 0
                                Card {
                                    Text(ch.uuid, color = Color.White, fontSize = 12.sp)
                                    Text(
                                        listOfNotNull(
                                            "read".takeIf { canRead }, "write".takeIf { canWrite },
                                            "notify".takeIf { ch.properties and 0x30 != 0 },
                                        ).joinToString(" · ").ifEmpty { "no access" },
                                        color = Tx.Muted, fontSize = 11.sp,
                                    )
                                    charOut[k]?.let { Text(it, color = Tx.Accent, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
                                    if (canRead || canWrite) {
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            if (canRead) Pill("Read") {
                                                charOut[k] = "Reading…"
                                                scope.launch { charOut[k] = EarbudsHub.readChar(svc.uuid, ch.uuid) }
                                            }
                                            if (canWrite) Pill("Write") { writeHex = ""; writeTarget = svc.uuid to ch.uuid }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    Text(
                        "Only what your earbuds really expose is shown. Writing unknown values to device services can change settings or misbehave, so only write values you know.",
                        color = Tx.Muted, fontSize = 12.sp, lineHeight = 17.sp,
                    )
                }
            }
        }
        writeTarget?.let { (svc, ch) ->
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { writeTarget = null },
                title = { Text("Write to device") },
                text = {
                    Column {
                        Text("Hex bytes, for example 01 0a. This sends data straight to your earbuds.", fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        androidx.compose.material3.OutlinedTextField(value = writeHex, onValueChange = { writeHex = it }, singleLine = true)
                    }
                },
                confirmButton = {
                    androidx.compose.material3.TextButton(onClick = {
                        val k = "$svc/$ch"
                        val data = writeHex
                        writeTarget = null
                        charOut[k] = "Writing…"
                        scope.launch { charOut[k] = EarbudsHub.writeChar(svc, ch, data) }
                    }) { Text("Send") }
                },
                dismissButton = { androidx.compose.material3.TextButton(onClick = { writeTarget = null }) { Text("Cancel") } },
            )
        }
    }
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().glassCard(20).padding(16.dp)) { content() }
}

@Composable
private fun Pill(label: String, onClick: () -> Unit) {
    Text(
        label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(Tx.Accent.copy(alpha = 0.35f)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
    )
}
