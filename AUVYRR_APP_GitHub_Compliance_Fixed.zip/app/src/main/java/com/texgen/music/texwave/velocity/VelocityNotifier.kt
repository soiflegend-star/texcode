package com.texgen.music.texwave.velocity

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Heads-up "Open Velocity" prompt shown while a song plays. */
object VelocityNotifier {
    private const val CHANNEL = "velocity_prompt"
    private const val ID = 4207
    private const val PREFS = "texwave_velocity"
    private const val MIN_GAP_MS = 5 * 60_000L

    fun enabled(ctx: Context): Boolean =
        runCatching { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("prompt", true) }.getOrDefault(true)

    fun setEnabled(ctx: Context, on: Boolean) {
        runCatching { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("prompt", on).apply() }
        if (!on) dismiss(ctx)
    }

    /** Shows the prompt at most once every few minutes so skipping tracks never spams. */
    fun maybeShow(ctx: Context, songTitle: String) {
        if (!enabled(ctx) || VelocityHost.activityOpen) return
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - sp.getLong("last", 0L) < MIN_GAP_MS) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        sp.edit().putLong("last", now).apply()
        show(ctx, songTitle)
    }

    private fun show(ctx: Context, songTitle: String) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Velocity", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Race your song in Velocity"
            ctx.getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, VelocityActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Open Velocity")
            .setContentText("Race \"$songTitle\" — your song becomes the track")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setTimeoutAfter(15_000)
            .addAction(0, "OPEN VELOCITY", open)
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(ID, n) }
    }

    fun dismiss(ctx: Context) {
        runCatching { NotificationManagerCompat.from(ctx).cancel(ID) }
    }
}
