package com.texgen.music.texwave.protocol.adapter

import com.texgen.music.texwave.protocol.models.*
import java.util.concurrent.ConcurrentHashMap

class AdapterRegistry {
    private val adapters = ConcurrentHashMap<String, DeviceAdapter>()
    private val byModel = ConcurrentHashMap<String, MutableList<String>>()

    fun register(adapter: DeviceAdapter) {
        adapters[adapter.adapterId] = adapter
        val key = modelKey(adapter.brand, adapter.model)
        byModel.computeIfAbsent(key) { mutableListOf() }.add(adapter.adapterId)
        adapter.modelFamily?.let { family ->
            byModel.computeIfAbsent(modelKey(adapter.brand, family)) { mutableListOf() }.add(adapter.adapterId)
        }
    }

    fun unregister(adapterId: String) {
        adapters.remove(adapterId)?.let { ad ->
            byModel[modelKey(ad.brand, ad.model)]?.remove(adapterId)
            ad.modelFamily?.let { byModel[modelKey(ad.brand, it)]?.remove(adapterId) }
        }
    }

    fun selectAdapter(identity: DeviceIdentity, preferVerified: Boolean = true): AdapterSelectionResult {
        val candidates = mutableListOf<DeviceAdapter>()
        val exactKey = modelKey(identity.brand, identity.model)
        byModel[exactKey]?.forEach { id -> adapters[id]?.let { candidates.add(it) } }

        if (candidates.isEmpty()) {
            byModel.entries.filter { it.key.startsWith(identity.brand.lowercase() + "/") }
                .forEach { (_, ids) -> ids.forEach { id -> adapters[id]?.let { candidates.add(it) } } }
        }

        if (candidates.isEmpty()) {
            return AdapterSelectionResult(null, "NO_ADAPTER_REGISTERED", 0.0, 0)
        }

        val fwCompatible = if (identity.firmware != null) {
            candidates.filter { it.isFirmwareCompatible(identity.firmware) }
        } else candidates

        val pool = if (fwCompatible.isNotEmpty()) fwCompatible else candidates
        val ranked = pool.sortedWith(
            compareByDescending<DeviceAdapter> {
                when (it.status) {
                    AdapterStatus.PRODUCTION -> 5
                    AdapterStatus.VERIFIED -> 4
                    AdapterStatus.TESTED -> 3
                    AdapterStatus.EXPERIMENTAL -> 2
                    AdapterStatus.RESEARCH -> 1
                    else -> 0
                }
            }.thenByDescending { it.priority }
        )

        val best = if (preferVerified) {
            ranked.firstOrNull { it.status == AdapterStatus.PRODUCTION || it.status == AdapterStatus.VERIFIED }
                ?: ranked.firstOrNull { it.status == AdapterStatus.TESTED }
                ?: ranked.firstOrNull()
        } else ranked.firstOrNull()

        return if (best != null) {
            val conf = when (best.status) {
                AdapterStatus.PRODUCTION, AdapterStatus.VERIFIED -> 0.9
                AdapterStatus.TESTED -> 0.7
                AdapterStatus.EXPERIMENTAL -> 0.4
                else -> 0.2
            }
            AdapterSelectionResult(best, "MATCHED_${best.status}", conf, pool.size)
        } else AdapterSelectionResult(null, "NO_SUITABLE_ADAPTER", 0.0, pool.size)
    }

    fun getAdapter(adapterId: String): DeviceAdapter? = adapters[adapterId]
    fun listAdapters(statusFilter: AdapterStatus? = null): List<DeviceAdapter> =
        adapters.values.filter { statusFilter == null || it.status == statusFilter }.toList()

    private fun modelKey(brand: String, model: String) =
        "${brand.lowercase().trim()}/${model.lowercase().trim()}"
}

data class AdapterSelectionResult(
    val adapter: DeviceAdapter?,
    val reason: String,
    val confidence: Double,
    val candidatesConsidered: Int
)

interface DeviceAdapter {
    val adapterId: String
    val version: String
    val brand: String
    val model: String
    val modelFamily: String?
    val status: AdapterStatus
    val protocolId: String
    val supportedFeatures: Set<String>
    val priority: Int get() = 0
    val evidenceRefs: List<String>
    val knownLimitations: List<String>
    val firmwareRange: String?

    fun isFirmwareCompatible(firmware: String?): Boolean {
        val range = firmwareRange
        if (range == null || firmware == null) return true
        return range == firmware || range.contains(firmware)
    }

    fun buildCommand(
        feature: String,
        operation: Operation,
        parameters: Map<String, Any> = emptyMap(),
        target: DeviceTarget = DeviceTarget.BOTH
    ): ProtocolCommand?

    fun parseResponse(command: ProtocolCommand, raw: ByteArray?): Map<String, Any>?
    fun claimedCapabilities(identity: DeviceIdentity): CapabilityProfile
}
