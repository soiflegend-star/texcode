package com.texgen.music.texwave.protocol.knowledge

import com.texgen.music.texwave.protocol.models.*
import java.io.File
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap

class KnowledgeStore(private val rootDir: File? = null) {
    private val knowledge = ConcurrentHashMap<String, ProtocolKnowledge>()
    private val failures = ConcurrentHashMap<String, FailureRecord>()
    private val evidence = ConcurrentHashMap<String, EvidenceRecord>()

    fun put(item: ProtocolKnowledge) {
        knowledge[item.knowledgeId] = item
        persist(item)
    }

    fun get(id: String): ProtocolKnowledge? = knowledge[id]

    fun findByDevice(brand: String, model: String): List<ProtocolKnowledge> =
        knowledge.values.filter {
            it.deviceIdentity.brand.equals(brand, true) &&
                    it.deviceIdentity.model.equals(model, true)
        }

    fun findBestForIdentity(identity: DeviceIdentity): ProtocolKnowledge? =
        knowledge.values
            .filter {
                it.deviceIdentity.brand.equals(identity.brand, true) &&
                        (it.deviceIdentity.model.equals(identity.model, true) ||
                                identity.model.contains(it.deviceIdentity.model, true))
            }
            .maxByOrNull {
                when (it.promotionState) {
                    KnowledgePromotionState.PRODUCTION -> 5
                    KnowledgePromotionState.VERIFIED -> 4
                    KnowledgePromotionState.TESTED -> 3
                    KnowledgePromotionState.EXPERIMENTAL -> 2
                    KnowledgePromotionState.RESEARCHED -> 1
                }
            }

    fun recordFailure(failure: FailureRecord) {
        failures[failure.failureId] = failure
        findByDevice(failure.deviceBrand, failure.deviceModel).forEach { k ->
            put(k.copy(failures = k.failures + failure, updatedAt = Instant.now()))
        }
    }

    fun getFailures(brand: String? = null, model: String? = null): List<FailureRecord> =
        failures.values.filter {
            (brand == null || it.deviceBrand.equals(brand, true)) &&
                    (model == null || it.deviceModel.equals(model, true))
        }

    fun putEvidence(ev: EvidenceRecord) { evidence[ev.id] = ev }
    fun getEvidence(id: String): EvidenceRecord? = evidence[id]

    fun promote(knowledgeId: String, to: KnowledgePromotionState, verification: VerificationResult? = null): ProtocolKnowledge? {
        val current = knowledge[knowledgeId] ?: return null
        if (!isValidTransition(current.promotionState, to)) return null
        val updated = current.copy(
            promotionState = to,
            testHistory = if (verification != null) current.testHistory + verification else current.testHistory,
            updatedAt = Instant.now()
        )
        put(updated)
        return updated
    }

    private fun isValidTransition(from: KnowledgePromotionState, to: KnowledgePromotionState): Boolean {
        val order = listOf(
            KnowledgePromotionState.RESEARCHED,
            KnowledgePromotionState.EXPERIMENTAL,
            KnowledgePromotionState.TESTED,
            KnowledgePromotionState.VERIFIED,
            KnowledgePromotionState.PRODUCTION
        )
        val fi = order.indexOf(from)
        val ti = order.indexOf(to)
        return ti == fi + 1 || from == to
    }

    private fun persist(item: ProtocolKnowledge) {
        rootDir ?: return
        try {
            val dir = File(rootDir, "knowledge")
            dir.mkdirs()
            File(dir, "${item.knowledgeId}.txt").writeText(
                "id=${item.knowledgeId}\nbrand=${item.deviceIdentity.brand}\nmodel=${item.deviceIdentity.model}\nstate=${item.promotionState}\n"
            )
        } catch (_: Exception) {}
    }

    fun allKnowledge(): List<ProtocolKnowledge> = knowledge.values.toList()
}
