package com.texgen.music.texwave.tagger

import android.content.Context
import android.media.MediaScannerConnection
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import org.jaudiotagger.tag.images.ArtworkFactory
import java.io.File
import java.util.logging.Level
import java.util.logging.Logger

/** Writes title, artist, album, year and artwork into the real audio file (MP3, M4A, FLAC, OGG and more). */
object TagWriter {
    private val lock = Any()

    init {
        try {
            Logger.getLogger("org.jaudiotagger").level = Level.OFF
        } catch (_: Throwable) {
        }
    }

    /** Returns null on success, or a short reason on failure. */
    fun write(
        context: Context,
        path: String,
        title: String,
        artist: String,
        album: String,
        year: Int,
        art: File?,
    ): String? {
        if (path.isBlank()) return "No file path"
        val file = File(path)
        if (!file.exists()) return "File not found"
        if (!StoragePerm.granted(context)) return "No file access"
        return try {
            synchronized(lock) {
                val audio = AudioFileIO.read(file)
                val tag = audio.tagOrCreateAndSetDefault
                if (title.isNotBlank()) tag.setField(FieldKey.TITLE, title)
                if (artist.isNotBlank()) tag.setField(FieldKey.ARTIST, artist)
                if (album.isNotBlank()) tag.setField(FieldKey.ALBUM, album)
                if (year > 0) tag.setField(FieldKey.YEAR, year.toString())
                if (art != null && art.exists() && art.length() > 0) {
                    val cover = ArtworkFactory.getNew()
                    cover.binaryData = art.readBytes()
                    cover.mimeType = "image/jpeg"
                    cover.pictureType = 3
                    tag.deleteArtworkField()
                    tag.setField(cover)
                }
                audio.commit()
            }
            try {
                MediaScannerConnection.scanFile(context.applicationContext, arrayOf(path), null, null)
            } catch (_: Throwable) {
            }
            null
        } catch (t: Throwable) {
            t.message?.take(80) ?: t.javaClass.simpleName
        }
    }
}
