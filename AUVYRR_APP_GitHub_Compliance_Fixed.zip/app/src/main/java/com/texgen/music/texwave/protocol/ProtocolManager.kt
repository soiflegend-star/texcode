package com.texgen.music.texwave.protocol

import com.texgen.music.texwave.protocol.adapter.*
import com.texgen.music.texwave.protocol.execution.ExecutionEngine
import com.texgen.music.texwave.protocol.identity.IdentityEngine
import com.texgen.music.texwave.protocol.knowledge.KnowledgeStore
import com.texgen.music.texwave.protocol.models.*
import com.texgen.music.texwave.protocol.safety.SafetyGate
import com.texgen.music.texwave.protocol.transport.SimulatedTransport
import com.texgen.music.texwave.protocol.transport.Transport
import com.texgen.music.texwave.protocol.verification.VerificationEngine
import java.time.Instant

/**
 * Central orchestrator for the AUVYRR protocol layer.
 * Integrate as a singleton similar to BrainManager in the host Texwave app.
 */
class ProtocolManager(
    private val knowledgeStore: KnowledgeStore = KnowledgeStore(),
    private val identityEngine: IdentityEngine = IdentityEngine(),
    private val adapterRegistry: AdapterRegistry = AdapterRegistry(),
    private val executionEngine: ExecutionEngine = ExecutionEngine(),
    private val safetyGate: SafetyGate = SafetyGate()
) {
    private var activeTransport: Transport = SimulatedTransport()
    private var lastIdentity: DeviceIdentity? = null
    private var lastCapability: CapabilityProfile? = null

    init {
        adapterRegistry.register(SimulatedStandardAdapter())
    }

    fun setTransport(transport: Transport, connect: Boolean = true) {
        activeTransport = transport
        if (connect) {
            try { transport.connect(null) } catch (_: Exception) {}
        }
    }

    fun getTransport(): Transport = activeTransport
    fun getRegistry(): AdapterRegistry = adapterRegistry
    fun getKnowledgeStore(): KnowledgeStore = knowledgeStore
    fun getLastIdentity(): DeviceIdentity? = lastIdentity

    fun identify(evidence: IdentityEngine.RawDeviceEvidence): DeviceIdentity {
        val identity = identityEngine.identify(evidence)
        lastIdentity = identity
        knowledgeStore.findBestForIdentity(identity)?.let { known ->
            if (known.deviceIdentity.confidence > identity.confidence) {
                lastIdentity = known.deviceIdentity
                return known.deviceIdentity
            }
        }
        return identity
    }

    fun resolveCapabilities(identity: DeviceIdentity? = null): CapabilityProfile {
        val id = identity ?: lastIdentity ?: return emptyCapability()
        val selection = adapterRegistry.selectAdapter(id)
        val ad = selection.adapter
        val profile = if (ad != null) {
            ad.claimedCapabilities(id)
        } else {
            CapabilityProfile(
                deviceIdentity = id,
                generatedAt = Instant.now(),
                adapterId = null,
                features = mapOf(
                    "ANC" to FeatureCapability(
                        support = FeatureSupport.UNKNOWN,
                        control = ControlStatus.RESEARCH_REQUIRED,
                        read = ReadStatus.NONE,
                        status = FeatureResultStatus.RESEARCH_REQUIRED,
                        notes = "No adapter registered"
                    ),
                    "BATTERY" to FeatureCapability(
                        support = FeatureSupport.UNKNOWN,
                        control = ControlStatus.NONE,
                        read = ReadStatus.UNVERIFIED,
                        status = FeatureResultStatus.RESEARCH_REQUIRED,
                        notes = "Standard Battery Service may exist; requires observation"
                    )
                )
            )
        }
        lastCapability = profile
        return profile
    }

    fun executeFeature(
        feature: String,
        operation: Operation,
        parameters: Map<String, Any> = emptyMap(),
        target: DeviceTarget = DeviceTarget.BOTH,
        userConfirmed: Boolean = false,
        identity: DeviceIdentity? = lastIdentity
    ): ExecutionEngine.ExecutionResult {
        val id = identity ?: return ExecutionEngine.ExecutionResult(
            null, null, null, FeatureResultStatus.DEVICE_UNSUPPORTED,
            "No device identity. Run identify() first."
        )
        val selection = adapterRegistry.selectAdapter(id)
        val adapter = selection.adapter
            ?: return ExecutionEngine.ExecutionResult(
                null, null, null, FeatureResultStatus.PROTOCOL_UNKNOWN,
                "No adapter for ${id.brand} ${id.model}. Research required. reason=${selection.reason}"
            )

        val evidenceStrength = when (adapter.status) {
            AdapterStatus.PRODUCTION, AdapterStatus.VERIFIED -> 0.9
            AdapterStatus.TESTED -> 0.7
            AdapterStatus.EXPERIMENTAL -> 0.45
            else -> 0.2
        }

        val result = executionEngine.execute(
            adapter, activeTransport, feature, operation, parameters, target,
            evidenceStrength, userConfirmed
        )

        result.verification?.let { v ->
            knowledgeStore.findBestForIdentity(id)?.let { existing ->
                knowledgeStore.put(existing.copy(testHistory = existing.testHistory + v, updatedAt = Instant.now()))
            }
            if (result.status == FeatureResultStatus.FAILED || result.status == FeatureResultStatus.UNSAFE_TO_EXECUTE) {
                knowledgeStore.recordFailure(
                    FailureRecord(
                        deviceBrand = id.brand,
                        deviceModel = id.model,
                        firmware = id.firmware,
                        transport = result.command?.transport ?: TransportType.OTHER,
                        protocolId = result.command?.protocolId,
                        feature = feature,
                        commandSummary = "${result.command?.operation} $feature",
                        parameters = parameters,
                        responseSummary = result.observation?.response?.errorMessage,
                        failureReason = result.message,
                        verificationAttempted = result.verification != null,
                        agent = "EXECUTION"
                    )
                )
            }
        }
        return result
    }

    /** Model routing hint for BrainManager integration. */
    fun routeModel(taskComplexity: String): String = when (taskComplexity.lowercase()) {
        "simple", "classification", "lookup", "parse" -> "Pico"
        "adapter_skeleton", "simple_verification" -> "Spark"
        "conflict", "reverse_engineering", "synthesis" -> "Atlas"
        else -> "Nova"
    }

    private fun emptyCapability() = CapabilityProfile(
        deviceIdentity = DeviceIdentity(
            brand = "UNKNOWN", model = "UNKNOWN",
            confidence = 0.0, status = IdentityStatus.UNKNOWN, evidence = emptyList()
        ),
        features = emptyMap()
    )
}
