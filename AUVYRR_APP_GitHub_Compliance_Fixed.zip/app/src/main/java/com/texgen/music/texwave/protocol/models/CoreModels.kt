package com.texgen.music.texwave.protocol.models

import java.time.Instant
import java.util.UUID

/**
 * Core data models for AUVYRR Protocol Engineering System.
 * Derived strictly from the specification schemas and rules.
 * No invented protocol details.
 */

// ---------- Enums ----------

enum class IdentityStatus {
    MATCH, MISMATCH, UNCERTAIN, UNKNOWN, VERIFIED
}

enum class IdentityConfidenceLevel {
    HIGH, MEDIUM, LOW, UNKNOWN
}

enum class ProtocolClassification {
    STANDARD, KNOWN_PROPRIETARY, PARTIALLY_DOCUMENTED, UNDOCUMENTED, REVERSE_ENGINEERED, UNKNOWN
}

enum class TransportType {
    BLE_GATT, CLASSIC, ANDROID_AUDIO, HID, MEDIA_SESSION, OTHER
}

enum class Operation {
    GET, SET, TOGGLE, RESET, QUERY, SUBSCRIBE
}

enum class DeviceTarget {
    LEFT, RIGHT, BOTH, CASE, SYSTEM, UNKNOWN
}

enum class SafetyLevel {
    SAFE_READ, SAFE_CONTROL, CAUTION, HIGH_IMPACT, DESTRUCTIVE
}

enum class VerificationMethod {
    EXPLICIT_RESPONSE, GATT_NOTIFY, STATE_READBACK, BEFORE_AFTER, SYSTEM_OBSERVATION, NONE_AVAILABLE
}

enum class FeatureSupport {
    SUPPORTED, PARTIAL, UNSUPPORTED, UNKNOWN
}

enum class ControlStatus {
    VERIFIED, UNVERIFIED, RESEARCH_REQUIRED, NONE
}

enum class ReadStatus {
    VERIFIED, UNVERIFIED, NONE
}

enum class FeatureResultStatus {
    VERIFIED_WORKING,
    VERIFIED_READ_ONLY,
    PARTIALLY_SUPPORTED,
    RESEARCH_REQUIRED,
    PROTOCOL_UNKNOWN,
    DEVICE_UNSUPPORTED,
    HARDWARE_LIMITATION,
    PERMISSION_LIMITATION,
    TRANSPORT_UNAVAILABLE,
    UNSAFE_TO_EXECUTE,
    NOT_VERIFIABLE,
    EXPERIMENTAL,
    FAILED,
    COMMAND_SENT_UNVERIFIED
}

enum class VerificationResultStatus {
    VERIFIED_WORKING,
    VERIFIED_READ_ONLY,
    PARTIALLY_SUPPORTED,
    NOT_VERIFIABLE,
    VERIFICATION_FAILURE,
    FAILED,
    EXPERIMENTAL,
    COMMAND_SENT_UNVERIFIED
}

enum class SourceType {
    OFFICIAL_DOC, SDK, BLUETOOTH_SIG, OPEN_SOURCE, REVERSE_ENGINEERING,
    PACKET_CAPTURE, DEVICE_OBSERVATION, COMMUNITY, OTHER
}

enum class AdapterStatus {
    RESEARCH, EXPERIMENTAL, TESTED, VERIFIED, PRODUCTION, FAILED, UNSUPPORTED
}

enum class KnowledgePromotionState {
    RESEARCHED, EXPERIMENTAL, TESTED, VERIFIED, PRODUCTION
}

// ---------- Device Identity ----------

data class OcrCandidate(
    val text: String,
    val confidence: Double,
    val source: String
)

data class DeviceIdentity(
    val brand: String,
    val model: String,
    val variant: String? = null,
    val firmware: String? = null,
    val hardwareRevision: String? = null,
    val confidence: Double,                 // 0.0 .. 1.0
    val confidenceLevel: IdentityConfidenceLevel = IdentityConfidenceLevel.UNKNOWN,
    val status: IdentityStatus,
    val bluetoothName: String? = null,
    val addressHash: String? = null,        // privacy-preserving hash, never store raw MAC long-term
    val serviceUuids: List<String> = emptyList(),
    val manufacturerId: String? = null,
    val manufacturerDataHex: String? = null,
    val userClaim: String? = null,
    val ocrCandidates: List<OcrCandidate> = emptyList(),
    val evidence: List<String> = emptyList(),
    val notes: String? = null,
    val identityId: String = UUID.randomUUID().toString(),
    val createdAt: Instant = Instant.now()
) {
    init {
        require(confidence in 0.0..1.0) { "confidence must be 0.0..1.0" }
    }

    fun withEvidence(vararg refs: String): DeviceIdentity =
        copy(evidence = evidence + refs.toList())
}

// ---------- Protocol ----------

data class ProtocolRecord(
    val protocolId: String,
    val classification: ProtocolClassification,
    val transport: TransportType,
    val serviceUuids: List<String> = emptyList(),
    val characteristicUuids: List<String> = emptyList(),
    val description: String? = null,
    val confidence: Double,
    val evidenceRefs: List<String> = emptyList(),
    val knownLimitations: List<String> = emptyList(),
    val adapterVersions: List<String> = emptyList()
) {
    init {
        require(confidence in 0.0..1.0)
    }
}

// ---------- Command ----------

data class ProtocolCommand(
    val feature: String,
    val operation: Operation,
    val parameters: Map<String, Any> = emptyMap(),
    val transport: TransportType,
    val protocolId: String? = null,
    val target: DeviceTarget = DeviceTarget.BOTH,
    val safetyLevel: SafetyLevel,
    val expectedResponse: Map<String, Any>? = null,
    val verificationMethod: VerificationMethod,
    val evidenceRefs: List<String>,
    val adapterVersion: String,
    val timeoutMs: Long = 3000L,
    val serviceUuid: String? = null,
    val characteristicUuid: String? = null,
    val commandId: String = UUID.randomUUID().toString()
)

// ---------- Capability ----------

data class FeatureCapability(
    val support: FeatureSupport,
    val control: ControlStatus = ControlStatus.NONE,
    val read: ReadStatus = ReadStatus.NONE,
    val status: FeatureResultStatus,
    val notes: String? = null,
    val lastVerified: Instant? = null,
    val adapterId: String? = null
)

data class CapabilityProfile(
    val deviceIdentity: DeviceIdentity,
    val generatedAt: Instant = Instant.now(),
    val adapterId: String? = null,
    val features: Map<String, FeatureCapability> = emptyMap()
)

// ---------- Evidence ----------

data class EvidenceRecord(
    val id: String = UUID.randomUUID().toString(),
    val source: String,
    val sourceType: SourceType,
    val date: String,
    val claim: String,
    val confidence: Double,
    val url: String? = null,
    val deviceModel: String? = null,
    val firmware: String? = null,
    val rawExcerpt: String? = null,
    val notes: String? = null
) {
    init {
        require(confidence in 0.0..1.0)
    }
}

// ---------- Verification ----------

data class VerificationResult(
    val commandId: String,
    val feature: String,
    val expected: Map<String, Any>? = null,
    val observed: Map<String, Any>? = null,
    val result: VerificationResultStatus,
    val confidence: Double = 0.0,
    val timestamp: Instant = Instant.now(),
    val adapterVersion: String? = null,
    val firmware: String? = null,
    val notes: String? = null,
    val evidenceRefs: List<String> = emptyList()
)

// ---------- Observation / Response ----------

data class DeviceResponse(
    val success: Boolean,
    val rawPayload: ByteArray? = null,
    val parsed: Map<String, Any>? = null,
    val errorMessage: String? = null,
    val timestamp: Instant = Instant.now()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as DeviceResponse
        return success == other.success &&
                rawPayload contentEquals other.rawPayload &&
                parsed == other.parsed &&
                errorMessage == other.errorMessage
    }
    override fun hashCode(): Int {
        var result = success.hashCode()
        result = 31 * result + (rawPayload?.contentHashCode() ?: 0)
        result = 31 * result + (parsed?.hashCode() ?: 0)
        result = 31 * result + (errorMessage?.hashCode() ?: 0)
        return result
    }
}

data class Observation(
    val observationId: String = UUID.randomUUID().toString(),
    val commandId: String,
    val response: DeviceResponse,
    val beforeState: Map<String, Any>? = null,
    val afterState: Map<String, Any>? = null,
    val systemObservations: Map<String, Any> = emptyMap(),
    val timestamp: Instant = Instant.now()
)

// ---------- Adapter / Knowledge ----------

data class AdapterVersion(
    val adapterId: String,
    val version: String,
    val status: AdapterStatus,
    val supportedModels: List<String> = emptyList(),
    val firmwareRange: String? = null,     // e.g. "1.0.0-2.3.1" or exact
    val protocolId: String,
    val features: List<String> = emptyList(),
    val evidenceRefs: List<String> = emptyList(),
    val knownLimitations: List<String> = emptyList(),
    val createdAt: Instant = Instant.now(),
    val lastVerifiedAt: Instant? = null
)

data class ProtocolKnowledge(
    val knowledgeId: String = UUID.randomUUID().toString(),
    val deviceIdentity: DeviceIdentity,
    val protocol: ProtocolRecord,
    val adapter: AdapterVersion?,
    val capabilities: CapabilityProfile?,
    val evidence: List<EvidenceRecord> = emptyList(),
    val promotionState: KnowledgePromotionState = KnowledgePromotionState.RESEARCHED,
    val testHistory: List<VerificationResult> = emptyList(),
    val failures: List<FailureRecord> = emptyList(),
    val updatedAt: Instant = Instant.now()
)

// ---------- Failure ----------

data class FailureRecord(
    val failureId: String = UUID.randomUUID().toString(),
    val deviceBrand: String,
    val deviceModel: String,
    val firmware: String? = null,
    val transport: TransportType,
    val protocolId: String? = null,
    val feature: String? = null,
    val commandSummary: String,
    val parameters: Map<String, Any> = emptyMap(),
    val responseSummary: String? = null,
    val failureReason: String,
    val retryCount: Int = 0,
    val verificationAttempted: Boolean = false,
    val timestamp: Instant = Instant.now(),
    val source: String = "SYSTEM",
    val agent: String? = null,
    val notes: String? = null
)

// ---------- Agent Task / Result ----------

data class AgentTask(
    val taskId: String = UUID.randomUUID().toString(),
    val agentRole: String,                 // IDENTIFICATION, RESEARCH, PROTOCOL, EXECUTION, VERIFICATION, SAFETY
    val description: String,
    val input: Map<String, Any> = emptyMap(),
    val modelHint: String? = null,         // Pico, Spark, Nova, Atlas
    val createdAt: Instant = Instant.now()
)

data class AgentResult(
    val taskId: String,
    val success: Boolean,
    val output: Map<String, Any> = emptyMap(),
    val confidence: Double = 0.0,
    val evidenceRefs: List<String> = emptyList(),
    val modelUsed: String? = null,
    val notes: String? = null,
    val timestamp: Instant = Instant.now()
)

// ---------- Research ----------

data class ResearchSource(
    val sourceId: String = UUID.randomUUID().toString(),
    val title: String,
    val url: String? = null,
    val sourceType: SourceType,
    val reliability: Double,               // 0.0 .. 1.0
    val extractedClaims: List<String> = emptyList(),
    val notes: String? = null
)

data class ResearchReport(
    val reportId: String = UUID.randomUUID().toString(),
    val deviceIdentity: DeviceIdentity,
    val query: String,
    val sources: List<ResearchSource> = emptyList(),
    val protocolCandidates: List<ProtocolRecord> = emptyList(),
    val facts: List<String> = emptyList(),
    val hypotheses: List<String> = emptyList(),
    val unknowns: List<String> = emptyList(),
    val conflicts: List<String> = emptyList(),
    val overallConfidence: Double = 0.0,
    val recommendation: String? = null,
    val createdAt: Instant = Instant.now()
)
