package com.texgen.music.texwave.protocol.identity

import com.texgen.music.texwave.protocol.models.*
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID

/**
 * Evidence-based device identification.
 * Never trusts display name or user claim alone.
 */
class IdentityEngine {

    data class RawDeviceEvidence(
        val bluetoothName: String? = null,
        val address: String? = null,
        val serviceUuids: List<String> = emptyList(),
        val manufacturerId: Int? = null,
        val manufacturerData: ByteArray? = null,
        val deviceClass: Int? = null,
        val systemModel: String? = null,
        val firmwareRevision: String? = null,
        val hardwareRevision: String? = null,
        val userClaimBrand: String? = null,
        val userClaimModel: String? = null,
        val ocrCandidates: List<OcrCandidate> = emptyList(),
        val previousVerifiedIdentity: DeviceIdentity? = null,
        val bondState: Int? = null,
        val type: Int? = null // BluetoothDevice.DEVICE_TYPE_*
    )

    fun identify(evidence: RawDeviceEvidence): DeviceIdentity {
        val evidenceList = mutableListOf<String>()
        var brand = "UNKNOWN"
        var model = "UNKNOWN"
        var confidence = 0.0
        var status = IdentityStatus.UNKNOWN

        evidence.previousVerifiedIdentity?.let { prev ->
            if (prev.status == IdentityStatus.VERIFIED || prev.confidence >= 0.85) {
                evidenceList.add("previous_verified_identity:${prev.identityId}")
                return prev.copy(
                    confidence = (prev.confidence * 0.95).coerceAtMost(0.99),
                    evidence = prev.evidence + "reused_from_local_knowledge"
                )
            }
        }

        val btName = evidence.bluetoothName?.trim()
        if (!btName.isNullOrBlank()) {
            evidenceList.add("bluetooth_name:$btName")
            val parsed = parseNameHints(btName)
            if (parsed.first != null) brand = parsed.first!!
            if (parsed.second != null) model = parsed.second!!
            confidence += 0.15
        }

        evidence.manufacturerId?.let { mid ->
            evidenceList.add("manufacturer_id:$mid")
            val known = knownManufacturer(mid)
            if (known != null) {
                brand = known
                confidence += 0.25
            } else {
                confidence += 0.05
            }
        }

        if (evidence.serviceUuids.isNotEmpty()) {
            evidenceList.add("service_uuids:${evidence.serviceUuids.joinToString(",")}")
            confidence += 0.10
        }

        val userBrand = evidence.userClaimBrand?.trim()
        val userModel = evidence.userClaimModel?.trim()
        if (!userBrand.isNullOrBlank() || !userModel.isNullOrBlank()) {
            evidenceList.add("user_claim:${userBrand ?: ""} ${userModel ?: ""}".trim())
            val nameMismatch = btName != null && userModel != null &&
                    !btName.lowercase(Locale.ROOT).contains(userModel.lowercase(Locale.ROOT).take(4))
            if (nameMismatch && brand != "UNKNOWN" && brand != userBrand) {
                status = IdentityStatus.MISMATCH
                evidenceList.add("user_claim_mismatch")
                confidence = (confidence * 0.6).coerceAtMost(0.55)
            } else {
                if (!userBrand.isNullOrBlank() && brand == "UNKNOWN") brand = userBrand
                if (!userModel.isNullOrBlank() && model == "UNKNOWN") model = userModel
                confidence += 0.20
            }
        }

        if (evidence.ocrCandidates.isNotEmpty()) {
            val best = evidence.ocrCandidates.maxByOrNull { it.confidence }
            if (best != null && best.confidence >= 0.6) {
                evidenceList.add("ocr:${best.text}@${best.confidence}")
                val ocrParsed = parseNameHints(best.text)
                if (ocrParsed.first != null && brand == "UNKNOWN") brand = ocrParsed.first!!
                if (ocrParsed.second != null && model == "UNKNOWN") model = ocrParsed.second!!
                confidence += 0.15 * best.confidence
            }
        }

        evidence.firmwareRevision?.let {
            evidenceList.add("firmware:$it")
            confidence += 0.05
        }
        evidence.hardwareRevision?.let {
            evidenceList.add("hw_rev:$it")
            confidence += 0.03
        }

        confidence = confidence.coerceIn(0.0, 0.95)

        val level = when {
            confidence >= 0.80 -> IdentityConfidenceLevel.HIGH
            confidence >= 0.55 -> IdentityConfidenceLevel.MEDIUM
            confidence >= 0.25 -> IdentityConfidenceLevel.LOW
            else -> IdentityConfidenceLevel.UNKNOWN
        }

        if (status == IdentityStatus.UNKNOWN) {
            status = when {
                level == IdentityConfidenceLevel.HIGH && brand != "UNKNOWN" && model != "UNKNOWN" ->
                    IdentityStatus.MATCH
                level == IdentityConfidenceLevel.MEDIUM -> IdentityStatus.UNCERTAIN
                else -> IdentityStatus.UNKNOWN
            }
        }

        val addressHash = evidence.address?.let { hashAddress(it) }

        return DeviceIdentity(
            brand = brand,
            model = model,
            variant = null,
            firmware = evidence.firmwareRevision,
            hardwareRevision = evidence.hardwareRevision,
            confidence = confidence,
            confidenceLevel = level,
            status = status,
            bluetoothName = btName,
            addressHash = addressHash,
            serviceUuids = evidence.serviceUuids,
            manufacturerId = evidence.manufacturerId?.toString(),
            manufacturerDataHex = evidence.manufacturerData?.joinToString("") { "%02x".format(it) },
            userClaim = listOfNotNull(userBrand, userModel).joinToString(" ").ifBlank { null },
            ocrCandidates = evidence.ocrCandidates,
            evidence = evidenceList,
            notes = if (status == IdentityStatus.MISMATCH)
                "User claim conflicts with observed Bluetooth evidence. Prefer hardware signals."
            else null
        )
    }

    private fun parseNameHints(name: String): Pair<String?, String?> {
        val lower = name.lowercase(Locale.ROOT)
        val brands = listOf(
            "sony", "bose", "sennheiser", "jabra", "anker", "soundcore",
            "samsung", "galaxy", "apple", "airpods", "beats", "jbl",
            "nothing", "pixel", "oneplus", "xiaomi", "redmi", "realme",
            "huawei", "honor", "oppo", "vivo", "marshall", "skullcandy",
            "audio-technica", "shure", "bang", "olufsen", "devialet"
        )
        var foundBrand: String? = null
        for (b in brands) {
            if (lower.contains(b)) {
                foundBrand = b.replaceFirstChar { it.uppercase() }
                break
            }
        }
        val modelCandidate = name.trim().takeIf { it.length in 3..40 }
        return foundBrand to modelCandidate
    }

    private fun knownManufacturer(id: Int): String? {
        // Public Bluetooth SIG Company Identifiers only
        return when (id) {
            0x004C -> "Apple"
            0x000F -> "Broadcom"
            0x0075 -> "Samsung"
            0x0087 -> "Garmin"
            0x00E0 -> "Google"
            0x0157 -> "Anhui Huami"
            0x02E5 -> "Bose"
            0x00D2 -> "Sony"
            else -> null
        }
    }

    private fun hashAddress(address: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(address.uppercase(Locale.ROOT).toByteArray())
        return digest.take(8).joinToString("") { "%02x".format(it) }
    }
}
