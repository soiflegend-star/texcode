package com.texgen.music.texwave.data

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val dateAdded: Long,
    val contentUri: String,
    val path: String = "",
    val year: Int = 0,
    val trackNumber: Int = 0,
    /** Artwork picked by the tag editor (file uri). Empty = use the device artwork. */
    val artOverride: String = "",
) {
    val artUri: String
        get() = if (artOverride.isNotBlank()) artOverride else "content://media/external/audio/albumart/$albumId"
}

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<Long>,
)

data class Album(
    val id: Long,
    val name: String,
    val artist: String,
    val songCount: Int,
    val songs: List<Song>,
)

data class ArtistGroup(
    val name: String,
    val songCount: Int,
    val albumCount: Int,
    val songs: List<Song>,
)
