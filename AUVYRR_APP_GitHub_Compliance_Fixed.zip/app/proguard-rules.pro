# Media3 / ExoPlayer ship consumer rules. Add project-specific keep rules here.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile


# Vosk offline speech
-keep class org.vosk.** { *; }
-dontwarn org.vosk.**

# WebRTC (JNI calls into org.webrtc)
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**

# Brains (MediaPipe on-device LLM) — native code calls back into these classes
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**
-keep class com.google.protobuf.** { *; }
-dontwarn com.google.protobuf.**
-keep class com.texgen.music.texwave.brain.** { *; }

# Cosmic explorer GL renderer is referenced by GLSurfaceView
-keep class com.texgen.music.texwave.ui.screens.universe.** { *; }

# Tag writer (jaudiotagger loads frame classes by reflection and references desktop-only classes)
-keep class org.jaudiotagger.** { *; }
-dontwarn org.jaudiotagger.**
-dontwarn java.awt.**
-dontwarn javax.imageio.**
-dontwarn javax.swing.**
-dontwarn javax.xml.**

# Velocity web-game host bridge (called from JavaScript)
-keepclassmembers class com.texgen.music.texwave.velocity.VelocityActivity$HostApi {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.texgen.music.texwave.velocity.** { *; }
