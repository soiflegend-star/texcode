# GitHub Compliance & Code Audit — AUVYRR

## Audit date
2026-11-17

## Scope
Static audit of the supplied AUVYRR/Texwave project archive, including Android/Gradle configuration, GitHub Actions configuration, manifest security settings, source-controlled configuration, and line counts.

## Problems fixed

1. **Backend credential/configuration was embedded in source**
   - Removed the Supabase URL/key values from `SupabaseConfig.kt`.
   - Values are now injected through `local.properties` for local development or environment variables in CI.
   - Added `local.properties.example`.
   - Added CI secret environment wiring for `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
   - No Supabase service-role/server secret is placed in the Android client.

2. **Missing repository ignore rules**
   - Added `.gitignore` covering Gradle/build output, IDE files, local properties, signing material, environment files, generated APK/AAB files, node modules, logs, and temporary files.

3. **Cleartext network traffic was globally enabled**
   - Disabled `android:usesCleartextTraffic`.
   - Updated the network security configuration to reject cleartext traffic and user-installed CA certificates by default.

4. **Unnecessary broad external-storage declarations**
   - Removed `MANAGE_EXTERNAL_STORAGE`.
   - Removed duplicate/obsolete `WRITE_EXTERNAL_STORAGE` declarations.
   - Removed `requestLegacyExternalStorage`.
   - Existing media-read permissions remain for the app's media functionality.

5. **GitHub Actions job lacked explicit read-only repository permissions**
   - Added `permissions: contents: read`.

6. **CI did not explicitly run Android lint**
   - CI now runs `:app:lintDebug` before assembling the debug APK.
   - Android lint is configured to fail the build on errors.

## Static verification

- Source/config scan found no embedded API/JWT-style credential after the fix.
- Remaining matches are documentation examples/commands that generate secrets at deployment time; they are not stored credentials.
- Android manifest was checked for duplicate external-storage declarations and cleartext configuration.
- GitHub workflow YAML structure was updated with explicit permissions and secret injection.

## Line count

The supplied archive contains **638 files**.

Total lines across code/config-like files (Kotlin, Gradle/KTS, XML, SQL, TypeScript/JavaScript, JSON, CSS/HTML, properties, YAML, etc.): **82,634 lines**.

Breakdown of the main code/config formats:

| Format | Files | Lines |
|---|---:|---:|
| Kotlin | 258 | 66,867 |
| SQL | 23 | 4,894 |
| JavaScript | 4 | 4,404 |
| TypeScript | 28 | 3,070 |
| JSON | 3 | 1,742 |
| CSS | 2 | 715 |
| XML | 20 | 482 |
| Gradle/KTS | 3 | 175 |
| HTML | 3 | 125 |
| YAML | 1 | 22 |
| Other counted config/code | 4 | 140 |

## Verification limitation

A full Gradle compile/lint run could not be completed in this environment because the supplied Gradle wrapper attempted to download Gradle 8.5 from `services.gradle.org`, while this execution environment has no external network access.

Therefore, this archive has been **statically compliance-fixed and structurally audited**, but a successful Android build should still be run in GitHub Actions or an Android Studio environment with dependency/network access.
