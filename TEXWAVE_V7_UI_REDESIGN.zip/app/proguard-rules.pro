# Media3 / ExoPlayer ship consumer rules. Add project-specific keep rules here.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile


# Vosk offline speech
-keep class org.vosk.** { *; }
-dontwarn org.vosk.**

# WebRTC (JNI calls into org.webrtc)
-keep class org.webrtc.** { *; }
-dontwarn org.webrtc.**
