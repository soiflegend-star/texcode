package com.texgen.music.texwave.util

import org.junit.Assert.assertEquals
import org.junit.Test

class FormatTest {
    @Test fun zeroAndNegative() {
        assertEquals("0:00", formatDuration(0))
        assertEquals("0:00", formatDuration(-5))
    }

    @Test fun minutesAndSeconds() {
        assertEquals("3:05", formatDuration(185_000))
        assertEquals("0:09", formatDuration(9_999))
    }

    @Test fun hours() {
        assertEquals("1:02:03", formatDuration(3_723_000))
    }

    @Test fun pluralisation() {
        assertEquals("1 song", songCount(1))
        assertEquals("0 songs", songCount(0))
        assertEquals("12 songs", songCount(12))
    }
}
