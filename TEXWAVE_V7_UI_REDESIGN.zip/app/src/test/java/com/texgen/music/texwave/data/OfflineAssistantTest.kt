package com.texgen.music.texwave.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pipeline checks for offline voice commands (no Android runtime needed).
 */
class OfflineAssistantTest {

    @Test
    fun playSongName_notMood() {
        val a = OfflineAssistant.parse("play indila")
        assertTrue("expected PlayQuery, got $a", a is OfflineAssistant.Action.PlayQuery)
        assertEquals("indila", (a as OfflineAssistant.Action.PlayQuery).query)
    }

    @Test
    fun playRainy_isMood() {
        val a = OfflineAssistant.parse("play rainy")
        assertTrue(a is OfflineAssistant.Action.PlayEmotion)
        assertEquals(EmotionMode.RAINY_NIGHT, (a as OfflineAssistant.Action.PlayEmotion).mode)
    }

    @Test
    fun playUnstoppable_isMood() {
        val a = OfflineAssistant.parse("play unstoppable")
        assertTrue(a is OfflineAssistant.Action.PlayEmotion)
        assertEquals(EmotionMode.UNSTOPPABLE, (a as OfflineAssistant.Action.PlayEmotion).mode)
    }

    @Test
    fun controls() {
        assertTrue(OfflineAssistant.parse("pause") is OfflineAssistant.Action.Pause)
        assertTrue(OfflineAssistant.parse("next") is OfflineAssistant.Action.Next)
        assertTrue(OfflineAssistant.parse("previous") is OfflineAssistant.Action.Previous)
        assertTrue(OfflineAssistant.parse("what is playing") is OfflineAssistant.Action.WhatsPlaying)
    }

    @Test
    fun infiniteMix() {
        assertTrue(OfflineAssistant.parse("start infinite mix") is OfflineAssistant.Action.InfiniteMix)
    }
}
