package com.texgen.music.texwave.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Mirrors WakeWordService.matchesWake without Android deps. */
class WakePhraseTest {
    private fun normalize(s: String): String =
        s.lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun matchesWake(hayRaw: String, wakeWord: String = "phantom"): Boolean {
        val hay = normalize(hayRaw)
        val ww = wakeWord.lowercase().trim()
        if (ww.length < 2 || hay.isBlank()) return false
        val tokens = hay.split(" ").filter { it.isNotEmpty() }
        return hay.contains(ww) ||
            tokens.any { it == ww } ||
            tokens.any { it.startsWith(ww) && it.length <= ww.length + 2 } ||
            (ww.length >= 3 && tokens.any { ww.startsWith(it) && it.length >= 3 }) ||
            (ww.length >= 4 && tokens.any { it.take(4) == ww.take(4) }) ||
            (tokens.any { it in listOf("phantom", "fantom") } && ww == "phantom")
    }

    @Test fun hearsPhantom() {
        assertTrue(matchesWake("phantom"))
        assertTrue(matchesWake("hey phantom"))
        assertTrue(matchesWake("ok phantom play something"))
        assertTrue(matchesWake("fantom"))
    }

    @Test fun ignoresUnrelated() {
        assertFalse(matchesWake("play music"))
        assertFalse(matchesWake("hello there"))
    }

    @Test fun weatherPhraseKeywords() {
        val q = "play a song that matches this weather"
        assertTrue("weather" in q && "play" in q && "match" in q)
    }
}
