package com.texgen.music.texwave.data.chat

import android.content.Context

/**
 * Wave Presence — temporary mood / activity friends see without a full conversation.
 * Local cache + TEXWAVE_PRESENCE messages for friends.
 */
object WavePresenceStore {
    data class Presence(
        val emoji: String,
        val label: String,
        val detail: String = "",
        val expiresAt: Long = 0L,
    )

    val presets = listOf(
        Presence("🎧", "Listening to music"),
        Presence("💬", "Available to talk"),
        Presence("🎯", "Deep focus"),
        Presence("🌙", "Winding down"),
        Presence("✨", "Today's thought"),
        Presence("🚀", "On a mission"),
    )

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("texwave_wave_presence", Context.MODE_PRIVATE)

    fun setLocal(ctx: Context, p: Presence, hours: Int = 6) {
        val exp = System.currentTimeMillis() + hours * 3_600_000L
        prefs(ctx).edit()
            .putString("emoji", p.emoji)
            .putString("label", p.label)
            .putString("detail", p.detail)
            .putLong("exp", exp)
            .apply()
    }

    fun getLocal(ctx: Context): Presence? {
        val p = prefs(ctx)
        val exp = p.getLong("exp", 0L)
        if (exp < System.currentTimeMillis()) return null
        val label = p.getString("label", null) ?: return null
        return Presence(
            emoji = p.getString("emoji", "✨") ?: "✨",
            label = label,
            detail = p.getString("detail", "") ?: "",
            expiresAt = exp,
        )
    }

    fun encode(p: Presence, hours: Int = 6): String {
        val exp = System.currentTimeMillis() + hours * 3_600_000L
        return "TEXWAVE_PRESENCE:${p.emoji}|${p.label.replace("|", "/")}|${p.detail.replace("|", "/")}|$exp"
    }

    fun parse(body: String?): Presence? {
        if (body == null || !body.startsWith("TEXWAVE_PRESENCE:")) return null
        val parts = body.removePrefix("TEXWAVE_PRESENCE:").split("|")
        if (parts.size < 4) return null
        val exp = parts[3].toLongOrNull() ?: return null
        if (exp < System.currentTimeMillis()) return null
        return Presence(parts[0], parts[1], parts.getOrElse(2) { "" }, exp)
    }
}
