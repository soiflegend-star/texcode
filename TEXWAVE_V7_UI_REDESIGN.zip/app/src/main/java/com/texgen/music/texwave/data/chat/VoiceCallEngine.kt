package com.texgen.music.texwave.data.chat

import android.content.Context
import android.media.AudioManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import io.github.jan.supabase.realtime.RealtimeChannel
import io.github.jan.supabase.realtime.broadcastFlow
import io.github.jan.supabase.realtime.channel
import io.github.jan.supabase.realtime.realtime
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.DataChannel
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.audio.JavaAudioDeviceModule

/** ICE servers for the call. Swap the TURN entry for your own server for best reliability. */
object CallConfig {
    data class Server(val urls: List<String>, val user: String? = null, val pass: String? = null)

    val servers = listOf(
        Server(listOf("stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302")),
        // Free public relay (rate limited). Replace with your own TURN for production use.
        Server(
            listOf(
                "turn:openrelay.metered.ca:80",
                "turn:openrelay.metered.ca:443",
                "turn:openrelay.metered.ca:443?transport=tcp",
            ),
            "openrelayproject",
            "openrelayproject",
        ),
    )
    const val RING_TIMEOUT_MS = 45_000L
}

@Serializable
data class CallSig(
    val from: String,
    val type: String,
    val sdp: String? = null,
    val mid: String? = null,
    val idx: Int = 0,
)

/**
 * Real-time peer-to-peer voice call (WebRTC / Opus audio).
 * Signaling (offer / answer / ICE) runs over a Supabase Realtime broadcast channel,
 * so the call happens fully inside TEXWAVE — no browser, no other app.
 *
 * The caller always creates the offer; the callee announces "ready" once it has joined
 * the signaling channel and opened its microphone.
 */
class VoiceCallEngine(
    context: Context,
    private val repo: ChatRepository,
    private val room: String,
    private val isCaller: Boolean,
) {
    enum class State { CONNECTING, WAITING, CONNECTED, RECONNECTING, ENDED, FAILED }

    private val appCtx = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _state = MutableStateFlow(State.CONNECTING)
    val state: StateFlow<State> = _state.asStateFlow()

    /** 0..1 loudness of the other person's voice. */
    private val _remoteLevel = MutableStateFlow(0f)
    val remoteLevel: StateFlow<Float> = _remoteLevel.asStateFlow()

    /** 0..1 loudness of my own voice. */
    private val _localLevel = MutableStateFlow(0f)
    val localLevel: StateFlow<Float> = _localLevel.asStateFlow()

    /** Reason shown when state == FAILED / ENDED. */
    @Volatile var endReason: String = ""
        private set

    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var channel: RealtimeChannel? = null
    private var me: String = ""
    private val pendingIce = mutableListOf<IceCandidate>()
    @Volatile private var remoteSet = false
    @Volatile private var closed = false
    private var readyJob: Job? = null
    private var timeoutJob: Job? = null
    private var statsJob: Job? = null
    private var muted = false

    private val audioManager = appCtx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var prevMode = AudioManager.MODE_NORMAL

    fun start() {
        scope.launch {
            try {
                me = repo.rawCurrentUserId()
                setupAudioRoute()
                initWebRtc()
                joinSignaling()
                if (isCaller) {
                    _state.value = State.WAITING
                    timeoutJob = launch {
                        delay(CallConfig.RING_TIMEOUT_MS)
                        if (_state.value != State.CONNECTED) fail("No answer")
                    }
                } else {
                    _state.value = State.CONNECTING
                    readyJob = launch {
                        // keep announcing until the caller's offer arrives
                        while (!remoteSet && !closed) {
                            send("ready")
                            delay(1_500)
                        }
                    }
                    timeoutJob = launch {
                        delay(25_000)
                        if (_state.value != State.CONNECTED) fail("Could not connect")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "start", e)
                fail("Call failed: ${e.message ?: "unknown error"}")
            }
        }
    }

    // -------------------- setup --------------------

    private fun setupAudioRoute() {
        prevMode = audioManager.mode
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = false
    }

    private fun initWebRtc() {
        ensureInit(appCtx)
        val adm = JavaAudioDeviceModule.builder(appCtx)
            .setUseHardwareAcousticEchoCanceler(true)
            .setUseHardwareNoiseSuppressor(true)
            .createAudioDeviceModule()
        val f = PeerConnectionFactory.builder()
            .setAudioDeviceModule(adm)
            .createPeerConnectionFactory()
        adm.release() // factory keeps its own reference
        factory = f

        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
        }
        val src = f.createAudioSource(constraints)
        audioSource = src
        val track = f.createAudioTrack("texwave-mic", src)
        track.setEnabled(true)
        audioTrack = track

        val ice = CallConfig.servers.map { s ->
            val b = PeerConnection.IceServer.builder(s.urls)
            if (s.user != null) b.setUsername(s.user)
            if (s.pass != null) b.setPassword(s.pass)
            b.createIceServer()
        }
        val cfg = PeerConnection.RTCConfiguration(ice).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }
        val conn = f.createPeerConnection(cfg, observer) ?: error("Could not create call connection")
        conn.addTrack(track, listOf("texwave-stream"))
        pc = conn
    }

    private suspend fun joinSignaling() {
        val ch = repo.rawClient().channel("call-$room")
        channel = ch
        val flow = ch.broadcastFlow<CallSig>("sig")
        scope.launch {
            flow.collect { sig ->
                if (sig.from == me || closed) return@collect
                runCatching { onSignal(sig) }.onFailure { Log.e(TAG, "signal ${sig.type}", it) }
            }
        }
        delay(150)
        withTimeout(15_000) { ch.subscribe(blockUntilSubscribed = true) }
    }

    private suspend fun send(type: String, sdp: String? = null, mid: String? = null, idx: Int = 0) {
        val ch = channel ?: return
        runCatching {
            ch.broadcast("sig", buildJsonObject {
                put("from", me)
                put("type", type)
                if (sdp != null) put("sdp", sdp)
                if (mid != null) put("mid", mid)
                put("idx", idx)
            })
        }
    }

    // -------------------- signaling --------------------

    private fun onSignal(sig: CallSig) {
        when (sig.type) {
            "ready" -> if (isCaller && !remoteSet) createAndSendOffer()
            "offer" -> if (!isCaller && !remoteSet && sig.sdp != null) handleOffer(sig.sdp)
            "answer" -> if (isCaller && !remoteSet && sig.sdp != null) handleAnswer(sig.sdp)
            "ice" -> if (sig.sdp != null) {
                val cand = IceCandidate(sig.mid ?: "0", sig.idx, sig.sdp)
                if (remoteSet) pc?.addIceCandidate(cand) else synchronized(pendingIce) { pendingIce.add(cand) }
            }
            "bye" -> finish("Call ended")
        }
    }

    @Volatile private var offerSdp: String? = null

    private fun createAndSendOffer() {
        val c = pc ?: return
        // the callee may announce "ready" several times; build the offer only once
        offerSdp?.let { sdp -> scope.launch { send("offer", sdp = sdp) }; return }
        val mc = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
        }
        c.createOffer(object : SdpAdapter() {
            override fun onCreateSuccess(desc: SessionDescription) {
                c.setLocalDescription(object : SdpAdapter() {
                    override fun onSetSuccess() {
                        offerSdp = desc.description
                        scope.launch { send("offer", sdp = desc.description) }
                    }
                }, desc)
            }
        }, mc)
    }

    private fun handleOffer(sdp: String) {
        val c = pc ?: return
        remoteSet = true // set early so repeated offers are ignored
        readyJob?.cancel()
        c.setRemoteDescription(object : SdpAdapter() {
            override fun onSetSuccess() {
                flushIce()
                c.createAnswer(object : SdpAdapter() {
                    override fun onCreateSuccess(desc: SessionDescription) {
                        c.setLocalDescription(object : SdpAdapter() {
                            override fun onSetSuccess() {
                                scope.launch { send("answer", sdp = desc.description) }
                            }
                        }, desc)
                    }
                }, MediaConstraints())
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    private fun handleAnswer(sdp: String) {
        val c = pc ?: return
        remoteSet = true
        c.setRemoteDescription(object : SdpAdapter() {
            override fun onSetSuccess() { flushIce() }
        }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
    }

    private fun flushIce() {
        val list = synchronized(pendingIce) { pendingIce.toList().also { pendingIce.clear() } }
        list.forEach { pc?.addIceCandidate(it) }
    }

    private val observer = object : PeerConnection.Observer {
        override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
        override fun onIceConnectionReceivingChange(b: Boolean) {}
        override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
        override fun onAddStream(s: MediaStream?) {}
        override fun onRemoveStream(s: MediaStream?) {}
        override fun onDataChannel(d: DataChannel?) {}
        override fun onRenegotiationNeeded() {}

        override fun onIceCandidate(c: IceCandidate) {
            scope.launch { send("ice", sdp = c.sdp, mid = c.sdpMid, idx = c.sdpMLineIndex) }
        }

        override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
            when (s) {
                PeerConnection.IceConnectionState.CONNECTED,
                PeerConnection.IceConnectionState.COMPLETED -> {
                    timeoutJob?.cancel()
                    if (_state.value != State.ENDED && _state.value != State.FAILED) {
                        _state.value = State.CONNECTED
                        startStats()
                    }
                }
                PeerConnection.IceConnectionState.DISCONNECTED ->
                    if (_state.value == State.CONNECTED) _state.value = State.RECONNECTING
                PeerConnection.IceConnectionState.FAILED -> fail("Connection lost")
                else -> {}
            }
        }
    }

    // -------------------- levels --------------------

    private fun startStats() {
        if (statsJob?.isActive == true) return
        statsJob = scope.launch {
            while (!closed) {
                pc?.getStats { report ->
                    var remote = 0.0
                    var local = 0.0
                    report.statsMap.values.forEach { st ->
                        val lvl = (st.members["audioLevel"] as? Number)?.toDouble() ?: return@forEach
                        when (st.type) {
                            "inbound-rtp" -> remote = maxOf(remote, lvl)
                            "media-source" -> local = maxOf(local, lvl)
                        }
                    }
                    _remoteLevel.value = remote.toFloat().coerceIn(0f, 1f)
                    _localLevel.value = if (muted) 0f else local.toFloat().coerceIn(0f, 1f)
                }
                delay(120)
            }
        }
    }

    // -------------------- controls --------------------

    fun setMuted(m: Boolean) {
        muted = m
        audioTrack?.setEnabled(!m)
    }

    fun setSpeaker(on: Boolean) {
        runCatching { audioManager.isSpeakerphoneOn = on }
    }

    /** End the call and tell the other side. */
    fun hangUp() {
        if (closed) return
        scope.launch {
            send("bye")
            finish("Call ended")
        }
    }

    private fun fail(reason: String) {
        if (closed) return
        endReason = reason
        _state.value = State.FAILED
        release()
    }

    private fun finish(reason: String) {
        if (closed) return
        endReason = reason
        _state.value = State.ENDED
        release()
    }

    /** Free everything. Safe to call more than once. */
    fun release() {
        if (closed) return
        closed = true
        readyJob?.cancel(); timeoutJob?.cancel(); statsJob?.cancel()
        runCatching { audioManager.isSpeakerphoneOn = false }
        runCatching { audioManager.mode = prevMode }
        val ch = channel
        runCatching { audioTrack?.setEnabled(false) }
        runCatching { pc?.close() }
        runCatching { pc?.dispose() }
        runCatching { audioTrack?.dispose() }
        runCatching { audioSource?.dispose() }
        runCatching { factory?.dispose() }
        pc = null; audioTrack = null; audioSource = null; factory = null
        // removing the channel suspends, so do it on a scope that outlives this engine
        CoroutineScope(Dispatchers.Default).launch {
            ch?.let { runCatching { repo.rawClient().realtime.removeChannel(it) } }
        }
        scope.cancel()
    }

    companion object {
        private const val TAG = "VoiceCall"
        @Volatile private var inited = false

        private fun ensureInit(ctx: Context) {
            if (inited) return
            synchronized(this) {
                if (inited) return
                PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions()
                )
                inited = true
            }
        }
    }
}

/** SdpObserver with no-op defaults. */
open class SdpAdapter : SdpObserver {
    override fun onCreateSuccess(desc: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(error: String?) { Log.e("VoiceCall", "sdp create failed: $error") }
    override fun onSetFailure(error: String?) { Log.e("VoiceCall", "sdp set failed: $error") }
}
