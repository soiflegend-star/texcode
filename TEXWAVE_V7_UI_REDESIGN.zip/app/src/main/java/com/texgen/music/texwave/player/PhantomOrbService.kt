package com.texgen.music.texwave.player

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.texgen.music.texwave.MainActivity
import com.texgen.music.texwave.R
import kotlin.math.min
import kotlin.math.sin

/**
 * Floating PHANTOM orb matching the Library orb (orb_core + orbit rings + swirl).
 */
class PhantomOrbService : Service() {

    private var windowManager: WindowManager? = null
    private var orbView: OrbView? = null
    private val main = Handler(Looper.getMainLooper())
    private val autoHide = Runnable { stopSelfSafe() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelfSafe()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            ensureChannel()
            startForeground(NOTIF_ID, buildNotif())
            attach()
            main.removeCallbacks(autoHide)
            // Stay visible while user speaks a command
            main.postDelayed(autoHide, 32_000L)
        } catch (_: Exception) {
            stopSelfSafe()
            return START_NOT_STICKY
        }
        return START_NOT_STICKY
    }

    private fun attach() {
        if (orbView != null) {
            orbView?.boost()
            return
        }
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val size = (112 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size,
            size,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP
            y = (100 * resources.displayMetrics.density).toInt()
        }
        val view = OrbView(this)
        orbView = view
        wm.addView(view, params)
    }

    private fun stopSelfSafe() {
        main.removeCallbacks(autoHide)
        try {
            orbView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }
        orbView = null
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        stopSelf()
    }

    override fun onDestroy() {
        main.removeCallbacks(autoHide)
        try {
            orbView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }
        orbView = null
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "PHANTOM orb", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                    setSound(null, null)
                },
            )
        }
    }

    private fun buildNotif() = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_notif_small)
        .setContentTitle("PHANTOM")
        .setContentText("Listening…")
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )
        .setOngoing(true)
        .setSilent(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    /** Library-style orb: core bitmap + rotating swirl + cyan/violet rings. */
    private class OrbView(context: Context) : View(context) {
        private var t = 0f
        private var energy = 1.15f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2.2f * resources.displayMetrics.density
        }
        private val matrix = Matrix()
        private val core: Bitmap? = try {
            BitmapFactory.decodeResource(resources, R.drawable.orb_core)
        } catch (_: Exception) {
            null
        }
        private val swirl: Bitmap? = try {
            BitmapFactory.decodeResource(resources, R.drawable.orb_swirl)
        } catch (_: Exception) {
            null
        }

        private val tick = object : Runnable {
            override fun run() {
                t += 0.045f
                energy += (1f - energy) * 0.04f
                invalidate()
                postDelayed(this, 16)
            }
        }

        fun boost() {
            energy = 1.35f
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            post(tick)
        }

        override fun onDetachedFromWindow() {
            removeCallbacks(tick)
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = w / 2f
            val cy = h / 2f
            val pulse = (0.94f + 0.06f * sin(t * 1.4f)) * energy
            val baseR = min(cx, cy) * 0.38f * pulse

            // Outer glow
            paint.shader = RadialGradient(
                cx, cy, baseR * 2.8f,
                intArrayOf(0x663DE0FF, 0x448B5CFF, 0x22E056A0, 0x00000000),
                floatArrayOf(0f, 0.35f, 0.65f, 1f),
                Shader.TileMode.CLAMP,
            )
            paint.style = Paint.Style.FILL
            paint.xfermode = null
            canvas.drawCircle(cx, cy, baseR * 2.6f, paint)
            paint.shader = null

            // Orbit rings (library style)
            ringPaint.color = 0x553DE0FF
            ringPaint.strokeWidth = 1.6f * resources.displayMetrics.density
            canvas.drawCircle(cx, cy, baseR * 1.28f, ringPaint)
            ringPaint.color = 0x668B5CFF
            ringPaint.strokeWidth = 1.2f * resources.displayMetrics.density
            canvas.drawCircle(cx, cy, baseR * 1.48f, ringPaint)
            ringPaint.color = 0x33E056A0
            ringPaint.strokeWidth = 0.9f * resources.displayMetrics.density
            canvas.drawCircle(cx, cy, baseR * 1.68f, ringPaint)

            // Swirl layer
            swirl?.let { bmp ->
                val d = baseR * 2.15f
                matrix.reset()
                matrix.postTranslate(-bmp.width / 2f, -bmp.height / 2f)
                matrix.postRotate((t * 28f) % 360f)
                matrix.postScale(d / bmp.width, d / bmp.height)
                matrix.postTranslate(cx, cy)
                paint.alpha = 160
                canvas.drawBitmap(bmp, matrix, paint)
                paint.alpha = 255
            }

            // Core orb image
            core?.let { bmp ->
                val d = baseR * 2f
                matrix.reset()
                matrix.postTranslate(-bmp.width / 2f, -bmp.height / 2f)
                matrix.postScale(d / bmp.width, d / bmp.height)
                matrix.postTranslate(cx, cy)
                paint.alpha = 240
                canvas.drawBitmap(bmp, matrix, paint)
                paint.alpha = 255
            } ?: run {
                paint.shader = RadialGradient(
                    cx, cy, baseR,
                    intArrayOf(0xFFFFFFFF.toInt(), 0xFF7BE0FF.toInt(), 0xFF8A5CFF.toInt()),
                    floatArrayOf(0f, 0.45f, 1f),
                    Shader.TileMode.CLAMP,
                )
                canvas.drawCircle(cx, cy, baseR, paint)
                paint.shader = null
            }
        }
    }

    companion object {
        const val ACTION_STOP = "com.texgen.music.texwave.ORB_STOP"
        private const val CHANNEL = "texwave_orb"
        private const val NOTIF_ID = 4253

        fun canOverlay(context: Context): Boolean = Settings.canDrawOverlays(context)

        fun show(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            try {
                val app = context.applicationContext
                val i = Intent(app, PhantomOrbService::class.java)
                if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(i)
                else app.startService(i)
            } catch (_: Exception) {
            }
        }

        fun hide(context: Context) {
            try {
                context.applicationContext.startService(
                    Intent(context.applicationContext, PhantomOrbService::class.java).setAction(ACTION_STOP),
                )
            } catch (_: Exception) {
            }
        }
    }
}
