package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.R
import kotlin.math.PI
import kotlin.math.sin

/**
 * PHANTOM's face: a luminous ghost floating inside a turning galaxy sphere.
 * Fully drawn (crisp at any size), with a gentle bob, a wavy hem, glowing eyes that blink
 * and a soft aura. Replaces the old flat silhouette picture.
 */
@Composable
fun PhantomAvatar(modifier: Modifier = Modifier, size: Dp = 104.dp) {
    val orb = ImageBitmap.imageResource(R.drawable.orb_core)
    val t = rememberInfiniteTransition(label = "phantomAvatar")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(40000, easing = LinearEasing)), label = "spin")
    val wave by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "wave")
    val blinkT by t.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart), label = "blink")
    val glow by t.animateFloat(0.7f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "glow")

    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val c = Offset(s / 2f, s / 2f)
        // galaxy sphere
        rotate(spin, c) {
            drawImage(
                orb,
                dstOffset = IntOffset(0, 0),
                dstSize = IntSize(s.toInt(), s.toInt()),
                alpha = 0.9f,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.High,
            )
        }
        // darken the centre so the ghost reads clearly
        drawCircle(Brush.radialGradient(listOf(Color(0xAA04010F), Color.Transparent), c, s * 0.36f), s * 0.36f, c)

        val bob = sin(wave) * s * 0.018f
        val bw = s * 0.46f
        val top = s * 0.20f + bob
        val bottom = s * 0.80f + bob
        val left = c.x - bw / 2f
        val right = c.x + bw / 2f
        val hemY = bottom - s * 0.05f
        val body = Path().apply {
            moveTo(left, hemY)
            cubicTo(left, top - s * 0.03f, right, top - s * 0.03f, right, hemY)
            // wavy hem: 4 scallops that ripple
            val n = 4
            val seg = bw / n
            for (i in 0 until n) {
                val x1 = right - seg * i
                val x2 = right - seg * (i + 1)
                val dip = s * 0.045f * sin(wave + i * 1.3f)
                quadraticBezierTo((x1 + x2) / 2f, bottom + dip, x2, hemY)
            }
            close()
        }
        // aura
        drawCircle(
            Brush.radialGradient(listOf(Color(0x66A37CFF).copy(alpha = 0.45f * glow), Color.Transparent), c, s * 0.5f),
            s * 0.5f, c,
        )
        drawPath(body, Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFD9CCFF), Color(0xFF8C6BFF)), top, bottom), alpha = 0.96f)
        drawPath(body, Color.White.copy(alpha = 0.6f), style = Stroke(width = 1.2f * density))

        // eyes (blink for ~6% of the cycle)
        val blink = if (blinkT in 0.94f..1f) 0.12f else 1f
        val ey = top + (hemY - top) * 0.40f
        val ex = bw * 0.20f
        val eyeW = s * 0.060f
        val eyeH = s * 0.095f * blink
        listOf(-1f, 1f).forEach { side ->
            val ec = Offset(c.x + side * ex, ey)
            drawCircle(
                Brush.radialGradient(listOf(Color(0xAA2FE6FF), Color.Transparent), ec, s * 0.12f),
                s * 0.12f, ec,
            )
            drawOval(Color(0xFF1B0B45), Offset(ec.x - eyeW, ec.y - eyeH), androidx.compose.ui.geometry.Size(eyeW * 2, eyeH * 2))
            drawOval(Color(0xFF7DF3FF), Offset(ec.x - eyeW * 0.55f, ec.y - eyeH * 0.55f), androidx.compose.ui.geometry.Size(eyeW * 1.1f, eyeH * 1.1f))
        }
        // tiny smile
        val sm = Path().apply {
            moveTo(c.x - s * 0.04f, ey + s * 0.09f)
            quadraticBezierTo(c.x, ey + s * 0.12f, c.x + s * 0.04f, ey + s * 0.09f)
        }
        drawPath(sm, Color(0xFF3A1F8F), style = Stroke(width = 1.6f * density, cap = androidx.compose.ui.graphics.StrokeCap.Round))
        // rim
        drawCircle(Color.White.copy(alpha = 0.35f), s / 2f - 1f, c, style = Stroke(1.2f * density))
    }
}
