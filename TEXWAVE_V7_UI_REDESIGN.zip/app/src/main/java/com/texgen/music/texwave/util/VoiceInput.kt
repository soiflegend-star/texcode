package com.texgen.music.texwave.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import org.vosk.Model
import org.vosk.android.RecognitionListener as VoskListener
import org.vosk.android.SpeechService
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Hybrid voice input:
 *  - Offline: Vosk (after the user downloads the model once, while online)
 *  - Online fallback: system SpeechRecognizer (Google / device packs)
 */
class VoiceInput(private val context: Context) {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var systemRecognizer: SpeechRecognizer? = null
    private var voskService: SpeechService? = null
    private var voskModel: Model? = null
    private val busy = AtomicBoolean(false)

    val models = VoskModelManager(app)

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    fun isSystemAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(app)

    fun isOfflineReady(): Boolean = models.isReady()

    fun start(
        preferOffline: Boolean = true,
        onPartial: (String) -> Unit = {},
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        onEnd: () -> Unit = {},
    ) {
        stop()
        if (!hasPermission()) {
            onError("Microphone permission required")
            return
        }
        val useVosk = preferOffline && models.isReady()
        if (useVosk) {
            startVosk(onPartial, onResult, onError, onEnd)
        } else {
            startSystem(onPartial, onResult, onError, onEnd)
        }
    }

    private fun startVosk(
        onPartial: (String) -> Unit,
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        onEnd: () -> Unit,
    ) {
        val path = models.modelPath()
        if (path == null) {
            onError("Offline model not ready")
            return
        }
        try {
            if (voskModel == null) {
                voskModel = Model(path)
            }
            val rec = org.vosk.Recognizer(voskModel, 16_000.0f)
            val service = SpeechService(rec, 16_000.0f)
            voskService = service
            busy.set(true)
            service.startListening(object : VoskListener {
                override fun onPartialResult(hypothesis: String?) {
                    val t = extractText(hypothesis)
                    if (t.isNotBlank()) main.post { onPartial(t) }
                }

                override fun onResult(hypothesis: String?) {
                    // intermediate final — ignore, wait for finalResult
                }

                override fun onFinalResult(hypothesis: String?) {
                    val t = extractText(hypothesis)
                    main.post {
                        busy.set(false)
                        if (t.isNotBlank()) onResult(t) else onError("Didn't catch that")
                        onEnd()
                    }
                    try { service.stop() } catch (_: Exception) {}
                }

                override fun onError(e: Exception?) {
                    main.post {
                        busy.set(false)
                        onError(e?.message ?: "Vosk error")
                        onEnd()
                    }
                }

                override fun onTimeout() {
                    main.post {
                        busy.set(false)
                        onError("No speech detected")
                        onEnd()
                    }
                }
            })
        } catch (e: Exception) {
            busy.set(false)
            onError("Offline voice failed: ${e.message}")
            onEnd()
        }
    }

    private fun extractText(hypothesis: String?): String {
        if (hypothesis.isNullOrBlank()) return ""
        return try {
            // Vosk returns JSON: {"text":"..."} or {"partial":"..."}
            val key = when {
                "\"text\"" in hypothesis -> "text"
                "\"partial\"" in hypothesis -> "partial"
                else -> return hypothesis.trim()
            }
            val i = hypothesis.indexOf("\"$key\"")
            val colon = hypothesis.indexOf(':', i)
            val start = hypothesis.indexOf('"', colon + 1) + 1
            val end = hypothesis.indexOf('"', start)
            if (start > 0 && end > start) hypothesis.substring(start, end).trim() else ""
        } catch (_: Exception) {
            hypothesis.trim()
        }
    }

    private fun startSystem(
        onPartial: (String) -> Unit,
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        onEnd: () -> Unit,
    ) {
        if (!isSystemAvailable()) {
            onError("Speech recognition not available. Download the offline model in PHANTOM.")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        systemRecognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio error"
                    SpeechRecognizer.ERROR_CLIENT -> "Client error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Need mic permission"
                    SpeechRecognizer.ERROR_NETWORK -> "Network error — download offline model for offline voice"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                    SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                    SpeechRecognizer.ERROR_SERVER -> "Server error"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
                    else -> "Error $error"
                }
                onError(msg)
                onEnd()
            }

            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull().orEmpty()
                if (text.isNotBlank()) onResult(text) else onError("Empty result")
                onEnd()
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                list?.firstOrNull()?.let { if (it.isNotBlank()) onPartial(it) }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        r.startListening(intent)
    }

    fun stop() {
        try {
            systemRecognizer?.stopListening()
            systemRecognizer?.cancel()
            systemRecognizer?.destroy()
        } catch (_: Exception) {
        }
        systemRecognizer = null
        try {
            voskService?.stop()
            voskService?.shutdown()
        } catch (_: Exception) {
        }
        voskService = null
        busy.set(false)
    }

    fun release() {
        stop()
        try {
            voskModel?.close()
        } catch (_: Exception) {
        }
        voskModel = null
    }
}
