package com.texgen.music.texwave.ui.screens.chat

import androidx.compose.foundation.background
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mail
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.SupabaseConfig
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.launch

@Composable
fun ChatAuthScreen(
    repo: ChatRepository,
    onBack: () -> Unit,
    onSignedIn: () -> Unit,
) {
    var isRegister by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = Tx.Accent,
        unfocusedBorderColor = Tx.Outline,
        focusedTextColor = Tx.Text,
        unfocusedTextColor = Tx.Text,
        cursorColor = Tx.Accent,
        focusedLabelColor = Tx.Accent,
        unfocusedLabelColor = Tx.Muted,
    )

    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .statusBarsPadding()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        IconButton(onClick = onBack, modifier = Modifier.align(Alignment.Start)) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Tx.Text)
        }

        Spacer(Modifier.height(12.dp))
        Icon(Icons.Rounded.Chat, contentDescription = null, tint = Tx.Accent, modifier = Modifier.padding(8.dp))
        Text(
            if (isRegister) "Create account" else "Sign in to Chat",
            color = Tx.Text,
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            "Private messaging inside Texwave",
            color = Tx.Muted,
            fontSize = 14.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 24.dp),
        )

        if (!SupabaseConfig.isConfigured) {
            Text(
                "Backend not configured yet.\nOpen SupabaseConfig.kt and paste your Project URL + anon key.",
                color = Tx.Danger,
                fontSize = 13.sp,
                modifier = Modifier.padding(16.dp),
            )
            return@Column
        }

        if (isRegister) {
            OutlinedTextField(
                value = displayName,
                onValueChange = { displayName = it },
                label = { Text("Display name") },
                leadingIcon = { Icon(Icons.Rounded.Person, null, tint = Tx.Muted) },
                singleLine = true,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = username,
                onValueChange = { username = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' }.take(24) },
                label = { Text("Username (unique)") },
                leadingIcon = { Icon(Icons.Rounded.Person, null, tint = Tx.Muted) },
                singleLine = true,
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                supportingText = { Text("3–24 chars, a-z 0-9 _", color = Tx.Muted, fontSize = 11.sp) },
            )
            Spacer(Modifier.height(12.dp))
        }

        OutlinedTextField(
            value = email,
            onValueChange = { email = it.replace(" ", "") },
            label = { Text("Email") },
            leadingIcon = { Icon(Icons.Rounded.Mail, null, tint = Tx.Muted) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            leadingIcon = { Icon(Icons.Rounded.Lock, null, tint = Tx.Muted) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
        )

        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = Tx.Danger, fontSize = 13.sp)
        }

        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                error = null
                loading = true
                scope.launch {
                    val result = if (isRegister) {
                        repo.signUp(email, password, displayName, username)
                    } else {
                        repo.signIn(email, password)
                    }
                    loading = false
                    result.fold(
                        onSuccess = { onSignedIn() },
                        onFailure = { e -> error = e.message ?: "Failed" },
                    )
                }
            },
            enabled = !loading && email.contains("@") && password.length >= 6
                    && (!isRegister || (username.length >= 3 && displayName.isNotBlank())),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent, contentColor = Color.Black),
        ) {
            if (loading) CircularProgressIndicator(color = Color.Black, modifier = Modifier.height(22.dp))
            else Text(if (isRegister) "Create account" else "Sign in", fontWeight = FontWeight.SemiBold)
        }

        TextButton(onClick = { isRegister = !isRegister; error = null }) {
            Text(
                if (isRegister) "Already have an account? Sign in" else "New here? Create an account",
                color = Tx.Accent,
            )
        }
    }
}
