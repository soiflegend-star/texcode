package com.texgen.music.texwave.data.chat

import com.texgen.music.texwave.data.Song
import org.json.JSONObject

/**
 * Resonance — music as a message.
 * Encoded in message body so no schema migration is required:
 *   TEXWAVE_RESONANCE:{json}
 */
object Resonance {
    private const val PREFIX = "TEXWAVE_RESONANCE:"

    val moods = listOf(
        "Lost in thought",
        "Unstoppable",
        "Peaceful",
        "Heart on fire",
        "Midnight drive",
        "Soft rain",
        "Victory",
        "Nostalgia",
    )

    data class Payload(
        val songId: Long = 0L,
        val title: String,
        val artist: String,
        val mood: String? = null,
        /** If this resonance replies to another resonance/message id */
        val replyToMessageId: String? = null,
        val album: String? = null,
        /** Supabase storage path so the other person can download & play */
        val storagePath: String? = null,
    ) {
        fun encode(): String {
            val j = JSONObject()
                .put("v", 1)
                .put("songId", songId)
                .put("title", title)
                .put("artist", artist)
            if (!mood.isNullOrBlank()) j.put("mood", mood)
            if (!replyToMessageId.isNullOrBlank()) j.put("replyTo", replyToMessageId)
            if (!album.isNullOrBlank()) j.put("album", album)
            if (!storagePath.isNullOrBlank()) j.put("storagePath", storagePath)
            return PREFIX + j.toString()
        }

        fun preview(): String = buildString {
            append("♪ $title")
            if (artist.isNotBlank()) append(" — $artist")
            if (!mood.isNullOrBlank()) append(" · $mood")
        }
    }

    fun isResonance(body: String?): Boolean =
        body != null && body.startsWith(PREFIX)

    fun parse(body: String?): Payload? {
        if (body == null || !body.startsWith(PREFIX)) return null
        return runCatching {
            val j = JSONObject(body.removePrefix(PREFIX))
            Payload(
                songId = j.optLong("songId", 0L),
                title = j.optString("title", "Unknown"),
                artist = j.optString("artist", ""),
                mood = j.optString("mood", null)?.takeIf { it.isNotBlank() },
                replyToMessageId = j.optString("replyTo", null)?.takeIf { it.isNotBlank() },
                album = j.optString("album", null)?.takeIf { it.isNotBlank() },
                storagePath = j.optString("storagePath", null)?.takeIf { it.isNotBlank() },
            )
        }.getOrNull()
    }

    fun fromSong(song: Song, mood: String? = null, replyTo: String? = null): Payload =
        Payload(
            songId = song.id,
            title = song.title,
            artist = song.artist,
            mood = mood,
            replyToMessageId = replyTo,
            album = song.album.takeIf { it.isNotBlank() },
        )
}
