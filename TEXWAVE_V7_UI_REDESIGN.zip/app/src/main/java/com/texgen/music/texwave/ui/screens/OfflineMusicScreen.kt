package com.texgen.music.texwave.ui.screens

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private val Cyan = Color(0xFF3DE0FF)
private val Violet = Color(0xFF9B6CFF)

private data class CatalogTrack(
    val identifier: String,
    val title: String,
    val artist: String,
    val fileName: String,
    val downloadUrl: String,
    val licenseUrl: String,
    val downloadId: Long = -1L,
) {
    fun json() = JSONObject().put("identifier", identifier).put("title", title).put("artist", artist)
        .put("fileName", fileName).put("downloadUrl", downloadUrl).put("licenseUrl", licenseUrl).put("downloadId", downloadId)
    companion object {
        fun from(o: JSONObject) = CatalogTrack(o.optString("identifier"), o.optString("title", "Untitled"),
            o.optString("artist", "Unknown artist"), o.optString("fileName"), o.optString("downloadUrl"),
            o.optString("licenseUrl"), o.optLong("downloadId", -1L))
    }
}

/** Internet Archive discovery limited to files whose metadata declares CC0, CC BY or CC BY-SA. */
private object OpenAudioCatalog {
    private fun getJson(url: String): JSONObject {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000; readTimeout = 15000
            setRequestProperty("User-Agent", "TEXWAVE/7.0 (open-audio-catalog)")
        }
        return try { JSONObject(connection.inputStream.bufferedReader().use { it.readText() }) }
        finally { connection.disconnect() }
    }
    suspend fun search(term: String): List<CatalogTrack> = withContext(Dispatchers.IO) {
        val q = if (term.isBlank()) "mediatype:audio" else "mediatype:audio AND title:\"${term.replace("\\", " ").replace("\"", " ").take(80)}\""
        val encoded = URLEncoder.encode(q, "UTF-8")
        val results = getJson("https://archive.org/advancedsearch.php?q=$encoded&fl[]=identifier,title,creator&rows=30&page=1&output=json")
            .optJSONObject("response")?.optJSONArray("docs") ?: JSONArray()
        val tracks = mutableListOf<CatalogTrack>()
        for (i in 0 until results.length()) {
            if (tracks.size >= 12) break
            val doc = results.optJSONObject(i) ?: continue
            val id = doc.optString("identifier").takeIf { it.isNotBlank() } ?: continue
            try {
                val meta = getJson("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}")
                val metadata = meta.optJSONObject("metadata") ?: continue
                val license = metadata.optString("licenseurl", metadata.optString("license_url", ""))
                val allowed = license.contains("creativecommons.org/publicdomain/zero", true) ||
                    license.contains("creativecommons.org/licenses/by/4.0", true) ||
                    license.contains("creativecommons.org/licenses/by/3.0", true) ||
                    license.contains("creativecommons.org/licenses/by-sa/4.0", true) ||
                    license.contains("creativecommons.org/licenses/by-sa/3.0", true)
                if (!allowed) continue
                val files = meta.optJSONArray("files") ?: continue
                var chosen: JSONObject? = null
                for (j in 0 until files.length()) {
                    val f = files.optJSONObject(j) ?: continue
                    val name = f.optString("name")
                    val format = f.optString("format")
                    if (name.endsWith(".mp3", true) && (format.contains("mp3", true) || format.contains("audio", true))) { chosen = f; break }
                }
                val file = chosen ?: continue
                val name = file.optString("name")
                if (name.isBlank() || name.contains("../")) continue
                val encodedName = name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                val title = metadata.optString("title", doc.optString("title", id)).ifBlank { id }
                val creator = metadata.optString("creator", doc.optString("creator", "Open audio creator"))
                tracks += CatalogTrack(id, title, creator, name.substringAfterLast('/'),
                    "https://archive.org/download/${URLEncoder.encode(id, "UTF-8")}/$encodedName", license)
            } catch (_: Exception) { /* skip unavailable or unverified metadata */ }
        }
        tracks
    }
}

@Composable
fun OfflineMusicScreen(onPlayDownloaded: (path: String, title: String, artist: String) -> Unit, onBack: (() -> Unit)? = null) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<CatalogTrack>>(emptyList()) }
    var downloads by remember { mutableStateOf(loadTracks(context)) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("Search openly licensed music to download for offline listening.") }

    fun refreshDownloads() { downloads = loadTracks(context) }
    LaunchedEffect(Unit) {
        // Refresh DownloadManager state after returning to this screen / app.
        while (true) { refreshDownloads(); delay(1800) }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF080A13)).padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.statusBarsPadding().padding(top = 8.dp, bottom = 4.dp)) {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
            Icon(Icons.Rounded.CloudDownload, null, tint = Cyan, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("OFFLINE MUSIC", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("Your phone + open music catalog", color = Color(0xFF9AA2C2), fontSize = 12.sp)
            }
            Icon(Icons.Rounded.Wifi, null, tint = Violet)
        }
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.weight(1f),
                singleLine = true, placeholder = { Text("Search open music") },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White, cursorColor = Cyan))
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                loading = true; error = null
                scope.launch {
                    try { results = OpenAudioCatalog.search(query); message = if (results.isEmpty()) "No verified CC0 / CC BY / CC BY-SA MP3s found. Try another search." else "Only tracks with supported open licences are shown." }
                    catch (e: Exception) { error = "Catalog unavailable. Check internet and try again." }
                    finally { loading = false }
                }
            }, enabled = !loading) { Icon(Icons.Rounded.Search, "Search catalog", tint = Cyan) }
        }
        Text("DOWNLOADS ON THIS DEVICE · ${downloads.count { isComplete(context, it.downloadId) }} READY", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            if (downloads.isNotEmpty()) {
                item { Text("Your offline tracks", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
                items(downloads, key = { "dl-${it.downloadId}" }) { track ->
                    val ready = isComplete(context, track.downloadId)
                    CatalogTrackCard(track.title, track.artist, if (ready) "PLAY OFFLINE" else downloadStatus(context, track.downloadId), ready,
                        onClick = {
                            if (ready) {
                                val path = downloadedPath(context, track.downloadId)
                                if (path != null) onPlayDownloaded(path, track.title, track.artist)
                            }
                        }, license = track.licenseUrl)
                }
            }
            item {
                Text("Open catalog", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                Text(message, color = Color(0xFF9AA2C2), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Cyan)
                error?.let { Text(it, color = Color(0xFFFF8A8A), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
            items(results, key = { "${it.identifier}-${it.fileName}" }) { track ->
                val already = downloads.any { it.identifier == track.identifier && it.fileName == track.fileName }
                CatalogTrackCard(track.title, track.artist, if (already) "ADDED" else "DOWNLOAD", already,
                    onClick = { if (!already) {
                        try {
                            val request = DownloadManager.Request(Uri.parse(track.downloadUrl))
                                .setTitle(track.title).setDescription("TEXWAVE · openly licensed audio")
                                .setMimeType("audio/mpeg")
                                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MUSIC, "texwave_${track.identifier.replace(Regex("[^A-Za-z0-9._-]"), "_")}_${track.fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            val id = manager.enqueue(request)
                            downloads = (downloads + track.copy(downloadId = id)); saveTracks(context, downloads)
                        } catch (_: Exception) { error = "Could not start download. Check available storage and try again." }
                    } }, license = track.licenseUrl)
            }
        }
    }
}

@Composable
private fun CatalogTrackCard(title: String, artist: String, action: String, done: Boolean, onClick: () -> Unit, license: String) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF121625), RoundedCornerShape(15.dp)).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).background(Color(0x222FE6FF), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Icon(if (done) Icons.Rounded.DownloadDone else Icons.Rounded.MusicNote, null, tint = Cyan)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 2, fontSize = 13.sp)
            Text(artist, color = Color(0xFF9AA2C2), maxLines = 1, fontSize = 11.sp)
            Text("Internet Archive · ${license.substringAfterLast('/').ifBlank { "open licence" }}", color = Color(0xFF6F7898), maxLines = 1, fontSize = 9.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text(action, color = if (done) Color(0xFF9B6CFF) else Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

private fun prefs(context: Context) = context.getSharedPreferences("texwave_open_downloads", Context.MODE_PRIVATE)
private fun loadTracks(context: Context): List<CatalogTrack> = try {
    val a = JSONArray(prefs(context).getString("tracks", "[]"))
    (0 until a.length()).mapNotNull { runCatching { CatalogTrack.from(a.getJSONObject(it)) }.getOrNull() }
} catch (_: Exception) { emptyList() }
private fun saveTracks(context: Context, tracks: List<CatalogTrack>) {
    val a = JSONArray(); tracks.distinctBy { it.downloadId }.forEach { a.put(it.json()) }
    prefs(context).edit().putString("tracks", a.toString()).apply()
}
private fun downloadedPath(context: Context, id: Long): String? {
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return null
    cursor.use {
        if (!it.moveToFirst() || it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_SUCCESSFUL) return null
        val uri = manager.getUriForDownloadedFile(id) ?: return null
        if (uri.scheme == "file") return uri.path
        // DownloadManager's content URI can be opened by Media3, but the playback helper expects a path.
        val local = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "texwave_play_$id.mp3")
        context.contentResolver.openInputStream(uri)?.use { input -> local.outputStream().use { output -> input.copyTo(output) } }
        return local.absolutePath.takeIf { local.exists() && local.length() > 0 }
    }
}
private fun isComplete(context: Context, id: Long): Boolean {
    return try {
        val c = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).query(DownloadManager.Query().setFilterById(id))
            ?: return false
        c.use { it.moveToFirst() && it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL }
    } catch (_: Exception) { false }
}
private fun downloadStatus(context: Context, id: Long): String {
    return try {
        val c = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).query(DownloadManager.Query().setFilterById(id))
            ?: return "QUEUED"
        c.use {
            if (!it.moveToFirst()) "QUEUED" else when (it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                DownloadManager.STATUS_SUCCESSFUL -> "READY"
                DownloadManager.STATUS_FAILED -> "FAILED"
                DownloadManager.STATUS_PAUSED -> "PAUSED"
                else -> "DOWNLOADING"
            }
        }
    } catch (_: Exception) { "QUEUED" }
}
