package com.texgen.music.texwave.data.chat

import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement

@Serializable
data class UserDataRow(
    @SerialName("user_id") val userId: String,
    val data: JsonElement,
)

/**
 * Saves / restores the user's music data (favorites, playlists, play counts, recents) in the
 * signed-in Supabase account, so it follows the user to any phone. Needs CREATE_USER_DATA_SYNC.sql.
 */
object CloudSync {
    suspend fun push(repo: ChatRepository, snapshotJson: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val uid = repo.rawCurrentUserId()
            val el = Json.parseToJsonElement(snapshotJson)
            repo.rawClient().from("app_user_data").upsert(UserDataRow(uid, el))
            Unit
        }.recoverCatching { e -> throw friendly(e) }
    }

    suspend fun pull(repo: ChatRepository): Result<String?> = withContext(Dispatchers.IO) {
        runCatching {
            val uid = repo.rawCurrentUserId()
            val row = repo.rawClient().from("app_user_data")
                .select { filter { eq("user_id", uid) } }
                .decodeSingleOrNull<UserDataRow>()
            row?.data?.toString()
        }.recoverCatching { e -> throw friendly(e) }
    }

    private fun friendly(e: Throwable): Throwable {
        val m = e.message ?: ""
        return if (m.contains("app_user_data") || m.contains("PGRST205") || m.contains("42P01"))
            IllegalStateException("Cloud backup isn't set up yet — run CREATE_USER_DATA_SYNC.sql in Supabase once.")
        else if (m.contains("Not signed in")) IllegalStateException("Sign in first.")
        else e
    }
}
