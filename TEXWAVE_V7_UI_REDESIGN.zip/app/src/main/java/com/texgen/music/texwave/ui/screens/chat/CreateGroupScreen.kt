package com.texgen.music.texwave.ui.screens.chat

import androidx.compose.foundation.background
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.Profile
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.launch

@Composable
fun CreateGroupScreen(
    repo: ChatRepository,
    onBack: () -> Unit,
    onGroupCreated: (conversationId: String, title: String) -> Unit,
) {
    var groupName by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Profile>>(emptyList()) }
    val selected = remember { mutableStateListOf<Profile>() }
    var loading by remember { mutableStateOf(false) }
    var creating by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) {
            results = emptyList()
            return
        }
        loading = true
        error = null
        scope.launch {
            repo.searchUsers(q)
                .onSuccess { results = it.filter { p -> selected.none { s -> s.id == p.id } } }
                .onFailure { error = it.message }
            loading = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .statusBarsPadding()
            .padding(horizontal = 12.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, "Back", tint = Tx.Text)
            }
            Text(
                "New group",
                color = Tx.Text,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            val canCreate = groupName.trim().length >= 2 && selected.isNotEmpty() && !creating
            Box(
                Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (canCreate) Tx.Accent else Tx.SurfaceHigh)
                    .clickable(enabled = canCreate) {
                        creating = true
                        error = null
                        scope.launch {
                            repo.createGroup(groupName.trim(), selected.map { it.id })
                                .onSuccess { cid ->
                                    onGroupCreated(cid, groupName.trim())
                                }
                                .onFailure { error = it.message }
                            creating = false
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            ) {
                if (creating) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.Black)
                } else {
                    Text(
                        "Create",
                        color = if (canCreate) Color.Black else Tx.Muted,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                    )
                }
            }
        }

        OutlinedTextField(
            value = groupName,
            onValueChange = { groupName = it.take(40) },
            placeholder = { Text("Group name", color = Tx.Muted) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Tx.Accent,
                unfocusedBorderColor = Tx.Outline,
                focusedTextColor = Tx.Text,
                unfocusedTextColor = Tx.Text,
                cursorColor = Tx.Accent,
            ),
        )

        if (selected.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(selected, key = { it.id }) { p ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box {
                            Box(
                                Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(Tx.SurfaceHigh),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    p.displayName.take(1).uppercase(),
                                    color = Tx.Accent,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(Tx.Danger)
                                    .clickable { selected.removeAll { it.id == p.id } },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Rounded.Close, null, tint = Color.White, modifier = Modifier.size(12.dp))
                            }
                        }
                        Text(p.displayName.take(8), color = Tx.Muted, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("Add members", color = Tx.Muted, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(6.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search username…", color = Tx.Muted) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Tx.Muted) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { search() }),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Tx.Accent,
                unfocusedBorderColor = Tx.Outline,
                focusedTextColor = Tx.Text,
                unfocusedTextColor = Tx.Text,
                cursorColor = Tx.Accent,
            ),
        )

        Spacer(Modifier.height(8.dp))
        if (loading) {
            Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Tx.Accent, strokeWidth = 2.dp)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(results, key = { it.id }) { profile ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (selected.none { it.id == profile.id }) {
                                    selected.add(profile)
                                    results = results.filter { it.id != profile.id }
                                }
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Tx.SurfaceHigh),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                profile.displayName.take(1).uppercase(),
                                color = Tx.Accent,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(profile.displayName, color = Tx.Text, fontWeight = FontWeight.Medium)
                            Text("@${profile.username}", color = Tx.Muted, fontSize = 13.sp)
                        }
                        Box(
                            Modifier
                                .size(24.dp)
                                .border(1.5.dp, Tx.Accent, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            // empty circle = add
                        }
                    }
                }
            }
        }
        error?.let {
            Text(it, color = Tx.Danger, fontSize = 13.sp, modifier = Modifier.padding(8.dp))
        }
    }
}
