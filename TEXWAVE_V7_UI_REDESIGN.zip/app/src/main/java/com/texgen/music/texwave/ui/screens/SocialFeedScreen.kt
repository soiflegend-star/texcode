package com.texgen.music.texwave.ui.screens

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.chat.SocialFeedRepository
import com.texgen.music.texwave.data.chat.SocialPost
import kotlinx.coroutines.launch

private val SocialBg = Color(0xFF070914)
private val SocialCyan = Color(0xFF00E5FF)
private val SocialViolet = Color(0xFF9B6CFF)

@Composable
fun SocialFeedScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { SocialFeedRepository.get(context) }
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf<List<SocialPost>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var caption by remember { mutableStateOf("") }
    var pendingType by remember { mutableStateOf("image") }
    var status by remember { mutableStateOf<String?>(null) }
    var likeState by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var likeCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var commentInputs by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var commentCounts by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }

    fun refresh() {
        loading = true
        scope.launch {
            repo.feed().onSuccess { loaded ->
                posts = loaded
                status = null
                val me = runCatching { repo.myUserId() }.getOrDefault("")
                val newLikes = mutableMapOf<String, Int>()
                val newMine = mutableMapOf<String, Boolean>()
                val newComments = mutableMapOf<String, Int>()
                loaded.forEach { post ->
                    repo.likesFor(post.id).getOrNull()?.let { likes ->
                        newLikes[post.id] = likes.size
                        newMine[post.id] = likes.any { it.user_id == me }
                    }
                    repo.commentsFor(post.id).getOrNull()?.let { newComments[post.id] = it.size }
                }
                likeCounts = newLikes
                likeState = newMine
                commentCounts = newComments
            }.onFailure { status = "Could not load the social feed. Sign in and run the TEXWAVE social SQL setup." }
            loading = false
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                repo.publish(uri, caption, pendingType)
                    .onSuccess { status = "Published! Your post is live."; caption = ""; refresh() }
                    .onFailure { status = it.message ?: "Upload failed. Check the social-media bucket and try again." }
                busy = false
            }
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize().background(SocialBg)) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("TEXWAVE COMMUNITY", color = Color.White, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp)
                Text("Photos • Reels • People", color = Color(0xFF9CA6C7), fontSize = 11.sp)
            }
            IconButton(onClick = { refresh() }, enabled = !loading) { Icon(Icons.Rounded.Refresh, "Refresh feed", tint = SocialCyan) }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).background(Color(0xFF10152A), RoundedCornerShape(20.dp)).padding(14.dp)) {
            Text("CREATE A POST", color = SocialCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = caption, onValueChange = { caption = it.take(2200) }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("What's happening? Add a caption…", color = Color(0xFF7883A7)) }, minLines = 2, maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = SocialCyan, unfocusedBorderColor = Color(0xFF303956), cursorColor = SocialCyan))
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { pendingType = "image"; picker.launch(arrayOf("image/*")) }, enabled = !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SocialViolet)) {
                    Icon(Icons.Rounded.Image, null); Spacer(Modifier.width(6.dp)); Text("Add photo")
                }
                Button(onClick = { pendingType = "video"; picker.launch(arrayOf("video/*")) }, enabled = !busy, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SocialCyan, contentColor = Color(0xFF06101B))) {
                    Icon(Icons.Rounded.Movie, null); Spacer(Modifier.width(6.dp)); Text("Upload reel")
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = SocialCyan)
            status?.let { Text(it, color = if (it.startsWith("Published")) SocialCyan else Color(0xFFFFA8B4), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = SocialCyan)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 30.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!loading && posts.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Your community starts here", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Upload the first photo or reel. Posts are visible to signed-in TEXWAVE users.", color = Color(0xFF9CA6C7), fontSize = 13.sp)
                }
            }
            items(posts, key = { it.id }) { post ->
                Column(Modifier.fillMaxWidth().background(Color(0xFF10152A), RoundedCornerShape(20.dp)).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (post.media_type == "video") "REEL" else "PHOTO", color = if (post.media_type == "video") SocialViolet else SocialCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                            Text("by ${post.user_id.take(8)}", color = Color(0xFF9CA6C7), fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (post.media_type == "image") {
                        AsyncImage(
                            model = post.media_url,
                            contentDescription = "Community photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 460.dp).clip(RoundedCornerShape(16.dp)),
                        )
                    } else {
                        // Play community videos inside TEXWAVE instead of handing them to an external app.
                        CommunityInlineVideo(url = post.media_url, modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp, max = 480.dp).clip(RoundedCornerShape(16.dp)))
                    }
                    if (post.caption.isNotBlank()) Text(post.caption, color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        TextButton(onClick = {
                            val liked = likeState[post.id] == true
                            scope.launch { repo.toggleLike(post.id, liked).onSuccess { likeState = likeState + (post.id to !liked); likeCounts = likeCounts + (post.id to ((likeCounts[post.id] ?: 0) + if (liked) -1 else 1)) }.onFailure { status = "Like failed: sign in or check the social SQL setup." } }
                        }) {
                            Icon(Icons.Rounded.Favorite, null, tint = if (likeState[post.id] == true) Color(0xFFFF4F91) else Color(0xFF9CA6C7))
                            Text(" ${likeCounts[post.id] ?: 0} Like", color = Color.White)
                        }
                        Text("${commentCounts[post.id] ?: 0} comments", color = Color(0xFF9CA6C7), fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = {
                            runCatching {
                                val request = DownloadManager.Request(Uri.parse(post.media_url)).setTitle("TEXWAVE ${post.media_type}").setDescription("Saving community media")
                                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "texwave_${post.id}.${if (post.media_type == "video") "mp4" else "jpg"}")
                                (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                                status = "Download started."
                            }.onFailure { status = "Could not start download." }
                        }, enabled = post.download_allowed) { Icon(Icons.Rounded.Download, "Download media", tint = SocialCyan) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = commentInputs[post.id].orEmpty(), onValueChange = { commentInputs = commentInputs + (post.id to it.take(1000)) }, modifier = Modifier.weight(1f), singleLine = true,
                            placeholder = { Text("Write a comment…", fontSize = 12.sp) }, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = SocialViolet, unfocusedBorderColor = Color(0xFF303956)))
                        IconButton(onClick = {
                            val text = commentInputs[post.id].orEmpty()
                            scope.launch { repo.addComment(post.id, text).onSuccess { commentInputs = commentInputs + (post.id to ""); commentCounts = commentCounts + (post.id to ((commentCounts[post.id] ?: 0) + 1)) }.onFailure { status = it.message ?: "Comment failed." } }
                        }) { Icon(Icons.Rounded.Send, "Post comment", tint = SocialViolet) }
                    }
                }
            }
        }
    }
}


@Composable
private fun CommunityInlineVideo(url: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
            playWhenReady = false
            setMediaItem(MediaItem.fromUri(Uri.parse(url)))
            prepare()
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = true
                controllerAutoShow = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                setKeepContentOnPlayerReset(true)
                this.player = player
            }
        },
        update = { view -> if (view.player !== player) view.player = player },
        modifier = modifier.background(Color.Black, RoundedCornerShape(16.dp))
    )
}
