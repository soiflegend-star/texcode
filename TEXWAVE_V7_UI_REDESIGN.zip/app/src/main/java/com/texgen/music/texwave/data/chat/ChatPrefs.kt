package com.texgen.music.texwave.data.chat

import android.content.Context

/** Per-conversation local settings: muted notifications and pinned-to-top. */
object ChatPrefs {
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("texwave_chat_prefs", Context.MODE_PRIVATE)

    fun isMuted(ctx: Context, id: String): Boolean = sp(ctx).getBoolean("mute_$id", false)
    fun isPinned(ctx: Context, id: String): Boolean = sp(ctx).getBoolean("pin_$id", false)

    fun setMuted(ctx: Context, id: String, v: Boolean) { sp(ctx).edit().putBoolean("mute_$id", v).apply() }
    fun setPinned(ctx: Context, id: String, v: Boolean) { sp(ctx).edit().putBoolean("pin_$id", v).apply() }
}
