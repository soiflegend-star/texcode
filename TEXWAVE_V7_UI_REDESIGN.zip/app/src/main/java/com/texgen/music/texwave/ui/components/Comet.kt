package com.texgen.music.texwave.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.pow

/**
 * A proper shooting star: a hot white head with a soft bloom, a long tapered tail that fades from
 * white through [accent] into nothing, and a small four-point glint.
 *
 * @param head   current head position
 * @param dir    unit vector the comet is travelling along (tail extends the opposite way)
 * @param length tail length in px
 * @param alpha  overall opacity 0..1
 */
fun DrawScope.drawComet(
    head: Offset,
    dir: Offset,
    length: Float,
    alpha: Float,
    accent: Color = Color(0xFF9B7CFF),
    thickness: Float = 3.2f * density,
) {
    if (alpha <= 0.01f) return
    val seg = 28
    for (k in 0 until seg) {
        val f0 = k / seg.toFloat()
        val f1 = (k + 1) / seg.toFloat()
        val p0 = Offset(head.x - dir.x * length * f0, head.y - dir.y * length * f0)
        val p1 = Offset(head.x - dir.x * length * f1, head.y - dir.y * length * f1)
        val fade = (1f - f0).pow(1.7f)
        // outer coloured glow
        drawLine(
            accent.copy(alpha = alpha * 0.30f * fade),
            p0, p1,
            strokeWidth = thickness * 3.2f * (1f - f0 * 0.85f),
            cap = StrokeCap.Round,
        )
        // bright core, white -> accent along the tail
        val core = Color(
            red = 1f + (accent.red - 1f) * f0,
            green = 1f + (accent.green - 1f) * f0,
            blue = 1f + (accent.blue - 1f) * f0,
            alpha = 1f,
        )
        drawLine(
            core.copy(alpha = alpha * fade),
            p0, p1,
            strokeWidth = thickness * (1f - f0 * 0.9f),
            cap = StrokeCap.Round,
        )
    }
    // head bloom
    val bloom = thickness * 7f
    drawCircle(
        Brush.radialGradient(
            listOf(Color.White.copy(alpha = alpha * 0.95f), accent.copy(alpha = alpha * 0.45f), Color.Transparent),
            head, bloom,
        ),
        bloom, head,
    )
    // glint cross
    val g = thickness * 4.2f
    drawLine(Color.White.copy(alpha = alpha * 0.9f), Offset(head.x - g, head.y), Offset(head.x + g, head.y), strokeWidth = thickness * 0.35f, cap = StrokeCap.Round)
    drawLine(Color.White.copy(alpha = alpha * 0.9f), Offset(head.x, head.y - g), Offset(head.x, head.y + g), strokeWidth = thickness * 0.35f, cap = StrokeCap.Round)
}
