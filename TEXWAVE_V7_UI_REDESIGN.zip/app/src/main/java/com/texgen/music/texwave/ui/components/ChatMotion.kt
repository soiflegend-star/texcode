package com.texgen.music.texwave.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.texgen.music.texwave.ui.theme.TexTokens

/**
 * Subtle fade + slide for newly appeared chat bubbles.
 * Does not animate items that are already settled in the list.
 */
@Composable
fun AnimatedMessageArrival(
    key: Any,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val visibleState = remember(key) {
        MutableTransitionState(false).apply { targetState = true }
    }
    AnimatedVisibility(
        visibleState = visibleState,
        enter = fadeIn(TexTokens.tweenNormal()) +
            slideInVertically(TexTokens.tweenEnter()) { h -> h / 8 },
        modifier = modifier,
    ) {
        Box { content() }
    }
}
