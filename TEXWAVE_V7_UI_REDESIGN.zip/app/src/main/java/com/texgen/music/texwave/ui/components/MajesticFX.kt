package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Full-screen majestic energy: orbiting rings, particle drift, soft pulse core.
 * Sit behind content with [Modifier.fillMaxSize] — drawn only, low cost.
 */
@Composable
fun MajesticEnergyField(
    modifier: Modifier = Modifier,
    cyan: Color = Tx.Accent2,
    violet: Color = Tx.Accent,
    pink: Color = Tx.Accent3,
) {
    val t = rememberInfiniteTransition(label = "majestic")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(28000, easing = LinearEasing)), label = "rot")
    val rot2 by t.animateFloat(0f, -360f, infiniteRepeatable(tween(19000, easing = LinearEasing)), label = "rot2")
    val pulse by t.animateFloat(0.85f, 1.12f, infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "pulse")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "drift")

    Canvas(modifier.fillMaxSize()) {
        val c = Offset(size.width * 0.5f, size.height * 0.42f)
        val r = min(size.width, size.height) * 0.28f
        // ambient bloom
        drawCircle(
            Brush.radialGradient(listOf(violet.copy(0.22f), cyan.copy(0.08f), Color.Transparent), c, r * 2.4f * pulse),
            r * 2.4f * pulse, c,
        )
        // rings
        for (i in 0 until 3) {
            val rr = r * (0.7f + i * 0.28f) * pulse
            drawCircle(
                listOf(cyan, violet, pink)[i].copy(alpha = 0.18f + i * 0.05f),
                rr, c, style = Stroke(width = (1.2f + i * 0.3f) * density),
            )
        }
        // orbiting beads
        for (k in 0 until 8) {
            val ang = Math.toRadians((rot + k * 45.0) % 360.0)
            val ang2 = Math.toRadians((rot2 + k * 40.0) % 360.0)
            val rr = r * (1.05f + (k % 3) * 0.12f)
            val p1 = Offset(c.x + cos(ang).toFloat() * rr, c.y + sin(ang).toFloat() * rr)
            val p2 = Offset(c.x + cos(ang2).toFloat() * rr * 0.85f, c.y + sin(ang2).toFloat() * rr * 0.85f)
            val col = if (k % 2 == 0) cyan else pink
            drawCircle(col.copy(alpha = 0.55f), 4.5f * density, p1)
            drawCircle(Color.White.copy(alpha = 0.7f), 1.6f * density, p1)
            drawCircle(violet.copy(alpha = 0.4f), 3.2f * density, p2)
        }
        // floating dust
        for (i in 0 until 40) {
            val x = ((i * 97 + drift * 120) % 1000) / 1000f * size.width
            val y = ((i * 53 + 20) % 1000) / 1000f * size.height
            val a = 0.08f + (i % 5) * 0.04f
            drawCircle(Color.White.copy(alpha = a), (0.6f + i % 3) * density, Offset(x, y))
        }
        // energy spokes
        for (s in 0 until 4) {
            val ang = Math.toRadians((rot * 0.5 + s * 90.0) % 360.0)
            val end = Offset(c.x + cos(ang).toFloat() * r * 1.5f, c.y + sin(ang).toFloat() * r * 1.5f)
            drawLine(cyan.copy(alpha = 0.08f), c, end, strokeWidth = 1.2f * density, cap = StrokeCap.Round)
        }
    }
}

@Composable
fun MajesticBackdrop(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        MajesticEnergyField(Modifier.fillMaxSize())
        content()
    }
}
