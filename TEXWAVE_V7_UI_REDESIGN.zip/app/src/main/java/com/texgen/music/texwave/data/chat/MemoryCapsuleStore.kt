package com.texgen.music.texwave.data.chat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Living Constellation — Memory Capsules.
 * Saved moments (message / resonance / note) that reopen on a chosen date.
 * Stored on-device so privacy stays with the user.
 */
object MemoryCapsuleStore {
    data class Capsule(
        val id: String,
        val conversationId: String,
        val title: String,
        val body: String,
        val createdAt: Long,
        /** Epoch ms when this capsule "opens" (0 = already open) */
        val opensAt: Long,
        val friendName: String = "",
    ) {
        val isOpen: Boolean get() = opensAt <= System.currentTimeMillis()
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("texwave_memory_capsules", Context.MODE_PRIVATE)

    fun list(ctx: Context, conversationId: String? = null): List<Capsule> {
        val arr = runCatching { JSONArray(prefs(ctx).getString("items", "[]")) }.getOrDefault(JSONArray())
        val out = mutableListOf<Capsule>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val c = Capsule(
                id = o.getString("id"),
                conversationId = o.getString("conversationId"),
                title = o.optString("title"),
                body = o.optString("body"),
                createdAt = o.optLong("createdAt"),
                opensAt = o.optLong("opensAt"),
                friendName = o.optString("friendName"),
            )
            if (conversationId == null || c.conversationId == conversationId) out.add(c)
        }
        return out.sortedByDescending { it.createdAt }
    }

    fun add(
        ctx: Context,
        conversationId: String,
        title: String,
        body: String,
        opensInDays: Int = 0,
        friendName: String = "",
    ): Capsule {
        val opensAt = if (opensInDays <= 0) System.currentTimeMillis()
        else System.currentTimeMillis() + opensInDays * 86_400_000L
        val c = Capsule(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            title = title.take(80),
            body = body.take(2000),
            createdAt = System.currentTimeMillis(),
            opensAt = opensAt,
            friendName = friendName,
        )
        val all = list(ctx).toMutableList()
        all.add(0, c)
        save(ctx, all)
        return c
    }

    fun remove(ctx: Context, id: String) {
        save(ctx, list(ctx).filterNot { it.id == id })
    }

    private fun save(ctx: Context, items: List<Capsule>) {
        val arr = JSONArray()
        items.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id)
                put("conversationId", c.conversationId)
                put("title", c.title)
                put("body", c.body)
                put("createdAt", c.createdAt)
                put("opensAt", c.opensAt)
                put("friendName", c.friendName)
            })
        }
        prefs(ctx).edit().putString("items", arr.toString()).apply()
    }
}
