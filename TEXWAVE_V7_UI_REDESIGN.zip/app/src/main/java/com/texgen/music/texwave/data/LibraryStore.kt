package com.texgen.music.texwave.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persists liked songs, playlists, history, play counts, positions, session. */
class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("texwave_library", Context.MODE_PRIVATE)

    fun loadLiked(): Set<Long> =
        (prefs.getStringSet(KEY_LIKED, emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()

    fun saveLiked(liked: Set<Long>) {
        prefs.edit().putStringSet(KEY_LIKED, liked.map { it.toString() }.toSet()).apply()
    }

    fun loadPlaylists(): List<Playlist> {
        val raw = prefs.getString(KEY_PLAYLISTS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ids = o.getJSONArray("songs")
                Playlist(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    songIds = (0 until ids.length()).map { ids.getLong(it) },
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun savePlaylists(playlists: List<Playlist>) {
        val arr = JSONArray()
        playlists.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("songs", JSONArray(p.songIds))
            )
        }
        prefs.edit().putString(KEY_PLAYLISTS, arr.toString()).apply()
    }

    fun loadRecents(): List<Long> =
        (prefs.getString(KEY_RECENTS, "") ?: "").split(',').mapNotNull { it.toLongOrNull() }

    fun saveRecents(ids: List<Long>) {
        prefs.edit().putString(KEY_RECENTS, ids.joinToString(",")).apply()
    }

    // Play counts: id -> count
    fun loadPlayCounts(): Map<Long, Int> {
        val raw = prefs.getString(KEY_PLAY_COUNTS, null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            o.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to o.getInt(k) } }.toMap()
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun savePlayCounts(map: Map<Long, Int>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k.toString(), v) }
        prefs.edit().putString(KEY_PLAY_COUNTS, o.toString()).apply()
    }

    // Resume positions: id -> positionMs
    fun loadPositions(): Map<Long, Long> {
        val raw = prefs.getString(KEY_POSITIONS, null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            o.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to o.getLong(k) } }.toMap()
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun savePositions(map: Map<Long, Long>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k.toString(), v) }
        prefs.edit().putString(KEY_POSITIONS, o.toString()).apply()
    }

    // Last session
    fun loadLastSession(): LastSession? {
        val id = prefs.getLong(KEY_SESSION_ID, -1L)
        if (id < 0) return null
        return LastSession(
            songId = id,
            positionMs = prefs.getLong(KEY_SESSION_POS, 0L),
            queueIds = (prefs.getString(KEY_SESSION_QUEUE, "") ?: "")
                .split(',').mapNotNull { it.toLongOrNull() },
            queueIndex = prefs.getInt(KEY_SESSION_INDEX, 0),
        )
    }

    fun saveLastSession(session: LastSession?) {
        if (session == null) {
            prefs.edit()
                .remove(KEY_SESSION_ID)
                .remove(KEY_SESSION_POS)
                .remove(KEY_SESSION_QUEUE)
                .remove(KEY_SESSION_INDEX)
                .apply()
            return
        }
        prefs.edit()
            .putLong(KEY_SESSION_ID, session.songId)
            .putLong(KEY_SESSION_POS, session.positionMs)
            .putString(KEY_SESSION_QUEUE, session.queueIds.joinToString(","))
            .putInt(KEY_SESSION_INDEX, session.queueIndex)
            .apply()
    }

    // Blacklist (exclude from shuffle)
    fun loadBlacklist(): Set<Long> =
        (prefs.getStringSet(KEY_BLACKLIST, emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()

    fun saveBlacklist(ids: Set<Long>) {
        prefs.edit().putStringSet(KEY_BLACKLIST, ids.map { it.toString() }.toSet()).apply()
    }

    private companion object {
        const val KEY_LIKED = "liked"
        const val KEY_PLAYLISTS = "playlists"
        const val KEY_RECENTS = "recents"
        const val KEY_PLAY_COUNTS = "play_counts"
        const val KEY_POSITIONS = "positions"
        const val KEY_SESSION_ID = "session_id"
        const val KEY_SESSION_POS = "session_pos"
        const val KEY_SESSION_QUEUE = "session_queue"
        const val KEY_SESSION_INDEX = "session_index"
        const val KEY_BLACKLIST = "blacklist"
    }
}

data class LastSession(
    val songId: Long,
    val positionMs: Long,
    val queueIds: List<Long>,
    val queueIndex: Int,
)
