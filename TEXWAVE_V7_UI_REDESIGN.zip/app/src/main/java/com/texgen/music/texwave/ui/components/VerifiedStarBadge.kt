package com.texgen.music.texwave.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** Metallic blue verified star shown after a username (Instagram-style). */
@Composable
fun VerifiedStarBadge(
    modifier: Modifier = Modifier,
    size: Dp = 16.dp,
) {
    Canvas(modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val rOuter = this.size.minDimension * 0.48f
        val rInner = rOuter * 0.42f
        val path = Path()
        for (i in 0 until 10) {
            val angle = Math.toRadians((-90.0 + i * 36.0))
            val r = if (i % 2 == 0) rOuter else rInner
            val x = cx + (r * cos(angle)).toFloat()
            val y = cy + (r * sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(
            path,
            brush = Brush.linearGradient(
                listOf(Color(0xFF5CE1FF), Color(0xFF1DA1F2), Color(0xFF7B61FF)),
                start = Offset(0f, 0f),
                end = Offset(this.size.width, this.size.height),
            ),
            style = Fill,
        )
        drawPath(
            path,
            color = Color.White.copy(alpha = 0.55f),
            style = Stroke(width = this.size.minDimension * 0.06f),
        )
    }
}
