package com.texgen.music.texwave.data.chat

/**
 * Call invite signaling over chat. The audio itself runs through [VoiceCallEngine] (WebRTC).
 *
 * TEXWAVE_CALL:INVITE|video|room|fromName
 * TEXWAVE_CALL:END|video|room|fromName
 */
object CallSignal {
    private const val PREFIX = "TEXWAVE_CALL:"

    enum class Action { INVITE, END, JOIN }

    data class Payload(
        val action: Action,
        val video: Boolean,
        val room: String,
        val fromName: String,
    )

    /** A fresh room per call so old signalling can never leak into a new call. */
    fun roomFor(conversationId: String): String =
        "tw${conversationId.replace("-", "").take(16)}${System.currentTimeMillis().toString(36)}"

    fun encodeInvite(video: Boolean, room: String, fromName: String): String =
        "$PREFIX${Action.INVITE.name}|${if (video) "1" else "0"}|$room|${fromName.replace("|", "")}"

    fun encodeEnd(video: Boolean, room: String, fromName: String): String =
        "$PREFIX${Action.END.name}|${if (video) "1" else "0"}|$room|${fromName.replace("|", "")}"

    fun parse(body: String?): Payload? {
        if (body == null || !body.startsWith(PREFIX)) return null
        val parts = body.removePrefix(PREFIX).split("|")
        if (parts.size < 4) return null
        val action = runCatching { Action.valueOf(parts[0]) }.getOrNull() ?: return null
        return Payload(
            action = action,
            video = parts[1] == "1",
            room = parts[2],
            fromName = parts[3],
        )
    }
}
