package com.texgen.music.texwave.ui.screens

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.texgen.music.texwave.data.catalog.OpenCatalogEngine
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.launch

@Composable
fun ReelsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("animation") }
    var reels by remember { mutableStateOf<List<OpenCatalogEngine.VideoItem>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf(true) }
    var muted by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(false) }
    var dragAcc by remember { mutableFloatStateOf(0f) }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            playWhenReady = true
        }
    }

    fun load(q: String) {
        loading = true
        error = null
        scope.launch {
            try {
                val list = OpenCatalogEngine.searchVideo(q, limit = 16)
                reels = list
                index = 0
                if (list.isEmpty()) error = "No reachable open clips. Try: animation, nature, train, jazz"
            } catch (e: Exception) {
                error = e.message ?: "Load failed"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        load(query)
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                buffering = playbackState == Player.STATE_BUFFERING
            }
            override fun onPlayerError(error: PlaybackException) {
                // Skip dead item
                if (index < reels.lastIndex) index++ else playing = false
            }
        })
    }

    LaunchedEffect(index, reels) {
        val cur = reels.getOrNull(index) ?: return@LaunchedEffect
        try {
            player.setMediaItem(MediaItem.fromUri(cur.url))
            player.prepare()
            player.playWhenReady = playing
            player.volume = if (muted) 0f else 1f
            // Preload hint: touch next URL in background probe (already probed at search)
            reels.getOrNull(index + 1)?.url?.let { OpenCatalogEngine.probeUrl(it) }
        } catch (_: Exception) {
            if (index < reels.lastIndex) index++
        }
    }

    LaunchedEffect(playing) { player.playWhenReady = playing }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    DisposableEffect(Unit) {
        onDispose {
            player.stop()
            player.release()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (reels.isNotEmpty()) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        this.player = player
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(reels, index) {
                        detectVerticalDragGestures(
                            onDragEnd = {
                                when {
                                    dragAcc < -80f && index < reels.lastIndex -> index++
                                    dragAcc > 80f && index > 0 -> index--
                                }
                                dragAcc = 0f
                            },
                            onVerticalDrag = { _, a -> dragAcc += a },
                        )
                    },
                update = { it.player = player },
            )
        }

        Box(Modifier.fillMaxWidth().height(140.dp).align(Alignment.TopCenter).background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent))))
        Box(Modifier.fillMaxWidth().height(200.dp).align(Alignment.BottomCenter).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE000000)))))

        Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null, tint = Color.White) }
                Text("Reels", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton(onClick = { muted = !muted }) {
                    Icon(if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp, null, tint = Color.White)
                }
                IconButton(onClick = { load(query) }) { Icon(Icons.Rounded.Refresh, null, tint = Tx.Accent2) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.weight(1f).height(52.dp),
                    singleLine = true,
                    placeholder = { Text("Search open clips…") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Tx.Accent2,
                        unfocusedBorderColor = Color(0x44FFFFFF),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Tx.Accent2,
                    ),
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { load(query) }, colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent)) {
                    Icon(Icons.Rounded.Search, null, modifier = Modifier.size(18.dp))
                }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Tx.Accent2)
            error?.let { Text(it, color = Tx.Danger, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }

            Spacer(Modifier.weight(1f))
            if (buffering) {
                CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally).padding(8.dp), color = Tx.Accent2)
            }
            val current = reels.getOrNull(index)
            if (current != null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    Column(Modifier.weight(1f)) {
                        Text(current.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("by ${current.creator}", color = Color(0xFFCDD5EC), fontSize = 12.sp, maxLines = 1)
                        Text("Probed · open license", color = Tx.Accent2, fontSize = 10.sp)
                        Text("${index + 1} / ${reels.size} · swipe up", color = Color(0x99FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        IconButton(
                            onClick = { playing = !playing },
                            modifier = Modifier.size(52.dp).clip(CircleShape).background(Color(0x66FFFFFF)),
                        ) {
                            Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        IconButton(onClick = { if (index > 0) index-- }) { Icon(Icons.Rounded.SkipPrevious, null, tint = Color.White) }
                        IconButton(onClick = { if (index < reels.lastIndex) index++ }) { Icon(Icons.Rounded.SkipNext, null, tint = Color.White) }
                    }
                }
            }
        }
    }
}
