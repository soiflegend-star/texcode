package com.texgen.music.texwave.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val ReelCyan = Color(0xFF00E5FF)
private val ReelViolet = Color(0xFF9B6CFF)
private data class OpenReel(val id:String,val title:String,val creator:String,val url:String,val license:String)

private object OpenVideoCatalog {
    private fun json(url:String):JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout=10000; c.readTimeout=12000
        c.setRequestProperty("User-Agent","TEXWAVE/7.0 open-video-browser")
        return try { JSONObject(c.getInputStream().bufferedReader().use { it.readText() }) } finally { c.disconnect() }
    }
    suspend fun search(term:String):List<OpenReel> = withContext(Dispatchers.IO) {
        val clean=term.replace("\\"," ").replace("\""," ").take(70).ifBlank { "short film" }
        val q=URLEncoder.encode("mediatype:movies AND title:(\"$clean\")", "UTF-8")
        val docs=json("https://archive.org/advancedsearch.php?q=$q&fl[]=identifier,title,creator&rows=25&page=1&output=json")
            .optJSONObject("response")?.optJSONArray("docs") ?: JSONArray()
        val out=mutableListOf<OpenReel>()
        for(i in 0 until docs.length()) {
            if(out.size>=10) break
            val d=docs.optJSONObject(i) ?: continue
            val id=d.optString("identifier").takeIf { it.isNotBlank() } ?: continue
            try {
                val meta=json("https://archive.org/metadata/${URLEncoder.encode(id,"UTF-8")}")
                val m=meta.optJSONObject("metadata") ?: continue
                val lic=m.optString("licenseurl",m.optString("license_url",""))
                val ok=lic.contains("creativecommons.org/publicdomain/zero",true) ||
                    lic.contains("creativecommons.org/licenses/by/4.0",true) || lic.contains("creativecommons.org/licenses/by/3.0",true) ||
                    lic.contains("creativecommons.org/licenses/by-sa/4.0",true) || lic.contains("creativecommons.org/licenses/by-sa/3.0",true)
                if(!ok) continue
                val files=meta.optJSONArray("files") ?: continue
                var chosen:String?=null
                for(j in 0 until files.length()) {
                    val f=files.optJSONObject(j) ?: continue
                    val name=f.optString("name"); val format=f.optString("format")
                    if((name.endsWith(".mp4",true) || name.endsWith(".webm",true)) && !name.contains("../") &&
                        (format.contains("mpeg4",true)||format.contains("mp4",true)||format.contains("webm",true)||name.endsWith(".mp4",true))) { chosen=name; break }
                }
                val name=chosen ?: continue
                val encoded=name.split("/").joinToString("/") { URLEncoder.encode(it,"UTF-8").replace("+","%20") }
                out += OpenReel(id,m.optString("title",d.optString("title",id)),m.optString("creator",d.optString("creator","Open creator")),
                    "https://archive.org/download/${URLEncoder.encode(id,"UTF-8")}/$encoded",lic)
            } catch (_:Exception) { }
        }
        out
    }
}

/** A real online catalog-backed video session. Only declared open-license items are listed. */
@Composable
fun ReelsScreen(onBack:()->Unit) {
    val context= LocalContext.current
    val scope= rememberCoroutineScope()
    var query by remember { mutableStateOf("short film") }
    var reels by remember { mutableStateOf<List<OpenReel>>(emptyList()) }
    var index by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf(true) }
    var drag by remember { mutableFloatStateOf(0f) }
    val current=reels.getOrNull(index)
    val player= remember { ExoPlayer.Builder(context).build().apply { playWhenReady=true; repeatMode=Player.REPEAT_MODE_ONE } }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(current?.url) {
        if(current!=null) { player.setMediaItem(MediaItem.fromUri(Uri.parse(current.url))); player.prepare(); player.playWhenReady=playing }
    }
    fun search() {
        loading=true; error=null
        scope.launch { try { reels=OpenVideoCatalog.search(query); index=0; if(reels.isEmpty()) error="No compatible open-licensed videos found. Try a broader search." }
            catch (_:Exception) { error="The video catalog is unavailable. Check your connection and retry." }
            finally { loading=false } }
    }
    LaunchedEffect(Unit) { search() }
    Column(Modifier.fillMaxSize().background(Color(0xFF050711))) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=12.dp, vertical=8.dp), verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack) { Icon(Icons.Rounded.ArrowBack,"Back",tint=Color.White) }
            Column(Modifier.weight(1f)) { Text("TEXWAVE REELS",color=Color.White,fontWeight=FontWeight.Bold,letterSpacing=2.sp); Text("Open-licensed video discovery",color=Color(0xFF9AA4C2),fontSize=11.sp) }
            IconButton(onClick={ search() },enabled=!loading) { Icon(Icons.Rounded.Refresh,"Refresh",tint=ReelCyan) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp, vertical=6.dp), verticalAlignment=Alignment.CenterVertically) {
            OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.weight(1f),singleLine=true,placeholder={Text("Search clips and short films")},
                colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=ReelCyan,focusedTextColor=Color.White,unfocusedTextColor=Color.White,cursorColor=ReelCyan))
            IconButton(onClick={search()},enabled=!loading) { Icon(Icons.Rounded.Search,"Search videos",tint=ReelCyan) }
        }
        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth(),color=ReelCyan)
        if(error!=null) Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
            Text(error!!,color=Color.White); Spacer(Modifier.height(12.dp)); Button(onClick={search()},colors=ButtonDefaults.buttonColors(containerColor=ReelViolet)){Text("Try again")}
        } else if(current!=null) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal=8.dp, vertical=6.dp).pointerInput(index,reels.size) {
                detectVerticalDragGestures(onVerticalDrag={ _, amount -> drag+=amount },onDragEnd={ if(drag < -55 && index<reels.lastIndex) index++; else if(drag>55 && index>0) index--; drag=0f })
            }.background(Color.Black,RoundedCornerShape(22.dp))) {
                AndroidView(factory={ ctx -> PlayerView(ctx).apply { useController=false; resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT } },
                    update={ it.player=player },modifier=Modifier.fillMaxSize())
                Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color(0xAA050711)).padding(16.dp)) {
                    Text(current.title,color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold,maxLines=2)
                    Text("by ${current.creator}",color=Color(0xFFCDD5EC),fontSize=12.sp,maxLines=1)
                    Text("License: ${current.license.substringAfterLast('/').ifBlank { "open license" }}",color=ReelCyan,fontSize=10.sp,maxLines=1)
                }
                Row(Modifier.align(Alignment.TopEnd).padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                    IconButton(onClick={playing=!playing; player.playWhenReady=playing}) { Icon(if(playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,if(playing) "Pause" else "Play",tint=Color.White) }
                }
                Row(Modifier.align(Alignment.Center).fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    IconButton(onClick={if(index>0) index--}) { Icon(Icons.Rounded.SkipPrevious,"Previous reel",tint=Color.White) }
                    IconButton(onClick={if(index<reels.lastIndex) index++}) { Icon(Icons.Rounded.SkipNext,"Next reel",tint=Color.White) }
                }
                Text("SWIPE UP FOR NEXT",color=Color.White.copy(alpha=.75f),fontSize=10.sp,letterSpacing=1.5.sp,modifier=Modifier.align(Alignment.TopCenter).padding(14.dp))
            }
            Text("${index+1} / ${reels.size}  ·  Content from Internet Archive",color=Color(0xFF9AA4C2),fontSize=11.sp,modifier=Modifier.align(Alignment.CenterHorizontally).padding(bottom=8.dp))
        } else if(!loading) Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center) { Text("Search for open-licensed clips to start.",color=Color.White) }
    }
}
