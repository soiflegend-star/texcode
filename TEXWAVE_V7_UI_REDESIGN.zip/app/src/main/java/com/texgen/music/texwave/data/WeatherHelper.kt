package com.texgen.music.texwave.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Free weather via Open-Meteo (no API key). Used by PHANTOM for "what's the weather" questions.
 */
object WeatherHelper {
    data class Report(
        val place: String,
        val tempC: Double,
        val feelsC: Double,
        val humidity: Int,
        val windKmh: Double,
        val code: Int,
        val summary: String,
    ) {
        fun spoken(): String = buildString {
            append("In $place it's $summary, ")
            append("${"%.0f".format(tempC)}°C")
            if (kotlin.math.abs(feelsC - tempC) >= 1.5) append(" (feels like ${"%.0f".format(feelsC)}°C)")
            append(", humidity $humidity%, wind ${"%.0f".format(windKmh)} km/h.")
        }
    }

    suspend fun forCity(city: String): Result<Report> = withContext(Dispatchers.IO) {
        runCatching {
            val q = URLEncoder.encode(city.trim(), "UTF-8")
            val geo = getJson("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=en&format=json")
            val results = geo.optJSONArray("results") ?: error("City not found: $city")
            if (results.length() == 0) error("City not found: $city")
            val place = results.getJSONObject(0)
            val name = place.optString("name", city)
            val country = place.optString("country", "")
            val lat = place.getDouble("latitude")
            val lon = place.getDouble("longitude")
            val wx = getJson(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m" +
                    "&timezone=auto",
            )
            val cur = wx.getJSONObject("current")
            val code = cur.optInt("weather_code", 0)
            Report(
                place = if (country.isBlank()) name else "$name, $country",
                tempC = cur.optDouble("temperature_2m", 0.0),
                feelsC = cur.optDouble("apparent_temperature", 0.0),
                humidity = cur.optInt("relative_humidity_2m", 0),
                windKmh = cur.optDouble("wind_speed_10m", 0.0),
                code = code,
                summary = codeLabel(code),
            )
        }
    }

    private fun codeLabel(code: Int): String = when (code) {
        0 -> "clear"
        1, 2 -> "mainly clear"
        3 -> "overcast"
        45, 48 -> "foggy"
        51, 53, 55 -> "drizzling"
        61, 63, 65 -> "raining"
        71, 73, 75, 77 -> "snowing"
        80, 81, 82 -> "showery"
        95, 96, 99 -> "thundery"
        else -> "mixed conditions"
    }

    private fun getJson(url: String): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 10_000
            requestMethod = "GET"
        }
        conn.inputStream.bufferedReader().use { reader ->
            return JSONObject(reader.readText())
        }
    }
}
