package com.texgen.music.texwave.ui.components

import android.media.audiofx.Visualizer
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.State
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.delay
import kotlin.math.sin

/**
 * Live loudness 0..1 from the audio session. Returns a [State] so callers can read it in a draw
 * scope only (no recomposition). Needs the mic permission; stays 0 when [enabled] is false or the
 * Visualizer can't be created.
 */
@Composable
fun rememberMusicHardness(audioSessionId: Int, active: Boolean, enabled: Boolean = true): State<Float> {
    val hardness = remember { mutableFloatStateOf(0f) }
    DisposableEffect(audioSessionId, active, enabled) {
        var viz: Visualizer? = null
        if (enabled && active && audioSessionId != 0) {
            try {
                viz = Visualizer(audioSessionId).apply {
                    captureSize = Visualizer.getCaptureSizeRange()[0]
                    setDataCaptureListener(
                        object : Visualizer.OnDataCaptureListener {
                            override fun onWaveFormDataCapture(
                                visualizer: Visualizer?,
                                waveform: ByteArray?,
                                samplingRate: Int,
                            ) {
                                if (waveform == null || waveform.isEmpty()) return
                                var sum = 0.0
                                for (b in waveform) {
                                    val v = (b.toInt() and 0xFF) - 128
                                    sum += v * v
                                }
                                val rms = kotlin.math.sqrt(sum / waveform.size) / 128.0
                                val target = (rms * 2.6).toFloat().coerceIn(0f, 1f)
                                // quick attack, slow release = smooth motion
                                val cur = hardness.floatValue
                                hardness.floatValue = if (target > cur) cur + (target - cur) * 0.6f else cur + (target - cur) * 0.2f
                            }
                            override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, sr: Int) {}
                        },
                        Visualizer.getMaxCaptureRate() / 2,
                        true,
                        false,
                    )
                    this.enabled = true
                }
            } catch (_: Throwable) {
                viz = null
            }
        }
        onDispose {
            try { viz?.enabled = false; viz?.release() } catch (_: Throwable) {}
        }
    }
    LaunchedEffect(active, enabled) {
        if (!active || !enabled) {
            while (hardness.floatValue > 0.02f) {
                hardness.floatValue *= 0.85f
                delay(32)
            }
            hardness.floatValue = 0f
        }
    }
    return hardness
}

/**
 * Water-flow visualizer. All animated values are read inside the draw block only, so the
 * composable itself never recomposes while animating.
 */
@Composable
fun WaterFlowVisualizer(
    active: Boolean,
    hardness: State<Float>,
    modifier: Modifier = Modifier,
    barCount: Int = 40,
) {
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(active) {
        if (active) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                phase.floatValue = (phase.floatValue + (now - last) / 1_000_000_000f * 2.6f) % (Math.PI * 2).toFloat()
                last = now
            }
        }
    }
    val c1 = Tx.Accent
    val c2 = Tx.Accent2
    val brush = remember(c1, c2) { Brush.verticalGradient(listOf(c1, c2, c1.copy(alpha = 0.6f))) }

    Canvas(modifier.fillMaxWidth().height(48.dp)) {
        val ph = phase.floatValue
        val hd = hardness.value
        val w = size.width
        val h = size.height
        val gap = 2.5.dp.toPx()
        val barW = ((w - gap * (barCount - 1)) / barCount).coerceAtLeast(2.dp.toPx())
        val mid = h / 2f
        val energy = if (active) (hd * 0.7f + 0.3f * (0.5f + 0.5f * sin(ph * 1.3f))).coerceIn(0.15f, 1f) else 0.06f
        for (i in 0 until barCount) {
            val xNorm = i.toFloat() / (barCount - 1).coerceAtLeast(1)
            val wave = sin(ph + xNorm * Math.PI.toFloat() * 3.2f)
            val secondary = sin(ph * 0.7f + xNorm * Math.PI.toFloat() * 5.1f) * 0.35f
            val level = if (active) {
                (0.18f + 0.82f * energy * (0.55f + 0.45f * wave) * (0.7f + 0.3f * secondary)).coerceIn(0.1f, 1f)
            } else 0.08f
            val barH = (h * level).coerceAtLeast(barW)
            drawRoundRect(
                brush = brush,
                topLeft = Offset(i * (barW + gap), mid - barH / 2f),
                size = Size(barW, barH),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f),
            )
        }
    }
}

/** Compact equalizer bars for list rows. */
@Composable
fun EqualizerBars(active: Boolean, modifier: Modifier = Modifier, color: androidx.compose.ui.graphics.Color = Tx.Accent2) {
    val t = rememberInfiniteTransition(label = "eq")
    val pState = t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(if (active) 600 else 2000, easing = LinearEasing), RepeatMode.Restart),
        label = "p",
    )
    Canvas(modifier.height(16.dp).fillMaxWidth()) {
        val p = pState.value
        val bars = 3
        val gap = 2.dp.toPx()
        val bw = (size.width - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val h = if (active) {
                size.height * (0.3f + 0.7f * (0.5f + 0.5f * sin((p * 6.28f) + i * 1.2f).toFloat()))
            } else size.height * 0.25f
            drawRoundRect(
                color = color,
                topLeft = Offset(i * (bw + gap), size.height - h),
                size = Size(bw, h),
                cornerRadius = CornerRadius(bw / 2f),
            )
        }
    }
}
