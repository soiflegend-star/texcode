package com.texgen.music.texwave.data.chat

import com.texgen.music.texwave.data.VerifiedBadgeStore

import android.content.Context

/**
 * Friends = people you have a 1:1 chat with.
 * Count is local + optional bio marker so others can see it on your profile.
 */
object FriendsStore {
    private const val PREFS = "texwave_friends"
    const val BIO_PREFIX = "[TW_FRIENDS:"

    fun syncFromConversations(ctx: Context, previews: List<ConversationPreview>): Set<String> {
        val ids = previews
            .filter { !it.conversation.isGroup }
            .mapNotNull { it.otherUser?.id }
            .toSet()
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putStringSet("ids", ids)
            .putInt("count", ids.size)
            .apply()
        return ids
    }

    fun count(ctx: Context): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("count", 0)

    fun ids(ctx: Context): Set<String> =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet("ids", emptySet()) ?: emptySet()

    fun parseCountFromBio(bio: String?): Int? {
        if (bio == null || !bio.contains(BIO_PREFIX)) return null
        val start = bio.indexOf(BIO_PREFIX) + BIO_PREFIX.length
        val end = bio.indexOf("]", start).takeIf { it > start } ?: return null
        return bio.substring(start, end).toIntOrNull()
    }

    fun withCountInBio(bio: String?, count: Int): String {
        val clean = bio.orEmpty()
            .replace(Regex("""\s*\[TW_FRIENDS:\d+]"""), "")
            .trim()
        val marker = "$BIO_PREFIX$count]"
        return if (clean.isBlank()) marker else "$clean $marker"
    }

    fun stripMarkers(bio: String?): String =
        bio.orEmpty()
            .replace(Regex("""\s*\[TW_FRIENDS:\d+]"""), "")
            .replace(VerifiedBadgeStore.BIO_MARKER, "")
            .trim()
}
