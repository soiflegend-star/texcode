package com.texgen.music.texwave.ui.screens

import com.texgen.music.texwave.ui.theme.Tx
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song

/**
 * Emotion Canvas — shareable TEXWAVE moment card for a track (private until user shares).
 */
@Composable
fun MomentCardScreen(
    song: Song?,
    moodLabel: String,
    onClose: () -> Unit,
) {
    val bg = when {
        moodLabel.contains("rain", true) || moodLabel.contains("calm", true) ->
            listOf(Color(0xFF0A1628), Color(0xFF1A3A5C))
        moodLabel.contains("boss", true) || moodLabel.contains("unstop", true) ->
            listOf(Color(0xFF1A0510), Color(0xFF5C1028))
        moodLabel.contains("space", true) || moodLabel.contains("night", true) ->
            listOf(Color(0xFF080818), Color(0xFF2A1060))
        else -> listOf(Color(0xFF0C0E18), Color(0xFF1A2840))
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF05060A))
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.verticalGradient(bg))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(24.dp))
                    .padding(28.dp),
            ) {
                Column {
                    Text(
                        "TEXWAVE MOMENT",
                        color = Color(0xFF7BDCFF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        song?.title ?: "No track",
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Light,
                    )
                    Text(
                        song?.artist ?: "",
                        color = Color.White.copy(alpha = 0.55f),
                        fontSize = 15.sp,
                    )
                    Spacer(Modifier.height(20.dp))
                    Text(
                        moodLabel.ifBlank { "Your wave" },
                        color = Tx.Accent2,
                        fontSize = 13.sp,
                    )
                    Spacer(Modifier.height(28.dp))
                    Text(
                        "A feeling you chose to keep.",
                        color = Color.White.copy(alpha = 0.35f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Start,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "TEXWAVE",
                        color = Color.White.copy(alpha = 0.25f),
                        fontSize = 10.sp,
                        letterSpacing = 3.sp,
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Private until you share it.",
                color = Color.White.copy(alpha = 0.4f),
                fontSize = 12.sp,
            )
            TextButton(onClick = onClose) {
                Text("Close", color = Color(0xFF7BDCFF))
            }
        }
    }
}
