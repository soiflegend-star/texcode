package com.texgen.music.texwave.data.chat

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Shared Soundtrack — songs exchanged via Resonance in a conversation
 * accumulate into a local playlist unique to that friendship.
 */
object SharedSoundtrackStore {
    data class Track(
        val title: String,
        val artist: String,
        val mood: String?,
        val songId: Long,
        val addedAt: Long,
        val byMe: Boolean,
    )

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("texwave_shared_soundtracks", Context.MODE_PRIVATE)

    fun list(ctx: Context, conversationId: String): List<Track> {
        val arr = runCatching {
            JSONArray(prefs(ctx).getString(conversationId, "[]"))
        }.getOrDefault(JSONArray())
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Track(
                title = o.optString("title"),
                artist = o.optString("artist"),
                mood = o.optString("mood", null)?.takeIf { it.isNotBlank() },
                songId = o.optLong("songId"),
                addedAt = o.optLong("addedAt"),
                byMe = o.optBoolean("byMe"),
            )
        }.reversed()
    }

    fun add(ctx: Context, conversationId: String, p: Resonance.Payload, byMe: Boolean) {
        val cur = list(ctx, conversationId).toMutableList()
        // Avoid exact duplicate of last track
        if (cur.firstOrNull()?.title == p.title && cur.firstOrNull()?.artist == p.artist) return
        cur.add(0, Track(p.title, p.artist, p.mood, p.songId, System.currentTimeMillis(), byMe))
        val arr = JSONArray()
        cur.take(100).forEach { t ->
            arr.put(JSONObject().apply {
                put("title", t.title)
                put("artist", t.artist)
                put("mood", t.mood ?: "")
                put("songId", t.songId)
                put("addedAt", t.addedAt)
                put("byMe", t.byMe)
            })
        }
        prefs(ctx).edit().putString(conversationId, arr.toString()).apply()
    }
}
