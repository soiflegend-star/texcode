package com.texgen.music.texwave.data

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Lightweight audio trim / export using MediaExtractor + MediaMuxer.
 * Works on most common audio containers (m4a, mp3 when system supports muxing).
 * Does not re-encode; it cuts at key-frame boundaries for speed and quality.
 */
object MusicEditor {
    private const val TAG = "MusicEditor"

    data class EditResult(
        val success: Boolean,
        val outputUri: String? = null,
        val message: String = "",
    )

    /**
     * Trim [sourceUri] from [startMs] to [endMs] and save as a new file in Music/Texwave.
     */
    suspend fun trim(
        context: Context,
        sourceUri: String,
        startMs: Long,
        endMs: Long,
        outputName: String,
    ): EditResult = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(context, Uri.parse(sourceUri), null)
            val trackIndex = (0 until extractor.trackCount).firstOrNull { i ->
                extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: return@withContext EditResult(false, message = "No audio track found")

            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)

            val outFile = createOutputFile(context, outputName)
            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxTrack = muxer.addTrack(format)
            muxer.start()

            val startUs = startMs * 1000
            val endUs = endMs * 1000
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val buffer = ByteBuffer.allocate(256 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val time = extractor.sampleTime
                if (time > endUs) break
                if (time >= startUs) {
                    info.offset = 0
                    info.size = sampleSize
                    info.presentationTimeUs = time - startUs
                    info.flags = extractor.sampleFlags
                    muxer.writeSampleData(muxTrack, buffer, info)
                }
                extractor.advance()
            }

            muxer.stop()
            muxer.release()
            muxer = null
            extractor.release()

            // Index in MediaStore so it appears in the library
            val mediaUri = insertIntoMediaStore(context, outFile, outputName)
            EditResult(true, mediaUri ?: outFile.toURI().toString(), "Saved: ${outFile.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Trim failed", e)
            try { muxer?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
            EditResult(false, message = e.message ?: "Trim failed")
        }
    }

    suspend fun getDurationMs(context: Context, uri: String): Long = withContext(Dispatchers.IO) {
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(context, Uri.parse(uri))
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            r.release()
            d
        } catch (_: Exception) {
            0L
        }
    }

    private fun createOutputFile(context: Context, name: String): File {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
            "Texwave"
        )
        if (!dir.exists()) dir.mkdirs()
        val safe = name.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        var file = File(dir, "$safe.m4a")
        var i = 1
        while (file.exists()) {
            file = File(dir, "${safe}_$i.m4a")
            i++
        }
        return file
    }

    /**
     * Index the file that is already on disk with the system media scanner. (The old approach inserted
     * a second MediaStore row for the same path, which on Android 10+ could create an empty duplicate
     * entry — tapping it then played the wrong / next song.)
     */
    private suspend fun insertIntoMediaStore(context: Context, file: File, title: String): String? {
        return try {
            kotlinx.coroutines.withTimeoutOrNull(6_000) {
                kotlinx.coroutines.suspendCancellableCoroutine<String?> { cont ->
                    android.media.MediaScannerConnection.scanFile(
                        context.applicationContext,
                        arrayOf(file.absolutePath),
                        arrayOf("audio/mp4"),
                    ) { _, uri -> if (cont.isActive) cont.resumeWith(Result.success(uri?.toString())) }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "scan failed: ${e.message}")
            null
        }
    }
}
