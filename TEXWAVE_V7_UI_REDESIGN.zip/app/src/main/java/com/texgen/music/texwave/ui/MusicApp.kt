package com.texgen.music.texwave.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import android.content.BroadcastReceiver
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.runtime.DisposableEffect
import kotlinx.coroutines.launch
import kotlinx.coroutines.MainScope
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.texgen.music.texwave.data.Playlist
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.components.EmptyState
import com.texgen.music.texwave.ui.components.GradientButton
import com.texgen.music.texwave.ui.components.ConfirmDialog
import com.texgen.music.texwave.ui.components.MiniPlayer
import com.texgen.music.texwave.ui.components.NamePlaylistDialog
import com.texgen.music.texwave.ui.components.PlaylistPickerSheet
import com.texgen.music.texwave.ui.components.QueueSheet
import com.texgen.music.texwave.ui.components.SongOptionsSheet
import com.texgen.music.texwave.ui.components.ParticleField
import com.texgen.music.texwave.ui.components.TexNavBar
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import androidx.compose.animation.togetherWith
import com.texgen.music.texwave.ui.screens.HomeScreen
import com.texgen.music.texwave.ui.screens.ResonancePortalScreen
import com.texgen.music.texwave.ui.screens.NebulaIntroScreen
import com.texgen.music.texwave.ui.screens.LivingWaveScreen
import com.texgen.music.texwave.ui.screens.ConstellationScreen
import com.texgen.music.texwave.ui.screens.MomentCardScreen
import com.texgen.music.texwave.ui.screens.LibraryScreen
import com.texgen.music.texwave.ui.screens.universe.UniverseDest
import com.texgen.music.texwave.ui.screens.universe.UniverseHubScreen
import com.texgen.music.texwave.ui.screens.universe.UniverseRouter
import com.texgen.music.texwave.ui.screens.NowPlayingScreen
import com.texgen.music.texwave.ui.screens.SimilarSongsScreen
import com.texgen.music.texwave.ui.screens.LovedDest
import com.texgen.music.texwave.ui.screens.LovedHubScreen
import com.texgen.music.texwave.ui.screens.LovedRouter
import com.texgen.music.texwave.ui.screens.PlaylistDetailScreen
import com.texgen.music.texwave.ui.screens.SearchScreen
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.TexwaveTheme
import com.texgen.music.texwave.ui.screens.SettingsScreen
import com.texgen.music.texwave.ui.screens.MemesScreen
import com.texgen.music.texwave.ui.screens.OfflineMusicScreen
import com.texgen.music.texwave.ui.screens.ReelsScreen
import com.texgen.music.texwave.ui.screens.StreamLibraryScreen
import com.texgen.music.texwave.ui.screens.SocialFeedScreen
import com.texgen.music.texwave.ui.components.NavTarget
import com.texgen.music.texwave.ui.components.SideNavDrawer
import com.texgen.music.texwave.ui.components.SideNavHandle
import com.texgen.music.texwave.ui.components.SideNavRail
import com.texgen.music.texwave.ui.components.RailWidth
import com.texgen.music.texwave.ui.screens.WavesScreen
import com.texgen.music.texwave.ui.screens.EqualizerScreen
import com.texgen.music.texwave.ui.screens.MusicEditorScreen
import com.texgen.music.texwave.ui.screens.AlarmScreen
import com.texgen.music.texwave.ui.screens.PhantomScreen
import com.texgen.music.texwave.ui.screens.PhantomChatScreen
import com.texgen.music.texwave.ui.components.LocalCustomArt
import com.texgen.music.texwave.ui.screens.SettingsActions
import com.texgen.music.texwave.ui.screens.ChatMessage
import com.texgen.music.texwave.ui.components.SleepTimerSheet
import com.texgen.music.texwave.ui.components.SpeedSheet
import com.texgen.music.texwave.ui.components.LyricsSheet
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.ChatNotifier
import com.texgen.music.texwave.ui.components.PhantomWakeOverlay
import com.texgen.music.texwave.data.chat.ChatAuthState
import com.texgen.music.texwave.ui.screens.chat.ChatAuthScreen
import com.texgen.music.texwave.ui.screens.chat.ChatListScreen
import com.texgen.music.texwave.ui.screens.chat.ConversationScreen
import com.texgen.music.texwave.ui.screens.chat.CreateGroupScreen
import com.texgen.music.texwave.ui.screens.chat.UserSearchScreen
import com.texgen.music.texwave.ui.screens.chat.ProfileScreen

private val audioPermission: String
    get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasAudioPermission(context: Context) =
    ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED

/** Makes sure runtime permission dialogs appear one after another, never together. */
private object PermissionQueue {
    @Volatile var busy: Boolean = false
}

private data class OptionsTarget(val song: Song, val playlistId: String?)

@Composable
fun MusicApp(vm: MusicViewModel = viewModel()) {
    TexwaveTheme {
        val context = LocalContext.current
        var granted by remember { mutableStateOf(hasAudioPermission(context)) }
        val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { wasGranted ->
            PermissionQueue.busy = false
            // Re-check Android's permission state rather than trusting a stale callback after
            // an activity recreation or vendor-specific permission dialog.
            granted = wasGranted && hasAudioPermission(context)
            if (!granted) {
                android.widget.Toast.makeText(
                    context,
                    "Audio access wasn't granted. You can allow it in Android Settings and try again.",
                    android.widget.Toast.LENGTH_LONG,
                ).show()
            }
        }

        // Ask for exactly one permission on first launch: audio library access. Notifications,
        // microphone, and overlay access are requested only when the user enables those features.
        // Automatically showing a second permission dialog shortly after the first made some
        // Android skins look like the app was bursting/crashing during startup.
        LaunchedEffect(granted) {
            if (granted) {
                // Let Android finish dismissing its permission sheet before querying MediaStore.
                // Some OEM builds briefly recreate/resume the activity during this transition.
                kotlinx.coroutines.delay(1200)
                if (hasAudioPermission(context) && !vm.lib.value.scanned && !vm.lib.value.loading) {
                    vm.scanLibrary()
                }
            }
        }

        if (!granted) {
            Box(Modifier.fillMaxSize()) {
                EmptyState(
                    icon = Icons.Rounded.MusicNote,
                    title = "Welcome to Texwave",
                    message = "Allow access to your audio files so Texwave can build your library. Everything stays on your device.",
                    action = {
                        GradientButton("Allow access", Icons.Rounded.LibraryMusic, {
                            PermissionQueue.busy = true
                            audioLauncher.launch(audioPermission)
                        })
                    },
                )
            }
        } else {
            AppContent(vm)
        }
    }
}

@Composable
private fun AppContent(vm: MusicViewModel) {
    val context = LocalContext.current
    val lib by vm.lib.collectAsState()
    val player by vm.player.collectAsState()
    val position = vm.position.collectAsState()

    var showIntro by rememberSaveable { mutableStateOf(true) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var openPlaylistId by rememberSaveable { mutableStateOf<String?>(null) }
    var showNowPlaying by rememberSaveable { mutableStateOf(false) }
    var showSimilarSongs by rememberSaveable { mutableStateOf(false) }
    var showLovedHub by rememberSaveable { mutableStateOf(false) }
    var lovedDest by remember { mutableStateOf<LovedDest?>(null) }
    var showSignature by rememberSaveable { mutableStateOf(false) } // off by default — was crashing after permission
    var showConstellation by rememberSaveable { mutableStateOf(false) }
    var showMyProfile by rememberSaveable { mutableStateOf(false) }
    var showMoment by remember { mutableStateOf(false) }
    var showPhantomChat by rememberSaveable { mutableStateOf(false) }
    var showUniverseHub by rememberSaveable { mutableStateOf(false) }
    var universeDest by remember { mutableStateOf<UniverseDest?>(null) }
    var showNav by rememberSaveable { mutableStateOf(false) } // persistent rail is the default; full drawer is opt-in
    val navPrefs = remember { context.getSharedPreferences("texwave_ui", android.content.Context.MODE_PRIVATE) }
    var railHidden by remember { mutableStateOf(true) } // sidebar removed — full-bleed premium chrome
    val setRailHidden: (Boolean) -> Unit = { h -> railHidden = h; navPrefs.edit().putBoolean("nav_rail_hidden", h).apply() }
    var libTabReq by remember { mutableStateOf(0 to 0) }
    var soundsOn by remember { mutableStateOf(com.texgen.music.texwave.util.UiSound.isEnabled(context)) }
    var showMemes by rememberSaveable { mutableStateOf(false) }
    var showOfflineMusic by rememberSaveable { mutableStateOf(false) }
    var showReels by rememberSaveable { mutableStateOf(false) }
    var showStreamLibrary by rememberSaveable { mutableStateOf(false) }
    var showCommunity by rememberSaveable { mutableStateOf(false) }
    var showWaves by rememberSaveable { mutableStateOf(false) }
    var phantomStudioMode by rememberSaveable { mutableStateOf("chat") }
    var phantomWakeRgb by remember { mutableStateOf(false) }
    var phantomOnline by rememberSaveable { mutableStateOf(true) }
    // User-to-user chat (Supabase)
    val chatRepo = remember { ChatRepository.get(context) }
    val chatAuth by chatRepo.authState.collectAsState()
    var chatConversationId by rememberSaveable { mutableStateOf<String?>(null) }
    var chatConversationTitle by rememberSaveable { mutableStateOf("") }
    var pendingCallRoom by remember { mutableStateOf<String?>(null) }
    var pendingCallVideo by remember { mutableStateOf(false) }

    // Notifications + deep links from message/call notifications
    LaunchedEffect(Unit) {
        ChatNotifier.ensureChannel(context)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            val ok = androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.POST_NOTIFICATIONS,
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!ok) {
                // permission is requested from ChatList; still ensure channel exists
            }
        }
        val act = context as? android.app.Activity
        val intent = act?.intent
        val openId = intent?.getStringExtra("open_chat")
        if (!openId.isNullOrBlank()) {
            chatConversationId = openId
            chatConversationTitle = "Chat"
        }
        val room = intent?.getStringExtra("join_call_room")
        if (!room.isNullOrBlank()) {
            pendingCallRoom = room
            pendingCallVideo = intent?.getBooleanExtra("join_call_video", false) == true
            val from = intent?.getStringExtra("join_call_from")
            if (!from.isNullOrBlank()) chatConversationTitle = from
            // Ensure chat opens so CallOverlay can mount
            if (chatConversationId.isNullOrBlank()) {
                val cid = intent?.getStringExtra("open_chat")
                if (!cid.isNullOrBlank()) chatConversationId = cid
            }
            // Start keep-alive so signaling stays up while joining
            runCatching {
                com.texgen.music.texwave.data.chat.ChatKeepAliveService.start(context.applicationContext)
            }
        }
        val wakeCmd = intent?.getStringExtra("wake_command")
        if (!wakeCmd.isNullOrBlank()) {
            phantomWakeRgb = true
            showPhantomChat = true
            val lower = wakeCmd.lowercase().trim()
            val order = lower
                .removePrefix("hey phantom")
                .removePrefix("ok phantom")
                .removePrefix("okay phantom")
                .removePrefix("phantom")
                .removePrefix("fantom")
                .removePrefix("fantom")
                .trim()
            if (order.isNotBlank() && order != "phantom") {
                kotlinx.coroutines.MainScope().launch {
                    val result = vm.phantomChat(order, emptyList())
                    val reply = result.getOrElse { e -> e.message ?: "Something went wrong" }
                    com.texgen.music.texwave.util.SpeechOut(context).speak(reply)
                }
            }
            // Wake-only ("phantom") is already acknowledged by the service with "I am hearing"
        }
    }

    var showUserSearch by rememberSaveable { mutableStateOf(false) }
    var showCreateGroup by rememberSaveable { mutableStateOf(false) }
    var showChatSettings by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var options by remember { mutableStateOf<OptionsTarget?>(null) }
    var pickerSong by remember { mutableStateOf<Song?>(null) }
    // When non-null a "name your playlist" dialog is open; the value is an optional song to add on create.
    var newPlaylistFor by remember { mutableStateOf<Long?>(null) }
    var newPlaylistOpen by remember { mutableStateOf(false) }
    var deletePlaylistTarget by remember { mutableStateOf<Playlist?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showEqualizer by remember { mutableStateOf(false) }
    var showEditor by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    val settings by vm.settings.collectAsState()
    LaunchedEffect(showNowPlaying) {
        if (showNowPlaying) com.texgen.music.texwave.util.UiSound.play(context, com.texgen.music.texwave.util.UiSound.Kind.OPEN)
    }

    // Wake-word commands from WakeWordService — fully autonomous replies
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: android.content.Context?, intent: Intent?) {
                val heard = intent?.getStringExtra(com.texgen.music.texwave.player.WakeWordService.EXTRA_TEXT) ?: return
                val lower = heard.lowercase().trim()
                phantomWakeRgb = true
                showPhantomChat = true
                // Pure wake word only — service already said "I am hearing"
                if (lower in listOf("phantom", "fantom", "fantom", "hey phantom", "ok phantom", "okay phantom")) {
                    return
                }
                val order = lower
                    .removePrefix("hey phantom")
                    .removePrefix("ok phantom")
                    .removePrefix("okay phantom")
                    .removePrefix("phantom")
                    .removePrefix("fantom")
                    .removePrefix("fantom")
                    .trim()
                    .ifBlank { heard.trim() }
                if (order.isBlank()) return
                kotlinx.coroutines.MainScope().launch {
                    val result = vm.phantomChat(order, emptyList())
                    val reply = result.getOrElse { e -> e.message ?: "Something went wrong" }
                    com.texgen.music.texwave.util.SpeechOut(context).speak(reply)
                }
            }
        }
        val filter = IntentFilter(com.texgen.music.texwave.player.WakeWordService.ACTION_COMMAND)
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(receiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(receiver, filter)
        }
        // Auto-resume wake listening if user had it enabled
        try {
            if (vm.settings.value.wakeEnabled) {
                val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                    context, android.Manifest.permission.RECORD_AUDIO,
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (hasMic) {
                    com.texgen.music.texwave.player.WakeWordService.startIfEnabled(context)
                }
            }
        } catch (_: Exception) {}
        onDispose {
            try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }


    // Keep draining pending wake commands while app is open (pipeline safety net)
    LaunchedEffect(settings.wakeEnabled) {
        if (!settings.wakeEnabled) return@LaunchedEffect
        while (true) {
            kotlinx.coroutines.delay(1500)
            try {
                val pending = com.texgen.music.texwave.data.AppSettings(context).consumePendingWakeCommand()
                if (!pending.isNullOrBlank()) {
                    phantomWakeRgb = true
                    showPhantomChat = true
                    val order = pending.lowercase().trim()
                        .removePrefix("hey phantom").removePrefix("ok phantom").removePrefix("okay phantom")
                        .removePrefix("phantom").removePrefix("fantom").trim()
                    if (order.isNotBlank() && order !in listOf("phantom", "fantom")) {
                        val result = vm.phantomChat(order, emptyList())
                        val reply = result.getOrElse { e -> e.message ?: "Something went wrong" }
                        com.texgen.music.texwave.util.SpeechOut(context).speak(reply)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    // Process wake command delivered while UI was not listening (service saved it)
    LaunchedEffect(Unit) {
        fun handleWake(orderRaw: String) {
            val lower = orderRaw.lowercase().trim()
            if (lower.isBlank()) return
            phantomWakeRgb = true
            showPhantomChat = true
            if (lower in listOf("phantom", "fantom", "hey phantom", "ok phantom", "okay phantom")) return
            val order = lower
                .removePrefix("hey phantom")
                .removePrefix("ok phantom")
                .removePrefix("okay phantom")
                .removePrefix("phantom")
                .removePrefix("fantom")
                .trim()
                .ifBlank { orderRaw.trim() }
            if (order.isBlank()) return
            kotlinx.coroutines.MainScope().launch {
                val result = vm.phantomChat(order, emptyList())
                val reply = result.getOrElse { e -> e.message ?: "Something went wrong" }
                com.texgen.music.texwave.util.SpeechOut(context).speak(reply)
            }
        }
        // From activity intent
        try {
            val act = context as? android.app.Activity
            val fromIntent = act?.intent?.getStringExtra("wake_command")
                ?: act?.intent?.getStringExtra(com.texgen.music.texwave.player.WakeWordService.EXTRA_TEXT)
            if (!fromIntent.isNullOrBlank()) {
                act?.intent?.removeExtra("wake_command")
                handleWake(fromIntent)
            }
        } catch (_: Exception) {}
        // From persisted queue
        try {
            val pending = com.texgen.music.texwave.data.AppSettings(context).consumePendingWakeCommand()
            if (!pending.isNullOrBlank()) handleWake(pending)
        } catch (_: Exception) {}
    }



    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { PermissionQueue.busy = false }
    val permScope = androidx.compose.runtime.rememberCoroutineScope()
    // Microphone is asked only when needed, and never while another permission dialog is open.
    val askMicState = androidx.compose.runtime.rememberUpdatedState<() -> Unit> {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permScope.launch {
                var waited = 0
                while (PermissionQueue.busy && waited < 20_000) { kotlinx.coroutines.delay(300); waited += 300 }
                PermissionQueue.busy = true
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }
    fun askMic() { askMicState.value.invoke() }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val songId = player.current?.id
        if (uri != null && songId != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            vm.setCustomArt(songId, uri)
        }
    }
    val playerBgPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            vm.setPlayerBackground(uri)
        }
    }
    val notifImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setNotifImage(uri)
    }
    val notifVideoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setNotifVideo(uri)
    }

    val openPlaylist = lib.playlists.firstOrNull { it.id == openPlaylistId }
    LaunchedEffect(openPlaylist, openPlaylistId) {
        if (openPlaylistId != null && openPlaylist == null) openPlaylistId = null
    }

    BackHandler(enabled = showMoment) { showMoment = false }
    BackHandler(enabled = showMyProfile) { showMyProfile = false }
    BackHandler(enabled = showConstellation) { showConstellation = false; tab = 0 }
    BackHandler(enabled = showSimilarSongs) { showSimilarSongs = false }
    BackHandler(enabled = lovedDest != null) { lovedDest = null }
    BackHandler(enabled = showLovedHub && lovedDest == null) { showLovedHub = false }
    BackHandler(enabled = showNowPlaying && !showSimilarSongs) { showNowPlaying = false }
    BackHandler(enabled = !showNowPlaying && openPlaylist != null) { openPlaylistId = null }
    BackHandler(enabled = !showNowPlaying && openPlaylist == null && tab != 0) { tab = 0 }
    BackHandler(enabled = showEqualizer) { showEqualizer = false }
    BackHandler(enabled = showEditor) { showEditor = false }
    BackHandler(enabled = showMemes) { showMemes = false }
    BackHandler(enabled = showOfflineMusic) { showOfflineMusic = false }
    BackHandler(enabled = showReels) { showReels = false }
    BackHandler(enabled = showStreamLibrary) { showStreamLibrary = false }
    BackHandler(enabled = showCommunity) { showCommunity = false }
    BackHandler(enabled = showSignature) { showSignature = false }
    BackHandler(enabled = showWaves) { showWaves = false }
    BackHandler(enabled = showPhantomChat) { showPhantomChat = false }
    BackHandler(enabled = universeDest != null) { universeDest = null }
    BackHandler(enabled = showUniverseHub && universeDest == null) { showUniverseHub = false }

    // ── Side navigation: every screen and setting, reachable from every session ──
    // Keep the navigation rail mounted across every normal app session, including overlays.
    // Only the intro/signature hand-off hides it; destinations remain available everywhere.
    val navAvailable = !showIntro && !showSignature
    val navigate: (NavTarget) -> Unit = { t ->
        showNav = false
        // Navigation switches sessions; it must not stack full-screen pages on top
        // of one another. Reset transient screens/sheets first, then open only the target.
        tab = 0
        openPlaylistId = null
        showNowPlaying = false
        showSimilarSongs = false
        showLovedHub = false
        lovedDest = null
        showConstellation = false
        showMyProfile = false
        showMoment = false
        showPhantomChat = false
        showUniverseHub = false
        universeDest = null
        showMemes = false
        showOfflineMusic = false
        showReels = false
        showStreamLibrary = false
        showCommunity = false
        showWaves = false
        showUserSearch = false
        showCreateGroup = false
        showChatSettings = false
        chatConversationId = null
        showSettings = false
        showEqualizer = false
        showEditor = false
        showSleep = false
        showQueue = false
        showSpeed = false
        showLyrics = false
        options = null
        pickerSong = null
        newPlaylistOpen = false
        deletePlaylistTarget = null
        fun openLib(i: Int) { openPlaylistId = null; tab = 2; libTabReq = i to (libTabReq.second + 1) }
        when (t) {
            NavTarget.Home -> { openPlaylistId = null; tab = 0 }
            NavTarget.Downloads -> { showOfflineMusic = true }
            NavTarget.Reels -> { showReels = true }
            NavTarget.Community -> { showCommunity = true }
            NavTarget.Search -> { openPlaylistId = null; tab = 1 }
            NavTarget.Library -> openLib(0)
            NavTarget.LibraryOrb -> openLib(1)
            NavTarget.Stars -> showConstellation = true
            NavTarget.Radar -> openLib(6)
            NavTarget.Explore -> { showStreamLibrary = true }
            NavTarget.SesCinema, NavTarget.SesGps, NavTarget.SesTwin, NavTarget.SesPulse,
            NavTarget.SesAutopsy, NavTarget.SesCapsule, NavTarget.SesSanctuary, NavTarget.SesFrequency,
            NavTarget.SesIdentity, NavTarget.SesRepair, NavTarget.SesDream, NavTarget.SesLab,
            NavTarget.SesWeather, NavTarget.SesAnchors, NavTarget.SesGhost, NavTarget.SesLiving, NavTarget.SesUnplayed ->
                openLib(10 + t.ordinal - NavTarget.SesCinema.ordinal)
            NavTarget.Chats -> {
                openPlaylistId = null
                showPhantomChat = false
                showLovedHub = false
                lovedDest = null
                tab = 3
            }
            NavTarget.LovedRooms -> { showLovedHub = true }
            NavTarget.Phantom -> {
                openPlaylistId = null
                showPhantomChat = false
                tab = 4
            }
            NavTarget.PhantomChat, NavTarget.PhantomKey -> {
                tab = 4
                phantomStudioMode = "chat"
                showPhantomChat = true
            }
            NavTarget.PhantomCode, NavTarget.PhantomImage -> {
                // Chat-only Phantom — code/image studios removed from product surface
                tab = 4
                phantomStudioMode = "chat"
                showPhantomChat = true
            }
            NavTarget.Equalizer -> {
                if (player.current == null) android.widget.Toast.makeText(context, "Play a song so the equalizer can attach", android.widget.Toast.LENGTH_SHORT).show()
                showEqualizer = true
            }
            NavTarget.Editor -> showEditor = true
            NavTarget.Alarms -> { openPlaylistId = null; tab = 5 }
            NavTarget.SleepTimer -> showSleep = true
            NavTarget.Rescan -> {
                vm.scanLibrary()
                android.widget.Toast.makeText(context, "Scanning for new songs…", android.widget.Toast.LENGTH_SHORT).show()
            }
            NavTarget.Theme -> playerBgPicker.launch(arrayOf("image/*"))
            NavTarget.Sounds -> {
                soundsOn = !soundsOn
                com.texgen.music.texwave.util.UiSound.setEnabled(context, soundsOn)
            }
            NavTarget.Profile -> showMyProfile = true
            NavTarget.Settings, NavTarget.Notifications -> showSettings = true
        }
    }
    PhantomWakeOverlay(active = phantomWakeRgb) { phantomWakeRgb = false }
    BackHandler(enabled = chatConversationId != null) { chatConversationId = null }

    CompositionLocalProvider(LocalCustomArt provides settings.customArt) {
    Box(Modifier.fillMaxSize()) {
        // Single exclusive branch — no return@Box (avoids Composer Stack.pop IndexOutOfBounds)
        // Main content + overlays. Intro fades out on top so the hand-off is smooth.
        when {
            showSignature -> LivingWaveScreen(
                reducedMotion = !settings.particles,
                onEnterWave = {
                    showSignature = false
                    showConstellation = false
                    tab = 0
                },
                onEnterLibrary = {
                    showSignature = false
                    tab = 2
                },
                onEnterYou = {
                    showSignature = false
                    tab = 3 // Chat tab
                },
            )
            showMyProfile -> com.texgen.music.texwave.ui.screens.MyProfileScreen(
                repo = chatRepo,
                vm = vm,
                onBack = { showMyProfile = false },
                onOpenChat = { showMyProfile = false; tab = 3 },
                onOpenSettings = { showMyProfile = false; showSettings = true },
            )
            showConstellation -> ConstellationScreen(
                songs = lib.songs,
                onPlay = { s ->
                    val all = lib.songs
                    val i = all.indexOfFirst { it.id == s.id }.coerceAtLeast(0)
                    vm.playSongs(all, i)
                },
                currentSongId = player.current?.id,
                isPlaying = player.isPlaying,
                onOpenLibrary = {
                    showConstellation = false
                    tab = 2
                },
                onBack = { showConstellation = false; tab = 0 },
            )
            showMoment -> MomentCardScreen(
                song = player.current,
                moodLabel = "Your constellation",
                onClose = {
                    showMoment = false
                    showConstellation = false
                    showNowPlaying = true
                },
            )
            else -> Scaffold(
            // Reserve real layout width for the persistent rail instead of drawing content
            // underneath it. This keeps the dock, headings and cards aligned to one grid.
            modifier = Modifier.sonicAtmosphere(), // full width — no side rail gutter
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            bottomBar = {
                Column {
                    if (tab != 0 || openPlaylist != null) {
                        MiniPlayer(
                            state = player,
                            position = position,
                            onOpen = { showNowPlaying = true },
                            onToggle = vm::togglePlay,
                            onNext = vm::next,
                        )
                    }
                    // Dock: Home · Search · Library · Chat · Phantom
                    // Internal tabs: 0 Home, 1 Search, 2 Library, 3 Chat, 4 Phantom, 5 Alarm
                    TexNavBar(
                        selected = when {
                            openPlaylist != null -> -1
                            tab in 0..4 -> tab
                            else -> -1
                        },
                        onSelect = { i ->
                            openPlaylistId = null
                            tab = i.coerceIn(0, 4)
                        },
                    )
                }
            },
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                androidx.compose.animation.AnimatedContent(
                    targetState = if (openPlaylist != null) -1 else tab,
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(320, 90)) +
                            androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(380, 90), initialScale = 0.94f) +
                            androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(380, 90)) { w -> dir * w / 10 }) togetherWith
                            (androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160)) +
                                androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(220)) { w -> -dir * w / 12 })
                    },
                    label = "tabs",
                ) { t ->
                when {
                    lib.songs.isEmpty() && lib.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Tx.Accent2)
                    }

                    lib.songs.isEmpty() && t in 0..1 -> EmptyState(
                        icon = Icons.Rounded.MusicNote,
                        title = "No music found",
                        message = lib.error ?: "Add some songs to your device, then scan again.",
                        action = { GradientButton("Scan again", Icons.Rounded.LibraryMusic, vm::scanLibrary) },
                    )

                    openPlaylist != null -> {
                        val byId = remember(lib.songs) { lib.songs.associateBy { it.id } }
                        val songs = remember(openPlaylist, byId) { openPlaylist.songIds.mapNotNull { byId[it] } }
                        PlaylistDetailScreen(
                            playlist = openPlaylist,
                            songs = songs,
                            lib = lib,
                            player = player,
                            onBack = { openPlaylistId = null },
                            onDelete = { deletePlaylistTarget = openPlaylist },
                            onPlay = vm::playSongs,
                            onShuffle = vm::shuffleAll,
                            onMore = { options = OptionsTarget(it, openPlaylist.id) },
                        )
                    }

                    t == 0 -> {
                        // Soft-start: first 1.5s use reduced motion so OEM permission
                        // transitions cannot kill the process; then full Resonance Portal.
                        var portalReady by remember { mutableStateOf(false) }
                        LaunchedEffect(Unit) {
                            kotlinx.coroutines.delay(600)
                            portalReady = true
                        }
                        ResonancePortalScreen(
                            lib = lib,
                            player = player,
                            position = position,
                            reducedMotion = !portalReady, // only first 0.6s light motion, then full circles+waves
                            onOpenNowPlaying = { showNowPlaying = true },
                            onBeginWave = {
                                runCatching {
                                    val mix = vm.dailyMix()
                                    when {
                                        mix.isNotEmpty() -> vm.playSongs(mix, 0)
                                        lib.songs.isNotEmpty() -> vm.shuffleAll(lib.songs)
                                    }
                                }
                            },
                            onDiscover = { tab = 1 },
                            onLibrary = { tab = 2 },
                            onPhantom = { tab = 4 },
                            onContinue = { s ->
                                runCatching {
                                    val all = lib.songs
                                    val i = all.indexOfFirst { it.id == s.id }.coerceAtLeast(0)
                                    if (all.isNotEmpty()) {
                                        if (player.current?.id == s.id) showNowPlaying = true
                                        else {
                                            vm.playSongs(all, i)
                                            showNowPlaying = true
                                        }
                                    }
                                }
                            },
                            onToggle = { runCatching { vm.togglePlay() } },
                            onNext = { runCatching { vm.next() } },
                            onEmotion = { mode -> runCatching { vm.playEmotion(mode) } },
                            onOpenSignature = { showSignature = true },
                            onPlayList = { songs -> runCatching { if (songs.isNotEmpty()) vm.playSongs(songs, 0) } },
                            onToggleLike = { id -> runCatching { vm.toggleLike(id) } },
                            onOpenConstellation = { showConstellation = true },
                            onOpenRadar = { tab = 2; libTabReq = 6 to (libTabReq.second + 1) },
                            onOpenStreamLibrary = { showStreamLibrary = true },
                            onOpenCommunity = { showCommunity = true },
                            onOpenDownloads = { showOfflineMusic = true },
                        )
                    }

                    t == 1 -> SearchScreen(
                        lib = lib, player = player,
                        onPlay = vm::playSongs,
                        onMore = { options = OptionsTarget(it, null) },
                    )

                    t == 3 -> {
                        // User-to-user Chat hub (list / search / groups / auth).
                        // Active conversation opens as a full-screen session overlay (like Phantom Chat).
                        when {
                            showChatSettings -> ProfileScreen(
                                repo = chatRepo,
                                onBack = { showChatSettings = false },
                                onSignedOut = { showChatSettings = false },
                            )
                            showCreateGroup -> CreateGroupScreen(
                                repo = chatRepo,
                                onBack = { showCreateGroup = false },
                                onGroupCreated = { cid, title ->
                                    chatConversationId = cid
                                    chatConversationTitle = title
                                    showCreateGroup = false
                                },
                            )
                            showUserSearch -> UserSearchScreen(
                                repo = chatRepo,
                                onBack = { showUserSearch = false },
                                onStartChat = { cid, title ->
                                    chatConversationId = cid
                                    chatConversationTitle = title
                                    showUserSearch = false
                                },
                            )
                            chatAuth is ChatAuthState.SignedIn -> ChatListScreen(
                                repo = chatRepo,
                                onBack = { tab = 0 },
                                onOpenConversation = { cid, title ->
                                    chatConversationId = cid
                                    chatConversationTitle = title
                                },
                                onSearchUsers = { showUserSearch = true },
                                onCreateGroup = { showCreateGroup = true },
                                onOpenSettings = { showChatSettings = true },
                                onSidebarHome = { tab = 0 },
                                onSidebarWaves = { navigate(NavTarget.Radar) },
                                onSidebarMemes = { navigate(NavTarget.SesCinema) },
                                onSidebarDiscover = { showMyProfile = true },
                                onSidebarMusic = { navigate(NavTarget.LibraryOrb) },
                                onSidebarCircles = {
                                    tab = 4
                                    phantomStudioMode = "chat"
                                    showPhantomChat = true
                                },
                            )
                            else -> ChatAuthScreen(
                                repo = chatRepo,
                                onBack = { tab = 0 },
                                onSignedIn = { /* authState updates automatically */ },
                            )
                        }
                    }

                    t == 4 -> {
                        PhantomScreen(
                            lib = lib,
                            player = player,
                            online = vm.isOnline(),
                            hasGroqKey = vm.hasGroqKey(),
                            onOpenChat = { showPhantomChat = true },
                            onOpenUniverse = { showUniverseHub = true },
                            onOpenProfile = { showMyProfile = true },
                            onPlayEmotion = vm::playEmotion,
                            onInfiniteMix = { vm.infiniteMixPlay() },
                            onPlaySongs = vm::playSongs,
                            onApplyAlchemist = vm::applyAlchemist,
                            onFocus = vm::playFocus,
                            onSoundDetective = vm::soundDetective,
                            onDnaExplain = vm::dnaExplain,
                            onUniverseExplain = vm::universeExplain,
                            onNeighbors = vm::universeNeighbors,
                            onSaveMemory = vm::saveMemory,
                            memoryFor = { songId -> vm.memoryFor(songId)?.note },
                            onSaveGroqKey = vm::saveGroqKey,
                            onAddBookmark = { vm.addBookmark(position.value) },
                            bookmarks = vm.bookmarksForCurrent(),
                        )
                    }

                    t == 5 -> AlarmScreen()

                    else -> LibraryScreen(
                        onOpenUniverse = { showUniverseHub = true },
                        onPlayDownloaded = vm::playExternalFile,
                        onOpenMenu = { showNav = true },
                        onNavigate = navigate,
                        tabRequest = libTabReq,

                        lib = lib, player = player,
                        onPlay = vm::playSongs, onShuffle = vm::shuffleAll,
                        onMore = { options = OptionsTarget(it, null) },
                        onOpenPlaylist = { openPlaylistId = it.id },
                        onNewPlaylist = { newPlaylistFor = null; newPlaylistOpen = true },
                        onRescan = vm::scanLibrary,
                        onOpenProfile = { showMyProfile = true },
                        onSettings = { showSettings = true },
                        onSort = vm::setSortMode,
                        onEqualizer = { showEqualizer = true },
                        onEditor = { showEditor = true },
                        onOpenConstellation = { showConstellation = true },
                        onSearch = { tab = 1 },
                    )
                }
                }
            }
        }
        } // end else -> Scaffold / when

        // Intro overlay — fast hyper-jump, then the galaxy lingers and dissolves slowly into the app
        AnimatedVisibility(
            visible = showIntro,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(1400)),
        ) {
            NebulaIntroScreen(onFinished = { showIntro = false })
        }

        AnimatedVisibility(
            visible = showNowPlaying && player.current != null,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            NowPlayingScreen(
                state = player,
                position = position,
                liked = player.current?.id in lib.liked,
                artOverride = player.current?.let { settings.customArt[it.id] },
                onClose = { showNowPlaying = false },
                onToggleLike = { player.current?.let { vm.toggleLike(it.id) } },
                onToggle = vm::togglePlay,
                onNext = vm::next,
                onPrevious = vm::previous,
                onSeek = vm::seekTo,
                onShuffle = vm::toggleShuffle,
                onRepeat = vm::cycleRepeat,
                onQueue = { showQueue = true },
                onSettings = { showSettings = true },
                onEqualizer = { showEqualizer = true },
                onEditor = { showEditor = true },
                onSleepTimer = { showSleep = true },
                onSpeed = { showSpeed = true },
                onLyrics = { showLyrics = true },
                onToggleVinyl = { vm.toggleVinyl() },
                playbackSpeed = settings.speed,
                vinylMode = settings.vinylMode,
                onSeekForward = vm::seekForward,
                onSeekBackward = vm::seekBackward,
                onPlaySimilar = { player.current?.let { vm.playSimilar(it) } },
                onSetImage = { imagePicker.launch(arrayOf("image/*")) },
                onResetImage = { player.current?.let { vm.clearCustomArt(it.id) } },
                hasCustomCover = player.current?.id?.let { it in settings.customArt } == true,
                particles = settings.particles,
                reactiveViz = settings.reactiveViz,
                audioSessionId = vm.audioSessionId(),
                playerBackgroundUri = settings.playerBackgroundUri,
                similarSongs = player.current?.let { vm.similarTracks(it) } ?: emptyList(),
                onPlaySimilarSong = { s ->
                    val list = player.current?.let { vm.similarTracks(it) } ?: listOf(s)
                    val idx = list.indexOfFirst { it.id == s.id }.coerceAtLeast(0)
                    vm.playSongs(if (list.isNotEmpty()) list else listOf(s), idx)
                },
                onOpenSimilarScreen = { showSimilarSongs = true },
            )
        }

        // Similar songs full screen (local + YouTube covers)
        if (showSimilarSongs) {
            val seed = player.current
            if (seed != null) {
                SimilarSongsScreen(
                    seed = seed,
                    localSimilar = vm.similarTracks(seed),
                    onPlayLocal = { s ->
                        val list = vm.similarTracks(seed)
                        val idx = list.indexOfFirst { it.id == s.id }.coerceAtLeast(0)
                        vm.playSongs(if (list.isNotEmpty()) list else listOf(s), idx)
                        showSimilarSongs = false
                    },
                    onBack = { showSimilarSongs = false },
                )
            } else {
                showSimilarSongs = false
            }
        }

        if (lovedDest != null) {
            LovedRouter(
                dest = lovedDest!!,
                lib = lib,
                seed = player.current,
                onPlay = { list, idx -> vm.playSongs(list, idx); lovedDest = null; showLovedHub = false },
                onBack = { lovedDest = null },
            )
        } else if (showLovedHub) {
            LovedHubScreen(
                onOpen = { lovedDest = it },
                onBack = { showLovedHub = false },
            )
        }

        if (showOfflineMusic) OverlayBlock(railOffset = false) { OfflineMusicScreen(onPlayDownloaded = vm::playExternalFile, onBack = { showOfflineMusic = false }) }
        if (showReels) OverlayBlock(railOffset = false) { ReelsScreen(onBack = { showReels = false }) }
        if (showStreamLibrary) OverlayBlock(railOffset = false) {
            StreamLibraryScreen(
                onStream = { url, title, artist -> vm.playExternalFile(url, title, artist) },
                onStreamQueue = { items, i -> vm.playStreamQueue(items, i) },
                onBack = { showStreamLibrary = false },
            )
        }
        if (showCommunity) OverlayBlock(railOffset = false) { SocialFeedScreen(onBack = { showCommunity = false }) }

        // Full-screen Instagram snow on top of every screen (Canvas does not steal taps)
        if (settings.particles) {
            ParticleField(
                active = true,
                modifier = Modifier.fillMaxSize(),
                count = 40,
            )
        }
    }
    }

    // ---- Sheets & dialogs -----------------------------------------------------------

    options?.let { target ->
        val song = target.song
        SongOptionsSheet(
            song = song,
            liked = song.id in lib.liked,
            inPlaylist = target.playlistId != null,
            blacklisted = song.id in lib.blacklist,
            onDismiss = { options = null },
            onPlayNext = { vm.playNext(song); options = null },
            onAddToQueue = { vm.addToQueue(song); options = null },
            onToggleLike = { vm.toggleLike(song.id); options = null },
            onAddToPlaylist = { pickerSong = song; options = null },
            onRemoveFromPlaylist = {
                target.playlistId?.let { vm.removeFromPlaylist(it, song.id) }
                options = null
            },
            onPlaySimilar = { vm.playSimilar(song); options = null },
            onQueueAlbum = { vm.queueRestOfAlbum(song); options = null },
            onShare = { /* share via system in future */ options = null },
            onToggleBlacklist = { vm.toggleBlacklist(song.id); options = null },
        )
    }

    pickerSong?.let { song ->
        PlaylistPickerSheet(
            playlists = lib.playlists,
            onDismiss = { pickerSong = null },
            onPick = { vm.addToPlaylist(it.id, song.id); pickerSong = null },
            onCreate = { newPlaylistFor = song.id; newPlaylistOpen = true; pickerSong = null },
        )
    }

    if (newPlaylistOpen) {
        NamePlaylistDialog(
            onConfirm = { name ->
                vm.createPlaylist(name, newPlaylistFor)
                newPlaylistOpen = false
                newPlaylistFor = null
            },
            onDismiss = { newPlaylistOpen = false; newPlaylistFor = null },
        )
    }

    deletePlaylistTarget?.let { p ->
        ConfirmDialog(
            title = "Delete playlist?",
            message = "\"${p.name}\" will be removed. Your songs are not deleted.",
            confirmLabel = "Delete",
            onConfirm = { vm.deletePlaylist(p.id); deletePlaylistTarget = null; openPlaylistId = null },
            onDismiss = { deletePlaylistTarget = null },
        )
    }

    if (showQueue) {
        QueueSheet(
            state = player,
            onDismiss = { showQueue = false },
            onJump = vm::skipTo,
            onRemove = vm::removeFromQueue,
            onClear = vm::clearQueue,
        )
    }

    if (showSettings) OverlayBlock(railOffset = false) {
        SettingsScreen(
            settings = settings,
            actions = SettingsActions(
                onBack = { showSettings = false },
                onSelectTheme = { vm.setTheme(it) },
                onSelectNotif = { vm.setNotifStyle(it) },
                onOpenAlarms = { showSettings = false; tab = 5 },
                onOpenEqualizer = { showSettings = false; showEqualizer = true },
                onPickCustomArt = { imagePicker.launch(arrayOf("image/*")) },
                onPickNotifImage = { notifImagePicker.launch(arrayOf("image/*")) },
                onPickNotifVideo = { notifVideoPicker.launch(arrayOf("video/*")) },
                onClearNotifVideo = { vm.setNotifVideo(null) },
                onSoif = { vm.setNotifSoif(it) },
                onSoifStyled = { vm.setNotifSoifStyled(it) },
                onWakeEnabled = { on ->
                    vm.setWakeEnabled(on)
                    if (on) {
                        val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                            context, android.Manifest.permission.RECORD_AUDIO,
                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        if (!hasMic) {
                            android.widget.Toast.makeText(context, "Allow microphone for wake word", android.widget.Toast.LENGTH_LONG).show()
                            askMic()
                        }
                        // Unrestricted battery so wake survives Doze / screen-off
                        try {
                            val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
                            val pkg = context.packageName
                            if (!pm.isIgnoringBatteryOptimizations(pkg)) {
                                android.widget.Toast.makeText(
                                    context,
                                    "Allow unrestricted battery so Phantom can hear you with the screen off",
                                    android.widget.Toast.LENGTH_LONG,
                                ).show()
                                context.startActivity(
                                    android.content.Intent(
                                        android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                        android.net.Uri.parse("package:$pkg"),
                                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                                )
                            }
                        } catch (_: Exception) {
                            try {
                                context.startActivity(
                                    android.content.Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                                )
                            } catch (_: Exception) {}
                        }
                        // Orb over lock screen / other apps
                        if (!com.texgen.music.texwave.player.PhantomOrbService.canOverlay(context)) {
                            android.widget.Toast.makeText(
                                context,
                                "Allow “Display over other apps” so the Phantom orb can appear",
                                android.widget.Toast.LENGTH_LONG,
                            ).show()
                            try {
                                context.startActivity(
                                    android.content.Intent(
                                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        android.net.Uri.parse("package:" + context.packageName),
                                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                                )
                            } catch (_: Exception) {}
                        }
                        com.texgen.music.texwave.player.WakeWordService.start(
                            context,
                            vm.settings.value.wakeWord.ifBlank { "phantom" },
                            vm.settings.value.wakeSilenceMs,
                        )
                        android.widget.Toast.makeText(
                            context,
                            "Wake on · say “phantom” — even with the screen off",
                            android.widget.Toast.LENGTH_LONG,
                        ).show()
                    } else {
                        com.texgen.music.texwave.player.WakeWordService.stop(context)
                        com.texgen.music.texwave.player.PhantomOrbService.hide(context)
                    }
                },
                onWakeWord = { w ->
                    vm.setWakeWord(w)
                    if (vm.settings.value.wakeEnabled) {
                        com.texgen.music.texwave.player.WakeWordService.stop(context)
                        com.texgen.music.texwave.player.WakeWordService.start(
                            context, w, vm.settings.value.wakeSilenceMs
                        )
                    }
                },
                onParticles = { vm.setParticles(it) },
                onSnowOverlay = { on ->
                    if (on) {
                        if (com.texgen.music.texwave.player.SnowOverlayService.canOverlay(context)) {
                            vm.setSnowOverlay(true)
                            com.texgen.music.texwave.player.SnowOverlayService.start(context)
                        } else {
                            vm.setSnowOverlay(true) // remember preference; start after permission
                            val intent = android.content.Intent(
                                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                android.net.Uri.parse("package:" + context.packageName),
                            )
                            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(intent)
                        }
                    } else {
                        vm.setSnowOverlay(false)
                        com.texgen.music.texwave.player.SnowOverlayService.stop(context)
                    }
                },
                onReactiveViz = {
                    vm.setReactiveViz(it)
                    if (it) askMic()
                },
                onSkipSilence = { vm.setSkipSilence(it) },
            ),
        )
    }

    if (showEqualizer) OverlayBlock(railOffset = false) {
        EqualizerScreen(
            eq = vm.equalizer,
            onBack = { showEqualizer = false },
        )
    }

    if (showEditor) OverlayBlock(railOffset = false) {
        MusicEditorScreen(
            songs = lib.songs,
            onBack = { showEditor = false },
            onExported = { vm.scanLibrary() },
        )
    }

    if (showSleep) {
        SleepTimerSheet(
            currentMinutes = settings.sleepTimerMinutes,
            onDismiss = { showSleep = false },
            onSet = { vm.setSleepTimer(it) },
        )
    }

    if (showSpeed) {
        SpeedSheet(
            current = settings.speed,
            onDismiss = { showSpeed = false },
            onSet = { vm.setSpeed(it) },
        )
    }

    if (showLyrics) {
        LyricsSheet(
            song = player.current,
            positionMs = position.value,
            groqKeyAvailable = vm.hasGroqKey(),
            onDismiss = { showLyrics = false },
        )
    }

    // PHANTOM AI chat session (existing)

    BackHandler(enabled = showNav && navAvailable) { showNav = false }
    val navSelected = when {
        showCommunity -> NavTarget.Community
        showReels -> NavTarget.Reels
        showStreamLibrary -> NavTarget.Explore
        showOfflineMusic -> NavTarget.Downloads
        showMemes -> NavTarget.Explore
        openPlaylistId != null -> NavTarget.Library
        tab == 0 -> NavTarget.Home
        tab == 1 -> NavTarget.Search
        tab == 2 -> NavTarget.Library
        tab == 3 -> NavTarget.Chats
        tab == 4 -> NavTarget.Phantom
        tab == 5 -> NavTarget.Alarms
        else -> null
    }
    // Side rail + edge handle removed — navigate via bottom bar, Explore tiles, Library menu
    SideNavDrawer(
        visible = showNav && navAvailable,
        soundsOn = soundsOn,
        selected = navSelected,
        onDismiss = { showNav = false },
        onSelect = navigate,
    )
    if (showPhantomChat) OverlayBlock(railOffset = false) {
        val online = vm.isOnline()
        LaunchedEffect(online) {
            if (online) askMic()
        }
        PhantomChatScreen(
            initialMode = phantomStudioMode,

            online = online,
            hasKey = vm.hasGroqKey(),
            onBack = { showPhantomChat = false },
            onSaveKey = { vm.saveGroqKey(it) },
            onSend = { text, history ->
                vm.phantomChat(
                    text,
                    history.map { it.role to it.text },
                )
            },
            onSendImage = { text, bytes, mime ->
                vm.phantomChatImage(text, bytes, mime)
            },
        )
    }


    // UNIVERSE LAB — billion-dollar exclusive screens
    if (showUniverseHub || universeDest != null) OverlayBlock(railOffset = false) {
        val dest = universeDest
        if (dest != null && dest != UniverseDest.Hub) {
            UniverseRouter(
                dest = dest,
                lib = lib,
                player = player,
                onPlay = { list, i -> vm.playSongs(list, i) },
                onBack = { universeDest = null },
            )
        } else {
            UniverseHubScreen(
                onOpen = { universeDest = it },
                onBack = { showUniverseHub = false; universeDest = null },
            )
        }
    }

    // User-to-user CHAT session — full-screen overlay, same pattern as Phantom Chat
    val activeChatId = chatConversationId
    if (activeChatId != null) OverlayBlock(railOffset = false) {
        ConversationScreen(
            repo = chatRepo,
            conversationId = activeChatId,
            title = chatConversationTitle,
            onBack = { chatConversationId = null },
            forceJoinRoom = pendingCallRoom,
            forceJoinPeer = chatConversationTitle,
            onForceJoinConsumed = { pendingCallRoom = null },
            librarySongs = lib.songs,
            onPlaySong = { song ->
                runCatching {
                    val all = lib.songs
                    val i = all.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
                    if (all.isNotEmpty()) vm.playSongs(all, i)
                }
            },
            onPlayResonance = { title, artist, storagePath ->
                vm.playResonanceOrDownload(title, artist, storagePath, chatRepo)
            },
        )
    }
}


/** Full-screen overlay that swallows taps so nothing underneath can be pressed by accident. */
@Composable
private fun OverlayBlock(railOffset: Boolean = true, content: @Composable () -> Unit) {
    // Overlay destinations use the same content grid as the main scaffold. The rail
    // remains a separate, clickable navigation surface instead of covering page content.
    Box(
        Modifier
            .fillMaxSize()
            .then(if (railOffset) Modifier.padding(start = RailWidth) else Modifier)
            .pointerInput(Unit) { detectTapGestures { } },
    ) { content() }
}
