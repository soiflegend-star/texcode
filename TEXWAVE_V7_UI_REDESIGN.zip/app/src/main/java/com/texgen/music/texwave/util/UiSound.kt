package com.texgen.music.texwave.util

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.texgen.music.texwave.R

/**
 * Short interface sounds (taps, tab switches, play/pause, whoosh, sparkle).
 * Uses SoundPool with the "sonification" usage, so it never pauses or ducks the music being played.
 */
object UiSound {
    enum class Kind(val res: Int) {
        TAP(R.raw.ui_tap),
        TAB(R.raw.ui_tab),
        PLAY(R.raw.ui_play),
        PAUSE(R.raw.ui_pause),
        SELECT(R.raw.ui_select),
        OPEN(R.raw.ui_open),
        LIKE(R.raw.ui_like),
    }

    private const val PREFS = "texwave_ui"
    private const val KEY = "ui_sounds"

    private var pool: SoundPool? = null
    private val ids = HashMap<Kind, Int>()
    private val ready = HashSet<Int>()

    @Volatile
    private var enabled = true

    private fun ensure(context: Context) {
        if (pool != null) return
        val app = context.applicationContext
        enabled = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, true)
        val sp = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        sp.setOnLoadCompleteListener { _, id, status -> if (status == 0) synchronized(ready) { ready.add(id) } }
        Kind.values().forEach { ids[it] = sp.load(app, it.res, 1) }
        pool = sp
    }

    fun isEnabled(context: Context): Boolean {
        ensure(context)
        return enabled
    }

    fun setEnabled(context: Context, on: Boolean) {
        ensure(context)
        enabled = on
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply()
    }

    fun play(context: Context, kind: Kind) {
        try {
            ensure(context)
            if (!enabled) return
            val id = ids[kind] ?: return
            val ok = synchronized(ready) { id in ready }
            if (ok) pool?.play(id, 0.55f, 0.55f, 1, 0, 1f)
        } catch (_: Throwable) {
            // sound is decoration only — never let it crash the UI
        }
    }
}
