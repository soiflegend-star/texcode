package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.seedColors
import com.texgen.music.texwave.util.formatDuration
import java.io.File

/** Per-song cover images the user picked (song id -> file uri). Provided once at the app root. */
val LocalCustomArt = androidx.compose.runtime.compositionLocalOf<Map<Long, String>> { emptyMap() }

/** Album art with a generated gradient fallback. Optional [artOverride] wins over MediaStore art. */
@Composable
fun Artwork(
    song: Song?,
    modifier: Modifier = Modifier,
    corner: Dp = 12.dp,
    iconSize: Dp = 24.dp,
    artOverride: String? = null,
) {
    val colors = remember(song?.album) { seedColors(song?.album ?: "texwave") }
    val custom = LocalCustomArt.current
    val raw = artOverride ?: song?.let { custom[it.id] } ?: song?.artUri
    val model: Any? = when {
        raw == null -> null
        raw.startsWith("/") -> File(raw)
        raw.startsWith("file:") -> File(android.net.Uri.parse(raw).path ?: raw)
        else -> raw
    }
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(colors.first, colors.second))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(iconSize))
        if (model != null) {
            AsyncImage(
                model = model,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/** A gradient tile (mixes, playlists, artists). */
@Composable
fun GradientTile(
    seed: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    corner: Dp = 16.dp,
    iconSize: Dp = 28.dp,
) {
    val colors = remember(seed) { seedColors(seed) }
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(colors.first, colors.second))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(iconSize))
    }
}

/** Three animated bars shown next to the currently playing track. */


@Composable
fun SongRow(
    song: Song,
    isCurrent: Boolean,
    isPlaying: Boolean,
    liked: Boolean,
    onClick: () -> Unit,
    onMore: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Artwork(song, Modifier.size(52.dp), corner = 10.dp)
            if (isCurrent) {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center,
                ) { EqualizerBars(active = isPlaying) }
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                color = if (isCurrent) Tx.Accent2 else Tx.Text,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (liked) {
                    Icon(Icons.Rounded.Favorite, null, tint = Tx.Accent, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    "${song.artist} · ${song.album}",
                    color = Tx.Muted,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Text(formatDuration(song.durationMs), color = Tx.Muted, style = MaterialTheme.typography.labelSmall)
        IconButton(onClick = onMore) {
            Icon(Icons.Rounded.MoreVert, contentDescription = "More options", tint = Tx.Muted)
        }
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, subtitle: String? = null) {
    Column(modifier.appear().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Text(
            title,
            color = Tx.Text,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = (-0.2).sp,
        )
        if (subtitle != null) {
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Tx.Muted, fontSize = 12.sp)
        }
    }
}

/** Pill button filled with the brand gradient. */
@Composable
fun GradientButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .clip(CircleShape)
            .background(Tx.Brand)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
    }
}

/** Outlined pill button. */
@Composable
fun GhostButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Tx.SurfaceHigh.copy(alpha = 0.9f))
            .border(
                1.dp,
                Brush.linearGradient(listOf(Tx.Accent.copy(alpha = 0.45f), Tx.Accent2.copy(alpha = 0.35f), Tx.Accent3.copy(alpha = 0.3f))),
                RoundedCornerShape(999.dp),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = Tx.Accent2, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Tx.Text, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
) {
    Column(
        modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        GradientTile("empty-$title", icon, Modifier.size(84.dp), corner = 28.dp, iconSize = 38.dp)
        Spacer(Modifier.height(20.dp))
        Text(title, color = Tx.Text, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(6.dp))
        Text(message, color = Tx.Muted, style = MaterialTheme.typography.bodyMedium, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(22.dp))
            action()
        }
    }
}


@Composable
fun SoifSignature(modifier: Modifier = Modifier) {
    Text(
        "SOIF",
        modifier = modifier,
        color = Tx.Accent2.copy(alpha = 0.35f),
        fontSize = 11.sp,
        fontWeight = FontWeight.Light,
        letterSpacing = 6.sp,
    )
}
