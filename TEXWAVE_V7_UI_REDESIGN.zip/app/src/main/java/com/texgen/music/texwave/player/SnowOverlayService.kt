package com.texgen.music.texwave.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.texgen.music.texwave.MainActivity
import com.texgen.music.texwave.R
import kotlin.math.sin
import kotlin.random.Random

/**
 * Draws Instagram-style small snow over the entire screen, including other apps.
 * Requires SYSTEM_ALERT_WINDOW (display over other apps) permission.
 * Touch is not blocked — overlay is not focusable / not touchable.
 */
class SnowOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var snowView: SnowView? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOverlay()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startForeground(NOTIF_ID, buildNotif())
            attachOverlay()
        } catch (e: Exception) {
            // OEM / Android 14 FGS restrictions — never crash the app
            try { stopOverlay() } catch (_: Exception) {}
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun attachOverlay() {
        if (snowView != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        params.gravity = Gravity.TOP or Gravity.START
        val view = SnowView(this)
        snowView = view
        try {
            wm.addView(view, params)
        } catch (_: Exception) {
            snowView = null
            stopSelf()
        }
    }

    private fun stopOverlay() {
        try {
            snowView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
        }
        snowView = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        stopOverlay()
        super.onDestroy()
    }

    private fun buildNotif(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, SnowOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Snow overlay", NotificationManager.IMPORTANCE_LOW).apply {
                        setShowBadge(false)
                        setSound(null, null)
                    }
                )
            }
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle("Snow falling")
            .setContentText("Small snow over all apps · tap Stop to end")
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .addAction(0, "Stop", stop)
            .build()
    }

    /** Lightweight View that paints tiny snowflakes every frame. */
    private class SnowView(context: Context) : View(context) {
        private data class Flake(
            var x: Float,
            var y: Float,
            var speed: Float,
            var size: Float,
            var phase: Float,
            var sway: Float,
        )

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val flakes = ArrayList<Flake>(100)
        private var last = System.nanoTime()
        private val tick = object : Runnable {
            override fun run() {
                invalidate()
                postOnAnimation(this)
            }
        }

        init {
            val rnd = Random(System.currentTimeMillis())
            repeat(88) {
                flakes.add(
                    Flake(
                        x = rnd.nextFloat(),
                        y = rnd.nextFloat(),
                        speed = 0.012f + rnd.nextFloat() * 0.03f,
                        size = 0.6f + rnd.nextFloat() * 1.5f,
                        phase = rnd.nextFloat() * 6.28f,
                        sway = 0.015f + rnd.nextFloat() * 0.025f,
                    )
                )
            }
            postOnAnimation(tick)
        }

        override fun onDraw(canvas: Canvas) {
            val now = System.nanoTime()
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
            last = now
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val dens = resources.displayMetrics.density
            for (f in flakes) {
                f.y += f.speed * dt
                if (f.y > 1.05f) {
                    f.y = -0.02f
                    f.x = Random.nextFloat()
                }
                val sx = ((f.x + f.sway * sin((f.y * 8f + f.phase).toDouble()).toFloat()) % 1f + 1f) % 1f
                val cx = sx * w
                val cy = f.y * h
                // One solid small dot only (no outer faded ring)
                val r = (f.size * 0.85f + 0.4f) * dens
                paint.alpha = 200
                canvas.drawCircle(cx, cy, r, paint)
            }
        }

        override fun onDetachedFromWindow() {
            removeCallbacks(tick)
            super.onDetachedFromWindow()
        }
    }

    companion object {
        const val ACTION_STOP = "com.texgen.music.texwave.SNOW_STOP"
        private const val CHANNEL = "texwave_snow"
        private const val NOTIF_ID = 4251

        fun canOverlay(context: Context): Boolean =
            Settings.canDrawOverlays(context)

        fun start(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            try {
                val i = Intent(context, SnowOverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i)
                else context.startService(i)
            } catch (_: Exception) {
            }
        }

        fun stop(context: Context) {
            context.startService(Intent(context, SnowOverlayService::class.java).setAction(ACTION_STOP))
        }
    }
}
