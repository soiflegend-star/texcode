package com.texgen.music.texwave.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.catalog.OpenCatalogEngine
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private fun dlPrefs(ctx: android.content.Context) =
    ctx.getSharedPreferences("texwave_offline_engine_v1", android.content.Context.MODE_PRIVATE)

private fun isDownloaded(ctx: android.content.Context, id: String): Boolean {
    val raw = dlPrefs(ctx).getString("tracks", "[]") ?: "[]"
    return try {
        val a = JSONArray(raw)
        (0 until a.length()).any { a.getJSONObject(it).optString("id") == id }
    } catch (_: Exception) {
        false
    }
}

private fun markDownloaded(ctx: android.content.Context, item: OpenCatalogEngine.AudioItem, path: String, downloadId: Long) {
    val raw = dlPrefs(ctx).getString("tracks", "[]") ?: "[]"
    val a = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
    // remove old
    val next = JSONArray()
    for (i in 0 until a.length()) {
        val o = a.getJSONObject(i)
        if (o.optString("id") != item.id) next.put(o)
    }
    next.put(
        JSONObject()
            .put("id", item.id)
            .put("title", item.title)
            .put("artist", item.artist)
            .put("fileName", item.fileName)
            .put("url", item.url)
            .put("license", item.license)
            .put("downloadId", downloadId)
            .put("localPath", path),
    )
    dlPrefs(ctx).edit().putString("tracks", next.toString()).apply()
}

@Composable
fun StreamLibraryScreen(
    onStream: (url: String, title: String, artist: String) -> Unit,
    onStreamQueue: (items: List<Triple<String, String, String>>, startIndex: Int) -> Unit = { list, i ->
        list.getOrNull(i)?.let { onStream(it.first, it.second, it.third) }
    },
    onBack: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var shelves by remember { mutableStateOf<List<Pair<OpenCatalogEngine.Shelf, List<OpenCatalogEngine.AudioItem>>>>(emptyList()) }
    var searchHits by remember { mutableStateOf<List<OpenCatalogEngine.AudioItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var searching by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var activeShelf by remember { mutableStateOf<Pair<OpenCatalogEngine.Shelf, List<OpenCatalogEngine.AudioItem>>?>(null) }
    var nowPlayingId by remember { mutableStateOf<String?>(null) }
    var downloadingId by remember { mutableStateOf<String?>(null) }
    var downloadedIds by remember { mutableStateOf(setOf<String>()) }

    LaunchedEffect(Unit) {
        // seed downloaded set
        val raw = dlPrefs(context).getString("tracks", "[]") ?: "[]"
        downloadedIds = try {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull { a.getJSONObject(it).optString("id").takeIf { id -> id.isNotBlank() } }.toSet()
        } catch (_: Exception) {
            emptySet()
        }
    }

    fun playItem(item: OpenCatalogEngine.AudioItem, queue: List<OpenCatalogEngine.AudioItem> = listOf(item)) {
        val idx = queue.indexOfFirst { it.id == item.id }.coerceAtLeast(0)
        val triples = queue.map { Triple(it.url, it.title, it.artist) }
        nowPlayingId = item.id
        onStreamQueue(triples, idx)
        Toast.makeText(context, "Playing · ${item.title}", Toast.LENGTH_SHORT).show()
    }

    fun downloadItem(item: OpenCatalogEngine.AudioItem) {
        if (downloadingId != null) return
        downloadingId = item.id
        scope.launch {
            val res = OpenCatalogEngine.downloadAudio(context, item)
            downloadingId = null
            if (res.ok && res.path != null) {
                markDownloaded(context, item, res.path, res.downloadId)
                downloadedIds = downloadedIds + item.id
                Toast.makeText(context, "Saved offline · ${item.title}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, res.error ?: "Download failed", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        loading = true
        error = null
        try {
            shelves = OpenCatalogEngine.loadHomeShelves(perShelf = 10)
            if (shelves.isEmpty()) error = "Could not load shelves — check network"
        } catch (e: Exception) {
            error = e.message ?: "Load failed"
        } finally {
            loading = false
        }
    }

    val headerEnter = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        headerEnter.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .statusBarsPadding(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .graphicsLayer {
                    alpha = headerEnter.value
                    translationY = (1f - headerEnter.value) * -20f
                },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, null, tint = Color.White)
                }
            }
            Icon(Icons.Rounded.LibraryMusic, null, tint = Tx.Accent2, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Online Library", color = Tx.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Play first · download if you like it", color = Tx.Muted, fontSize = 12.sp)
            }
        }

        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf("Home", "Search").forEachIndexed { i, label ->
                val on = tab == i
                val scale by animateFloatAsState(if (on) 1.05f else 1f, label = "tab$i")
                Text(
                    label,
                    color = if (on) Color.Black else Tx.Text,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .scale(scale)
                        .clip(RoundedCornerShape(999.dp))
                        .background(if (on) Tx.Accent2 else Tx.SurfaceHigh)
                        .clickable {
                            tab = i
                            activeShelf = null
                        }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        AnimatedVisibility(visible = loading, enter = fadeIn(), exit = fadeOut()) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(16.dp), color = Tx.Accent2)
        }
        error?.let {
            Text(it, color = Tx.Danger, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
        }

        when {
            activeShelf != null -> {
                val (shelf, items) = activeShelf!!
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { activeShelf = null }) {
                                Icon(Icons.Rounded.ArrowBack, null, tint = Color.White)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(shelf.title, color = Tx.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("Tap play · then save offline", color = Tx.Muted, fontSize = 12.sp)
                            }
                            IconButton(onClick = { if (items.isNotEmpty()) playItem(items.random(), items) }) {
                                Icon(Icons.Rounded.Shuffle, null, tint = Tx.Accent2)
                            }
                        }
                    }
                    itemsIndexed(items, key = { _, it -> it.id }) { i, item ->
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(tween(280, delayMillis = (i * 30).coerceAtMost(300))) +
                                slideInVertically(tween(280)) { it / 4 },
                        ) {
                            StreamTrackRow(
                                index = i + 1,
                                item = item,
                                playing = nowPlayingId == item.id,
                                downloading = downloadingId == item.id,
                                downloaded = item.id in downloadedIds,
                                onPlay = { playItem(item, items) },
                                onDownload = { downloadItem(item) },
                            )
                        }
                    }
                    item { Spacer(Modifier.height(100.dp)) }
                }
            }

            tab == 1 -> {
                Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            placeholder = { Text("Search to preview…") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Tx.Accent2,
                                unfocusedBorderColor = Tx.Outline,
                                focusedTextColor = Tx.Text,
                                unfocusedTextColor = Tx.Text,
                                cursorColor = Tx.Accent2,
                            ),
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                searching = true
                                scope.launch {
                                    try {
                                        searchHits = OpenCatalogEngine.searchAudio(query, limit = 24)
                                    } finally {
                                        searching = false
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Tx.Accent),
                        ) {
                            Icon(Icons.Rounded.Search, null, modifier = Modifier.size(18.dp))
                        }
                    }
                    AnimatedVisibility(visible = searching) {
                        LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp), color = Tx.Accent2)
                    }
                    LazyColumn(
                        Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        itemsIndexed(searchHits, key = { _, it -> it.id }) { i, item ->
                            StreamTrackRow(
                                index = i + 1,
                                item = item,
                                playing = nowPlayingId == item.id,
                                downloading = downloadingId == item.id,
                                downloaded = item.id in downloadedIds,
                                onPlay = { playItem(item, searchHits) },
                                onDownload = { downloadItem(item) },
                            )
                        }
                        item { Spacer(Modifier.height(100.dp)) }
                    }
                }
            }

            else -> {
                LazyColumn(contentPadding = PaddingValues(bottom = 100.dp)) {
                    item {
                        Text(
                            "Preview any track · download only what you keep",
                            color = Tx.Muted,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        )
                    }
                    items(shelves, key = { it.first.id }) { (shelf, items) ->
                        Column(Modifier.padding(bottom = 18.dp)) {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(shelf.title, color = Tx.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text(
                                    "See all",
                                    color = Tx.Accent2,
                                    fontSize = 12.sp,
                                    modifier = Modifier.clickable { activeShelf = shelf to items },
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                items(items, key = { it.id }) { item ->
                                    StreamCard(
                                        item = item,
                                        playing = nowPlayingId == item.id,
                                        downloaded = item.id in downloadedIds,
                                        downloading = downloadingId == item.id,
                                        onPlay = { playItem(item, items) },
                                        onDownload = { downloadItem(item) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamCard(
    item: OpenCatalogEngine.AudioItem,
    playing: Boolean,
    downloaded: Boolean,
    downloading: Boolean,
    onPlay: () -> Unit,
    onDownload: () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.94f else 1f,
        spring(stiffness = Spring.StiffnessMedium),
        label = "cardScale",
    )
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        0.35f, 0.75f,
        infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "glow",
    )
    Column(
        Modifier
            .width(148.dp)
            .scale(scale)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF121018))
            .border(
                1.dp,
                if (playing) Brush.linearGradient(listOf(Tx.Accent2, Tx.Accent, Tx.Accent3))
                else Brush.linearGradient(listOf(Color(0x22FFFFFF), Color(0x11FFFFFF))),
                RoundedCornerShape(14.dp),
            )
            .clickable(interactionSource = interaction, indication = null, onClick = onPlay)
            .padding(10.dp),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(120.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            Tx.Accent.copy(if (playing) glow else 0.45f),
                            Tx.Accent2.copy(0.35f),
                            Color(0xFF1A1028),
                        ),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(40.dp))
            if (downloaded) {
                Icon(
                    Icons.Rounded.DownloadDone,
                    null,
                    tint = Color(0xFF4ADE80),
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(item.title, color = Tx.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.height(36.dp))
        Text(item.artist, color = Tx.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (playing) "Playing" else "Play",
                color = if (playing) Tx.Accent2 else Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x33FFFFFF))
                    .clickable(onClick = onPlay)
                    .padding(horizontal = 10.dp, vertical = 5.dp),
            )
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x337B5CFF))
                    .clickable(enabled = !downloading && !downloaded, onClick = onDownload)
                    .padding(horizontal = 8.dp, vertical = 5.dp),
            ) {
                when {
                    downloading -> CircularProgressIndicator(Modifier.size(12.dp), strokeWidth = 1.5.dp, color = Tx.Accent2)
                    downloaded -> Icon(Icons.Rounded.DownloadDone, null, tint = Color(0xFF4ADE80), modifier = Modifier.size(14.dp))
                    else -> Icon(Icons.Rounded.CloudDownload, null, tint = Tx.Accent2, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
private fun StreamTrackRow(
    index: Int,
    item: OpenCatalogEngine.AudioItem,
    playing: Boolean,
    downloading: Boolean,
    downloaded: Boolean,
    onPlay: () -> Unit,
    onDownload: () -> Unit,
) {
    val scale by animateFloatAsState(if (playing) 1.02f else 1f, label = "row")
    Row(
        Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(12.dp))
            .background(if (playing) Color(0x332FE6FF) else Color(0xE6120F1C))
            .border(
                1.dp,
                if (playing) Tx.Accent2.copy(0.5f) else Color(0x14FFFFFF),
                RoundedCornerShape(12.dp),
            )
            .clickable(onClick = onPlay)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("$index", color = Tx.Muted, fontSize = 13.sp, modifier = Modifier.width(28.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Tx.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (playing) "Now playing · ${item.artist}" else item.artist,
                color = if (playing) Tx.Accent2 else Tx.Muted,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        IconButton(onClick = onPlay) {
            Icon(Icons.Rounded.PlayArrow, "Play", tint = if (playing) Tx.Accent2 else Color.White)
        }
        IconButton(onClick = onDownload, enabled = !downloading) {
            when {
                downloading -> CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Tx.Accent2)
                downloaded -> Icon(Icons.Rounded.DownloadDone, "Saved", tint = Color(0xFF4ADE80))
                else -> Icon(Icons.Rounded.CloudDownload, "Download", tint = Tx.Accent)
            }
        }
    }
}
