package com.texgen.music.texwave.util

import java.util.Locale

/** Formats milliseconds as m:ss or h:mm:ss. */
fun formatDuration(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.ROOT, "%d:%02d", m, s)
}

/** "1 song" / "3 songs". */
fun songCount(n: Int): String = if (n == 1) "1 song" else "$n songs"
