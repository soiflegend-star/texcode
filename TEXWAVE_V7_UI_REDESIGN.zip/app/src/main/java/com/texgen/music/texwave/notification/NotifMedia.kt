package com.texgen.music.texwave.notification

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import java.io.File
import java.io.FileOutputStream

/** Image helpers shared by the notification renderer, the in-app preview and the cover-art picker. */
object NotifMedia {
    const val SIZE = 384

    fun centerCropSquare(src: Bitmap, target: Int): Bitmap {
        val side = minOf(src.width, src.height)
        val x = (src.width - side) / 2
        val y = (src.height - side) / 2
        val square = if (side == src.width && side == src.height) src else Bitmap.createBitmap(src, x, y, side, side)
        return if (side != target) Bitmap.createScaledBitmap(square, target, target, true) else square
    }

    /** Decodes [uri] (content:// or file://) to a square bitmap of about [target] px, honouring EXIF rotation. */
        fun decodeSquare(context: Context, uri: Uri, target: Int = SIZE): Bitmap? {
        return try {
            val streamProvider: () -> java.io.InputStream? = {
                when {
                    uri.scheme == "file" || uri.scheme == null -> {
                        val path = uri.path ?: uri.toString()
                        val f = File(path)
                        if (f.exists()) java.io.FileInputStream(f) else null
                    }
                    else -> try {
                        context.contentResolver.openInputStream(uri)
                    } catch (_: Exception) {
                        // last resort: treat as path
                        val f = File(uri.toString())
                        if (f.exists()) java.io.FileInputStream(f) else null
                    }
                }
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            streamProvider()?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            val minSide = minOf(bounds.outWidth, bounds.outHeight)
            while (minSide / (sample * 2) >= target) sample *= 2
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            var bmp = streamProvider()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val degrees = try {
                streamProvider()?.use { stream ->
                    when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (_: Exception) {
                0f
            }
            if (degrees != 0f) {
                val m = Matrix().apply { postRotate(degrees) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            centerCropSquare(bmp, target)
        } catch (_: Exception) {
            null
        }
    }

    /** Embedded or MediaStore cover art for a song, or null when there is none. */
    fun loadSongArt(context: Context, contentUri: String, albumId: Long, target: Int = SIZE): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val thumb = context.contentResolver.loadThumbnail(Uri.parse(contentUri), Size(target, target), null)
                return centerCropSquare(thumb, target)
            } catch (_: Exception) {
                // fall through to the legacy album-art URI
            }
        }
        if (albumId > 0) {
            decodeSquare(context, Uri.parse("content://media/external/audio/albumart/$albumId"), target)?.let { return it }
        }
        return null
    }

    /**
     * Copies a picked image into app storage (so it keeps working after the picker permission expires)
     * and returns a file path string, or null on failure.
     * When [keepAspect] is true (player backgrounds), preserves aspect ratio at high quality.
     */
    fun importImage(context: Context, source: Uri, name: String, maxSide: Int = 1024, keepAspect: Boolean = false): String? {
        return try {
            val bmp = if (keepAspect) {
                decodeFit(context, source, maxSide) ?: return null
            } else {
                decodeSquare(context, source, maxSide) ?: return null
            }
            val dir = File(context.filesDir, "art").apply { mkdirs() }
            val file = File(dir, "$name-${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 94, it) }
            // Keep only the newest file per name.
            dir.listFiles()?.filter { it.name.startsWith("$name-") && it != file }?.forEach { it.delete() }
            // Absolute path — survives forever inside app storage (no URI permission needed).
            file.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    /** Decode image keeping aspect ratio, longest side ≈ [maxSide]. */
    fun decodeFit(context: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val streamProvider: () -> java.io.InputStream? = {
                when {
                    uri.scheme == "file" || uri.scheme == null -> {
                        val path = uri.path ?: uri.toString()
                        val f = File(path)
                        if (f.exists()) java.io.FileInputStream(f) else null
                    }
                    else -> try {
                        context.contentResolver.openInputStream(uri)
                    } catch (_: Exception) {
                        val f = File(uri.toString())
                        if (f.exists()) java.io.FileInputStream(f) else null
                    }
                }
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            streamProvider()?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            val longest = maxOf(bounds.outWidth, bounds.outHeight)
            while (longest / (sample * 2) >= maxSide) sample *= 2
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            var bmp = streamProvider()?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val degrees = try {
                streamProvider()?.use { stream ->
                    when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (_: Exception) {
                0f
            }
            if (degrees != 0f) {
                val m = Matrix().apply { postRotate(degrees) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val maxDim = maxOf(bmp.width, bmp.height)
            if (maxDim > maxSide) {
                val scale = maxSide.toFloat() / maxDim
                val nw = (bmp.width * scale).toInt().coerceAtLeast(1)
                val nh = (bmp.height * scale).toInt().coerceAtLeast(1)
                bmp = Bitmap.createScaledBitmap(bmp, nw, nh, true)
            }
            bmp
        } catch (_: Exception) {
            null
        }
    }
}

/** Frames cut from a user-chosen video; the notification cycles through them as its animation. */
object NotifVideoFrames {
    private const val DIR = "notif_video"
    private const val FRAME_SIZE = 320

    private fun dir(context: Context) = File(context.filesDir, DIR)

    fun load(context: Context, index: Int, count: Int): Bitmap? {
        if (count <= 0) return null
        val file = File(dir(context), "f_%02d.jpg".format(((index % count) + count) % count))
        return if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
    }

    fun clear(context: Context) {
        dir(context).listFiles()?.forEach { it.delete() }
    }

    /**
     * Extracts up to [frames] evenly-spaced frames from the first [maxSpanMs] of the video.
     * Blocking; call from a background thread. Returns the number of frames written.
     */
    fun extract(context: Context, uri: Uri, frames: Int = 20, maxSpanMs: Long = 12_000L): Int {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val span = if (duration > 0) minOf(duration, maxSpanMs) else 1_000L
            val out = dir(context).apply { mkdirs() }
            out.listFiles()?.forEach { it.delete() }
            var written = 0
            for (i in 0 until frames) {
                val timeUs = span * 1000L * i / frames
                val raw = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST) ?: continue
                val square = NotifMedia.centerCropSquare(raw, FRAME_SIZE)
                FileOutputStream(File(out, "f_%02d.jpg".format(written))).use {
                    square.compress(Bitmap.CompressFormat.JPEG, 82, it)
                }
                written++
            }
            return written
        } catch (_: Exception) {
            return 0
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }
}
