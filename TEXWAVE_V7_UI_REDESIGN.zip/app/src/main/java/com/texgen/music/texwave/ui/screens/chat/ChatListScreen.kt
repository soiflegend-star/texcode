package com.texgen.music.texwave.ui.screens.chat

import com.texgen.music.texwave.data.VerifiedBadgeStore
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import com.texgen.music.texwave.data.chat.WaveDropStore
import com.texgen.music.texwave.data.chat.FriendsStore
import com.texgen.music.texwave.data.chat.ChatPrefs
import com.texgen.music.texwave.data.chat.WavePresenceStore
import com.texgen.music.texwave.data.CreatorAdminStore
import com.texgen.music.texwave.ui.components.VerifiedStarBadge

import androidx.compose.foundation.background
import androidx.compose.ui.draw.scale
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.Card
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.chat.ChatAuthState
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.ConversationPreview
import com.texgen.music.texwave.data.chat.Resonance
import com.texgen.music.texwave.data.chat.ChatEmpireStore
import com.texgen.music.texwave.data.chat.ChatEmpireProtocol
import com.texgen.music.texwave.data.chat.StoriesRepository
import com.texgen.music.texwave.data.chat.ChatNotifier
import com.texgen.music.texwave.data.chat.ChatKeepAliveService
import com.texgen.music.texwave.data.chat.StoryWithAuthor
import android.net.Uri
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import android.widget.Toast
import android.Manifest
import android.os.Build
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.texgen.music.texwave.data.chat.avatarModel
import com.texgen.music.texwave.data.chat.isUserOnline
import com.texgen.music.texwave.data.chat.lastSeenLabel
import com.texgen.music.texwave.data.chat.parseIsoMillis

@Composable
private fun NameWithBadge(name: String, verified: Boolean, color: androidx.compose.ui.graphics.Color, size: androidx.compose.ui.unit.TextUnit = 15.sp) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(name, color = color, fontWeight = FontWeight.SemiBold, fontSize = size, maxLines = 1)
        if (verified) {
            Spacer(Modifier.width(4.dp))
            VerifiedStarBadge(size = 14.dp)
        }
    }
}

@Composable
fun ChatListScreen(
    repo: ChatRepository,
    onBack: () -> Unit,
    onOpenConversation: (conversationId: String, title: String) -> Unit,
    onSearchUsers: () -> Unit,
    onCreateGroup: () -> Unit = {},
    onOpenSettings: () -> Unit,
    onSidebarHome: () -> Unit = {},
    onSidebarWaves: () -> Unit = {},
    onSidebarMemes: () -> Unit = {},
    onSidebarDiscover: () -> Unit = {},
    onSidebarMusic: () -> Unit = {},
    onSidebarCircles: () -> Unit = {},
) {
    val auth by repo.authState.collectAsState()
    val convs by repo.conversations.collectAsState()
    var loading by remember { mutableStateOf(false) }
    var showSidebar by remember { mutableStateOf(false) }
    var sidebarSelected by remember { mutableStateOf(com.texgen.music.texwave.ui.screens.chat.ChatSidebarDest.Chats) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun reload() {
        loading = true
        error = null
        scope.launch {
            repo.loadConversations().onFailure { error = it.message }
            loading = false
        }
    }

    val onlineIds by repo.onlineUserIds.collectAsState()
    val recentlyActive by repo.recentlyActive.collectAsState()
    LaunchedEffect(auth) {
        if (auth !is ChatAuthState.SignedIn) return@LaunchedEffect
        while (true) {
            kotlinx.coroutines.delay(25_000)
            runCatching { repo.loadConversations() }
        }
    }
    val context = LocalContext.current
    LaunchedEffect(convs) {
        FriendsStore.syncFromConversations(context, convs)
    }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        ChatNotifier.ensureChannel(context)
        if (Build.VERSION.SDK_INT >= 33) {
            val ok = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (!ok) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        ChatKeepAliveService.start(context)
    }
    LaunchedEffect(auth) {
        if (auth is ChatAuthState.SignedIn) {
            ChatKeepAliveService.start(context)
        }
    }

    LaunchedEffect(auth) {
        if (auth is ChatAuthState.SignedIn) {
            reload()
            // a new message / new chat arrived: refresh the list right away
            launch {
                repo.inboxEvents.collect {
                    delay(400)
                    repo.loadConversations()
                }
            }
            // safety net in case the realtime connection drops
            while (true) {
                delay(15_000)
                repo.loadConversations()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .statusBarsPadding(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { showSidebar = true }) {
                Icon(Icons.Rounded.Menu, "Social menu", tint = Tx.Text)
            }
            Text(
                "Messages",
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = { reload() }) {
                Icon(Icons.Rounded.Refresh, "Refresh", tint = Tx.Muted)
            }
            IconButton(onClick = onSearchUsers) {
                Icon(Icons.Rounded.Edit, "New message", tint = Tx.Text)
            }
        }

        // Clean messages hub — search/profile live in header icons + Phantom profile
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("Your chats", color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            if (VerifiedBadgeStore.isVerified(context)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    VerifiedStarBadge(size = 14.dp)
                    Spacer(Modifier.width(4.dp))
                    Text("Verified", color = Color(0xFF1DA1F2), fontSize = 12.sp)
                }
            }
        }

                // Stories strip (24h)
        StoriesStrip(repo = repo)

        // Chat Empire quick powers
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            listOf(
                "🎵 Song cards",
                "🎧 Listen together",
                "🌙 Night crew",
                "✉ Letters",
                "🗳 Votes",
                "⏳ Capsules",
                "👻 Phantom seat",
            ).forEach { label ->
                Text(
                    label,
                    color = Color.White,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color(0x22A78BFA))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        when (auth) {
            is ChatAuthState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Tx.Accent, strokeWidth = 2.dp)
                }
            }
            is ChatAuthState.SignedOut, is ChatAuthState.Error -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Sign in to use messages", color = Tx.Muted)
                }
            }
            is ChatAuthState.SignedIn -> {
                if (loading && convs.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Tx.Accent, strokeWidth = 2.dp)
                    }
                } else if (convs.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Box(
                            Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(Tx.Accent.copy(alpha = 0.3f), Tx.Accent2.copy(alpha = 0.3f)))
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.Edit, null, tint = Tx.Accent, modifier = Modifier.size(32.dp))
                        }
                        Spacer(Modifier.height(20.dp))
                        Text("Your messages", color = Tx.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Send private photos, files and messages to friends",
                            color = Tx.Muted,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                        Spacer(Modifier.height(28.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Tx.Accent)
                                    .clickable(onClick = onSearchUsers)
                                    .padding(horizontal = 18.dp, vertical = 10.dp),
                            ) {
                                Text("New message", color = Color.Black, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Tx.SurfaceHigh)
                                    .clickable(onClick = onCreateGroup)
                                    .padding(horizontal = 18.dp, vertical = 10.dp),
                            ) {
                                Text("New group", color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                        }
                    }
                } else {
                    Column(Modifier.fillMaxSize()) {
                        val drop = WaveDropStore.today(context)
                        val dropDone = WaveDropStore.isDone(context)
                        val myPresence = WavePresenceStore.getLocal(context)
                        if (myPresence != null) {
                            Text(
                                "${myPresence.emoji} ${myPresence.label}",
                                color = Tx.Accent,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                            )
                        }
                        var showDropAnswer by remember { mutableStateOf(false) }
                        var dropAnswer by remember { mutableStateOf(WaveDropStore.myAnswer(context) ?: "") }
                        val friendIds = remember(convs) { FriendsStore.syncFromConversations(context, convs) }
                        val friendCount = friendIds.size
                        val solvers = remember(convs, drop.id) {
                            val samples = convs.mapNotNull { p ->
                                val sid = p.lastMessage?.senderId ?: return@mapNotNull null
                                val name = p.otherUser?.displayName
                                    ?: p.otherUser?.username
                                    ?: "Friend"
                                // If last message is from me, still show if it's a solved drop
                                Triple(sid, p.lastMessage?.body, name)
                            }
                            WaveDropStore.solversFromSamples(drop.id, samples)
                        }
                        val friendsSolved = solvers.size
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                                .clickable { showDropAnswer = true },
                            colors = androidx.compose.material3.CardDefaults.cardColors(
                                containerColor = Color(0xFF0C0E16),
                            ),
                            shape = RoundedCornerShape(16.dp),
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(
                                    if (dropDone) "Wave Drop · answered · tap to edit" else "Today's Wave Drop · tap to answer",
                                    color = Tx.Accent2,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(drop.title, color = Tx.Text, fontWeight = FontWeight.Medium)
                                Text(drop.prompt, color = Tx.Muted, fontSize = 12.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "$friendsSolved of $friendCount friends solved today",
                                    color = Tx.Accent2,
                                    fontSize = 12.sp,
                                )
                                if (solvers.isNotEmpty()) {
                                    Text(
                                        "Solved by: " + solvers.joinToString { it.name.ifBlank { "Friend" } },
                                        color = Tx.Muted,
                                        fontSize = 11.sp,
                                        maxLines = 2,
                                    )
                                }
                            }
                        }
                        if (showDropAnswer) {
                            AlertDialog(
                                onDismissRequest = { showDropAnswer = false },
                                title = { Text(drop.title) },
                                text = {
                                    Column {
                                        Text(drop.prompt, color = Tx.Muted, fontSize = 13.sp)
                                        Spacer(Modifier.height(10.dp))
                                        OutlinedTextField(
                                            value = dropAnswer,
                                            onValueChange = { dropAnswer = it.take(200) },
                                            label = { Text("Your answer") },
                                            modifier = Modifier.fillMaxWidth(),
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            "$friendsSolved friends solved · $friendCount friends",
                                            color = Tx.Muted,
                                            fontSize = 12.sp,
                                        )
                                        if (solvers.isNotEmpty()) {
                                            Spacer(Modifier.height(6.dp))
                                            Text("Who solved:", color = Tx.Text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                            solvers.forEach { s ->
                                                Text(
                                                    "· ${s.name}" + if (s.answer.isNotBlank()) " — ${s.answer.take(40)}" else "",
                                                    color = Tx.Muted,
                                                    fontSize = 12.sp,
                                                )
                                            }
                                        }
                                    }
                                },
                                confirmButton = {
                                    TextButton(onClick = {
                                        val ans = dropAnswer.trim()
                                        if (ans.isEmpty()) {
                                            Toast.makeText(context, "Write an answer first", Toast.LENGTH_SHORT).show()
                                        } else {
                                            WaveDropStore.saveAnswer(context, ans)
                                            showDropAnswer = false
                                            Toast.makeText(
                                                context,
                                                "Answer saved · use chat tools to share with friends",
                                                Toast.LENGTH_LONG,
                                            ).show()
                                        }
                                    }) { Text("Submit answer") }
                                },
                                dismissButton = {
                                    TextButton(onClick = { showDropAnswer = false }) { Text("Close") }
                                },
                            )
                        }

                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            LazyColumn(Modifier.fillMaxSize()) {
                                items(convs.sortedByDescending { ChatPrefs.isPinned(context, it.conversation.id) }, key = { it.conversation.id }) { preview ->
                                    InstaConversationRow(preview, onlineIds, recentlyActive) {
                                        val title = when {
                                            preview.conversation.isGroup ->
                                                preview.conversation.title ?: "Group"
                                            else ->
                                                preview.otherUser?.displayName
                                                    ?: preview.otherUser?.username
                                                    ?: "Chat"
                                        }
                                        onOpenConversation(preview.conversation.id, title)
                                    }
                                }
                                item { Spacer(Modifier.height(88.dp)) }
                            }
                            Column(
                                Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                horizontalAlignment = Alignment.End,
                            ) {
                                FloatingActionButton(
                                    onClick = onCreateGroup,
                                    containerColor = Tx.SurfaceHigh,
                                    contentColor = Tx.Accent,
                                    modifier = Modifier.size(48.dp),
                                ) {
                                    Icon(Icons.Rounded.GroupAdd, "New group")
                                }
                                FloatingActionButton(
                                    onClick = onSearchUsers,
                                    containerColor = Tx.Accent,
                                    contentColor = Color.Black,
                                ) {
                                    Icon(Icons.Rounded.Edit, "New message")
                                }
                            }
                        }
                    }
                }
                error?.let {
                    Text(it, color = Tx.Danger, modifier = Modifier.padding(16.dp), fontSize = 13.sp)
                }
            }
        }
    }

    val unread = convs.sumOf { it.unreadCount }
    ChatSettingsSidebar(
        visible = showSidebar,
        selected = sidebarSelected,
        unreadChats = unread,
        onClose = { showSidebar = false },
        onSelect = { dest: ChatSidebarDest ->
            sidebarSelected = dest
            showSidebar = false
            when (dest) {
                ChatSidebarDest.Home -> onSidebarHome()
                ChatSidebarDest.Chats -> Unit
                ChatSidebarDest.Waves -> onSidebarWaves()
                ChatSidebarDest.Memes -> onSidebarMemes()
                ChatSidebarDest.Photos -> Unit
                ChatSidebarDest.Stories -> Unit
                ChatSidebarDest.Create -> onSidebarCircles()
                ChatSidebarDest.Discover -> onSidebarDiscover()
                ChatSidebarDest.Music -> onSidebarMusic()
                ChatSidebarDest.InnerCircles -> Unit
            }
        },
    )
    } // Box
}

@Composable
private fun InstaConversationRow(preview: ConversationPreview, onlineIds: Set<String>, recentlyActive: Map<String, Long> = emptyMap(), onClick: () -> Unit) {
    val context = LocalContext.current
    val isGroup = preview.conversation.isGroup
    val name = when {
        isGroup -> preview.conversation.title ?: "Group"
        else -> preview.otherUser?.displayName ?: preview.otherUser?.username ?: "Unknown"
    }
    val online = !isGroup && preview.otherUser?.let { isUserOnline(it.id, it.lastSeenAt, onlineIds, recentlyActive[it.id] ?: 0L) } == true
    val quiet = ChatEmpireStore.isInQuietHours(context, preview.conversation.id)
    val body = preview.lastMessage?.body
    val last = when {
        ChatEmpireStore.shouldHideBody(context, preview.conversation.id, body) -> "🛡 Hidden by shield"
        Resonance.isResonance(body) ->
            Resonance.parse(body)?.preview()?.take(55) ?: "♪ Resonance"
        ChatEmpireProtocol.preview(body) != null -> ChatEmpireProtocol.preview(body)!!.take(55)
        body != null -> body.take(55)
        preview.lastMessage != null -> "Attachment"
        else -> if (isGroup) "Group created" else "Tap to chat"
    }
    val timeMs = parseIsoMillis(preview.lastMessage?.createdAt)
    val timeLabel = if (timeMs > 0L) {
        val diff = System.currentTimeMillis() - timeMs
        when {
            diff < 60_000 -> "now"
            diff < 3_600_000 -> "${diff / 60_000}m"
            diff < 86_400_000 -> "${diff / 3_600_000}h"
            else -> java.text.SimpleDateFormat("d MMM", java.util.Locale.getDefault()).format(java.util.Date(timeMs))
        }
    } else ""

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 3.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                if (preview.unreadCount > 0) Color(0x14A78BFA) else Color.Transparent
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ChatAvatar(
            name = name,
            imageUrl = preview.otherUser?.avatarModel,
            size = 58.dp,
            online = online,
            isGroup = isGroup,
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    name,
                    color = Tx.Text,
                    fontWeight = if (preview.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (VerifiedBadgeStore.isProfileVerified(preview.otherUser?.bio)) {
                    Spacer(Modifier.width(4.dp))
                    VerifiedStarBadge(size = 14.dp)
                }
                Spacer(Modifier.weight(1f))
                if (timeLabel.isNotEmpty()) {
                    Text(
                        timeLabel,
                        color = if (preview.unreadCount > 0) Color(0xFF5CE1FF) else Tx.Muted,
                        fontSize = 12.sp,
                        fontWeight = if (preview.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (online) {
                    Text("● ", color = Color(0xFF5CE1FF), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Text(
                    last,
                    color = if (preview.unreadCount > 0) Tx.Text else Tx.Muted,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = if (preview.unreadCount > 0) FontWeight.Medium else FontWeight.Normal,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        if (preview.unreadCount > 0) {
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF5CE1FF)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (preview.unreadCount > 9) "9+" else preview.unreadCount.toString(),
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    lineHeight = 11.sp,
                )
            }
        }
    }
}


@Composable
private fun StoriesStrip(repo: ChatRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var stories by remember { mutableStateOf<List<StoryWithAuthor>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var viewingStory by remember { mutableStateOf<StoryWithAuthor?>(null) }
    val storiesRepo = remember { StoriesRepository(repo) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            loading = true
            storiesRepo.publish(context, uri, null)
                .onSuccess {
                    Toast.makeText(context, "Story posted · lives 24h", Toast.LENGTH_SHORT).show()
                    storiesRepo.listActive().onSuccess { stories = it }
                }
                .onFailure {
                    Toast.makeText(
                        context,
                        it.message ?: "Story failed — run CREATE_STORIES_AND_CHAT.sql in Supabase",
                        Toast.LENGTH_LONG,
                    ).show()
                }
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        storiesRepo.listActive().onSuccess { stories = it }
    }

    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Add story
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .padding(end = 12.dp)
                .clickable(enabled = !loading) { pick.launch("*/*") },
        ) {
            Box(
                Modifier
                    .size(58.dp)
                    .border(
                        2.dp,
                        Brush.linearGradient(listOf(Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF))),
                        CircleShape,
                    )
                    .padding(3.dp)
                    .clip(CircleShape)
                    .background(Tx.SurfaceHigh),
                contentAlignment = Alignment.Center,
            ) {
                Text("+", color = Tx.Accent, fontSize = 26.sp, fontWeight = FontWeight.Light)
            }
            Text("Your story", color = Tx.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
        stories.forEach { s ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .padding(end = 12.dp)
                    .clickable { viewingStory = s },
            ) {
                Box(
                    Modifier
                        .size(58.dp)
                        .border(
                            2.5.dp,
                            Tx.StoryRing,
                            CircleShape,
                        )
                        .padding(3.dp)
                        .clip(CircleShape)
                        .background(Tx.SurfaceHigh),
                ) {
                    AsyncImage(
                        model = s.mediaUrl,
                        contentDescription = s.displayName ?: s.username,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                }
                Text(
                    (s.displayName ?: s.username ?: "Story").take(10),
                    color = Tx.Muted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }

    // Full-screen story viewer (Instagram-style)
    viewingStory?.let { story ->
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { viewingStory = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable { viewingStory = null },
            ) {
                val isVideo = story.mediaUrl.contains(".mp4") || story.mediaUrl.contains("video")
                if (isVideo) {
                    // Open system player for video stories
                    AndroidViewVideoHint(story.mediaUrl)
                } else {
                    AsyncImage(
                        model = story.mediaUrl,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit,
                    )
                }
                Column(
                    Modifier
                        .align(Alignment.TopStart)
                        .statusBarsPadding()
                        .padding(16.dp),
                ) {
                    Text(
                        story.displayName ?: story.username ?: "Story",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 16.sp,
                    )
                    story.caption?.takeIf { it.isNotBlank() }?.let {
                        Text(it, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                    }
                }
                Text(
                    "Tap to close",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 12.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(24.dp),
                )
            }
        }
    }
}

@Composable
private fun AndroidViewVideoHint(url: String) {
    val context = LocalContext.current
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Video story", color = Color.White, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                "Tap to play",
                color = Tx.Accent,
                fontSize = 14.sp,
                modifier = Modifier.clickable {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(Uri.parse(url), "video/*")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    } catch (_: Exception) {
                        Toast.makeText(context, "Cannot play video", Toast.LENGTH_SHORT).show()
                    }
                },
            )
            AsyncImage(
                model = url,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentScale = ContentScale.Fit,
            )
        }
    }
}
