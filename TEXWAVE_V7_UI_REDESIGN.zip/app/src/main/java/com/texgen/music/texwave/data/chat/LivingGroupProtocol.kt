package com.texgen.music.texwave.data.chat

/**
 * Living Groups — polls, shared listen, challenges encoded in message body (no schema change).
 */
object LivingGroupProtocol {
    data class Poll(
        val question: String,
        val options: List<String>,
        val votes: Map<String, Int> = emptyMap(), // optionIndex as string -> count (client-side tally from replies)
    )

    fun encodePoll(question: String, options: List<String>): String {
        val opts = options.take(6).joinToString(";") { it.replace(";", ",").replace("|", "/") }
        return "TEXWAVE_POLL:${question.replace("|", "/")}|$opts"
    }

    fun parsePoll(body: String?): Poll? {
        if (body == null || !body.startsWith("TEXWAVE_POLL:")) return null
        val rest = body.removePrefix("TEXWAVE_POLL:")
        val parts = rest.split("|", limit = 2)
        if (parts.size < 2) return null
        val options = parts[1].split(";").map { it.trim() }.filter { it.isNotEmpty() }
        if (options.isEmpty()) return null
        return Poll(parts[0], options)
    }

    fun encodeVote(pollSnippet: String, optionIndex: Int): String =
        "TEXWAVE_VOTE:$optionIndex|${pollSnippet.take(40)}"

    fun encodeSharedListen(title: String, artist: String): String =
        "TEXWAVE_LISTEN:${title.replace("|", "/")}|${artist.replace("|", "/")}"

    fun parseListen(body: String?): Pair<String, String>? {
        if (body == null || !body.startsWith("TEXWAVE_LISTEN:")) return null
        val p = body.removePrefix("TEXWAVE_LISTEN:").split("|")
        return (p.getOrNull(0) ?: return null) to (p.getOrNull(1) ?: "")
    }

    fun encodeChallenge(text: String): String =
        "TEXWAVE_CHALLENGE:${text.take(180).replace("|", "/")}"
}
