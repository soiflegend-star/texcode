package com.texgen.music.texwave.ui.screens

import android.graphics.Bitmap
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.data.AppTheme
import com.texgen.music.texwave.data.NotifCatalog
import com.texgen.music.texwave.data.NotifStyle
import com.texgen.music.texwave.data.ThemeCatalog
import com.texgen.music.texwave.notification.NotifArtRenderer
import com.texgen.music.texwave.notification.NotifMedia
import com.texgen.music.texwave.notification.NotifVideoFrames
import com.texgen.music.texwave.ui.SettingsState
import com.texgen.music.texwave.ui.components.GhostButton
import com.texgen.music.texwave.ui.components.GradientButton
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.seedColors
import com.texgen.music.texwave.util.SoifLogo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class SettingsActions(
    val onBack: () -> Unit,
    val onSelectTheme: (String) -> Unit,
    val onSelectNotif: (String) -> Unit,
    val onOpenAlarms: () -> Unit = {},
    val onOpenEqualizer: () -> Unit,
    val onPickCustomArt: () -> Unit,
    val onPickNotifImage: () -> Unit,
    val onPickNotifVideo: () -> Unit,
    val onClearNotifVideo: () -> Unit,
    val onSoif: (Boolean) -> Unit,
    val onSoifStyled: (Boolean) -> Unit,
    val onWakeEnabled: (Boolean) -> Unit = {},
    val onWakeWord: (String) -> Unit = {},
    val onParticles: (Boolean) -> Unit,
    val onSnowOverlay: (Boolean) -> Unit = {},
    val onReactiveViz: (Boolean) -> Unit,
    val onSkipSilence: (Boolean) -> Unit,
)

@Composable
fun SettingsScreen(
    settings: SettingsState,
    actions: SettingsActions,
) {
    var section by remember { mutableStateOf("main") } // main | themes | notif
    var search by remember { mutableStateOf("") }

    BackHandler { if (section == "main") actions.onBack() else section = "main" }

    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = {
                if (section == "main") actions.onBack() else section = "main"
            }) {
                Icon(Icons.Rounded.ArrowBack, "Back", tint = Tx.Text)
            }
            Text(
                when (section) {
                    "themes" -> "Themes"
                    "notif" -> "Notification"
                    else -> "Settings"
                },
                color = Tx.Text,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f),
            )
        }

        when (section) {
            "themes" -> ThemeBrowser(
                currentId = settings.themeId,
                search = search,
                onSearch = { search = it },
                onSelect = actions.onSelectTheme,
            )
            "notif" -> NotifBrowser(settings, actions)
            else -> MainSettings(
                settings = settings,
                actions = actions,
                onThemes = { section = "themes"; search = "" },
                onNotif = { section = "notif" },
            )
        }
    }
}

@Composable
private fun MainSettings(
    settings: SettingsState,
    actions: SettingsActions,
    onThemes: () -> Unit,
    onNotif: () -> Unit,
) {
    val theme = ThemeCatalog.byId(settings.themeId)
    val notif = NotifCatalog.byId(settings.notifStyleId)

    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SettingsCard(Icons.Rounded.Palette, "Theme", theme.name, onThemes)
        }
        item {
            SettingsCard(
                Icons.Rounded.Notifications,
                "Notification",
                notif.name + if (notif.isAnimated) " · animated" else "",
                onNotif,
            )
        }
        item {
            SettingsCard(Icons.Rounded.Equalizer, "Equalizer", "Bass, treble & presets", actions.onOpenEqualizer)
            SettingsCard(
                Icons.Rounded.Alarm,
                "Alarms",
                "Set time · weather briefing · custom song tone",
                actions.onOpenAlarms,
            )
        }
        item {
            SettingsCard(Icons.Rounded.Image, "Cover art for current song", "Pick an image · also shown in the notification", actions.onPickCustomArt)
        }
        item { SwitchRow("Snow", "Small Instagram-style snow on Now Playing", settings.particles, actions.onParticles) }
        item {
            SwitchRow(
                "Snow over apps",
                "Falls on every app. Needs “Display over other apps” permission. Single small dots.",
                settings.snowOverlay,
                actions.onSnowOverlay,
            )
        }
        item {
            SwitchRow(
                "Wake word",
                "Say “${settings.wakeWord}” then your command · needs offline Vosk model · low battery mode",
                settings.wakeEnabled,
                actions.onWakeEnabled,
            )
        }
        item {
            Column(
                Modifier
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Tx.Surface)
                    .padding(14.dp),
            ) {
                Text("Wake word", color = Tx.Text, style = MaterialTheme.typography.titleSmall)
                Text(
                    "Say this word, then your command. After ~2 seconds of silence it sends automatically. PHANTOM replies by voice.",
                    color = Tx.Muted,
                    style = MaterialTheme.typography.bodySmall,
                )
                var wordDraft by remember(settings.wakeWord) { mutableStateOf(settings.wakeWord) }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = wordDraft,
                    onValueChange = { wordDraft = it.lowercase().filter { c -> c.isLetterOrDigit() || c == ' ' }.take(24) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("phantom", color = Tx.Muted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Tx.Text,
                        unfocusedTextColor = Tx.Text,
                        focusedBorderColor = Tx.Accent,
                        unfocusedBorderColor = Tx.Outline,
                        cursorColor = Tx.Accent2,
                        focusedContainerColor = Tx.SurfaceHigh,
                        unfocusedContainerColor = Tx.SurfaceHigh,
                    ),
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = {
                        actions.onWakeWord(wordDraft)
                        if (settings.wakeEnabled) {
                            // parent restarts service via onWakeWord + enabled
                        }
                    }) { Text("Save wake word", color = Tx.Accent2) }
                }
            }
        }
        item {
            SwitchRow(
                "Beat-reactive visuals",
                "Visualizer and particles follow the music. Needs microphone permission.",
                settings.reactiveViz,
                actions.onReactiveViz,
            )
        }
        item { SwitchRow("Skip silence", "Jump over silent gaps in tracks", settings.skipSilence, actions.onSkipSilence) }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Tx.Surface)
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Tx.Text, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Tx.Accent, checkedThumbColor = Color.White),
        )
    }
}

@Composable
private fun SettingsCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Tx.Surface)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Tx.Accent.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = Tx.Accent2, modifier = Modifier.size(24.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = Tx.Text, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
        }
        Icon(Icons.Rounded.Tune, null, tint = Tx.Muted, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun ThemeBrowser(
    currentId: String,
    search: String,
    onSearch: (String) -> Unit,
    onSelect: (String) -> Unit,
) {
    val filtered = remember(search) {
        val q = search.trim().lowercase()
        if (q.isEmpty()) ThemeCatalog.all
        else ThemeCatalog.all.filter {
            it.name.lowercase().contains(q) || it.description.lowercase().contains(q)
        }
    }

    Column(Modifier.fillMaxSize()) {
        SearchField(search, onSearch, "Search themes…")
        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(filtered, key = { it.id }) { theme ->
                ThemeRow(theme, selected = theme.id == currentId, onClick = { onSelect(theme.id) })
            }
            if (filtered.isEmpty()) {
                item {
                    Text("No themes match. Try another keyword.", color = Tx.Muted, modifier = Modifier.padding(16.dp))
                }
            }
        }
    }
}

@Composable
private fun NotifBrowser(settings: SettingsState, actions: SettingsActions) {
    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                NotifPreview(settings)
            }
        }
        item {
            Text(
                "Live preview of your notification artwork. Android refreshes notification images a couple of times a second, so the animation plays frame by frame.",
                color = Tx.Muted,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientButton(
                    if (settings.notifVideoFrames > 0) "Change video" else "Pick video",
                    Icons.Rounded.VideoLibrary,
                    actions.onPickNotifVideo,
                )
                GhostButton("Pick image", Icons.Rounded.Image, actions.onPickNotifImage)
            }
        }
        if (settings.notifVideoBusy) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator(color = Tx.Accent2, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text("Cutting frames from your video…", color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        } else if (settings.notifVideoFrames > 0) {
            item {
                Text(
                    "Video ready · ${settings.notifVideoFrames} frames. Remove it",
                    color = Tx.Accent2,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.clickable(onClick = actions.onClearNotifVideo),
                )
            }
        }
        // SOIF branding removed
        items(NotifCatalog.all, key = { it.id }) { style ->
            NotifRow(
                style = style,
                selected = style.id == settings.notifStyleId,
                onClick = {
                    when {
                        style.id == "custom" && settings.notifCustomUri == null -> actions.onPickNotifImage()
                        style.id == "video" && settings.notifVideoFrames <= 0 -> actions.onPickNotifVideo()
                        else -> actions.onSelectNotif(style.id)
                    }
                },
            )
        }
    }
}

@Composable
private fun NotifPreview(settings: SettingsState) {
    val context = LocalContext.current
    val theme = ThemeCatalog.byId(settings.themeId)
    val style = settings.notifStyleId
    val animated = NotifCatalog.byId(style).isAnimated
    val base by produceState<Bitmap?>(null, style, settings.notifCustomUri) {
        value = withContext(Dispatchers.IO) {
            val u = settings.notifCustomUri
            if (style == "custom" && u != null) NotifMedia.decodeSquare(context, Uri.parse(u), 256) else null
        }
    }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(style, base, settings.notifSoif, settings.notifVideoFrames, theme.id) {
        var f = 0
        while (true) {
            image = withContext(Dispatchers.Default) {
                val video = if (style == "video" && settings.notifVideoFrames > 0)
                    NotifVideoFrames.load(context, f, settings.notifVideoFrames) else null
                NotifArtRenderer.render(
                    size = 256,
                    style = style,
                    frame = f,
                    base = base,
                    videoFrame = video,
                    seed = "Texwave",
                    accent = theme.primary.toInt(),
                    accent2 = theme.secondary.toInt(),
                    showLogo = settings.notifSoif,
                ).asImageBitmap()
            }
            if (!animated) break
            delay(700)
            f++
        }
    }
    Box(
        Modifier
            .size(200.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Tx.Surface),
        contentAlignment = Alignment.Center,
    ) {
        image?.let {
            Image(it, "Notification preview", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, placeholder: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp),
        placeholder = { Text(placeholder, color = Tx.Muted) },
        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Tx.Muted) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Tx.Accent,
            unfocusedBorderColor = Tx.Outline,
            focusedTextColor = Tx.Text,
            unfocusedTextColor = Tx.Text,
            cursorColor = Tx.Accent2,
            focusedContainerColor = Tx.Surface,
            unfocusedContainerColor = Tx.Surface,
        ),
    )
}

@Composable
private fun ThemeRow(theme: AppTheme, selected: Boolean, onClick: () -> Unit) {
    val c1 = Color(theme.primary)
    val c2 = Color(theme.secondary)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Tx.SurfaceHigh else Tx.Surface)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(c1, c2)))
        )
        Column(Modifier.weight(1f)) {
            Text(theme.name, color = Tx.Text, style = MaterialTheme.typography.titleMedium)
            Text(theme.description, color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
        }
        if (selected) {
            Icon(Icons.Rounded.Check, "Selected", tint = Tx.Accent2)
        }
    }
}

@Composable
private fun NotifRow(style: NotifStyle, selected: Boolean, onClick: () -> Unit) {
    val colors = seedColors(style.previewSeed)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Tx.SurfaceHigh else Tx.Surface)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(colors.first, colors.second))),
            contentAlignment = Alignment.Center,
        ) {
            if (style.isAnimated) {
                Text("✦", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(style.name, color = Tx.Text, style = MaterialTheme.typography.titleMedium)
            Text(style.description, color = Tx.Muted, style = MaterialTheme.typography.bodySmall)
        }
        if (selected) {
            Icon(Icons.Rounded.Check, "Selected", tint = Tx.Accent2)
        }
    }
}
