package com.texgen.music.texwave.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.AppTheme
import kotlin.math.abs

object Tx {
    var Bg by mutableStateOf(Color(0xFF010105))
        private set
    var Surface by mutableStateOf(Color(0xFF08060F))
        private set
    var SurfaceHigh by mutableStateOf(Color(0xFF12101C))
        private set
    var Glass by mutableStateOf(Color(0xE60A0816))
        private set
    var Outline by mutableStateOf(Color(0xFF1A1528))
        private set
    var Accent by mutableStateOf(Color(0xFFA37CFF))
        private set
    var Accent2 by mutableStateOf(Color(0xFF2FE6FF))
        private set
    var Text by mutableStateOf(Color(0xFFF0ECFF))
        private set
    var Muted by mutableStateOf(Color(0xFF9A93B4))
        private set
    var Danger by mutableStateOf(Color(0xFFFF5A7A))
        private set

    /** Third brand colour (hot magenta) used for glows and highlights. */
    val Accent3 = Color(0xFFFF3DCB)

    val Brand: Brush
        get() = Brush.linearGradient(listOf(Accent, Accent2, Accent3))

    val BrandVertical: Brush
        get() = Brush.verticalGradient(listOf(Accent.copy(alpha = 0.35f), Color.Transparent))

    val CosmicBg: Brush
        get() = Brush.verticalGradient(
            listOf(Color(0xFF000000), Color(0xFF060412), Color(0xFF0C0720), Color(0xFF05030E), Color(0xFF000000))
        )

    val GlassCard: Brush
        get() = Brush.linearGradient(
            listOf(Color(0x22FFFFFF), Color(0x0AFFFFFF), Accent.copy(0.16f), Accent2.copy(0.12f))
        )

    val BubbleMine: Brush
        get() = Brush.linearGradient(listOf(Color(0xFF5B34D6), Color(0xFF3B1FA3), Color(0xFF8A2BC2)))

    val StoryRing: Brush
        get() = Brush.linearGradient(
            listOf(Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF), Color(0xFF515BD4), Color(0xFF5CE1FF))
        )

    fun apply(theme: AppTheme) {
        fun c(v: Long): Color = try {
            Color(v.toInt())
        } catch (_: Exception) {
            Color(0xFF8B6CFF)
        }
        Bg = c(theme.background)
        Surface = c(theme.surface)
        val s = c(theme.surface)
        SurfaceHigh = Color(
            red = (s.red + 0.05f).coerceAtMost(1f),
            green = (s.green + 0.05f).coerceAtMost(1f),
            blue = (s.blue + 0.06f).coerceAtMost(1f),
        )
        Glass = SurfaceHigh.copy(alpha = 0.82f)
        Accent = c(theme.primary)
        Accent2 = c(theme.secondary)
        Outline = Color(0xFF241A3D)
        Text = Color(0xFFF0ECFF)
        Muted = Color(0xFF8A82A8)
    }
}

fun seedColors(seed: String): Pair<Color, Color> {
    val hue = (abs(seed.hashCode()) % 360).toFloat()
    return Color.hsv(hue, 0.68f, 0.94f) to Color.hsv((hue + 48f) % 360f, 0.82f, 0.48f)
}

private val TexTypography = Typography(
    headlineLarge = TextStyle(fontSize = 32.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp),
    labelSmall = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.2.sp),
)

/** Premium glass panel — translucent stack + specular edge (no runtime blur required). */
fun Modifier.glassCard(corner: Int = 20): Modifier =
    this
        .clip(RoundedCornerShape(corner.dp))
        .background(
            Brush.verticalGradient(
                listOf(
                    Color(0x55FFFFFF),
                    Color(0x18FFFFFF),
                    Color(0x0AFFFFFF),
                    Tx.Glass,
                )
            )
        )
        .background(Tx.Surface.copy(alpha = 0.55f))
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(
                    Color(0x88FFFFFF),
                    Tx.Accent.copy(alpha = 0.55f),
                    Tx.Accent2.copy(alpha = 0.45f),
                    Tx.Accent3.copy(alpha = 0.35f),
                    Color(0x22FFFFFF),
                )
            ),
            RoundedCornerShape(corner.dp),
        )

/** Thin frosted bar — headers / composers. */
fun Modifier.glassBar(corner: Int = 22): Modifier =
    this
        .clip(RoundedCornerShape(corner.dp))
        .background(Color(0xCC0A0814))
        .background(
            Brush.verticalGradient(
                listOf(Color(0x28FFFFFF), Color(0x08FFFFFF), Color.Transparent)
            )
        )
        .border(
            0.8.dp,
            Brush.linearGradient(
                listOf(
                    Color(0x55FFFFFF),
                    Tx.Accent2.copy(0.35f),
                    Tx.Accent.copy(0.25f),
                    Color(0x22FFFFFF),
                )
            ),
            RoundedCornerShape(corner.dp),
        )

/** Pill chip with glass edge. */
fun Modifier.glassPill(): Modifier =
    this
        .clip(RoundedCornerShape(999.dp))
        .background(Color(0x33101830))
        .border(
            1.dp,
            Brush.horizontalGradient(listOf(Tx.Accent2.copy(0.55f), Tx.Accent.copy(0.4f), Color(0x44FFFFFF))),
            RoundedCornerShape(999.dp),
        )

@Composable
fun TexwaveTheme(content: @Composable () -> Unit) {
    val accent = Tx.Accent
    val accent2 = Tx.Accent2
    val bg = Tx.Bg
    val surface = Tx.Surface
    val surfaceHigh = Tx.SurfaceHigh
    val muted = Tx.Muted
    val text = Tx.Text
    val outline = Tx.Outline

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            onPrimary = Color.White,
            secondary = accent2,
            background = bg,
            onBackground = text,
            surface = surface,
            onSurface = text,
            surfaceVariant = surfaceHigh,
            onSurfaceVariant = muted,
            outline = outline,
        ),
        typography = TexTypography,
        content = content,
    )
}
