package com.texgen.music.texwave.player

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.texgen.music.texwave.MainActivity
import com.texgen.music.texwave.notification.TexwaveNotificationProvider

/**
 * Full music session host: ExoPlayer + MediaSession with audio focus,
 * noisy-audio handling, wake lock, skip-silence and the custom Texwave notification.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var player: ExoPlayer? = null
    private var provider: TexwaveNotificationProvider? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            provider?.onPlayerChanged()
        }

        override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
            provider?.onPlayerChanged()
        }

        override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
            provider?.onPlayerChanged()
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            Companion.audioSessionId = audioSessionId
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val p = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        p.skipSilenceEnabled = skipSilence
        p.addListener(playerListener)
        audioSessionId = p.audioSessionId
        player = p

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val artPlayer = ArtPlayer(p)
        session = MediaSession.Builder(this, artPlayer)
            .setSessionActivity(openApp)
            .build()

        try {
            val prov = TexwaveNotificationProvider(this)
            prov.artSink = { key, bmp -> artPlayer.setArt(key, bmp) }
            provider = prov
            setMediaNotificationProvider(prov)
        } catch (t: Throwable) {
            // fall back to Media3's own notification
            provider = null
            com.texgen.music.texwave.CrashGuard.nonFatal("provider", t)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        audioSessionId = 0
        provider?.release()
        provider = null
        player?.removeListener(playerListener)
        session?.run {
            player.release()
            release()
        }
        session = null
        player = null
        super.onDestroy()
    }

    companion object {
        /** ExoPlayer audio session id (the app and the service share one process). 0 = none. */
        @Volatile
        var audioSessionId: Int = 0

        @Volatile
        private var instance: PlaybackService? = null

        @Volatile
        var skipSilence: Boolean = false
            set(value) {
                field = value
                instance?.player?.let { p ->
                    android.os.Handler(p.applicationLooper).post { p.skipSilenceEnabled = value }
                }
            }
    }
}
