package com.texgen.music.texwave.ui.screens.chat

import com.texgen.music.texwave.data.chat.SilentSignalStore
import com.texgen.music.texwave.data.chat.CallSignal
import com.texgen.music.texwave.data.chat.LivingGroupProtocol
import com.texgen.music.texwave.data.chat.WavePresenceStore
import com.texgen.music.texwave.data.chat.ResonanceReply
import com.texgen.music.texwave.data.chat.ChatThemeStore

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AttachFile
import com.texgen.music.texwave.data.chat.WaveDropStore
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.scaleIn
import androidx.compose.animation.fadeIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import com.texgen.music.texwave.data.chat.ChatAuthState
import com.texgen.music.texwave.data.chat.ChatMessageUi
import com.texgen.music.texwave.data.chat.ConversationMembers
import com.texgen.music.texwave.data.chat.Message
import com.texgen.music.texwave.data.chat.avatarModel
import com.texgen.music.texwave.data.chat.isUserOnline
import com.texgen.music.texwave.data.chat.lastSeenLabel
import com.texgen.music.texwave.data.chat.parseIsoMillis
import java.util.UUID
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.Resonance
import com.texgen.music.texwave.data.chat.SharedSoundtrackStore
import com.texgen.music.texwave.data.chat.MemoryCapsuleStore
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import com.texgen.music.texwave.data.chat.ChatEmpireProtocol
import com.texgen.music.texwave.data.chat.ChatEmpireStore

@Composable
fun ConversationScreen(
    repo: ChatRepository,
    conversationId: String,
    title: String,
    onBack: () -> Unit,
    forceJoinRoom: String? = null,
    forceJoinPeer: String? = null,
    onForceJoinConsumed: () -> Unit = {},
    librarySongs: List<Song> = emptyList(),
    onPlaySong: (Song) -> Unit = {},
    onPlayResonance: (title: String, artist: String, storagePath: String?) -> Unit = { _, _, _ -> },
) {
    val messages = remember { mutableStateListOf<ChatMessageUi>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var sending by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableFloatStateOf(-1f) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var members by remember { mutableStateOf<ConversationMembers?>(null) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val auth by repo.authState.collectAsState()
    val myId = (auth as? ChatAuthState.SignedIn)?.profile?.id ?: ""
    val onlineIds by repo.onlineUserIds.collectAsState()
    val recentlyActive by repo.recentlyActive.collectAsState()
    LaunchedEffect(messages) {
        val me = (repo.authState.value as? com.texgen.music.texwave.data.chat.ChatAuthState.SignedIn)?.profile?.id
        messages.takeLast(12).forEach { m ->
            val sid = m.message.senderId
            if (sid.isNotBlank() && sid != me) repo.noteUserActive(sid)
        }
    }


    // Refresh presence / last-seen so Active now stays accurate
        DisposableEffect(conversationId) {
        repo.setActiveConversation(conversationId)
        onDispose { repo.setActiveConversation(null) }
    }

    LaunchedEffect(conversationId) {
        while (true) {
            delay(12_000)
            repo.loadMembers(conversationId).onSuccess { m ->
                members = m
                m.profiles.forEach { p ->
                    if (com.texgen.music.texwave.data.chat.isUserOnline(p.id, p.lastSeenAt, onlineIds)) {
                        repo.noteUserActive(p.id)
                    }
                }
            }
        }
    }

    // Live channel for this chat: new messages, typing, seen.
    val live = remember(conversationId) { repo.openConversation(conversationId) }
    DisposableEffect(conversationId) { onDispose { live.close(); repo.clearActiveConversation(conversationId) } }
    val typingIds by live.typingUserIds.collectAsState()
    val readAt by live.readAt.collectAsState()

    // Per-chat theme (password "soifstar" to edit)
    var theme by remember(conversationId) { mutableStateOf(ChatThemeStore.get(context, conversationId)) }
    var showThemePw by remember { mutableStateOf(false) }
    var themePw by remember { mutableStateOf("") }
    var themePwError by remember { mutableStateOf<String?>(null) }
    var showThemePicker by remember { mutableStateOf(false) }
    var showResonance by remember { mutableStateOf(false) }
    var showSoundtrack by remember { mutableStateOf(false) }
    var showCapsules by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    val mediaRecorderHolder = remember { mutableStateOf<android.media.MediaRecorder?>(null) }
    val recordPathHolder = remember { mutableStateOf<String?>(null) }

    val pickThemeBg = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        // Local preview immediately
        val local = theme.copy(backgroundUri = uri.toString(), preset = 5)
        theme = local
        ChatThemeStore.set(context, conversationId, local)
        showThemePicker = false
        // Upload so the other person can see the same photo
        scope.launch {
            repo.uploadThemeBackground(conversationId, uri)
                .onSuccess { publicUrl ->
                    val shared = theme.copy(backgroundUri = publicUrl, preset = 5)
                    theme = shared
                    ChatThemeStore.set(context, conversationId, shared)
                    val body = ChatThemeStore.encode(shared)
                    repo.sendText(conversationId, body)
                    Toast.makeText(context, "Theme photo shared with them", Toast.LENGTH_SHORT).show()
                }
                .onFailure { e ->
                    Toast.makeText(
                        context,
                        "Photo saved for you · share failed: ${e.message ?: "upload"}",
                        Toast.LENGTH_LONG,
                    ).show()
                }
        }
    }


    val others = members?.profiles.orEmpty()
    val isGroup = others.size > 1
    val other = if (!isGroup) others.firstOrNull() else null
    val typingNames = others.filter { it.id in typingIds }.map { it.displayName }
    val otherOnline = other != null && isUserOnline(other.id, other.lastSeenAt, onlineIds)

    // Keeps server messages, plus my own messages that are still sending / failed.
    fun applyServer(fresh: List<ChatMessageUi>) {
        val freshClientIds = fresh.mapNotNull { it.message.clientMsgId }.toSet()
        val local = messages.filter {
            (it.isPending || it.isFailed) && it.message.clientMsgId !in freshClientIds
        }
        val merged = fresh + local
        val same = merged.size == messages.size &&
            merged.indices.all { i ->
                merged[i].message.id == messages[i].message.id &&
                    merged[i].attachments.size == messages[i].attachments.size &&
                    merged[i].isPending == messages[i].isPending &&
                    merged[i].isFailed == messages[i].isFailed
            }
        if (!same) {
            messages.clear()
            messages.addAll(merged)
        }
    }

    fun sendMessage(text: String, retryOf: ChatMessageUi? = null) {
        val clientId = retryOf?.message?.clientMsgId ?: UUID.randomUUID().toString()
        val localId = "local-$clientId"
        val local = ChatMessageUi(
            message = Message(
                id = localId,
                conversationId = conversationId,
                senderId = myId,
                body = text,
                clientMsgId = clientId,
            ),
            isMine = true,
            isPending = true,
        )
        val at = messages.indexOfFirst { it.message.id == localId }
        if (at >= 0) messages[at] = local else messages.add(local)
        live.sendTyping(false)
        scope.launch {
            repo.sendText(conversationId, text, clientId)
                .onSuccess { m ->
                    val i = messages.indexOfFirst { it.message.id == localId }
                    val already = messages.any { it.message.id == m.id }
                    val real = ChatMessageUi(message = m, isMine = true)
                    if (i >= 0) {
                        if (already) messages.removeAt(i) else messages[i] = real
                    } else if (!already) {
                        messages.add(real)
                    }
                }
                .onFailure { e ->
                    val i = messages.indexOfFirst { it.message.id == localId }
                    if (i >= 0) messages[i] = local.copy(isPending = false, isFailed = true)
                    error = e.message
                }
        }
    }

    val pickAttachment = { uri: Uri? ->
        if (uri != null) {
            sending = true
            uploadProgress = 0f
            scope.launch {
                repo.sendAttachment(conversationId, uri) { p -> uploadProgress = p }
                    .onSuccess { ui ->
                        if (messages.none { it.message.id == ui.message.id }) messages.add(ui)
                    }
                    .onFailure { e ->
                        error = e.message
                        Toast.makeText(context, e.message ?: "Upload failed", Toast.LENGTH_LONG).show()
                    }
                sending = false
                uploadProgress = -1f
            }
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
        }
        pickAttachment(uri)
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        pickAttachment(uri)
    }

    // Initial load + live messages + safety-net refresh.
    LaunchedEffect(conversationId) {
        // new messages from the other person, instantly
        launch {
            live.incoming.collect { m ->
                launch {
                    val ui = repo.toUi(m)
                    if (messages.none { it.message.id == ui.message.id }) messages.add(ui)
                    if (repo.isForeground) repo.markRead(conversationId)
                }
            }
        }
        loading = true
        repo.loadMembers(conversationId).onSuccess {
            members = it
            live.seedReadAt(it.readAt)
        }
        repo.loadMessages(conversationId)
            .onSuccess {
                applyServer(it)
                repo.markRead(conversationId)
            }
            .onFailure { error = it.message }
        loading = false
        if (messages.isNotEmpty()) listState.scrollToItem(messages.lastIndex)

        // safety net: if the realtime socket is down, polling still keeps the chat correct
        var round = 0
        while (true) {
            delay(8000)
            round++
            repo.loadMessages(conversationId).onSuccess { fresh ->
                val hadNew = fresh.any { f -> !f.isMine && messages.none { it.message.id == f.message.id } }
                applyServer(fresh)
                if (hadNew && repo.isForeground) repo.markRead(conversationId)
            }
            if (round % 2 == 0 || members == null) {
                repo.loadMembers(conversationId).onSuccess {
                    members = it
                    live.seedReadAt(it.readAt)
                }
            }
        }
    }

    // Always show the newest message.
    LaunchedEffect(messages.size, typingNames.isNotEmpty()) {
        if (messages.isNotEmpty()) {
            val last = messages.lastIndex + if (typingNames.isNotEmpty()) 1 else 0
            listState.animateScrollToItem(last)
        }
    }

    // "typing…" for the other person: announce while I type, stop after 3 s of silence.
    val lastTypingSent = remember { longArrayOf(0L) }
    LaunchedEffect(input) {
        if (input.isNotEmpty()) {
            val now = System.currentTimeMillis()
            if (now - lastTypingSent[0] > 2500L) {
                live.sendTyping(true)
                lastTypingSent[0] = now
            }
            delay(3000)
            live.sendTyping(false)
            lastTypingSent[0] = 0L
        }
    }


    ConversationBody(
        forceJoinRoom = forceJoinRoom,
        forceJoinPeer = forceJoinPeer,
        onForceJoinConsumed = onForceJoinConsumed,
        repo = repo,
        conversationId = conversationId,
        title = title,
        onBack = onBack,
        librarySongs = librarySongs,
        onPlayResonance = onPlayResonance,
        messages = messages,
        members = members,
        onlineIds = onlineIds,
        recentlyActive = recentlyActive,
        typingIds = typingIds,
        readAt = readAt,
        loading = loading,
        error = error,
        onError = { error = it },
        input = input,
        onInputChange = { input = it },
        uploadProgress = uploadProgress,
        onUploadProgress = { uploadProgress = it },
        listState = listState,
        theme = theme,
        onThemeChange = { theme = it },
        showResonance = showResonance,
        onShowResonance = { showResonance = it },
        showSoundtrack = showSoundtrack,
        onShowSoundtrack = { showSoundtrack = it },
        showCapsules = showCapsules,
        onShowCapsules = { showCapsules = it },
        showThemePw = showThemePw,
        onShowThemePw = { showThemePw = it },
        themePw = themePw,
        onThemePwChange = { themePw = it },
        themePwError = themePwError,
        onThemePwError = { themePwError = it },
        showThemePicker = showThemePicker,
        onShowThemePicker = { showThemePicker = it },
        menuOpen = menuOpen,
        onMenuOpen = { menuOpen = it },
        recording = recording,
        onRecordingChange = { recording = it },
        mediaRecorderHolder = mediaRecorderHolder,
        recordPathHolder = recordPathHolder,
        pickThemeBg = pickThemeBg,
        imagePicker = imagePicker,
        filePicker = filePicker,
        onSendMessage = { sendMessage(it) },
        onPickedAttachment = { pickAttachment(it) },
        live = live,
        myId = myId,
        scope = scope,
        context = context,
    )
}

@Composable
internal fun ResonanceCard(
    payload: Resonance.Payload,
    mine: Boolean,
    onPlay: () -> Unit,
    onSaveCapsule: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = if (mine) 0.18f else 0.35f))
            .clickable(onClick = onPlay)
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF7B61FF), Color(0xFF5CE1FF), Tx.Accent, Color(0xFF4A7FFF))),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.MusicNote, null, tint = Color.White, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("RESONANCE", color = Color.White.copy(alpha = 0.55f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(payload.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1)
                Text(payload.artist.ifBlank { "Unknown artist" }, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp, maxLines = 1)
            }
        }
        if (!payload.mood.isNullOrBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(
                "· ${payload.mood}",
                color = Color(0xFFA78BFA),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
            )
        }
        if (!payload.replyToMessageId.isNullOrBlank()) {
            Text("Song reply", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row {
            Text(
                "Tap to play",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp,
                modifier = Modifier.weight(1f),
            )
            Text(
                "Save memory",
                color = Color(0xFF67E8F9),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable(onClick = onSaveCapsule),
            )
        }
    }
}

@Composable
internal fun TypingBubble() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        Row(
            Modifier
                .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 6.dp, bottomEnd = 18.dp))
                .background(Brush.linearGradient(listOf(Color(0xE61A1B24), Color(0xE6222330))))
                .border(0.5.dp, Color(0x18FFFFFF), RoundedCornerShape(18.dp))
                .padding(horizontal = 16.dp, vertical = 11.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val t = rememberInfiniteTransition(label = "typing")
            repeat(3) { i ->
                val a by t.animateFloat(
                    initialValue = 0.25f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(500, delayMillis = i * 160),
                        repeatMode = RepeatMode.Reverse,
                    ),
                    label = "dot$i",
                )
                Box(
                    Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(Tx.Muted.copy(alpha = a)),
                )
            }
        }
    }
}

@Composable
internal fun BottomChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Color(0xCC12121A))
            .border(0.5.dp, Color(0x22FFFFFF), RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Color(0xFF8BE0FF), modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
internal fun EmpireMessageCard(body: String, mine: Boolean) {
    val preview = ChatEmpireProtocol.preview(body) ?: body
    val accent = when {
        body.startsWith("TEXWAVE_SONG:") || body.startsWith("TEXWAVE_LISTEN:") -> Color(0xFF5CE1FF)
        body.startsWith("TEXWAVE_LETTER:") -> Tx.Accent
        body.startsWith("TEXWAVE_CREW:") || body.startsWith("TEXWAVE_RECAP:") -> Color(0xFFFF9F6B)
        body.startsWith("TEXWAVE_VOTE:") -> Color(0xFF7CFFB2)
        else -> Color(0xFFA78BFA)
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = if (mine) 0.18f else 0.35f))
            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
            .padding(12.dp),
    ) {
        Text("TEXWAVE", color = accent.copy(alpha = 0.8f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(preview, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        when {
            body.startsWith("TEXWAVE_LETTER:") -> {
                Spacer(Modifier.height(6.dp))
                Text(ChatEmpireProtocol.parseLetter(body)?.body ?: "", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
            body.startsWith("TEXWAVE_VOTE:") -> {
                val v = ChatEmpireProtocol.parseVote(body)
                v?.options?.forEach { opt ->
                    Text("· $opt", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
            body.startsWith("TEXWAVE_CAPSULE:") -> {
                val c = ChatEmpireProtocol.parseCapsule(body)
                if (c != null) {
                    val open = c.opensAt <= System.currentTimeMillis()
                    Text(if (open) c.note else "Sealed until ${java.text.SimpleDateFormat("d MMM", java.util.Locale.getDefault()).format(java.util.Date(c.opensAt))}",
                        color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}



@Composable
internal fun InstaMediaViewer(
    path: String?,
    bytesProvider: suspend () -> ByteArray?,
    title: String,
    isAudio: Boolean,
    onDismiss: () -> Unit,
    onDownloaded: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xF0000000))
                .clickable(onClick = onDismiss),
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(top = 40.dp, bottom = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = onDismiss) { Text("Close", color = Color.White) }
                    Text(title.take(28), color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                    TextButton(
                        onClick = {
                            scope.launch {
                                loading = true
                                err = null
                                try {
                                    val bytes = bytesProvider()
                                    if (bytes == null) {
                                        err = "Download failed"
                                        return@launch
                                    }
                                    val name = title.ifBlank { "texwave_${System.currentTimeMillis()}" }
                                    val dir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS)
                                        ?: context.cacheDir
                                    val out = java.io.File(dir, name)
                                    out.writeBytes(bytes)
                                    onDownloaded(out.absolutePath)
                                    // Also publish to public Downloads when possible
                                    runCatching {
                                        val resolver = context.contentResolver
                                        val values = android.content.ContentValues().apply {
                                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, if (isAudio) "audio/*" else "image/*")
                                            if (android.os.Build.VERSION.SDK_INT >= 29) {
                                                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/TEXWAVE")
                                            }
                                        }
                                        val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                                        if (uri != null) resolver.openOutputStream(uri)?.use { it.write(bytes) }
                                    }
                                    Toast.makeText(context, "Saved · $name", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    err = e.message
                                    Toast.makeText(context, e.message ?: "Save failed", Toast.LENGTH_SHORT).show()
                                } finally {
                                    loading = false
                                }
                            }
                        },
                    ) { Text(if (loading) "Saving…" else "Download", color = Color(0xFF5CE1FF), fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.weight(1f))
                if (!isAudio && path != null) {
                    coil.compose.AsyncImage(
                        model = path,
                        contentDescription = title,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(6f)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(16.dp)),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    )
                } else {
                    Text(
                        if (isAudio) "Voice note ready — use Download to keep it" else "Loading…",
                        color = Color.White,
                        fontSize = 15.sp,
                    )
                }
                Spacer(Modifier.weight(1f))
                err?.let { Text(it, color = Color(0xFFFF6B8A), fontSize = 12.sp) }
            }
        }
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun PremiumBubble(msg: ChatMessageUi, repo: ChatRepository, seen: Boolean, delivered: Boolean = false, onRetry: () -> Unit, conversationId: String, title: String, onPlayResonance: (String, String, String?) -> Unit, onQuickSend: (String) -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val mine = msg.isMine
    val time = formatTime(msg.message.createdAt)

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        Column(
            horizontalAlignment = if (mine) Alignment.End else Alignment.Start,
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            fun copyMessageText() {
                val body = msg.message.body
                val text = when {
                    body.isNullOrBlank() -> {
                        Toast.makeText(context, "Nothing to copy", Toast.LENGTH_SHORT).show()
                        return
                    }
                    Resonance.isResonance(body) -> Resonance.parse(body)?.preview() ?: body
                    ChatThemeStore.parse(body) != null -> "Chat theme update"
                    SilentSignalStore.parse(body) != null -> SilentSignalStore.label(body) ?: body
                    body.startsWith("TEXWAVE_DROP") -> WaveDropStore.parseSolver(body, "", "")?.answer
                        ?: body.substringAfter("|").substringAfter("|").ifBlank { body }
                    body.startsWith("TEXWAVE_") -> body.substringAfter(":").take(500)
                    else -> body
                }
                val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("message", text))
                Toast.makeText(context, "Message copied", Toast.LENGTH_SHORT).show()
            }
            Column(
                Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 20.dp,
                            topEnd = 20.dp,
                            bottomStart = if (mine) 20.dp else 6.dp,
                            bottomEnd = if (mine) 6.dp else 20.dp,
                        )
                    )
                    .then(
                        if (mine) Modifier.background(
                            // Signature TEXWAVE send — violet → cyan, not IG blue
                            Brush.linearGradient(listOf(Color(0xFF6C4DFF), Color(0xFF5B8CFF), Color(0xFF3DD0FF)))
                        )
                        else Modifier.background(
                            // Soft glass receive
                            Brush.linearGradient(listOf(Color(0xE61A1B24), Color(0xE6222330), Color(0xE6161720)))
                        )
                    )
                    .border(
                        0.5.dp,
                        if (mine) Color(0x33FFFFFF) else Color(0x14FFFFFF),
                        RoundedCornerShape(20.dp),
                    )
                    .padding(horizontal = 14.dp, vertical = 9.dp),
            ) {
                val resonance = Resonance.parse(msg.message.body)
                if (resonance != null) {
                    ResonanceCard(
                        payload = resonance,
                        mine = mine,
                        onPlay = { onPlayResonance(resonance.title, resonance.artist, resonance.storagePath) },
                        onSaveCapsule = {
                            MemoryCapsuleStore.add(
                                context, conversationId,
                                title = "♪ ${resonance.title}",
                                body = resonance.preview(),
                                opensInDays = 0,
                                friendName = title,
                            )
                            Toast.makeText(context, "Saved to Memory Capsule", Toast.LENGTH_SHORT).show()
                        },
                    )
                } else if (ChatThemeStore.parse(msg.message.body) != null) {
                    Text(
                        "🎨 Updated chat theme",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    )
                } else if (SilentSignalStore.parse(msg.message.body) != null) {
                    Text(
                        SilentSignalStore.label(msg.message.body) ?: "Signal",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                    )
                } else if (ChatEmpireProtocol.preview(msg.message.body) != null) {
                    EmpireMessageCard(body = msg.message.body.orEmpty(), mine = msg.isMine)
                } else if (CallSignal.parse(msg.message.body) != null) {
                    val c = CallSignal.parse(msg.message.body)!!
                    Text(
                        when (c.action) {
                            CallSignal.Action.INVITE -> if (c.video) "📹 Video call" else "📞 Voice call"
                            CallSignal.Action.END -> "Call ended"
                            else -> "Call"
                        },
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                    )
                } else if (LivingGroupProtocol.parsePoll(msg.message.body) != null) {
                    val poll = LivingGroupProtocol.parsePoll(msg.message.body)!!
                    Column {
                        Text("📊 ${poll.question}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(Modifier.height(6.dp))
                        poll.options.forEachIndexed { idx, opt ->
                            Text(
                                "  ${idx + 1}. $opt",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 13.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onQuickSend(LivingGroupProtocol.encodeVote(poll.question, idx))
                                    }
                                    .padding(vertical = 3.dp),
                            )
                        }
                        Text("Tap an option to vote", color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
                    }
                } else if (WavePresenceStore.parse(msg.message.body) != null) {
                    val p = WavePresenceStore.parse(msg.message.body)!!
                    Text("${p.emoji} ${p.label}" + if (p.detail.isNotBlank()) " · ${p.detail}" else "",
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                } else if (msg.message.body?.startsWith("TEXWAVE_DROP:") == true) {
                    Text("🌊 Wave Drop · ${msg.message.body!!.removePrefix("TEXWAVE_DROP:").replace("|", " — ")}",
                        color = Color.White, fontSize = 13.sp)
                } else if (ResonanceReply.parse(msg.message.body) != null) {
                    Text(ResonanceReply.label(msg.message.body) ?: "Reaction",
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                } else if (LivingGroupProtocol.parseListen(msg.message.body) != null) {
                    val (t, a) = LivingGroupProtocol.parseListen(msg.message.body)!!
                    Text("🎧 Listening together · $t" + if (a.isNotBlank()) " — $a" else "",
                        color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                } else if (msg.message.body?.startsWith("TEXWAVE_VOTE:") == true) {
                    val v = msg.message.body!!.removePrefix("TEXWAVE_VOTE:").substringBefore("|")
                    Text("✓ Voted option ${(v.toIntOrNull() ?: 0) + 1}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                } else if (msg.message.body?.startsWith("TEXWAVE_CHALLENGE:") == true) {
                    Text("🏆 Challenge · ${msg.message.body!!.removePrefix("TEXWAVE_CHALLENGE:")}",
                        color = Color.White, fontSize = 13.sp)
                } else {
                    msg.message.body?.let {
                        Text(it, color = Color.White, fontSize = 15.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp)
                    }
                }
                msg.attachments.forEach { att ->
                    val isImage = att.mimeType.startsWith("image/")
                    val isAudio = att.mimeType.startsWith("audio/") ||
                        att.originalName.endsWith(".m4a", true) ||
                        att.originalName.endsWith(".aac", true) ||
                        att.originalName.endsWith(".mp3", true)
                    var localPath by remember(att.id) { mutableStateOf<String?>(null) }
                    var playing by remember(att.id) { mutableStateOf(false) }
                    var player by remember(att.id) { mutableStateOf<android.media.MediaPlayer?>(null) }
                    var showViewer by remember(att.id) { mutableStateOf(false) }
                    var voiceOpened by remember(att.id) {
                        mutableStateOf(
                            context.getSharedPreferences("texwave_voice_once", 0)
                                .getBoolean("opened_${att.id}", false)
                        )
                    }
                    LaunchedEffect(att.id) {
                        // Always try to fetch so download/play works offline after first open
                        repo.downloadAttachment(att).onSuccess { bytes ->
                            val out = File(context.cacheDir, "att_${att.id}_${att.originalName.ifBlank { "file" }}")
                            out.writeBytes(bytes)
                            localPath = out.absolutePath
                        }
                    }
                    
                    if (showViewer) {
                        InstaMediaViewer(
                            path = localPath,
                            bytesProvider = {
                                val existing = localPath?.let { File(it) }?.takeIf { it.exists() }
                                if (existing != null) existing.readBytes()
                                else repo.downloadAttachment(att).getOrNull()
                            },
                            title = att.originalName.ifBlank { if (isAudio) "voice.m4a" else "photo.jpg" },
                            isAudio = isAudio,
                            onDismiss = { showViewer = false },
                            onDownloaded = { p -> localPath = p },
                        )
                    }
                    DisposableEffect(att.id) {
                        onDispose {
                            try { player?.release() } catch (_: Exception) {}
                            player = null
                        }
                    }
                    Column(
                        Modifier
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.22f))
                            .clickable {
                                scope.launch {
                                    val existing = localPath?.let { File(it) }?.takeIf { it.exists() }
                                    val bytes = if (existing != null) existing.readBytes()
                                    else {
                                        Toast.makeText(context, "Downloading…", Toast.LENGTH_SHORT).show()
                                        repo.downloadAttachment(att).getOrElse {
                                            Toast.makeText(context, it.message ?: "Download failed", Toast.LENGTH_SHORT).show()
                                            return@launch
                                        }
                                    }
                                    val safeName = att.originalName.ifBlank { "texwave_${att.id}" }
                                    val out = File(context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS) ?: context.cacheDir, safeName)
                                    out.parentFile?.mkdirs()
                                    out.writeBytes(bytes)
                                    localPath = out.absolutePath
                                    // MediaStore-friendly share URI via FileProvider
                                    val uri = androidx.core.content.FileProvider.getUriForFile(
                                        context, "${context.packageName}.fileprovider", out,
                                    )
                                    Toast.makeText(context, "Downloaded · ${out.name}", Toast.LENGTH_SHORT).show()
                                    // Full system share sheet (any app)
                                    val mime = att.mimeType.ifBlank {
                                        when {
                                            isImage -> "image/*"
                                            isAudio -> "audio/*"
                                            safeName.endsWith(".mp4") || safeName.endsWith(".mkv") -> "video/mp4"
                                            else -> "*/*"
                                        }
                                    }
                                    val share = Intent(Intent.ACTION_SEND).apply {
                                        type = mime
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    val view = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, mime)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    val chooser = Intent.createChooser(share, "Share or open").apply {
                                        putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(view))
                                    }
                                    try {
                                        context.startActivity(chooser)
                                    } catch (_: Exception) {
                                        try { context.startActivity(Intent.createChooser(view, "Open with")) }
                                        catch (_: Exception) {
                                            Toast.makeText(context, "Saved to ${out.absolutePath}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            }
                            .padding(10.dp),
                    ) {
                        if (isImage) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 160.dp, max = 280.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0xFF0A0C14))
                                    .clickable { showViewer = true },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (localPath != null) {
                                    AsyncImage(
                                        model = File(localPath!!),
                                        contentDescription = att.originalName,
                                        modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
                                        contentScale = ContentScale.Crop,
                                    )
                                } else {
                                    // Instagram-style loading skeleton while bytes download
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        CircularProgressIndicator(
                                            Modifier.size(28.dp),
                                            color = Tx.Accent2,
                                            strokeWidth = 2.dp,
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        Text("Loading photo…", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isAudio) {
                                Icon(
                                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    null,
                                    tint = Color.White,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clickable {
                                            val path = localPath
                                            if (path == null) {
                                                Toast.makeText(context, "Loading voice…", Toast.LENGTH_SHORT).show()
                                                return@clickable
                                            }
                                            if (!mine) {
                                                context.getSharedPreferences("texwave_voice_once", 0)
                                                    .edit().putBoolean("opened_${att.id}", true).apply()
                                                voiceOpened = true
                                            }
                                            try {
                                                if (playing) {
                                                    player?.pause()
                                                    playing = false
                                                } else {
                                                    if (player == null) {
                                                        val mp = android.media.MediaPlayer().apply {
                                                            setDataSource(path)
                                                            prepare()
                                                            setOnCompletionListener {
                                                                playing = false
                                                            }
                                                        }
                                                        player = mp
                                                    }
                                                    player?.start()
                                                    playing = true
                                                }
                                            } catch (e: Exception) {
                                                Toast.makeText(context, e.message ?: "Cannot play", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                )
                                Spacer(Modifier.width(10.dp))
                            } else {
                                Icon(
                                    when {
                                        isImage -> Icons.Rounded.Image
                                        else -> Icons.Rounded.InsertDriveFile
                                    },
                                    null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp),
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            if (!isImage) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (isAudio) "Voice note" else att.originalName,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                )
                                Text(
                                    if (isAudio) (if (playing) "Playing…" else "Tap play to listen")
                                    else formatSize(att.sizeBytes),
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                )
                            }
                            } else {
                                Spacer(Modifier.weight(1f))
                            }
                            Icon(
                                Icons.Rounded.Download,
                                null,
                                tint = Color.White.copy(alpha = 0.85f),
                                modifier = Modifier
                                    .size(18.dp)
                                    .clickable {
                                        scope.launch {
                                            val path = localPath
                                            val bytes = if (path != null && File(path).exists()) File(path).readBytes()
                                            else repo.downloadAttachment(att).getOrElse {
                                                Toast.makeText(context, it.message ?: "Download failed", Toast.LENGTH_SHORT).show()
                                                return@launch
                                            }
                                            val saved = saveToDownloads(context, att.originalName.ifBlank { "texwave_file" }, bytes, att.mimeType)
                                            Toast.makeText(
                                                context,
                                                if (saved != null) "Downloaded to $saved" else "Saved in app storage",
                                                Toast.LENGTH_LONG,
                                            ).show()
                                        }
                                    },
                            )
                        }
                    }
                }
            }
            // Last line under bubble: time · ticks · Copy
            Row(
                Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                when {
                    msg.isFailed -> Text(
                        "!",
                        color = Color(0xFFFF6B6B),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable(onClick = onRetry),
                    )
                    msg.isPending -> {
                        Icon(
                            Icons.Rounded.AccessTime,
                            null,
                            tint = Color(0xFF8696A0),
                            modifier = Modifier.size(14.dp),
                        )
                    }
                    else -> {
                        if (time.isNotEmpty()) Text(time, color = Color(0xFF8696A0), fontSize = 10.sp)
                        if (mine) {
                            Spacer(Modifier.width(3.dp))
                            val tickColor = if (seen) Color(0xFF53BDEB) else Color(0xFF8696A0)
                            Box(Modifier.size(width = 18.dp, height = 12.dp)) {
                                if (seen || delivered) {
                                    Icon(
                                        Icons.Rounded.Done,
                                        null,
                                        tint = tickColor.copy(alpha = 0.55f),
                                        modifier = Modifier.size(14.dp).align(Alignment.CenterStart),
                                    )
                                    Icon(
                                        Icons.Rounded.Done,
                                        null,
                                        tint = tickColor,
                                        modifier = Modifier.size(14.dp).align(Alignment.CenterEnd),
                                    )
                                } else {
                                    Icon(
                                        Icons.Rounded.Done,
                                        null,
                                        tint = tickColor,
                                        modifier = Modifier.size(14.dp).align(Alignment.CenterEnd),
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    "Copy",
                    color = Color(0xFF8696A0),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { copyMessageText() }
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
    }
}

internal fun formatTime(iso: String?): String {
    val ms = parseIsoMillis(iso)
    if (ms <= 0L) return ""
    return SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date(ms))
}

internal fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> String.format("%.1f MB", bytes / (1024.0 * 1024))
}


private fun saveToDownloads(context: android.content.Context, name: String, bytes: ByteArray, mime: String): String? {
    return try {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
                put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null
            context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            values.clear()
            values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
            name
        } else {
            val dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val out = java.io.File(dir, name)
            out.writeBytes(bytes)
            out.absolutePath
        }
    } catch (_: Exception) {
        val out = java.io.File(context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), name)
        out.parentFile?.mkdirs()
        out.writeBytes(bytes)
        out.absolutePath
    }
}
