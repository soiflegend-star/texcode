package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.theme.Tx

@Composable
fun MiniPlayer(
    state: PlayerState,
    position: State<Long>,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
    artOverride: String? = null,
) {
    val song = state.current ?: return
    val scale by animateFloatAsState(
        if (state.isPlaying) 1f else 0.96f,
        spring(dampingRatio = 0.7f),
        label = "miniScale",
    )

    Column(
        modifier
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .fillMaxWidth()
            .shadow(18.dp, RoundedCornerShape(22.dp), ambientColor = Tx.Accent.copy(alpha = 0.3f))
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0x66FFFFFF), Color(0x22FFFFFF), Color(0xF2140D28), Color(0xF2080512))
                )
            )
            .background(Color(0xDD0A0618))
            .border(
                1.dp,
                Brush.horizontalGradient(
                    listOf(
                        Color(0x77FFFFFF),
                        Tx.Accent.copy(alpha = 0.55f),
                        Color(0x33FFFFFF),
                        Tx.Accent2.copy(alpha = 0.5f),
                    )
                ),
                RoundedCornerShape(22.dp),
            )
            .clickable(onClick = onOpen)
    ) {
        Row(
            Modifier.padding(start = 10.dp, end = 4.dp, top = 10.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.graphicsLayer { scaleX = scale; scaleY = scale }) {
                Artwork(song, Modifier.size(50.dp), corner = 14.dp, artOverride = artOverride)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title, color = Tx.Text, style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    song.artist, color = Tx.Muted, style = MaterialTheme.typography.bodySmall,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Tx.Brand)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (state.isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp),
                )
            }
            IconButton(onClick = onNext) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = Tx.Text, modifier = Modifier.size(26.dp))
            }
        }
        val barColor = Tx.Accent2
        Box(
            Modifier
                .fillMaxWidth()
                .height(3.dp)
                .drawBehind {
                    val d = state.durationMs
                    if (d > 0) {
                        val f = (position.value.toFloat() / d).coerceIn(0f, 1f)
                        drawRect(barColor, size = androidx.compose.ui.geometry.Size(size.width * f, size.height))
                    }
                }
        )
    }
}
