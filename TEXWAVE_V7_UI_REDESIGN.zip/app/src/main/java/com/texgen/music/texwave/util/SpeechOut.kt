package com.texgen.music.texwave.util

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/** Clear, natural PHANTOM voice replies. */
class SpeechOut(
    context: Context,
    /** USAGE_ALARM so alarm speech still plays under DND / silent. */
    private val audioUsage: Int = AudioAttributes.USAGE_ASSISTANCE_SONIFICATION,
) : TextToSpeech.OnInitListener {
    private val app = context.applicationContext
    private var tts: TextToSpeech? = TextToSpeech(app, this)
    private var ready = false
    private var pendingText: String? = null

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) return
        val engine = tts ?: return
        engine.language = Locale.US
        try {
            val best = engine.voices
                ?.filter { v ->
                    v.locale.language == "en" &&
                        !v.isNetworkConnectionRequired &&
                        v.quality >= Voice.QUALITY_NORMAL
                }
                ?.sortedByDescending { it.quality }
                ?.firstOrNull()
            if (best != null) engine.voice = best
        } catch (_: Exception) {
        }
        engine.setSpeechRate(0.96f)
        engine.setPitch(1.02f)
        try {
            engine.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(audioUsage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
        } catch (_: Exception) {
        }
        pendingText?.let { p ->
            pendingText = null
            speak(p)
        }
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            pendingText = text
            android.os.Handler(app.mainLooper).postDelayed({
                val p = pendingText
                if (ready && p != null) {
                    pendingText = null
                    speak(p)
                }
            }, 800)
            return
        }
        val clean = text
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("[*_#>`\\[\\]]"), "")
            .replace(Regex("https?://\\S+"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(900)
        if (clean.isBlank()) return
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "phantom_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
