package com.texgen.music.texwave.data

/**
 * Full offline understanding layer — no network, no LLM.
 * Parses natural phrases into music actions and short spoken replies.
 */
object OfflineAssistant {

    sealed class Action {
        data class PlayQuery(val query: String) : Action()
        data class PlayEmotion(val mode: EmotionMode) : Action()
        data object InfiniteMix : Action()
        data object Pause : Action()
        data object Resume : Action()
        data object Next : Action()
        data object Previous : Action()
        data object WhatsPlaying : Action()
        data object Help : Action()
        data class SmallTalk(val reply: String) : Action()
        data object Unknown : Action()
    }

    fun parse(raw: String): Action {
        val t = raw.trim().lowercase()
            .replace(Regex("[?!.,]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (t.isBlank()) return Action.Unknown

        // Control
        when {
            t in listOf("pause", "stop", "halt") || t.startsWith("pause ") || t == "stop music" ->
                return Action.Pause
            t in listOf("resume", "continue", "unpause") || t == "play" || t == "play music" ->
                return Action.Resume
            t in listOf("next", "skip", "next song", "skip song") || t.startsWith("next ") ->
                return Action.Next
            t in listOf("previous", "back", "last song", "previous song") || t.startsWith("previous ") ->
                return Action.Previous
            t.contains("what") && t.contains("playing") -> return Action.WhatsPlaying
            t.contains("now playing") -> return Action.WhatsPlaying
            t in listOf("help", "what can you do", "commands", "how do you work") ->
                return Action.Help
        }

        // Small talk (offline)
        when {
            t.matches(Regex(".*(hello|hi|hey|good morning|good evening|good night).*")) ->
                return Action.SmallTalk("Hey. I'm PHANTOM offline — I can play songs from your library, moods, and mixes without internet.")
            t.matches(Regex(".*(thank you|thanks|thx).*")) ->
                return Action.SmallTalk("You're welcome.")
            t.matches(Regex(".*(who are you|what are you).*")) ->
                return Action.SmallTalk("I'm PHANTOM, your offline music assistant inside TEXWAVE. Say “play” plus a song name.")
        }

        // Infinite mix
        if (t.contains("infinite") && t.contains("mix")) return Action.InfiniteMix
        if (t.contains("smart mix") || t.contains("surprise me")) return Action.InfiniteMix

        // Emotions / moods
        val moods = listOf(
            listOf("rainy night", "rainy", "rain", "drizzle", "storm", "mellow", "cozy rain") to EmotionMode.RAINY_NIGHT,
            listOf("unstoppable", "hype", "energy", "energetic", "workout", "gym", "motivation", "pump up") to EmotionMode.UNSTOPPABLE,
            listOf("lost in space", "space", "dreamy", "cosmic", "ambient", "weightless") to EmotionMode.LOST_IN_SPACE,
            listOf("let me think", "think", "reflective", "calm", "chill", "after hours", "reflect") to EmotionMode.LET_ME_THINK,
            listOf("final boss", "boss", "intense", "epic", "battle", "rage") to EmotionMode.FINAL_BOSS,
            listOf("deep focus", "focus", "study", "studying", "concentrate", "deep work", "coding") to EmotionMode.FOCUS,
            listOf("night drive", "long drive", "drive", "cruise", "highway", "road trip") to EmotionMode.NIGHT_DRIVE,
        )
        val explicitMood = t.contains("mood") || t.contains("emotion") || t.contains("vibe") ||
            t.contains("feeling") || t.endsWith(" mode") || t.contains("session")
        val playish = t.startsWith("play ") || t.startsWith("put on ") || t.startsWith("start ")
        // Exact mood phrase (e.g. "play rainy night", "rainy") — not "play Rain On Me"
        for ((keys, mode) in moods) {
            val hit = keys.firstOrNull { key ->
                t == key || t == "play $key" || t == "put on $key" || t == "start $key" ||
                    t == "play $key music" || t == "play some $key" ||
                    (explicitMood && key in t)
            }
            if (hit != null) return Action.PlayEmotion(mode)
        }
        // Soft mood only when the remaining query after "play " is purely a mood keyword
        if (playish) {
            val rest = t.removePrefix("play ").removePrefix("put on ").removePrefix("start ").trim()
            for ((keys, mode) in moods) {
                if (keys.any { it == rest || rest == "$it music" || rest == "some $it" }) {
                    return Action.PlayEmotion(mode)
                }
            }
        }

        // Song query extraction
        val prefixes = listOf(
            "play the song ", "play song ", "play the track ", "play track ",
            "play ", "put on ", "listen to ", "queue ", "start ",
            "find song ", "find the song ", "find ",
            "search for song ", "search for ", "search ",
            "can you play ", "please play ", "i want to hear ", "i want ",
            "do you have ", "is there ", "got ",
        )
        for (p in prefixes) {
            if (t.startsWith(p)) {
                var q = t.removePrefix(p).trim()
                q = q.removeSuffix(" please").removeSuffix(" now").removeSuffix(" for me").trim()
                // strip mood-only leftovers
                if (q in listOf("music", "something", "anything", "a song", "songs")) {
                    return Action.Help
                }
                // if query is purely a known mood keyword, emotion already handled above
                if (q.length >= 2) return Action.PlayQuery(q)
            }
        }

        // Bare title attempt: if user just says a multi-word phrase without "play"
        if (t.split(" ").size in 2..6 && !t.contains("http") && t.length in 4..48) {
            // Treat as possible song name when not a question
            if (!t.startsWith("what") && !t.startsWith("who") && !t.startsWith("why") &&
                !t.startsWith("how") && !t.startsWith("when") && !t.contains("?")) {
                return Action.PlayQuery(t)
            }
        }

        return Action.Unknown
    }

    fun helpText(): String = buildString {
        appendLine("Offline PHANTOM commands:")
        appendLine("• Play <song name>")
        appendLine("• Play rainy night / focus / night drive / …")
        appendLine("• Infinite mix")
        appendLine("• Pause · Next · Previous · What's playing?")
        appendLine()
        appendLine("No internet needed for these. Online mode adds web answers & Groq chat.")
    }
}
