package com.texgen.music.texwave.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.sin

/**
 * One solid small dot per flake — slight opacity only, no soft multi-glow stacks.
 */
@Composable
fun ParticleField(
    active: Boolean,
    modifier: Modifier = Modifier,
    count: Int = 48,
    energy: State<Float>? = null,
) {
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.033f)
            time.floatValue += dt
            last = now
        }
    }
    val seeds = remember(count) {
        FloatArray(count * 4) { i ->
            var x = i * 374761393 + 668265263
            x = (x xor (x ushr 13)) * 1274126177
            x = x xor (x ushr 16)
            (x and 0xFFFFFF) / 16777215f
        }
    }
    Canvas(modifier) {
        if (!active) return@Canvas
        val t = time.floatValue
        val boost = 1f + (energy?.value ?: 0f) * 0.2f
        val w = size.width
        val h = size.height
        for (i in 0 until count) {
            val x0 = seeds[i * 4]
            val speedSeed = seeds[i * 4 + 1]
            val phase = seeds[i * 4 + 2]
            val sizeSeed = seeds[i * 4 + 3]
            val speed = (0.014f + 0.03f * speedSeed) * boost
            val y = ((phase + t * speed) % 1f)
            val sway = 0.02f * sin(t * 0.4f + i * 0.7f)
            val x = ((x0 + sway) % 1f + 1f) % 1f
            // Single concrete dot — only mild alpha, no outer glow rings
            val r = (1.2f + 1.4f * sizeSeed) * density
            val alpha = 0.55f + 0.35f * sizeSeed
            drawCircle(
                Color.White.copy(alpha = alpha),
                radius = r,
                center = Offset(x * w, y * h),
            )
        }
    }
}
