package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay

/**
 * Full-screen RGB energy sweep when Phantom wakes.
 * Shows briefly then calls [onFinished].
 */
@Composable
fun PhantomWakeOverlay(
    active: Boolean,
    onFinished: () -> Unit,
) {
    if (!active) return
    val t by rememberInfiniteTransition(label = "rgb").animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep",
    )
    LaunchedEffect(active) {
        if (active) {
            delay(1600)
            onFinished()
        }
    }
    val shift = t * 360f
    fun hue(h: Float): Color {
        val x = ((h % 360f) + 360f) % 360f
        return when {
            x < 60 -> Color(1f, x / 60f, 0f, 0.35f)
            x < 120 -> Color(1f - (x - 60f) / 60f, 1f, 0f, 0.35f)
            x < 180 -> Color(0f, 1f, (x - 120f) / 60f, 0.35f)
            x < 240 -> Color(0f, 1f - (x - 180f) / 60f, 1f, 0.35f)
            x < 300 -> Color((x - 240f) / 60f, 0f, 1f, 0.35f)
            else -> Color(1f, 0f, 1f - (x - 300f) / 60f, 0.35f)
        }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(
                        hue(shift),
                        hue(shift + 120f),
                        hue(shift + 240f),
                        hue(shift + 360f),
                    ),
                ),
            ),
    )
}
