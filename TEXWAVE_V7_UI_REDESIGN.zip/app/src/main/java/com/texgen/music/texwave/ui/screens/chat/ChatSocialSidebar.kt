package com.texgen.music.texwave.ui.screens.chat

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Mood
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens
import com.texgen.music.texwave.ui.theme.Tx

/**
 * Destinations reachable from the Chat-only social sidebar.
 * Maps to existing app surfaces; Coming Soon items are labeled and non-navigating.
 */
enum class ChatSidebarDest {
    Home,
    Chats,
    Waves,
    Memes,
    Photos,
    Stories,
    Create,
    Discover,
    Music,
    InnerCircles,
}

data class SidebarItem(
    val dest: ChatSidebarDest,
    val label: String,
    val icon: ImageVector,
    val available: Boolean,
    val badge: Int = 0,
    val comingSoon: Boolean = false,
)

/**
 * Premium animated sidebar that appears **only inside Chat**.
 * Does not replace or modify the bottom circular navigation.
 */
@Composable
fun ChatSettingsSidebar(
    visible: Boolean,
    selected: ChatSidebarDest,
    unreadChats: Int = 0,
    onClose: () -> Unit,
    onSelect: (ChatSidebarDest) -> Unit,
) {
    if (visible) {
        BackHandler(onBack = onClose)
    }

    val items = remember(unreadChats) {
        listOf(
            SidebarItem(ChatSidebarDest.Chats, "Chats", Icons.Rounded.Chat, available = true, badge = unreadChats),
            SidebarItem(ChatSidebarDest.Home, "App Settings", Icons.Rounded.Home, available = true),
            SidebarItem(ChatSidebarDest.Discover, "Profile", Icons.Rounded.Explore, available = true),
            SidebarItem(ChatSidebarDest.Music, "Theme", Icons.Rounded.LibraryMusic, available = true),
            SidebarItem(ChatSidebarDest.Waves, "Notifications", Icons.Rounded.Videocam, available = true),
            SidebarItem(ChatSidebarDest.Create, "Phantom tools", Icons.Rounded.AddCircle, available = true),
            SidebarItem(ChatSidebarDest.Memes, "UI Sounds", Icons.Rounded.Mood, available = true),
        )
    }

    Box(Modifier.fillMaxSize()) {
        // Scrim
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(TexTokens.tweenNormal()),
            exit = fadeOut(TexTokens.tweenExit()),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onClose,
                    )
            )
        }

        // Panel from the left (chat list is right-heavy; left edge is free)
        AnimatedVisibility(
            visible = visible,
            enter = slideInHorizontally(TexTokens.tweenEnter()) { -it } + fadeIn(TexTokens.tweenNormal()),
            exit = slideOutHorizontally(TexTokens.tweenExit()) { -it } + fadeOut(TexTokens.tweenExit()),
            modifier = Modifier.align(Alignment.CenterStart),
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .width(300.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF0C1020), Color(0xFF070914), Color(0xFF0A0E1C))
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            listOf(
                                TexTokens.Cyan.copy(alpha = 0.35f),
                                TexTokens.Violet.copy(alpha = 0.25f),
                                Color.Transparent,
                            )
                        ),
                        shape = RoundedCornerShape(topEnd = 22.dp, bottomEnd = 22.dp),
                    )
                    .clip(RoundedCornerShape(topEnd = 22.dp, bottomEnd = 22.dp))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(bottom = 12.dp)
            ) {
                // Header
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "TEXWAVE",
                            color = TexTokens.Cyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            letterSpacing = 1.2.sp,
                        )
                        Text(
                            "Settings",
                            color = TexTokens.TextSecondary,
                            fontSize = 12.sp,
                        )
                    }
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0x22FFFFFF))
                            .clickable(onClick = onClose),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }

                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .padding(horizontal = 16.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, TexTokens.Violet.copy(0.5f), Color.Transparent)
                            )
                        )
                )

                Spacer(Modifier.height(10.dp))

                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    items.forEachIndexed { index, item ->
                        SidebarRow(
                            item = item,
                            selected = item.dest == selected,
                            onClick = {
                                if (item.comingSoon) {
                                    // Stay open; selection still highlights briefly via callback
                                    onSelect(item.dest)
                                } else {
                                    onSelect(item.dest)
                                }
                            },
                        )
                    }
                }

                Text(
                    "Settings for this chat session",
                    color = TexTokens.TextSecondary.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun SidebarRow(
    item: SidebarItem,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                if (selected) {
                    Brush.horizontalGradient(
                        listOf(TexTokens.Violet.copy(alpha = 0.28f), TexTokens.Cyan.copy(alpha = 0.12f))
                    )
                } else {
                    Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                }
            )
            .then(
                if (selected) {
                    Modifier.border(
                        1.dp,
                        Brush.horizontalGradient(
                            listOf(TexTokens.Violet.copy(0.7f), TexTokens.Cyan.copy(0.5f))
                        ),
                        shape,
                    )
                } else Modifier
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            item.icon,
            contentDescription = item.label,
            tint = when {
                selected -> TexTokens.Cyan
                item.comingSoon -> TexTokens.TextSecondary.copy(alpha = 0.55f)
                else -> TexTokens.TextPrimary
            },
            modifier = Modifier.size(22.dp),
        )
        Spacer(Modifier.width(14.dp))
        Text(
            item.label,
            color = when {
                selected -> TexTokens.TextPrimary
                item.comingSoon -> TexTokens.TextSecondary.copy(alpha = 0.7f)
                else -> TexTokens.TextPrimary
            },
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            fontSize = 15.sp,
            modifier = Modifier.weight(1f),
        )
        if (item.comingSoon) {
            Text(
                "Soon",
                color = TexTokens.Magenta.copy(alpha = 0.85f),
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
            )
        } else if (item.badge > 0) {
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(TexTokens.Magenta)
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            ) {
                Text(
                    if (item.badge > 99) "99+" else item.badge.toString(),
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        } else if (selected) {
            Box(
                Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(TexTokens.Cyan)
            )
        }
    }
}


/** Alias kept for older call sites. */
@Composable
fun ChatSocialSidebar(
    visible: Boolean,
    selected: ChatSidebarDest,
    unreadChats: Int = 0,
    onClose: () -> Unit,
    onSelect: (ChatSidebarDest) -> Unit,
) = ChatSettingsSidebar(
    visible = visible,
    selected = selected,
    unreadChats = unreadChats,
    onClose = onClose,
    onSelect = onSelect,
)
