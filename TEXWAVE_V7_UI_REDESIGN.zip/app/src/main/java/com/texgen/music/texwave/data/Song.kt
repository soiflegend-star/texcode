package com.texgen.music.texwave.data

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val dateAdded: Long,
    val contentUri: String,
    val path: String = "",
    val year: Int = 0,
    val trackNumber: Int = 0,
) {
    val artUri: String
        get() = "content://media/external/audio/albumart/$albumId"
}

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<Long>,
)

data class Album(
    val id: Long,
    val name: String,
    val artist: String,
    val songCount: Int,
    val songs: List<Song>,
)

data class ArtistGroup(
    val name: String,
    val songCount: Int,
    val albumCount: Int,
    val songs: List<Song>,
)
