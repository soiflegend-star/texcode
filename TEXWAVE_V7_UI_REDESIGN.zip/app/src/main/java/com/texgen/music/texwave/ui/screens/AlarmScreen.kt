package com.texgen.music.texwave.ui.screens

import com.texgen.music.texwave.ui.theme.Tx
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAlarm
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.AlarmEngine
import com.texgen.music.texwave.ui.theme.glassCard
import com.texgen.music.texwave.notification.TexwaveAlarmReceiver
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

private data class TexAlarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String,
    val daily: Boolean,
    val enabled: Boolean,
    val trigger: Long,
    val soundUri: String?,
)

@Composable
fun AlarmScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("texwave_alarms", Context.MODE_PRIVATE) }
    var alarms by remember { mutableStateOf(loadAlarms(prefs)) }
    var showLabel by remember { mutableStateOf(false) }
    var label by remember { mutableStateOf("") }
    var daily by remember { mutableStateOf(true) }
    var pendingSound by remember { mutableStateOf<String?>(prefs.getString("default_sound", null)) }
    var soundName by remember {
        mutableStateOf(prefs.getString("default_sound_name", "Default alarm sound") ?: "Default alarm sound")
    }

    val pickSound = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        } catch (_: Exception) {
            // some providers don't support persistable grants
        }
        pendingSound = uri.toString()
        soundName = uri.lastPathSegment ?: "Custom sound"
        prefs.edit()
            .putString("default_sound", pendingSound)
            .putString("default_sound_name", soundName)
            .apply()
        Toast.makeText(context, "Alarm sound set", Toast.LENGTH_SHORT).show()
    }

    fun persist(next: List<TexAlarm>) {
        alarms = next
        val arr = JSONArray()
        next.forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id)
                put("hour", a.hour)
                put("minute", a.minute)
                put("label", a.label)
                put("daily", a.daily)
                put("enabled", a.enabled)
                put("trigger", a.trigger)
                put("soundUri", a.soundUri ?: JSONObject.NULL)
            })
        }
        prefs.edit().putString("alarms", arr.toString()).apply()
    }

    fun schedule(a: TexAlarm) {
        AlarmEngine.schedule(
            context,
            id = a.id,
            hour = a.hour,
            minute = a.minute,
            label = a.label,
            soundUri = a.soundUri,
            triggerAt = a.trigger,
        )
    }

    fun addAlarm(hour: Int, minute: Int) {
        val at = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val nextId = (alarms.maxOfOrNull { it.id } ?: 1000) + 1
        val a = TexAlarm(
            nextId, hour, minute,
            label.ifBlank { "TEXWAVE Alarm" },
            daily, true, at.timeInMillis, pendingSound,
        )
        persist(alarms + a)
        schedule(a)
        showLabel = false
        label = ""
        Toast.makeText(
            context,
            "Alarm set for %02d:%02d".format(hour, minute),
            Toast.LENGTH_SHORT,
        ).show()
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF000000), Color(0xFF05060C))))
            .statusBarsPadding()
            .padding(16.dp),
    ) {
        Text("Alarms", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            "Bottom tab · Alarm  ·  set time and sound",
            color = Color(0xFF8B93B0),
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 10.dp),
        )

        // Primary action first so it is never buried
        Button(
            onClick = {
                val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    Toast.makeText(context, "Allow exact alarms in system settings", Toast.LENGTH_LONG).show()
                    runCatching {
                        context.startActivity(
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                }
                showLabel = true
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
        ) {
            Icon(Icons.Rounded.AddAlarm, null)
            Spacer(Modifier.width(8.dp))
            Text("Create alarm", fontSize = 16.sp)
        }

        Spacer(Modifier.height(12.dp))

        // Sound picker
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF0A0C16))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.MusicNote, null, tint = Tx.Accent2)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Alarm sound", color = Color.White, fontWeight = FontWeight.Medium)
                Text(soundName, color = Color(0xFF8B93B0), fontSize = 12.sp, maxLines = 1)
            }
            TextButton(onClick = { pickSound.launch("audio/*") }) {
                Text("Song", color = Tx.Accent2)
            }
            TextButton(onClick = {
                pendingSound = null
                soundName = "Default alarm sound"
                prefs.edit().remove("default_sound").putString("default_sound_name", soundName).apply()
            }) {
                Text("Default", color = Color(0xFF8B93B0))
            }
        }

        Spacer(Modifier.height(8.dp))
        var showBrief by remember { mutableStateOf(false) }
        TextButton(onClick = { showBrief = !showBrief }) {
            Text(if (showBrief) "Hide briefing options" else "Weather briefing options", color = Tx.Accent2)
        }
        if (showBrief) {
            var briefingCity by remember {
                mutableStateOf(prefs.getString("briefing_city", "Delhi") ?: "Delhi")
            }
            OutlinedTextField(
                value = briefingCity,
                onValueChange = {
                    briefingCity = it
                    prefs.edit().putString("briefing_city", it.trim()).apply()
                },
                label = { Text("City for weather") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            )
            listOf(
                "say_greeting" to "Greeting",
                "say_time" to "Time & day",
                "say_label" to "Alarm label",
                "say_weather" to "Weather",
                "say_battery" to "Battery",
            ).forEach { (key, label) ->
                var on by remember { mutableStateOf(prefs.getBoolean(key, true)) }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(
                        checked = on,
                        onCheckedChange = {
                            on = it
                            prefs.edit().putBoolean(key, it).apply()
                        },
                    )
                    Text(label, color = Color(0xFFC8CEE0), fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        if (alarms.isEmpty()) {
            Column(
                Modifier.fillMaxWidth().padding(top = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(Icons.Rounded.Alarm, null, tint = Color(0xFF56627E), modifier = Modifier.padding(8.dp))
                Text("No alarms yet", color = Color.White, fontSize = 18.sp)
                Text("Create one with your own sound", color = Color(0xFF8B93B0), fontSize = 13.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(alarms, key = { it.id }) { a ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0A0C16))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "%02d:%02d".format(a.hour, a.minute),
                                color = Color.White,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Light,
                            )
                            Text(
                                a.label + if (a.daily) " · Daily" else " · Once",
                                color = Color(0xFF8B93B0),
                                fontSize = 13.sp,
                            )
                            if (!a.soundUri.isNullOrBlank()) {
                                Text("Custom sound", color = Tx.Accent2, fontSize = 11.sp)
                            }
                        }
                        Switch(
                            checked = a.enabled,
                            onCheckedChange = { on ->
                                val updated = a.copy(enabled = on)
                                val next = alarms.map { if (it.id == a.id) updated else it }
                                persist(next)
                                if (on) schedule(updated) else {
                                    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                                    val pi = PendingIntent.getBroadcast(
                                        context, a.id,
                                        Intent(context, TexwaveAlarmReceiver::class.java),
                                        PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE,
                                    )
                                    AlarmEngine.cancel(context, a.id)
                                }
                            },
                        )
                        IconButton(onClick = {
                            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                            val pi = PendingIntent.getBroadcast(
                                context, a.id,
                                Intent(context, TexwaveAlarmReceiver::class.java),
                                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE,
                            )
                            AlarmEngine.cancel(context, a.id)
                            persist(alarms.filterNot { it.id == a.id })
                        }) {
                            Icon(Icons.Rounded.Delete, "Delete", tint = Color(0xFFFF6D9B))
                        }
                    }
                }
            }
        }
    }

    if (showLabel) {
        AlertDialog(
            onDismissRequest = { showLabel = false },
            title = { Text("New alarm") },
            text = {
                Column {
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it },
                        label = { Text("Label (optional)") },
                        singleLine = true,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = daily, onCheckedChange = { daily = it })
                        Text("Repeat daily")
                    }
                    Text(
                        "Sound: $soundName",
                        color = Color(0xFF8B93B0),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val now = Calendar.getInstance()
                    TimePickerDialog(
                        context,
                        { _, h, m -> addAlarm(h, m) },
                        now.get(Calendar.HOUR_OF_DAY),
                        now.get(Calendar.MINUTE),
                        true,
                    ).show()
                }) { Text("Choose time") }
            },
            dismissButton = { TextButton(onClick = { showLabel = false }) { Text("Cancel") } },
        )
    }
}

private fun loadAlarms(prefs: android.content.SharedPreferences): List<TexAlarm> = runCatching {
    val arr = JSONArray(prefs.getString("alarms", "[]"))
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        TexAlarm(
            o.getInt("id"),
            o.getInt("hour"),
            o.getInt("minute"),
            o.optString("label", "TEXWAVE Alarm"),
            o.optBoolean("daily"),
            o.optBoolean("enabled", true),
            o.optLong("trigger"),
            if (o.isNull("soundUri")) null else o.optString("soundUri", null),
        )
    }
}.getOrDefault(emptyList())
