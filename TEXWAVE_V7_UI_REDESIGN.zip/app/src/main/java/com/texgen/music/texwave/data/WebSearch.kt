package com.texgen.music.texwave.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Multi-source web lookup (no API key) to ground PHANTOM answers —
 * DuckDuckGo Instant Answer + Wikipedia search/summary.
 */
object WebSearch {

    data class Result(
        val query: String,
        val abstractText: String?,
        val abstractSource: String?,
        val related: List<String>,
        val rawSnippet: String,
    )

    suspend fun lookup(context: Context, query: String): Result = withContext(Dispatchers.IO) {
        if (!NetworkGate.isOnline(context)) {
            return@withContext Result(query, null, null, emptyList(), "Offline — cannot search.")
        }
        val q = query.trim().ifEmpty {
            return@withContext Result(query, null, null, emptyList(), "")
        }

        val ddg = duckDuckGo(q)
        var abstract = ddg.abstractText
        var source = ddg.abstractSource
        val related = ddg.related.toMutableList()

        // Wikipedia: try direct summary, then search for best title
        if (abstract.isNullOrBlank()) {
            wikipediaSummary(q)?.let {
                abstract = it
                source = "Wikipedia"
            }
        }
        if (abstract.isNullOrBlank()) {
            wikipediaSearch(q)?.let { title ->
                wikipediaSummary(title)?.let {
                    abstract = it
                    source = "Wikipedia ($title)"
                }
            }
        }

        val snippet = buildString {
            if (!abstract.isNullOrBlank()) {
                appendLine(abstract)
                if (!source.isNullOrBlank()) appendLine("(Source: $source)")
            }
            if (related.isNotEmpty()) {
                appendLine()
                appendLine("Related:")
                related.take(6).forEach { appendLine("• $it") }
            }
            if (isEmpty()) {
                append("No strong web hit. Answer carefully from general knowledge and note uncertainty.")
            }
        }
        Result(q, abstract, source, related.distinct(), snippet.trim())
    }

    private fun duckDuckGo(query: String): Result {
        return try {
            val url =
                "https://api.duckduckgo.com/?q=${URLEncoder.encode(query, "UTF-8")}&format=json&no_html=1&skip_disambig=1"
            val text = httpGet(url)
            val json = JSONObject(text)
            val abstract = json.optString("AbstractText").ifBlank { null }
            val source = json.optString("AbstractSource").ifBlank { null }
            val related = mutableListOf<String>()
            val topics = json.optJSONArray("RelatedTopics")
            if (topics != null) {
                for (i in 0 until minOf(topics.length(), 10)) {
                    val item = topics.optJSONObject(i) ?: continue
                    item.optString("Text").takeIf { it.isNotBlank() }?.let { related.add(it) }
                    val kids = item.optJSONArray("Topics")
                    if (kids != null) {
                        for (j in 0 until minOf(kids.length(), 3)) {
                            kids.optJSONObject(j)?.optString("Text")
                                ?.takeIf { it.isNotBlank() }
                                ?.let { related.add(it) }
                        }
                    }
                }
            }
            // Also Answer field
            val answer = json.optString("Answer").ifBlank { null }
            val abs = abstract ?: answer
            Result(query, abs, source ?: if (answer != null) "DuckDuckGo" else null, related.distinct(), "")
        } catch (_: Exception) {
            Result(query, null, null, emptyList(), "")
        }
    }

    private fun wikipediaSummary(titleOrQuery: String): String? {
        return try {
            val encoded = URLEncoder.encode(titleOrQuery.replace(' ', '_'), "UTF-8")
            val url = "https://en.wikipedia.org/api/rest_v1/page/summary/$encoded"
            val text = httpGet(url)
            val json = JSONObject(text)
            if (json.optString("type") == "disambiguation") return null
            json.optString("extract").ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }

    private fun wikipediaSearch(query: String): String? {
        return try {
            val url =
                "https://en.wikipedia.org/w/api.php?action=opensearch&search=${URLEncoder.encode(query, "UTF-8")}&limit=3&namespace=0&format=json"
            val text = httpGet(url)
            val arr = JSONArray(text)
            if (arr.length() < 2) return null
            val titles = arr.getJSONArray(1)
            if (titles.length() == 0) return null
            titles.getString(0)
        } catch (_: Exception) {
            null
        }
    }

    private fun httpGet(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("User-Agent", "TexwaveMusic/5.5 (Android; PHANTOM)")
            setRequestProperty("Accept", "application/json")
            connectTimeout = 12_000
            readTimeout = 16_000
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
    }
}
