package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.background
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.player.EqualizerController
import com.texgen.music.texwave.ui.theme.Tx

@Composable
fun EqualizerScreen(
    eq: EqualizerController,
    onBack: () -> Unit,
) {
    var enabled by remember { mutableStateOf(eq.isEnabled()) }
    var preset by remember { mutableIntStateOf(0) }
    val bandCount = eq.bandCount.coerceIn(3, 10)
    val range = eq.bandLevelRange
    val minL = range[0].toFloat()
    val maxL = range[1].toFloat()

    var levels by remember {
        mutableStateOf(List(bandCount) { eq.getBandLevel(it).toFloat() })
    }

    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, "Back", tint = Tx.Text)
            }
            Text(
                "Equalizer",
                color = Tx.Text,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f),
            )
            Switch(
                checked = enabled,
                onCheckedChange = {
                    enabled = it
                    eq.setEnabled(it)
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Tx.Accent2,
                    checkedTrackColor = Tx.Accent.copy(alpha = 0.5f),
                ),
            )
        }

        Text(
            "Presets",
            color = Tx.Muted,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            itemsIndexed(EqualizerController.PRESET_NAMES) { index, name ->
                FilterChip(
                    selected = preset == index,
                    onClick = {
                        preset = index
                        eq.applyPreset(index)
                        enabled = true
                        levels = List(bandCount) { eq.getBandLevel(it).toFloat() }
                    },
                    label = { Text(name) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Tx.Accent.copy(alpha = 0.35f),
                        selectedLabelColor = Tx.Text,
                        containerColor = Tx.Surface,
                        labelColor = Tx.Muted,
                    ),
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Tx.Surface)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            for (i in 0 until bandCount) {
                val freq = eq.getCenterFreq(i)
                val label = when {
                    freq >= 1000 -> "${freq / 1000}k"
                    else -> "$freq"
                }
                Column {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("$label Hz", color = Tx.Muted, style = MaterialTheme.typography.labelSmall)
                        Text(
                            "${(levels[i] / 100).toInt()} dB",
                            color = Tx.Text,
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                    Slider(
                        value = levels[i].coerceIn(minL, maxL),
                        onValueChange = { v ->
                            levels = levels.toMutableList().also { it[i] = v }
                            eq.setBandLevel(i, v.toInt())
                            if (!enabled) {
                                enabled = true
                                eq.setEnabled(true)
                            }
                        },
                        valueRange = minL..maxL,
                        colors = SliderDefaults.colors(
                            thumbColor = Tx.Accent2,
                            activeTrackColor = Tx.Accent,
                            inactiveTrackColor = Tx.Outline,
                        ),
                    )
                }
            }
        }

        Text(
            "Equalizer applies to the current playback session. Play a song first if bands don’t respond.",
            color = Tx.Muted,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(20.dp),
        )
    }
}
