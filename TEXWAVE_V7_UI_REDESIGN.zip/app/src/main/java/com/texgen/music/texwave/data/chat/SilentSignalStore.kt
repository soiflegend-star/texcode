package com.texgen.music.texwave.data.chat

import android.content.Context

/**
 * Silent Signal — temporary presence without forcing a conversation.
 * Encoded as TEXWAVE_SIGNAL:mode|expiresAt so it works over normal chat.
 */
object SilentSignalStore {
    enum class Mode(val label: String, val emoji: String) {
        LISTENING("Listening", "🎧"),
        FOCUS("Deep focus", "🎯"),
        OPEN("Open to talk", "💬"),
        AWAY("Away", "🌙"),
    }

    fun encode(mode: Mode, minutes: Int = 60): String {
        val exp = System.currentTimeMillis() + minutes * 60_000L
        return "TEXWAVE_SIGNAL:${mode.name}|$exp"
    }

    fun parse(body: String?): Pair<Mode, Long>? {
        if (body == null || !body.startsWith("TEXWAVE_SIGNAL:")) return null
        val parts = body.removePrefix("TEXWAVE_SIGNAL:").split("|")
        if (parts.size < 2) return null
        val mode = runCatching { Mode.valueOf(parts[0]) }.getOrNull() ?: return null
        val exp = parts[1].toLongOrNull() ?: return null
        if (exp < System.currentTimeMillis()) return null
        return mode to exp
    }

    fun label(body: String?): String? {
        val p = parse(body) ?: return null
        return "${p.first.emoji} ${p.first.label}"
    }
}
