package com.texgen.music.texwave.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Groq LLM client for PHANTOM online intelligence.
 * API key is stored only on-device in private prefs — never hardcoded.
 */
class GroqClient(context: Context) {
    private val prefs = context.getSharedPreferences("texwave_groq", Context.MODE_PRIVATE)
    private val appContext = context.applicationContext

    var apiKey: String
        get() = prefs.getString(KEY, "") ?: ""
        set(value) {
            val cleaned = value.trim().replace("\n", "").replace("\r", "").replace(" ", "")
            prefs.edit().putString(KEY, cleaned).commit()
        }

    fun hasKey(): Boolean = apiKey.isNotBlank()

    /** Models tried in order when the preferred one is rejected (renamed / retired / rate limited). */
    private fun modelChain(preferred: String): List<String> =
        (listOf(preferred) + FALLBACK_MODELS).distinct()

    private fun shouldFallback(e: Throwable?): Boolean {
        val m = e?.message?.lowercase() ?: return false
        return m.startsWith("groq 404") || m.startsWith("groq 429") || m.startsWith("groq 503") ||
            (m.startsWith("groq 400") && (m.contains("model") || m.contains("decommission"))) ||
            m.contains("model_not_found") || m.contains("does not exist")
    }

    /** Qwen-style reasoning models emit <think>…</think>; never show that to the user. */
    private fun clean(text: String): String =
        text.replace(Regex("(?s)<think>.*?</think>"), "").trim()

    suspend fun chat(
        system: String,
        user: String,
        model: String = DEFAULT_MODEL,
        temperature: Double = 0.4,
        maxTokens: Int = 1024,
    ): Result<String> {
        var last: Result<String> = Result.failure(IllegalStateException("No model available"))
        for (m in modelChain(model)) {
            last = chatOnce(system, user, m, temperature, maxTokens)
            if (last.isSuccess) return last.map(::clean)
            if (!shouldFallback(last.exceptionOrNull())) break
        }
        return last
    }

    /** Multi-turn chat. [messages] are (role, content) pairs with role user / assistant / system. */
    suspend fun chatMessages(
        messages: List<Pair<String, String>>,
        model: String = DEFAULT_MODEL,
        temperature: Double = 0.6,
        maxTokens: Int = 1600,
    ): Result<String> {
        var last: Result<String> = Result.failure(IllegalStateException("No model available"))
        for (m in modelChain(model)) {
            last = chatMessagesOnce(messages, m, temperature, maxTokens)
            if (last.isSuccess) return last.map(::clean)
            if (!shouldFallback(last.exceptionOrNull())) break
        }
        return last
    }

    private suspend fun chatOnce(
        system: String,
        user: String,
        model: String = DEFAULT_MODEL,
        temperature: Double = 0.4,
        maxTokens: Int = 1024,
    ): Result<String> = withContext(Dispatchers.IO) {
        val key = apiKey
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Groq API key not set"))
        if (!NetworkGate.isOnline(appContext)) {
            return@withContext Result.failure(IllegalStateException("Internet required for PHANTOM"))
        }
        try {
            val body = JSONObject()
                .put("model", model)
                .put("temperature", temperature)
                .put("max_tokens", maxTokens)
                .put(
                    "messages",
                    JSONArray()
                        .put(JSONObject().put("role", "system").put("content", system))
                        .put(JSONObject().put("role", "user").put("content", user)),
                )
            val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Authorization", "Bearer $key")
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 20_000
                readTimeout = 45_000
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
            if (code !in 200..299) {
                val detail = try {
                    JSONObject(text).optJSONObject("error")?.optString("message")?.take(280)
                } catch (_: Exception) { null }
                val msg = detail ?: text.take(200)
                return@withContext Result.failure(Exception("Groq $code: $msg"))
            }
            val json = JSONObject(text)
            val content = json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
            Result.success(content)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    
    /** Multi-turn chat. [history] is list of role to content ("user"/"assistant"/"system"). */
    private suspend fun chatMessagesOnce(
        messages: List<Pair<String, String>>,
        model: String = DEFAULT_MODEL,
        temperature: Double = 0.5,
        maxTokens: Int = 1600,
    ): Result<String> = withContext(Dispatchers.IO) {
        val key = apiKey
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Groq API key not set"))
        try {
            val arr = JSONArray()
            messages.forEach { (role, content) ->
                arr.put(JSONObject().put("role", role).put("content", content))
            }
            val body = JSONObject()
                .put("model", model)
                .put("temperature", temperature)
                .put("max_tokens", maxTokens)
                .put("messages", arr)
            val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Authorization", "Bearer $key")
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 20_000
                readTimeout = 60_000
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
            if (code !in 200..299) {
                val detail = try {
                    JSONObject(text).optJSONObject("error")?.optString("message")?.take(280)
                } catch (_: Exception) { null }
                val msg = detail ?: text.take(200)
                return@withContext Result.failure(Exception("Groq $code: $msg"))
            }
            val json = JSONObject(text)
            val content = json.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
            Result.success(content)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Rank / explain song picks for an emotion mode. */
    suspend fun emotionRank(
        modeLabel: String,
        candidates: List<Song>,
        limit: Int = 20,
    ): Result<List<Long>> {
        if (candidates.isEmpty()) return Result.success(emptyList())
        val catalog = candidates.take(80).joinToString("\n") {
            "${it.id}|${it.title}|${it.artist}|${it.durationMs / 1000}s"
        }
        val system = """You are TEXWAVE PHANTOM, a precise mood-matching engine.
Return ONLY a JSON array of song ids (numbers) that truly fit the requested experience.
Rules:
- Match emotional energy, not just a word in the title.
- Rainy / mellow → slow, soft, ambient, ballads. Reject gym/hype/party tracks.
- Unstoppable / energy → high energy, anthems, strong beat. Reject lullabies and pure ambient.
- Night drive → cinematic, cruise, synth/night-city feel.
- Focus → instrumental/calm/lofi; avoid aggressive vocals.
- Prefer clear fits over filling the list. Fewer good ids is better than wrong ones.
No markdown, no commentary. Max $limit ids, best first."""
        val user = "Experience: $modeLabel\nLibrary (id|title|artist|duration):\n$catalog\n\nJSON array of matching ids only:"
        return chat(system, user, maxTokens = 400).mapCatching { raw ->
            val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val arr = JSONArray(cleaned)
            (0 until arr.length()).mapNotNull {
                when (val v = arr.get(it)) {
                    is Number -> v.toLong()
                    is String -> v.toLongOrNull()
                    else -> null
                }
            }.take(limit)
        }
    }

    /** Music DNA explanation + cluster labels. */
    suspend fun musicDnaExplain(songs: List<Song>): Result<String> {
        val sample = songs.take(40).joinToString("\n") {
            "${it.title} — ${it.artist} (${it.durationMs / 1000}s)"
        }
        val system = "You are TEXWAVE Music DNA. Analyze taste patterns. Be vivid, concise, structured with short bullets."
        val user = "Local library sample:\n$sample\n\nDescribe hidden structure of this listener's taste (textures, energy, patterns)."
        return chat(system, user, maxTokens = 600)
    }

    /** Sound Detective — structural notes for one track. */
    suspend fun soundDetective(song: Song): Result<String> {
        val system = "You are TEXWAVE Sound Detective. Infer likely structure from metadata. Mark times as estimates."
        val user = """Track: ${song.title}
Artist: ${song.artist}
Album: ${song.album}
Duration: ${song.durationMs / 1000}s

Give: estimated tempo range, likely sections with times, energy arc, listening tips."""
        return chat(system, user, maxTokens = 500)
    }

    /** Infinite Mix ordering rationale + preferred order of ids. */
    suspend fun infiniteMixOrder(songs: List<Song>): Result<List<Long>> {
        if (songs.size <= 2) return Result.success(songs.map { it.id })
        val catalog = songs.take(40).joinToString("\n") {
            "${it.id}|${it.title}|${it.artist}|${it.durationMs / 1000}s"
        }
        val system = """You are TEXWAVE Infinite Mix. Order tracks for a coherent emotional arc.
Return ONLY a JSON array of all given song ids in play order. No markdown."""
        val user = "Tracks:\n$catalog\n\nOrdered JSON array of ids:"
        return chat(system, user, maxTokens = 500).mapCatching { raw ->
            val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val arr = JSONArray(cleaned)
            (0 until arr.length()).mapNotNull {
                when (val v = arr.get(it)) {
                    is Number -> v.toLong()
                    is String -> v.toLongOrNull()
                    else -> null
                }
            }
        }
    }

    /** Universe constellation labels between songs. */
    suspend fun universeLinks(seed: Song, neighbors: List<Song>): Result<String> {
        val list = neighbors.take(12).joinToString("\n") { "• ${it.title} — ${it.artist}" }
        val system = "You are TEXWAVE Local Music Universe. Explain connections poetically but clearly."
        val user = "Seed: ${seed.title} — ${seed.artist}\nNearby in library:\n$list\n\nWhy these form a constellation:"
        return chat(system, user, maxTokens = 400)
    }

    /**
     * Vision: send an image + text instruction (describe / suggest edits / analyze).
     * Uses a vision-capable model when available.
     */
    suspend fun chatWithImage(
        system: String,
        userText: String,
        imageBytes: ByteArray,
        mime: String = "image/jpeg",
        model: String = VISION_MODEL,
        maxTokens: Int = 1200,
    ): Result<String> = withContext(Dispatchers.IO) {
        val key = apiKey
        if (key.isBlank()) return@withContext Result.failure(IllegalStateException("Groq API key not set"))
        val b64 = android.util.Base64.encodeToString(imageBytes, android.util.Base64.NO_WRAP)
        val dataUrl = "data:$mime;base64,$b64"
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", userText))
            .put(
                JSONObject()
                    .put("type", "image_url")
                    .put("image_url", JSONObject().put("url", dataUrl)),
            )
        var last: Result<String> = Result.failure(IllegalStateException("No vision model available"))
        for (m in (listOf(model) + VISION_FALLBACKS).distinct()) {
            last = try {
                val body = JSONObject()
                    .put("model", m)
                    .put("temperature", 0.3)
                    .put("max_tokens", maxTokens)
                    .put(
                        "messages",
                        JSONArray()
                            .put(JSONObject().put("role", "system").put("content", system))
                            .put(JSONObject().put("role", "user").put("content", content)),
                    )
                val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                    connectTimeout = 25_000
                    readTimeout = 90_000
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                if (code !in 200..299) {
                    val detail = try {
                        JSONObject(text).optJSONObject("error")?.optString("message")?.take(280)
                    } catch (_: Exception) { null }
                    Result.failure(Exception("Groq $code: ${detail ?: text.take(200)}"))
                } else {
                    val contentOut = JSONObject(text)
                        .getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .getString("content")
                    Result.success(clean(contentOut))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
            if (last.isSuccess) return@withContext last
            if (!shouldFallback(last.exceptionOrNull())) return@withContext last
        }
        last
    }

    companion object {
        const val KEY = "api_key"
        const val ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"
        /**
         * Groq model IDs change often. Prefer stable public ids and fall through
         * the chain on 404 / model_not_found so Phantom keeps answering.
         * Vision: llama-4 scout when available; otherwise text-only fallbacks.
         */
        const val VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"
        const val DEFAULT_MODEL = "llama-3.3-70b-versatile"
        val FALLBACK_MODELS = listOf(
            "llama-3.3-70b-versatile",
            "llama-3.1-70b-versatile",
            "llama-3.1-8b-instant",
            "gemma2-9b-it",
            "mixtral-8x7b-32768",
            "qwen/qwen3-32b",
            "meta-llama/llama-4-scout-17b-16e-instruct",
        )
        val VISION_FALLBACKS = listOf(
            "meta-llama/llama-4-scout-17b-16e-instruct",
            "meta-llama/llama-4-maverick-17b-128e-instruct",
            "llama-3.2-90b-vision-preview",
            "llama-3.2-11b-vision-preview",
        )
    }
}
