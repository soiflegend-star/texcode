package com.texgen.music.texwave.player

import android.graphics.Bitmap
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import java.io.ByteArrayOutputStream
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Wraps the real player so the MediaSession (system media tile, lock screen, Bluetooth, the
 * notification) is told that the current track's artwork is our rendered frame. Playback itself
 * is untouched. Call [setArt] on the main thread.
 */
class ArtPlayer(player: Player) : ForwardingPlayer(player) {
    private val listeners = CopyOnWriteArraySet<Player.Listener>()

    @Volatile private var artKey: String? = null
    @Volatile private var artBytes: ByteArray? = null

    override fun addListener(listener: Player.Listener) {
        listeners.add(listener)
        super.addListener(listener)
    }

    override fun removeListener(listener: Player.Listener) {
        listeners.remove(listener)
        super.removeListener(listener)
    }

    private fun decorate(mediaId: String?, md: MediaMetadata): MediaMetadata {
        val bytes = artBytes
        if (bytes == null || mediaId == null || mediaId != artKey) return md
        return md.buildUpon()
            .setArtworkData(bytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
            .setArtworkUri(null)
            .build()
    }

    override fun getMediaMetadata(): MediaMetadata =
        decorate(super.getCurrentMediaItem()?.mediaId, super.getMediaMetadata())

    override fun getCurrentMediaItem(): MediaItem? {
        val item = super.getCurrentMediaItem() ?: return null
        return item.buildUpon().setMediaMetadata(decorate(item.mediaId, item.mediaMetadata)).build()
    }

    // ---- Previous / next ----------------------------------------------------------------
    // The default seekToPrevious() only restarts the current song when it has played > 3 s, and the
    // buttons are disabled on the first track. Phone / lock-screen / Bluetooth "previous" must always
    // go to the previous song (wrapping to the last one).

    private fun goPrevious() {
        val n = mediaItemCount
        if (n <= 0) return
        val prev = wrappedPlayer.previousMediaItemIndex
        val target = if (prev != C.INDEX_UNSET) prev else n - 1
        seekTo(target, 0L)
        play()
    }

    private fun goNext() {
        val n = mediaItemCount
        if (n <= 0) return
        val next = wrappedPlayer.nextMediaItemIndex
        val target = if (next != C.INDEX_UNSET) next else 0
        seekTo(target, 0L)
        play()
    }

    override fun seekToPrevious() = goPrevious()
    override fun seekToPreviousMediaItem() = goPrevious()
    override fun seekToNext() = goNext()
    override fun seekToNextMediaItem() = goNext()

    override fun getAvailableCommands(): Player.Commands {
        val base = super.getAvailableCommands()
        if (mediaItemCount <= 0) return base
        return base.buildUpon()
            .addAll(
                Player.COMMAND_SEEK_TO_PREVIOUS,
                Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM,
                Player.COMMAND_SEEK_TO_NEXT,
                Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
            )
            .build()
    }

    override fun isCommandAvailable(command: Int): Boolean = availableCommands.contains(command)

    fun setArt(key: String, bitmap: Bitmap) {
        try {
            val out = ByteArrayOutputStream(48_000)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            artKey = key
            artBytes = out.toByteArray()
            val md = mediaMetadata
            listeners.forEach { it.onMediaMetadataChanged(md) }
        } catch (_: Throwable) {
        }
    }
}
