package com.texgen.music.texwave.data.chat

/** Visual reaction pulses on messages. */
object ResonanceReply {
    data class Reaction(val id: String, val label: String, val emoji: String)

    val all = listOf(
        Reaction("pulse", "Excitement", "⚡"),
        Reaction("ripple", "Support", "🌊"),
        Reaction("spark", "Love", "✨"),
        Reaction("fire", "Fire", "🔥"),
        Reaction("music", "Music", "🎵"),
        Reaction("wave", "Wave", "👋"),
    )

    fun encode(messageId: String, reactionId: String): String =
        "TEXWAVE_REACT:$reactionId|$messageId"

    fun parse(body: String?): Pair<String, String>? {
        if (body == null || !body.startsWith("TEXWAVE_REACT:")) return null
        val p = body.removePrefix("TEXWAVE_REACT:").split("|")
        if (p.size < 2) return null
        return p[0] to p[1]
    }

    fun label(body: String?): String? {
        val p = parse(body) ?: return null
        val r = all.firstOrNull { it.id == p.first }
        return "${r?.emoji ?: "✨"} ${r?.label ?: p.first}"
    }
}
