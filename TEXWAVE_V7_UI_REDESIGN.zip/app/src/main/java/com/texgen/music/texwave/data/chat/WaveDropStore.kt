package com.texgen.music.texwave.data.chat

import android.content.Context
import java.util.Calendar
import kotlin.random.Random

/** Daily Wave Drop — unique each day (no immediate repeat), answer + who solved. */
object WaveDropStore {
    data class Drop(val id: String, val title: String, val prompt: String, val kind: String)
    data class Solver(val userId: String, val name: String, val answer: String)

    private val pool = listOf(
        Drop("d1", "Three-word story", "Send a friend a story in exactly three words.", "story"),
        Drop("d2", "Song guess", "Describe a song in 5 words — can they name it?", "music"),
        Drop("d3", "Daily question", "What's one sound that always calms you?", "question"),
        Drop("d4", "Vibe check", "Share the mood of your day in one emoji + one song.", "vibe"),
        Drop("d5", "Memory spark", "Name a track that takes you back to a specific place.", "memory"),
        Drop("d6", "Quick puzzle", "Unscramble: V-A-E-W-X-E-T (hint: this app).", "puzzle"),
        Drop("d7", "Grateful note", "Tell someone one thing you appreciated this week.", "kind"),
        Drop("d8", "One lyric", "Type one lyric that describes your week.", "lyric"),
        Drop("d9", "Hidden gem", "Name a song almost nobody knows but you love.", "music"),
        Drop("d10", "Color mood", "If today were a color + a song, what are they?", "vibe"),
        Drop("d11", "Time machine", "Which year had the best music for you — and one track from it?", "memory"),
        Drop("d12", "Silent signal", "Describe a feeling without using sad/happy/angry.", "story"),
        Drop("d13", "Beat drop", "Name the song with the best beat drop you know.", "music"),
        Drop("d14", "Night drive", "Song for a 2 AM empty road.", "vibe"),
    )

    private fun dayKey(): Int = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
    private fun yearKey(): Int = Calendar.getInstance().get(Calendar.YEAR)

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("texwave_wave_drops", Context.MODE_PRIVATE)

    /** Pick today's drop: stable for the calendar day, avoids repeating recent days. */
    fun today(ctx: Context? = null): Drop {
        val day = dayKey()
        val year = yearKey()
        if (ctx != null) {
            val p = prefs(ctx)
            val savedId = p.getString("pick_${year}_$day", null)
            if (savedId != null) {
                pool.firstOrNull { it.id == savedId }?.let { return it }
            }
            // Avoid last 5 used ids
            val recent = p.getString("recent_ids", "")!!.split(",").filter { it.isNotBlank() }.toSet()
            val candidates = pool.filter { it.id !in recent }.ifEmpty { pool }
            val pick = candidates[Random(year * 1000L + day).nextInt(candidates.size)]
            val nextRecent = (listOf(pick.id) + recent).distinct().take(5).joinToString(",")
            p.edit()
                .putString("pick_${year}_$day", pick.id)
                .putString("recent_ids", nextRecent)
                .apply()
            return pick
        }
        return pool[(year * 366 + day) % pool.size]
    }

    fun markDone(ctx: Context) {
        prefs(ctx).edit().putBoolean("done_${yearKey()}_${dayKey()}", true).apply()
    }

    fun isDone(ctx: Context): Boolean =
        prefs(ctx).getBoolean("done_${yearKey()}_${dayKey()}", false)

    fun saveAnswer(ctx: Context, answer: String) {
        prefs(ctx).edit()
            .putString("answer_${yearKey()}_${dayKey()}", answer.take(200))
            .putBoolean("done_${yearKey()}_${dayKey()}", true)
            .apply()
    }

    fun myAnswer(ctx: Context): String? =
        prefs(ctx).getString("answer_${yearKey()}_${dayKey()}", null)

    fun encodeShare(drop: Drop, answer: String): String =
        "TEXWAVE_DROP:${drop.id}|${drop.title}|${answer.take(200).replace("|", "/")}"

    fun encodeSolved(drop: Drop, answer: String, displayName: String = ""): String {
        val name = displayName.replace("|", "/").take(40)
        return "TEXWAVE_DROP_SOLVED:${drop.id}|${answer.take(120).replace("|", "/")}|$name"
    }

    fun isSolvedMessage(body: String?, dropId: String): Boolean {
        if (body == null) return false
        return body.startsWith("TEXWAVE_DROP_SOLVED:$dropId") ||
            body.startsWith("TEXWAVE_DROP:$dropId|")
    }

    fun parseSolver(body: String?, senderId: String, fallbackName: String): Solver? {
        if (body == null) return null
        return when {
            body.startsWith("TEXWAVE_DROP_SOLVED:") -> {
                val rest = body.removePrefix("TEXWAVE_DROP_SOLVED:")
                val parts = rest.split("|")
                val id = parts.getOrNull(0) ?: return null
                if (id != today().id && id != (parts.getOrNull(0))) {
                    // check against any - caller filters by today
                }
                Solver(
                    userId = senderId,
                    name = parts.getOrNull(2)?.ifBlank { fallbackName } ?: fallbackName,
                    answer = parts.getOrNull(1) ?: "",
                )
            }
            body.startsWith("TEXWAVE_DROP:") -> {
                val parts = body.removePrefix("TEXWAVE_DROP:").split("|")
                Solver(
                    userId = senderId,
                    name = fallbackName,
                    answer = parts.getOrNull(2) ?: "",
                )
            }
            else -> null
        }
    }

    fun solversFromSamples(
        dropId: String,
        samples: List<Triple<String, String?, String>>, // senderId, body, name
    ): List<Solver> {
        val map = linkedMapOf<String, Solver>()
        samples.forEach { (sid, body, name) ->
            if (body == null) return@forEach
            if (!isSolvedMessage(body, dropId)) return@forEach
            parseSolver(body, sid, name)?.let { map[sid] = it }
        }
        return map.values.toList()
    }

    fun countFriendsSolved(
        friendIds: Set<String>,
        messageSamples: List<Pair<String, String?>>,
    ): Int {
        val dropId = today().id
        return messageSamples
            .filter { (sender, body) -> sender in friendIds && isSolvedMessage(body, dropId) }
            .map { it.first }
            .toSet()
            .size
    }
}
