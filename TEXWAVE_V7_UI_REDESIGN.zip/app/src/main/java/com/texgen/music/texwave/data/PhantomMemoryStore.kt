package com.texgen.music.texwave.data

import android.content.Context

/**
 * Phantom — personal wave memory the user controls.
 * Explicit interests only; never silent profiling of private chats.
 */
object PhantomMemoryStore {
    private const val PREFS = "texwave_phantom_memory"

    fun interests(ctx: Context): Set<String> =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet("interests", emptySet()) ?: emptySet()

    fun addInterest(ctx: Context, item: String) {
        val next = interests(ctx).toMutableSet()
        next.add(item.trim().take(40))
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet("interests", next).apply()
    }

    fun removeInterest(ctx: Context, item: String) {
        val next = interests(ctx).toMutableSet()
        next.remove(item)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet("interests", next).apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun style(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("style", "warm") ?: "warm"

    fun setStyle(ctx: Context, style: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("style", style).apply()
    }

    fun memorySummary(ctx: Context): String {
        val i = interests(ctx)
        val s = style(ctx)
        return buildString {
            append("Phantom remembers (only what you saved):\n")
            if (i.isEmpty()) append("• No interests yet — add some from Phantom settings.\n")
            else i.forEach { append("• $it\n") }
            append("Conversation style: $s")
        }
    }

    fun systemHint(ctx: Context): String {
        val i = interests(ctx).joinToString(", ")
        val s = style(ctx)
        return buildString {
            append("User-controlled Phantom memory. Style=$s. ")
            if (i.isNotBlank()) append("Interests: $i. ")
            append("Never invent private chat facts. Be helpful and concise.")
        }
    }
}
