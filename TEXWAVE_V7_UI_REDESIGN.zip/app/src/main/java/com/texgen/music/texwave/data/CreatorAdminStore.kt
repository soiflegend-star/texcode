package com.texgen.music.texwave.data

import android.content.Context

/**
 * Creator Command Center — local feature flags for the product owner.
 * Password: soifstar. Does NOT read private messages.
 */
object CreatorAdminStore {
    const val PASSWORD = "soifstar"
    private const val PREFS = "texwave_creator_admin"

    fun isUnlocked(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("unlocked", false)

    fun unlock(ctx: Context, password: String): Boolean {
        if (password != PASSWORD) return false
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("unlocked", true).apply()
        return true
    }

    fun flag(ctx: Context, key: String, default: Boolean = true): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("flag_$key", default)

    fun setFlag(ctx: Context, key: String, value: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("flag_$key", value).apply()
    }

    val flags = listOf(
        "wave_drops" to "Wave Drops",
        "wave_presence" to "Wave Presence",
        "living_groups" to "Living Groups",
        "resonance_replies" to "Resonance Replies",
        "phantom" to "Phantom",
        "calls" to "Voice / Video calls",
    )
}
