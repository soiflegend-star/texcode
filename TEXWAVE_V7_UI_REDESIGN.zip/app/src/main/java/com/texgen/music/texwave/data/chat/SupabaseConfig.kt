package com.texgen.music.texwave.data.chat

/**
 * TEXWAVE Chat — Supabase client configuration.
 * Project URL + publishable/anon key for client use only.
 * Never put service_role / secret keys here.
 */
object SupabaseConfig {
    const val SUPABASE_URL = "https://ascwhsyyznwgchexboug.supabase.co"
    const val SUPABASE_ANON_KEY = "sb_publishable_dbg8KLLzWJhMzU2tSiC2zQ_fC7lx4Rn"

    const val MAX_FILE_BYTES = 50L * 1024 * 1024
    const val STORAGE_BUCKET = "chat-files"
    /** Public bucket for profile photos (created by RUN_THIS_ONCE.sql). */
    const val AVATAR_BUCKET = "avatars"

    val isConfigured: Boolean
        get() = SUPABASE_ANON_KEY.isNotBlank()
                && !SUPABASE_ANON_KEY.contains("YOUR_ANON")
}
