package com.texgen.music.texwave.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.data.Playlist
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.songCount

@Composable
private fun ActionRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Tx.Text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, color = Tx.Text, style = MaterialTheme.typography.bodyLarge)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongOptionsSheet(
    song: Song,
    liked: Boolean,
    inPlaylist: Boolean,
    blacklisted: Boolean = false,
    onDismiss: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onToggleLike: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
    onPlaySimilar: () -> Unit = {},
    onQueueAlbum: () -> Unit = {},
    onShare: () -> Unit = {},
    onToggleBlacklist: () -> Unit = {},
    onSetArt: () -> Unit = {},
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(),
        containerColor = Tx.Surface,
    ) {
        Column(Modifier.navigationBarsPadding()) {
            Row(
                Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Artwork(song, Modifier.size(52.dp), corner = 10.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = Tx.Text, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = Tx.Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(4.dp))
            ActionRow(Icons.Rounded.SkipNext, "Play next", onPlayNext)
            ActionRow(Icons.Rounded.QueueMusic, "Add to queue", onAddToQueue)
            ActionRow(if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (liked) "Unlike" else "Like", onToggleLike)
            ActionRow(Icons.Rounded.PlaylistAdd, "Add to playlist", onAddToPlaylist)
            if (inPlaylist) ActionRow(Icons.Rounded.Delete, "Remove from playlist", onRemoveFromPlaylist)
            ActionRow(Icons.Rounded.PlaylistPlay, "Play similar (artist / album)", onPlaySimilar)
            ActionRow(Icons.Rounded.Add, "Queue rest of album", onQueueAlbum)
            ActionRow(Icons.Rounded.Add, "Share", onShare)
            ActionRow(Icons.Rounded.Close, if (blacklisted) "Include in shuffle" else "Exclude from shuffle", onToggleBlacklist)
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(
    state: PlayerState,
    onDismiss: () -> Unit,
    onJump: (Int) -> Unit,
    onRemove: (Int) -> Unit,
    onClear: () -> Unit = {},
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Tx.Surface,
    ) {
        Column(Modifier.navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Queue · ${songCount(state.queue.size)}",
                    color = Tx.Text,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    "Clear",
                    color = Tx.Accent2,
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onClear(); onDismiss() }
                        .padding(8.dp),
                )
            }
            LazyColumn {
                itemsIndexed(state.queue) { index, song ->
                    val isCurrent = index == state.queueIndex
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onJump(index) }
                            .background(if (isCurrent) Tx.Accent.copy(alpha = 0.14f) else androidx.compose.ui.graphics.Color.Transparent)
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Artwork(song, Modifier.size(44.dp), corner = 10.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                song.title,
                                color = if (isCurrent) Tx.Accent2 else Tx.Text,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            Text(song.artist, color = Tx.Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (isCurrent) {
                            EqualizerBars(active = state.isPlaying)
                        } else {
                            IconButton(onClick = { onRemove(index) }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Remove from queue", tint = Tx.Muted)
                            }
                        }
                    }
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistPickerSheet(
    playlists: List<Playlist>,
    onDismiss: () -> Unit,
    onPick: (Playlist) -> Unit,
    onCreate: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(),
        containerColor = Tx.Surface,
    ) {
        Column(Modifier.navigationBarsPadding()) {
            Text(
                "Add to playlist",
                color = Tx.Text,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
            )
            ActionRow(Icons.Rounded.Add, "Create new playlist", onCreate)
            LazyColumn {
                items(playlists, key = { it.id }) { p ->
                    ActionRow(Icons.Rounded.PlaylistAdd, p.name) { onPick(p) }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun NamePlaylistDialog(
    title: String = "New playlist",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Tx.SurfaceHigh,
        title = { Text(title, color = Tx.Text) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(60) },
                singleLine = true,
                placeholder = { Text("Playlist name", color = Tx.Muted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Tx.Text,
                    unfocusedTextColor = Tx.Text,
                    focusedBorderColor = Tx.Accent,
                    unfocusedBorderColor = Tx.Outline,
                    cursorColor = Tx.Accent2,
                ),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(name) }) { Text("Create", color = Tx.Accent2) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Tx.Muted) } },
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Tx.SurfaceHigh,
        title = { Text(title, color = Tx.Text) },
        text = { Text(message, color = Tx.Muted) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel, color = Tx.Accent2) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Tx.Muted) } },
    )
}
