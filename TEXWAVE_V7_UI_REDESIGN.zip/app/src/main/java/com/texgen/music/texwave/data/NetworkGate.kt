package com.texgen.music.texwave.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object NetworkGate {
    /**
     * True when the device has a network that can reach the internet.
     * Does NOT require VALIDATED (that flag is often delayed/false on mobile
     * and was causing Phantom to always say "offline" even with a working API key).
     */
    fun isOnline(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val net = cm.activeNetwork ?: return fallback(cm)
            val caps = cm.getNetworkCapabilities(net) ?: return fallback(cm)
            val hasTransport =
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            (hasTransport && hasInternet) || caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) {
            true // fail-open so Groq can still be attempted; request will fail if truly offline
        }
    }

    @Suppress("DEPRECATION")
    private fun fallback(cm: ConnectivityManager): Boolean {
        return try {
            val ni = cm.activeNetworkInfo
            ni != null && ni.isConnected
        } catch (_: Exception) {
            false
        }
    }
}
