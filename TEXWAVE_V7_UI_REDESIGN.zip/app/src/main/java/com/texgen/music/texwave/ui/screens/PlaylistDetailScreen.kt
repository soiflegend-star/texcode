package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.texgen.music.texwave.data.Playlist
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.GhostButton
import com.texgen.music.texwave.ui.components.GradientButton
import com.texgen.music.texwave.ui.components.GradientTile
import com.texgen.music.texwave.ui.components.SongRow
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.util.songCount

@Composable
fun PlaylistDetailScreen(
    playlist: Playlist,
    songs: List<Song>,
    lib: LibraryState,
    player: PlayerState,
    onBack: () -> Unit,
    onDelete: () -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onMore: (Song) -> Unit,
) {
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Tx.Text)
                }
                Box(Modifier.weight(1f))
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.Delete, contentDescription = "Delete playlist", tint = Tx.Muted)
                }
            }
        }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                GradientTile(playlist.id, Icons.Rounded.PlaylistPlay, Modifier.size(160.dp), corner = 28.dp, iconSize = 64.dp)
                Spacer(Modifier.height(16.dp))
                Text(
                    playlist.name, color = Tx.Text, style = MaterialTheme.typography.headlineMedium,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                Text(songCount(songs.size), color = Tx.Muted, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    GradientButton("Play", Icons.Rounded.PlayArrow, { if (songs.isNotEmpty()) onPlay(songs, 0) })
                    GhostButton("Shuffle", Icons.Rounded.Shuffle, { onShuffle(songs) })
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        if (songs.isEmpty()) {
            item {
                Text(
                    "This playlist is empty. Open a song's menu and choose \"Add to playlist\".",
                    color = Tx.Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(20.dp),
                )
            }
        }
        itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
            SongRow(
                song = song,
                isCurrent = player.current?.id == song.id,
                isPlaying = player.isPlaying,
                liked = song.id in lib.liked,
                onClick = { onPlay(songs, index) },
                onMore = { onMore(song) },
            )
        }
    }
}
