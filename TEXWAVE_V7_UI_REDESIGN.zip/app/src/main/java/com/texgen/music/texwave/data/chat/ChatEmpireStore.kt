package com.texgen.music.texwave.data.chat

import android.content.Context

/**
 * Local preferences for Chat Empire features that stay on-device.
 */
object ChatEmpireStore {
    private fun p(ctx: Context) = ctx.getSharedPreferences("texwave_chat_empire", Context.MODE_PRIVATE)

    fun setQuietHours(ctx: Context, chatId: String, startHour: Int, endHour: Int) {
        p(ctx).edit().putString("quiet_$chatId", "$startHour|$endHour").apply()
    }
    fun quietHours(ctx: Context, chatId: String): Pair<Int, Int>? {
        val s = p(ctx).getString("quiet_$chatId", null) ?: return null
        val parts = s.split("|")
        return (parts.getOrNull(0)?.toIntOrNull() ?: return null) to (parts.getOrNull(1)?.toIntOrNull() ?: return null)
    }
    fun isInQuietHours(ctx: Context, chatId: String): Boolean {
        val q = quietHours(ctx, chatId) ?: return false
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return if (q.first <= q.second) h in q.first until q.second
        else h >= q.first || h < q.second
    }

    fun setReceipts(ctx: Context, chatId: String, on: Boolean) {
        p(ctx).edit().putBoolean("receipts_$chatId", on).apply()
    }
    fun receiptsOn(ctx: Context, chatId: String) = p(ctx).getBoolean("receipts_$chatId", true)

    fun setVaultPin(ctx: Context, pin: String) {
        p(ctx).edit().putString("vault_pin", pin).apply()
    }
    fun vaultPin(ctx: Context) = p(ctx).getString("vault_pin", null)
    fun lockChat(ctx: Context, chatId: String, locked: Boolean) {
        p(ctx).edit().putBoolean("lock_$chatId", locked).apply()
    }
    fun isLocked(ctx: Context, chatId: String) = p(ctx).getBoolean("lock_$chatId", false)

    fun setShieldKeywords(ctx: Context, chatId: String, csv: String) {
        p(ctx).edit().putString("shield_$chatId", csv).apply()
    }
    fun shieldKeywords(ctx: Context, chatId: String): List<String> =
        p(ctx).getString("shield_$chatId", "")?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }.orEmpty()

    fun shouldHideBody(ctx: Context, chatId: String, body: String?): Boolean {
        if (body.isNullOrBlank()) return false
        val keys = shieldKeywords(ctx, chatId)
        if (keys.isEmpty()) return false
        val low = body.lowercase()
        return keys.any { it.lowercase() in low }
    }

    fun bumpEdge(ctx: Context, a: String, b: String) {
        val key = "edge_${listOf(a, b).sorted().joinToString("_")}"
        val n = p(ctx).getInt(key, 0) + 1
        p(ctx).edit().putInt(key, n).apply()
    }
    fun edgeWeight(ctx: Context, a: String, b: String): Int {
        val key = "edge_${listOf(a, b).sorted().joinToString("_")}"
        return p(ctx).getInt(key, 0)
    }

    fun setNightCrewEnd(ctx: Context, chatId: String, endsAt: Long) {
        p(ctx).edit().putLong("crew_$chatId", endsAt).apply()
    }
    fun nightCrewEnd(ctx: Context, chatId: String) = p(ctx).getLong("crew_$chatId", 0L)

    fun addVote(ctx: Context, voteId: String, option: String) {
        val k = "vote_$voteId"
        val cur = p(ctx).getString(k, "") ?: ""
        p(ctx).edit().putString(k, if (cur.isBlank()) option else "$cur||$option").apply()
    }
    fun voteCounts(ctx: Context, voteId: String): Map<String, Int> {
        val cur = p(ctx).getString("vote_$voteId", "") ?: return emptyMap()
        return cur.split("||").filter { it.isNotBlank() }.groupingBy { it }.eachCount()
    }

    fun sessionStats(ctx: Context, chatId: String): Triple<Int, Int, Int> {
        val s = p(ctx).getString("stats_$chatId", "0|0|0") ?: "0|0|0"
        val p3 = s.split("|")
        return Triple(p3.getOrNull(0)?.toIntOrNull() ?: 0, p3.getOrNull(1)?.toIntOrNull() ?: 0, p3.getOrNull(2)?.toIntOrNull() ?: 0)
    }
    fun bumpStat(ctx: Context, chatId: String, songs: Int = 0, drawings: Int = 0, minutes: Int = 0) {
        val cur = sessionStats(ctx, chatId)
        p(ctx).edit().putString("stats_$chatId", "${cur.first + songs}|${cur.second + drawings}|${cur.third + minutes}").apply()
    }
}
