package com.texgen.music.texwave.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

/** Full-storage music scan — includes short tracks and non-flagged audio files. */
class MusicRepository(private val context: Context) {

    fun loadAllSongs(): List<Song> {
        // Query the audio provider only once. The previous two-pass scan read the entire
        // MediaStore twice immediately after permission was granted, creating unnecessary
        // startup load on devices with large libraries or slower vendor MediaStore providers.
        val byId = LinkedHashMap<Long, Song>()
        scan(byId, "${MediaStore.Audio.Media.DURATION} >= 3000")
        return byId.values.sortedBy { it.title.lowercase() }
    }

    private fun scan(into: MutableMap<Long, Song>, selection: String) {
        val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            // DATA is deprecated/restricted on modern Android and is not needed for playback.
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.SIZE,
        )
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            context.contentResolver.query(collection, projection, selection, null, sort)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val addedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val yearCol = c.getColumnIndex(MediaStore.Audio.Media.YEAR)
                val trackCol = c.getColumnIndex(MediaStore.Audio.Media.TRACK)
                val sizeCol = c.getColumnIndex(MediaStore.Audio.Media.SIZE)
                while (c.moveToNext()) {
                    // One malformed/provider-specific row should not abort the whole scan.
                    try {
                        val id = c.getLong(idCol)
                        if (into.containsKey(id)) continue
                        val size = if (sizeCol >= 0) c.getLong(sizeCol) else 0L
                        if (size in 1 until 8_000) continue // skip tiny non-music
                        // Build the item URI from the same collection queried above.
                        val uri = ContentUris.withAppendedId(collection, id)
                        into[id] = Song(
                            id = id,
                            title = c.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Unknown title",
                            artist = cleanArtist(c.getString(artistCol)),
                            album = c.getString(albumCol)?.takeIf { it.isNotBlank() } ?: "Unknown album",
                            albumId = c.getLong(albumIdCol),
                            durationMs = c.getLong(durCol).coerceAtLeast(0L),
                            dateAdded = c.getLong(addedCol),
                            contentUri = uri.toString(),
                            path = "",
                            year = if (yearCol >= 0) c.getInt(yearCol) else 0,
                            trackNumber = if (trackCol >= 0) c.getInt(trackCol) % 1000 else 0,
                        )
                    } catch (_: Exception) {
                        // Skip a row the device's MediaStore cannot read cleanly.
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun cleanArtist(raw: String?): String {
        if (raw.isNullOrBlank() || raw == MediaStore.UNKNOWN_STRING || raw == "<unknown>") return "Unknown artist"
        return raw
    }
}
