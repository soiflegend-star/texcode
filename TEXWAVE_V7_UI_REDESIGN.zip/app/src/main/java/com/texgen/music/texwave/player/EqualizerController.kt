package com.texgen.music.texwave.player

import android.media.audiofx.Equalizer
import android.util.Log
import com.texgen.music.texwave.data.AppSettings

/**
 * Wraps Android's Equalizer audio effect attached to the ExoPlayer audio session.
 * Safe to call from any thread; internal state is guarded.
 */
class EqualizerController(private val settings: AppSettings) {
    private var equalizer: Equalizer? = null
    private var sessionId: Int = 0

    val bandCount: Int get() = equalizer?.numberOfBands?.toInt() ?: 5
    val bandLevelRange: ShortArray get() = equalizer?.bandLevelRange ?: shortArrayOf(-1500, 1500)

    fun attach(audioSessionId: Int) {
        if (audioSessionId == 0 || audioSessionId == sessionId) return
        release()
        sessionId = audioSessionId
        try {
            equalizer = Equalizer(0, audioSessionId).apply {
                enabled = settings.loadEqEnabled()
                val bands = settings.loadEqBands()
                val n = numberOfBands.toInt().coerceAtMost(bands.size)
                for (i in 0 until n) {
                    setBandLevel(i.toShort(), bands[i].toShort())
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Equalizer unavailable: ${e.message}")
            equalizer = null
        }
    }

    fun setEnabled(on: Boolean) {
        settings.saveEqEnabled(on)
        try {
            equalizer?.enabled = on
        } catch (_: Exception) { }
    }

    fun isEnabled(): Boolean = try {
        equalizer?.enabled == true
    } catch (_: Exception) {
        settings.loadEqEnabled()
    }

    fun getBandLevel(band: Int): Int = try {
        equalizer?.getBandLevel(band.toShort())?.toInt() ?: 0
    } catch (_: Exception) {
        settings.loadEqBands().getOrElse(band) { 0 }
    }

    fun setBandLevel(band: Int, levelMillibels: Int) {
        try {
            equalizer?.setBandLevel(band.toShort(), levelMillibels.toShort())
        } catch (_: Exception) { }
        val bands = settings.loadEqBands().copyOf(bandCount.coerceAtLeast(5))
        if (band in bands.indices) bands[band] = levelMillibels
        settings.saveEqBands(bands)
    }

    fun getCenterFreq(band: Int): Int = try {
        (equalizer?.getCenterFreq(band.toShort()) ?: 0) / 1000  // Hz
    } catch (_: Exception) {
        when (band) {
            0 -> 60; 1 -> 230; 2 -> 910; 3 -> 3600; else -> 14000
        }
    }

    fun applyPreset(index: Int) {
        settings.saveEqPreset(index)
        val presets = PRESETS.getOrNull(index) ?: return
        for (i in presets.indices) setBandLevel(i, presets[i])
        setEnabled(true)
    }

    fun release() {
        try {
            equalizer?.release()
        } catch (_: Exception) { }
        equalizer = null
        sessionId = 0
    }

    companion object {
        private const val TAG = "EqController"

        val PRESET_NAMES = listOf(
            "Flat", "Bass Boost", "Treble Boost", "Vocal", "Rock", "Electronic", "Classical"
        )

        /** 5-band levels in millibels */
        private val PRESETS = listOf(
            intArrayOf(0, 0, 0, 0, 0),
            intArrayOf(800, 400, 0, 0, 0),
            intArrayOf(0, 0, 0, 400, 800),
            intArrayOf(-200, 200, 600, 400, 0),
            intArrayOf(500, 300, -100, 200, 400),
            intArrayOf(600, 200, -200, 300, 600),
            intArrayOf(0, 200, 0, 200, 0),
        )
    }
}
