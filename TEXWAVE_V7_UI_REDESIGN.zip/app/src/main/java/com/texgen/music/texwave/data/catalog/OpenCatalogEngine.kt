package com.texgen.music.texwave.data.catalog

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Real catalog engine for open-license audio/video from Internet Archive.
 * - Parallel metadata fetch
 * - URL probe before offering play/download
 * - DownloadManager + HTTP fallback with size verification
 */
object OpenCatalogEngine {

    data class AudioItem(
        val id: String,
        val title: String,
        val artist: String,
        val fileName: String,
        val url: String,
        val license: String,
        val bytesHint: Long = 0L,
    )

    data class VideoItem(
        val id: String,
        val title: String,
        val creator: String,
        val url: String,
        val license: String,
        val bytesHint: Long = 0L,
    )

    private val probeCache = ConcurrentHashMap<String, Boolean>()
    private val ioMutex = Mutex()

    private fun httpJson(url: String, timeoutMs: Int = 18_000): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "TEXWAVE/7.2 CatalogEngine")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (body.isBlank()) JSONObject() else JSONObject(body)
        } finally {
            c.disconnect()
        }
    }

    /** Lightweight reachability — HEAD, fallback GET range */
    fun probeUrl(url: String, minBytes: Long = 8_000L): Boolean {
        probeCache[url]?.let { return it }
        val ok = try {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 8_000
                readTimeout = 8_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "TEXWAVE/7.2")
            }
            try {
                val code = c.responseCode
                val len = c.contentLengthLong.takeIf { it > 0 } ?: c.getHeaderField("Content-Length")?.toLongOrNull() ?: 0L
                when {
                    code in 200..299 && (len == 0L || len >= minBytes) -> true
                    code in 200..399 -> true
                    else -> {
                        // Some IA servers reject HEAD — try ranged GET
                        val g = (URL(url).openConnection() as HttpURLConnection).apply {
                            requestMethod = "GET"
                            setRequestProperty("Range", "bytes=0-1023")
                            connectTimeout = 8_000
                            readTimeout = 8_000
                            instanceFollowRedirects = true
                            setRequestProperty("User-Agent", "TEXWAVE/7.2")
                        }
                        try {
                            g.responseCode in 200..299 || g.responseCode == 206
                        } finally {
                            g.disconnect()
                        }
                    }
                }
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            false
        }
        probeCache[url] = ok
        return ok
    }

    private fun licenseOk(raw: String): Boolean {
        val l = raw.lowercase()
        if (l.isBlank()) return false
        return l.contains("publicdomain/zero") ||
            l.contains("public domain") ||
            l.contains("licenses/by/") ||
            l.contains("licenses/by-sa/") ||
            l.contains("creativecommons.org/licenses/by")
    }

    private fun encodePath(name: String): String =
        name.split("/").joinToString("/") {
            URLEncoder.encode(it, "UTF-8").replace("+", "%20")
        }

    // -------------------- AUDIO --------------------

    suspend fun searchAudio(term: String, limit: Int = 20): List<AudioItem> = withContext(Dispatchers.IO) {
        val cleaned = term.replace("\"", " ").trim().take(80)
        val queries = if (cleaned.isBlank()) {
            listOf(
                "collection:opensource_audio AND mediatype:audio",
                "mediatype:audio AND licenseurl:creativecommons.org AND format:mp3",
            )
        } else {
            listOf(
                "mediatype:audio AND title:($cleaned) AND format:mp3",
                "collection:opensource_audio AND ($cleaned)",
                "mediatype:audio AND ($cleaned) AND licenseurl:creativecommons.org",
            )
        }
        val ids = linkedSetOf<String>()
        for (q in queries) {
            if (ids.size >= limit * 2) break
            try {
                val enc = URLEncoder.encode(q, "UTF-8")
                val docs = httpJson(
                    "https://archive.org/advancedsearch.php?q=$enc&fl[]=identifier,title,creator&rows=40&page=1&output=json",
                ).optJSONObject("response")?.optJSONArray("docs") ?: JSONArray()
                for (i in 0 until docs.length()) {
                    val id = docs.optJSONObject(i)?.optString("identifier").orEmpty()
                    if (id.isNotBlank()) ids += id
                }
            } catch (_: Exception) {
            }
        }
        coroutineScope {
            ids.take(limit * 2).map { id ->
                async {
                    try {
                        resolveAudio(id)
                    } catch (_: Exception) {
                        null
                    }
                }
            }.awaitAll().filterNotNull().filter { probeUrl(it.url, 12_000L) }.take(limit)
        }
    }

    private fun resolveAudio(id: String): AudioItem? {
        val meta = httpJson("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}")
        val metadata = meta.optJSONObject("metadata") ?: return null
        val license = metadata.optString("licenseurl", metadata.optString("license_url", ""))
        if (!licenseOk(license)) return null
        val files = meta.optJSONArray("files") ?: return null
        var best: Triple<String, Long, String>? = null // name, size, format
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name")
            if (!name.endsWith(".mp3", true) || name.contains("../")) continue
            val size = f.optString("size").toLongOrNull() ?: 0L
            val format = f.optString("format")
            if (best == null || (size > 0 && size < (best.second.takeIf { it > 0 } ?: Long.MAX_VALUE) && size > 80_000)) {
                // Prefer reasonable size VBR MP3
                best = Triple(name, size, format)
            }
            if (format.contains("VBR", true) && size in 100_000..15_000_000L) {
                best = Triple(name, size, format)
                break
            }
        }
        val name = best?.first ?: return null
        val title = metadata.optString("title", id).ifBlank { id }
        val artist = metadata.optString("creator", "Open artist")
        val url = "https://archive.org/download/${URLEncoder.encode(id, "UTF-8")}/${encodePath(name)}"
        return AudioItem(id, title, artist, name.substringAfterLast('/'), url, license, best?.second ?: 0L)
    }

    // -------------------- VIDEO --------------------

    suspend fun searchVideo(term: String, limit: Int = 16): List<VideoItem> = withContext(Dispatchers.IO) {
        val cleaned = term.replace("\"", " ").trim().take(60).ifBlank { "animation" }
        val queries = listOf(
            "mediatype:movies AND ($cleaned) AND format:(MPEG4)",
            "collection:opensource_movies AND ($cleaned)",
            "mediatype:movies AND title:($cleaned)",
        )
        val ids = linkedSetOf<String>()
        for (q in queries) {
            if (ids.size >= limit * 2) break
            try {
                val enc = URLEncoder.encode(q, "UTF-8")
                val docs = httpJson(
                    "https://archive.org/advancedsearch.php?q=$enc&fl[]=identifier,title,creator&rows=35&page=1&output=json",
                ).optJSONObject("response")?.optJSONArray("docs") ?: JSONArray()
                for (i in 0 until docs.length()) {
                    val id = docs.optJSONObject(i)?.optString("identifier").orEmpty()
                    if (id.isNotBlank()) ids += id
                }
            } catch (_: Exception) {
            }
        }
        coroutineScope {
            ids.take(limit * 2).map { id ->
                async {
                    try {
                        resolveVideo(id)
                    } catch (_: Exception) {
                        null
                    }
                }
            }.awaitAll().filterNotNull().filter { probeUrl(it.url, 40_000L) }.take(limit)
        }
    }

    private fun resolveVideo(id: String): VideoItem? {
        val meta = httpJson("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}")
        val metadata = meta.optJSONObject("metadata") ?: return null
        val license = metadata.optString("licenseurl", metadata.optString("license_url", ""))
        if (!licenseOk(license)) return null
        val files = meta.optJSONArray("files") ?: return null
        data class Cand(val name: String, val size: Long)
        val cands = mutableListOf<Cand>()
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name")
            if (name.contains("../")) continue
            val okExt = name.endsWith(".mp4", true) || name.endsWith(".webm", true)
            if (!okExt) continue
            val size = f.optString("size").toLongOrNull() ?: Long.MAX_VALUE
            // Prefer 2MB–80MB for reel-like playback
            cands += Cand(name, size)
        }
        val pick = cands
            .sortedWith(compareBy<Cand> { size ->
                when {
                    size in 2_000_000..80_000_000 -> 0
                    size < 2_000_000 -> 1
                    else -> 2
                }
            }.thenBy { it.size })
            .firstOrNull() ?: return null
        val url = "https://archive.org/download/${URLEncoder.encode(id, "UTF-8")}/${encodePath(pick.name)}"
        return VideoItem(
            id = id,
            title = metadata.optString("title", id),
            creator = metadata.optString("creator", "Creator"),
            url = url,
            license = license,
            bytesHint = pick.size,
        )
    }

    // -------------------- DOWNLOAD --------------------

    data class DownloadResult(val ok: Boolean, val path: String?, val downloadId: Long = -1L, val error: String? = null)

    /**
     * Primary: system DownloadManager.
     * Fallback: direct HTTP into app Music dir with min size check.
     */
    suspend fun downloadAudio(context: Context, item: AudioItem): DownloadResult = withContext(Dispatchers.IO) {
        if (!probeUrl(item.url, 8_000L)) {
            return@withContext DownloadResult(false, null, error = "Source URL unreachable")
        }
        // Try DownloadManager first
        try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val req = DownloadManager.Request(Uri.parse(item.url))
                .setTitle(item.title)
                .setDescription("${item.artist} · TEXWAVE")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setMimeType("audio/mpeg")
            val fileName = item.fileName.ifBlank { "${item.id}.mp3" }.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            try {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "TEXWAVE/$fileName")
            } catch (_: Exception) {
                req.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MUSIC, fileName)
            }
            val id = dm.enqueue(req)
            // Wait briefly for completion (up to ~3 min polling)
            val deadline = System.currentTimeMillis() + 180_000L
            while (System.currentTimeMillis() < deadline) {
                val st = queryDmStatus(context, id)
                when (st) {
                    "READY" -> {
                        val path = resolveDmPath(context, id)
                        if (path != null) return@withContext DownloadResult(true, path, id)
                        break
                    }
                    "FAILED" -> break
                    else -> kotlinx.coroutines.delay(1000)
                }
            }
        } catch (_: Exception) {
        }
        // HTTP fallback
        ioMutex.withLock {
            try {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
                val out = File(dir, item.fileName.ifBlank { "${item.id}.mp3" }.replace(Regex("[^a-zA-Z0-9._-]"), "_"))
                val c = (URL(item.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 120_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "TEXWAVE/7.2")
                }
                try {
                    if (c.responseCode !in 200..299) {
                        return@withContext DownloadResult(false, null, error = "HTTP ${c.responseCode}")
                    }
                    c.inputStream.use { input ->
                        FileOutputStream(out).use { output -> input.copyTo(output) }
                    }
                    if (out.length() < 12_000L) {
                        out.delete()
                        return@withContext DownloadResult(false, null, error = "File too small")
                    }
                    return@withContext DownloadResult(true, out.absolutePath, -1L)
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                return@withContext DownloadResult(false, null, error = e.message)
            }
        }
    }

    fun queryDmStatus(context: Context, id: Long): String {
        if (id < 0) return "NONE"
        return try {
            val c = (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager)
                .query(DownloadManager.Query().setFilterById(id)) ?: return "QUEUED"
            c.use {
                if (!it.moveToFirst()) return "QUEUED"
                when (it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                    DownloadManager.STATUS_SUCCESSFUL -> "READY"
                    DownloadManager.STATUS_FAILED -> "FAILED"
                    DownloadManager.STATUS_RUNNING -> "DOWNLOADING"
                    DownloadManager.STATUS_PAUSED -> "PAUSED"
                    else -> "QUEUED"
                }
            }
        } catch (_: Exception) {
            "QUEUED"
        }
    }

    fun resolveDmPath(context: Context, id: Long): String? {
        if (id < 0) return null
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = dm.query(DownloadManager.Query().setFilterById(id)) ?: return null
        cursor.use {
            if (!it.moveToFirst()) return null
            if (it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_SUCCESSFUL) return null
            val uri = dm.getUriForDownloadedFile(id) ?: return null
            if (uri.scheme == "file") return uri.path
            val local = File(context.getExternalFilesDir(Environment.DIRECTORY_MUSIC), "dm_$id.mp3")
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(local).use { output -> input.copyTo(output) }
                }
                if (local.exists() && local.length() > 12_000L) return local.absolutePath
            } catch (_: Exception) {
            }
            return uri.toString()
        }
    }
}

    data class Shelf(val id: String, val title: String, val query: String)

    /** Spotify-like fixed shelves — each query is resolved by searchAudio */
    val streamShelves: List<Shelf> = listOf(
        Shelf("focus", "Focus", "piano ambient study"),
        Shelf("lofi", "Lo-Fi Beats", "lofi chill"),
        Shelf("jazz", "Jazz", "jazz instrumental"),
        Shelf("electronic", "Electronic", "electronic ambient"),
        Shelf("classical", "Classical", "classical orchestra"),
        Shelf("world", "World", "world folk acoustic"),
        Shelf("sleep", "Sleep", "sleep ambient drone"),
        Shelf("guitar", "Guitar", "acoustic guitar"),
    )

    suspend fun loadShelf(shelf: Shelf, limit: Int = 12): List<AudioItem> =
        searchAudio(shelf.query, limit = limit)

    suspend fun loadHomeShelves(perShelf: Int = 10): List<Pair<Shelf, List<AudioItem>>> = coroutineScope {
        streamShelves.map { shelf ->
            async {
                shelf to runCatching { loadShelf(shelf, perShelf) }.getOrDefault(emptyList())
            }
        }.awaitAll().filter { it.second.isNotEmpty() }
    }
