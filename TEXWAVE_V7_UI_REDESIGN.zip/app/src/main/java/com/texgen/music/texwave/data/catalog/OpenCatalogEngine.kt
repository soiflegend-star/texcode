package com.texgen.music.texwave.data.catalog

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Real catalog engine for open-license audio/video from Internet Archive.
 */
object OpenCatalogEngine {

    data class AudioItem(
        val id: String,
        val title: String,
        val artist: String,
        val fileName: String,
        val url: String,
        val license: String,
        val bytesHint: Long = 0L,
    )

    data class VideoItem(
        val id: String,
        val title: String,
        val creator: String,
        val url: String,
        val license: String,
        val bytesHint: Long = 0L,
    )

    data class DownloadResult(
        val ok: Boolean,
        val path: String?,
        val downloadId: Long = -1L,
        val error: String? = null,
    )

    data class Shelf(val id: String, val title: String, val query: String)

    private val probeCache = ConcurrentHashMap<String, Boolean>()
    private val ioMutex = Mutex()

    val streamShelves: List<Shelf> = listOf(
        Shelf("focus", "Focus", "piano ambient study"),
        Shelf("lofi", "Lo-Fi Beats", "lofi chill"),
        Shelf("jazz", "Jazz", "jazz instrumental"),
        Shelf("electronic", "Electronic", "electronic ambient"),
        Shelf("classical", "Classical", "classical orchestra"),
        Shelf("world", "World", "world folk acoustic"),
        Shelf("sleep", "Sleep", "sleep ambient drone"),
        Shelf("guitar", "Guitar", "acoustic guitar"),
    )

    private fun httpJson(url: String, timeoutMs: Int = 18_000): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "TEXWAVE/7.2 CatalogEngine")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (body.isBlank()) JSONObject() else JSONObject(body)
        } finally {
            c.disconnect()
        }
    }

    fun probeUrl(url: String, minBytes: Long = 8_000L): Boolean {
        probeCache[url]?.let { return it }
        val ok = try {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 8_000
                readTimeout = 8_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "TEXWAVE/7.2")
            }
            try {
                val code = c.responseCode
                val len = c.contentLengthLong
                code in 200..399 && (len <= 0 || len >= minBytes)
            } finally {
                c.disconnect()
            }
        } catch (_: Exception) {
            try {
                val c = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8_000
                    readTimeout = 8_000
                    setRequestProperty("Range", "bytes=0-2047")
                    setRequestProperty("User-Agent", "TEXWAVE/7.2")
                }
                try {
                    c.responseCode in 200..399
                } finally {
                    c.disconnect()
                }
            } catch (_: Exception) {
                false
            }
        }
        probeCache[url] = ok
        return ok
    }

    private fun licenseOk(license: String): Boolean {
        val l = license.lowercase()
        if (l.isBlank()) return true
        return listOf("publicdomain", "creative commons", "cc0", "cc-by", "cc by", "attribution").any { l.contains(it) } ||
            !listOf("all rights reserved", "copyrighted").any { l.contains(it) }
    }

    private fun encodePath(name: String): String =
        name.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }

    private fun resolveAudio(id: String): AudioItem? {
        val meta = httpJson("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}")
        val metadata = meta.optJSONObject("metadata") ?: return null
        val license = metadata.optString("licenseurl", metadata.optString("license_url", ""))
        if (!licenseOk(license)) return null
        val files = meta.optJSONArray("files") ?: return null
        data class Cand(val name: String, val size: Long)
        val cands = mutableListOf<Cand>()
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name")
            if (name.contains("../")) continue
            val lower = name.lowercase()
            val okExt = lower.endsWith(".mp3") || lower.endsWith(".ogg") || lower.endsWith(".m4a") || lower.endsWith(".flac")
            if (!okExt) continue
            val size = f.optString("size").toLongOrNull() ?: Long.MAX_VALUE
            cands += Cand(name, size)
        }
        val pick = cands
            .sortedWith(
                compareBy<Cand> { size ->
                    when {
                        size in 500_000..40_000_000 -> 0
                        size < 500_000 -> 1
                        else -> 2
                    }
                }.thenBy { it.size },
            )
            .firstOrNull() ?: return null
        val url = "https://archive.org/download/${URLEncoder.encode(id, "UTF-8")}/${encodePath(pick.name)}"
        return AudioItem(
            id = id,
            title = metadata.optString("title", id),
            artist = metadata.optString("creator", "Artist"),
            fileName = pick.name.substringAfterLast('/'),
            url = url,
            license = license,
            bytesHint = pick.size,
        )
    }

    private fun resolveVideo(id: String): VideoItem? {
        val meta = httpJson("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}")
        val metadata = meta.optJSONObject("metadata") ?: return null
        val license = metadata.optString("licenseurl", metadata.optString("license_url", ""))
        if (!licenseOk(license)) return null
        val files = meta.optJSONArray("files") ?: return null
        data class Cand(val name: String, val size: Long)
        val cands = mutableListOf<Cand>()
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name")
            if (name.contains("../")) continue
            val okExt = name.endsWith(".mp4", true) || name.endsWith(".webm", true)
            if (!okExt) continue
            val size = f.optString("size").toLongOrNull() ?: Long.MAX_VALUE
            cands += Cand(name, size)
        }
        val pick = cands
            .sortedWith(
                compareBy<Cand> { size ->
                    when {
                        size in 2_000_000..80_000_000 -> 0
                        size < 2_000_000 -> 1
                        else -> 2
                    }
                }.thenBy { it.size },
            )
            .firstOrNull() ?: return null
        val url = "https://archive.org/download/${URLEncoder.encode(id, "UTF-8")}/${encodePath(pick.name)}"
        return VideoItem(
            id = id,
            title = metadata.optString("title", id),
            creator = metadata.optString("creator", "Creator"),
            url = url,
            license = license,
            bytesHint = pick.size,
        )
    }

    suspend fun searchAudio(query: String, limit: Int = 20): List<AudioItem> = withContext(Dispatchers.IO) {
        val q = query.trim().ifBlank { "creative commons music" }
        val encoded = URLEncoder.encode(q, "UTF-8")
        val url =
            "https://archive.org/advancedsearch.php?q=$encoded+AND+mediatype:(audio)&fl[]=identifier&fl[]=title&rows=${limit * 2}&page=1&output=json"
        val root = httpJson(url)
        val docs = root.optJSONObject("response")?.optJSONArray("docs") ?: return@withContext emptyList()
        val ids = (0 until docs.length()).mapNotNull { docs.optJSONObject(it)?.optString("identifier") }.filter { it.isNotBlank() }
        coroutineScope {
            ids.take(limit * 2).map { id ->
                async {
                    runCatching {
                        val item = resolveAudio(id) ?: return@async null
                        if (probeUrl(item.url)) item else null
                    }.getOrNull()
                }
            }.awaitAll().filterNotNull().take(limit)
        }
    }

    suspend fun searchVideo(query: String, limit: Int = 12): List<VideoItem> = withContext(Dispatchers.IO) {
        val q = query.trim().ifBlank { "creative commons film" }
        val encoded = URLEncoder.encode(q, "UTF-8")
        val url =
            "https://archive.org/advancedsearch.php?q=$encoded+AND+mediatype:(movies)&fl[]=identifier&fl[]=title&rows=${limit * 2}&page=1&output=json"
        val root = httpJson(url)
        val docs = root.optJSONObject("response")?.optJSONArray("docs") ?: return@withContext emptyList()
        val ids = (0 until docs.length()).mapNotNull { docs.optJSONObject(it)?.optString("identifier") }.filter { it.isNotBlank() }
        coroutineScope {
            ids.take(limit * 2).map { id ->
                async {
                    runCatching {
                        val item = resolveVideo(id) ?: return@async null
                        if (probeUrl(item.url, 50_000L)) item else null
                    }.getOrNull()
                }
            }.awaitAll().filterNotNull().take(limit)
        }
    }

    suspend fun loadShelf(shelf: Shelf, limit: Int = 12): List<AudioItem> =
        searchAudio(shelf.query, limit = limit)

    suspend fun loadHomeShelves(perShelf: Int = 10): List<Pair<Shelf, List<AudioItem>>> = coroutineScope {
        streamShelves.map { shelf ->
            async {
                shelf to runCatching { loadShelf(shelf, perShelf) }.getOrDefault(emptyList())
            }
        }.awaitAll().filter { it.second.isNotEmpty() }
    }

    private fun queryDmStatus(context: Context, id: Long): String {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val q = DownloadManager.Query().setFilterById(id)
        dm.query(q)?.use { c ->
            if (!c.moveToFirst()) return "UNKNOWN"
            val col = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
            return when (if (col >= 0) c.getInt(col) else -1) {
                DownloadManager.STATUS_SUCCESSFUL -> "READY"
                DownloadManager.STATUS_FAILED -> "FAILED"
                DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PENDING, DownloadManager.STATUS_PAUSED -> "RUNNING"
                else -> "UNKNOWN"
            }
        }
        return "UNKNOWN"
    }

    private fun resolveDmPath(context: Context, id: Long): String? {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val q = DownloadManager.Query().setFilterById(id)
        dm.query(q)?.use { c ->
            if (!c.moveToFirst()) return null
            val idx = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
            if (idx < 0) return null
            val uri = Uri.parse(c.getString(idx) ?: return null)
            if (uri.scheme == "file") return uri.path
            return uri.toString()
        }
        return null
    }

    suspend fun downloadAudio(context: Context, item: AudioItem): DownloadResult = withContext(Dispatchers.IO) {
        if (!probeUrl(item.url, 8_000L)) {
            return@withContext DownloadResult(false, null, error = "Source URL unreachable")
        }
        try {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val req = DownloadManager.Request(Uri.parse(item.url))
                .setTitle(item.title)
                .setDescription("${item.artist} · TEXWAVE")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setMimeType("audio/mpeg")
            val fileName = item.fileName.ifBlank { "${item.id}.mp3" }.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            try {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "TEXWAVE/$fileName")
            } catch (_: Exception) {
                req.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MUSIC, fileName)
            }
            val id = dm.enqueue(req)
            val deadline = System.currentTimeMillis() + 180_000L
            while (System.currentTimeMillis() < deadline) {
                when (queryDmStatus(context, id)) {
                    "READY" -> {
                        val path = resolveDmPath(context, id)
                        if (path != null) return@withContext DownloadResult(true, path, id)
                        break
                    }
                    "FAILED" -> break
                    else -> kotlinx.coroutines.delay(1000)
                }
            }
        } catch (_: Exception) {
        }
        ioMutex.withLock {
            try {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: context.filesDir
                val out = File(dir, item.fileName.ifBlank { "${item.id}.mp3" }.replace(Regex("[^a-zA-Z0-9._-]"), "_"))
                val c = (URL(item.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "TEXWAVE/7.2")
                }
                try {
                    if (c.responseCode !in 200..299) {
                        return@withContext DownloadResult(false, null, error = "HTTP ${c.responseCode}")
                    }
                    c.inputStream.use { input ->
                        FileOutputStream(out).use { output -> input.copyTo(output) }
                    }
                    if (out.length() < 8_000L) {
                        out.delete()
                        return@withContext DownloadResult(false, null, error = "File too small")
                    }
                    DownloadResult(true, out.absolutePath)
                } finally {
                    c.disconnect()
                }
            } catch (e: Exception) {
                DownloadResult(false, null, error = e.message ?: "Download failed")
            }
        }
    }
}
