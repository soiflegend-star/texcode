package com.texgen.music.texwave

import android.app.Application

class TexwaveApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashGuard.install(this)
    }
}
