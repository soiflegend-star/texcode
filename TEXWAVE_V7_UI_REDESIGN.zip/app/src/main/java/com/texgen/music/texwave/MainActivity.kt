package com.texgen.music.texwave

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.MusicApp

class MainActivity : ComponentActivity() {
    // Chat presence: "online" only while the app is on screen.
    override fun onStart() {
        super.onStart()
        try { com.texgen.music.texwave.data.chat.ChatRepository.get(this).setForeground(true) } catch (_: Throwable) {}
    }

    override fun onStop() {
        try { com.texgen.music.texwave.data.chat.ChatRepository.get(this).setForeground(false) } catch (_: Throwable) {}
        super.onStop()
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        deliverWake(intent)
    }

    override fun onResume() {
        super.onResume()
        deliverWake(intent)
    }

    private fun deliverWake(intent: android.content.Intent?) {
        if (intent == null) return
        val cmd = intent.getStringExtra("wake_command")
            ?: intent.getStringExtra(com.texgen.music.texwave.player.WakeWordService.EXTRA_TEXT)
            ?: return
        if (cmd.isBlank()) return
        try {
            com.texgen.music.texwave.data.AppSettings(this).savePendingWakeCommand(cmd)
        } catch (_: Exception) {
        }
        try {
            val i = android.content.Intent(com.texgen.music.texwave.player.WakeWordService.ACTION_COMMAND).apply {
                setPackage(packageName)
                putExtra(com.texgen.music.texwave.player.WakeWordService.EXTRA_TEXT, cmd)
            }
            sendBroadcast(i)
        } catch (_: Exception) {
        }
        // Consume so we don't replay forever
        intent.removeExtra("wake_command")
        intent.removeExtra(com.texgen.music.texwave.player.WakeWordService.EXTRA_TEXT)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { enableEdgeToEdge() } catch (_: Throwable) {}
        val report = CrashGuard.pendingReport(this)
        CrashGuard.scheduleStable(this)
        setContent {
            var showReport by remember { mutableStateOf(report) }
            val r = showReport
            if (r != null) {
                CrashScreen(
                    report = r,
                    onCopy = {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Texwave crash report", r))
                        Toast.makeText(this, "Copied — paste it to Claude", Toast.LENGTH_LONG).show()
                    },
                    onOpen = {
                        CrashGuard.resetRiskyState(this)
                        CrashGuard.safeMode = true
                        CrashGuard.clearReport(this)
                        showReport = null
                        CrashGuard.scheduleStable(this)
                    },
                    onReset = {
                        CrashGuard.resetEverything(this)
                        CrashGuard.safeMode = true
                        CrashGuard.clearReport(this)
                        showReport = null
                        CrashGuard.scheduleStable(this)
                    },
                )
            } else {
                MusicApp()
            }
        }
        if (report == null) CrashGuard.scheduleStable(this)
    }
}

@androidx.compose.runtime.Composable
private fun CrashScreen(report: String, onCopy: () -> Unit, onOpen: () -> Unit, onReset: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF07070B))
            .statusBarsPadding()
            .padding(20.dp),
    ) {
        Text("Texwave closed unexpectedly", color = Color.White, fontSize = 22.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Copy the report below and send it to Claude so the exact bug can be fixed. You can still open the app in safe mode.",
            color = Color(0xFFB0B4C8),
            fontSize = 13.sp,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            report,
            color = Color(0xFFFF9AA8),
            fontSize = 10.sp,
            lineHeight = 13.sp,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF12121A))
                .padding(10.dp)
                .verticalScroll(rememberScrollState()),
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = onCopy, modifier = Modifier.fillMaxWidth()) { Text("Copy report") }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Button(onClick = onOpen, modifier = Modifier.weight(1f)) { Text("Open (safe mode)") }
            Spacer(Modifier.padding(4.dp))
            OutlinedButton(onClick = onReset, modifier = Modifier.weight(1f)) { Text("Reset app data") }
        }
    }
}
