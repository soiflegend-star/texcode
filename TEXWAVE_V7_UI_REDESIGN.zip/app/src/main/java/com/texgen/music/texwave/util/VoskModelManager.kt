package com.texgen.music.texwave.util

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Downloads Vosk English models for offline voice.
 * - Standard: ~128MB lgraph (fast, good accuracy)
 * - Large / Max: ~1.8–2.3GB full model (highest accuracy; needs free space ~4GB including unpack)
 */
class VoskModelManager(context: Context) {
    private val app = context.applicationContext
    private val root = File(app.filesDir, "vosk")
    private val prefs = app.getSharedPreferences("vosk_models", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(readState())
    val state: StateFlow<State> = _state.asStateFlow()

    enum class ModelPack(
        val id: String,
        val label: String,
        val sizeHint: String,
        val url: String,
        val dirName: String,
        val marker: String,
    ) {
        STANDARD(
            "standard",
            "Standard voice model",
            "~128 MB",
            "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip",
            "vosk-model-en-us-0.22-lgraph",
            ".ready_lgraph_v1",
        ),
        LARGE(
            "large",
            "Maximum accuracy (4 GB class)",
            "~1.8 GB download · needs ~4 GB free",
            "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22.zip",
            "vosk-model-en-us-0.22",
            ".ready_full_022_v1",
        ),
    }

    data class State(
        val ready: Boolean = false,
        val downloading: Boolean = false,
        val progress: Float = 0f,
        val error: String? = null,
        val modelPath: String? = null,
        val activePack: String = ModelPack.STANDARD.id,
        val bytesDownloaded: Long = 0L,
        val bytesTotal: Long = 0L,
    )

    private fun activePack(): ModelPack {
        val id = prefs.getString(KEY_ACTIVE, ModelPack.STANDARD.id) ?: ModelPack.STANDARD.id
        return ModelPack.entries.find { it.id == id } ?: ModelPack.STANDARD
    }

    fun isReady(): Boolean {
        val pack = activePack()
        val marker = File(root, pack.marker)
        val dir = File(root, pack.dirName)
        if (!marker.exists() || !dir.exists()) return false
        return File(dir, "am").exists() || File(dir, "conf").exists() ||
            File(dir, "ivector").exists() || dir.list()?.isNotEmpty() == true
    }

    fun modelPath(): String? = if (isReady()) File(root, activePack().dirName).absolutePath else null

    fun isPackReady(pack: ModelPack): Boolean {
        val marker = File(root, pack.marker)
        val dir = File(root, pack.dirName)
        if (!marker.exists() || !dir.exists()) return false
        return dir.list()?.isNotEmpty() == true
    }

    private fun readState(): State {
        val pack = activePack()
        val path = modelPath()
        return State(
            ready = path != null,
            modelPath = path,
            activePack = pack.id,
        )
    }

    fun refresh() {
        _state.value = readState().copy(
            downloading = _state.value.downloading,
            progress = _state.value.progress,
            bytesDownloaded = _state.value.bytesDownloaded,
            bytesTotal = _state.value.bytesTotal,
        )
    }

    fun setActivePack(pack: ModelPack) {
        prefs.edit().putString(KEY_ACTIVE, pack.id).apply()
        refresh()
    }

    /** Download [pack] (standard or large/max). Large needs ~4GB free space while unpacking. */
    suspend fun ensureModel(pack: ModelPack = activePack()): Result<String> = withContext(Dispatchers.IO) {
        prefs.edit().putString(KEY_ACTIVE, pack.id).apply()
        if (isPackReady(pack)) {
            val p = File(root, pack.dirName).absolutePath
            _state.value = State(ready = true, modelPath = p, activePack = pack.id)
            return@withContext Result.success(p)
        }
        _state.value = State(downloading = true, progress = 0f, activePack = pack.id)
        try {
            root.mkdirs()
            // Free space check for large model
            if (pack == ModelPack.LARGE) {
                val free = root.usableSpace
                if (free < 3_500_000_000L) {
                    val msg = "Need about 4 GB free space (have ${free / 1_000_000} MB)."
                    _state.value = State(ready = false, downloading = false, error = msg, activePack = pack.id)
                    return@withContext Result.failure(IllegalStateException(msg))
                }
            }
            val zip = File(root, "${pack.dirName}.zip")
            download(pack.url, zip) { read, total ->
                val prog = if (total > 0) (read.toFloat() / total).coerceIn(0f, 1f) else 0f
                _state.value = State(
                    downloading = true,
                    progress = prog * 0.85f,
                    activePack = pack.id,
                    bytesDownloaded = read,
                    bytesTotal = total,
                )
            }
            _state.value = State(downloading = true, progress = 0.88f, activePack = pack.id)
            val target = File(root, pack.dirName)
            if (target.exists()) target.deleteRecursively()
            unzip(zip, root)
            // zip often extracts to folder named pack.dirName already
            if (!target.exists()) {
                // find extracted folder
                root.listFiles()?.firstOrNull { it.isDirectory && it.name.startsWith("vosk-model") }?.let { found ->
                    if (found.name != pack.dirName) found.renameTo(target)
                }
            }
            try { zip.delete() } catch (_: Exception) {}
            File(root, pack.marker).writeText("ok")
            val path = target.absolutePath
            _state.value = State(ready = true, modelPath = path, activePack = pack.id, progress = 1f)
            Result.success(path)
        } catch (e: Exception) {
            _state.value = State(ready = false, downloading = false, progress = 0f, error = e.message, activePack = pack.id)
            Result.failure(e)
        }
    }

    private fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("User-Agent", "TexwaveMusic/6.9 (Android; Vosk)")
            connectTimeout = 45_000
            readTimeout = 600_000
            instanceFollowRedirects = true
        }
        val total = conn.contentLengthLong
        BufferedInputStream(conn.inputStream).use { input ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(256 * 1024)
                var readTotal = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n <= 0) break
                    out.write(buf, 0, n)
                    readTotal += n
                    onProgress(readTotal, total)
                }
            }
        }
    }

    private fun unzip(zip: File, target: File) {
        ZipInputStream(BufferedInputStream(zip.inputStream())).use { zis ->
            var entry = zis.nextEntry
            val buf = ByteArray(256 * 1024)
            while (entry != null) {
                val outFile = File(target, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out ->
                        while (true) {
                            val n = zis.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    companion object {
        private const val KEY_ACTIVE = "active_pack"
        /** @deprecated use ModelPack.STANDARD.url */
        const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip"
        const val MODEL_DIR_NAME = "vosk-model-en-us-0.22-lgraph"
        private const val READY_MARKER = ".ready_lgraph_v1"
    }
}
