package com.texgen.music.texwave.notification

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import androidx.core.graphics.ColorUtils
import com.texgen.music.texwave.util.SoifLogo
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Draws one square frame of the notification artwork. Android notifications cannot run a live
 * animation, so the "animation" is a sequence of these frames swapped in a few times a second.
 *
 * Pure function of its inputs (style + frame number), so the in-app preview and the real
 * notification always look identical.
 */
object NotifArtRenderer {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Seconds of animation time advanced per frame. */
    private const val STEP = 0.7f

    @Synchronized
    fun render(
        size: Int,
        style: String,
        frame: Int,
        base: Bitmap?,
        videoFrame: Bitmap?,
        seed: String,
        accent: Int,
        accent2: Int,
        showLogo: Boolean,
        lyricsLines: List<String> = emptyList(),
    ): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size.toFloat()
        val t = frame * STEP

        when (style) {
            "video" -> {
                drawCover(c, videoFrame ?: base, s, seed)
                scrim(c, s, 0, 0x22)
            }
            "vinyl" -> drawVinyl(c, s, t, base, seed, accent)
            "galaxy" -> {
                drawCover(c, base, s, seed)
                scrim(c, s, 0, 0xB8)
                drawGalaxy(c, s, t, accent, accent2)
            }
            "neon_grid" -> drawNeonGrid(c, s, t, base, accent, accent2)
            "wave" -> {
                drawCover(c, base, s, seed)
                scrim(c, s, 0, 0x30)
                drawWave(c, s, t, accent, accent2)
            }
            "pulse" -> {
                drawCover(c, base, s, seed)
                scrim(c, s, 0, 0x20)
                drawPulse(c, s, t, accent, accent2)
            }
            "particles" -> {
                drawCover(c, base, s, seed)
                scrim(c, s, 0, 0x58)
                drawParticles(c, s, t, accent, accent2)
            }
            "lyrics" -> {
                drawCover(c, base, s, seed)
                // Thin bottom gap only — not full art takeover
                reset()
                paint.color = withAlpha(0xFF000000.toInt(), 160)
                c.drawRect(0f, s * 0.78f, s, s, paint)
                c.save()
                c.clipRect(0f, s * 0.78f, s, s)
                drawLyricsRise(c, s, t, accent, accent2, lyricsLines.ifEmpty { seed.split(" ").filter { it.isNotBlank() } })
                c.restore()
            }
            "spectrum" -> {
                drawCover(c, base, s, seed)
                scrim(c, s, 0, 0x70)
                drawSpectrum(c, s, t, accent, accent2)
            }
            "liquid" -> {
                drawCover(c, base, s, seed)
                drawLiquid(c, s, t, accent, accent2)
            }
            else -> drawCover(c, base, s, seed)
        }

        if (showLogo) drawLogo(c, s, accent, accent2)
        return bmp
    }

    // ---- building blocks ------------------------------------------------------------

    private fun reset() {
        paint.reset()
        paint.isAntiAlias = true
    }

    private fun rnd(i: Int, salt: Int): Float {
        var x = i * 374761393 + salt * 668265263
        x = (x xor (x ushr 13)) * 1274126177
        x = x xor (x ushr 16)
        return (x and 0xFFFFFF) / 16777215f
    }

    private fun withAlpha(color: Int, alpha: Int): Int = ColorUtils.setAlphaComponent(color, alpha.coerceIn(0, 255))

    private fun drawCover(c: Canvas, bmp: Bitmap?, s: Float, seed: String) {
        reset()
        if (bmp != null) {
            c.drawBitmap(bmp, null, RectF(0f, 0f, s, s), paint)
            return
        }
        val hue = (abs(seed.hashCode()) % 360).toFloat()
        val c1 = Color.HSVToColor(floatArrayOf(hue, 0.68f, 0.94f))
        val c2 = Color.HSVToColor(floatArrayOf((hue + 48f) % 360f, 0.82f, 0.48f))
        paint.shader = LinearGradient(0f, 0f, s, s, c1, c2, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, paint)
    }

    /** Vertical darkening: [top] and [bottom] are 0..255 alpha values. */
    private fun scrim(c: Canvas, s: Float, top: Int, bottom: Int) {
        reset()
        paint.shader = LinearGradient(0f, 0f, 0f, s, withAlpha(Color.BLACK, top), withAlpha(Color.BLACK, bottom), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, paint)
    }

    private fun drawLogo(c: Canvas, s: Float, accent: Int, accent2: Int) {
        reset()
        paint.shader = LinearGradient(0f, s * 0.60f, 0f, s, 0x00000000, 0xD0000000.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, s * 0.60f, s, s, paint)
        SoifLogo.draw(
            canvas = c,
            cx = s / 2f,
            cy = s * 0.885f,
            width = s * 0.46f,
            color1 = ColorUtils.blendARGB(accent, Color.WHITE, 0.25f),
            color2 = ColorUtils.blendARGB(accent2, Color.WHITE, 0.25f),
            glow = true,
        )
    }

    // ---- styles ---------------------------------------------------------------------

    private fun drawWave(c: Canvas, s: Float, t: Float, accent: Int, accent2: Int) {
        val n = 22
        val gap = s * 0.012f
        val bw = (s - gap * (n + 1)) / n
        val baseline = s * 0.80f
        reset()
        paint.shader = LinearGradient(0f, s * 0.38f, 0f, baseline, accent2, accent, Shader.TileMode.CLAMP)
        paint.alpha = 235
        for (i in 0 until n) {
            val a = 0.5f + 0.5f * sin(t * 2.4f + i * 0.6f)
            val b = 0.5f + 0.5f * sin(t * 1.5f + i * 1.9f)
            val h = s * (0.07f + 0.36f * (0.65f * a + 0.35f * b))
            val x = gap + i * (bw + gap)
            c.drawRoundRect(RectF(x, baseline - h, x + bw, baseline), bw / 2f, bw / 2f, paint)
        }
    }

    private fun drawPulse(c: Canvas, s: Float, t: Float, accent: Int, accent2: Int) {
        val cx = s / 2f
        val cy = s * 0.45f
        val r = s * (0.50f + 0.12f * sin(t * 1.8f))
        reset()
        paint.shader = RadialGradient(
            cx, cy, r,
            intArrayOf(withAlpha(accent, 170), withAlpha(accent2, 70), 0x00000000),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP,
        )
        c.drawCircle(cx, cy, r, paint)
        // expanding ring
        val phase = (t * 0.3f) % 1f
        reset()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.012f
        paint.color = withAlpha(Color.WHITE, ((1f - phase) * 150).toInt())
        c.drawCircle(cx, cy, s * (0.12f + 0.40f * phase), paint)
    }

    private fun drawVinyl(c: Canvas, s: Float, t: Float, base: Bitmap?, seed: String, accent: Int) {
        reset()
        paint.shader = LinearGradient(0f, 0f, s, s, 0xFF1A1A22.toInt(), 0xFF050507.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, paint)

        val cx = s / 2f
        val cy = s * 0.44f
        val r = s * 0.38f
        val angle = frameAngle(t)

        // disc body
        reset()
        paint.color = 0xFF0C0C10.toInt()
        c.drawCircle(cx, cy, r, paint)
        // grooves
        reset()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f
        paint.color = withAlpha(Color.WHITE, 26)
        var gr = r * 0.46f
        while (gr < r - 2f) {
            c.drawCircle(cx, cy, gr, paint)
            gr += r * 0.045f
        }
        // rotating sheen
        c.save()
        c.rotate(angle, cx, cy)
        reset()
        paint.shader = SweepGradient(
            cx, cy,
            intArrayOf(0x00FFFFFF, 0x38FFFFFF, 0x00FFFFFF, 0x38FFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.12f, 0.5f, 0.62f, 1f),
        )
        c.drawCircle(cx, cy, r, paint)
        // label with the cover
        val lr = r * 0.40f
        val clip = Path().apply { addCircle(cx, cy, lr, Path.Direction.CW) }
        c.save()
        c.clipPath(clip)
        drawCoverInto(c, base, RectF(cx - lr, cy - lr, cx + lr, cy + lr), seed)
        c.restore()
        c.restore()
        // spindle
        reset()
        paint.color = 0xFF0C0C10.toInt()
        c.drawCircle(cx, cy, r * 0.045f, paint)
        // tone arm
        reset()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.016f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = withAlpha(accent, 220)
        c.drawLine(s * 0.93f, s * 0.07f, s * 0.70f, s * 0.34f, paint)
        reset()
        paint.color = withAlpha(Color.WHITE, 230)
        c.drawCircle(s * 0.93f, s * 0.07f, s * 0.028f, paint)
    }

    private fun frameAngle(t: Float): Float = (t / STEP) * 30f

    private fun drawCoverInto(c: Canvas, bmp: Bitmap?, dst: RectF, seed: String) {
        reset()
        if (bmp != null) {
            c.drawBitmap(bmp, null, dst, paint)
            return
        }
        val hue = (abs(seed.hashCode()) % 360).toFloat()
        paint.shader = LinearGradient(
            dst.left, dst.top, dst.right, dst.bottom,
            Color.HSVToColor(floatArrayOf(hue, 0.68f, 0.94f)),
            Color.HSVToColor(floatArrayOf((hue + 48f) % 360f, 0.82f, 0.48f)),
            Shader.TileMode.CLAMP,
        )
        c.drawRect(dst, paint)
    }

                /** Instagram-style small pure snow for notification art background. */
    private fun drawParticles(c: Canvas, s: Float, t: Float, accent: Int, accent2: Int) {
        val n = 55
        for (i in 0 until n) {
            val x0 = rnd(i, 11)
            val speed = 0.012f + 0.03f * rnd(i, 12)
            val phase = rnd(i, 13)
            val y = ((phase + t * speed) % 1f)
            val sway = 0.02f * sin(t * 0.4f + i * 0.65f)
            val x = ((x0 + sway) % 1f + 1f) % 1f
            val r = s * (0.004f + 0.006f * rnd(i, 14))
            reset()
            paint.color = withAlpha(Color.WHITE, (160 + 60 * rnd(i, 15)).toInt().coerceIn(120, 230))
            c.drawCircle(x * s, y * s, r, paint)
        }
    }


    private fun drawSpectrum(c: Canvas, s: Float, t: Float, accent: Int, accent2: Int) {
        val n = 13 // per side, mirrored around the centre
        val gap = s * 0.014f
        val bw = (s * 0.92f - gap * (2 * n - 1)) / (2 * n)
        val mid = s * 0.44f
        reset()
        paint.shader = LinearGradient(0f, mid - s * 0.34f, 0f, mid + s * 0.34f, accent2, accent, Shader.TileMode.CLAMP)
        for (i in 0 until n) {
            val a = 0.5f + 0.5f * sin(t * 2.1f + i * 0.8f)
            val b = 0.5f + 0.5f * sin(t * 1.3f + i * 2.3f)
            val energy = (1f - i / (n * 1.25f)) // low bands hit harder
            val h = s * (0.05f + 0.30f * energy * (0.6f * a + 0.4f * b))
            val offset = i * (bw + gap)
            val right = s / 2f + gap / 2f + offset
            val left = s / 2f - gap / 2f - offset - bw
            c.drawRoundRect(RectF(right, mid - h, right + bw, mid + h), bw / 2f, bw / 2f, paint)
            c.drawRoundRect(RectF(left, mid - h, left + bw, mid + h), bw / 2f, bw / 2f, paint)
        }
    }

    private fun drawGalaxy(c: Canvas, s: Float, t: Float, accent: Int, accent2: Int) {
        // stars
        for (i in 0 until 70) {
            val tw = 0.5f + 0.5f * sin(t * 1.7f + i * 2.1f)
            reset()
            paint.color = withAlpha(Color.WHITE, (70 + 170 * tw).toInt())
            c.drawCircle(rnd(i, 11) * s, rnd(i, 12) * s * 0.88f, s * (0.0025f + 0.005f * rnd(i, 13)), paint)
        }
        // spiral
        val cx = s / 2f
        val cy = s * 0.44f
        val total = 150
        for (k in 0 until total) {
            val f = k / total.toFloat()
            val ang = k * 0.21f + t * 0.5f
            val rad = f * s * 0.42f
            val x = cx + cos(ang) * rad
            val y = cy + sin(ang) * rad * 0.55f
            reset()
            paint.color = withAlpha(ColorUtils.blendARGB(accent, accent2, f), (230 - 160 * f).toInt())
            c.drawCircle(x, y, s * (0.012f - 0.007f * f), paint)
        }
        // core glow
        reset()
        paint.shader = RadialGradient(
            cx, cy, s * 0.14f,
            intArrayOf(withAlpha(Color.WHITE, 230), withAlpha(accent, 90), 0x00000000),
            floatArrayOf(0f, 0.4f, 1f),
            Shader.TileMode.CLAMP,
        )
        c.drawCircle(cx, cy, s * 0.14f, paint)
    }

    private fun drawLiquid(c: Canvas, s: Float, t: Float, accent: Int, accent2: Int) {
        val cx = s / 2f
        val cy = s / 2f
        val screen = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        for (band in 0 until 2) {
            val ang = t * (0.32f + 0.18f * band) + band * 1.9f
            val dx = cos(ang) * s
            val dy = sin(ang) * s
            reset()
            paint.shader = LinearGradient(
                cx - dx / 2f, cy - dy / 2f, cx + dx / 2f, cy + dy / 2f,
                intArrayOf(
                    0x00FFFFFF,
                    withAlpha(if (band == 0) Color.WHITE else accent2, 120),
                    withAlpha(accent, 40),
                    withAlpha(if (band == 0) accent2 else Color.WHITE, 120),
                    0x00FFFFFF,
                ),
                floatArrayOf(0f, 0.3f, 0.5f, 0.7f, 1f),
                Shader.TileMode.CLAMP,
            )
            paint.xfermode = screen
            c.drawRect(0f, 0f, s, s, paint)
        }
        reset()
        paint.color = withAlpha(accent, 34)
        c.drawRect(0f, 0f, s, s, paint)
    }

    private fun drawNeonGrid(c: Canvas, s: Float, t: Float, base: Bitmap?, accent: Int, accent2: Int) {
        val hy = s * 0.50f
        reset()
        paint.shader = LinearGradient(0f, 0f, 0f, s, 0xFF1B0638.toInt(), 0xFF07020F.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, paint)

        // sun
        reset()
        paint.shader = LinearGradient(0f, hy - s * 0.30f, 0f, hy, accent, accent2, Shader.TileMode.CLAMP)
        c.save()
        c.clipRect(0f, 0f, s, hy)
        c.drawCircle(s / 2f, hy - s * 0.02f, s * 0.27f, paint)
        c.restore()

        // cover on the sun
        if (base != null) {
            val cs = s * 0.30f
            val rect = RectF(s / 2f - cs / 2f, hy - cs * 1.08f, s / 2f + cs / 2f, hy - cs * 0.08f)
            c.save()
            val clip = Path().apply { addRoundRect(rect, s * 0.03f, s * 0.03f, Path.Direction.CW) }
            c.clipPath(clip)
            reset()
            c.drawBitmap(base, null, rect, paint)
            c.restore()
        }

        // floor
        reset()
        paint.color = 0xFF0A0314.toInt()
        c.drawRect(0f, hy, s, s, paint)

        reset()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.006f
        // perspective rails
        for (k in -9..9) {
            paint.color = withAlpha(accent2, 150)
            c.drawLine(s / 2f + k * s * 0.012f, hy, s / 2f + k * s * 0.16f, s, paint)
        }
        // scrolling cross lines
        val scroll = (t * 0.35f) % 1f
        for (j in 0 until 8) {
            val z = (j + scroll) / 8f
            val y = hy + (s - hy) * z * z
            paint.color = withAlpha(accent, (60 + 190 * z).toInt())
            c.drawLine(0f, y, s, y, paint)
        }
        // horizon glow + scan line
        reset()
        paint.color = withAlpha(accent2, 200)
        c.drawRect(0f, hy - 2f, s, hy + 2f, paint)
        val scanY = ((t * 0.22f) % 1f) * s
        reset()
        paint.color = withAlpha(Color.WHITE, 26)
        c.drawRect(0f, scanY, s, scanY + s * 0.012f, paint)
    }

    /** Lyrics rise from bottom, fade in, drift up, fade out. */
    private fun drawLyricsRise(
        c: Canvas,
        s: Float,
        t: Float,
        accent: Int,
        accent2: Int,
        lines: List<String>,
    ) {
        if (lines.isEmpty()) return
        val cycle = lines.size.coerceAtLeast(1)
        val speed = 0.085f
        for (i in 0 until cycle * 2) {
            val line = lines[i % cycle]
            val phase = ((t * speed) + i * 0.18f) % 1.2f
            if (phase > 1f) continue
            val y = s * (1.05f - phase * 1.15f)
            val alphaF = when {
                phase < 0.12f -> phase / 0.12f
                phase > 0.72f -> ((1f - phase) / 0.28f).coerceIn(0f, 1f)
                else -> 1f
            }
            val a = (alphaF * 230).toInt().coerceIn(0, 255)
            val textSize = s * (0.055f + 0.01f * (i % 3))
            reset()
            paint.textAlign = Paint.Align.CENTER
            paint.isFakeBoldText = true
            paint.textSize = textSize
            paint.color = withAlpha(0xFF000000.toInt(), (a * 0.55f).toInt())
            paint.maskFilter = BlurMaskFilter(s * 0.012f, BlurMaskFilter.Blur.NORMAL)
            c.drawText(line, s * 0.5f, y + s * 0.008f, paint)
            reset()
            paint.textAlign = Paint.Align.CENTER
            paint.isFakeBoldText = true
            paint.textSize = textSize
            paint.color = withAlpha(0xFFFFFFFF.toInt(), a)
            c.drawText(line, s * 0.5f, y, paint)
            if (phase in 0.2f..0.45f) {
                val uw = paint.measureText(line).coerceAtMost(s * 0.7f)
                reset()
                paint.color = withAlpha(accent, (a * 0.5f).toInt())
                paint.strokeWidth = s * 0.006f
                paint.style = Paint.Style.STROKE
                c.drawLine(s * 0.5f - uw / 2f, y + s * 0.02f, s * 0.5f + uw / 2f, y + s * 0.02f, paint)
            }
        }
    }

}
