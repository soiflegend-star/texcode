package com.texgen.music.texwave.ui.screens.chat

import androidx.compose.foundation.background
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.Profile
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import com.texgen.music.texwave.data.chat.avatarModel
import com.texgen.music.texwave.data.chat.isUserOnline

@Composable
fun UserSearchScreen(
    repo: ChatRepository,
    onBack: () -> Unit,
    onStartChat: (conversationId: String, title: String) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Profile>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var searched by remember { mutableStateOf("") }   // the query the visible results belong to
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val onlineIds by repo.onlineUserIds.collectAsState()

    suspend fun runSearch(q: String) {
        loading = true
        error = null
        repo.searchUsers(q)
            .onSuccess { results = it; searched = q }
            .onFailure { error = it.message; results = emptyList() }
        loading = false
    }

    // Search while typing (short pause after the last key) and also on the keyboard's search button.
    LaunchedEffect(query) {
        val q = query.trim().removePrefix("@").trim()
        if (q.isEmpty()) {
            results = emptyList()
            searched = ""
            error = null
            loading = false
            return@LaunchedEffect
        }
        delay(300)
        runSearch(q)
    }

    Column(
        Modifier
            .fillMaxSize()
            .sonicAtmosphere()
            .statusBarsPadding()
            .padding(horizontal = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, "Back", tint = Tx.Text)
            }
            Text("Search", color = Tx.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search name, @username or email…", color = Tx.Muted) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Tx.Muted) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                val q = query.trim().removePrefix("@").trim()
                if (q.isNotEmpty()) scope.launch { runSearch(q) }
            }),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Tx.Accent,
                unfocusedBorderColor = Tx.Outline,
                focusedTextColor = Tx.Text,
                unfocusedTextColor = Tx.Text,
                cursorColor = Tx.Accent,
                focusedContainerColor = Tx.Surface,
                unfocusedContainerColor = Tx.Surface,
            ),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Find people by @username, display name, or their exact email",
            color = Tx.Muted,
            fontSize = 12.sp,
        )

        error?.let {
            Text(it, color = Tx.Danger, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
        }

        Box(Modifier.fillMaxSize().padding(top = 12.dp)) {
            LazyColumn(Modifier.fillMaxSize()) {
                items(results, key = { it.id }) { profile ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                scope.launch {
                                    repo.getOrCreateDirectConversation(profile.id)
                                        .onSuccess { cid -> onStartChat(cid, profile.displayName) }
                                        .onFailure { error = it.message }
                                }
                            }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        ChatAvatar(
                            name = profile.displayName,
                            imageUrl = profile.avatarModel,
                            size = 52.dp,
                            online = isUserOnline(profile.id, profile.lastSeenAt, onlineIds),
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(profile.displayName, color = Tx.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("@" + profile.username, color = Tx.Muted, fontSize = 13.sp)
                        }
                        Text("Chat", color = Tx.Accent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }
            if (loading && results.isEmpty()) {
                CircularProgressIndicator(
                    color = Tx.Accent,
                    strokeWidth = 2.dp,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 24.dp),
                )
            } else if (!loading && error == null && searched.isNotEmpty() && results.isEmpty()) {
                Column(
                    Modifier.align(Alignment.TopCenter).padding(top = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("No one found for \"$searched\"", color = Tx.Text, fontWeight = FontWeight.Medium)
                    Text(
                        "Check the spelling, or ask them for their @username",
                        color = Tx.Muted,
                        fontSize = 12.sp,
                    )
                }
            }
        }
    }
}
