package com.texgen.music.texwave.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.widget.RemoteViews
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.IconCompat
import androidx.media3.common.Player
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.google.common.collect.ImmutableList
import com.texgen.music.texwave.MainActivity
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.AppSettings
import com.texgen.music.texwave.data.NotifCatalog
import com.texgen.music.texwave.data.ThemeCatalog
import com.texgen.music.texwave.util.SoifLogo
import java.util.concurrent.Executors

/**
 * The Texwave media notification.
 *
 *  - five real controls: -10s, previous, play/pause, next, +10s
 *  - every song shows "SOIF" (stylised) as its artist line; the real artist moves to the sub text
 *  - the large icon is rendered by [NotifArtRenderer]: static or animated, or frames of a video
 *    the user picked. Animation = a new frame pushed to the same notification a few times a second
 *    while music is playing.
 */
class TexwaveNotificationProvider(private val context: Context) : MediaNotification.Provider {

    private val appContext = context.applicationContext
    private val settings = AppSettings(appContext)
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val nm = NotificationManagerCompat.from(appContext)

    // state captured on the main thread -------------------------------------------------
    private data class Snap(
        val key: String,
        val songId: Long,
        val title: String,
        val artist: String,
        val album: String,
        val contentUri: String,
        val albumId: Long,
        val playing: Boolean,
        val hasItem: Boolean,
    )

    private data class Config(
        val style: String,
        val styleCustomUri: String?,
        val videoFrames: Int,
        val soif: Boolean,
        val soifStyled: Boolean,
        val accent: Int,
        val accent2: Int,
        val customArt: Map<Long, String>,
    )

    /** Receives each rendered frame so the system media tile / lock screen can show it too. Main thread. */
    var artSink: ((String, Bitmap) -> Unit)? = null
    @Volatile private var lastSig: String? = null

    private var session: MediaSession? = null
    private var factory: MediaNotification.ActionFactory? = null

    @Volatile private var snap: Snap? = null
    @Volatile private var frame = 0
    @Volatile private var released = false
    @Volatile private var rendering = false

    // base art cache (single entry)
    private var baseKey: String? = null
    private var baseBmp: Bitmap? = null
    private var videoCache: Array<Bitmap?> = emptyArray()
    private var videoCacheCount = 0

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        // any setting change: redraw right away
        main.post { refreshNow() }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (released) return
            val s = snap
            val cfg = config()
            if (s != null && s.playing && isAnimated(cfg)) {
                frame++
                refreshNow()
                main.postDelayed(this, FRAME_MS)
            }
        }
    }

    init {
        createChannel()
        appContext.getSharedPreferences(AppSettings.PREFS_NAME, Context.MODE_PRIVATE)
            .registerOnSharedPreferenceChangeListener(prefsListener)
    }

    // ---- Provider -------------------------------------------------------------------

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback,
    ): MediaNotification {
        session = mediaSession
        factory = actionFactory
        return try {
            snap = capture(mediaSession.player)
            val cfg = config()
            updateTicker(cfg)
            // A quick first build with what is cached; the worker then swaps in the real artwork.
            val n = build(mediaSession, actionFactory, cachedArt(snap, cfg), cfg)
            val sig = "${snap?.key}|${snap?.playing}|${cfg.style}|${cfg.customArt[snap?.songId ?: -1L]}|${cfg.styleCustomUri}|${cfg.videoFrames}"
            if (sig != lastSig) {
                lastSig = sig
                scheduleRender()
            }
            MediaNotification(NOTIFICATION_ID, n)
        } catch (t: Throwable) {
            com.texgen.music.texwave.CrashGuard.nonFatal("notification", t)
            MediaNotification(NOTIFICATION_ID, fallback(mediaSession))
        }
    }

    /** Plain system media notification, used if the custom one ever fails to build. */
    private fun fallback(mediaSession: MediaSession): android.app.Notification {
        val title = try { mediaSession.player.mediaMetadata.title?.toString() } catch (_: Throwable) { null } ?: "Texwave"
        return NotificationCompat.Builder(appContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle(title)
            .setStyle(MediaStyleNotificationHelper.MediaStyle(mediaSession))
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .build()
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean = false

    fun release() {
        released = true
        try { nm.cancel(CARD_ID) } catch (_: Throwable) {}
        main.removeCallbacksAndMessages(null)
        try {
            appContext.getSharedPreferences(AppSettings.PREFS_NAME, Context.MODE_PRIVATE)
                .unregisterOnSharedPreferenceChangeListener(prefsListener)
        } catch (_: Exception) {
        }
        worker.shutdown()
        session = null
        factory = null
    }

    /** Call from the service when the player state changes (play/pause, track change...). */
    fun onPlayerChanged() {
        if (released) return
        main.post {
            val sess = session ?: return@post
            snap = capture(sess.player)
            if (snap?.hasItem != true || sess.player.playbackState == Player.STATE_IDLE) {
                try { nm.cancel(CARD_ID) } catch (_: Throwable) {}
            }
            updateTicker(config())
            scheduleRender()
        }
    }

    // ---- internals ------------------------------------------------------------------

    private fun capture(p: Player): Snap {
        val item = p.currentMediaItem
        val md = item?.mediaMetadata
        val art = md?.artworkUri?.lastPathSegment?.toLongOrNull() ?: 0L
        return Snap(
            key = item?.mediaId ?: "none",
            songId = item?.mediaId?.toLongOrNull() ?: -1L,
            title = md?.title?.toString() ?: "Texwave",
            artist = md?.artist?.toString() ?: "",
            album = md?.albumTitle?.toString() ?: "",
            contentUri = item?.localConfiguration?.uri?.toString() ?: "",
            albumId = art,
            playing = p.isPlaying,
            hasItem = item != null,
        )
    }

    private fun config(): Config {
        val theme = ThemeCatalog.byId(settings.loadThemeId())
        return Config(
            style = settings.loadNotifStyleId(),
            styleCustomUri = settings.loadNotifCustomUri(),
            videoFrames = settings.loadNotifVideoFrames(),
            soif = false, // SOIF branding removed
            soifStyled = false,
            accent = theme.primary.toInt(),
            accent2 = theme.secondary.toInt(),
            customArt = settings.loadCustomArt(),
        )
    }

    private fun isAnimated(cfg: Config): Boolean {
        // Always animate art / lyrics strip while a track is active
        return NotifCatalog.byId(cfg.style).isAnimated || cfg.style == "lyrics" || cfg.style == "particles"
    }

    private fun updateTicker(cfg: Config) {
        main.removeCallbacks(ticker)
        val s = snap
        if (s != null && s.playing && isAnimated(cfg)) main.postDelayed(ticker, FRAME_MS)
    }

    private fun refreshNow() {
        if (released) return
        scheduleRender()
    }

    /** Renders on the worker thread, then posts the notification from the main thread. */
    private fun scheduleRender() {
        if (released || rendering) return
        val s = snap ?: return
        if (!s.hasItem) return
        val cfg = config()
        val f = frame
        rendering = true
        try {
            worker.execute {
                var art: Bitmap? = null
                try {
                    art = renderArt(s, cfg, f)
                } catch (_: Throwable) {
                } finally {
                    rendering = false
                }
                val bmp = art
                main.post {
                    if (released) return@post
                    val sess = session ?: return@post
                    val fac = factory ?: return@post
                    // the player may have moved on while we rendered
                    val current = snap ?: return@post
                    if (current.key != s.key) {
                        scheduleRender()
                        return@post
                    }
                    try {
                        if (canNotify()) {
                            nm.notify(NOTIFICATION_ID, build(sess, fac, bmp, cfg))
                            if (current.hasItem) nm.notify(CARD_ID, build(sess, fac, bmp, cfg, custom = true))
                        }
                        if (bmp != null) artSink?.invoke(s.key, bmp)
                    } catch (_: SecurityException) {
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
            rendering = false
        }
    }

    private fun canNotify(): Boolean = try {
        nm.areNotificationsEnabled()
    } catch (_: Exception) {
        true
    }

    // ---- artwork --------------------------------------------------------------------

    private fun cachedArt(s: Snap?, cfg: Config): Bitmap? {
        if (s == null) return null
        return if (baseKey == baseCacheKey(s, cfg)) baseBmp else null
    }

    private fun baseCacheKey(s: Snap, cfg: Config) =
        "${s.key}|${cfg.customArt[s.songId]}|${if (cfg.style == "custom") cfg.styleCustomUri else ""}"

    @Synchronized
    private fun renderArt(s: Snap, cfg: Config, f: Int): Bitmap {
        val key = baseCacheKey(s, cfg)
        if (baseKey != key) {
            baseBmp = loadBase(s, cfg)
            baseKey = key
        }
        var video: Bitmap? = null
        if (cfg.style == "video" && cfg.videoFrames > 0) {
            if (videoCacheCount != cfg.videoFrames) {
                videoCache = arrayOfNulls(cfg.videoFrames)
                videoCacheCount = cfg.videoFrames
            }
            val idx = f % cfg.videoFrames
            if (videoCache[idx] == null) videoCache[idx] = NotifVideoFrames.load(appContext, idx, cfg.videoFrames)
            video = videoCache[idx]
        }
        val lyricLines = buildList {
            if (s.title.isNotBlank()) add(s.title)
            if (s.artist.isNotBlank()) add(s.artist)
            if (s.album.isNotBlank()) add(s.album)
        }
        return NotifArtRenderer.render(
            size = NotifMedia.SIZE,
            style = cfg.style,
            frame = f,
            base = baseBmp,
            videoFrame = video,
            seed = s.title + s.album,
            accent = cfg.accent,
            accent2 = cfg.accent2,
            showLogo = false,
            lyricsLines = lyricLines,
        )
    }

    private fun loadBase(s: Snap, cfg: Config): Bitmap? {
        // 1. your image for the whole notification
        if (cfg.style == "custom" && !cfg.styleCustomUri.isNullOrBlank()) {
            NotifMedia.decodeSquare(appContext, Uri.parse(cfg.styleCustomUri))?.let { return it }
        }
        // 2. cover you set for this song
        cfg.customArt[s.songId]?.let { u ->
            NotifMedia.decodeSquare(appContext, Uri.parse(u))?.let { return it }
        }
        // 3. the album art
        return NotifMedia.loadSongArt(appContext, s.contentUri, s.albumId)
    }

    // ---- notification ---------------------------------------------------------------

    private fun build(
        mediaSession: MediaSession,
        actionFactory: MediaNotification.ActionFactory,
        art: Bitmap?,
        cfg: Config,
        custom: Boolean = false,
    ): android.app.Notification {
        val player = mediaSession.player
        val s = snap
        val playing = s?.playing == true

        val open = PendingIntent.getActivity(
            appContext, 0,
            Intent(appContext, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val title = s?.title ?: (player.mediaMetadata.title?.toString() ?: "Texwave")
        val realArtist = s?.artist.orEmpty().ifBlank { "Unknown" }
        val soifLine = realArtist
        val artistLine = s?.album.orEmpty()

        // ---- Texwave's own custom layout ------------------------------------------------
        val small = RemoteViews(appContext.packageName, R.layout.notif_texwave_small)
        val big = RemoteViews(appContext.packageName, R.layout.notif_texwave_big)
        small.setTextViewText(R.id.notif_title, title)
        small.setTextViewText(R.id.notif_line, soifLine)
        big.setTextViewText(R.id.notif_title_big, title)
        big.setTextViewText(R.id.notif_artist_big, soifLine + if (artistLine.isNotBlank()) " · $artistLine" else "")
        big.setTextViewText(R.id.notif_brand, "TEXWAVE")
        big.setTextViewText(R.id.notif_lyrics_strip, "")
        val bg = mixDark(cfg.accent, 0.12f)
        try {
            small.setInt(R.id.notif_root_small, "setBackgroundColor", bg)
            big.setInt(R.id.notif_root_big, "setBackgroundColor", bg)
            small.setTextColor(R.id.notif_line, cfg.accent2 or 0xFF000000.toInt())
            big.setTextColor(R.id.notif_brand, cfg.accent2 or 0xFF000000.toInt())
        } catch (_: Exception) {}
        if (art != null) {
            small.setImageViewBitmap(R.id.notif_art, art)
            big.setImageViewBitmap(R.id.notif_art_big, art)
        }

        val playIcon = if (playing) R.drawable.ic_notif_pause else R.drawable.ic_notif_play
        // Wire media actions through Media3 action factory
        fun mediaPi(command: Int): PendingIntent =
            actionFactory.createMediaActionPendingIntent(mediaSession, command.toLong())

        small.setImageViewResource(R.id.notif_play, playIcon)
        big.setImageViewResource(R.id.notif_play_big, playIcon)
        small.setOnClickPendingIntent(R.id.notif_prev, mediaPi(Player.COMMAND_SEEK_TO_PREVIOUS))
        small.setOnClickPendingIntent(R.id.notif_play, mediaPi(Player.COMMAND_PLAY_PAUSE))
        small.setOnClickPendingIntent(R.id.notif_next, mediaPi(Player.COMMAND_SEEK_TO_NEXT))
        big.setOnClickPendingIntent(R.id.notif_rew, mediaPi(Player.COMMAND_SEEK_BACK))
        big.setOnClickPendingIntent(R.id.notif_prev_big, mediaPi(Player.COMMAND_SEEK_TO_PREVIOUS))
        big.setOnClickPendingIntent(R.id.notif_play_big, mediaPi(Player.COMMAND_PLAY_PAUSE))
        big.setOnClickPendingIntent(R.id.notif_next_big, mediaPi(Player.COMMAND_SEEK_TO_NEXT))
        big.setOnClickPendingIntent(R.id.notif_fwd, mediaPi(Player.COMMAND_SEEK_FORWARD))

        // Also keep standard actions for OEM media surfaces / Android 13+ QS
        val rewind = NotificationCompat.Action.Builder(
            IconCompat.createWithResource(appContext, R.drawable.ic_notif_rewind), "Rewind",
            mediaPi(Player.COMMAND_SEEK_BACK),
        ).build()
        val prev = NotificationCompat.Action.Builder(
            IconCompat.createWithResource(appContext, R.drawable.ic_notif_prev), "Previous",
            mediaPi(Player.COMMAND_SEEK_TO_PREVIOUS),
        ).build()
        val playPause = NotificationCompat.Action.Builder(
            IconCompat.createWithResource(appContext, playIcon),
            if (playing) "Pause" else "Play",
            mediaPi(Player.COMMAND_PLAY_PAUSE),
        ).build()
        val next = NotificationCompat.Action.Builder(
            IconCompat.createWithResource(appContext, R.drawable.ic_notif_next), "Next",
            mediaPi(Player.COMMAND_SEEK_TO_NEXT),
        ).build()
        val forward = NotificationCompat.Action.Builder(
            IconCompat.createWithResource(appContext, R.drawable.ic_notif_forward), "Forward",
            mediaPi(Player.COMMAND_SEEK_FORWARD),
        ).build()

        val color = if (art != null) averageColor(art) else cfg.accent

        val b = NotificationCompat.Builder(appContext, if (custom) CARD_CHANNEL_ID else CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle(title)
            .setContentText(
                if (cfg.style == "lyrics") {
                    val lines = listOfNotNull(
                        s?.title?.takeIf { it.isNotBlank() },
                        s?.artist?.takeIf { it.isNotBlank() },
                        s?.album?.takeIf { it.isNotBlank() },
                    )
                    if (lines.isNotEmpty()) lines[frame % lines.size] else soifLine
                } else soifLine
            )
            .setSubText(artistLine.ifBlank { null })
            .setContentIntent(open)
            .setDeleteIntent(actionFactory.createMediaActionPendingIntent(mediaSession, Player.COMMAND_STOP.toLong()))
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(playing)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setColor(color)
            .setColorized(true)
            .addAction(rewind)
            .addAction(prev)
            .addAction(playPause)
            .addAction(next)
            .addAction(forward)

        if (custom) {
            // Texwave's own card. Deliberately NOT MediaStyle: phone-maker skins (ColorOS etc.)
            // fold every MediaStyle notification into their own media tile and hide the card.
            b.setCustomContentView(small)
                .setCustomBigContentView(big)
                .setStyle(NotificationCompat.DecoratedCustomViewStyle())
        } else {
            b.setStyle(
                MediaStyleNotificationHelper.MediaStyle(mediaSession)
                    .setShowActionsInCompactView(1, 2, 3)
            )
        }

        if (art != null) b.setLargeIcon(art)
        return b.build()
    }


    private fun frameIndex(cfg: Config): Int = frame

    private fun mixDark(accent: Int, amount: Float): Int {
        val a = accent or 0xFF000000.toInt()
        val r = ((a shr 16) and 0xFF) * amount
        val g = ((a shr 8) and 0xFF) * amount
        val b = (a and 0xFF) * amount
        return (0xFF000000.toInt()
            or ((r.toInt().coerceIn(0, 40)) shl 16)
            or ((g.toInt().coerceIn(0, 40)) shl 8)
            or b.toInt().coerceIn(0, 48))
    }

    private fun averageColor(bmp: Bitmap): Int {
        val tiny = Bitmap.createScaledBitmap(bmp, 1, 1, true)
        val px = tiny.getPixel(0, 0)
        if (tiny !== bmp) tiny.recycle()
        // keep it dark enough for white text
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(px, hsl)
        hsl[1] = hsl[1].coerceAtMost(0.7f)
        hsl[2] = hsl[2].coerceIn(0.14f, 0.32f)
        return ColorUtils.HSLToColor(hsl) or Color.BLACK
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val m = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (m.getNotificationChannel(CARD_CHANNEL_ID) == null) {
            val c = NotificationChannel(CARD_CHANNEL_ID, "Texwave player card", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Texwave's own now-playing card"
                setShowBadge(false)
                setSound(null, null)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            m.createNotificationChannel(c)
        }
        if (m.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Texwave Player", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Texwave's own now-playing notification (not the system media tile)"
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            m.createNotificationChannel(ch)
        }
    }

    companion object {
        const val CHANNEL_ID = "texwave_media_v3"
        const val NOTIFICATION_ID = 4242
        const val CARD_ID = 4243
        const val CARD_CHANNEL_ID = "texwave_card_v1"
        const val FRAME_MS = 700L
    }
}
