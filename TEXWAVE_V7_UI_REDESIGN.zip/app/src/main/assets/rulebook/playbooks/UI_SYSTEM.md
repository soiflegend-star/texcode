# TEXCODE UI System — Build Instructions

How to build **premium product UI** in generated apps and how TEXCODE’s own Compose UI is structured.

## Goal
Interfaces that feel finished: hierarchy, motion, empty/error states, mobile-first, dark-friendly. Not wireframes.

---

## TEXCODE host UI (Compose)

### Screens
| Screen | Role |
|--------|------|
| SplashIntro | Branded intro, ease-in logo, fade to home |
| TexcodeApp | Main: drawer, mission chat, composer, corner session |
| LiveActivityScreen | Live mission timeline |
| SkillsScreen | Learned skills |

### Theme tokens (`ui/theme/Theme.kt`)
- Surfaces: `NearBlack`, `Surface0–3`, `SurfaceElevated`
- Accent: soft indigo (`Accent`, `AccentBright`)
- Semantic: `Success`, `Warning`, `Danger`, `Info`
- Spacing / Radii / shapes: `Spacing`, `Radii`, `ShapeCard`, `ShapeInput`, `ShapeChip`

### Motion (required patterns)
1. **Status dots** — pulse + scale while RUNNING / QUEUED  
2. **Event rows** — slide/fade in as steps arrive  
3. **Composer hints** — `AnimatedContent` cross-fade  
4. **Error banners** — `AnimatedVisibility` + slide  
5. **Model install** — progress bar + pulsing indicator  
6. **Splash** — reticle scale + fade  

When adding UI, prefer:
```kotlin
rememberInfiniteTransition + animateFloat + infiniteRepeatable(tween, Reverse)
AnimatedVisibility(fadeIn + slideInVertically)
AnimatedContent(fadeIn togetherWith fadeOut)
graphicsLayer { alpha; translationX; scaleX/Y }
```

### Corner controls
- Session: Talk / Apps / Fix / Games / Internet  
- Tools menu  
- **📌 Notes** — persistent `[USER_CONTEXT]` for the LLM  
- Level 1–10  

### Rules for host UI changes
- Keep main thread free during missions  
- Cap list sizes (events, missions) to avoid Compose OOM  
- Never block Send on heavy work — use coroutines  

---

## Generated product UI (HTML/CSS/JS)

### Must
1. Mobile viewport meta + readable type scale  
2. Clear primary action (one obvious button per screen)  
3. Navigation: tab bar or sidebar with active state  
4. Empty states with a next action  
5. Error toasts or inline errors  
6. Loading skeletons or spinners for async work  
7. Consistent spacing (8px grid) and radius  
8. Dark-friendly contrast (WCAG-ish)  

### Should
- Micro-interactions (button press scale, list enter)  
- Respect `prefers-reduced-motion`  
- Focus rings for keyboard  
- Safe-area insets on notched phones  

### Recommended structure
```
index.html
css/base.css        # tokens, reset
css/components.css  # buttons, cards, inputs
css/views.css       # per-screen layout
js/ui.js            # DOM helpers, toasts, transitions
js/app.js
```

### CSS motion snippets
```css
:root {
  --ease: cubic-bezier(0.22, 1, 0.36, 1);
  --dur: 220ms;
}
.fade-in { animation: fadeIn var(--dur) var(--ease) both; }
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: none; }
}
@media (prefers-reduced-motion: reduce) {
  * { animation: none !important; transition: none !important; }
}
```

---

## Prompt examples

- `Build a premium dark UI kit with sidebar, KPI cards, data table, and animated status chips.`  
- `Create a mobile-first social feed UI with stories row, double-tap like animation, and bottom tabs.`  

## Acceptance checklist

- [ ] Works at 360px width  
- [ ] Empty and error states exist  
- [ ] Primary actions obvious  
- [ ] Subtle motion without jank  
- [ ] Tokens used consistently (no random colors)  
