# TEXCODE Brain / AI Engine — Build Instructions

How to build a **reasoning brain** (planner + memory + tools + trace) in generated products, and how TEXCODE’s own on-device brain works.

## Goal
A transparent mini-agent: accept a goal, plan steps, use tools, remember facts, show an execution trace. Honest about limits (no fake “AGI”).

---

## Must features (brain product)

1. **Goal input** — User objective box + Run  
2. **Planner** — Break goal into ordered steps (shown in UI)  
3. **Memory** — Save / recall short facts (local persistence)  
4. **Tools registry** — List of tools (search, calc, http mock, file note…) with enable flags  
5. **Executor** — Run steps, mark success/fail  
6. **Execution trace** — Timeline of thoughts, tool calls, results  
7. **Stop / reset** — Cancel run, clear ephemeral state  
8. **Persistence** — Memory + last plan survive reload  
9. **Honest status** — “rule-based”, “heuristic”, or “model-backed” label  

## Should features

- Re-plan on failure  
- Tool permission prompts  
- Export trace as JSON/Markdown  
- Simple scoring / confidence per step  
- RAG over local notes (keyword BM25 is enough)  

---

## Architecture (generated web brain)

```
brain/
  index.html
  css/brain.css
  js/memory.js      # get/set facts
  js/tools.js       # registry + implementations
  js/planner.js     # goal → steps
  js/executor.js    # run loop + trace events
  js/ui.js
  js/app.js
  data/seed-memory.js
  README.md
```

### Minimal planner (deterministic)
1. Normalize goal text  
2. Match intent keywords → template plan  
3. Attach tools per step  
4. Emit plan to UI before execute  

### Executor loop
```
for step in plan:
  emit(trace, thinking, step)
  result = tools[step.tool](step.args)
  emit(trace, tool_result, result)
  memory.maybeStore(result)
  if failed and canReplan: replan once
```

### Memory model
```json
{ "id", "content", "tags", "confidence", "updatedAt" }
```
Cap entries (e.g. 200). Prefer verified user notes over ephemeral model text.

---

## TEXCODE host brain (on device)

| Component | Role |
|-----------|------|
| EmbeddedLlmRuntime | Engineering brain + optional MediaPipe GenAI |
| ModelRuntime / ModelManager | Neural model lifecycle (READY / DOWNLOAD / ENGINEERING) |
| LocalLlmClient | Routes to embedded or neural backend |
| MemoryStore | Verified vs unverified facts |
| ContextFusion | Soul + memory + RAG + objective → bounded prompt |
| LocalRag | Keyword context, no cloud embeddings required |
| AppTypeDictionary | Expands short app asks into full feature briefs |
| NeuralCodeEngine | Optional polish — **skipped** on heavy multi-file apps (anti-crash) |

### States the UI already shows
- Engineering brain only  
- Downloading neural weights + progress %  
- Offline ready  

### Rules (never break)
1. Identity locked — do not invent a different product persona  
2. Bound context size (ContextFusion max chars)  
3. No unbounded RAG reindex after huge CREATE (OOM history)  
4. Skip neural enhance for chat / social / game / ≥6 files  
5. Stream large seed data to disk (SeedForge)  

---

## How to ask TEXCODE for a brain

- `Build a brain engine with planner, memory, tools registry, execution trace, and Python-style step runner. Open index.html.`  
- Or: `brain engine planner memory tools` (dictionary expands Must features)  
- Put standing constraints in **📌 Notes** (e.g. “always show tool args in the trace”).

---

## Acceptance checklist

- [ ] Plan visible before/during run  
- [ ] At least 3 tools registered and callable  
- [ ] Memory write + recall demonstrated  
- [ ] Trace lists each step and outcome  
- [ ] Stop works mid-run  
- [ ] Survives page reload  
- [ ] Label states whether model-backed or heuristic  

## Anti-crash notes
- Keep traces capped  
- Do not load large models on the UI thread  
- Prefer deterministic planner when neural is not READY  
