# TEXCODE Voice Engine — Build Instructions

How to design and implement a **voice system** (speech-to-text + text-to-speech) inside products TEXCODE generates, and how TEXCODE’s own engine relates to voice.

## Goal
Ship a usable offline-first voice UI: record / type, transcribe (or mock STT), speak replies (TTS), show a live log, and persist settings. No crash on missing mic permission.

---

## Must features (always implement)

1. **Mic control** — Start / stop recording button with clear idle / listening / processing states  
2. **Permission UX** — If mic denied, show message + “Open settings” style hint; never crash  
3. **Transcript panel** — Live or final text from STT (or typed fallback)  
4. **TTS playback** — Speak selected text or last bot reply; stop button  
5. **Voice log** — Timestamped list of user speech + system replies  
6. **Settings** — Language (at least en), speech rate, pitch (if platform allows)  
7. **Persistence** — Save log + settings (localStorage / SharedPreferences / IndexedDB)  
8. **Empty + error states** — “No speech yet”, “Mic unavailable”, “TTS failed”  
9. **Mobile layout** — Large hit targets, safe-area aware  

## Should features

- Partial (interim) transcripts while speaking  
- Waveform or level meter animation while listening  
- Voice activity detection (auto-stop on silence)  
- Export log as text  
- Multiple voices / locales  
- Push-to-talk vs continuous mode  

---

## Architecture (recommended)

```
voice/
  index.html          # shell + permission banner
  css/voice.css       # states: idle listening processing speaking error
  js/store.js         # settings + log persistence
  js/stt.js           # Web Speech API or Android SpeechRecognizer bridge
  js/tts.js           # speechSynthesis or Android TTS
  js/ui.js            # buttons, log list, meters
  js/app.js           # wire events
  README.md
```

### Web (generated apps)
- Prefer `webkitSpeechRecognition` / `SpeechRecognition` when available  
- Prefer `window.speechSynthesis` for TTS  
- Always provide **type instead** fallback when STT missing  

### Android (TEXCODE host app)
- STT: `SpeechRecognizer` or system recognizer intent  
- TTS: `TextToSpeech`  
- Run recognition callbacks on main thread; release resources in `onDestroy`  
- Never block the UI thread with long TTS init  

---

## UI states (animate these)

| State        | Visual                                      |
|-------------|----------------------------------------------|
| idle        | Mic outline, muted pulse                     |
| listening   | Strong pulse / ring, level meter             |
| processing  | Spinner or three dots                        |
| speaking    | Speaker icon + progress or waveform          |
| error       | Red banner, recoverable action               |

Use CSS transitions or Compose `animateFloat` / `InfiniteTransition` for pulse rings (same pattern as TEXCODE status dots).

---

## Safety / anti-crash rules

1. Wrap STT/TTS init in try/catch; degrade to text-only  
2. Do not keep the mic open after stop  
3. Cancel recognition when the screen is destroyed or mission stops  
4. Cap log length (e.g. 200 entries) to avoid OOM  
5. Do not request neural enhance solely for voice UI scaffolding  

---

## Prompt examples for TEXCODE

- `Build a voice system with speech-to-text, text-to-speech, controls, log, and settings. Offline-first.`  
- Session **APP**, Level 8–10. Optional: put language/locale prefs in **📌 Notes**.

## Acceptance checklist

- [ ] Mic start/stop works or shows a clear fallback  
- [ ] Transcript appears in the UI  
- [ ] TTS speaks and can be stopped  
- [ ] Log persists across reload  
- [ ] No crash without mic permission  
- [ ] Mobile-friendly layout  
