# Quality Gate

A delivery is not finished until it passes this gate.

## Functional
- [ ] Every Must feature works end-to-end
- [ ] Core user flows complete without errors
- [ ] Data persists across reload
- [ ] Empty states exist and make sense
- [ ] Mobile layout is usable

## Product
- [ ] Seed data makes the app feel alive
- [ ] Important actions give clear feedback
- [ ] No “coming soon” buttons that do nothing
- [ ] Search / filters / settings actually change what the user sees

## Code
- [ ] Modules are separated cleanly
- [ ] No large amounts of dead code
- [ ] Naming is clear
- [ ] Architecture matches the stated template or is deliberately better

## Honesty & Size
- [ ] No empty versioned stub files
- [ ] No size padding
- [ ] Research note exists for non-trivial products
- [ ] Feature matrix was written before heavy implementation
- [ ] Output is substantial real content (target ≥ 10 MB of useful application code + seed + assets when the feature set supports it)

## Chatting-app specific
- [ ] 1:1 and group chats work
- [ ] Messages send, persist, and show delivery/read state
- [ ] Reply and reactions work
- [ ] Media entry points work
- [ ] Chat list unread / pin / mute / archive behave correctly
- [ ] Settings change real behaviour

## Instagram-class specific
- [ ] Feed, stories, explore, create, profile, DMs, activity are interactive
- [ ] Likes, comments, and persistence work

If any required box fails, the work is not ready.
