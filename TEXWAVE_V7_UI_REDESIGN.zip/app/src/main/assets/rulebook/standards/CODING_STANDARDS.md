# Coding Standards

## Architecture
- Clear module boundaries
- Data layer separate from UI
- Features own their rendering and actions
- No circular dependencies
- No god files unless deliberately justified

## State & Persistence
- Single source of truth
- Browser apps: IndexedDB for structured data; localStorage only for tiny settings
- Every important user action must survive reload

## UI
- Mobile-first when the product is mobile
- Real empty states
- Loading and error states where needed
- Consistent tokens (colour, spacing, type)
- Keyboard and focus considered

## JavaScript
- Readable names
- Small focused functions
- No dead code
- Avoid deep nesting

## CSS
- Variables for theme values
- Component-oriented organisation
- Responsive without breaking core flows

## Data & Seed
- Seed data must demonstrate the features
- Realistic names, messages, timestamps
- Enough volume that lists and scroll feel real

## Forbidden
- Empty versioned feature files
- Buttons that do nothing
- “Coming soon” as a substitute for implementation
- Padding the deliverable with duplicate or useless files
- Claiming a feature is done when it is only a visual shell

## Review questions before delivery
1. Does every Must feature actually work?
2. Does data persist?
3. Can a new user understand the app quickly?
4. Is the code structured so another engineer could extend it?
5. Is there any content added only to inflate size?
