# MAX LEVEL — any non-game app

TEXCODE max path:
1. Match type (dictionary + FeatureDiscovery)
2. Optional feature picker (AWAITING_FEATURES)
3. Route:
   - social → InstagramScaffold
   - chat messaging → ChatAppScaffold
   - music → MusicAppScaffold
   - everything else non-game → PlayStoreAppScaffold (multi-surface CRUD app)
4. Floor tier 8; ultimate/max language → tier 10
5. Depth modules after scaffold (settings, export, social/chat extras when relevant)

Games use GameScaffold paths separately.
