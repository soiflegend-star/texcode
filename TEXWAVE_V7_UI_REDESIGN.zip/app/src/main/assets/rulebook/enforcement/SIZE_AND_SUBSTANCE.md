# Size & substance (MAX)

## Floor
User selects **1 / 2 / 5 / 10 / 20 / 30 MB** minimum via UI chip (`[SIZE_MB:N]`).

## Split (realistic 10 MB)
| Slice | Share | Contents |
|-------|-------|----------|
| **UI** | ~78% (7–8 MB) | Design tokens, themes, components, motion, chrome (Instagram / todo / chat) |
| **Features / logic** | ~22% (2 MB) | Screens, repositories, domain — **no seeds** |

## Forbidden
- seed.js / demo users / fake posts / padding-only text
- Shipping thin 16 KB shells

## Required
- Zip **after** UI + feature expansion
- Online-first products
- Working auth (localStorage with clear errors)


## 2026-10-07 anti-bloat
- Android design: **one** `ColorSystem.kt` etc. — never `ColorSystem_r0..r17`
- Feature screens: **one** `Screen_Inbox.kt` — never `Screen_Inbox_0_0` rounds
- Size floor must not be filled by revision spam
