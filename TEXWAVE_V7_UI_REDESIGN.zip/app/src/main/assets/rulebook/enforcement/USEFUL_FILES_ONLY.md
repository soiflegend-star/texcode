# Useful files only

TEXCODE must not write junk.

## Allowed
- Core entry: index.html, styles, app/store/auth/runtime/ui/feed
- Android: MainActivity, AppRoot, ViewModel, Repository, Models, real screens
- One design module per concern (ColorSystem.kt not ColorSystem_r3.kt)
- Research notes, README, gradle project files

## Forbidden
- *_r0.kt / *_r1.css revision spam
- Feature00.kt label stubs
- UseCase0..N clones
- seed.js
- Unlinked ui/components dumps
- Empty thin files

## Research
- Parallel web search ≥ 50 queries for the product domain
- Implement all must-features, not 5 of 10

## UI
- Domain chrome (instagram / chat / todo / music) linked from entry
- Instagram-class polish target for every app type
