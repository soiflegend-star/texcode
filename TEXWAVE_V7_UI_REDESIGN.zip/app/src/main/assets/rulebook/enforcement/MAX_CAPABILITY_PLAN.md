# TEXCODE max capability plan

## Research (all CREATE)
- Minimum **10 web searches** via ResearchPhase (product queries + UX + architecture).
- Note written to `research/RESEARCH_NOTE.md`.
- Offline fallback: dictionary features still implement.

## Recognition (UniversalScaffold)
1. Social / Instagram → InstagramScaffold (max local surfaces)
2. Chat → ChatAppScaffold
3. Music → MusicAppScaffold
4. Todo / Alarm / Shop → dedicated routes
5. Weather / expense / habit / fitness / calendar / clock → dictionary + Android/web scaffold
6. Else → PlayStore / Android by tier

## Instagram max (local)
- Auth, feed, likes, comments, double-tap
- Stories create + viewer
- Explore, create post, profile, DMs
- Activity from real actions
- Share via clipboard
- Reels page = vertical posts (video hosting = out of scope / impossible on pure local web without media pipeline)

## Impossible / out of scope (honest)
- Multi-device real-time social network without a server
- True video reel CDN
- Secure production auth (bcrypt/OAuth cloud)

## Pipeline
P0 boot → P1 plan + research≥10 → P2 implement features → P3 integrate → P4 verify/package + agent squad
