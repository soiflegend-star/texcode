# TEXCODE App Build Pipeline

## Goal
Ship **working** multi-surface apps (social, chat, todo, music, alarm, shop, …).
Size is measured on **integrated** code, not unused design dumps.

## Steps (every CREATE mission)
1. Understand objective
2. Dictionary + feature brief
3. Research comparable products
4. Architecture (honest: local vs backend)
5. Scaffold shell (correct type)
6. Implement each must-feature as a real unit
7. UI system **linked** from entrypoint only
8. Wire navigation
9. Persistence + empty states
10. Repair runtime deps (no missing scripts)
11. Honest verify + package

## Instagram-class must (local product)
- Auth (signup/login/logout) with storage
- Feed, likes, comments, double-tap
- Stories viewer + create path
- Create post, profile grid, explore
- DMs local, activity shell
- **runtime.js present** and referenced
- No claim of real multi-device backend unless implemented

## Forbidden
- Deleting runtime helpers as "seeds"
- Counting unlinked CSS/HTML as features
- Placeholders labeled as finished systems (fake share, fake reels video)

## Any-app rule
Same pipeline; different dictionary features + scaffold.
