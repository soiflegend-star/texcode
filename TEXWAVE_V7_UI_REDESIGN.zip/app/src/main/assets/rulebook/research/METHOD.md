# Research Method (mandatory before implementation)

TEXCODE never starts heavy product coding from imagination alone.

## Process

1. Identify 2–4 real products that best match the request.
2. Use web research to pull current (2025–2026) feature lists and behaviour.
3. Record:
   - Core daily surfaces
   - Interaction patterns (likes, replies, receipts, media, etc.)
   - Data that must persist
   - Privacy / settings expectations
   - Mobile vs desktop differences
   - Offline expectations
4. Write a short research note.
5. Only then produce the feature matrix and architecture.

## Chatting apps — minimum research targets

- WhatsApp (mainstream flows, receipts, media, groups)
- Signal (privacy defaults, simplicity)
- Telegram (large groups, extra power features)
- Discord (community / channel patterns when relevant)

## Social / Instagram-class — minimum research targets

- Current Instagram surfaces: feed, stories, reels, explore, create, profile, DMs, activity
- Interaction details: double-tap, stickers, carousels, etc.

## Output of research phase

A markdown research note that lists:
- Products examined
- Must-have surfaces discovered
- Notable interaction details
- Complexity or risk points

This note is part of the delivery.
