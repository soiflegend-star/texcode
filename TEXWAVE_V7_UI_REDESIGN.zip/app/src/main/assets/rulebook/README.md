# TEXCODE

Autonomous high-capability coding system.

This package contains **only TEXCODE**.  
No demo apps. No Android. No other distribution. No padding.

## What TEXCODE is required to do

- Research real products first  
- Extract and implement full feature matrices  
- Produce 99% working features (tests separate, ≤ 1%)  
- Deliver substantial pure application content (target ≥ 10 MB of real useful code + seed + assets when the feature set supports it)  
- Code at senior-engineer quality  
- Excel at full chatting apps and Instagram-class social apps  
- Never ship skeletons or empty stubs  

## Contents

```
TEXCODE/
├── README.md
├── core/
│   ├── TEXCODE.md              ← main mandate
│   └── SYSTEM_PROMPT.md        ← prompt that enforces behaviour
├── research/
│   └── METHOD.md
├── matrices/
│   ├── CHATTING_APP.md         ← primary capability test
│   ├── SOCIAL_INSTAGRAM_CLASS.md
│   └── APP_TYPE_DICTIONARY.md  ← 50+ app types with full Must/Should + build notes
├── playbooks/
│   ├── CHATTING_APP.md
│   ├── SOCIAL_APP.md
│   ├── IMPLEMENTATION_ORDER.md
│   ├── VOICE_ENGINE.md      ← STT/TTS voice system instructions
│   ├── UI_SYSTEM.md         ← host + generated UI + motion
│   └── BRAIN_ENGINE.md      ← planner / memory / tools / trace
├── standards/
│   ├── CODING_STANDARDS.md
│   └── QUALITY_GATE.md
├── templates/
│   └── CHAT_ARCHITECTURE.md
└── enforcement/
    └── SIZE_AND_SUBSTANCE.md
```

## How it works

On every request TEXCODE must follow:

1. Research Method  
2. Relevant Feature Matrix  
3. Implementation Order / Playbook  
4. Coding Standards  
5. Size & Substance rules  
6. Quality Gate  

Only then is the work considered done.

## Primary stress tests

- Full chatting app (WhatsApp / Signal / Telegram / Discord class)  
- Instagram-level social app  

If TEXCODE cannot deliver those at full depth, it has failed its purpose.
