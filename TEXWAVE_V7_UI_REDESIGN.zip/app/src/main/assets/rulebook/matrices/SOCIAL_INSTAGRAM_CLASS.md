# Feature Matrix — Instagram-Class Social App

Checkpoint capability for TEXCODE.

## Must

- Auth (signup / login / logout) with persistence
- Home feed with posts, likes (including double-tap), comments
- Stories row + full-screen viewer
- Explore / search
- Create post (caption, media or colour, tags)
- Profile (stats, grid)
- Activity / notifications
- Direct messages (threads)
- Persistence (localStorage or IndexedDB)
- Realistic seed content

## Should

- Reels surface
- Bookmarks / save
- Hashtags and mentions
- Close friends
- Alt text
- Richer create tools
- Story stickers (poll, quiz, countdown)
- Insights / simple analytics

## Definition of done

Core daily surfaces (feed, stories, explore, create, profile, DMs) are interactive and persistent. The app feels like a real social client, not a static mock.
