# Feature Matrix — Full Chatting App

Primary capability test for TEXCODE.

## Must (all required)

- 1:1 chats and group chats
- Chat list with unread counts, last message, timestamp
- Pin, mute, archive
- Folders or filters (All / Unread / Groups / Archived)
- Message thread with day separators
- Send text messages
- Delivery and read state (✓ / ✓✓)
- Reply to messages
- Reactions
- Context menu: copy, star, delete for me, delete for everyone, forward
- Media: images, voice notes (record UI), files
- Search chats + search inside conversation
- New chat and new group flows
- Profile / me chip
- Settings (privacy toggles, theme, storage)
- Persistence via IndexedDB (or equivalent) — data survives reload
- Realistic seed conversations so the app feels alive on first open
- Empty states and basic error handling
- Mobile-responsive layout

## Should (implement majority)

- Link previews
- Polls with live votes
- Voice / video call UI
- Typing indicator simulation
- Disappearing / view-once indicators
- Starred messages view
- Chat info panel (members, media gallery)
- Theme (dark / light)
- Enter-to-send toggle
- Offline-friendly behaviour

## Architecture baseline

```
db.js          IndexedDB schema + helpers
store.js       reactive state + persistence
ui.js          DOM helpers, toast, modal
features/
  auth.js
  chats.js
  messages.js
  media.js
  search.js
  settings.js
  calls.js
seed.js        rich realistic data
app.js         boot
```

## Data model minimum

- users
- chats (dm + group)
- messages (text, image, voice, file, poll, system)
- settings

## Definition of done

A user can open the app, use seeded chats, send messages, reply, react, attach media, create a group, search, change settings, and reload without losing data. No surface is a non-functional placeholder.
