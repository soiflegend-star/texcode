# TEXCODE App-Type Dictionary

Complete feature matrices and build instructions for 50+ distinct product types.
When the user asks for any of these (short or long name), expand the objective with the **Must** list and follow the **Build notes**. Never ship a skeleton. Prefer multi-file HTML/CSS/JS offline apps unless the user specifies otherwise. Skip neural enhance on multi-file scaffolds (anti-crash). Size from real seed + real modules, never padding.

---

## 1. Chatbot / AI Assistant
**Triggers:** chatbot, ai chat, assistant, gpt clone, talk bot  
**Must:** message list, user + bot bubbles, input + send, typing indicator, clear chat, local history (localStorage/IndexedDB), system prompt / persona, multi-turn memory, error state, empty state, mobile layout  
**Should:** model picker, temperature, export chat, voice input UI, markdown/code blocks, regenerate, stop generation  
**Build notes:** Single-page or modular `js/chat.js` + `js/store.js`. Seed 8–15 sample turns. No cloud required for UI demo; mark API as optional.

## 2. Chat / Messaging App (WhatsApp-class)
**Triggers:** chat app, messaging, messenger, whatsapp, telegram, signal, dm app  
**Must:** auth, chat list (unread, last msg, time), 1:1 + groups, send text, receipts, reply, reactions, media attach UI, search, pin/mute/archive, settings, IndexedDB, realistic seed ≥ target when possible  
**Should:** polls, calls UI, typing, view-once, starred, theme  
**Build notes:** Use ChatAppScaffold + SeedForge.chat. Follow CHATTING_APP matrix.

## 3. Instagram-class Social
**Triggers:** instagram, insta, texgram, social app, feed app, reels  
**Must:** auth, home feed, likes (double-tap), comments, stories + viewer, explore/search, create post, profile grid, activity, DMs, persistence, realistic seed  
**Should:** reels, bookmarks, hashtags, close friends, stickers, insights  
**Build notes:** InstagramScaffold + SeedForge.social. Neural skipped. See SOCIAL_INSTAGRAM_CLASS.md.

## 4. Todo / Tasks
**Triggers:** todo, task app, checklist, reminders  
**Must:** add/edit/delete tasks, complete toggle, lists/projects, due dates, filters (all/active/done), local persistence, empty state  
**Should:** priority, tags, subtasks, search, recurring UI, drag reorder  

## 5. Notes / Notion-lite
**Triggers:** notes app, notepad, notion clone, wiki  
**Must:** note list, create/edit/delete, rich text or markdown, folders/tags, search, persistence  
**Should:** favorites, export, templates, backlinks UI  

## 6. E-commerce / Store
**Triggers:** shop, store, ecommerce, marketplace, product catalog  
**Must:** product grid, product detail, cart, add/remove, checkout UI, categories, search, persistence  
**Should:** wishlist, reviews, order history, coupons UI  

## 7. Music Player
**Triggers:** music player, playlist, spotify clone, audio player  
**Must:** track list, play/pause, next/prev, progress, volume, playlists, now-playing, local tracks or demo URLs  
**Should:** shuffle, repeat, lyrics panel, equalizer UI  

## 8. Video / Reels Player
**Triggers:** video player, reels, short video, tiktok clone  
**Must:** vertical feed, play/pause, like, comment UI, profile, upload UI (placeholder), persistence of likes  
**Should:** duet UI, sounds, following feed  

## 9. Weather
**Triggers:** weather app, forecast  
**Must:** current conditions, multi-day forecast, location label, refresh, unit toggle, attractive cards  
**Should:** hourly, maps UI, alerts, multiple cities  

## 10. Calculator
**Triggers:** calculator, calc app  
**Must:** digit pad, operations, clear, display, history  
**Should:** scientific mode, memory keys, themes  

## 11. Calendar / Events
**Triggers:** calendar, events, schedule  
**Must:** month view, day detail, add event, edit/delete, persistence  
**Should:** week view, reminders UI, recurring  

## 12. Habit Tracker
**Triggers:** habit, streak, daily goals  
**Must:** habit list, check-in, streaks, calendar heat, add/edit, persistence  
**Should:** categories, reminders UI, stats charts  

## 13. Fitness / Workout
**Triggers:** fitness, workout, gym log, exercise  
**Must:** exercise library, log sets/reps, history, routines, persistence  
**Should:** rest timer, charts, body metrics  

## 14. Recipe / Cooking
**Triggers:** recipe, cooking, meal planner  
**Must:** recipe list, detail (ingredients + steps), search, favorites, persistence  
**Should:** meal plan week, shopping list, timers  

## 15. Expense / Budget
**Triggers:** expense, budget, money tracker, finance  
**Must:** add expense/income, categories, list, totals, filters by date, persistence  
**Should:** charts, budgets, export CSV UI  

## 16. Blog / CMS
**Triggers:** blog, cms, articles  
**Must:** post list, post detail, create/edit (title body tags), draft/publish, persistence  
**Should:** categories, comments UI, markdown  

## 17. Forum / Reddit-lite
**Triggers:** forum, reddit clone, community board  
**Must:** posts, comments, upvote/downvote, communities, create post, persistence  
**Should:** sort hot/new, user profiles, search  

## 18. Kanban / Trello-lite
**Triggers:** kanban, trello, boards, project board  
**Must:** boards, lists, cards, drag between lists (or move buttons), add/edit, persistence  
**Should:** labels, due dates, members UI  

## 19. CRM / Contacts
**Triggers:** crm, contacts, leads  
**Must:** contact list, detail, add/edit, search, tags, persistence  
**Should:** pipeline stages, notes timeline, deals  

## 20. Email Client UI
**Triggers:** email client, inbox ui, mail app  
**Must:** inbox list, read pane, compose UI, folders, star, search  
**Should:** labels, attachments UI, threads  

## 21. Map / Location
**Triggers:** map app, places, location finder  
**Must:** map placeholder or static, search places, list results, detail card, favorites  
**Should:** directions UI, layers  

## 22. Quiz / Trivia
**Triggers:** quiz, trivia, mcq  
**Must:** question flow, score, results, categories, restart  
**Should:** timer, leaderboard local, explanations  

## 23. Flashcards / SRS
**Triggers:** flashcards, anki, spaced repetition  
**Must:** decks, cards front/back, review flow, again/good, persistence  
**Should:** SRS scheduling, stats  

## 24. Pomodoro / Focus
**Triggers:** pomodoro, focus timer, productivity timer  
**Must:** timer 25/5, start/pause/reset, session count, persistence  
**Should:** custom durations, task label, sounds UI  

## 25. Drawing / Whiteboard
**Triggers:** drawing, whiteboard, canvas sketch  
**Must:** canvas, pen color/size, clear, undo, save image UI  
**Should:** shapes, eraser, export  

## 26. Photo Gallery
**Triggers:** gallery, photo album  
**Must:** grid, full-screen viewer, albums, persistence of meta  
**Should:** filters UI, share, favorites  

## 27. File Manager UI
**Triggers:** file manager, files app  
**Must:** folder tree/list, file rows, open/rename/delete UI, breadcrumb  
**Should:** sort, search, multi-select  

## 28. Password Manager UI
**Triggers:** password manager, vault  
**Must:** vault list, add entry (site user pass), copy, search, lock screen UI, persistence (demo)  
**Should:** generator, categories, strength  

## 29. Survey / Forms
**Triggers:** survey, forms, typeform  
**Must:** form builder or fixed form, field types, submit, results list, persistence  
**Should:** logic jumps UI, export  

## 30. Booking / Appointments
**Triggers:** booking, appointments, reservations  
**Must:** service list, calendar slots, book form, my bookings, persistence  
**Should:** staff, payments UI  

## 31. Ride / Taxi UI
**Triggers:** ride app, taxi, uber clone ui  
**Must:** map placeholder, pickup/drop, estimate, request ride, status, history  
**Should:** driver card, rating  

## 32. Food Delivery
**Triggers:** food delivery, restaurant order  
**Must:** restaurant list, menu, cart, checkout, order status, persistence  
**Should:** ratings, tracking UI  

## 33. Learning / Courses
**Triggers:** course app, elearning, lms  
**Must:** course list, lessons, progress, mark complete, persistence  
**Should:** quizzes, certificates UI  

## 34. Podcast Player
**Triggers:** podcast, episode player  
**Must:** show list, episodes, play/pause, progress, speed, persistence  
**Should:** sleep timer, downloads UI  

## 35. News Reader
**Triggers:** news app, rss reader  
**Must:** feed list, article detail, categories, bookmarks, persistence  
**Should:** offline cache UI, sources  

## 36. Stock / Crypto Tracker UI
**Triggers:** stocks, crypto tracker, portfolio  
**Must:** watchlist, price cards, portfolio total, add symbol, persistence  
**Should:** simple chart, news links  

## 37. Meditation / Breath
**Triggers:** meditation, breathwork, calm  
**Must:** session timer, breathe animation UI, presets, history  
**Should:** sounds, streaks  

## 38. Language Learn
**Triggers:** language learning, duolingo lite  
**Must:** lessons list, exercise types (match/choice), XP, streaks, persistence  
**Should:** audio UI, leaderboard local  

## 39. Invoice / Billing
**Triggers:** invoice, billing, estimates  
**Must:** client list, create invoice, line items, total, status, persistence  
**Should:** PDF export UI, payments  

## 40. Inventory
**Triggers:** inventory, stock management  
**Must:** item list, SKU, qty, add/edit, low-stock flag, persistence  
**Should:** suppliers, barcode UI  

## 41. Job Board
**Triggers:** job board, careers  
**Must:** job list, detail, apply form, filters, post job, persistence  
**Should:** saved jobs, company pages  

## 42. Dating UI
**Triggers:** dating app, tinder ui  
**Must:** card stack, like/pass, matches list, chat stub, profile edit, persistence  
**Should:** filters, discovery settings  

## 43. Event Tickets
**Triggers:** events, tickets, meetup  
**Must:** event list, detail, ticket types, book, my tickets, persistence  
**Should:** QR UI, map  

## 44. Real Estate
**Triggers:** real estate, property listings  
**Must:** listing grid, detail, filters (price beds), favorites, contact form, persistence  
**Should:** map, agent profile  

## 45. Dashboard / Admin
**Triggers:** admin dashboard, analytics ui, kpi  
**Must:** sidebar, KPI cards, table, charts placeholders, filters, settings  
**Should:** dark theme, export  

## 46. Game: Snake / Arcade
**Triggers:** snake game, arcade snake  
**Must:** canvas/grid, controls, score, game over, restart, high score persistence  
**Should:** levels, mobile swipe  

## 47. Game: 2D Platformer / Rope
**Triggers:** platformer, rope hero, 2d game  
**Must:** player move/jump, platforms, score/lives, touch controls, game over  
**Should:** enemies, collectibles — use RopeHeroLiteScaffold when matched  

## 48. Game: Quiz Race / Trivia Game
**Triggers:** trivia game, quiz race  
**Must:** timed questions, score, multiplayer-local or solo, results  
**Should:** power-ups UI  

## 49. Browser / Startpage
**Triggers:** startpage, browser homepage, new tab page  
**Must:** search bar, shortcuts grid, clock, customize links, persistence  
**Should:** weather widget, themes  

## 50. Voice Notes / Recorder UI
**Triggers:** voice notes, audio recorder  
**Must:** record button UI, list of notes, play, delete, persistence of meta  
**Should:** waveform, transcripts placeholder  

## 51. QR / Barcode Tools
**Triggers:** qr code, barcode generator  
**Must:** generate QR from text, display, download/share UI, history  
**Should:** scan placeholder  

## 52. Unit Converter
**Triggers:** unit converter, currency converter  
**Must:** category, from/to units, input, result, common conversions  
**Should:** favorites, history  

## 53. Markdown Editor
**Triggers:** markdown editor, md preview  
**Must:** editor pane, live preview, open/save local, persistence  
**Should:** split view, export HTML  

## 54. Kanban + Calendar Hybrid
**Triggers:** planner app, productivity suite  
**Must:** tasks + calendar views, drag or assign dates, persistence  
**Should:** goals, reviews  

## 55. Multi-tool Utility
**Triggers:** utility toolkit, swiss army app  
**Must:** home grid of tools (calc, notes, converter…), navigation, each tool functional, persistence  
**Should:** search tools, favorites  

---

## Global build instructions (all types)

1. **Research** when network available; write `research/RESEARCH_NOTE.md` for major types (chat, social, ecommerce, music, games).  
2. **Expand short asks** using this dictionary Must list before writing files.  
3. **Multi-file** structure: `index.html`, `css/`, `js/` modules, `README.md`.  
4. **Persistence** required (localStorage or IndexedDB).  
5. **Seed** realistic demo data the UI actually loads.  
6. **No padding**, no empty stubs, no "coming soon".  
7. **Neural enhance** only on small single-file tools; **skip** for multi-file / social / chat / games (anti-crash).  
8. **Quality**: mobile viewport, empty states, error handling, accessible buttons.  
9. Package with ArtifactBudget; tests separate if any.  
10. Prefer offline-first demos that open via `index.html`.
