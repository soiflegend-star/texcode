# Template — Chatting App Architecture

## Folder layout

```
app/
  index.html
  css/
    base.css
    components.css
    chat.css
    features.css
  js/
    db.js
    store.js
    ui.js
    features/
      auth.js
      chats.js
      messages.js
      media.js
      search.js
      settings.js
      calls.js
    seed.js
    app.js
  data/           # rich seed / bulk data
  research/       # research notes
```

## IndexedDB stores

- users        { id, name, username, color, bio, lastSeen, online }
- chats        { id, type, name, peerId, members, color, updatedAt, lastMessage, unread, pinned, muted, archived }
- messages     { id, chatId, from, type, text, ts, status, replyTo, reactions, starred, media… }
- settings     { key, value }

## Key indexes
- messages by chatId + ts
- chats by updatedAt

## Message types
- text, image, voice, file, poll, system

## Critical flows
1. Boot → session → load chats → render list
2. Open chat → load messages → mark read → render thread
3. Send → write DB → update preview → UI update → delivery/read simulation
4. Create group → write chat + system message → open
5. Search → filter and highlight

## UI surfaces
- Auth
- Chat list (folders)
- Conversation + composer
- Context menu
- Settings / privacy / storage
- Chat info + media gallery
- Optional call overlay

This is the expected baseline when TEXCODE builds a chatting app.
