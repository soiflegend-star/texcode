(function(g){
  var CFG_KEY = 'tex_api_cfg_v1';
  function cfg(){ try { return JSON.parse(localStorage.getItem(CFG_KEY)||'{}'); } catch(e){ return {}; } }
  function saveCfg(c){ try { localStorage.setItem(CFG_KEY, JSON.stringify(c)); } catch(e){} }
  function mode(){ var c=cfg(); return (c.serverMode && c.base) ? 'server' : 'local'; }
  function base(){ return (cfg().base||'').replace(/\/$/,''); }
  function token(){ return cfg().token||''; }
  function headers(){ var h={'Content-Type':'application/json'}; if(token()) h['Authorization']='Bearer '+token(); return h; }
  async function req(path, opts){
    var r = await fetch(base()+path, Object.assign({headers: headers()}, opts||{}));
    var j = {}; try { j = await r.json(); } catch(e){}
    if (!r.ok) throw new Error(j.error||('http '+r.status)); return j;
  }
  g.TexAPI = {
    kind: 'music', mode: mode, getConfig: cfg,
    setConfig: function(partial){ var c=Object.assign(cfg(), partial||{}); saveCfg(c); return c; },
    enableServer: function(url){ return this.setConfig({ serverMode:true, base:(url||'').replace(/\/$/,'') }); },
    disableServer: function(){ return this.setConfig({ serverMode:false }); },
    health: async function(){ return req('/health'); },
    register: async function(user, pass){ return req('/api/register', { method:'POST', body: JSON.stringify({user:user, pass:pass}) }); },
    login: async function(user, pass){
      var j = await req('/api/login', { method:'POST', body: JSON.stringify({user:user, pass:pass}) });
      if (j.token) this.setConfig({ token:j.token, user:j.user, userId:j.user_id }); return j;
    },
    list: async function(collection){ return req('/api/list/'+encodeURIComponent(collection||'items')); },
    tasks: async function(){ return req('/api/tasks'); },
    upsert: async function(collection, item){ return req('/api/upsert', { method:'POST', body: JSON.stringify({ collection:collection, item:item }) }); },
    remove: async function(collection, id){ return req('/api/delete', { method:'POST', body: JSON.stringify({ collection:collection, id:id }) }); }
  };
})(window);
