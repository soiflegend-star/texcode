(function(g){
  var COLORS=['#3d2c8d','#1b4332','#7f5539','#1d3557','#6a4c93'];
  g.TGRuntime={ensure:function(){},COLORS:COLORS,all:[]};
  g.TGSeed=g.TGRuntime;
})(window);