[PRODUCT_INSTRUCTIONS]
TYPE: music — Music player (TexWave)
WHAT: A music app with library, playlists, now-playing, search, and player controls.
SCAFFOLD: MusicAppScaffold
UI_SCREENS (build all):
  1. Home / library
  2. Playlists list + playlist detail
  3. Liked / favorites
  4. Search
  5. Now playing (large art + controls)
  6. Queue sheet
  7. Settings (volume defaults, theme)
MUST_BUILD (every item):
  1. Add songs (URL or local metadata)
  2. Play / pause / next / previous
  3. Seek bar + volume
  4. Shuffle + repeat
  5. Create playlist and add tracks
  6. Liked songs list
  7. Search by title/artist
  8. Persist library + playlists
HOW_UI:
  - Dark player aesthetic: near-black, accent green or purple
  - Bottom mini-player always visible when a track is active
  - Large now-playing with cover color block
  - List rows: title · artist · duration · heart
HOW_LOGIC:
  - HTML5 audio element or Web Audio
  - store: tracks[], playlists[], liked[], queue[], index
  - Player state machine: play pause seek end→next
  - MusicAppScaffold
[END_PRODUCT_INSTRUCTIONS]
Original ask: FULL_AUTO build. Implement EVERY must-feature (all of them, not a subset). Complete Music Player with features: home made-for-you; search tracks; library all tracks; playlists; liked songs; play pause next prev; seek volume; shuffle repeat; equalizer; visualizer; import local files; localStorage persistence; now playing bar; optional local file tones. Prefer real Kotlin/Gradle Android when asked f


# Music player (TexWave) — build manual

A music app with library, playlists, now-playing, search, and player controls.

## UI screens
- Home / library
- Playlists list + playlist detail
- Liked / favorites
- Search
- Now playing (large art + controls)
- Queue sheet
- Settings (volume defaults, theme)

## Must build
- Add songs (URL or local metadata)
- Play / pause / next / previous
- Seek bar + volume
- Shuffle + repeat
- Create playlist and add tracks
- Liked songs list
- Search by title/artist
- Persist library + playlists

## How to make the UI
- Dark player aesthetic: near-black, accent green or purple
- Bottom mini-player always visible when a track is active
- Large now-playing with cover color block
- List rows: title · artist · duration · heart

## How to make it work
- HTML5 audio element or Web Audio
- store: tracks[], playlists[], liked[], queue[], index
- Player state machine: play pause seek end→next
- MusicAppScaffold

Scaffold: `MusicAppScaffold`
