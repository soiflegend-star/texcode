# TEXWAVE V7 UI Redesign Notes

## What changed

- Reserved real layout width for the persistent side rail in the main Scaffold, so the Home/Search/Library/Chat/Phantom content and bottom dock no longer render underneath the rail.
- Applied the same shared content grid to full-screen overlay destinations (Community, Reels, Downloads, Settings, Equalizer, Editor, Phantom chat, Universe and one-to-one chat). The rail remains a separate clickable navigation surface.
- Changed navigation from a pile of simultaneous overlay flags into a single-destination transition: selecting a new destination closes stale full-screen screens and transient sheets first.
- Added a visible Back action to the standalone Downloads screen while keeping the Library's embedded Downloads destination compatible.
- Reorganized the feature drawer into CORE, SOCIAL, DISCOVER, LIBRARY SESSIONS, RITUALS, PHANTOM and TOOLS AND SETTINGS. CORE and SOCIAL start expanded; deeper feature groups are collapsible. Search expands matching results so every feature remains discoverable.
- Improved Community feed layout: the feed takes only the remaining vertical space below the composer, photo posts crop cleanly inside rounded corners, and inline video frames have rounded corners and a more controlled height.

## Validation

- ZIP structure and CRC integrity checked.
- Android build not verified: the Gradle wrapper needs to download Gradle 8.5 from services.gradle.org, and network access was unavailable in this environment.
- Please build and test on-device, especially navigation between overlays, Downloads inside Library, and community media playback.
