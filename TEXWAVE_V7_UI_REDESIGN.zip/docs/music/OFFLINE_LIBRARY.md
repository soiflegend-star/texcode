# TEXWAVE Offline Music Library

## What's implemented

- Existing local-device music discovery remains powered by `MusicRepository` / MediaStore and uses the existing Media3 playback service.
- Library > Offline provides a catalog search for Internet Archive audio records.
- The catalog only offers MP3 files when the record metadata declares one of these supported licenses: CC0, CC BY 3.0/4.0, or CC BY-SA 3.0/4.0.
- Downloads use Android's `DownloadManager`, survive app restarts, and are stored in TEXWAVE's app-specific Music directory.
- Completed downloads are playable offline from Library > Offline and are passed to the existing playback helper; the existing media session/player service is not replaced.
- Download metadata (title, creator, source identifier, license URL and DownloadManager ID) is persisted locally.

## Use

1. Grant TEXWAVE audio permission so it can continue to scan local music.
2. Open Library > Offline.
3. Search for a title, or search blank to browse the catalog.
4. Download a track. Android manages the transfer and reports progress/completion.
5. Tap a completed track in Your offline tracks to play it without a network connection.

## Licensing and attribution

The catalog queries the Internet Archive metadata API and only offers tracks whose metadata declares CC0, CC BY, or CC BY-SA under the supported versions. This is a conservative filter, not a legal guarantee that every uploaded file is correctly labeled. Review the original record and license before redistribution. For CC BY and CC BY-SA tracks, retain the creator/title/source/license information and follow the license's attribution and share-alike terms. TEXWAVE does not download from Spotify or YouTube and does not bypass DRM.

Catalog availability depends on Internet Archive network access and the quality of record metadata. Only MP3 files are currently offered. The Android Gradle build could not be verified in the current environment because the Gradle 8.5 distribution was unavailable offline; compile and test the project in Android Studio or a connected build environment before publishing.
