# TEXWAVE Chat — Setup (₹0 / free tier)

You only need to do the steps below once. Everything else is already in the project.

## Free-plan limits (honest)

| Resource              | Limit                          |
|-----------------------|--------------------------------|
| Auth MAU              | 50,000                         |
| Database              | 500 MB                         |
| File storage          | 1 GB total                     |
| Max file size         | **50 MB** per file             |
| Realtime connections  | 200 concurrent                 |
| Realtime messages     | ~2 million / month             |
| Egress                | 5 GB / month                   |
| Project pause         | After 1 week of inactivity     |

No credit card is required to start. Projects pause (not delete) after inactivity — you can unpause from the dashboard.

Unsupported / not implemented in this first version:
- Group chats (schema is ready, UI not built)
- Voice / video calls
- True WebSocket push without polling fallback (polling every 4 s is active; Realtime channel code is present but optional)
- Read receipts beyond last_read_at timestamp

---

## Exact steps for you (≈ 5–8 minutes)

### 1. Create Supabase project
1. Go to https://supabase.com/dashboard
2. Sign up / log in (GitHub or email is fine)
3. Click **New project**
4. Name it `texwave-chat` (or anything)
5. Set a strong database password (save it somewhere safe — you rarely need it)
6. Choose the closest region
7. Wait until the project is ready (green)

### 2. Run the database schema
1. In the left sidebar click **SQL** → **New query**
2. Open the file `supabase/schema.sql` from this project
3. Copy **all** of its content and paste into the SQL editor
4. Click **Run**
5. You should see “Success. No rows returned”

### 3. Create the storage bucket
1. Left sidebar → **Storage** → **New bucket**
2. Name: `chat-files` (exactly)
3. **Public bucket**: OFF (private)
4. File size limit: `52428800` (50 MB)
5. Allowed MIME types: leave empty
6. Create bucket

### 4. Apply storage policies
1. SQL → New query
2. Open `supabase/storage_policies.sql`
3. Copy all → paste → **Run**

### 5. Get your keys
1. Left sidebar → **Project Settings** (gear) → **API**
2. Copy **Project URL**
3. Copy the **anon public** key (the long JWT that starts with `eyJ...`)
   - Never copy the `service_role` key into the app

### 6. Put the keys into the app
1. Open  
   `app/src/main/java/com/texgen/music/texwave/data/chat/SupabaseConfig.kt`
2. Replace the two placeholder strings:

```kotlin
const val SUPABASE_URL = "https://xxxxxxxx.supabase.co"
const val SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...."
```

3. Save the file.

### 7. Build & install
On a PC with Android Studio / JDK 17 + Android SDK:

```bash
./gradlew :app:assembleDebug
```

APK appears at:
`app/build/outputs/apk/debug/app-debug.apk`

Install on two phones (or one phone + emulator) and test:

- Register User A and User B with different emails / usernames
- On A: Chat tab → search B’s username → start chat
- Exchange text messages
- Attach a file < 50 MB and download on the other side

---

## What the app already does

- Email + password sign-up / sign-in
- Unique username (3–24 chars, a-z0-9_)
- Private 1:1 conversations (no duplicates)
- Real-time-ish messaging (poll + optional Realtime)
- File attachments up to 50 MB (images, video, audio, PDF, Office, ZIP, TAR, GZIP, etc.)
- Download + open/share via system apps
- Soft-delete own messages
- Unread counts
- Row-level security so only participants can read messages/files
- Music player completely untouched

## If something fails

- “Backend not configured” → you still have the placeholder strings in SupabaseConfig.kt
- Sign-up error about username → username already taken or invalid format
- Upload fails with size → file > 50 MB
- Download fails → storage policies not applied, or you are not a participant
- Project paused → open Supabase dashboard and click Restore / Unpause
