# TEXWAVE Chat — minimum setup (phone)

## Already done in the project
- Chat UI (Instagram-style), groups, auth screens, file attach
- Project URL prefilled: https://ascwhsyyznwgchexboug.supabase.co
- Secure SQL migration with RPCs (no client can add strangers to chats)

## You must do (unavoidable)

### A. SQL (once)
1. Open https://supabase.com/dashboard/project/ascwhsyyznwgchexboug/sql/new
2. Download/open `RUN_THIS_ONCE.sql` from the project zip
3. Paste entire file → Run

If mobile browser breaks `$fn$` quotes, use a PC browser once, or the Supabase mobile app desktop mode.

### B. Storage
Nothing to do: `RUN_THIS_ONCE.sql` now creates the `chat-files` (private) and `avatars` (public) buckets and their policies.

### C. Anon key only
1. https://supabase.com/dashboard/project/ascwhsyyznwgchexboug/settings/api
2. Copy **anon public** key
3. Put it in:
   `app/src/main/java/com/texgen/music/texwave/data/chat/SupabaseConfig.kt`
   as SUPABASE_ANON_KEY

### D. Build
./gradlew :app:assembleDebug

Never put service_role key in the app.
