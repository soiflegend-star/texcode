# TEXWAVE Community feed setup

The Community screen supports authenticated photo/video publishing, a signed-in-user feed, likes, comments, and downloads for posts that allow downloads. Reels remains a separate open-licensed discovery catalog; user-uploaded video posts appear in Community.

## One-time Supabase setup

1. Open the project's Supabase Dashboard → SQL Editor.
2. Run `supabase/002_social_feed_uploads.sql` after the existing chat schema.
3. Ensure users are signed in through the existing TEXWAVE chat/account session.
4. Rebuild and install the APK.

The migration creates `social_posts`, `social_post_likes`, `social_post_comments`, and the public `social-media` bucket. Upload/update/delete access is restricted to the authenticated user's own folder. Posts and public media are visible to signed-in users / public media URLs as configured in the migration. Each upload is capped at 50 MB by the app and storage bucket.

## Important limitations

- This is a first functional feed layer, not a full Instagram clone: video posts open in the device's video handler; there is no in-app vertical playback, notifications, reporting/moderation UI, or creator profile page yet.
- Downloads are for user-uploaded posts only. Only upload media you own or have permission to share.
- Online music availability/download rights are separate from this feed. TEXWAVE should only expose downloads from sources that permit them.
