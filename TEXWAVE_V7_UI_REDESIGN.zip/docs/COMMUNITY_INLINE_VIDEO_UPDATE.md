# TEXWAVE Community Inline Video Update

- Community video posts now render with AndroidX Media3 `PlayerView` inside the TEXWAVE feed.
- Playback uses the app's ExoPlayer integration with built-in playback controls and buffering indicator.
- Removed the external `ACTION_VIEW` handoff for community video posts.
- Video player instances are released when their feed item leaves composition.

Build status: source-level change only; Android Gradle build was not verified in this environment.
