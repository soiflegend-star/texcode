-- TEXWAVE: create chat storage buckets (run once in Supabase SQL Editor)
-- Fixes: "Bucket not found" when sending photos/files in chat

insert into storage.buckets (id, name, public, file_size_limit)
values ('chat-files', 'chat-files', false, 52428800)
on conflict (id) do update set file_size_limit = excluded.file_size_limit;

insert into storage.buckets (id, name, public, file_size_limit)
values ('avatars', 'avatars', true, 5242880)
on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit;

-- Policies for chat-files (private, conversation folder = first path segment)
drop policy if exists "Chat files: participants can upload" on storage.objects;
drop policy if exists "Chat files: participants can download" on storage.objects;
drop policy if exists "Chat files: owner can delete" on storage.objects;
drop policy if exists "Chat files authenticated upload" on storage.objects;
drop policy if exists "Chat files authenticated read" on storage.objects;

-- Simpler policies so uploads always work for signed-in users
create policy "Chat files authenticated upload"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-files');

create policy "Chat files authenticated read"
  on storage.objects for select to authenticated
  using (bucket_id = 'chat-files');

create policy "Chat files: owner can delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'chat-files' and owner = auth.uid());

-- Avatars
drop policy if exists "Avatars: public read" on storage.objects;
drop policy if exists "Avatars: owner insert" on storage.objects;
drop policy if exists "Avatars: owner update" on storage.objects;
drop policy if exists "Avatars: owner delete" on storage.objects;

create policy "Avatars: public read"
  on storage.objects for select to public
  using (bucket_id = 'avatars');

create policy "Avatars: owner insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Avatars: owner update"
  on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Avatars: owner delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

select id, name, public from storage.buckets where id in ('chat-files', 'avatars');
