# Contributing

1. Fork and create a branch: `git checkout -b feature/my-change`
2. Make sure `./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug` passes
3. Keep Kotlin code in the official style (`kotlin.code.style=official`)
4. Open a pull request describing what changed and why (screenshots welcome for UI changes)

## Project layout

```
app/src/main/java/com/texgen/music/texwave/
├── data/      MediaStore repository, models, on-device persistence
├── player/    Media3 service + controller connection
├── ui/        ViewModel, app shell, screens, components, theme
└── util/      Formatting helpers
```
