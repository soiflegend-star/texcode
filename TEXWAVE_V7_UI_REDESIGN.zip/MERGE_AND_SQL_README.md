# TEXWAVE Complete Merge (V3 base + new UI features)

## What this is
Full TEXWAVE V3 project with additive features from the partial GitHub build:
- Action wheel (settings) on every session
- Chat social/settings sidebar
- Memes screen, Waves screen, Drawing canvas
- Design tokens, PhantomStudio, TEXCODE rulebook assets

Original V3 modules preserved: PlaybackService, player/*, data/*, chat repository (1285 lines), PNGs, WAVs, notifications.

## Supabase SQL (run once)
Dashboard → SQL Editor → New query → paste **TEXWAVE_CHAT_SQL_FIXED.sql** → Run.

Also acceptable: `supabase/` scripts or root `CREATE_*` / `RUN_THIS_ONCE.sql` from V3 if already applied.

API key is in `SupabaseConfig` (publishable). Never add service_role.

## Build
```bash
chmod +x gradlew
./gradlew :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## GitHub
Push this folder as repo root (gradlew at top). Actions workflows under `.github/workflows/`.
