-- =============================================================================
-- TEXWAVE — Storage buckets + Stories (run once)
-- WHERE TO RUN:
--   1. Open https://supabase.com/dashboard
--   2. Select your project (ascwhsyyznwgchexboug)
--   3. Left sidebar → SQL Editor → New query
--   4. Paste this entire file → click Run
-- =============================================================================

-- 1) Chat file + avatar buckets (fixes "Bucket not found")
insert into storage.buckets (id, name, public, file_size_limit)
values ('chat-files', 'chat-files', false, 52428800)
on conflict (id) do update set file_size_limit = excluded.file_size_limit;

insert into storage.buckets (id, name, public, file_size_limit)
values ('avatars', 'avatars', true, 5242880)
on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit;

insert into storage.buckets (id, name, public, file_size_limit)
values ('stories', 'stories', true, 10485760)
on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit;

-- 2) Storage policies (simple + reliable for authenticated users)
drop policy if exists "Chat files authenticated upload" on storage.objects;
drop policy if exists "Chat files authenticated read" on storage.objects;
drop policy if exists "Chat files: owner can delete" on storage.objects;
drop policy if exists "Chat files: participants can upload" on storage.objects;
drop policy if exists "Chat files: participants can download" on storage.objects;

create policy "Chat files authenticated upload"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-files');

create policy "Chat files authenticated read"
  on storage.objects for select to authenticated
  using (bucket_id = 'chat-files');

create policy "Chat files: owner can delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'chat-files' and owner = auth.uid());

drop policy if exists "Avatars: public read" on storage.objects;
drop policy if exists "Avatars: owner insert" on storage.objects;
drop policy if exists "Avatars: owner update" on storage.objects;
drop policy if exists "Avatars: owner delete" on storage.objects;

create policy "Avatars: public read"
  on storage.objects for select to public
  using (bucket_id = 'avatars');

create policy "Avatars: owner insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Avatars: owner update"
  on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Avatars: owner delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "Stories public read" on storage.objects;
drop policy if exists "Stories owner insert" on storage.objects;
drop policy if exists "Stories owner delete" on storage.objects;

create policy "Stories public read"
  on storage.objects for select to public
  using (bucket_id = 'stories');

create policy "Stories owner insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'stories' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "Stories owner delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'stories' and (storage.foldername(name))[1] = auth.uid()::text);

-- 3) Stories table (24h)
create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  media_url text not null,
  caption text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);
create index if not exists stories_expires_idx on public.stories (expires_at desc);
create index if not exists stories_user_idx on public.stories (user_id, created_at desc);

alter table public.stories enable row level security;

drop policy if exists "stories_select" on public.stories;
drop policy if exists "stories_insert" on public.stories;
drop policy if exists "stories_delete" on public.stories;

create policy "stories_select" on public.stories for select to authenticated
  using (expires_at > now());

create policy "stories_insert" on public.stories for insert to authenticated
  with check (auth.uid() = user_id);

create policy "stories_delete" on public.stories for delete to authenticated
  using (auth.uid() = user_id);

-- List stories with author profile
create or replace function public.list_active_stories()
returns table (
  id uuid,
  user_id uuid,
  media_url text,
  caption text,
  created_at timestamptz,
  expires_at timestamptz,
  username text,
  display_name text,
  avatar_url text
)
language sql
stable
security definer
set search_path = public
as $$
  select s.id, s.user_id, s.media_url, s.caption, s.created_at, s.expires_at,
         p.username, p.display_name, p.avatar_url
  from public.stories s
  join public.profiles p on p.id = s.user_id
  where s.expires_at > now()
  order by s.created_at desc
  limit 80;
$$;

grant execute on function public.list_active_stories() to authenticated;

-- 4) Realtime for messages (notifications / live list)
do $$
begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
end $$;

-- 5) Confirm check
select id, name, public from storage.buckets
where id in ('chat-files', 'avatars', 'stories');
