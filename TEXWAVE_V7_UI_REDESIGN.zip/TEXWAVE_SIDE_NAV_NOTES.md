# V6
- Bottom dock restored: Home, Search, Library, Phantom.
- Side menu in the Chat-sidebar style: open first, close with the X / dark area / swipe left / Back; edge tab reopens it on every session.
- Library tabs: All, Songs, Constellation (one tap opens full screen), Albums, Artists, Playlists, Liked, Radar, 12 sessions, Explore.
- Menu holds every old 3-dot item plus Chats, Phantom, Alarms and more.
- Overlay screens (Settings, Equalizer, Editor, Phantom chat, Chat, Universe) now swallow stray taps.
