-- =====================================================================
-- TEXWAVE — cloud backup of your music data (favorites, playlists, play counts, recents).
-- Supabase Dashboard -> SQL Editor -> New query -> paste ALL -> Run. Safe to run again.
-- (Chats / profile already live in Supabase; this adds the music data.)
-- =====================================================================
create table if not exists public.app_user_data (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.app_user_data enable row level security;

drop policy if exists "own data select" on public.app_user_data;
drop policy if exists "own data insert" on public.app_user_data;
drop policy if exists "own data update" on public.app_user_data;
create policy "own data select" on public.app_user_data for select using (auth.uid() = user_id);
create policy "own data insert" on public.app_user_data for insert with check (auth.uid() = user_id);
create policy "own data update" on public.app_user_data for update using (auth.uid() = user_id);
