# TEXWAVE + Aether UI integration notes

This merge keeps TEXWAVE's native Android/Jetpack Compose architecture and existing music playback, Supabase chat/profile, Phantom AI, search, and voice/wake-word paths. It does not copy Aether's Python/Kivy runtime into Android; those Python modules are not directly executable as native Kotlin screens.

## Added in this merge
- New sixth bottom-navigation destination: **Alarm**.
- Multiple labelled alarms with one-time or daily-repeat scheduling.
- Android AlarmManager alarm-clock scheduling, alarm notification channel, and boot-time rescheduling.
- Exact-alarm access prompt on Android 12+.
- Existing music/chat/profile code and Supabase setup are preserved.

## First-run notes
- Grant **Alarms & reminders** / exact alarm access when Android asks.
- Allow TEXWAVE notifications so alarm alerts can appear.
- Test with a short lead time first. Device vendor battery restrictions can affect background delivery.
- The Aether Python AI engines, OCR/image connector, and standalone note/memory stores are not automatically merged by this native UI integration; they require deliberate Kotlin/API ports rather than copying Python files into the APK.
