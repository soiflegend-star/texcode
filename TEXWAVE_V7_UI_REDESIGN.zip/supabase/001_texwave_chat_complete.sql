-- =====================================================================
-- TEXWAVE CHAT — ONE script that fixes everything on the Supabase side.
-- Supabase Dashboard -> SQL Editor -> New query -> paste ALL -> Run.
-- Safe to run again any time (idempotent). No other SQL file is needed.
--
-- What this does
--   1. Any email can sign up and log in right away (accounts are auto-confirmed,
--      old unconfirmed accounts are confirmed too).
--   2. Every account always gets a profile (signup trigger + repair function +
--      back-fill of old accounts), so Profile and Search work for everybody.
--   3. Search function: finds people by @username, display name, exact email
--      or user id.
--   4. Online / last seen, "seen" ticks and instant delivery (realtime).
--   5. Storage buckets + policies: chat-files (private) and avatars (public).
-- =====================================================================

-- ========== TABLES ==========
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null,
  avatar_url text,
  bio text,
  last_seen_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles add column if not exists last_seen_at timestamptz;
alter table public.profiles add column if not exists bio text;
alter table public.profiles add column if not exists avatar_url text;
create index if not exists profiles_username_idx on public.profiles (username);
do $fn$
begin
  create unique index if not exists profiles_username_lower_idx on public.profiles (lower(username));
exception when others then
  raise notice 'Skipped case-insensitive username index: %', sqlerrm;
end;
$fn$;

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  is_group boolean not null default false,
  title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversation_participants (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  last_read_at timestamptz,
  primary key (conversation_id, user_id)
);
create index if not exists participants_user_idx on public.conversation_participants (user_id);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text,
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted_at timestamptz,
  client_msg_id text
);
create index if not exists messages_conv_created_idx on public.messages (conversation_id, created_at desc);

create table if not exists public.attachments (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references public.messages(id) on delete cascade,
  storage_path text not null,
  original_name text not null,
  mime_type text not null,
  size_bytes bigint not null,
  created_at timestamptz not null default now()
);
create index if not exists attachments_message_idx on public.attachments (message_id);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reported_id uuid not null references public.profiles(id) on delete cascade,
  reason text,
  created_at timestamptz not null default now()
);

-- ========== EMAIL: ANY EMAIL CAN SIGN UP AND LOG IN ==========
-- Marks every new account as confirmed the moment it is created, so you never
-- have to type an email into the SQL editor again.
create or replace function public.texwave_autoconfirm_email()
returns trigger
language plpgsql
security definer
set search_path = public
as $fn$
begin
  if new.email_confirmed_at is null then
    new.email_confirmed_at := now();
  end if;
  return new;
end;
$fn$;

do $fn$
begin
  drop trigger if exists texwave_autoconfirm on auth.users;
  create trigger texwave_autoconfirm
    before insert on auth.users
    for each row execute function public.texwave_autoconfirm_email();
exception when others then
  raise notice 'Could not install auto-confirm trigger: %', sqlerrm;
end;
$fn$;

-- Confirm every account that is still waiting for confirmation.
update auth.users
set email_confirmed_at = now()
where email_confirmed_at is null;

-- ========== PROFILES: ALWAYS EXIST ==========
create or replace function public.create_profile_for(uid uuid, em text, meta jsonb)
returns public.profiles
language plpgsql
security definer
set search_path = public
as $fn$
declare
  base text;
  cand text;
  n int := 0;
  dn text;
  p public.profiles;
begin
  select * into p from public.profiles where id = uid;
  if found then return p; end if;

  base := lower(regexp_replace(lower(coalesce(meta->>'username', '')), '[^a-z0-9_]', '', 'g'));
  if length(base) < 3 then
    base := lower(regexp_replace(split_part(coalesce(em, ''), '@', 1), '[^a-zA-Z0-9_]', '', 'g'));
  end if;
  if length(base) < 3 then
    base := 'user_' || substr(replace(uid::text, '-', ''), 1, 8);
  end if;
  base := left(base, 20);
  cand := base;
  while exists (select 1 from public.profiles where lower(username) = cand) loop
    n := n + 1;
    cand := base || n::text;
  end loop;

  dn := coalesce(
    nullif(trim(meta->>'display_name'), ''),
    nullif(initcap(split_part(coalesce(em, ''), '@', 1)), ''),
    'Texwave User'
  );

  insert into public.profiles (id, username, display_name)
  values (uid, cand, left(dn, 40))
  on conflict (id) do nothing;

  select * into p from public.profiles where id = uid;
  return p;
end;
$fn$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $fn$
begin
  perform public.create_profile_for(new.id, new.email, coalesce(new.raw_user_meta_data, '{}'::jsonb));
  return new;
exception when others then
  -- never block a signup; the app repairs the profile through ensure_my_profile()
  return new;
end;
$fn$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- The app calls this after every login: creates the profile if it is missing.
create or replace function public.ensure_my_profile()
returns public.profiles
language plpgsql
security definer
set search_path = public, auth
as $fn$
declare
  me uuid := auth.uid();
  u record;
begin
  if me is null then
    raise exception 'Not authenticated';
  end if;
  select id, email, raw_user_meta_data into u from auth.users where id = me;
  return public.create_profile_for(me, u.email, coalesce(u.raw_user_meta_data, '{}'::jsonb));
end;
$fn$;

-- Back-fill profiles for accounts that were created before the trigger existed.
do $fn$
declare r record;
begin
  for r in
    select u.id, u.email, u.raw_user_meta_data
    from auth.users u
    left join public.profiles p on p.id = u.id
    where p.id is null
  loop
    perform public.create_profile_for(r.id, r.email, coalesce(r.raw_user_meta_data, '{}'::jsonb));
  end loop;
end;
$fn$;

-- Used by the sign-up form to warn "username taken" BEFORE the account is created.
create or replace function public.username_available(u text)
returns boolean
language sql
stable
security definer
set search_path = public
as $fn$
  select not exists (select 1 from public.profiles where lower(username) = lower(trim(u)));
$fn$;

-- ========== HELPERS ==========
create or replace function public.is_participant(conv_id uuid, uid uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $fn$
  select exists (
    select 1 from public.conversation_participants
    where conversation_id = conv_id and user_id = uid
  );
$fn$;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $fn$
begin
  new.updated_at = now();
  return new;
end;
$fn$;

drop trigger if exists profiles_updated on public.profiles;
create trigger profiles_updated
  before update on public.profiles
  for each row execute function public.set_updated_at();

drop trigger if exists conversations_updated on public.conversations;
create trigger conversations_updated
  before update on public.conversations
  for each row execute function public.set_updated_at();

-- A new message moves its conversation to the top of everybody's list.
create or replace function public.bump_conversation()
returns trigger
language plpgsql
security definer
set search_path = public
as $fn$
begin
  update public.conversations set updated_at = now() where id = new.conversation_id;
  return new;
end;
$fn$;

drop trigger if exists messages_bump_conversation on public.messages;
create trigger messages_bump_conversation
  after insert on public.messages
  for each row execute function public.bump_conversation();

-- ========== SEARCH ==========
-- Finds people by @username (partial), display name (partial),
-- exact email, or exact user id. Never returns yourself.
create or replace function public.search_users(q text)
returns setof public.profiles
language plpgsql
stable
security definer
set search_path = public, auth
as $fn$
declare
  t text := lower(trim(coalesce(q, '')));
  pat text;
begin
  if left(t, 1) = '@' then t := substr(t, 2); end if;
  -- allow 1+ chars so short usernames and partial emails still match
  if auth.uid() is null or length(t) < 1 then
    return;
  end if;
  pat := '%' || replace(replace(replace(t, E'\', E'\\'), '%', E'\%'), '_', E'\_') || '%';
  return query
    select p.*
    from public.profiles p
    where p.id <> auth.uid()
      and (
        lower(p.username) like pat escape '\'
        or lower(coalesce(p.display_name, '')) like pat escape '\'
        or p.id::text = t
        -- exact or partial email (security definer can read auth.users)
        or exists (
          select 1 from auth.users u
          where u.id = p.id
            and lower(coalesce(u.email, '')) like pat escape '\'
        )
      )
    order by
      (lower(p.username) = t) desc,
      (lower(p.username) like (replace(replace(replace(t, E'\', E'\\'), '%', E'\%'), '_', E'\_') || '%') escape '\') desc,
      (exists (select 1 from auth.users u where u.id = p.id and lower(u.email) = t)) desc,
      p.username
    limit 40;
end;
$fn$;

-- ========== ONLINE / SEEN ==========
create or replace function public.touch_presence()
returns void
language sql
security definer
set search_path = public
as $fn$
  update public.profiles set last_seen_at = now() where id = auth.uid();
$fn$;

create or replace function public.mark_conversation_read(conv uuid)
returns void
language sql
security definer
set search_path = public
as $fn$
  update public.conversation_participants
  set last_read_at = now()
  where conversation_id = conv and user_id = auth.uid();
$fn$;

-- ========== SECURE CONVERSATION RPCs ==========
create or replace function public.create_direct_conversation(other_user_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $fn$
declare
  me uuid := auth.uid();
  existing_id uuid;
  new_id uuid;
begin
  if me is null then
    raise exception 'Not authenticated';
  end if;
  if other_user_id is null or other_user_id = me then
    raise exception 'Invalid other user';
  end if;
  if not exists (select 1 from public.profiles where id = other_user_id) then
    raise exception 'User not found';
  end if;
  if exists (
    select 1 from public.blocks
    where (blocker_id = me and blocked_id = other_user_id)
       or (blocker_id = other_user_id and blocked_id = me)
  ) then
    raise exception 'Cannot message this user';
  end if;

  select c.id into existing_id
  from public.conversations c
  where c.is_group = false
    and exists (select 1 from public.conversation_participants p
                where p.conversation_id = c.id and p.user_id = me)
    and exists (select 1 from public.conversation_participants p
                where p.conversation_id = c.id and p.user_id = other_user_id)
    and (select count(*) from public.conversation_participants p
         where p.conversation_id = c.id) = 2
  limit 1;

  if existing_id is not null then
    return existing_id;
  end if;

  insert into public.conversations (is_group) values (false) returning id into new_id;
  insert into public.conversation_participants (conversation_id, user_id, last_read_at)
  values (new_id, me, now()), (new_id, other_user_id, null);
  return new_id;
end;
$fn$;

create or replace function public.create_group_conversation(group_title text, member_ids uuid[])
returns uuid
language plpgsql
security definer
set search_path = public
as $fn$
declare
  me uuid := auth.uid();
  new_id uuid;
  uid uuid;
begin
  if me is null then
    raise exception 'Not authenticated';
  end if;
  if group_title is null or length(trim(group_title)) < 2 then
    raise exception 'Group name too short';
  end if;
  if member_ids is null or array_length(member_ids, 1) is null then
    raise exception 'Add at least one member';
  end if;

  insert into public.conversations (is_group, title)
  values (true, left(trim(group_title), 40))
  returning id into new_id;

  insert into public.conversation_participants (conversation_id, user_id, last_read_at)
  values (new_id, me, now());

  foreach uid in array member_ids
  loop
    if uid is distinct from me and exists (select 1 from public.profiles where id = uid) then
      insert into public.conversation_participants (conversation_id, user_id)
      values (new_id, uid)
      on conflict do nothing;
    end if;
  end loop;

  return new_id;
end;
$fn$;

-- ========== RLS ==========
alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_participants enable row level security;
alter table public.messages enable row level security;
alter table public.attachments enable row level security;
alter table public.blocks enable row level security;
alter table public.reports enable row level security;

drop policy if exists "profiles_select" on public.profiles;
drop policy if exists "profiles_insert" on public.profiles;
drop policy if exists "profiles_update" on public.profiles;
drop policy if exists "Profiles are viewable by authenticated users" on public.profiles;
drop policy if exists "Users can update own profile" on public.profiles;
create policy "profiles_select" on public.profiles for select to authenticated using (true);
create policy "profiles_insert" on public.profiles for insert to authenticated
  with check (auth.uid() = id);
create policy "profiles_update" on public.profiles for update to authenticated
  using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "conv_select" on public.conversations;
drop policy if exists "conv_insert" on public.conversations;
drop policy if exists "Participants can view conversations" on public.conversations;
drop policy if exists "Authenticated can create conversations" on public.conversations;
create policy "conv_select" on public.conversations for select to authenticated
  using (public.is_participant(id, auth.uid()));

drop policy if exists "parts_select" on public.conversation_participants;
drop policy if exists "parts_insert" on public.conversation_participants;
drop policy if exists "parts_update" on public.conversation_participants;
drop policy if exists "Participants can view members" on public.conversation_participants;
drop policy if exists "Users can join as themselves" on public.conversation_participants;
drop policy if exists "Users can update own last_read" on public.conversation_participants;
create policy "parts_select" on public.conversation_participants for select to authenticated
  using (public.is_participant(conversation_id, auth.uid()));
create policy "parts_update" on public.conversation_participants for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "msg_select" on public.messages;
drop policy if exists "msg_insert" on public.messages;
drop policy if exists "msg_update" on public.messages;
drop policy if exists "Participants can read messages" on public.messages;
drop policy if exists "Participants can send messages" on public.messages;
drop policy if exists "Senders can soft-delete own messages" on public.messages;
create policy "msg_select" on public.messages for select to authenticated
  using (public.is_participant(conversation_id, auth.uid()));
create policy "msg_insert" on public.messages for insert to authenticated
  with check (sender_id = auth.uid() and public.is_participant(conversation_id, auth.uid()));
create policy "msg_update" on public.messages for update to authenticated
  using (sender_id = auth.uid()) with check (sender_id = auth.uid());

drop policy if exists "att_select" on public.attachments;
drop policy if exists "att_insert" on public.attachments;
drop policy if exists "Participants can view attachments" on public.attachments;
drop policy if exists "Participants can insert attachments" on public.attachments;
create policy "att_select" on public.attachments for select to authenticated
  using (exists (
    select 1 from public.messages m
    where m.id = message_id and public.is_participant(m.conversation_id, auth.uid())
  ));
create policy "att_insert" on public.attachments for insert to authenticated
  with check (exists (
    select 1 from public.messages m
    where m.id = message_id and m.sender_id = auth.uid()
      and public.is_participant(m.conversation_id, auth.uid())
  ));

drop policy if exists "blocks_all" on public.blocks;
drop policy if exists "Users manage own blocks" on public.blocks;
create policy "blocks_all" on public.blocks for all to authenticated
  using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

drop policy if exists "reports_insert" on public.reports;
drop policy if exists "Users can create reports" on public.reports;
create policy "reports_insert" on public.reports for insert to authenticated
  with check (reporter_id = auth.uid());

-- ========== GRANTS ==========
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant execute on all functions in schema public to authenticated;
grant execute on function public.username_available(text) to anon;

-- ========== REALTIME ==========
do $fn$
begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
end;
$fn$;
do $fn$
begin
  alter publication supabase_realtime add table public.conversations;
exception when duplicate_object then null;
end;
$fn$;
do $fn$
begin
  alter publication supabase_realtime add table public.conversation_participants;
exception when duplicate_object then null;
end;
$fn$;

-- ========== STORAGE (buckets + policies) ==========
-- Kept in guarded blocks so a storage hiccup can never undo the parts above.
do $fn$
begin
  insert into storage.buckets (id, name, public, file_size_limit)
  values ('chat-files', 'chat-files', false, 52428800)
  on conflict (id) do update set file_size_limit = excluded.file_size_limit;

  insert into storage.buckets (id, name, public, file_size_limit)
  values ('avatars', 'avatars', true, 5242880)
  on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit;
exception when others then
  raise notice 'Could not create storage buckets (create "chat-files" private and "avatars" public by hand): %', sqlerrm;
end;
$fn$;

do $fn$
begin
  -- chat-files: private, only members of the conversation (first folder = conversation id)
  drop policy if exists "Chat files: participants can upload" on storage.objects;
  drop policy if exists "Chat files: participants can download" on storage.objects;
  drop policy if exists "Chat files: owner can delete" on storage.objects;

  create policy "Chat files: participants can upload"
    on storage.objects for insert to authenticated
    with check (
      bucket_id = 'chat-files'
      and case
            when (storage.foldername(name))[1] ~ '^[0-9a-fA-F-]{36}$'
              then public.is_participant(((storage.foldername(name))[1])::uuid, auth.uid())
            else false
          end
    );

  create policy "Chat files: participants can download"
    on storage.objects for select to authenticated
    using (
      bucket_id = 'chat-files'
      and case
            when (storage.foldername(name))[1] ~ '^[0-9a-fA-F-]{36}$'
              then public.is_participant(((storage.foldername(name))[1])::uuid, auth.uid())
            else false
          end
    );

  create policy "Chat files: owner can delete"
    on storage.objects for delete to authenticated
    using (bucket_id = 'chat-files' and owner = auth.uid());

  -- avatars: public to read, each user writes only inside their own folder
  drop policy if exists "Avatars: public read" on storage.objects;
  drop policy if exists "Avatars: owner insert" on storage.objects;
  drop policy if exists "Avatars: owner update" on storage.objects;
  drop policy if exists "Avatars: owner delete" on storage.objects;

  create policy "Avatars: public read"
    on storage.objects for select to public
    using (bucket_id = 'avatars');

  create policy "Avatars: owner insert"
    on storage.objects for insert to authenticated
    with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

  create policy "Avatars: owner update"
    on storage.objects for update to authenticated
    using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
    with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

  create policy "Avatars: owner delete"
    on storage.objects for delete to authenticated
    using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
exception when others then
  raise notice 'Could not create storage policies: %', sqlerrm;
end;
$fn$;

-- Done. Quick self-check (should show your accounts, all confirmed, all with a profile):
select u.email,
       u.email_confirmed_at is not null as confirmed,
       p.username
from auth.users u
left join public.profiles p on p.id = u.id
order by u.created_at desc
limit 20;
