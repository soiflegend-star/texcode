<p align="center"><img src="docs/icon.png" width="120" alt="Texwave icon"></p>
<h1 align="center">Texwave</h1>
<p align="center">
  A fast, beautiful, fully offline music player for Android.<br>
  Kotlin · Jetpack Compose · Media3
</p>

<p align="center">
  <a href="../../actions/workflows/android.yml"><img alt="Android CI" src="../../actions/workflows/android.yml/badge.svg"></a>
  <img alt="Min SDK 26" src="https://img.shields.io/badge/minSdk-26-7C5CFF">
  <img alt="License MIT" src="https://img.shields.io/badge/license-MIT-00E5C3">
</p>

## Features

| | |
|---|---|
| **Library** | Scans your device with MediaStore — no accounts, no network |
| **Now Playing** | Large artwork, adaptive colour backdrop, seek bar, shuffle, repeat |
| **Mini player** | Always-visible controls with live progress |
| **Home** | Shuffle-all hero, jump back in, auto-generated artist mixes, recently added |
| **Search** | Instant search by title, artist or album; browse by artist |
| **Playlists & likes** | Create playlists, like songs — persisted on-device |
| **Queue** | Play next, add to queue, jump / remove from queue |
| **Background playback** | Media3 `MediaSessionService`: notification, lock-screen and headset controls, audio-focus handling |
| **Themes** | Built-in + searchable internet catalog; apply instantly on the player UI |
| **Notification styles** | Animated / custom notification artwork (title & artist stay readable) |
| **Custom cover art** | Set a personal image for any track from the gallery |
| **Equalizer** | Multi-band EQ with presets |
| **Music Editor** | Trim tracks and export to Music/Texwave |

## Resonance Universe design reference

The four-screen concept reference is available at `docs/texwave-resonance-portal-reference.png`. The Kotlin UI uses the concept as a design direction while keeping playback, library totals, and Phantom insights connected to real app state. The breathing atmosphere and artwork animations are intentionally restrained for phone performance.

## Tech stack

- Kotlin 1.9, Jetpack Compose (Material 3), single-activity
- AndroidX Media3 (ExoPlayer + MediaSession)
- Coil for album art
- `StateFlow`-driven `ViewModel`, SharedPreferences persistence
- GitHub Actions: build, unit tests, lint, tag-based releases

## Build

Requirements: Android Studio Hedgehog+ (or JDK 17 + Android SDK 34).

```bash
./gradlew :app:assembleDebug        # debug APK → app/build/outputs/apk/debug/
./gradlew :app:testDebugUnitTest    # unit tests
```

Install the APK, allow audio access, and your music appears.

### Signed release builds

Set `TEXWAVE_KEYSTORE`, `TEXWAVE_KEYSTORE_PASSWORD`, `TEXWAVE_KEY_ALIAS`, `TEXWAVE_KEY_PASSWORD`
and run `./gradlew :app:assembleRelease`. For CI releases, push a `v*` tag and add the matching
repository secrets (`TEXWAVE_KEYSTORE_BASE64`, …) — see `.github/workflows/release.yml`.

## Project structure

See [CONTRIBUTING.md](CONTRIBUTING.md). The original HTML/JS prototype lives in [`legacy-web/`](legacy-web).

## Notes

- Only shows audio that Android's MediaStore has indexed (tracks over 30 s, flagged as music).
- Album art uses MediaStore thumbnails when available, otherwise a generated gradient.

## License

[MIT](LICENSE)

## Chat (new)

Private 1:1 messaging powered by free Supabase.

See **[docs/chat/SETUP.md](docs/chat/SETUP.md)** for the 6 short steps you must do once (create project, run SQL, paste keys).

- Tab **Chat** in the bottom navigation
- Email sign-up / sign-in, unique username search
- Text + file attachments up to 50 MB (free-plan limit)
- Music player is completely unchanged
