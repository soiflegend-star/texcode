package com.texgen.music.texwave.ui.components

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.util.UiSound
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.launch

/*
 * EngageKit — the "can't put it down" layer.
 *
 *  • Drops      story-style rings: unseen ones glow and spin, seen ones go quiet (reset every day)
 *  • Streak     a daily-return flame with a 7-dot week meter
 *  • Feed       a scrollable "For you" feed with double-tap-to-love, heart burst and haptics
 *  • Caught up  an end-of-feed card whose button reshuffles the whole feed
 *  • Backdrop   a slow living galaxy behind Home, so the intro's vibe never fully ends
 *
 * Everything is driven by the user's own library; nothing here invents counts or fake people.
 */

// ───────────────────────────── persistence ─────────────────────────────

object EngageStore {
    private const val PREFS = "texwave_engage"

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Local calendar day number (changes at the user's midnight). */
    fun today(): Long {
        val now = System.currentTimeMillis()
        return (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    fun streak(ctx: Context): Int {
        val p = prefs(ctx)
        val last = p.getLong("last_day", -1L)
        val s = p.getInt("streak", 0)
        return if (last == today() || last == today() - 1) s.coerceAtLeast(1) else 1
    }

    /** Call once per visit: extends the streak if yesterday was the last visit, restarts it after a gap. */
    fun touchStreak(ctx: Context): Int {
        val p = prefs(ctx)
        val td = today()
        val last = p.getLong("last_day", -1L)
        val old = p.getInt("streak", 0)
        if (last == td) return old.coerceAtLeast(1)
        val next = if (last == td - 1) old + 1 else 1
        p.edit().putLong("last_day", td).putInt("streak", next).apply()
        return next
    }

    fun seenDrops(ctx: Context): Set<String> {
        val p = prefs(ctx)
        if (p.getLong("seen_day", -1L) != today()) return emptySet()
        return (p.getStringSet("seen", null) ?: emptySet()).toSet()
    }

    fun markSeen(ctx: Context, id: String) {
        val p = prefs(ctx)
        val keep = seenDrops(ctx) + id
        p.edit().putLong("seen_day", today()).putStringSet("seen", keep).apply()
    }
}

// ───────────────────────────── haptics ─────────────────────────────

/** Light "tick" for taps. Never throws. */
@Composable
fun rememberTick(): () -> Unit {
    val h = LocalHapticFeedback.current
    return remember(h) { { runCatching { h.performHapticFeedback(HapticFeedbackType.TextHandleMove) }; Unit } }
}

/** Heavier "thump" for rewarding moments (a like, a drop opening). Never throws. */
@Composable
fun rememberThump(): () -> Unit {
    val h = LocalHapticFeedback.current
    return remember(h) { { runCatching { h.performHapticFeedback(HapticFeedbackType.LongPress) }; Unit } }
}

// ───────────────────────────── galaxy backdrop ─────────────────────────────

private class GDust(val arm: Int, val r: Float, val jitter: Float, val size: Float, val hue: Int, val phase: Float)

private fun galaxyTint(h: Int): Color = when (h) {
    0 -> Color(0xFFFFFFFF)
    1 -> Color(0xFFBFA8FF)
    2 -> Color(0xFF8FEFFF)
    else -> Color(0xFFFF9EE6)
}

/**
 * A slow, living galaxy for behind Home: the intro's spiral carries on at a whisper. Loops seamlessly,
 * reads its animation state only while drawing (no recomposition), ~240 dots.
 */
@Composable
fun GalaxyBackdrop(modifier: Modifier = Modifier) {
    val dust = remember {
        val r = Random(21)
        List(240) { GDust(r.nextInt(3), r.nextFloat().pow(0.8f), (r.nextFloat() - 0.5f) * 0.35f, 0.4f + r.nextFloat() * 1.3f, r.nextInt(4), r.nextFloat() * 6.28f) }
    }
    val t = rememberInfiniteTransition(label = "galaxyBackdrop")
    val spin = t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(110_000, easing = LinearEasing)), label = "gSpin")
    val drift = t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(18_000, easing = LinearEasing)), label = "gDrift")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w * 0.5f, h * 0.60f)
        val sp = spin.value
        val dr = drift.value
        val tilt = -0.38f
        val ct = cos(tilt)
        val st = sin(tilt)
        // soft nebula light that breathes
        val glowR = w * (0.95f + 0.04f * sin(dr))
        drawCircle(
            Brush.radialGradient(listOf(Color(0x2E6A3BFF), Color(0x14FF2FC2), Color.Transparent), c, glowR),
            glowR, c,
        )
        dust.forEach { s ->
            val rr = s.r * w * 0.72f
            val a = s.arm * 2.0944f + s.r * 5.2f + s.jitter + sp
            val x0 = cos(a) * rr
            val y0 = sin(a) * rr * 0.42f
            val p = Offset(c.x + x0 * ct - y0 * st, c.y + x0 * st + y0 * ct)
            val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin(dr * 2f + s.phase))
            drawCircle(galaxyTint(s.hue).copy(alpha = 0.34f * tw * (1f - s.r * 0.5f)), s.size * density, p)
        }
        val core = w * 0.16f
        drawCircle(
            Brush.radialGradient(listOf(Color(0x55FFFFFF), Color(0x33B79CFF), Color.Transparent), c, core),
            core, c,
        )
    }
}

// ───────────────────────────── drops (story-style rings) ─────────────────────────────

class Drop(val id: String, val title: String, val songs: List<Song>)

/** Builds today's drops from the library. Deterministic per day, so rings do not reshuffle while you use the app. */
fun buildDrops(songs: List<Song>, liked: Set<Long>, counts: Map<Long, Int>, day: Long): List<Drop> {
    if (songs.isEmpty()) return emptyList()
    val out = ArrayList<Drop>()
    out += Drop("daily", "Daily Mix", songs.shuffled(Random(day)).take(30))
    out += Drop("fresh", "Fresh", songs.sortedByDescending { it.dateAdded }.take(25))
    val unheard = songs.filter { (counts[it.id] ?: 0) == 0 }
    if (unheard.size >= 3) out += Drop("rediscover", "Unheard", unheard.shuffled(Random(day + 1)).take(25))
    val fav = songs.filter { it.id in liked }
    if (fav.isNotEmpty()) out += Drop("fav", "Loved", fav.shuffled(Random(day + 2)).take(30))
    val repeat = songs.filter { (counts[it.id] ?: 0) > 0 }.sortedByDescending { counts[it.id] ?: 0 }.take(20)
    if (repeat.isNotEmpty()) out += Drop("repeat", "On Repeat", repeat)
    return out
}

@Composable
fun DropRing(drop: Drop, seen: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val thump = rememberThump()
    val t = rememberInfiniteTransition(label = "dropRing")
    val rot = t.animateFloat(0f, 360f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "dropRot")
    val pulse = t.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dropPulse")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.9f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "dropPress")
    Column(
        modifier
            .width(78.dp)
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clickable(interactionSource = src, indication = null) { thump(); onClick() },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(70.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 3f * density
                val rad = size.minDimension / 2f - stroke
                if (seen) {
                    drawCircle(Color(0x33FFFFFF), rad, style = Stroke(stroke))
                } else {
                    // soft halo, then the spinning gradient ring
                    drawCircle(Color(0xFF8A5CFF).copy(alpha = 0.22f * pulse.value), rad + stroke * 1.6f)
                    rotate(rot.value) {
                        drawCircle(
                            Brush.sweepGradient(listOf(Color(0xFF3DE0FF), Color(0xFF8A5CFF), Color(0xFFE040C0), Color(0xFFFFB347), Color(0xFF3DE0FF))),
                            rad, style = Stroke(stroke),
                        )
                    }
                }
            }
            Artwork(
                drop.songs.firstOrNull(),
                Modifier.size(58.dp).graphicsLayer { alpha = if (seen) 0.55f else 1f },
                corner = 29.dp,
                iconSize = 22.dp,
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            drop.title,
            color = if (seen) Color(0xFF7A829E) else Color.White,
            fontSize = 11.sp,
            fontWeight = if (seen) FontWeight.Normal else FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

// ───────────────────────────── streak ─────────────────────────────

@Composable
fun StreakChip(days: Int, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "streak")
    val glow = t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "streakGlow")
    val shape = RoundedCornerShape(20.dp)
    val filled = ((days - 1).coerceAtLeast(0) % 7) + 1
    Row(
        modifier
            .clip(shape)
            .background(Color(0x26FF8A3D))
            .border(1.dp, Brush.horizontalGradient(listOf(Color(0xAAFFB347), Color(0xAAFF3D8B))), shape)
            .padding(start = 8.dp, end = 10.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Rounded.LocalFireDepartment, null, tint = Color(0xFFFFA24A),
            modifier = Modifier.size(18.dp).graphicsLayer {
                val g = glow.value
                alpha = 0.6f + 0.4f * g
                scaleX = 0.92f + 0.12f * g
                scaleY = 0.92f + 0.12f * g
            },
        )
        Spacer(Modifier.width(4.dp))
        Text(
            if (days == 1) "1 day" else "$days days",
            color = Color(0xFFFFD2A0), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.width(8.dp))
        Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in 1..7) {
                Box(
                    Modifier
                        .size(if (i == filled) 6.dp else 5.dp)
                        .clip(CircleShape)
                        .background(if (i <= filled) Color(0xFFFFA24A) else Color(0x33FFFFFF)),
                )
            }
        }
    }
}

// ───────────────────────────── feed ─────────────────────────────

class FeedItem(val song: Song, val reason: String)

/** Mixes new, unheard, on-repeat and loved songs round-robin; `seed` changes the shuffle. */
fun buildFeed(songs: List<Song>, liked: Set<Long>, counts: Map<Long, Int>, seed: Long, limit: Int = 8): List<FeedItem> {
    if (songs.isEmpty()) return emptyList()
    val rnd = Random(seed)
    val pools = listOf(
        "Just landed in your universe" to songs.sortedByDescending { it.dateAdded }.take(14).shuffled(rnd),
        "You haven't played this yet" to songs.filter { (counts[it.id] ?: 0) == 0 }.shuffled(rnd),
        "On repeat lately" to songs.filter { (counts[it.id] ?: 0) > 0 }.sortedByDescending { counts[it.id] ?: 0 }.take(12).shuffled(rnd),
        "From your favorites" to songs.filter { it.id in liked }.shuffled(rnd),
    )
    val idx = IntArray(pools.size)
    val used = HashSet<Long>()
    val out = ArrayList<FeedItem>()
    var guard = 0
    while (out.size < limit && guard < 400) {
        guard++
        val k = guard % pools.size
        val (reason, list) = pools[k]
        while (idx[k] < list.size && list[idx[k]].id in used) idx[k]++
        if (idx[k] < list.size) {
            val s = list[idx[k]++]
            used += s.id
            out += FeedItem(s, reason)
        }
        if (pools.indices.all { j -> idx[j] >= pools[j].second.size }) break
    }
    return out
}

/**
 * One feed post: tap = play, double-tap = love (with heart burst + thump), heart button toggles.
 */
@Composable
fun FeedSongCard(
    item: FeedItem,
    liked: Boolean,
    isCurrent: Boolean,
    isPlaying: Boolean,
    plays: Int,
    onPlay: () -> Unit,
    onToggleLike: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val song = item.song
    val sound = rememberUiSound()
    val thump = rememberThump()
    val scope = rememberCoroutineScope()
    val burst = remember { Animatable(0f) }
    var burstOn by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(22.dp)

    fun fireBurst() {
        scope.launch {
            burstOn = true
            burst.snapTo(0f)
            burst.animateTo(1f, tween(780, easing = FastOutSlowInEasing))
            burstOn = false
        }
    }

    val heartScale by animateFloatAsState(
        if (liked) 1f else 0.92f,
        spring(dampingRatio = 0.35f, stiffness = 380f),
        label = "heartScale",
    )

    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xFF090914))
            .border(1.dp, Color(0x22FFFFFF), shape),
    ) {
        // header
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(36.dp)
                    .border(2.dp, Brush.sweepGradient(listOf(Color(0xFF3DE0FF), Color(0xFF8A5CFF), Color(0xFFE040C0), Color(0xFF3DE0FF))), CircleShape)
                    .padding(3.dp),
            ) { Artwork(song, Modifier.fillMaxSize(), corner = 16.dp, iconSize = 14.dp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.artist.ifBlank { "Unknown artist" },
                    color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Color(0xFF8FEFFF), modifier = Modifier.size(11.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(item.reason, color = Color(0xFF8FB4FF), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        // media: tap to play, double-tap to love
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .pointerInput(song.id, liked) {
                    detectTapGestures(
                        onDoubleTap = {
                            fireBurst()
                            thump()
                            if (!liked) { sound(UiSound.Kind.LIKE); onToggleLike() }
                        },
                        onTap = { sound(UiSound.Kind.PLAY); onPlay() },
                    )
                },
        ) {
            Artwork(song, Modifier.fillMaxSize(), corner = 0.dp, iconSize = 72.dp)
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Transparent, Color(0x22000000), Color(0xDD000000))),
                ),
            )
            Column(Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 14.dp)) {
                Text(
                    song.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                if (song.album.isNotBlank()) {
                    Text(song.album, color = Color(0xCCFFFFFF), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (isCurrent) {
                Row(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x99000000))
                        .padding(horizontal = 9.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(if (isPlaying) Color(0xFF3DE0FF) else Color(0xFF7A829E)))
                    Spacer(Modifier.width(6.dp))
                    Text(if (isPlaying) "Playing" else "Paused", color = Color.White, fontSize = 11.sp)
                }
            }
            if (burstOn) {
                Canvas(Modifier.fillMaxSize()) {
                    val p = burst.value
                    val c = Offset(size.width / 2f, size.height / 2f)
                    for (i in 0 until 10) {
                        val a = i * (2f * PI.toFloat() / 10f)
                        val dist = p * 120f * density * (0.7f + 0.3f * ((i % 3) / 2f))
                        drawCircle(
                            (if (i % 2 == 0) Color(0xFFFF3D7F) else Color(0xFFFFB347)).copy(alpha = (1f - p).coerceIn(0f, 1f)),
                            (4f - 2.5f * p) * density,
                            Offset(c.x + cos(a) * dist, c.y + sin(a) * dist),
                        )
                    }
                }
                Icon(
                    Icons.Rounded.Favorite, null, tint = Color(0xFFFF3D7F),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(104.dp)
                        .graphicsLayer {
                            val p = burst.value
                            val s = if (p < 0.3f) 0.3f + (p / 0.3f) * 1.0f else 1.3f - (p - 0.3f) * 0.35f
                            scaleX = s; scaleY = s
                            alpha = 1f - ((p - 0.55f) / 0.45f).coerceIn(0f, 1f)
                        },
                )
            }
        }

        // actions
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = if (liked) "Unlike" else "Like",
                tint = if (liked) Color(0xFFFF3D7F) else Color.White,
                modifier = Modifier
                    .size(28.dp)
                    .graphicsLayer { scaleX = heartScale; scaleY = heartScale }
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        thump()
                        if (!liked) { sound(UiSound.Kind.LIKE); fireBurst() }
                        onToggleLike()
                    },
            )
            Spacer(Modifier.width(16.dp))
            Icon(
                if (isCurrent && isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = "Play",
                tint = Color.White,
                modifier = Modifier
                    .size(30.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        sound(if (isCurrent && isPlaying) UiSound.Kind.PAUSE else UiSound.Kind.PLAY)
                        onPlay()
                    },
            )
            Spacer(Modifier.weight(1f))
            Text(
                when {
                    plays <= 0 -> "Not played yet"
                    plays == 1 -> "Played once"
                    else -> "Played $plays times"
                },
                color = Color(0xFF7A829E), fontSize = 12.sp,
            )
        }
    }
}

/** End-of-feed card, like "You're all caught up" — its button reshuffles the whole feed. */
@Composable
fun CaughtUpCard(onRefresh: () -> Unit, modifier: Modifier = Modifier) {
    val tick = rememberTick()
    val sound = rememberUiSound()
    var turns by remember { mutableStateOf(0) }
    val spin by animateFloatAsState(turns * 360f, tween(600, easing = FastOutSlowInEasing), label = "refreshSpin")
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0A1A44), Color(0xFF150F3C))))
            .border(1.dp, Brush.horizontalGradient(listOf(Color(0x883DE0FF), Color(0x888A5CFF))), shape)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("You're all caught up", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text("Your universe has more. Shake it up.", color = Color(0xFF7A829E), fontSize = 12.5.sp)
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF2EC8FF), Color(0xFF8A5CFF), Color(0xFFE040C0))))
                .pressable(0.94f) { tick(); sound(UiSound.Kind.OPEN); turns++; onRefresh() }
                .padding(horizontal = 20.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp).graphicsLayer { rotationZ = spin })
            Spacer(Modifier.width(8.dp))
            Text("Shuffle the universe", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
