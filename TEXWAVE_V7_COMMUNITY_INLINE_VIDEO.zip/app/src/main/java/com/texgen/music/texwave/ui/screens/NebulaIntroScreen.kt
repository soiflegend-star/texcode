package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.delay

/**
 * Total length. The motion itself is fast (hyper-jump finishes in ~1.4 s); the extra time is the
 * galaxy staying alive on screen. Raise this to keep the galaxy longer, lower it to finish sooner.
 */
private const val INTRO_SECONDS = 6.2f

private class Star(val angle: Float, val offset: Float, val speed: Float, val hue: Int, val size: Float)
private class Dust(val arm: Int, val r: Float, val jitter: Float, val size: Float, val hue: Int, val phase: Float)

private fun starColor(h: Int): Color = when (h) {
    0 -> Color(0xFFFFFFFF)
    1 -> Color(0xFFBFA8FF)
    2 -> Color(0xFF8FEFFF)
    else -> Color(0xFFFF9EE6)
}

/**
 * Dark-universe intro: a very fast hyper-jump star tunnel (peaks around 9x the old speed) snaps into a
 * spinning galaxy within the first second, a shockwave reveals the Texwave emblem, then the title resolves
 * while the galaxy keeps turning, twinkling and throwing shooting stars until the end. Tap to skip.
 * Fully procedural (no video file), 60 fps, ~6.2 seconds.
 */
@Composable
fun NebulaIntroScreen(onFinished: () -> Unit) {
    var t by remember { mutableFloatStateOf(0f) }
    // distance travelled by the warp stars; integrated per frame so speed changes never make stars jump
    var travel by remember { mutableFloatStateOf(0f) }
    val haptic = LocalHapticFeedback.current
    val warp = remember {
        val r = Random(11)
        List(300) { Star(r.nextFloat() * 6.2832f, r.nextFloat(), 0.6f + r.nextFloat() * 0.9f, r.nextInt(4), 0.6f + r.nextFloat() * 1.6f) }
    }
    val galaxy = remember {
        val r = Random(5)
        List(820) { Dust(r.nextInt(3), r.nextFloat().pow(0.8f), (r.nextFloat() - 0.5f) * 0.35f, 0.5f + r.nextFloat() * 1.8f, r.nextInt(4), r.nextFloat() * 6.28f) }
    }
    // far background stars that make the galaxy feel like it floats in deep space
    val deep = remember {
        val r = Random(77)
        List(110) { Offset(r.nextFloat(), r.nextFloat()) to (r.nextFloat() * 6.28f) }
    }

    LaunchedEffect(Unit) {
        var start = -1L
        var last = 0f
        while (t < INTRO_SECONDS) {
            androidx.compose.runtime.withFrameNanos { n ->
                if (start < 0) start = n
                val now = (n - start) / 1_000_000_000f
                val dt = (now - last).coerceIn(0f, 0.05f)
                last = now
                // hyper-jump: very fast for the first ~1.2 s, then settles into a gentle drift
                val power = 1f - ((now - 0.9f) / 1.3f).coerceIn(0f, 1f).let { it * it * (3f - 2f * it) }
                travel += dt * (0.30f + power * 7.5f)
                t = now
            }
        }
        onFinished()
    }
    // a physical "thump" when the emblem lands
    LaunchedEffect(Unit) {
        delay(1000)
        runCatching { haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
    }

    fun ease(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }
    fun seg(a: Float, b: Float): Float = ease((t - a) / (b - a))

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF010005))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onFinished() },
    ) {
        Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = seg(0f, 0.30f) }) {
            val w = size.width
            val h = size.height
            val c = Offset(w / 2f, h * 0.44f)
            val maxR = kotlin.math.hypot(w, h) * 0.62f
            val d = density

            // nebula clouds
            fun cloud(col: Color, x: Float, y: Float, r: Float, a: Float) = drawCircle(
                Brush.radialGradient(listOf(col.copy(alpha = a), col.copy(alpha = a * 0.3f), Color.Transparent), Offset(x, y), r),
                r, Offset(x, y),
            )
            val drift = t * 0.6f
            cloud(Color(0xFF6A3BFF), w * (0.30f + 0.06f * sin(drift)), h * 0.30f, w * 1.0f, 0.32f)
            cloud(Color(0xFFFF2FC2), w * (0.86f + 0.05f * cos(drift)), h * 0.52f, w * 0.75f, 0.20f)
            cloud(Color(0xFF1FD5FF), w * (0.40f + 0.08f * sin(drift * 0.8f)), h * 0.84f, w * 0.85f, 0.18f)
            cloud(Color(0xFF3A1B8F), c.x, c.y, w * 0.9f, 0.40f)

            // deep-space backdrop stars (always there, twinkling)
            deep.forEach { (o, ph) ->
                val tw = 0.25f + 0.75f * (0.5f + 0.5f * sin(t * 2.4f + ph))
                drawCircle(Color.White.copy(alpha = 0.55f * tw * seg(0.2f, 1.0f)), 0.9f * d, Offset(o.x * w, o.y * h))
            }

            // galaxy (flattened + tilted spiral) — snaps in during the jump and stays for the whole intro
            val gAlpha = seg(0.25f, 1.25f)
            if (gAlpha > 0f) {
                // spins fast as it appears, then settles into a slow majestic turn
                val rot = t * 0.55f + 2.8f * (1f - exp(-1.5f * t))
                val tilt = -0.38f + 0.05f * sin(t * 0.6f)
                val ct = cos(tilt); val st = sin(tilt)
                // the whole galaxy blooms outward a little as it appears
                val bloom = 0.82f + 0.18f * seg(0.25f, 1.6f)
                galaxy.forEach { s ->
                    val rr = s.r * w * 0.62f * bloom
                    val a = s.arm * 2.0944f + s.r * 5.2f - rot / (0.4f + s.r) * 0.6f + s.jitter
                    val x0 = cos(a) * rr
                    val y0 = sin(a) * rr * 0.42f
                    val px = c.x + x0 * ct - y0 * st
                    val py = c.y + x0 * st + y0 * ct
                    val tw = 0.45f + 0.55f * (0.5f + 0.5f * sin(t * 3f + s.phase))
                    drawCircle(starColor(s.hue).copy(alpha = gAlpha * tw * (1f - s.r * 0.45f)), s.size * d, Offset(px, py))
                }
                // bright galactic core
                val core = w * (0.20f + 0.015f * sin(t * 2.2f))
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFFFFFFFF).copy(alpha = 0.85f * gAlpha), Color(0xFFB79CFF).copy(alpha = 0.45f * gAlpha), Color.Transparent),
                        c, core,
                    ),
                    core, c,
                )
            }

            // hyper-jump / drifting stars
            val warpPower = 1f - seg(0.9f, 2.2f)
            warp.forEach { s ->
                val p = ((s.offset + travel * s.speed * 0.5f) % 1f)
                val r = p.pow(2.3f) * maxR
                val trail = r * (0.05f + 0.75f * warpPower * s.speed)
                val dir = Offset(cos(s.angle), sin(s.angle))
                val a = (p * 1.4f).coerceAtMost(1f) * (0.30f + 0.70f * (1f - seg(1.8f, 3.0f) * 0.75f))
                drawLine(
                    starColor(s.hue).copy(alpha = a),
                    Offset(c.x + dir.x * (r - trail), c.y + dir.y * (r - trail)),
                    Offset(c.x + dir.x * r, c.y + dir.y * r),
                    strokeWidth = (0.6f + p * 2.2f) * s.size * 0.6f * d,
                    cap = StrokeCap.Round,
                )
            }

            // white flash at the instant the jump ends
            val flash = 1f - ((t - 1.0f) / 0.35f).coerceIn(0f, 1f)
            if (t in 0.9f..1.4f) drawRect(Color.White.copy(alpha = 0.22f * flash * flash))

            // shooting stars across the galaxy while it lingers
            for (k in 0 until 4) {
                val st0 = 2.3f + k * 0.95f
                val u = (t - st0) / 0.55f
                if (u in 0f..1f) {
                    val sx = w * (0.15f + 0.22f * k)
                    val sy = h * (0.10f + 0.07f * (k % 2))
                    val hx = sx + u * w * 0.55f
                    val hy = sy + u * h * 0.22f
                    drawLine(
                        Brush.linearGradient(listOf(Color.Transparent, Color.White), Offset(hx - w * 0.16f, hy - h * 0.06f), Offset(hx, hy)),
                        Offset(hx - w * 0.16f, hy - h * 0.06f), Offset(hx, hy),
                        strokeWidth = 2f * d, cap = StrokeCap.Round, alpha = (1f - u) * 0.9f,
                    )
                    drawCircle(Color.White.copy(alpha = (1f - u)), 2.4f * d, Offset(hx, hy))
                }
            }

            // shockwave ring when the emblem lands
            val sw = ((t - 1.0f) / 1.1f)
            if (sw in 0f..1f) {
                val rr = ease(sw) * w * 0.95f
                drawCircle(
                    Brush.sweepGradient(
                        listOf(Color(0xFF2FE6FF), Color(0xFFA37CFF), Color(0xFFFF3DCB), Color(0xFF2FE6FF)), c,
                    ),
                    radius = rr, center = c,
                    style = Stroke(width = (6f * (1f - sw) + 1f) * d),
                    alpha = (1f - sw) * 0.9f,
                )
            }
            // emblem glow
            val glow = seg(0.9f, 1.8f)
            if (glow > 0f) {
                val gr = w * (0.46f + 0.03f * sin(t * 2.6f))
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFF7B4DFF).copy(alpha = 0.55f * glow), Color(0xFF2FE6FF).copy(alpha = 0.10f * glow), Color.Transparent),
                        c, gr,
                    ),
                    gr, c,
                )
            }
            // vignette
            drawRect(
                Brush.radialGradient(
                    listOf(Color.Transparent, Color(0xCC000000)),
                    Offset(w / 2, h / 2), kotlin.math.hypot(w, h) * 0.55f,
                ),
            )
        }

        // emblem + title
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(0.44f))
            Image(
                painter = painterResource(R.drawable.intro_emblem),
                contentDescription = "Texwave",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(210.dp)
                    .graphicsLayer {
                        val a = seg(1.0f, 1.75f)
                        // overshoot a little for a "landing" feel
                        val s = 0.55f + 0.45f * a + 0.06f * sin(a * 3.1416f)
                        alpha = a
                        scaleX = s; scaleY = s
                    },
            )
            Spacer(Modifier.weight(0.56f))
        }
        Column(
            Modifier
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Bottom,
        ) {
            Text(
                "TEXWAVE",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(Color(0xFF2FE6FF), Color(0xFFE8E0FF), Color(0xFFFF8AE6))),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 12.sp,
                    textAlign = TextAlign.Center,
                ),
                modifier = Modifier.graphicsLayer {
                    val a = seg(1.6f, 2.3f)
                    alpha = a
                    val s = 1.18f - 0.18f * a
                    scaleX = s; scaleY = s
                },
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Your music. Your memories. Your universe.",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 13.sp,
                letterSpacing = 1.sp,
                modifier = Modifier.graphicsLayer { alpha = seg(2.1f, 2.9f) },
            )
            Spacer(Modifier.height(56.dp))
        }
    }
}
