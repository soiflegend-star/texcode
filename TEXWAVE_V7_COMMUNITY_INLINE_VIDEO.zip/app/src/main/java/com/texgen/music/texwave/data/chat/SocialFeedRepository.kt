package com.texgen.music.texwave.data.chat

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID

@Serializable
data class SocialPost(
    val id: String,
    val user_id: String,
    val media_url: String,
    val media_path: String,
    val media_type: String,
    val caption: String = "",
    val download_allowed: Boolean = true,
    val created_at: String = "",
)

@Serializable
data class SocialLike(val post_id: String, val user_id: String)

@Serializable
data class SocialComment(
    val id: String,
    val post_id: String,
    val user_id: String,
    val body: String,
    val created_at: String = "",
)

/** Uses the same authenticated Supabase client as chat; no second login/session is created. */
class SocialFeedRepository private constructor(private val context: Context) {
    private val chat = ChatRepository.get(context)
    private fun client() = chat.rawClient()
    fun myUserId(): String = chat.rawCurrentUserId()

    suspend fun feed(): Result<List<SocialPost>> = withContext(Dispatchers.IO) {
        runCatching {
            client().from("social_posts").select {
                order("created_at", Order.DESCENDING)
                limit(100)
            }.decodeList<SocialPost>()
        }
    }

    suspend fun publish(uri: Uri, caption: String, mediaType: String): Result<SocialPost> = withContext(Dispatchers.IO) {
        runCatching {
            require(mediaType == "image" || mediaType == "video") { "Choose a photo or video." }
            val userId = chat.rawCurrentUserId()
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Could not read the selected file.")
            require(bytes.isNotEmpty() && bytes.size <= 50 * 1024 * 1024) { "Choose a file smaller than 50 MB." }
            val mime = context.contentResolver.getType(uri).orEmpty()
            require(if (mediaType == "image") mime.startsWith("image/") else mime.startsWith("video/")) {
                "The selected file type does not match the post type."
            }
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)?.take(8) ?: if (mediaType == "image") "jpg" else "mp4"
            val path = "$userId/${UUID.randomUUID()}.$ext"
            client().storage.from("social-media").upload(path, bytes, upsert = false)
            val publicUrl = "${SupabaseConfig.SUPABASE_URL}/storage/v1/object/public/social-media/$path"
            client().from("social_posts").insert(buildJsonObject {
                put("user_id", userId)
                put("media_url", publicUrl)
                put("media_path", path)
                put("media_type", mediaType)
                put("caption", caption.trim().take(2200))
                put("download_allowed", true)
            }) { select() }.decodeSingle<SocialPost>()
        }
    }

    suspend fun likesFor(postId: String): Result<List<SocialLike>> = withContext(Dispatchers.IO) {
        runCatching { client().from("social_post_likes").select { filter { eq("post_id", postId) } }.decodeList<SocialLike>() }
    }

    suspend fun toggleLike(postId: String, currentlyLiked: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val me = chat.rawCurrentUserId()
            if (currentlyLiked) client().from("social_post_likes").delete { filter { eq("post_id", postId); eq("user_id", me) } }
            else client().from("social_post_likes").insert(buildJsonObject { put("post_id", postId); put("user_id", me) })
            Unit
        }
    }

    suspend fun commentsFor(postId: String): Result<List<SocialComment>> = withContext(Dispatchers.IO) {
        runCatching { client().from("social_post_comments").select { filter { eq("post_id", postId) }; order("created_at", Order.ASCENDING) }.decodeList<SocialComment>() }
    }

    suspend fun addComment(postId: String, body: String): Result<SocialComment> = withContext(Dispatchers.IO) {
        runCatching {
            val text = body.trim()
            require(text.isNotEmpty() && text.length <= 1000) { "Comment must be 1–1000 characters." }
            client().from("social_post_comments").insert(buildJsonObject {
                put("post_id", postId); put("user_id", chat.rawCurrentUserId()); put("body", text)
            }) { select() }.decodeSingle<SocialComment>()
        }
    }

    companion object {
        @Volatile private var instance: SocialFeedRepository? = null
        fun get(context: Context): SocialFeedRepository = instance ?: synchronized(this) {
            instance ?: SocialFeedRepository(context.applicationContext).also { instance = it }
        }
    }
}
