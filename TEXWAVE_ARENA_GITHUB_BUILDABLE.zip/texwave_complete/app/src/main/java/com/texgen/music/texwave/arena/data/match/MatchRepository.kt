package com.texgen.music.texwave.arena.data.match

import com.texgen.music.texwave.arena.data.supabase.SupabaseArenaClient
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull

/**
 * Online match API — all mutations go through SECURITY DEFINER RPCs.
 * Realtime: subscribe to arena_online_matches / arena_match_actions via TEXWAVE Supabase realtime.
 */
interface MatchRepository {
    suspend fun enqueueRanked(): Result<QueueResult>
    suspend fun cancelQueue(): Result<Unit>
    suspend fun inviteFriend(userId: String): Result<String>
    suspend fun respondInvite(inviteId: String, accept: Boolean): Result<QueueResult>
    suspend fun ready(matchId: String): Result<OnlineMatch>
    suspend fun submitAction(matchId: String, action: String): Result<ActionResult>
    suspend fun abandon(matchId: String): Result<Unit>
    suspend fun fetchMatch(matchId: String): Result<OnlineMatch>
}

class SupabaseMatchRepository(
    private val client: SupabaseArenaClient
) : MatchRepository {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    override suspend fun enqueueRanked(): Result<QueueResult> = runCatching {
        val raw = client.rpcRaw("arena_mm_enqueue", mapOf("p_mode" to "RANKED"))
        val o = json.parseToJsonElement(raw).jsonObject
        QueueResult(
            status = o["status"]?.jsonPrimitive?.contentOrNull ?: "QUEUED",
            matchId = o["match_id"]?.jsonPrimitive?.contentOrNull,
            opponentId = o["opponent_id"]?.jsonPrimitive?.contentOrNull,
            rating = o["rating"]?.jsonPrimitive?.intOrNull
        )
    }

    override suspend fun cancelQueue(): Result<Unit> = runCatching {
        client.rpcRaw("arena_mm_cancel_queue")
        Unit
    }

    override suspend fun inviteFriend(userId: String): Result<String> = runCatching {
        client.rpcRaw("arena_mm_invite", mapOf("p_to" to userId)).trim().removeSurrounding("\"")
    }

    override suspend fun respondInvite(inviteId: String, accept: Boolean): Result<QueueResult> =
        runCatching {
            val raw = client.rpcRaw(
                "arena_mm_respond_invite",
                mapOf("p_invite" to inviteId, "p_accept" to accept)
            )
            val o = json.parseToJsonElement(raw).jsonObject
            QueueResult(
                status = o["status"]?.jsonPrimitive?.contentOrNull ?: "",
                matchId = o["match_id"]?.jsonPrimitive?.contentOrNull
            )
        }

    override suspend fun ready(matchId: String): Result<OnlineMatch> = runCatching {
        val raw = client.rpcRaw("arena_match_ready", mapOf("p_match" to matchId))
        parseMatch(raw)
    }

    override suspend fun submitAction(matchId: String, action: String): Result<ActionResult> =
        runCatching {
            val raw = client.rpcRaw(
                "arena_match_submit_action",
                mapOf("p_match" to matchId, "p_action" to action)
            )
            val o = json.parseToJsonElement(raw).jsonObject
            ActionResult(
                status = o["status"]?.jsonPrimitive?.contentOrNull ?: "",
                round = o["round"]?.jsonPrimitive?.intOrNull,
                roundWinner = o["round_winner"]?.jsonPrimitive?.contentOrNull,
                scoreA = o["score_a"]?.jsonPrimitive?.intOrNull,
                scoreB = o["score_b"]?.jsonPrimitive?.intOrNull,
                winnerId = o["winner_id"]?.jsonPrimitive?.contentOrNull,
                nextRound = o["next_round"]?.jsonPrimitive?.intOrNull
            )
        }

    override suspend fun abandon(matchId: String): Result<Unit> = runCatching {
        client.rpcRaw("arena_match_abandon", mapOf("p_match" to matchId))
        Unit
    }

    override suspend fun fetchMatch(matchId: String): Result<OnlineMatch> = runCatching {
        val raw = client.select(
            "arena_online_matches",
            filters = mapOf("id" to "eq.$matchId"),
            limit = 1
        )
        val arr = json.parseToJsonElement(raw).jsonObject.let {
            // select returns array
            json.parseToJsonElement(raw)
        }
        val el = json.parseToJsonElement(raw).let { el ->
            when (el) {
                is kotlinx.serialization.json.JsonArray -> el.firstOrNull()?.jsonObject
                else -> el.jsonObject
            }
        } ?: error("Match not found")
        OnlineMatch(
            id = el["id"]?.jsonPrimitive?.contentOrNull ?: matchId,
            playerA = el["player_a"]?.jsonPrimitive?.contentOrNull ?: "",
            playerB = el["player_b"]?.jsonPrimitive?.contentOrNull ?: "",
            status = el["status"]?.jsonPrimitive?.contentOrNull ?: "",
            currentRound = el["current_round"]?.jsonPrimitive?.intOrNull ?: 1,
            scoreA = el["score_a"]?.jsonPrimitive?.intOrNull ?: 0,
            scoreB = el["score_b"]?.jsonPrimitive?.intOrNull ?: 0,
            ratingA = el["rating_a"]?.jsonPrimitive?.intOrNull ?: 1000,
            ratingB = el["rating_b"]?.jsonPrimitive?.intOrNull ?: 1000,
            aReady = el["a_ready"]?.jsonPrimitive?.booleanOrNull ?: false,
            bReady = el["b_ready"]?.jsonPrimitive?.booleanOrNull ?: false,
            winnerId = el["winner_id"]?.jsonPrimitive?.contentOrNull,
            ratingDeltaA = el["rating_delta_a"]?.jsonPrimitive?.intOrNull,
            ratingDeltaB = el["rating_delta_b"]?.jsonPrimitive?.intOrNull
        )
    }

    private fun parseMatch(raw: String): OnlineMatch {
        val el = json.parseToJsonElement(raw).jsonObject
        return OnlineMatch(
            id = el["id"]?.jsonPrimitive?.contentOrNull ?: "",
            playerA = el["player_a"]?.jsonPrimitive?.contentOrNull ?: "",
            playerB = el["player_b"]?.jsonPrimitive?.contentOrNull ?: "",
            status = el["status"]?.jsonPrimitive?.contentOrNull ?: "",
            currentRound = el["current_round"]?.jsonPrimitive?.intOrNull ?: 1,
            scoreA = el["score_a"]?.jsonPrimitive?.intOrNull ?: 0,
            scoreB = el["score_b"]?.jsonPrimitive?.intOrNull ?: 0,
            ratingA = el["rating_a"]?.jsonPrimitive?.intOrNull ?: 1000,
            ratingB = el["rating_b"]?.jsonPrimitive?.intOrNull ?: 1000,
            aReady = el["a_ready"]?.jsonPrimitive?.booleanOrNull ?: false,
            bReady = el["b_ready"]?.jsonPrimitive?.booleanOrNull ?: false,
            winnerId = el["winner_id"]?.jsonPrimitive?.contentOrNull
        )
    }
}

/**
 * Local stub for UI without backend — clearly labeled simulation.
 * Does NOT claim to be online multiplayer.
 */
class SimulatedMatchRepository : MatchRepository {
    override suspend fun enqueueRanked() =
        Result.success(QueueResult("QUEUED", rating = 1000))
    override suspend fun cancelQueue() = Result.success(Unit)
    override suspend fun inviteFriend(userId: String) = Result.failure(IllegalStateException("Simulation only"))
    override suspend fun respondInvite(inviteId: String, accept: Boolean) =
        Result.failure(IllegalStateException("Simulation only"))
    override suspend fun ready(matchId: String) =
        Result.failure(IllegalStateException("Simulation only"))
    override suspend fun submitAction(matchId: String, action: String) =
        Result.failure(IllegalStateException("Simulation only"))
    override suspend fun abandon(matchId: String) = Result.success(Unit)
    override suspend fun fetchMatch(matchId: String) =
        Result.failure(IllegalStateException("Simulation only"))
}
