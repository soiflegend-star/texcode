package com.texgen.music.texwave.arena.domain

import com.texgen.music.texwave.arena.data.model.LeaderboardEntry
import com.texgen.music.texwave.arena.data.model.LeaderboardPage
import com.texgen.music.texwave.arena.data.model.LeaderboardScope
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * Builds ranked pages from player snapshots.
 * Designed so the same logic can run on a backend with pagination.
 */
object LeaderboardEngine {

    data class PlayerSnapshot(
        val userId: String,
        val username: String,
        val displayName: String,
        val level: Int,
        val totalXp: Long,
        val weeklyXp: Long = 0L,
        val monthlyXp: Long = 0L,
        val dailyXp: Long = 0L,
        val totalPushUps: Long = 0L,
        val isFriend: Boolean = false
    )

    fun buildPage(
        scope: LeaderboardScope,
        players: List<PlayerSnapshot>,
        currentUserId: String,
        limit: Int = 50
    ): LeaderboardPage {
        val metric: (PlayerSnapshot) -> Long = when (scope) {
            LeaderboardScope.GLOBAL_ALL_TIME -> { it.totalXp }
            LeaderboardScope.GLOBAL_WEEKLY -> { it.weeklyXp }
            LeaderboardScope.GLOBAL_MONTHLY -> { it.monthlyXp }
            LeaderboardScope.GLOBAL_DAILY -> { it.dailyXp }
            LeaderboardScope.FRIENDS -> { it.totalXp }
            LeaderboardScope.SQUAD -> { it.totalXp }
        }

        val pool = when (scope) {
            LeaderboardScope.FRIENDS -> players.filter { it.isFriend || it.userId == currentUserId }
            else -> players
        }

        val ranked = pool
            .sortedWith(compareByDescending<PlayerSnapshot> { metric(it) }.thenBy { it.username })
            .mapIndexed { index, p ->
                LeaderboardEntry(
                    rank = index + 1,
                    userId = p.userId,
                    username = p.username,
                    displayName = p.displayName,
                    level = p.level,
                    xp = metric(p),
                    pushUps = p.totalPushUps,
                    isCurrentUser = p.userId == currentUserId
                )
            }

        val pageEntries = ranked.take(limit)
        val me = ranked.find { it.isCurrentUser }

        val zone = ZoneId.systemDefault()
        val now = Instant.now()
        val (label, resets) = when (scope) {
            LeaderboardScope.GLOBAL_ALL_TIME -> "All-time" to null
            LeaderboardScope.GLOBAL_WEEKLY -> {
                val end = LocalDate.now(zone).plusDays((8 - LocalDate.now(zone).dayOfWeek.value).toLong())
                    .atStartOfDay(zone).toInstant()
                "This week" to end
            }
            LeaderboardScope.GLOBAL_MONTHLY -> {
                val end = LocalDate.now(zone).withDayOfMonth(1).plusMonths(1)
                    .atStartOfDay(zone).toInstant()
                "This month" to end
            }
            LeaderboardScope.GLOBAL_DAILY -> {
                val end = LocalDate.now(zone).plusDays(1).atStartOfDay(zone).toInstant()
                "Today" to end
            }
            LeaderboardScope.FRIENDS -> "Friends" to null
            LeaderboardScope.SQUAD -> "Squad ranking" to null
        }

        return LeaderboardPage(
            scope = scope,
            entries = pageEntries,
            currentUserEntry = me,
            totalPlayers = ranked.size,
            periodLabel = label,
            resetsAt = resets
        )
    }

    /** Demo population so leaderboards are never empty. */
    fun demoPlayers(currentUserId: String, currentUsername: String, currentLevel: Int, currentXp: Long, currentPushUps: Long): List<PlayerSnapshot> {
        val names = listOf(
            "nova_lex", "kai_storm", "luna_v", "apex_zero", "shadow_rim",
            "volt_9", "iris_flux", "orbit_k", "zenith_x", "pulse_neo",
            "raven_cx", "sol_arc", "nyx_byte", "echo_prime", "drift_max"
        )
        val base = names.mapIndexed { i, name ->
            PlayerSnapshot(
                userId = "bot-$i",
                username = name,
                displayName = name.replace('_', ' ').replaceFirstChar { it.uppercase() },
                level = 8 + (i % 12),
                totalXp = (3200L + i * 417 + (15 - i) * 90),
                weeklyXp = (180L + i * 33),
                monthlyXp = (900L + i * 110),
                dailyXp = (20L + i * 7),
                totalPushUps = (800L + i * 95),
                isFriend = i < 4
            )
        }
        val me = PlayerSnapshot(
            userId = currentUserId,
            username = currentUsername,
            displayName = currentUsername.replace('_', ' ').replaceFirstChar { it.uppercase() },
            level = currentLevel,
            totalXp = currentXp,
            weeklyXp = (currentXp / 8).coerceAtLeast(50),
            monthlyXp = (currentXp / 3).coerceAtLeast(200),
            dailyXp = 40L,
            totalPushUps = currentPushUps,
            isFriend = true
        )
        return base + me
    }
}
