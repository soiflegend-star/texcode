package com.texgen.music.texwave.arena.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.ArenaPlayer
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.ui.components.RankChip
import com.texgen.music.texwave.arena.ui.components.StatCard
import com.texgen.music.texwave.arena.ui.components.XpProgressBar
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import com.texgen.music.texwave.arena.ui.theme.arenaGlow
import com.texgen.music.texwave.arena.ui.theme.arenaRing

@Composable
fun ArenaProfileScreen(
    repository: ArenaRepository = ArenaModule.repository,
    onOpenHistory: () -> Unit = {},
    onOpenLog: () -> Unit = {},
    onOpenCamera: () -> Unit = {}
) {
    val player by repository.observePlayer().collectAsState(
        initial = ArenaPlayer(userId = "", username = "…")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            "PLAYER PROFILE",
            color = ArenaColors.Cyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
        Spacer(Modifier.height(16.dp))

        // Identity card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .arenaGlassCard(20)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(88.dp)
                    .arenaGlow(ArenaColors.GlowCyan, 48.dp)
                    .arenaRing(ArenaColors.Cyan, 2.5.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                ArenaColors.Violet.copy(alpha = 0.7f),
                                ArenaColors.Cyan.copy(alpha = 0.5f)
                            )
                        )
                    )
            ) {
                Text(
                    player.username.take(1).uppercase(),
                    color = androidx.compose.ui.graphics.Color.White,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                player.displayName,
                color = ArenaColors.Text,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "@${player.username}  ·  ID ${player.userId.take(8)}",
                color = ArenaColors.Muted,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "Level ${player.level}",
                color = ArenaColors.Cyan,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(14.dp))
            XpProgressBar(
                progress = player.progressFraction,
                current = player.xpIntoCurrentLevel,
                required = player.xpRequiredForNextLevel
            )
        }

        Spacer(Modifier.height(14.dp))

        // Ranks
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            RankChip("Global", player.globalRank, Icons.Filled.Public, ArenaColors.Cyan)
            RankChip("Weekly", player.weeklyRank, Icons.Filled.MilitaryTech, ArenaColors.Violet)
            RankChip("Monthly", player.monthlyRank, Icons.Filled.MilitaryTech, ArenaColors.Magenta)
        }

        Spacer(Modifier.height(14.dp))

        // Stats grid
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            StatCard(
                title = "Total XP",
                value = formatNum(player.totalXp),
                icon = Icons.Filled.Bolt,
                accent = ArenaColors.Cyan,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Push-ups",
                value = formatNum(player.totalPushUps),
                icon = Icons.Filled.FitnessCenter,
                accent = ArenaColors.Violet,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(10.dp))

        if (player.squadName != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .arenaGlassCard(16)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Groups, null, tint = ArenaColors.Violet)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Squad", color = ArenaColors.Muted, fontSize = 12.sp)
                    Text(
                        player.squadName!!,
                        color = ArenaColors.Text,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // Quick actions
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            ActionButton("Log Session", onOpenLog, Modifier.weight(1f))
            ActionButton("Camera", onOpenCamera, Modifier.weight(1f))
            ActionButton("History", onOpenHistory, Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .arenaGlassCard(14)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = ArenaColors.Cyan,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

private fun formatNum(v: Long): String = when {
    v >= 1_000_000 -> String.format("%.1fM", v / 1_000_000.0)
    v >= 1_000 -> String.format("%.1fK", v / 1_000.0)
    else -> v.toString()
}
