package com.texgen.music.texwave.arena.ui.achievements

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.AchievementSummary
import com.texgen.music.texwave.arena.data.model.ArenaPlayer
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.domain.AchievementEngine
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard

@Composable
fun AchievementsScreen(
    repository: ArenaRepository = ArenaModule.repository
) {
    val player by repository.observePlayer().collectAsState(
        initial = ArenaPlayer("", "…")
    )
    val activities by repository.observeActivities().collectAsState(initial = emptyList())
    val challenges by repository.observeChallenges().collectAsState(initial = emptyList())

    val achievements = remember(player, activities, challenges) {
        AchievementEngine.evaluateAll(
            player = player,
            activities = activities,
            challengesCompleted = challenges.count { it.isCompleted },
            hasSquad = player.squadId != null,
            alreadyUnlocked = emptySet()
        )
    }

    val unlocked = achievements.count { it.isUnlocked }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg)
    ) {
        Text(
            "ACHIEVEMENTS",
            color = ArenaColors.Cyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
        Text(
            "$unlocked / ${achievements.size} unlocked",
            color = ArenaColors.Muted,
            fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        // Shareable identity card
        Spacer(Modifier.height(12.dp))
        ShareableAchievementCard(
            player = player,
            unlockedCount = unlocked,
            total = achievements.size
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(achievements, key = { it.id }) { ach ->
                AchievementTile(ach)
            }
        }
    }
}

@Composable
fun ShareableAchievementCard(
    player: ArenaPlayer,
    unlockedCount: Int,
    total: Int
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .arenaGlassCard(18)
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(ArenaColors.Cyan.copy(alpha = 0.5f), ArenaColors.Violet.copy(alpha = 0.4f))
                ),
                RoundedCornerShape(18.dp)
            )
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("TEXWAVE ARENA", color = ArenaColors.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(listOf(ArenaColors.Violet, ArenaColors.Cyan))
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                player.username.take(1).uppercase(),
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(player.displayName, color = ArenaColors.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Lv ${player.level}  ·  ${format(player.totalXp)} XP  ·  ${format(player.totalPushUps)} reps",
            color = ArenaColors.Muted,
            fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "$unlockedCount / $total achievements",
            color = ArenaColors.Cyan,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            "Share this card inside TEXWAVE",
            color = ArenaColors.Muted,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun AchievementTile(ach: AchievementSummary) {
    val alpha = if (ach.isUnlocked) 1f else 0.45f
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha)
            .arenaGlassCard(14)
            .then(
                if (ach.isUnlocked)
                    Modifier.border(1.dp, ArenaColors.Cyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                else Modifier
            )
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedVisibility(
            visible = true,
            enter = fadeIn() + scaleIn()
        ) {
            Text(
                iconFor(ach.iconKey),
                fontSize = 32.sp,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            ach.title,
            color = ArenaColors.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        Text(
            ach.description,
            color = ArenaColors.Muted,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
        Spacer(Modifier.height(6.dp))
        if (ach.isUnlocked) {
            Text("+${ach.xpReward} XP", color = ArenaColors.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        } else {
            Text("Locked", color = ArenaColors.Muted, fontSize = 11.sp)
        }
    }
}

private fun iconFor(key: String): String = when (key) {
    "first_session" -> "🎯"
    "consistency" -> "📅"
    "weekly" -> "⚔️"
    "rising" -> "📈"
    "centurion" -> "💯"
    "global" -> "🌍"
    "squad" -> "🛡️"
    "veteran" -> "🏅"
    "thousand" -> "🔥"
    else -> "⭐"
}

private fun format(v: Long): String = when {
    v >= 1_000_000 -> String.format("%.1fM", v / 1_000_000.0)
    v >= 1_000 -> String.format("%.1fK", v / 1_000.0)
    else -> v.toString()
}
