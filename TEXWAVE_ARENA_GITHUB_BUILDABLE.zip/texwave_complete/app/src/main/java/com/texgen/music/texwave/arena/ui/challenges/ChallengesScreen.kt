package com.texgen.music.texwave.arena.ui.challenges

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.data.repository.ChallengeView
import com.texgen.music.texwave.arena.ui.components.DifficultyBadge
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.ArenaShapes
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.Instant

@Composable
fun ChallengesScreen(
    repository: ArenaRepository = ArenaModule.repository,
    onOpenDetail: (String) -> Unit = {}
) {
    val challenges by repository.observeChallenges().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var busyId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg)
    ) {
        Text(
            "CHALLENGES",
            color = ArenaColors.Cyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
        if (message != null) {
            Text(
                message!!,
                color = ArenaColors.Cyan,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(challenges, key = { it.challenge.id }) { view ->
                ChallengeListCard(
                    view = view,
                    isBusy = busyId == view.challenge.id,
                    onJoin = {
                        busyId = view.challenge.id
                        scope.launch {
                            repository.joinChallenge(view.challenge.id)
                                .onSuccess { message = "Joined ${view.challenge.title}" }
                                .onFailure { message = it.message }
                            busyId = null
                        }
                    },
                    onClaim = {
                        busyId = view.challenge.id
                        scope.launch {
                            repository.claimChallengeReward(view.challenge.id)
                                .onSuccess { xp -> message = "Claimed +$xp XP" }
                                .onFailure { message = it.message }
                            busyId = null
                        }
                    },
                    onClick = { onOpenDetail(view.challenge.id) }
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun ChallengeListCard(
    view: ChallengeView,
    isBusy: Boolean,
    onJoin: () -> Unit,
    onClaim: () -> Unit,
    onClick: () -> Unit
) {
    val ch = view.challenge
    val fraction = if (ch.targetCount > 0) (view.progress.toFloat() / ch.targetCount).coerceIn(0f, 1f) else 0f
    val remaining = Duration.between(Instant.now(), ch.endAt)
    val timeLeft = when {
        remaining.isNegative -> "Ended"
        remaining.toHours() < 24 -> "${remaining.toHours()}h left"
        else -> "${remaining.toDays()}d left"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(16)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(ch.title, color = ArenaColors.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            DifficultyBadge(ch.difficulty)
        }
        Spacer(Modifier.height(6.dp))
        Text(ch.description, color = ArenaColors.Muted, fontSize = 13.sp, maxLines = 2)
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth().height(5.dp).clip(ArenaShapes.Progress),
            color = ArenaColors.Violet,
            trackColor = ArenaColors.Outline.copy(alpha = 0.5f),
            strokeCap = StrokeCap.Round
        )
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("${view.progress} / ${ch.targetCount}", color = ArenaColors.Muted, fontSize = 12.sp)
            Text("+${ch.xpReward} XP · $timeLeft", color = ArenaColors.Cyan, fontSize = 12.sp)
        }
        Spacer(Modifier.height(12.dp))
        when {
            view.isClaimed -> {
                Text("Reward claimed", color = ArenaColors.Success, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            view.isCompleted && view.isJoined -> {
                Button(
                    onClick = onClaim,
                    enabled = !isBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Cyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isBusy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
                    else Text("Claim +${ch.xpReward} XP", fontWeight = FontWeight.SemiBold)
                }
            }
            !view.isJoined -> {
                Button(
                    onClick = onJoin,
                    enabled = !isBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = ArenaColors.Violet, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isBusy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    else Text("Join Challenge", fontWeight = FontWeight.SemiBold)
                }
            }
            else -> {
                Text("In progress · ${ch.participantCount} participants", color = ArenaColors.Muted, fontSize = 12.sp)
            }
        }
    }
}
