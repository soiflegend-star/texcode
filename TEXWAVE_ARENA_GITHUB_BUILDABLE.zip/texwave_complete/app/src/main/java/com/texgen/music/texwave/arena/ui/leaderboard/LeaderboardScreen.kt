package com.texgen.music.texwave.arena.ui.leaderboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.arena.data.model.LeaderboardEntry
import com.texgen.music.texwave.arena.data.model.LeaderboardPage
import com.texgen.music.texwave.arena.data.model.LeaderboardScope
import com.texgen.music.texwave.arena.data.repository.ArenaRepository
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import kotlinx.coroutines.launch

@Composable
fun LeaderboardScreen(
    repository: ArenaRepository = ArenaModule.repository
) {
    var scope by remember { mutableStateOf(LeaderboardScope.GLOBAL_ALL_TIME) }
    val page by repository.observeLeaderboard(scope).collectAsState(
        initial = LeaderboardPage(scope, emptyList(), null, 0, "")
    )
    val scopeLaunch = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        scopeLaunch.launch { repository.markLeaderboardVisited() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArenaColors.Bg)
    ) {
        Text(
            "LEADERBOARD",
            color = ArenaColors.Cyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )

        // Scope chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ScopeChip("All-time", LeaderboardScope.GLOBAL_ALL_TIME, scope) { scope = it }
            ScopeChip("Weekly", LeaderboardScope.GLOBAL_WEEKLY, scope) { scope = it }
            ScopeChip("Monthly", LeaderboardScope.GLOBAL_MONTHLY, scope) { scope = it }
            ScopeChip("Friends", LeaderboardScope.FRIENDS, scope) { scope = it }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "${page.periodLabel} · ${page.totalPlayers} players",
            color = ArenaColors.Muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Podium
            if (page.entries.size >= 3) {
                item {
                    Podium(page.entries.take(3))
                    Spacer(Modifier.height(12.dp))
                }
            }

            // Rest of list (skip top 3 if shown)
            val rest = if (page.entries.size >= 3) page.entries.drop(3) else page.entries
            items(rest, key = { it.userId }) { entry ->
                RankRow(entry)
            }

            // Sticky own rank if outside top page
            page.currentUserEntry?.let { me ->
                if (me.rank > page.entries.size || me.rank > 3 && rest.none { it.isCurrentUser }) {
                    item {
                        Spacer(Modifier.height(8.dp))
                        Text("Your position", color = ArenaColors.Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        RankRow(me, highlight = true)
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun ScopeChip(
    label: String,
    value: LeaderboardScope,
    selected: LeaderboardScope,
    onSelect: (LeaderboardScope) -> Unit
) {
    FilterChip(
        selected = selected == value,
        onClick = { onSelect(value) },
        label = { Text(label, fontSize = 12.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = ArenaColors.Cyan.copy(alpha = 0.2f),
            selectedLabelColor = ArenaColors.Cyan,
            containerColor = ArenaColors.Surface,
            labelColor = ArenaColors.Muted
        )
    )
}

@Composable
private fun Podium(top3: List<LeaderboardEntry>) {
    // Order visually: 2nd | 1st | 3rd
    val second = top3.getOrNull(1)
    val first = top3.getOrNull(0)
    val third = top3.getOrNull(2)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .arenaGlassCard(18)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        if (second != null) PodiumSlot(second, height = 72.dp, color = ArenaColors.RankSilver)
        if (first != null) PodiumSlot(first, height = 96.dp, color = ArenaColors.RankGold)
        if (third != null) PodiumSlot(third, height = 56.dp, color = ArenaColors.RankBronze)
    }
}

@Composable
private fun PodiumSlot(entry: LeaderboardEntry, height: androidx.compose.ui.unit.Dp, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(color.copy(alpha = 0.5f), ArenaColors.Violet.copy(alpha = 0.3f))
                    )
                )
                .border(2.dp, color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                entry.username.take(1).uppercase(),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            entry.username,
            color = ArenaColors.Text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
        Text("#${entry.rank}", color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text("${formatXp(entry.xp)} XP", color = ArenaColors.Muted, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .width(64.dp)
                .height(height)
                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                .background(color.copy(alpha = 0.25f))
        )
    }
}

@Composable
private fun RankRow(entry: LeaderboardEntry, highlight: Boolean = false) {
    val bg = if (entry.isCurrentUser || highlight)
        Modifier
            .fillMaxWidth()
            .border(1.dp, ArenaColors.Cyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            .arenaGlassCard(14)
    else
        Modifier.fillMaxWidth().arenaGlassCard(14)

    Row(
        modifier = bg.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "#${entry.rank}",
            color = when (entry.rank) {
                1 -> ArenaColors.RankGold
                2 -> ArenaColors.RankSilver
                3 -> ArenaColors.RankBronze
                else -> ArenaColors.Muted
            },
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(40.dp),
            textAlign = TextAlign.Center
        )
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(ArenaColors.SurfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            Text(
                entry.username.take(1).uppercase(),
                color = ArenaColors.Cyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                entry.displayName + if (entry.isCurrentUser) " (you)" else "",
                color = ArenaColors.Text,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
            Text("Lv ${entry.level}", color = ArenaColors.Muted, fontSize = 12.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(formatXp(entry.xp), color = ArenaColors.Cyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("XP", color = ArenaColors.Muted, fontSize = 11.sp)
        }
    }
}

private fun formatXp(v: Long): String = when {
    v >= 1_000_000 -> String.format("%.1fM", v / 1_000_000.0)
    v >= 1_000 -> String.format("%.1fK", v / 1_000.0)
    else -> v.toString()
}
