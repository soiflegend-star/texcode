package com.texgen.music.texwave.arena.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.SportsMma
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.texgen.music.texwave.arena.data.model.WarriorGender
import com.texgen.music.texwave.arena.data.model.WarriorLoadout
import com.texgen.music.texwave.arena.domain.RankSystem
import com.texgen.music.texwave.arena.ui.theme.ArenaColors
import com.texgen.music.texwave.arena.ui.theme.arenaGlassCard
import com.texgen.music.texwave.arena.ui.three.Warrior3DView

/**
 * Immersive Arena Home — warrior-centric premium HUD.
 */
@Composable
fun ArenaHomeScreen(
    viewModel: ArenaHomeViewModel = viewModel(),
    onOpenTraining: () -> Unit = {},
    onOpenCamera: () -> Unit = {},
    onOpenChampionship: () -> Unit = {},
    onOpenWarrior: () -> Unit = {},
    onOpenRanks: () -> Unit = {},
    onOpenChallenges: () -> Unit = {},
    onOpenAchievements: () -> Unit = {},
    onOpenSquads: () -> Unit = {}
) {
    val state by viewModel.state.collectAsState()
    val player = state.player
    val level = player.level.coerceIn(1, 100)
    val rank = RankSystem.RankTier.forLevel(level)
    val loadout = WarriorLoadout(gender = WarriorGender.BOY)

    Box(
        Modifier
            .fillMaxSize()
            .background(ArenaColors.ScreenBg)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(ArenaColors.AmbientTop)
        )

        when {
            state.isLoading && player.userId.isEmpty() -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Loading Arena…", color = ArenaColors.Muted)
                }
            }
            state.error != null -> {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(state.error ?: "Error", color = ArenaColors.Magenta)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Retry",
                        color = ArenaColors.Cyan,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(ArenaColors.Cyan.copy(alpha = 0.15f))
                            .clickable { viewModel.refresh() }
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                    )
                }
            }
            else -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "TEXWAVE ARENA",
                                    color = ArenaColors.Cyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 3.sp
                                )
                                Text(
                                    player.displayName.ifBlank { player.username },
                                    color = ArenaColors.Text,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            RankPill(rank, level)
                        }
                    }

                    item {
                        Warrior3DView(
                            loadout = loadout,
                            rank = rank,
                            heightDp = 300,
                            modifier = Modifier.clickable(onClick = onOpenWarrior)
                        )
                    }

                    item {
                        // XP HUD
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .arenaGlassCard(18)
                                .padding(16.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("LEVEL $level", color = ArenaColors.Text, fontWeight = FontWeight.Bold)
                                Text(
                                    "${player.xpIntoCurrentLevel} / ${player.xpRequiredForNextLevel} XP",
                                    color = ArenaColors.Muted,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(ArenaColors.Outline.copy(alpha = 0.5f))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(player.progressFraction.coerceIn(0.02f, 1f))
                                        .height(10.dp)
                                        .background(
                                            Brush.horizontalGradient(
                                                listOf(ArenaColors.Violet, ArenaColors.Cyan)
                                            )
                                        )
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "${player.totalPushUps} accepted reps · Rank ${rank.displayName}",
                                color = ArenaColors.Muted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    item {
                        Text(
                            "COMMAND",
                            color = ArenaColors.Muted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }

                    item {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CommandTile(
                                "Train",
                                Icons.Filled.FitnessCenter,
                                ArenaColors.Cyan,
                                Modifier.weight(1f),
                                onOpenTraining
                            )
                            CommandTile(
                                "Camera",
                                Icons.Filled.Videocam,
                                ArenaColors.Violet,
                                Modifier.weight(1f),
                                onOpenCamera
                            )
                        }
                    }
                    item {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CommandTile(
                                "Championship",
                                Icons.Filled.SportsMma,
                                ArenaColors.Magenta,
                                Modifier.weight(1f),
                                onOpenChampionship
                            )
                            CommandTile(
                                "Forge",
                                Icons.Filled.MilitaryTech,
                                ArenaColors.RankGold,
                                Modifier.weight(1f),
                                onOpenWarrior
                            )
                        }
                    }
                    item {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CommandTile(
                                "Ranks",
                                Icons.Filled.EmojiEvents,
                                ArenaColors.Cyan,
                                Modifier.weight(1f),
                                onOpenRanks
                            )
                            CommandTile(
                                "Squads",
                                Icons.Filled.Groups,
                                ArenaColors.Violet,
                                Modifier.weight(1f),
                                onOpenSquads
                            )
                        }
                    }

                    item {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            SmallLink("Challenges", onOpenChallenges, Modifier.weight(1f))
                            SmallLink("Achievements", onOpenAchievements, Modifier.weight(1f))
                        }
                    }

                    item {
                        Text(
                            "Avatar is cosmetic game progression. Camera counts are measured on-device, not server-verified proof.",
                            color = ArenaColors.Muted.copy(alpha = 0.75f),
                            fontSize = 10.sp
                        )
                    }
                    item { Spacer(Modifier.height(72.dp)) }
                }
            }
        }
    }
}

@Composable
private fun RankPill(rank: RankSystem.RankTier, level: Int) {
    val color = when {
        rank.ordinal >= RankSystem.RankTier.S_HUNTER.ordinal -> ArenaColors.RankGold
        rank.ordinal >= RankSystem.RankTier.A.ordinal -> ArenaColors.Magenta
        else -> ArenaColors.Cyan
    }
    Text(
        "LV $level · ${rank.displayName}",
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
private fun CommandTile(
    label: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier
            .height(96.dp)
            .arenaGlassCard(16)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(26.dp))
        Text(label, color = ArenaColors.Text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun SmallLink(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Text(
        label,
        color = ArenaColors.Cyan,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = modifier
            .arenaGlassCard(12)
            .clickable(onClick = onClick)
            .padding(14.dp)
    )
}
