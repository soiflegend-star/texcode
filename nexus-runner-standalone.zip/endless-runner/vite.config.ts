import { defineConfig } from "vite";

// base "./" makes the build work from any sub-path (GitHub Pages project sites, itch.io, a local file server).
export default defineConfig({
  root: ".",
  base: "./",
  publicDir: "assets",
  server: { port: 5173, host: true, open: false },   // host:true → reachable from a phone on the same Wi-Fi
  preview: { port: 4173, host: true },
  build: { outDir: "dist", target: "es2022", chunkSizeWarningLimit: 1200 },
});
