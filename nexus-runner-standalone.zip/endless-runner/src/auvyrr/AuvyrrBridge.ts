/**
 * AuvyrrBridge — Version 1.0.0
 *
 * Clean, versioned, optional intelligence boundary.
 *
 * - Game never blocks waiting for AUVYRR.
 * - All commands are validated before execution.
 * - Full offline / no-AUVYRR fallback.
 * - Real AUVYRR connection is NOT provided in this deliverable.
 */

import {
  AUVYRR_BRIDGE_VERSION,
  AuvyrrBridgeConfig,
  AuvyrrCommand,
  AuvyrrEvent,
  CommandExecutionResult,
  CommandValidationResult,
  GameStateSnapshot,
} from "./types.js";

export type StateProvider = () => GameStateSnapshot;

/** Declarative payload schema: validated by the bridge before any handler runs. */
export interface FieldSchema { type: "string" | "number" | "boolean"; required?: boolean; min?: number; max?: number; enum?: readonly string[]; maxLength?: number }
export type PayloadSchema = Record<string, FieldSchema>;
export type CommandHandler = (cmd: AuvyrrCommand) => Promise<CommandExecutionResult>;
export type EventListener = (event: AuvyrrEvent) => void;

const DEFAULT_CONFIG: AuvyrrBridgeConfig = {
  enabled: true,
  version: AUVYRR_BRIDGE_VERSION,
  maxEventQueueSize: 256,
  maxCommandQueueSize: 64,
  stateSnapshotIntervalMs: 500,
  commandTimeoutMs: 2000,
  fallbackToLocalIntelligence: true,
};

export class AuvyrrBridge {
  private config: AuvyrrBridgeConfig;
  private eventQueue: AuvyrrEvent[] = [];
  private commandQueue: AuvyrrCommand[] = [];
  private listeners: EventListener[] = [];
  private stateProvider: StateProvider | null = null;
  private commandHandlers = new Map<string, CommandHandler>();
  private schemas = new Map<string, PayloadSchema>();
  private lastSnapshot: GameStateSnapshot | null = null;
  private snapshotTimer: ReturnType<typeof setInterval> | null = null;
  private connected = false;
  private transport: { send: (data: string) => void; close?: () => void } | null = null;
  private transportHandler: ((event: MessageEvent) => void) | null = null;

  /** Standalone mode: disable to make every emit/command a no-op. */
  setEnabled(on: boolean) { this.config.enabled = on; }
  isEnabled() { return this.config.enabled; }

  constructor(config: Partial<AuvyrrBridgeConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  // ─────────────────────────────────────────────
  // Lifecycle
  // ─────────────────────────────────────────────

  initialize(stateProvider: StateProvider): void {
    this.stateProvider = stateProvider;
    if (this.config.enabled) {
      this.startSnapshotLoop();
    }
    console.info(
      `[AuvyrrBridge] Initialized v${this.config.version} | Real connection: NOT PROVIDED`
    );
  }

  shutdown(): void {
    if (this.snapshotTimer) {
      clearInterval(this.snapshotTimer);
      this.snapshotTimer = null;
    }
    this.eventQueue = [];
    this.commandQueue = [];
    this.detachTransport();
  }

  /** Attach any JSON transport (MessagePort, WebView bridge, WebSocket adapter, etc.). */
  attachTransport(transport: { send: (data: string) => void; close?: () => void }, onMessage: (handler: (event: MessageEvent) => void) => void): void {
    this.transport = transport;
    this.transportHandler = (event) => {
      try {
        const msg = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
        if (msg?.kind === "command") void this.submitCommand(msg.command);
      } catch {}
    };
    onMessage(this.transportHandler);
    this.markConnected();
  }

  detachTransport(): void {
    try { this.transport?.close?.(); } catch {}
    this.transport = null;
    this.transportHandler = null;
    this.markDisconnected();
  }

  /** Called by an external AUVYRR client when it attaches */
  markConnected(): void {
    this.connected = true;
    console.info("[AuvyrrBridge] External AUVYRR client marked as connected");
  }

  markDisconnected(): void {
    this.connected = false;
  }

  isConnected(): boolean {
    return this.connected;
  }

  getVersion(): string {
    return this.config.version;
  }

  // ─────────────────────────────────────────────
  // Game → AUVYRR  (Events)
  // ─────────────────────────────────────────────

  emit(event: Omit<AuvyrrEvent, "timestamp">): void {
    if (!this.config.enabled) return;

    const full: AuvyrrEvent = {
      ...event,
      timestamp: Date.now(),
    };

    this.eventQueue.push(full);
    if (this.eventQueue.length > this.config.maxEventQueueSize) {
      this.eventQueue.shift();
    }

    // Notify local listeners and optionally forward the same event to the attached AUVYRR transport
    if (this.transport) {
      try { this.transport.send(JSON.stringify({ kind: "event", event: full })); } catch {}
    }

    for (const listener of this.listeners) {
      try {
        listener(full);
      } catch (e) {
        console.warn("[AuvyrrBridge] Event listener error", e);
      }
    }
  }

  /** Drain events for an external consumer (future AUVYRR) */
  drainEvents(max = 50): AuvyrrEvent[] {
    const drained = this.eventQueue.splice(0, max);
    return drained;
  }

  onEvent(listener: EventListener): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  // ─────────────────────────────────────────────
  // Game → AUVYRR  (State)
  // ─────────────────────────────────────────────

  private startSnapshotLoop(): void {
    if (this.snapshotTimer) clearInterval(this.snapshotTimer);
    this.snapshotTimer = setInterval(() => {
      if (this.stateProvider) {
        try { this.lastSnapshot = this.stateProvider(); } catch { /* provider not ready */ }
      }
    }, this.config.stateSnapshotIntervalMs);
    (this.snapshotTimer as any)?.unref?.();
  }

  getLatestSnapshot(): GameStateSnapshot | null {
    if (this.stateProvider) {
      this.lastSnapshot = this.stateProvider();
      if (this.transport) {
        try { this.transport.send(JSON.stringify({ kind: "snapshot", snapshot: this.lastSnapshot })); } catch {}
      }
    }
    return this.lastSnapshot;
  }

  // ─────────────────────────────────────────────
  // AUVYRR → Game  (Commands)
  // ─────────────────────────────────────────────

  registerCommandHandler(type: string, handler: CommandHandler): void {
    this.commandHandlers.set(type, handler);
  }

  /** Register a strict payload schema for a command type. Unknown keys are dropped, bad values rejected. */
  registerCommandSchema(type: string, schema: PayloadSchema): void {
    this.schemas.set(type, schema);
  }

  /** Validate a payload against a schema. */
  private validateSchema(type: string, payload: Record<string, unknown>): { ok: true; payload: Record<string, unknown> } | { ok: false; reason: string } {
    const schema = this.schemas.get(type);
    if (!schema) return { ok: true, payload };
    const out: Record<string, unknown> = {};
    for (const [key, f] of Object.entries(schema)) {
      const v = payload[key];
      if (v === undefined || v === null) {
        if (f.required) return { ok: false, reason: `Missing required field: ${key}` };
        continue;
      }
      if (typeof v !== f.type) return { ok: false, reason: `Field ${key} must be ${f.type}` };
      if (f.type === "number") {
        if (!Number.isFinite(v as number)) return { ok: false, reason: `Field ${key} must be finite` };
        if (f.min !== undefined && (v as number) < f.min) return { ok: false, reason: `Field ${key} below minimum ${f.min}` };
        if (f.max !== undefined && (v as number) > f.max) return { ok: false, reason: `Field ${key} above maximum ${f.max}` };
      }
      if (f.type === "string") {
        if ((v as string).length > (f.maxLength ?? 64)) return { ok: false, reason: `Field ${key} too long` };
        if (f.enum && !f.enum.includes(v as string)) return { ok: false, reason: `Field ${key} must be one of: ${f.enum.join(", ")}` };
      }
      out[key] = v;
    }
    return { ok: true, payload: out };
  }

  /** External AUVYRR (or local intelligence) submits a command */
  async submitCommand(cmd: AuvyrrCommand): Promise<CommandExecutionResult> {
    if (!this.config.enabled) {
      return { success: false, reason: "Bridge disabled" };
    }

    const validation = this.validateCommand(cmd);
    if (!validation.valid) {
      return { success: false, reason: validation.reason };
    }

    // Queue + process asynchronously — never block the game loop
    this.commandQueue.push(validation.sanitized);
    if (this.commandQueue.length > this.config.maxCommandQueueSize) {
      this.commandQueue.shift();
    }

    return this.processNextCommand();
  }

  private async processNextCommand(): Promise<CommandExecutionResult> {
    const cmd = this.commandQueue.shift();
    if (!cmd) {
      return { success: false, reason: "Empty queue" };
    }

    const handler = this.commandHandlers.get(cmd.type);
    if (!handler) {
      if (this.config.fallbackToLocalIntelligence) {
        return this.localFallback(cmd);
      }
      return { success: false, reason: `No handler for ${cmd.type}` };
    }

    try {
      const timeout = cmd.timeoutMs ?? this.config.commandTimeoutMs;
      const result = await Promise.race([
        handler(cmd),
        new Promise<CommandExecutionResult>((resolve) =>
          setTimeout(
            () => resolve({ success: false, reason: "Command timeout" }),
            timeout
          )
        ),
      ]);
      return result;
    } catch (e) {
      return {
        success: false,
        reason: e instanceof Error ? e.message : "Handler exception",
      };
    }
  }

  // ─────────────────────────────────────────────
  // Validation (critical safety boundary)
  // ─────────────────────────────────────────────

  validateCommand(cmd: AuvyrrCommand): CommandValidationResult {
    if (!cmd || typeof cmd !== "object") {
      return { valid: false, reason: "Invalid command object" };
    }
    if (!cmd.id || typeof cmd.id !== "string") {
      return { valid: false, reason: "Missing or invalid command id" };
    }
    if (!cmd.type || typeof cmd.type !== "string") {
      return { valid: false, reason: "Missing or invalid command type" };
    }

    // Whitelist of allowed high-level command types
    const allowed: Set<string> = new Set([
      "suggestAction",
      "requestChallenge",
      "requestMission",
      "requestEvent",
      "requestRoute",
      "requestTrainingScenario",
      "requestDifficultyAdjustment",
      "requestRivalBehavior",
      "requestWorldMutation",
      "requestReward",
      "requestCoachingHint",
    ]);

    if (!allowed.has(cmd.type)) {
      return { valid: false, reason: `Command type not allowed: ${cmd.type}` };
    }

    // Payload sanitization (no deep code execution possible) + per-command schema validation
    const cleaned = this.sanitizePayload(cmd.payload || {});
    const checked = this.validateSchema(cmd.type, cleaned);
    if (!checked.ok) return { valid: false, reason: checked.reason };
    const sanitized: AuvyrrCommand = {
      id: String(cmd.id).slice(0, 64),
      type: cmd.type as any,
      timestamp: Date.now(),
      payload: checked.payload,
      priority: cmd.priority || "normal",
      timeoutMs: Math.min(Math.max(cmd.timeoutMs || 2000, 100), 10000),
    };

    return { valid: true, sanitized };
  }

  private sanitizePayload(payload: Record<string, unknown>): Record<string, unknown> {
    const clean: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(payload)) {
      if (typeof k !== "string" || k.length > 64) continue;
      if (
        typeof v === "string" ||
        typeof v === "number" ||
        typeof v === "boolean" ||
        v === null
      ) {
        clean[k] = v;
      } else if (Array.isArray(v) && v.length < 32) {
        clean[k] = v.filter(
          (i) =>
            typeof i === "string" ||
            typeof i === "number" ||
            typeof i === "boolean"
        );
      }
      // Objects and functions are dropped — no arbitrary code
    }
    return clean;
  }

  // ─────────────────────────────────────────────
  // Local Intelligence Fallback
  // ─────────────────────────────────────────────

  private async localFallback(cmd: AuvyrrCommand): Promise<CommandExecutionResult> {
    // Very simple local intelligence so the game never stalls
    switch (cmd.type) {
      case "requestDifficultyAdjustment":
        return {
          success: true,
          result: { adjustment: 0, reason: "Local fallback — no change" },
        };
      case "requestCoachingHint":
        return {
          success: true,
          result: { hint: "Keep your flow high by chaining advanced moves." },
        };
      default:
        return {
          success: true,
          result: { acknowledged: true, source: "local-fallback" },
        };
    }
  }

  // ─────────────────────────────────────────────
  // Diagnostics
  // ─────────────────────────────────────────────

  getDiagnostics() {
    return {
      version: this.config.version,
      enabled: this.config.enabled,
      realConnection: this.connected,
      eventQueueSize: this.eventQueue.length,
      commandQueueSize: this.commandQueue.length,
      registeredHandlers: Array.from(this.commandHandlers.keys()),
      lastSnapshotAge: this.lastSnapshot
        ? Date.now() - this.lastSnapshot.timestamp
        : null,
    };
  }
}

/** Singleton convenience for the game */
export const auvyrrBridge = new AuvyrrBridge();