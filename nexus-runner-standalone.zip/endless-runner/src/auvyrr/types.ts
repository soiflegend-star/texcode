/**
 * AUVYRR Bridge Types — Version 1.0.0
 * 
 * These are the ONLY contracts the game exposes to a future AUVYRR system.
 * No internal engine types leak here.
 * 
 * REAL AUVYRR CONNECTION: NOT PROVIDED
 * This file defines the interface only.
 */

export const AUVYRR_BRIDGE_VERSION = "1.0.0";

// ─────────────────────────────────────────────
// GAME → AUVYRR  (State Snapshot)
// ─────────────────────────────────────────────

export interface PlayerState {
  position: { x: number; y: number; z: number };
  velocity: { x: number; y: number; z: number };
  lane: number;                 // -1, 0, 1 typically
  health: number;
  maxHealth: number;
  stamina: number;
  maxStamina: number;
  movementState: MovementStateId;
  activeAbilities: string[];
  combo: number;
  flow: number;                 // 0–100 continuous skill meter
  equipmentIds: string[];
  modifiers: Record<string, number>;
  characterId: string;
}

export type MovementStateId =
  | "running"
  | "jumping"
  | "sliding"
  | "rolling"
  | "wallRunning"
  | "wallJumping"
  | "grinding"
  | "grappling"
  | "swinging"
  | "airDashing"
  | "climbing"
  | "falling"
  | "stunned"
  | "dead";

export interface WorldState {
  regionId: string;
  biomeId: string;
  chunkIndex: number;
  routeOptions: RouteOption[];
  activeHazards: HazardInfo[];
  activeEnemies: EnemyInfo[];
  visibleRewards: RewardInfo[];
  activeEvents: string[];
  environmentFlags: Record<string, boolean | number>;
}

export interface RouteOption {
  id: string;
  riskLevel: "safe" | "risky" | "extreme";
  rewardMultiplier: number;
  requiredAbility?: string;
  description: string;
}

export interface HazardInfo {
  id: string;
  type: string;
  position: { x: number; y: number; z: number };
  severity: number;
}

export interface EnemyInfo {
  id: string;
  type: string;
  position: { x: number; y: number; z: number };
  threatLevel: number;
}

export interface RewardInfo {
  id: string;
  type: string;
  value: number;
  position: { x: number; y: number; z: number };
}

export interface RunState {
  distance: number;
  score: number;
  speed: number;
  timeElapsed: number;
  currentObjective?: string;
  riskLevel: number;            // 0–1
  recentFailures: number;
  recentSuccesses: number;
  seed: string;
}

export interface ProgressionState {
  unlockedCharacters: string[];
  unlockedAbilities: string[];
  equipmentInventory: string[];
  mastery: Record<string, number>;
  activeMissions: string[];
  discoveries: string[];
  storyFlags: Record<string, boolean>;
}

export interface BehaviorSignals {
  preferredRisk: number;        // 0–1 observed
  averageReactionTime: number;
  successfulAdvancedMoves: number;
  frequentMistakes: string[];
  successfulTechniques: string[];
}

export interface RivalSnapshot {
  id: string; name: string; personality: string; lane: number; relativeZ: number; speed: number; score: number; coins: number; mood: string; ahead: boolean;
}
export interface MissionSnapshot { id: string; title: string; kind: string; progress: number; target: number; reward: number; completed: boolean }
export interface EventSnapshot { active: Array<{ id: string; name: string; remaining: number }>; atmosphere: { night: number; dusk: number; rain: number; fogMul: number; storm: number } }

export interface GameStateSnapshot {
  version: string;
  timestamp: number;
  phase: string;
  player: PlayerState;
  world: WorldState;
  run: RunState;
  boost: { meter: number; active: boolean; powerUps: Record<string, number> };
  events: EventSnapshot;
  rival: RivalSnapshot | null;
  missions: MissionSnapshot[];
  progression: ProgressionState & { unlockedRegions: string[]; highScore: number; bestDistance: number; coinBank: number };
  behavior: BehaviorSignals;
}

// ─────────────────────────────────────────────
// GAME → AUVYRR  (Events)
// ─────────────────────────────────────────────

export type AuvyrrEventType =
  | "RUN_STARTED"
  | "RUN_ENDED"
  | "PLAYER_JUMPED"
  | "PLAYER_SLID"
  | "PLAYER_WALL_RAN"
  | "PLAYER_PERFECT_DODGED"
  | "PLAYER_NEAR_MISSED"
  | "PLAYER_FAILED"
  | "PLAYER_DIED"
  | "NEW_REGION_ENTERED"
  | "SECRET_DISCOVERED"
  | "RIVAL_APPEARED"
  | "RIVAL_DEFEATED"
  | "BOSS_STARTED"
  | "BOSS_DEFEATED"
  | "MISSION_COMPLETED"
  | "REWARD_COLLECTED"
  | "COMBO_STARTED"
  | "COMBO_BROKEN"
  | "FLOW_PEAK"
  | "PLAYER_STRUGGLING"
  | "PLAYER_MASTERED_MOVEMENT"
  | "ABILITY_USED"
  | "ROUTE_CHOSEN"
  | "CUSTOM";

export interface AuvyrrEvent {
  type: AuvyrrEventType;
  timestamp: number;
  runId: string;
  payload?: Record<string, unknown>;
}

// ─────────────────────────────────────────────
// AUVYRR → GAME  (Commands)
// ─────────────────────────────────────────────

export type AuvyrrCommandType =
  | "suggestAction"
  | "requestChallenge"
  | "requestMission"
  | "requestEvent"
  | "requestRoute"
  | "requestTrainingScenario"
  | "requestDifficultyAdjustment"
  | "requestRivalBehavior"
  | "requestWorldMutation"
  | "requestReward"
  | "requestCoachingHint";

export interface AuvyrrCommand {
  id: string;                   // unique command id for tracking
  type: AuvyrrCommandType;
  timestamp: number;
  payload: Record<string, unknown>;
  priority?: "low" | "normal" | "high";
  timeoutMs?: number;
}

export type CommandValidationResult =
  | { valid: true; sanitized: AuvyrrCommand }
  | { valid: false; reason: string };

export type CommandExecutionResult =
  | { success: true; result?: unknown }
  | { success: false; reason: string };

// ─────────────────────────────────────────────
// Bridge Configuration
// ─────────────────────────────────────────────

export interface AuvyrrBridgeConfig {
  enabled: boolean;
  version: string;
  maxEventQueueSize: number;
  maxCommandQueueSize: number;
  stateSnapshotIntervalMs: number;
  commandTimeoutMs: number;
  fallbackToLocalIntelligence: boolean;
}