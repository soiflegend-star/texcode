/**
 * Post — optional bloom pipeline (EffectComposer + UnrealBloomPass + OutputPass from three/examples).
 * Enabled only on HIGH/ULTRA. Any failure returns null and the scene renders directly (no bloom).
 * NOTE: written without being able to run it against real Three.js in the authoring environment — see docs/VERIFICATION_REPORT.md.
 */
import * as THREE from "three";
import type { QualitySettings } from "../data/GameData.js";

export interface Post { render(dt: number): void; setSize(w: number, h: number, pr: number): void; dispose(): void; setStrength(s: number): void }

export async function createPost(renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.Camera, q: QualitySettings): Promise<Post | null> {
  if (q.tier !== "HIGH" && q.tier !== "ULTRA") return null;
  try {
    const [{ EffectComposer }, { RenderPass }, { UnrealBloomPass }, { OutputPass }] = await Promise.all([
      import("three/examples/jsm/postprocessing/EffectComposer.js"), import("three/examples/jsm/postprocessing/RenderPass.js"),
      import("three/examples/jsm/postprocessing/UnrealBloomPass.js"), import("three/examples/jsm/postprocessing/OutputPass.js"),
    ]);
    const size = new THREE.Vector2(); (renderer as any).getSize(size);
    const pr = renderer.getPixelRatio();
    const rt = new THREE.WebGLRenderTarget(Math.max(2, size.x * pr), Math.max(2, size.y * pr), { type: THREE.HalfFloatType, samples: q.tier === "ULTRA" ? 4 : 2 } as any);
    const composer = new EffectComposer(renderer, rt);
    composer.addPass(new RenderPass(scene, camera));
    const bloom = new UnrealBloomPass(new THREE.Vector2(size.x * 0.5, size.y * 0.5), q.tier === "ULTRA" ? 0.38 : 0.28, 0.55, 0.82);
    composer.addPass(bloom); composer.addPass(new OutputPass());
    return {
      render: (dt) => composer.render(dt),
      setSize: (w, h, p) => { composer.setPixelRatio(p); composer.setSize(w, h); bloom.resolution.set(w * 0.5, h * 0.5); },
      setStrength: (s) => { bloom.strength = s; },
      dispose: () => { composer.dispose?.(); rt.dispose(); },
    };
  } catch (e) { console.warn("[Nexus Runner] bloom pipeline unavailable, rendering without it:", e); return null; }
}
