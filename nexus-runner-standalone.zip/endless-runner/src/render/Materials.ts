/**
 * MaterialLibrary — the small set of shared PBR materials used by all merged scenery.
 * Every material uses vertex colours for tint/AO so one material serves many colours.
 * Real texture files can replace the procedural ones by assigning `map`/`normalMap` here.
 */
import * as THREE from "three";
import { QualitySettings } from "../data/GameData.js";
import * as T from "./Textures.js";

export class MaterialLibrary {
  private mats = new Map<string, THREE.Material>();
  private facade: THREE.MeshStandardMaterial[] = [];
  private roads: THREE.MeshStandardMaterial[] = [];
  private water: THREE.MeshStandardMaterial | null = null;
  private waterMap: THREE.Texture | null = null;
  private glowBasic: THREE.MeshBasicMaterial[] = [];
  textures = new Map<string, THREE.Texture>();

  constructor(public q: QualitySettings) { this.build(); }

  get(key: string): THREE.Material {
    const m = this.mats.get(key);
    if (!m) throw new Error(`[MaterialLibrary] unknown material key: ${key}`);
    return m;
  }
  has(key: string) { return this.mats.has(key); }
  allMaterials(): THREE.Material[] { return [...this.mats.values()]; }

  private std(key: string, p: THREE.MeshStandardMaterialParameters) { const m = new THREE.MeshStandardMaterial({ vertexColors: true, ...p }); this.mats.set(key, m); return m; }

  private build() {
    const q = this.q, s = q.texSize, an = q.anisotropy;
    this.std("paint", { roughness: 0.78, metalness: 0.04 });
    this.std("metal", { roughness: 0.36, metalness: 0.78 });
    this.std("rubber", { roughness: 0.95, metalness: 0 });
    this.std("foliage", { roughness: 0.92, metalness: 0 });
    this.std("glass", { roughness: 0.08, metalness: 0.9, transparent: true, opacity: 0.5, envMapIntensity: 1.4 });
    // emissive / unlit surfaces: lights, screens, hazard glows (fogged, but not tone-mapped away)
    const em = new THREE.MeshBasicMaterial({ vertexColors: true, fog: true }); this.mats.set("emissive", em); this.glowBasic.push(em);
    const additive = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false }); this.mats.set("glow", additive);

    const conc = T.concreteTexture(s, an);
    this.std("concrete", { map: conc.map, normalMap: conc.normal, roughness: 0.94, normalScale: new THREE.Vector2(0.7, 0.7) });
    const walk = T.tileTexture("sidewalk", s, an);
    this.std("sidewalk", { map: walk.map, normalMap: walk.normal, roughness: 0.88, normalScale: new THREE.Vector2(0.8, 0.8) });
    const plaza = T.tileTexture("plaza", s, an);
    this.std("plaza", { map: plaza.map, normalMap: plaza.normal, roughness: 0.85 });
    const sub = T.tileTexture("subway", s, an);
    this.std("tile", { map: sub.map, normalMap: sub.normal, roughness: 0.32, metalness: 0.0, envMapIntensity: 0.9 });
    const corr = T.corrugatedTexture(s, an);
    this.std("corrugated", { map: corr.map, normalMap: corr.normal, roughness: 0.55, metalness: 0.45 });
    const grass = T.grassTexture(s, an);
    this.std("grass", { map: grass, roughness: 1 });
    const stone = T.stoneTexture(s, an);
    this.std("stone", { map: stone.map, normalMap: stone.normal, roughness: 0.95 });

    for (const k of ["glass", "brick", "concrete", "industrial", "stone"] as const) {
      const f = T.facadeTextures(k, s, an);
      const m = this.std("facade_" + k, { map: f.map, emissiveMap: f.emissive, emissive: new THREE.Color(0xffffff), emissiveIntensity: 0, roughness: k === "glass" ? 0.18 : 0.8, metalness: k === "glass" ? 0.55 : 0.05 });
      this.facade.push(m);
    }
    for (const k of ["city", "highway", "subway", "industrial", "ruins"] as const) {
      const r = T.roadTextures(k, s, an);
      const m = this.std("road_" + k, { map: r.map, normalMap: r.normal, roughness: 0.92, metalness: 0.02, normalScale: new THREE.Vector2(0.9, 0.9) });
      this.roads.push(m);
    }
    const w = T.waterTexture(s, an); this.waterMap = w.map;
    this.water = this.std("water", { map: w.map, normalMap: w.normal, roughness: 0.04, metalness: 0.2, transparent: true, opacity: 0.88, envMapIntensity: 1.6 });
    this.textures.set("nexusBillboard", T.nexusBillboardTexture());
  }

  /** Surfaces get glossier & darker when wet; windows glow at night. Cheap: only uniforms change. */
  setAtmosphere(wet: number, night: number) {
    for (const r of this.roads) { r.roughness = 0.92 - 0.72 * wet; r.envMapIntensity = 1 + wet * 1.2; r.color.setScalar(1 - 0.3 * wet); }
    const sw = this.get("sidewalk") as THREE.MeshStandardMaterial; sw.roughness = 0.88 - 0.5 * wet; sw.color.setScalar(1 - 0.2 * wet);
    for (const f of this.facade) f.emissiveIntensity = night * 1.35;
  }

  /** flicker: 0..1 — emissive lights waver slightly (subway fluorescents, damaged signs). */
  update(dt: number, t: number, flicker = 0) {
    const f = 1 - flicker * (0.12 + 0.3 * Math.max(0, Math.sin(t * 37) * Math.sin(t * 11.3) - 0.6)); for (const m of this.glowBasic) m.color.setScalar(f);
    if (this.waterMap) { this.waterMap.offset.set((t * 0.015) % 1, (t * 0.03) % 1); }
    const nm = (this.water as any)?.normalMap as THREE.Texture | null; if (nm) nm.offset.set((t * -0.02) % 1, (t * 0.025) % 1);
  }

  /** Per-instance helper for decals like billboards (not shared). */
  makeSignMaterial(map: THREE.Texture, emissive = 0.55): THREE.MeshStandardMaterial {
    return new THREE.MeshStandardMaterial({ map, emissiveMap: map, emissive: new THREE.Color(0xffffff), emissiveIntensity: emissive, roughness: 0.5, metalness: 0.1 });
  }

  dispose() { for (const m of this.mats.values()) m.dispose(); for (const t of this.textures.values()) t.dispose(); }
}
