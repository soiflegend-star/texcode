/**
 * Ambient — living-world extras that never touch gameplay: distant traffic on far roads and drones with blinking lights.
 * Purely visual, instanced, recycled around the player, scaled by the quality tier (q.ambientTraffic).
 */
import * as THREE from "three";
import type { QualitySettings } from "../data/GameData.js";

interface Car { x: number; y: number; z: number; v: number; dir: 1 | -1; s: number }
interface Drone { a: number; r: number; y: number; w: number; cx: number; ph: number }

/** Per-region traffic layout (scene units). null = no traffic in this region. */
const LAYOUT: Array<null | { xs: number[]; y: number; speeds: [number, number]; scale: number; both: boolean; drones: boolean }> = [
  { xs: [-46, -38, 38, 46], y: -18, speeds: [10, 17], scale: 1, both: true, drones: true },      // rooftops: street level far below
  { xs: [-30, -24, 24, 30], y: -16, speeds: [18, 30], scale: 1.1, both: true, drones: true },    // highway: lower viaduct roads
  null,                                                                                         // subway
  { xs: [-52, -46, 46, 52], y: 0, speeds: [6, 12], scale: 1.7, both: false, drones: true },      // industrial: trucks on far yard roads
  null,                                                                                         // ruins
];

export class Ambient {
  group = new THREE.Group();
  private bodies: THREE.InstancedMesh; private lights: THREE.InstancedMesh; private cars: Car[] = [];
  private droneGroup = new THREE.Group(); private drones: Drone[] = []; private droneLights: THREE.Mesh[] = [];
  private max: number; private _m = new THREE.Matrix4(); private _q = new THREE.Quaternion(); private _e = new THREE.Euler(); private _p = new THREE.Vector3(); private _s = new THREE.Vector3(); private t = 0;

  constructor(private q: QualitySettings) {
    this.max = Math.max(2, q.ambientTraffic * 2);
    this.bodies = new THREE.InstancedMesh(new THREE.BoxGeometry(1.9, 1.3, 4.2), new THREE.MeshStandardMaterial({ roughness: 0.4, metalness: 0.5 }), this.max);
    this.lights = new THREE.InstancedMesh(new THREE.BoxGeometry(1.7, 0.22, 0.12), new THREE.MeshBasicMaterial({ color: 0xffffff, fog: true }), this.max * 2);
    for (const m of [this.bodies, this.lights]) { m.frustumCulled = false; m.count = 0; this.group.add(m); }
    const colors = [0xc8452f, 0x2f6db5, 0xe8e6de, 0x3a3f45, 0xd9a02b, 0x3f8a55, 0xb0b4b8];
    for (let i = 0; i < this.max; i++) { this.cars.push({ x: 0, y: 0, z: -40 - Math.random() * 200, v: 12, dir: 1, s: 1 }); this.bodies.setColorAt(i, new THREE.Color(colors[i % colors.length])); }
    // drones: dark body + blinking red/white light
    const dm = new THREE.MeshStandardMaterial({ color: 0x2b333b, roughness: 0.4, metalness: 0.7 });
    for (let i = 0; i < 4; i++) {
      const d = new THREE.Group(); d.add(new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.18, 0.7), dm));
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const r = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.02, 10), new THREE.MeshBasicMaterial({ color: 0x9fb0bf, transparent: true, opacity: 0.35 })); r.position.set(sx * 0.5, 0.12, sz * 0.5); d.add(r); }
      const l = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 5), new THREE.MeshBasicMaterial({ color: i % 2 ? 0xff3a2e : 0xffffff })); l.position.set(0, -0.06, -0.38); d.add(l); this.droneLights.push(l);
      this.droneGroup.add(d); this.drones.push({ a: Math.random() * 6.28, r: 10 + Math.random() * 14, y: 9 + Math.random() * 12, w: 0.25 + Math.random() * 0.3, cx: (i % 2 ? 1 : -1) * (14 + Math.random() * 10), ph: Math.random() * 6 });
    }
    this.group.add(this.droneGroup);
  }

  private respawn(c: Car, lay: NonNullable<(typeof LAYOUT)[number]>, far: boolean) {
    c.x = lay.xs[Math.floor(Math.random() * lay.xs.length)] + (Math.random() - 0.5) * 2; c.y = lay.y; c.s = lay.scale * (0.9 + Math.random() * 0.3);
    c.dir = lay.both && Math.random() < 0.5 ? -1 : 1; c.v = lay.speeds[0] + Math.random() * (lay.speeds[1] - lay.speeds[0]);
    c.z = far ? -(150 + Math.random() * 120) : -(10 + Math.random() * 260);
  }

  /** speed = player speed (m/s). camPos used to anchor traffic around the player. */
  update(dt: number, region: number, speed: number, enclosed: boolean, cam: THREE.Vector3) {
    this.t += dt; const lay = LAYOUT[region % LAYOUT.length];
    const on = !!lay && !enclosed;
    this.bodies.visible = this.lights.visible = on; this.droneGroup.visible = !!lay?.drones && !enclosed && this.q.ambientTraffic >= 6;
    if (on && lay) {
      const n = Math.min(this.max, Math.max(2, this.q.ambientTraffic * 2)); let li = 0;
      for (let i = 0; i < n; i++) {
        const c = this.cars[i]; if (c.y !== lay.y || c.z === undefined || Math.abs(c.x) < 15 || this.lastRegion !== region) this.respawn(c, lay, false);
        // relative motion toward the camera: the player moves at `speed`; same-direction cars move away at v, oncoming approach at v
        c.z += (speed - c.v * c.dir) * dt;
        if (c.z > 30) this.respawn(c, lay, true); if (c.z < -300) c.z = 30 - Math.random() * 10;
        this._e.set(0, c.dir === 1 ? 0 : Math.PI, 0); this._q.setFromEuler(this._e); this._p.set(c.x, c.y + 0.65 * c.s, c.z); this._s.set(c.s, c.s, c.s * (lay.scale > 1.5 ? 1.8 : 1));
        this._m.compose(this._p, this._q, this._s); this.bodies.setMatrixAt(i, this._m);
        // rear (red) and front (white) light bars
        for (const side of [1, -1]) { const dz = side * 2.15 * this._s.z; this._p.set(c.x, c.y + 0.55 * c.s, c.z + dz * (c.dir === 1 ? 1 : -1)); this._m.compose(this._p, this._q, this._s.set(c.s, c.s, c.s)); this.lights.setMatrixAt(li, this._m); this.lights.setColorAt(li, new THREE.Color(side === 1 ? (c.dir === 1 ? 0xff2a2a : 0xfff3c8) : (c.dir === 1 ? 0xfff3c8 : 0xff2a2a))); li++; }
      }
      this.bodies.count = n; this.lights.count = li; this.bodies.instanceMatrix.needsUpdate = true; this.lights.instanceMatrix.needsUpdate = true;
      if (this.bodies.instanceColor) this.bodies.instanceColor.needsUpdate = true; if (this.lights.instanceColor) this.lights.instanceColor.needsUpdate = true;
      this.lastRegion = region;
    }
    if (this.droneGroup.visible) {
      this.drones.forEach((d, i) => { const g = this.droneGroup.children[i]; d.a += dt * d.w; g.position.set(d.cx + Math.sin(d.a) * d.r * 0.4, d.y + Math.sin(this.t * 1.3 + d.ph) * 0.5, -Math.cos(d.a) * d.r * 3 - 20); g.rotation.y = d.a; (this.droneLights[i].material as THREE.MeshBasicMaterial).color.setHex(Math.sin(this.t * 6 + d.ph) > 0 ? (i % 2 ? 0xff3a2e : 0xffffff) : 0x201010); });
    }
    this.group.position.set(cam.x * 0, 0, 0);
  }
  private lastRegion = -1;
  dispose() { this.bodies.geometry.dispose(); this.lights.geometry.dispose(); }
}
