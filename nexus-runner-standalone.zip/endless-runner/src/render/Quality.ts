/** Quality auto-detection and a downward-only FPS governor (with hysteresis) for AUTO mode. */
import { QUALITY, QUALITY_ORDER, QualityTier } from "../data/GameData.js";

export interface DeviceInfo { cores: number; memGB: number; coarse: boolean; pixels: number; dpr: number; renderer: string }

export function readDevice(gl?: WebGLRenderingContext | WebGL2RenderingContext | null): DeviceInfo {
  const nav: any = typeof navigator !== "undefined" ? navigator : {};
  let renderer = "";
  try { const ext = gl?.getExtension("WEBGL_debug_renderer_info"); if (ext && gl) renderer = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) ?? ""); } catch { /* ignore */ }
  const w = typeof window !== "undefined" ? window : ({ innerWidth: 1280, innerHeight: 720, devicePixelRatio: 1, matchMedia: undefined } as any);
  return { cores: nav.hardwareConcurrency ?? 4, memGB: nav.deviceMemory ?? 4, coarse: !!(w.matchMedia && w.matchMedia("(pointer: coarse)").matches), pixels: w.innerWidth * w.innerHeight * (w.devicePixelRatio || 1) ** 2, dpr: w.devicePixelRatio || 1, renderer };
}

/** Pick a starting tier from coarse device capability signals (a heuristic, not a benchmark). */
export function detectTier(d: DeviceInfo): QualityTier {
  const r = d.renderer.toLowerCase();
  if (/swiftshader|llvmpipe|software|basic render/.test(r)) return "LOW";
  let score = 0;
  score += d.cores >= 8 ? 2 : d.cores >= 6 ? 1.5 : d.cores >= 4 ? 1 : 0;
  score += d.memGB >= 8 ? 2 : d.memGB >= 4 ? 1 : 0;
  if (/apple (m|gpu)|rtx|radeon rx|geforce|arc|adreno \(tm\) 7|adreno 7|mali-g7|mali-g9/.test(r)) score += 2;
  if (/adreno \(tm\) [2-5]|mali-4|mali-t|powervr|intel.*(hd|uhd) graphics/.test(r)) score -= 1;
  if (d.coarse) score -= 1;
  if (d.pixels > 3.5e6) score -= 1;
  return score >= 5 ? "ULTRA" : score >= 3.5 ? "HIGH" : score >= 2 ? "MEDIUM" : "LOW";
}

export class QualityGovernor {
  private acc = 0; private n = 0; private lowWindows = 0; private cooldown = 6;
  constructor(public tier: QualityTier) {}
  /** returns a lower tier when sustained FPS is below target, else null */
  update(dt: number, running: boolean): QualityTier | null {
    if (!running || dt <= 0 || dt > 0.5) return null;
    this.cooldown -= dt; if (this.cooldown > 0) return null;
    this.acc += dt; this.n++;
    if (this.acc < 2.5) return null;
    const fps = this.n / this.acc; this.acc = 0; this.n = 0;
    const target = QUALITY[this.tier].fpsTarget;
    if (fps < target * 0.8) this.lowWindows++; else this.lowWindows = Math.max(0, this.lowWindows - 1);
    if (this.lowWindows >= 2) {
      this.lowWindows = 0; this.cooldown = 8;
      const i = QUALITY_ORDER.indexOf(this.tier);
      if (i > 0) { this.tier = QUALITY_ORDER[i - 1]; return this.tier; }
    }
    return null;
  }
}
