/**
 * ChunkLibrary — builds each (region, variant, kind, landmark) scenery template once (merged geometry),
 * then hands out cheap clones (shared geometry/materials) and mirrored clones. Templates are built lazily
 * and can be pre-warmed one per frame so streaming never causes a long frame.
 */
import * as THREE from "three";
import { ChunkPlan } from "../world/ChunkPlan.js";
import { buildRegionChunk } from "./Regions.js";
import { signMesh } from "./Models.js";
import type { MaterialLibrary } from "./Materials.js";
import type { EmitterSpec, AnimSpec } from "./Props.js";

export interface ChunkTemplate { group: THREE.Group; emitters: EmitterSpec[]; anims: AnimSpec[]; stats: { parts: number; vertices: number; materials: number; buildMs: number } }
export interface ChunkInstance { plan: ChunkPlan; group: THREE.Group; emitters: EmitterSpec[]; mirror: boolean }

export function templateKey(p: ChunkPlan) { return `${p.region.index}|${p.variant}|${p.kind === "transition" ? "T" : "N"}|${p.kind === "transition" ? "" : p.landmark ?? ""}`; }

export class ChunkLibrary {
  private templates = new Map<string, ChunkTemplate>();
  builds = 0; totalBuildMs = 0; maxBuildMs = 0;
  constructor(public lib: MaterialLibrary, public seedTag = "nexus") {}

  has(p: ChunkPlan) { return this.templates.has(templateKey(p)); }

  getTemplate(p: ChunkPlan): ChunkTemplate {
    const key = templateKey(p); let t = this.templates.get(key);
    if (t) return t;
    const t0 = typeof performance !== "undefined" ? performance.now() : Date.now();
    const ctx = buildRegionChunk(p.region.index, p.variant, this.lib, this.seedTag, { transition: p.kind === "transition", landmark: p.kind === "transition" ? null : p.landmark });
    const group = ctx.b.build(this.lib);
    const signs = new THREE.Group(); signs.name = "signs";
    for (const s of ctx.signs) signs.add(signMesh(s));
    group.add(signs);
    for (const e of ctx.extras) group.add(e);
    const ms = (typeof performance !== "undefined" ? performance.now() : Date.now()) - t0;
    this.builds++; this.totalBuildMs += ms; this.maxBuildMs = Math.max(this.maxBuildMs, ms);
    t = { group, emitters: ctx.emitters, anims: ctx.anims, stats: { ...ctx.b.stats(), buildMs: ms } };
    this.templates.set(key, t);
    return t;
  }

  /** Cheap instance of a template. Mirrored copies flip X; sign meshes are counter-flipped so text stays readable. */
  instantiate(p: ChunkPlan): ChunkInstance {
    const t = this.getTemplate(p);
    const g = t.group.clone(true);
    const mirror = p.mirror && p.kind !== "transition" && p.kind !== "start";
    if (mirror) {
      g.scale.x = -1;
      const signs = g.getObjectByName("signs");
      signs?.children.forEach((m: any) => { m.scale.x = -1; });
    }
    g.name = `chunk_${p.index}`;
    return { plan: p, group: g, emitters: t.emitters, mirror };
  }

  clear() { this.templates.clear(); }
  stats() { return { templates: this.templates.size, builds: this.builds, avgBuildMs: this.builds ? this.totalBuildMs / this.builds : 0, maxBuildMs: this.maxBuildMs }; }
}
