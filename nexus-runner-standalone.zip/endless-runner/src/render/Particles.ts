/**
 * Particles — one pooled point-sprite system (alpha) and one additive system, plus speed-lines and rain streaks.
 * All buffers are pre-allocated; emission is O(1) with a ring cursor. Counts scale with the quality tier.
 */
import * as THREE from "three";
import { softDot } from "./Textures.js";

const VS = `attribute float aSize; attribute vec4 aColor; varying vec4 vColor; uniform float uScale;
void main(){ vColor = aColor; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = aSize * uScale / max(0.5, -mv.z); gl_Position = projectionMatrix * mv; }`;
const FS = `uniform sampler2D uMap; varying vec4 vColor;
void main(){ vec4 t = texture2D(uMap, gl_PointCoord); float a = t.a * vColor.a; if (a < 0.01) discard; gl_FragColor = vec4(vColor.rgb, a); }`;

class Pool {
  pos: Float32Array; vel: Float32Array; size: Float32Array; col: Float32Array; life: Float32Array; maxLife: Float32Array; grav: Float32Array; size0: Float32Array; drag: Float32Array; grow: Float32Array;
  geo = new THREE.BufferGeometry(); points: THREE.Points; cursor = 0; mat: THREE.ShaderMaterial;
  constructor(public n: number, additive: boolean, map: THREE.Texture) {
    this.pos = new Float32Array(n * 3); this.vel = new Float32Array(n * 3); this.size = new Float32Array(n); this.col = new Float32Array(n * 4); this.life = new Float32Array(n); this.maxLife = new Float32Array(n); this.grav = new Float32Array(n); this.size0 = new Float32Array(n); this.drag = new Float32Array(n); this.grow = new Float32Array(n);
    this.geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute("aSize", new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute("aColor", new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage));
    this.mat = new THREE.ShaderMaterial({ vertexShader: VS, fragmentShader: FS, transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, uniforms: { uMap: { value: map }, uScale: { value: 600 } } });
    this.points = new THREE.Points(this.geo, this.mat); this.points.frustumCulled = false; this.points.renderOrder = 10;
    for (let i = 0; i < n; i++) this.pos[i * 3 + 1] = -999;
  }
  spawn(x: number, y: number, z: number, vx: number, vy: number, vz: number, life: number, size: number, r: number, g: number, b: number, a: number, grav: number, drag = 0, grow = 0) {
    const i = this.cursor; this.cursor = (this.cursor + 1) % this.n;
    this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z; this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
    this.life[i] = life; this.maxLife[i] = life; this.size0[i] = size; this.size[i] = size; this.col[i * 4] = r; this.col[i * 4 + 1] = g; this.col[i * 4 + 2] = b; this.col[i * 4 + 3] = a; this.grav[i] = grav; this.drag[i] = drag; this.grow[i] = grow;
  }
  update(dt: number) {
    const n = this.n;
    for (let i = 0; i < n; i++) {
      if (this.life[i] <= 0) { if (this.pos[i * 3 + 1] > -900) { this.pos[i * 3 + 1] = -999; this.size[i] = 0; } continue; }
      this.life[i] -= dt; const t = this.life[i] / this.maxLife[i];
      const d = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i * 3] *= d; this.vel[i * 3 + 1] = this.vel[i * 3 + 1] * d - this.grav[i] * dt; this.vel[i * 3 + 2] *= d;
      this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      this.size[i] = this.size0[i] * (1 + this.grow[i] * (1 - t)) * (t < 0.3 ? t / 0.3 : 1);
      this.col[i * 4 + 3] = Math.min(1, t * 2.2) * 0.9;
    }
    this.geo.attributes.position.needsUpdate = true; this.geo.attributes.aSize.needsUpdate = true; this.geo.attributes.aColor.needsUpdate = true;
  }
}

const _c = new THREE.Color();
export class Particles {
  alpha: Pool; add: Pool; group = new THREE.Group(); amount = 1;
  speedLines: THREE.LineSegments; private slPos: Float32Array; private slSpeed: Float32Array; private slN = 36; private slMat: THREE.LineBasicMaterial;
  rain: THREE.LineSegments | null = null; private rainPos: Float32Array | null = null; private rainN = 0; private rainMat: THREE.LineBasicMaterial;
  constructor(maxAlpha = 500, maxAdd = 500) {
    const tex = softDot(64);
    this.alpha = new Pool(maxAlpha, false, tex); this.add = new Pool(maxAdd, true, tex);
    this.group.add(this.alpha.points, this.add.points);
    this.slPos = new Float32Array(this.slN * 6); this.slSpeed = new Float32Array(this.slN);
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(this.slPos, 3).setUsage(THREE.DynamicDrawUsage));
    this.slMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, fog: false });
    this.speedLines = new THREE.LineSegments(g, this.slMat); this.speedLines.frustumCulled = false; this.speedLines.renderOrder = 11; this.group.add(this.speedLines);
    this.rainMat = new THREE.LineBasicMaterial({ color: 0xcfe0f2, transparent: true, opacity: 0.5, depthWrite: false, fog: false });
    for (let i = 0; i < this.slN; i++) this.respawnLine(i, true);
  }
  setScale(s: number) { (this.alpha.mat.uniforms.uScale.value = s); (this.add.mat.uniforms.uScale.value = s); }
  setRainCount(n: number) {
    if (this.rain) { this.group.remove(this.rain); this.rain.geometry.dispose(); this.rain = null; }
    this.rainN = n; if (!n) return;
    this.rainPos = new Float32Array(n * 6); const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(this.rainPos, 3).setUsage(THREE.DynamicDrawUsage));
    for (let i = 0; i < n; i++) this.respawnDrop(i, true);
    this.rain = new THREE.LineSegments(g, this.rainMat); this.rain.frustumCulled = false; this.rain.renderOrder = 12; this.rain.visible = false; this.group.add(this.rain);
  }
  private respawnLine(i: number, init = false) {
    const a = Math.random() * Math.PI * 2, r = 2.2 + Math.random() * 5;
    const x = Math.cos(a) * r, y = 1.5 + Math.sin(a) * r * 0.6, z = init ? -Math.random() * 28 : -26 - Math.random() * 4;
    this.slPos[i * 6] = x; this.slPos[i * 6 + 1] = y; this.slPos[i * 6 + 2] = z; this.slPos[i * 6 + 3] = x; this.slPos[i * 6 + 4] = y; this.slPos[i * 6 + 5] = z - 2; this.slSpeed[i] = 30 + Math.random() * 25;
  }
  private respawnDrop(i: number, init = false) {
    const p = this.rainPos!; const x = (Math.random() - 0.5) * 36, y = init ? Math.random() * 22 : 20 + Math.random() * 4, z = (Math.random() - 0.5) * 40 - 8;
    p[i * 6] = x; p[i * 6 + 1] = y; p[i * 6 + 2] = z; p[i * 6 + 3] = x - 0.08; p[i * 6 + 4] = y + 0.9; p[i * 6 + 5] = z - 0.1;
  }
  /** per frame: camera-relative effects */
  update(dt: number, cam: THREE.Vector3, speed: number, boost: number, rain: number) {
    this.alpha.update(dt); this.add.update(dt);
    // speed lines (camera-local: drawn relative to a group offset)
    const want = Math.max(0, Math.min(1, (speed - 22) / 12)) * 0.5 + boost * 0.6;
    this.slMat.opacity += (want * 0.55 - this.slMat.opacity) * Math.min(1, dt * 6);
    this.speedLines.visible = this.slMat.opacity > 0.02; this.speedLines.position.set(cam.x, cam.y - 1.2, cam.z - 3);
    if (this.speedLines.visible) {
      for (let i = 0; i < this.slN; i++) { const dz = this.slSpeed[i] * dt * (1 + boost); this.slPos[i * 6 + 2] += dz; this.slPos[i * 6 + 5] += dz; if (this.slPos[i * 6 + 2] > 6) this.respawnLine(i); this.slPos[i * 6 + 5] = this.slPos[i * 6 + 2] - (2 + boost * 3 + speed * 0.05); }
      this.speedLines.geometry.attributes.position.needsUpdate = true;
    }
    if (this.rain && this.rainPos) {
      this.rain.visible = rain > 0.02; this.rainMat.opacity = 0.55 * rain;
      if (this.rain.visible) {
        this.rain.position.set(cam.x, cam.y - 6, cam.z);
        const p = this.rainPos; const fall = 24 * dt; for (let i = 0; i < this.rainN; i++) { p[i * 6 + 1] -= fall; p[i * 6 + 4] -= fall; p[i * 6 + 2] += speed * 0.25 * dt; p[i * 6 + 5] += speed * 0.25 * dt; if (p[i * 6 + 1] < -2) this.respawnDrop(i); }
        this.rain.geometry.attributes.position.needsUpdate = true;
      }
    }
  }
  /** radial burst */
  burst(x: number, y: number, z: number, color: number, count: number, speed = 4, life = 0.6, size = 0.35, opts: { additive?: boolean; grav?: number; up?: number; spread?: number } = {}) {
    const n = Math.max(1, Math.round(count * this.amount)); _c.setHex(color); const pool = opts.additive === false ? this.alpha : this.add;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, u = Math.random() * 2 - 1, r = Math.sqrt(1 - u * u), sp = speed * (0.4 + Math.random() * 0.9), sp2 = opts.spread ?? 1;
      pool.spawn(x, y, z, Math.cos(a) * r * sp * sp2, u * sp * sp2 + (opts.up ?? 0), Math.sin(a) * r * sp * sp2, life * (0.7 + Math.random() * 0.6), size * (0.6 + Math.random() * 0.8), _c.r, _c.g, _c.b, 1, opts.grav ?? 6, 1.5);
    }
  }
  /** soft smoke puff (alpha blended) */
  puff(x: number, y: number, z: number, color: number, count = 3, size = 0.9, life = 0.9, vy = 0.8, vz = 0) {
    const n = Math.max(1, Math.round(count * this.amount)); _c.setHex(color);
    for (let i = 0; i < n; i++) this.alpha.spawn(x + (Math.random() - 0.5) * 0.3, y, z + (Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.6, vy * (0.6 + Math.random() * 0.8), vz + (Math.random() - 0.5) * 0.4, life, size * (0.7 + Math.random() * 0.6), _c.r, _c.g, _c.b, 0.55, -0.1, 1.2, 1.4);
  }
  /** moving trail point */
  trail(x: number, y: number, z: number, color: number, size = 0.3, life = 0.35) { _c.setHex(color); this.add.spawn(x, y, z, 0, 0, 0, life, size, _c.r, _c.g, _c.b, 0.8, 0, 2, -0.4); }
  ring(x: number, y: number, z: number, color: number, count = 18, radius = 0.4, speed = 5, life = 0.45, size = 0.3) {
    _c.setHex(color); const n = Math.max(6, Math.round(count * this.amount));
    for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2; this.add.spawn(x + Math.cos(a) * radius, y, z + Math.sin(a) * radius, Math.cos(a) * speed, 0.4, Math.sin(a) * speed, life, size, _c.r, _c.g, _c.b, 1, 0, 3, -0.3); }
  }
  dispose() { this.alpha.geo.dispose(); this.add.geo.dispose(); this.alpha.mat.dispose(); this.add.mat.dispose(); }
}
