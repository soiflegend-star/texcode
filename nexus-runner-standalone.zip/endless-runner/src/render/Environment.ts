/**
 * Environment — sky dome, cloud layer, horizon skyline, fog, light rig, time-of-day and weather blending,
 * reflection probe. All region/event "looks" are described by `Theme` records that are blended smoothly,
 * so crossing a region boundary or starting a sunset never pops.
 */
import * as THREE from "three";
import { QualitySettings, REGIONS } from "../data/GameData.js";
import { Atmosphere } from "../events/EventDirector.js";
import { cloudTexture, skylineTexture } from "./Textures.js";
import { clamp, lerp } from "../util/rng.js";

export interface Theme {
  skyTop: number; skyHorizon: number; skyBottom: number; fog: number; fogNear: number; fogFarMul: number;
  sun: number; sunI: number; sunElev: number; sunAz: number;
  hemiSky: number; hemiGround: number; hemiI: number; exposure: number; env: number;
  skyline: "city" | "highway" | "industrial" | "ruins" | "none"; skylineOpacity: number; cloudOpacity: number; enclosed: number; headlight: number;
}
export const THEMES: Theme[] = [
  // 0 Neon Rooftops (bright day)
  { skyTop: 0x3f8fe0, skyHorizon: 0xcfe7f7, skyBottom: 0xaac4d8, fog: 0xbdd9ec, fogNear: 30, fogFarMul: 1, sun: 0xfff0d2, sunI: 2.9, sunElev: 0.95, sunAz: 0.6, hemiSky: 0xcfe6ff, hemiGround: 0x8d9298, hemiI: 1.0, exposure: 1.0, env: 0.9, skyline: "city", skylineOpacity: 0.95, cloudOpacity: 0.95, enclosed: 0, headlight: 0 },
  // 1 Sky Highway
  { skyTop: 0x2f7fd8, skyHorizon: 0xc5e0f4, skyBottom: 0xa5bfd4, fog: 0xb4d2e8, fogNear: 35, fogFarMul: 1.05, sun: 0xffeccc, sunI: 3.0, sunElev: 0.85, sunAz: 0.4, hemiSky: 0xc7e1fa, hemiGround: 0x7d858c, hemiI: 1.0, exposure: 1.02, env: 0.95, skyline: "highway", skylineOpacity: 0.9, cloudOpacity: 1, enclosed: 0, headlight: 0 },
  // 2 Subway Tunnels (enclosed, bright tube lighting)
  { skyTop: 0x16202e, skyHorizon: 0x26384a, skyBottom: 0x121a24, fog: 0x1f2c3a, fogNear: 14, fogFarMul: 0.42, sun: 0xcfe6ff, sunI: 0.0, sunElev: 1.2, sunAz: 0, hemiSky: 0xd6e6f2, hemiGround: 0x586470, hemiI: 1.75, exposure: 1.12, env: 0.35, skyline: "none", skylineOpacity: 0, cloudOpacity: 0, enclosed: 1, headlight: 1 },
  // 3 Industrial Zone (warm afternoon haze)
  { skyTop: 0x7d9bb8, skyHorizon: 0xf0cfa0, skyBottom: 0xb9a58a, fog: 0xd9bf9b, fogNear: 28, fogFarMul: 0.9, sun: 0xffc27a, sunI: 2.7, sunElev: 0.5, sunAz: 0.9, hemiSky: 0xf2dcc0, hemiGround: 0x6d6258, hemiI: 1.0, exposure: 1.0, env: 0.8, skyline: "industrial", skylineOpacity: 0.9, cloudOpacity: 0.8, enclosed: 0, headlight: 0 },
  // 4 Overgrown Ruins (misty green)
  { skyTop: 0x5ea8e0, skyHorizon: 0xe2f1d6, skyBottom: 0xa9c4a0, fog: 0xc6ddc0, fogNear: 22, fogFarMul: 0.85, sun: 0xfff3c4, sunI: 2.5, sunElev: 0.8, sunAz: 0.2, hemiSky: 0xd8ecd0, hemiGround: 0x4c6a3c, hemiI: 1.05, exposure: 1.0, env: 0.9, skyline: "ruins", skylineOpacity: 0.9, cloudOpacity: 0.9, enclosed: 0, headlight: 0 },
];
const NIGHT: Partial<Theme> = { skyTop: 0x070d24, skyHorizon: 0x1b2a56, skyBottom: 0x0a1226, fog: 0x121c3a, sun: 0x8fa8e8, sunI: 0.75, sunElev: 0.9, hemiSky: 0x5b73b8, hemiGround: 0x1f2740, hemiI: 0.62, exposure: 1.05, env: 0.35, cloudOpacity: 0.15 };
const DUSK: Partial<Theme> = { skyTop: 0x4a5fa8, skyHorizon: 0xffa65c, skyBottom: 0xc9805a, fog: 0xe8b08a, sun: 0xff9a4d, sunI: 2.6, sunElev: 0.2, sunAz: 0.35, hemiSky: 0xffc89a, hemiGround: 0x6b5048, hemiI: 0.95, exposure: 1.05, env: 0.7 };
const STORM: Partial<Theme> = { skyTop: 0x4a5668, skyHorizon: 0x8a96a4, skyBottom: 0x6c7886, fog: 0x7e8a98, sunI: 0.9, hemiI: 0.9, hemiSky: 0xaab6c4, exposure: 0.95, cloudOpacity: 1 };

const _ca = new THREE.Color(), _cb = new THREE.Color();
function lerpHex(a: number, b: number, t: number, out: THREE.Color) { _ca.setHex(a); _cb.setHex(b); out.copy(_ca).lerp(_cb, t); return out; }

export function blendTheme(a: Theme, b: Theme, t: number): Theme {
  const c = (x: number, y: number) => lerpHex(x, y, t, new THREE.Color()).getHex();
  const n = (x: number, y: number) => lerp(x, y, t);
  return {
    skyTop: c(a.skyTop, b.skyTop), skyHorizon: c(a.skyHorizon, b.skyHorizon), skyBottom: c(a.skyBottom, b.skyBottom), fog: c(a.fog, b.fog), fogNear: n(a.fogNear, b.fogNear), fogFarMul: n(a.fogFarMul, b.fogFarMul),
    sun: c(a.sun, b.sun), sunI: n(a.sunI, b.sunI), sunElev: n(a.sunElev, b.sunElev), sunAz: n(a.sunAz, b.sunAz), hemiSky: c(a.hemiSky, b.hemiSky), hemiGround: c(a.hemiGround, b.hemiGround),
    hemiI: n(a.hemiI, b.hemiI), exposure: n(a.exposure, b.exposure), env: n(a.env, b.env), skyline: t < 0.5 ? a.skyline : b.skyline,
    skylineOpacity: n(a.skylineOpacity, b.skylineOpacity), cloudOpacity: n(a.cloudOpacity, b.cloudOpacity), enclosed: n(a.enclosed, b.enclosed), headlight: n(a.headlight, b.headlight),
  };
}
function mixPartial(base: Theme, over: Partial<Theme>, t: number): Theme { if (t <= 0.001) return base; return blendTheme(base, { ...base, ...over } as Theme, clamp(t, 0, 1)); }

/** Region theme at a distance (smoothly blended across the physical transition piece) + atmosphere overlays. */
export function themeAt(distance: number, atm: Atmosphere): Theme {
  const seg = Math.floor(Math.max(0, distance) / 960);
  const into = distance - seg * 960;
  const cur = THEMES[seg % REGIONS.length], nxt = THEMES[(seg + 1) % REGIONS.length];
  const blendStart = 960 - 130, blendEnd = 960 + 20;
  let t = 0; let base = cur;
  if (into > blendStart) { t = clamp((into - blendStart) / (blendEnd - blendStart), 0, 1); base = blendTheme(cur, nxt, t * t * (3 - 2 * t)); }
  else if (into < 20 && seg > 0) { const prev = THEMES[(seg - 1) % REGIONS.length]; const tt = clamp((into + 130) / 150, 0, 1); base = blendTheme(prev, cur, tt * tt * (3 - 2 * tt)); }
  const enclosedAmt = base.enclosed;   // tunnels ignore time of day (no sky)
  let th = mixPartial(base, STORM, atm.storm * (1 - enclosedAmt));
  th = mixPartial(th, DUSK, atm.dusk * (1 - enclosedAmt));
  th = mixPartial(th, NIGHT, atm.night * (1 - enclosedAmt * 0.85));
  th.fogFarMul *= clamp(atm.fogMul, 0.2, 1.2);
  if (atm.fogMul < 0.95) { th.fog = lerpHex(th.fog, 0xc9d2da, (1 - atm.fogMul) * 0.7 * (1 - atm.night), new THREE.Color()).getHex(); }
  return th;
}

// ───────────────────────── Sky dome ─────────────────────────
const SKY_VS = `varying vec3 vDir; void main(){ vDir = normalize(position); vec4 p = modelViewMatrix * vec4(position,1.0); gl_Position = projectionMatrix * p; }`;
const SKY_FS = `
uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uBottom; uniform vec3 uSunDir; uniform vec3 uSunColor; uniform float uNight; uniform float uEnclosed;
varying vec3 vDir;
float hash(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
void main(){
  vec3 d = normalize(vDir);
  float h = clamp(d.y, -0.25, 1.0);
  float t = pow(max(h, 0.0), 0.5);
  vec3 col = mix(uHorizon, uTop, t);
  col = mix(col, uBottom, smoothstep(0.0, -0.25, d.y));
  float sd = max(dot(d, normalize(uSunDir)), 0.0);
  col += uSunColor * (pow(sd, 700.0) * 4.0 + pow(sd, 28.0) * 0.30 + pow(sd, 5.0) * 0.07) * (1.0 - uEnclosed);
  vec3 sp = floor(d * 260.0);
  float star = step(0.9965, hash(sp)) * smoothstep(0.08, 0.4, d.y);
  col += vec3(star) * uNight;
  gl_FragColor = vec4(col, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

export class Environment {
  scene: THREE.Scene; renderer: THREE.WebGLRenderer; q: QualitySettings;
  sky: THREE.Mesh; skyMat: THREE.ShaderMaterial;
  hemi: THREE.HemisphereLight; sun: THREE.DirectionalLight; fill: THREE.DirectionalLight; headlight: THREE.PointLight;
  clouds: THREE.Sprite[] = []; private cloudAng: number[] = [];
  backdrop: THREE.Mesh; private backdropMat: THREE.MeshBasicMaterial; private skylineTex = new Map<string, THREE.Texture>();
  fog: THREE.Fog;
  theme: Theme = THEMES[0];
  private pmrem: THREE.PMREMGenerator | null = null; private envRT: THREE.WebGLRenderTarget | null = null; private envScene: THREE.Scene | null = null; private envSkyMat: THREE.ShaderMaterial | null = null;
  private lastEnvTime = -99; private lastEnvKey = ""; private lightningBoost = 0;
  private fogColor = new THREE.Color();

  constructor(scene: THREE.Scene, renderer: THREE.WebGLRenderer, q: QualitySettings) {
    this.scene = scene; this.renderer = renderer; this.q = q;
    this.fog = new THREE.Fog(0xbdd9ec, 30, 380); scene.fog = this.fog;

    this.skyMat = new THREE.ShaderMaterial({
      vertexShader: SKY_VS, fragmentShader: SKY_FS, side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false,
      uniforms: { uTop: { value: new THREE.Color() }, uHorizon: { value: new THREE.Color() }, uBottom: { value: new THREE.Color() }, uSunDir: { value: new THREE.Vector3(0.3, 0.8, -0.5) }, uSunColor: { value: new THREE.Color() }, uNight: { value: 0 }, uEnclosed: { value: 0 } },
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(900, 24, 16), this.skyMat); this.sky.renderOrder = -100; this.sky.frustumCulled = false; this.sky.name = "sky"; scene.add(this.sky);

    // Skyline backdrop
    this.backdropMat = new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, fog: false, side: THREE.BackSide, opacity: 1 });
    this.backdrop = new THREE.Mesh(new THREE.CylinderGeometry(560, 560, 200, 40, 1, true), this.backdropMat);
    this.backdrop.position.y = 52; this.backdrop.renderOrder = -90; this.backdrop.frustumCulled = false; this.backdrop.name = "skyline"; scene.add(this.backdrop);

    // Clouds
    const n = q.clouds; const tex = [cloudTexture(1), cloudTexture(2), cloudTexture(3)];
    for (let i = 0; i < n; i++) {
      const m = new THREE.SpriteMaterial({ map: tex[i % 3], transparent: true, depthWrite: false, fog: false, opacity: 0.9, color: 0xffffff });
      const s = new THREE.Sprite(m); const ang = (i / n) * Math.PI * 2 + 0.4; const r = 520 + (i % 3) * 30; const y = 110 + (i % 4) * 34;
      s.position.set(Math.sin(ang) * r, y, -Math.cos(ang) * r * 0.9 - 60); s.scale.set(260 + (i % 3) * 70, 110 + (i % 2) * 30, 1); s.renderOrder = -80; scene.add(s); this.clouds.push(s); this.cloudAng.push(ang);
    }

    // Lights. NOTE: three r155+ uses physical light units → sun ≈ 3, hemisphere ≈ 1.
    this.hemi = new THREE.HemisphereLight(0xcfe6ff, 0x8d9298, 1.0); scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff0d2, 2.9); this.sun.position.set(-18, 34, 16); this.sun.target.position.set(0, 0, -8); scene.add(this.sun); scene.add(this.sun.target);
    this.fill = new THREE.DirectionalLight(0xbcd8ff, 0.35); this.fill.position.set(8, 6, 20); scene.add(this.fill);
    this.headlight = new THREE.PointLight(0xfff2d8, 0, 38, 1.6); this.headlight.position.set(0, 3.2, 3); scene.add(this.headlight);
    this.applyShadowQuality();
    this.setupEnvProbe();
    this.applyTheme(THEMES[0], 0, true);
  }

  applyShadowQuality() {
    const q = this.q;
    this.renderer.shadowMap.enabled = q.shadows;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.sun.castShadow = q.shadows;
    if (q.shadows) {
      const s = this.sun.shadow; s.mapSize.set(q.shadowMap, q.shadowMap);
      const c = s.camera as THREE.OrthographicCamera; c.left = -15; c.right = 15; c.top = 30; c.bottom = -22; c.near = 1; c.far = 110; c.updateProjectionMatrix();
      s.bias = -0.0004; s.normalBias = 0.04; s.radius = 3;
      if (s.map) { (s.map as any).dispose?.(); (s as any).map = null; }
    }
  }

  setQuality(q: QualitySettings) {
    this.q = q; this.applyShadowQuality();
    this.clouds.forEach((c, i) => { c.visible = i < q.clouds; });
    if (!q.envReflections) { this.scene.environment = null; } else this.lastEnvTime = -99;
  }

  private setupEnvProbe() {
    if (!this.q.envReflections) return;
    try {
      this.pmrem = new THREE.PMREMGenerator(this.renderer);
      this.envScene = new THREE.Scene();
      this.envSkyMat = this.skyMat.clone(); this.envSkyMat!.uniforms = THREE.UniformsUtils.clone(this.skyMat.uniforms);
      const m = new THREE.Mesh(new THREE.SphereGeometry(50, 16, 12), this.envSkyMat); this.envScene.add(m);
    } catch { this.pmrem = null; }
  }

  /** Re-bake the reflection probe (throttled — PMREM generation is not free). */
  refreshProbe(time: number, key: string, force = false) {
    if (!this.pmrem || !this.envScene || !this.envSkyMat || !this.q.envReflections) return;
    if (!force && (time - this.lastEnvTime < 6 || key === this.lastEnvKey)) return;
    this.lastEnvTime = time; this.lastEnvKey = key;
    try {
      for (const k of Object.keys(this.skyMat.uniforms)) { const a = this.skyMat.uniforms[k].value, b = this.envSkyMat.uniforms[k].value; if (a && a.isColor) b.copy(a); else if (a && a.isVector3) b.copy(a); else this.envSkyMat.uniforms[k].value = a; }
      const rt = this.pmrem.fromScene(this.envScene, 0.03);
      this.envRT?.dispose(); this.envRT = rt; this.scene.environment = rt.texture;
    } catch { this.scene.environment = null; }
  }

  private skylineFor(kind: Theme["skyline"], fogHex: number): void {
    if (kind === "none") { this.backdropMat.opacity = 0; this.backdrop.visible = false; return; }
    this.backdrop.visible = true;
    const key = kind; let tex = this.skylineTex.get(key);
    if (!tex) { tex = skylineTexture(kind, "#ffffff"); tex.repeat.set(2, 1); this.skylineTex.set(key, tex); }
    if (this.backdropMat.map !== tex) { this.backdropMat.map = tex; this.backdropMat.needsUpdate = true; }
  }

  /** Apply a (blended) theme to every lighting / fog / sky parameter. */
  applyTheme(t: Theme, lightning: number, instant = false) {
    this.theme = t;
    const u = this.skyMat.uniforms;
    (u.uTop.value as THREE.Color).setHex(t.skyTop); (u.uHorizon.value as THREE.Color).setHex(t.skyHorizon); (u.uBottom.value as THREE.Color).setHex(t.skyBottom);
    (u.uSunColor.value as THREE.Color).setHex(t.sun).multiplyScalar(0.8); u.uEnclosed.value = t.enclosed;
    // sun direction: elevation (0..1 ≈ 0..~80°) and azimuth
    const el = clamp(t.sunElev, 0.05, 1.2) * 1.2, az = t.sunAz;
    const dir = new THREE.Vector3(-Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el) * -1);
    // light comes from behind-left of the player towards the horizon so shadows fall forward-right
    dir.set(-Math.sin(az) * 0.9, Math.sin(el), Math.cos(az) * 0.7).normalize();
    this.sun.position.copy(dir).multiplyScalar(48).add(this.sun.target.position);
    (u.uSunDir.value as THREE.Vector3).set(dir.x, dir.y, -dir.z * 1.2).normalize();
    const flash = lightning;
    this.sun.color.setHex(t.sun); this.sun.intensity = t.sunI + flash * 3.5;
    this.sun.castShadow = this.q.shadows && t.sunI > 0.2;
    this.hemi.color.setHex(t.hemiSky); this.hemi.groundColor.setHex(t.hemiGround); this.hemi.intensity = t.hemiI * (this.scene.environment ? 0.62 : 1) + flash * 1.4;
    this.fill.intensity = 0.28 + t.enclosed * 0.25;
    this.headlight.intensity = t.headlight * 38;
    this.renderer.toneMappingExposure = t.exposure;
    (this.scene as any).environmentIntensity = t.env;
    this.fog.color.setHex(t.fog); if (flash > 0) this.fog.color.lerp(new THREE.Color(0xffffff), flash * 0.35);
    this.fog.near = t.fogNear; this.fog.far = Math.max(t.fogNear + 40, this.q.fogFar * t.fogFarMul);
    this.fogColor.copy(this.fog.color);
    this.scene.background = null;
    this.renderer.setClearColor(this.fog.color);
    // skyline + clouds tinted by the fog so they sit "in" the atmosphere
    this.skylineFor(t.skyline, t.fog);
    this.backdropMat.color.copy(this.fogColor).multiplyScalar(0.78).lerp(new THREE.Color(t.skyTop), 0.18);
    this.backdropMat.opacity = t.skylineOpacity;
    for (const c of this.clouds) { const m = c.material as THREE.SpriteMaterial; m.opacity = t.cloudOpacity * 0.92; m.color.copy(this.fogColor).lerp(new THREE.Color(0xffffff), 0.55 * (1 - Math.min(1, (1 - t.sunI / 3) * 0.9))); }
  }

  /** Per frame: keep dome/backdrop/clouds centred on the camera and drift the clouds. */
  follow(camera: THREE.Camera, dt: number, speed: number) {
    const p = camera.position;
    this.sky.position.copy(p); this.backdrop.position.x = p.x; this.backdrop.position.z = p.z;
    for (let i = 0; i < this.clouds.length; i++) {
      this.cloudAng[i] += dt * 0.004 * (1 + (i % 3) * 0.4);
      const a = this.cloudAng[i]; const r = 520 + (i % 3) * 30;
      this.clouds[i].position.set(p.x + Math.sin(a) * r, 110 + (i % 4) * 34, p.z - Math.cos(a) * r * 0.9);
    }
    // keep shadow rig centred on the (fixed) player zone
    this.sun.target.position.set(0, 0, -8);
  }

  dispose() { this.envRT?.dispose(); this.pmrem?.dispose(); this.skyMat.dispose(); for (const t of this.skylineTex.values()) t.dispose(); }
}
