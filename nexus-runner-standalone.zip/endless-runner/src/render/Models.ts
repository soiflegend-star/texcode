/**
 * Models — procedural models for every obstacle type, the seven power-ups, rails and boost pads.
 * Obstacle models are centred on x/z, with y=0 at the obstacle's bottom edge, facing the player (+z side).
 * Coins are rendered as one InstancedMesh by Scene3D (see makeCoinMesh).
 */
import * as THREE from "three";
import { OBSTACLES, POWERUPS, PowerUpId } from "../data/GameData.js";
import { makeRng } from "../util/rng.js";
import { ChunkCtx, G, PAL } from "./Props.js";
import { mat } from "./Batch.js";
import type { MaterialLibrary } from "./Materials.js";
import { coinTexture, softDot } from "./Textures.js";

export interface ModelAnim { kind: "rotor" | "bob" | "spin" | "blink" | "sway"; node: THREE.Object3D; speed: number; amp?: number }
export interface ObstacleModel { group: THREE.Group; anims: ModelAnim[]; broken?: boolean }

const STRIPE = [0xff6a1a, 0xf4f4f4];
function hazardStripes(c: ChunkCtx, x: number, y: number, z: number, w: number, h: number, d: number) {
  const n = Math.max(2, Math.round(w / 0.28));
  for (let i = 0; i < n; i++) c.box("paint", w / n, h, d, x - w / 2 + (i + 0.5) * (w / n), y, z, STRIPE[i % 2]);
}
function wheels(c: ChunkCtx, w: number, d: number, r: number, zs: number[]) {
  for (const z of zs) for (const s of [-1, 1]) c.b.add("rubber", G.cyl(r, r, 0.22, 12), mat(s * (w / 2 - 0.05), r, z, 0, 0, Math.PI / 2), { color: 0x1d1f23 });
}

export function buildObstacle(type: string, lib: MaterialLibrary): ObstacleModel {
  const def = OBSTACLES[type]; if (!def) throw new Error("unknown obstacle " + type);
  const rng = makeRng("obs:" + type); const c = new ChunkCtx(rng, lib);
  const anims: ModelAnim[] = []; const W = def.w, H = def.h, D = def.d, Y = 0;
  const hw = W / 2;
  const posts = (y0: number, h: number, ex = 0.12) => { for (const s of [-1, 1]) c.box("metal", 0.14, y0 + h, 0.14, s * (hw + ex), 0, 0, 0x7e868d, { ao: 0.5 }); };
  switch (type) {
    case "barricade": case "construction_barrier": {
      for (const s of [-1, 1]) { c.box("metal", 0.1, H, 0.55, s * (hw - 0.2), 0, 0, 0xcfd3d6); c.box("metal", 0.1, 0.1, 0.9, s * (hw - 0.2), 0, 0, 0xcfd3d6); }
      for (let i = 0; i < 2; i++) hazardStripes(c, 0, 0.3 + i * 0.4, 0, W - 0.1, 0.3, 0.08);
      c.box("emissive", 0.14, 0.08, 0.14, -hw + 0.2, H, 0, 0xff3d2e); c.box("emissive", 0.14, 0.08, 0.14, hw - 0.2, H, 0, 0xff3d2e);
      if (type === "construction_barrier") c.sign({ text: "DETOUR", bg: "#f2c230", fg: "#111", w: 0.9, h: 0.35, x: 0, y: H * 0.3, z: 0.06, ry: 0 });
      break;
    }
    case "jersey_barrier": c.box("concrete", W, H, D, 0, 0, 0, 0xc9c5ba, { tile: 2, ao: 0.4 }); c.box("concrete", W, 0.2, D + 0.2, 0, 0, 0, 0xb8b4a9); hazardStripes(c, 0, H - 0.25, D / 2 + 0.005, W - 0.2, 0.18, 0.01); break;
    case "crate": case "crate_stack": {
      const n = type === "crate" ? 1 : 2; const cw = W * 0.92;
      for (let i = 0; i < n; i++) { const h = H / n; c.box("paint", cw, h - 0.02, D * 0.95, i === 1 ? 0.06 : 0, i * h, 0, i === 1 ? 0xb8864f : 0xc79556, { ry: i * 0.12, ao: 0.4 }); for (const dx of [-1, 1]) c.box("paint", 0.09, h, D * 0.97, dx * cw * 0.45, i * h, 0, 0x7a5430, { ry: i * 0.12 }); c.box("paint", cw, 0.09, D * 0.97, 0, i * h + h * 0.45, 0, 0x7a5430, { ry: i * 0.12 }); c.box("paint", cw, 0.09, D * 0.97, 0, i * h + 0.02, 0, 0x7a5430, { ry: i * 0.12 }); }
      if (type === "crate_stack") { c.box("paint", 0.9, 0.5, 0.04, 0, 0.4, D * 0.5, 0xf4f1e4); c.box("paint", 0.7, 0.08, 0.05, 0, 0.55, D * 0.5 + 0.01, 0xc23b2f); }
      break;
    }
    case "roadblock": { c.box("concrete", W, H * 0.45, D, 0, 0, 0, 0xcfcac0, { tile: 2 }); c.box("concrete", W * 0.9, H * 0.55, D * 0.6, 0, H * 0.45, 0, 0xb7b3a8, { tile: 2 }); hazardStripes(c, 0, H * 0.18, D / 2 + 0.005, W - 0.1, 0.3, 0.01); c.box("emissive", 0.2, 0.2, 0.2, 0, H, 0, 0xff3d2e); break; }
    case "low_beam": case "steel_beam": case "pipe_low": case "vine_bar": {
      posts(Y, def.y + H);
      if (type === "low_beam") { c.box("metal", W, H, D, 0, def.y, 0, 0x4a5a6a, { ao: 0.2 }); hazardStripes(c, 0, def.y + 0.08, D / 2 + 0.005, W - 0.2, H - 0.16, 0.01); }
      else if (type === "steel_beam") { c.box("metal", W, 0.12, D, 0, def.y, 0, 0x6c7b88); c.box("metal", W, 0.12, D, 0, def.y + H - 0.12, 0, 0x6c7b88); c.box("metal", W, H - 0.2, 0.12, 0, def.y + 0.1, 0, 0x6c7b88); hazardStripes(c, 0, def.y, D / 2 + 0.01, W, 0.14, 0.01); }
      else if (type === "pipe_low") { c.pipe("metal", H / 2, W + 0.2, 0, def.y + H / 2, 0, 0xb04a2a, "x", 12); for (const x of [-hw + 0.3, hw - 0.3]) c.pipe("metal", H / 2 + 0.05, 0.12, x, def.y + H / 2, 0, 0x888d92, "x", 12); }
      else { c.box("paint", W, 0.1, 0.12, 0, def.y + H - 0.1, 0, 0x5a4630); for (let i = 0; i < 9; i++) c.box("foliage", 0.08, 0.5 + (i % 3) * 0.15, 0.08, -hw + 0.15 + i * (W - 0.3) / 8, def.y + H - 0.55 - (i % 3) * 0.12, 0.0, PAL.foliage[i % 5]); for (let i = 0; i < 5; i++) c.sphere("foliage", 0.18, -hw + 0.2 + i * (W - 0.4) / 4, def.y + H - 0.1, 0, PAL.foliage[(i + 2) % 5], 1, 0.6, 1, { ws: 6, hs: 4 }); }
      break;
    }
    case "overhead_sign": {
      for (const s of [-1, 1]) c.box("metal", 0.3, def.y + H, 0.3, s * (hw - 0.1), 0, 0, 0x7e868d);
      c.box("metal", W, H, 0.22, 0, def.y, 0, 0x2a5a8a); c.sign({ text: "CAUTION  LOW CLEARANCE", bg: "#f2c230", fg: "#111", sub: "SLIDE UNDER", w: W - 0.4, h: H - 0.25, x: 0, y: def.y + H / 2, z: 0.13, ry: 0 });
      break;
    }
    case "drone": {
      c.box("metal", 0.7, 0.2, 0.7, 0, def.y + 0.25, 0, 0x2f3841, { ao: 0.5 }); c.sphere("metal", 0.22, 0, def.y + 0.2, 0.0, 0x3d4955); c.box("emissive", 0.3, 0.07, 0.3, 0, def.y + 0.18, 0.28, 0xff3a2e);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) { c.box("metal", 0.5, 0.05, 0.05, sx * 0.4, def.y + 0.3, sz * 0.4, 0x2a3138, { ry: sx * sz * Math.PI / 4 }); }
      const rotors = new THREE.Group(); const rm = new THREE.MeshBasicMaterial({ color: 0xcfd8e0, transparent: true, opacity: 0.35, side: THREE.DoubleSide, depthWrite: false });
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const r = new THREE.Mesh(new THREE.CircleGeometry(0.3, 14), rm); r.rotation.x = -Math.PI / 2; r.position.set(sx * 0.58, def.y + 0.37, sz * 0.58); rotors.add(r); }
      anims.push({ kind: "bob", node: rotors, speed: 3, amp: 0.05 }); const g = c.b.build(lib); g.add(rotors); return finish(g, c, anims, W, H, D, def.y);
    }
    case "hvac_unit": c.box("metal", W, H, D, 0, 0, 0, 0xb5bcc2, { ao: 0.5 }); c.box("metal", W * 0.9, 0.1, D * 0.9, 0, H, 0, 0x8d949b); for (let i = 0; i < 5; i++) c.box("metal", W * 0.8, 0.04, 0.02, 0, 0.35 + i * 0.22, D / 2 + 0.005, 0x4a5058); c.cyl("metal", 0.5, 0.18, 0, H + 0.08, 0, 0x2f353b, { seg: 16 }); break;
    case "car": case "van": case "truck": {
      const col = pickColor(rng); const cab = type === "truck";
      if (type === "car") { c.box("paint", W, 0.55, D, 0, 0.32, 0, col, { ao: 0.3 }); c.box("paint", W * 0.86, 0.5, D * 0.5, 0, 0.87, D * -0.05, col); c.box("glass", W * 0.88, 0.42, D * 0.48, 0, 0.88, D * -0.05, 0x2a3a4a); wheels(c, W, D, 0.34, [-D * 0.3, D * 0.3]); }
      else if (type === "van") { c.box("paint", W, H * 0.7, D, 0, 0.35, 0, 0xf2f2ee, { ao: 0.3 }); c.box("paint", W * 0.94, H * 0.3, D * 0.3, 0, 0.35 + H * 0.7 - 0.05, D * -0.3, 0xf2f2ee); c.box("glass", W * 0.9, 0.5, 0.05, 0, 1.5, -D / 2 + 0.05, 0x2a3a4a); c.box("paint", W * 0.98, 0.18, D * 0.98, 0, 0.9, 0, col); wheels(c, W, D, 0.36, [-D * 0.3, D * 0.3]); }
      else { c.box("paint", W, 0.35, D, 0, 0.45, 0, 0x3a3f45); c.box("paint", W, H - 0.8, D * 0.72, 0, 0.8, D * 0.14, 0xe8e6de, { ao: 0.5 }); c.box("paint", W * 0.96, 1.9, D * 0.2, 0, 0.8, -D * 0.4, col); c.box("glass", W * 0.9, 0.7, 0.05, 0, 1.55, -D / 2 - 0.01, 0x2a3a4a); wheels(c, W, D, 0.5, [-D * 0.38, D * 0.15, D * 0.38]); }
      void cab; c.box("emissive", 0.3, 0.12, 0.05, -hw * 0.6, 0.55, D / 2 + 0.01, 0xff3d2e); c.box("emissive", 0.3, 0.12, 0.05, hw * 0.6, 0.55, D / 2 + 0.01, 0xff3d2e);
      break;
    }
    case "container": c.b.add("corrugated", G.box(W, H, D, 2), mat(0, H / 2, 0), { color: pickColor(rng), aoHeight: 0.6 }); c.box("metal", 0.1, H, 0.1, hw, 0, D / 2, 0x3a3f44); c.box("metal", 0.1, H, 0.1, -hw, 0, D / 2, 0x3a3f44); c.box("metal", W, 0.1, D, 0, H, 0, 0x3a3f44); break;
    case "forklift": c.box("paint", W * 0.9, 0.7, D * 0.7, 0, 0.3, D * 0.1, 0xe5a423); c.box("paint", W * 0.8, 0.14, D * 0.5, 0, 1.8, D * 0.05, 0x2f353b); for (const s of [-1, 1]) c.box("metal", 0.1, 1.6, 0.1, s * W * 0.38, 0.5, D * 0.28, 0x2f353b); c.box("metal", 0.08, 2.2, 0.06, 0.3, 0, -D * 0.4, 0x3a3f44); c.box("metal", 0.08, 2.2, 0.06, -0.3, 0, -D * 0.4, 0x3a3f44); c.box("metal", 1.1, 0.06, 1.0, 0, 0.1, -D * 0.5 - 0.3, 0x3a3f44); c.box("paint", 0.9, 0.5, 0.6, 0, 0.3, -D * 0.5 - 0.3, 0xc79556); wheels(c, W, D, 0.32, [D * 0.3, -D * 0.2]); c.box("emissive", 0.18, 0.1, 0.18, 0, 1.95, 0, 0xffa31a); break;
    case "train": {
      c.box("metal", W, H - 0.4, D, 0, 0.4, 0, 0xd5dbe0, { ao: 0.5 }); c.box("paint", W + 0.02, 0.35, D, 0, 1.0, 0, 0x1d6fa5); c.box("metal", W - 0.2, 0.2, D, 0, H - 0.2, 0, 0x8d949b);
      for (let z = -D / 2 + 1.6; z < D / 2 - 1; z += 3.2) for (const s of [-1, 1]) c.box("glass", 0.06, 0.8, 1.4, s * (hw + 0.005), 1.6, z, 0x2a3a4a);
      c.box("glass", W * 0.8, 1.0, 0.05, 0, 2.0, D / 2 + 0.01, 0x2a3a4a); c.box("emissive", 0.4, 0.22, 0.06, -0.7, 0.75, D / 2 + 0.02, 0xfff4cf); c.box("emissive", 0.4, 0.22, 0.06, 0.7, 0.75, D / 2 + 0.02, 0xfff4cf); c.box("paint", 0.14, 0.14, 0.05, 0, 0.5, D / 2 + 0.02, 0xc9382d);
      break;
    }
    case "bench": c.box("paint", W, 0.1, 0.5, 0, 0.45, 0, 0x8c6a46); c.box("paint", W, 0.4, 0.08, 0, 0.5, 0.25, 0x8c6a46); for (const s of [-1, 1]) c.box("metal", 0.1, 0.46, 0.5, s * (hw - 0.15), 0, 0, 0x3a3f44); c.box("paint", W, 0.3, 0.06, 0, 0.6, 0.3, 0x8c6a46); break;
    case "cart": c.box("metal", 1.3, 0.12, 0.9, 0, 0.3, 0, 0x6c7b88); for (const s of [-1, 1]) { c.box("metal", 0.06, 0.7, 0.9, s * 0.62, 0.3, 0, 0x8d949b); } c.box("metal", 1.3, 0.06, 0.06, 0, 1.0, 0.45, 0x8d949b); c.box("paint", 1.0, 0.5, 0.7, 0, 0.42, 0, 0xc79556); wheels(c, 1.3, 0.9, 0.12, [-0.35, 0.35]); break;
    case "turnstile": for (const s of [-1, 1]) c.box("metal", 0.4, 1.0, 0.7, s * (hw - 0.2), 0, 0, 0x8d949b); c.box("emissive", 0.3, 0.06, 0.05, -hw + 0.2, 0.95, 0.36, 0xff3d2e); c.box("metal", W - 0.8, 0.07, 0.07, 0, 0.9, 0, 0xd5dbe0); c.box("metal", 0.07, 0.7, 0.07, 0, 0.3, 0, 0xd5dbe0); break;
    case "fallen_log": c.b.add("paint", G.cyl(0.46, 0.5, W, 10), mat(0, 0.48, 0, 0, 0, Math.PI / 2), { color: 0x6a4a32 }); for (let i = 0; i < 3; i++) c.sphere("foliage", 0.3, (i - 1) * 0.6, 0.85, 0.1, PAL.foliage[i], 1, 0.7, 1, { ws: 6, hs: 4 }); c.b.add("paint", G.cyl(0.4, 0.4, 0.04, 10), mat(hw, 0.48, 0, 0, 0, Math.PI / 2), { color: 0xc9a173 }); break;
    case "rock": for (let i = 0; i < 3; i++) c.ico("stone", 0.7 - i * 0.12, (i - 1) * 0.5, 0.6 - i * 0.1, 0, 0x8f8b7f - i * 0x0a0a0a, 1.2, 1.15, 1.0, i * 1.2, 1); c.sphere("foliage", 0.5, 0.3, 1.5, 0, PAL.foliage[1], 1.4, 0.35, 1, { ws: 6, hs: 4 }); break;
    case "ruined_wall": c.box("stone", W, H * 0.7, D, 0, 0, 0, 0xb4ae9e, { tile: 2, ao: 0.6 }); c.box("stone", W * 0.55, H * 0.3, D * 0.9, -0.3, H * 0.7, 0, 0xa8a291, { tile: 2 }); c.box("stone", W * 0.3, H * 0.18, D * 0.8, 0.5, H * 0.7, 0, 0xa8a291, { rz: 0.2 }); for (let i = 0; i < 4; i++) c.sphere("foliage", 0.22, -hw + 0.3 + i * 0.5, H * 0.9, D / 2, PAL.foliage[i], 1.3, 0.6, 0.8, { ws: 6, hs: 4 }); break;
    case "moving_barrier": c.box("metal", W, H, D, 0, 0, 0, 0x2f353b); hazardStripes(c, 0, 0.2, D / 2 + 0.005, W - 0.1, 0.4, 0.01); hazardStripes(c, 0, H - 0.6, D / 2 + 0.005, W - 0.1, 0.4, 0.01); c.box("emissive", 0.4, 0.1, 0.1, 0, H + 0.02, 0, 0xff3d2e); for (const s of [-1, 1]) c.box("emissive", 0.1, 0.35, 0.05, s * (hw - 0.15), 0.7, D / 2 + 0.01, 0xffb23a); break;
    case "falling_debris": c.box("concrete", W, H, D, 0, 0, 0, 0xa7a398, { tile: 2, ao: 0.4, ry: 0.2 }); c.box("metal", 0.05, H * 0.9, 0.06, 0.2, 0.1, D / 2 - 0.1, 0x7e868d, { rz: 0.3 }); for (let i = 0; i < 3; i++) c.box("concrete", 0.4, 0.3, 0.4, (i - 1) * 0.5, H, (i % 2) * 0.3, 0xb9b5aa, { ry: i, rz: 0.5 }); break;
    default: c.box("paint", W, H, D, 0, 0, 0, 0xcc6677);
  }
  const g = c.b.build(lib);
  for (const s of c.signs) g.add(signMesh(s));
  return finish(g, c, anims, W, H, D, def.y);
}
function pickColor(r: () => number) { return [0xc8452f, 0x2f6db5, 0xd9a02b, 0x3f8a55, 0x8e5a3a, 0xb0b4b8, 0xe8e6de][Math.floor(r() * 7)]; }
import { signTexture, nexusBillboardTexture } from "./Textures.js";
const signMats = new Map<string, THREE.MeshStandardMaterial>();
export function signMesh(s: { key: string; w: number; h: number; x: number; y: number; z: number; ry: number; text: string; bg: string; fg: string; sub?: string; special?: string }): THREE.Mesh {
  let m = signMats.get(s.key);
  if (!m) { const t = s.special === "nexus" ? nexusBillboardTexture() : signTexture(s.text, s.bg, s.fg, 512, 256, s.sub); m = new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: new THREE.Color(0xffffff), emissiveIntensity: 0.5, roughness: 0.5, side: THREE.DoubleSide }); signMats.set(s.key, m); }
  const me = new THREE.Mesh(G.plane(s.w, s.h), m); me.position.set(s.x, s.y, s.z); me.rotation.y = s.ry; return me;
}
function finish(g: THREE.Group, c: ChunkCtx, anims: ModelAnim[], w: number, h: number, d: number, y: number): ObstacleModel {
  g.traverse((o: any) => { const m = o as THREE.Mesh; if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
  g.userData = { w, h, d, y }; return { group: g, anims };
}

// ───────────────────────── Power-ups ─────────────────────────
export function buildPowerup(id: PowerUpId): THREE.Group {
  const def = POWERUPS[id]; const col = new THREE.Color(def.color); const g = new THREE.Group();
  const core = new THREE.MeshStandardMaterial({ color: col, roughness: 0.25, metalness: 0.3, emissive: col, emissiveIntensity: 0.55 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x2a3340, roughness: 0.4, metalness: 0.6 });
  const white = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3, emissive: 0xffffff, emissiveIntensity: 0.25 });
  const add = (m: THREE.Mesh) => { m.castShadow = false; g.add(m); return m; };
  switch (id) {
    case "shield": { const s = new THREE.Shape(); s.moveTo(0, 0.5); s.bezierCurveTo(0.4, 0.5, 0.45, 0.4, 0.45, 0.2); s.bezierCurveTo(0.45, -0.2, 0.2, -0.4, 0, -0.55); s.bezierCurveTo(-0.2, -0.4, -0.45, -0.2, -0.45, 0.2); s.bezierCurveTo(-0.45, 0.4, -0.4, 0.5, 0, 0.5); add(new THREE.Mesh(new THREE.ExtrudeGeometry(s, { depth: 0.14, bevelEnabled: true, bevelSize: 0.04, bevelThickness: 0.04, bevelSegments: 2 }), core)).position.z = -0.07; const r = add(new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.5, 0.05), white)); r.position.set(0, 0.0, 0.14); const r2 = add(new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.1, 0.05), white)); r2.position.set(0, 0.08, 0.14); break; }
    case "magnet": { const t = add(new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.1, 10, 16, Math.PI), core)); t.rotation.z = 0; t.position.y = 0.1; for (const s of [-1, 1]) { add(new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.22, 10), white)).position.set(s * 0.3, -0.05, 0); add(new THREE.Mesh(new THREE.CylinderGeometry(0.105, 0.105, 0.1, 10), dark)).position.set(s * 0.3, -0.18, 0); } break; }
    case "speed": { const s = new THREE.Shape(); s.moveTo(0.1, 0.55); s.lineTo(-0.28, -0.04); s.lineTo(-0.02, -0.04); s.lineTo(-0.12, -0.55); s.lineTo(0.3, 0.12); s.lineTo(0.04, 0.12); s.closePath(); add(new THREE.Mesh(new THREE.ExtrudeGeometry(s, { depth: 0.14, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.03, bevelSegments: 1 }), core)).position.z = -0.07; break; }
    case "coinx2": { add(new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.12, 24), core)).rotation.x = Math.PI / 2; const c = document.createElement("canvas"); c.width = c.height = 128; const x = c.getContext("2d")!; x.fillStyle = "rgba(0,0,0,0)"; x.clearRect(0, 0, 128, 128); x.fillStyle = "#fff"; x.font = "900 84px system-ui, Arial"; x.textAlign = "center"; x.textBaseline = "middle"; x.fillText("x2", 64, 70); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; const lab = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.62), new THREE.MeshBasicMaterial({ map: t, transparent: true })); lab.position.z = 0.075; g.add(lab); const lab2 = lab.clone(); lab2.rotation.y = Math.PI; lab2.position.z = -0.075; g.add(lab2); break; }
    case "invuln": { const s = new THREE.Shape(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 0.23 : 0.52; if (i === 0) s.moveTo(Math.cos(a) * r, -Math.sin(a) * r); else s.lineTo(Math.cos(a) * r, -Math.sin(a) * r); } s.closePath(); add(new THREE.Mesh(new THREE.ExtrudeGeometry(s, { depth: 0.14, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.03, bevelSegments: 1 }), core)).position.z = -0.07; break; }
    case "slowmo": { add(new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.07, 10, 24), core)); add(new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.06, 24), new THREE.MeshStandardMaterial({ color: 0xeafffa, roughness: 0.3 }))).rotation.x = Math.PI / 2; const h1 = add(new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.26, 0.04), dark)); h1.position.set(0, 0.1, 0.05); h1.geometry.translate(0, 0.0, 0); const h2 = add(new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.05, 0.04), dark)); h2.position.set(0.08, 0, 0.05); add(new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.06, 0.08), core)).position.y = 0.52; break; }
    case "scorex2": { add(new THREE.Mesh(new THREE.OctahedronGeometry(0.48, 0), core)); add(new THREE.Mesh(new THREE.OctahedronGeometry(0.24, 0), white)); break; }
  }
  // soft glow halo (billboard sprite) + ring for visibility
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: col, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending, depthWrite: false })); sp.scale.set(1.9, 1.9, 1); sp.name = "halo"; g.add(sp);
  g.scale.setScalar(1.0); g.userData.powerup = id; return g;
}
let _halo: THREE.Texture | null = null; function haloTex() { return (_halo ??= softDot(64, "rgba(255,255,255,1)", "rgba(255,255,255,0)")); }

// ───────────────────────── Coins, rails, boost pads ─────────────────────────
export function makeCoinMesh(max: number): THREE.InstancedMesh {
  const g = new THREE.CylinderGeometry(0.34, 0.34, 0.08, 20, 1);
  const tex = coinTexture();
  const rim = new THREE.MeshStandardMaterial({ color: 0xe3a21c, roughness: 0.28, metalness: 0.85, emissive: 0xb86e00, emissiveIntensity: 0.35 });
  const face = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.3, metalness: 0.7, emissive: 0xffb300, emissiveMap: tex, emissiveIntensity: 0.4 });
  const m = new THREE.InstancedMesh(g, [rim, face, face] as any, max);
  // InstancedMesh supports a material array via groups of the geometry
  m.count = 0; m.frustumCulled = false; m.castShadow = false; m.name = "coins";
  // orient so the face points along the local +z (towards the camera) before per-instance spin about y
  g.rotateX(Math.PI / 2);
  return m;
}
export function buildRail(len = 8): THREE.Group {
  const g = new THREE.Group(); const m = new THREE.MeshStandardMaterial({ color: 0xcfd6dc, roughness: 0.25, metalness: 0.9 }); const d = new THREE.MeshStandardMaterial({ color: 0x3a4048, roughness: 0.5, metalness: 0.6 });
  const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, len, 8), m); rail.rotation.x = Math.PI / 2; rail.position.y = 0.55; g.add(rail);
  for (const z of [-len / 2 + 0.3, 0, len / 2 - 0.3]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.55, 0.08), d); p.position.set(0, 0.27, z); g.add(p); const f = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.04, 0.2), d); f.position.set(0, 0.02, z); g.add(f); }
  const glow = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.02, len), new THREE.MeshBasicMaterial({ color: 0x6fe3ff })); glow.position.y = 0.62; g.add(glow);
  g.traverse((o: any) => { (o as THREE.Mesh).castShadow = true; }); return g;
}
export function buildBoostPad(): THREE.Group {
  const g = new THREE.Group(); const c = document.createElement("canvas"); c.width = 128; c.height = 256; const x = c.getContext("2d")!;
  x.fillStyle = "#14308f"; x.fillRect(0, 0, 128, 256); x.strokeStyle = "#7fd2ff"; x.lineWidth = 10; x.strokeRect(5, 5, 118, 246);
  for (let i = 0; i < 3; i++) { x.strokeStyle = i === 1 ? "#9fe3ff" : "#4aa8ff"; x.lineWidth = 16; x.lineCap = "round"; x.beginPath(); x.moveTo(24, 210 - i * 62); x.lineTo(64, 160 - i * 62); x.lineTo(104, 210 - i * 62); x.stroke(); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.MeshStandardMaterial({ map: t, emissiveMap: t, emissive: 0xffffff, emissiveIntensity: 0.75, roughness: 0.4 });
  const p = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 2.6), mat); p.rotation.x = -Math.PI / 2; p.position.y = 0.03; g.add(p);
  const halo = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 3.2), new THREE.MeshBasicMaterial({ map: haloTex(), color: 0x4aa8ff, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false })); halo.rotation.x = -Math.PI / 2; halo.position.y = 0.025; g.add(halo);
  return g;
}
