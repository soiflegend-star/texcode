/**
 * CharacterFactory — five structurally different procedural characters (not recolours) plus a rival variant.
 * Each is a jointed rig built from capsules/boxes/spheres: different proportions, hair, clothing layers and accessories.
 * Convention: the character FACES -z (running direction in the scene); the back logo is on the +z side (seen by the chase cam).
 */
import * as THREE from "three";
import { logoNTexture } from "./Textures.js";

export type PoseKey = "rootY" | "pitch" | "roll" | "yaw" | "spine" | "chestTwist" | "headP" | "headY"
  | "shL" | "shLz" | "elL" | "shR" | "shRz" | "elR" | "hipL" | "hipLz" | "knL" | "hipR" | "hipRz" | "knR" | "ankL" | "ankR";
export const POSE_KEYS: PoseKey[] = ["rootY", "pitch", "roll", "yaw", "spine", "chestTwist", "headP", "headY", "shL", "shLz", "elL", "shR", "shRz", "elR", "hipL", "hipLz", "knL", "hipR", "hipRz", "knR", "ankL", "ankR"];

export interface Rig {
  root: THREE.Group; body: THREE.Group; hips: THREE.Group; spine: THREE.Group; chest: THREE.Group; head: THREE.Group;
  shL: THREE.Group; elL: THREE.Group; shR: THREE.Group; elR: THREE.Group;
  hipL: THREE.Group; knL: THREE.Group; hipR: THREE.Group; knR: THREE.Group; ankL: THREE.Group; ankR: THREE.Group;
  /** loose parts animated with secondary motion */
  trails: Array<{ node: THREE.Object3D; amp: number; phase: number; axis: "x" | "z" }>;
  hand: { L: THREE.Object3D; R: THREE.Object3D };
  glow: THREE.Mesh | null;
  materials: THREE.Material[];
  height: number;
}

export interface Look {
  id: string; scale: number; widthMul: number; legLen: number; torsoLen: number; armLen: number; headR: number; limbR: number;
  skin: number; top: number; top2: number; pants: number; shoes: number; hair: number; accent: number; logo: string | null;
}
export const LOOKS: Record<string, Look> = {
  runner:    { id: "runner", scale: 1.0, widthMul: 1.0, legLen: 0.92, torsoLen: 0.56, armLen: 0.62, headR: 0.135, limbR: 0.062, skin: 0xe0ac8a, top: 0x2f6fb5, top2: 0x1f4f88, pants: 0x30343c, shoes: 0xf2f2f2, hair: 0x3a2a20, accent: 0xf5c542, logo: "#ffffff" },
  acrobat:   { id: "acrobat", scale: 1.02, widthMul: 0.86, legLen: 1.02, torsoLen: 0.5, armLen: 0.64, headR: 0.125, limbR: 0.052, skin: 0xc58c6a, top: 0xe0407a, top2: 0xfff1d6, pants: 0x27304a, shoes: 0x4de0d0, hair: 0x1d1620, accent: 0x4de0d0, logo: null },
  speedster: { id: "speedster", scale: 1.03, widthMul: 0.8, legLen: 1.0, torsoLen: 0.55, armLen: 0.6, headR: 0.12, limbR: 0.05, skin: 0xe8b894, top: 0xf2f4f8, top2: 0xffc928, pants: 0xf2f4f8, shoes: 0xffc928, hair: 0x201a14, accent: 0xff4d3a, logo: null },
  heavy:     { id: "heavy", scale: 1.1, widthMul: 1.4, legLen: 0.88, torsoLen: 0.62, armLen: 0.6, headR: 0.15, limbR: 0.092, skin: 0xa7714f, top: 0x4a5a3a, top2: 0x2e2a26, pants: 0x3a3228, shoes: 0x2a2420, hair: 0x15110d, accent: 0xd98a2b, logo: null },
  ninja:     { id: "ninja", scale: 1.0, widthMul: 0.9, legLen: 0.96, torsoLen: 0.54, armLen: 0.62, headR: 0.125, limbR: 0.055, skin: 0xd9a584, top: 0x1c1f2a, top2: 0x7a1f2c, pants: 0x171a22, shoes: 0x23262f, hair: 0x0c0c10, accent: 0xc2263a, logo: null },
  rival:     { id: "rival", scale: 1.0, widthMul: 1.02, legLen: 0.92, torsoLen: 0.56, armLen: 0.62, headR: 0.135, limbR: 0.062, skin: 0xd09a78, top: 0xd8312f, top2: 0x8f1d1d, pants: 0x25262c, shoes: 0xf2f2f2, hair: 0x7a3b1c, accent: 0xffffff, logo: "#ffffff" },
};

const matCache = new Map<string, THREE.MeshStandardMaterial>();
function M(color: number, o: { r?: number; m?: number; e?: number; ei?: number } = {}): THREE.MeshStandardMaterial {
  const k = `${color}|${o.r ?? 0.7}|${o.m ?? 0}|${o.e ?? 0}|${o.ei ?? 0}`;
  let m = matCache.get(k);
  if (!m) { m = new THREE.MeshStandardMaterial({ color, roughness: o.r ?? 0.7, metalness: o.m ?? 0, emissive: new THREE.Color(o.e ?? 0), emissiveIntensity: o.ei ?? 0 }); matCache.set(k, m); }
  return m;
}
function mesh(g: THREE.BufferGeometry, m: THREE.Material, x = 0, y = 0, z = 0): THREE.Mesh { const me = new THREE.Mesh(g, m); me.position.set(x, y, z); me.castShadow = true; me.receiveShadow = false; return me; }
function limbGeo(r: number, len: number, r2 = r * 0.85) { const g = new THREE.CylinderGeometry(r, r2, len, 8, 1); g.translate(0, -len / 2, 0); return g; }
function capsuleDown(r: number, len: number) { const g = new THREE.CapsuleGeometry(r, Math.max(0.001, len - 2 * r), 4, 8); g.translate(0, -len / 2, 0); return g; }
const G = (o: THREE.Object3D, ...c: THREE.Object3D[]) => { c.forEach((x) => o.add(x)); return o; };
function grp(name: string, x = 0, y = 0, z = 0) { const g = new THREE.Group(); g.name = name; g.position.set(x, y, z); return g; }

export function buildCharacter(lookId: string, override: Partial<Look> = {}): Rig {
  const L: Look = { ...(LOOKS[lookId] ?? LOOKS.runner), ...override };
  const id = lookId === "rival" ? "rival" : L.id;
  const mats: THREE.Material[] = [];
  const mk = (c: number, o?: Parameters<typeof M>[1]) => { const m = M(c, o); mats.push(m); return m; };
  const skin = mk(L.skin, { r: 0.62 }), top = mk(L.top, { r: 0.85 }), top2 = mk(L.top2, { r: 0.85 }), pants = mk(L.pants, { r: 0.85 }), shoes = mk(L.shoes, { r: 0.55 }), hair = mk(L.hair, { r: 0.8 }), acc = mk(L.accent, { r: 0.5 });
  const sole = mk(0xf0efe9, { r: 0.7 }), dark = mk(0x15171c, { r: 0.6 }), white = mk(0xf4f4f4, { r: 0.6 }), metal = mk(0x9aa3ab, { r: 0.35, m: 0.8 });

  const root = grp("root"); const body = grp("body"); root.add(body);
  const W = L.widthMul;
  const legLen = L.legLen, torsoLen = L.torsoLen;
  const hips = grp("hips", 0, legLen, 0); body.add(hips);
  const spine = grp("spine", 0, 0.05, 0); hips.add(spine);
  const chest = grp("chest", 0, torsoLen * 0.45, 0); spine.add(chest);
  const shoulderY = torsoLen * 0.55, shoulderX = 0.2 * W + 0.03;
  const trails: Rig["trails"] = [];

  // ── Torso ──
  const tw = 0.34 * W, td = 0.2 + 0.05 * W;
  const torso = mesh(new THREE.CapsuleGeometry(1, 1, 4, 10), top, 0, torsoLen * 0.05, 0); torso.scale.set(tw * 0.5, torsoLen * 0.34, td * 0.5);
  torso.geometry = new THREE.CapsuleGeometry(1, 0.8, 4, 12); chest.add(torso);
  const waist = mesh(new THREE.CylinderGeometry(tw * 0.38, tw * 0.34, 0.2, 10), id === "speedster" ? top : id === "ninja" ? top2 : pants, 0, -torsoLen * 0.5, 0); spine.add(waist); waist.position.y = -0.02;

  // ── Head ──
  const neck = mesh(new THREE.CylinderGeometry(0.045, 0.05, 0.08, 8), skin, 0, shoulderY * 0.9, 0); chest.add(neck);
  const head = grp("head", 0, shoulderY + L.headR * 0.95, 0); chest.add(head);
  head.add(mesh(new THREE.SphereGeometry(L.headR, 16, 12), skin));
  const faceZ = -L.headR * 0.9;
  const eyeM = mk(0x15171c, { r: 0.3 });
  const showFace = id !== "ninja";
  if (showFace) for (const s of [-1, 1]) { const e = mesh(new THREE.SphereGeometry(L.headR * 0.11, 6, 5), eyeM, s * L.headR * 0.36, L.headR * 0.08, faceZ + 0.005); e.scale.set(1, 1.3, 0.6); head.add(e); const br = mesh(new THREE.BoxGeometry(L.headR * 0.32, 0.012, 0.012), hair, s * L.headR * 0.36, L.headR * 0.3, faceZ + 0.0); head.add(br); }
  if (showFace) head.add(mesh(new THREE.BoxGeometry(L.headR * 0.28, 0.012, 0.01), mk(0x7a3b3b), 0, -L.headR * 0.38, faceZ + 0.0));
  head.add(mesh(new THREE.SphereGeometry(L.headR * 0.12, 6, 5), skin, 0, -L.headR * 0.05, faceZ - 0.005));   // nose

  // ── Arms ──
  const upper = L.armLen * 0.5, lower = L.armLen * 0.5, r = L.limbR;
  const mkArm = (s: number) => {
    const sh = grp(s < 0 ? "shL" : "shR", s * shoulderX, shoulderY - 0.02, 0); chest.add(sh);
    const sleeve = id === "speedster" || id === "acrobat" ? (id === "acrobat" ? top2 : top) : top;
    sh.add(mesh(capsuleDown(r * 1.12, upper), sleeve));
    if (id === "heavy") sh.add(mesh(new THREE.SphereGeometry(r * 1.45, 10, 8), mk(0x59606a, { r: 0.4, m: 0.6 }), 0, 0.02, 0));
    const el = grp(s < 0 ? "elL" : "elR", 0, -upper, 0); sh.add(el);
    const forearmMat = id === "ninja" ? mk(0x2a2d38) : id === "runner" || id === "rival" ? top : id === "heavy" ? skin : id === "acrobat" ? skin : top;
    el.add(mesh(capsuleDown(r, lower), forearmMat));
    if (id === "acrobat" || id === "ninja") el.add(mesh(new THREE.CylinderGeometry(r * 1.2, r * 1.2, 0.1, 8), id === "ninja" ? mk(0x2a2d38) : acc, 0, -lower * 0.55, 0));
    if (id === "heavy") el.add(mesh(new THREE.CylinderGeometry(r * 1.35, r * 1.25, 0.16, 8), mk(0x3a3f46, { r: 0.5, m: 0.5 }), 0, -lower * 0.5, 0));
    const hand = mesh(new THREE.SphereGeometry(r * (id === "heavy" ? 1.45 : 1.2), 8, 6), id === "speedster" ? acc : skin, 0, -lower - r * 0.4, 0); el.add(hand);
    return { sh, el, hand };
  };
  const aL = mkArm(-1), aR = mkArm(1);

  // ── Legs ──
  const thigh = legLen * 0.5, shin = legLen * 0.5;
  const mkLeg = (s: number) => {
    const hp = grp(s < 0 ? "hipL" : "hipR", s * 0.095 * W, 0, 0); hips.add(hp);
    hp.add(mesh(capsuleDown(r * 1.4, thigh), pants));
    const kn = grp("kn", 0, -thigh, 0); hp.add(kn);
    kn.add(mesh(capsuleDown(r * 1.15, shin), id === "ninja" ? mk(0x2a2d38) : pants));
    if (id === "ninja") kn.add(mesh(new THREE.CylinderGeometry(r * 1.3, r * 1.3, 0.28, 8), mk(0x3a3f4d), 0, -shin * 0.62, 0));
    if (id === "heavy") kn.add(mesh(new THREE.BoxGeometry(r * 3, 0.16, r * 3), mk(0x59606a, { r: 0.4, m: 0.6 }), 0, -0.02, -r * 0.5));
    const ank = grp("ank", 0, -shin, 0); kn.add(ank);
    const shoeLen = id === "heavy" ? 0.31 : 0.27, shoeH = id === "heavy" ? 0.13 : 0.085;
    ank.add(mesh(new THREE.BoxGeometry(0.115 * W + 0.02, shoeH, shoeLen), shoes, 0, -shoeH * 0.45, -shoeLen * 0.25));
    ank.add(mesh(new THREE.BoxGeometry(0.12 * W + 0.02, 0.03, shoeLen + 0.01), id === "ninja" ? dark : sole, 0, -shoeH * 0.9, -shoeLen * 0.25));
    if (id === "heavy") ank.add(mesh(new THREE.BoxGeometry(0.14, 0.18, 0.18), shoes, 0, 0.02, 0.0));
    if (id === "speedster") { const w = mesh(new THREE.BoxGeometry(0.01, 0.1, 0.12), acc, s * 0.075, 0.05, 0.1); w.rotation.z = s * 0.3; ank.add(w); }
    return { hp, kn, ank };
  };
  const lL = mkLeg(-1), lR = mkLeg(1);

  // ── Per-character clothing & accessories ──
  const back = chest; const bz = td * 0.5 + 0.01; // +z = back
  switch (id) {
    case "runner": case "rival": {
      // hoodie: pouch, hood bundle at the neck, cuffs, drawstrings, hem, N logo on the back
      const hem = mesh(new THREE.CylinderGeometry(tw * 0.55, tw * 0.52, 0.07, 12), top2, 0, -torsoLen * 0.38, 0); hem.scale.z = 0.7; chest.add(hem);
      const hood = mesh(new THREE.TorusGeometry(0.1, 0.045, 7, 12), top, 0, shoulderY + 0.02, 0.045); hood.rotation.x = Math.PI / 2.4; chest.add(hood);
      for (const s of [-1, 1]) { chest.add(mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.16, 4), white, s * 0.04, shoulderY - 0.12, -td * 0.5 - 0.005)); aL.el.add(mesh(new THREE.CylinderGeometry(r * 1.2, r * 1.2, 0.05, 8), top2, 0, -lower * 0.88, 0)); aR.el.add(mesh(new THREE.CylinderGeometry(r * 1.2, r * 1.2, 0.05, 8), top2, 0, -lower * 0.88, 0)); break; }
      const pouch = mesh(new THREE.BoxGeometry(tw * 0.62, 0.1, 0.03), top2, 0, -torsoLen * 0.18, -td * 0.5 - 0.005); chest.add(pouch);
      const logo = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.2), new THREE.MeshStandardMaterial({ map: logoNTexture("N", L.logo ?? "#fff", 128), transparent: true, roughness: 0.8, alphaTest: 0.05 })); logo.position.set(0, 0.0, bz + 0.07); logo.castShadow = false; chest.add(logo);
      // hair & cap-less short hair
      head.add(mesh(new THREE.SphereGeometry(L.headR * 1.04, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), hair, 0, 0.012, 0.012));
      for (const s of [-1, 1]) head.add(mesh(new THREE.BoxGeometry(L.headR * 0.28, L.headR * 0.45, L.headR * 0.4), hair, s * L.headR * 0.92, 0.02, 0.02));
      if (id === "rival") { const band = mesh(new THREE.TorusGeometry(L.headR * 1.02, 0.015, 5, 16), white, 0, L.headR * 0.3, 0); band.rotation.x = Math.PI / 2; head.add(band); }
      // small shoulder bag strap
      const strap = mesh(new THREE.BoxGeometry(0.035, torsoLen * 0.95, 0.01), dark, -tw * 0.18, 0, -td * 0.5 - 0.004); strap.rotation.z = 0.35; chest.add(strap);
      break;
    }
    case "acrobat": {
      // cropped jacket over bare-midriff top, sash with trailing tail, ponytail, headband, wrist & ankle wraps
      chest.add(mesh(new THREE.CylinderGeometry(tw * 0.52, tw * 0.46, torsoLen * 0.3, 12), top2, 0, -torsoLen * 0.3, 0));
      for (const s of [-1, 1]) { const lap = mesh(new THREE.BoxGeometry(0.1, torsoLen * 0.5, 0.02), top, s * 0.07, 0.04, -td * 0.5 - 0.01); lap.rotation.z = s * 0.2; chest.add(lap); }
      const sash = mesh(new THREE.TorusGeometry(tw * 0.4, 0.035, 6, 16), acc, 0, -torsoLen * 0.5, 0); sash.rotation.x = Math.PI / 2; sash.scale.y = 0.75; spine.add(sash); sash.position.y = 0.02;
      const tail = grp("sashTail", 0.1, 0.02, bz); const tl = mesh(new THREE.BoxGeometry(0.05, 0.42, 0.012), acc, 0, -0.21, 0); tail.add(tl); spine.add(tail); trails.push({ node: tail, amp: 0.5, phase: 0, axis: "x" });
      head.add(mesh(new THREE.SphereGeometry(L.headR * 1.04, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.5), hair, 0, 0.012, 0.01));
      const pony = grp("pony", 0, L.headR * 0.5, L.headR * 0.9); pony.add(mesh(new THREE.SphereGeometry(0.05, 8, 6), hair)); const pl = mesh(capsuleDown(0.04, 0.4), hair, 0, -0.03, 0); pony.add(pl); head.add(pony); trails.push({ node: pony, amp: 0.45, phase: 1.3, axis: "x" });
      const band = mesh(new THREE.TorusGeometry(L.headR * 1.02, 0.017, 5, 16), acc, 0, L.headR * 0.38, 0); band.rotation.x = Math.PI / 2; head.add(band);
      for (const e of [lL.kn, lR.kn]) e.add(mesh(new THREE.CylinderGeometry(r * 1.4, r * 1.4, 0.12, 8), acc, 0, -shin * 0.82, 0));
      break;
    }
    case "speedster": {
      // aerodynamic bodysuit w/ chest stripe, helmet with visor + dorsal fin, jet-pack sleeve, hand grips
      chest.add(mesh(new THREE.BoxGeometry(0.06, torsoLen * 0.85, 0.01), top2, 0, 0, -td * 0.5 - 0.012));
      chest.add(mesh(new THREE.BoxGeometry(0.06, torsoLen * 0.85, 0.01), top2, 0, 0, td * 0.5 + 0.012));
      const helm = mesh(new THREE.SphereGeometry(L.headR * 1.12, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.62), white, 0, 0.0, 0.01); head.add(helm);
      const visor = mesh(new THREE.SphereGeometry(L.headR * 1.14, 14, 8, -0.9, 1.8, 1.0, 0.8), mk(0x1b2a3a, { r: 0.12, m: 0.9, e: 0x2aa8ff, ei: 0.35 }), 0, 0.0, -0.005); visor.scale.set(1, 1, 1); head.add(visor);
      const fin = mesh(new THREE.BoxGeometry(0.012, 0.1, 0.24), acc, 0, L.headR * 1.0, 0.04); fin.rotation.x = 0.35; head.add(fin);
      const pack = mesh(new THREE.BoxGeometry(tw * 0.65, torsoLen * 0.55, 0.09), mk(0x2c3440, { r: 0.4, m: 0.6 }), 0, 0.02, bz + 0.03); chest.add(pack);
      for (const s of [-1, 1]) { const n = mesh(new THREE.CylinderGeometry(0.03, 0.045, 0.1, 8), acc, s * 0.08, -torsoLen * 0.3, bz + 0.045); chest.add(n); }
      for (const e of [lL.kn, lR.kn]) e.add(mesh(new THREE.CylinderGeometry(r * 1.4, r * 1.25, 0.14, 8), top2, 0, -shin * 0.35, 0));
      break;
    }
    case "heavy": {
      // armoured vest + shoulder guards + belt with pouches + beanie + beard + bracers
      chest.add(mesh(new THREE.BoxGeometry(tw * 0.92, torsoLen * 0.62, td * 0.96), top2, 0, 0.0, 0));
      const plate = mesh(new THREE.BoxGeometry(tw * 0.76, torsoLen * 0.42, 0.045), mk(0x59606a, { r: 0.4, m: 0.7 }), 0, 0.02, -td * 0.5 - 0.03); chest.add(plate);
      chest.add(mesh(new THREE.BoxGeometry(tw * 0.6, torsoLen * 0.4, 0.045), mk(0x59606a, { r: 0.4, m: 0.7 }), 0, 0.02, td * 0.5 + 0.03));
      for (const s of [-1, 1]) { const pad = mesh(new THREE.CylinderGeometry(0.13, 0.15, 0.1, 10), mk(0x59606a, { r: 0.4, m: 0.7 }), s * (shoulderX + 0.02), shoulderY + 0.02, 0); pad.rotation.z = s * 0.35; chest.add(pad); }
      const belt = mesh(new THREE.CylinderGeometry(tw * 0.56, tw * 0.56, 0.07, 12), mk(0x5a3a1f, { r: 0.7 }), 0, -torsoLen * 0.48, 0); belt.scale.z = 0.75; chest.add(belt);
      chest.add(mesh(new THREE.BoxGeometry(0.07, 0.07, 0.03), mk(0xd9b44a, { r: 0.3, m: 0.9 }), 0, -torsoLen * 0.48, -td * 0.5 - 0.03));
      for (const s of [-1, 1]) chest.add(mesh(new THREE.BoxGeometry(0.1, 0.1, 0.07), mk(0x4a3a2a), s * 0.17, -torsoLen * 0.48, -td * 0.5 + 0.0));
      const beanie = mesh(new THREE.SphereGeometry(L.headR * 1.1, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), acc, 0, 0.02, 0.0); head.add(beanie);
      const cuff = mesh(new THREE.TorusGeometry(L.headR * 1.02, 0.03, 6, 16), mk(0x8a5a1f), 0, L.headR * 0.28, 0); cuff.rotation.x = Math.PI / 2; head.add(cuff);
      const beard = mesh(new THREE.SphereGeometry(L.headR * 0.62, 10, 8), hair, 0, -L.headR * 0.55, -L.headR * 0.45); beard.scale.set(1.1, 0.8, 0.7); head.add(beard);
      break;
    }
    case "ninja": {
      // layered gi with crossed front, obi, hood + face mask with eye slit, long trailing scarf, katana across the back, wrapped forearms
      for (const s of [-1, 1]) { const lap = mesh(new THREE.BoxGeometry(0.13, torsoLen * 0.78, 0.02), top2, s * 0.05, 0.02, -td * 0.5 - 0.012); lap.rotation.z = -s * 0.5; chest.add(lap); }
      const obi = mesh(new THREE.CylinderGeometry(tw * 0.5, tw * 0.5, 0.08, 12), acc, 0, -torsoLen * 0.45, 0); obi.scale.z = 0.72; chest.add(obi);
      const hood = mesh(new THREE.SphereGeometry(L.headR * 1.12, 14, 10), mk(0x1c1f2a, { r: 0.9 }), 0, 0.0, 0.015); head.add(hood);
      head.add(mesh(new THREE.BoxGeometry(L.headR * 1.5, L.headR * 0.5, 0.02), skin, 0, L.headR * 0.1, faceZ - 0.012));
      for (const s of [-1, 1]) head.add(mesh(new THREE.SphereGeometry(L.headR * 0.1, 6, 5), mk(0xffffff, { r: 0.3, e: 0xffffff, ei: 0.2 }), s * L.headR * 0.36, L.headR * 0.12, faceZ - 0.022));
      const scarf = grp("scarf", 0, shoulderY * 0.95, bz); const sc = mesh(new THREE.BoxGeometry(0.1, 0.02, 0.62), acc, 0, 0, 0.31); sc.rotation.x = 0; scarf.add(sc); chest.add(scarf); trails.push({ node: scarf, amp: 0.4, phase: 0.2, axis: "z" });
      const ring = mesh(new THREE.TorusGeometry(0.095, 0.035, 6, 12), acc, 0, shoulderY * 0.95, 0); ring.rotation.x = Math.PI / 2; chest.add(ring);
      const sword = grp("katana", 0, 0.05, bz + 0.03); sword.rotation.z = 0.7;
      sword.add(mesh(new THREE.BoxGeometry(0.025, 0.78, 0.012), mk(0xd5dde4, { r: 0.2, m: 0.95 }), 0, 0.12, 0)); sword.add(mesh(new THREE.BoxGeometry(0.03, 0.2, 0.025), dark, 0, -0.36, 0)); sword.add(mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.012, 8), acc, 0, -0.26, 0)); chest.add(sword);
      for (const e of [aL.el, aR.el]) e.add(mesh(new THREE.CylinderGeometry(r * 1.3, r * 1.2, 0.2, 8), mk(0xe6e0d0, { r: 0.9 }), 0, -lower * 0.55, 0));
      break;
    }
  }

  // glow shell for boost / invuln (additive, hidden by default)
  const glow = mesh(new THREE.CapsuleGeometry(0.42, 0.9, 6, 12), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }), 0, 0.9, 0);
  glow.castShadow = false; glow.visible = false; body.add(glow);

  root.scale.setScalar(L.scale);
  return { root, body, hips, spine, chest, head, shL: aL.sh, elL: aL.el, shR: aR.sh, elR: aR.el, hipL: lL.hp, knL: lL.kn, hipR: lR.hp, knR: lR.kn, ankL: lL.ank, ankR: lR.ank, trails, hand: { L: aL.hand, R: aR.hand }, glow, materials: mats, height: (legLen + torsoLen + L.headR * 2) * L.scale };
}
