/**
 * Props — procedural prop library. Every prop writes into a ChunkCtx (a Batch plus
 * sign / emitter lists) in chunk-local coordinates: x lateral, y up, z from 0 (near end) to -60 (far end).
 */
import * as THREE from "three";
import { Batch, boxGeo, mat } from "./Batch.js";
import { Rng } from "../util/rng.js";
import type { MaterialLibrary } from "./Materials.js";

export interface SignSpec { key: string; w: number; h: number; x: number; y: number; z: number; ry: number; text: string; bg: string; fg: string; sub?: string; special?: "nexus" }
export interface EmitterSpec { type: "steam" | "smoke" | "spark" | "dust" | "drip" | "fire" | "leaf"; x: number; y: number; z: number; rate?: number }
export interface AnimSpec { kind: "spin" | "bob" | "blink" | "sway"; mesh: THREE.Object3D; speed: number; amp?: number }

const geoCache = new Map<string, THREE.BufferGeometry>();
function cached(key: string, make: () => THREE.BufferGeometry) { let g = geoCache.get(key); if (!g) { g = make(); geoCache.set(key, g); } return g; }
export const G = {
  box: (w: number, h: number, d: number, tile = 4) => cached(`b${w.toFixed(3)},${h.toFixed(3)},${d.toFixed(3)},${tile}`, () => boxGeo(w, h, d, tile)),
  cyl: (rt: number, rb: number, h: number, seg = 10) => cached(`c${rt.toFixed(3)},${rb.toFixed(3)},${h.toFixed(3)},${seg}`, () => new THREE.CylinderGeometry(rt, rb, h, seg, 1)),
  sphere: (r: number, ws = 10, hs = 8) => cached(`s${r.toFixed(3)},${ws},${hs}`, () => new THREE.SphereGeometry(r, ws, hs)),
  plane: (w: number, h: number) => cached(`p${w.toFixed(3)},${h.toFixed(3)}`, () => new THREE.PlaneGeometry(w, h)),
  ico: (r: number, d = 1) => cached(`i${r.toFixed(3)},${d}`, () => new THREE.IcosahedronGeometry(r, d)),
  torus: (r: number, t: number, rs = 6, ts = 14, arc = Math.PI * 2) => cached(`t${r.toFixed(3)},${t.toFixed(3)},${rs},${ts},${arc.toFixed(2)}`, () => new THREE.TorusGeometry(r, t, rs, ts, arc)),
  circle: (r: number, seg = 16) => cached(`o${r.toFixed(3)},${seg}`, () => new THREE.CircleGeometry(r, seg)),
  capsule: (r: number, l: number, cs = 4, rs = 8) => cached(`k${r.toFixed(3)},${l.toFixed(3)},${cs},${rs}`, () => new THREE.CapsuleGeometry(r, l, cs, rs)),
};

export class ChunkCtx {
  b = new Batch();
  signs: SignSpec[] = [];
  emitters: EmitterSpec[] = [];
  /** extra non-batched things (animated props etc.) */
  extras: THREE.Object3D[] = [];
  anims: AnimSpec[] = [];
  constructor(public rng: Rng, public lib: MaterialLibrary, public length = 60) {}

  /** Box with its BOTTOM at y. */
  box(mk: string, w: number, h: number, d: number, x: number, y: number, z: number, color: number, o: { ry?: number; rx?: number; rz?: number; tile?: number; ao?: number; aoS?: number } = {}) {
    this.b.add(mk, G.box(w, h, d, o.tile ?? 4), mat(x, y + h / 2, z, o.rx ?? 0, o.ry ?? 0, o.rz ?? 0), { color, aoHeight: o.ao, aoStrength: o.aoS });
  }
  /** Vertical cylinder (bottom at y). rTop for tapering. */
  cyl(mk: string, r: number, h: number, x: number, y: number, z: number, color: number, o: { rTop?: number; seg?: number; rx?: number; rz?: number; ry?: number; ao?: number } = {}) {
    this.b.add(mk, G.cyl(o.rTop ?? r, r, h, o.seg ?? 10), mat(x, y + h / 2, z, o.rx ?? 0, o.ry ?? 0, o.rz ?? 0), { color, aoHeight: o.ao });
  }
  /** Horizontal cylinder along Z (axis='z') or X; centre at (x,y,z). */
  pipe(mk: string, r: number, len: number, x: number, y: number, z: number, color: number, axis: "x" | "z" = "z", seg = 8) {
    this.b.add(mk, G.cyl(r, r, len, seg), axis === "z" ? mat(x, y, z, Math.PI / 2, 0, 0) : mat(x, y, z, 0, 0, Math.PI / 2), { color });
  }
  sphere(mk: string, r: number, x: number, y: number, z: number, color: number, sx = 1, sy = 1, sz = 1, o: { ws?: number; hs?: number; ao?: number } = {}) {
    this.b.add(mk, G.sphere(r, o.ws ?? 9, o.hs ?? 7), mat(x, y, z, 0, 0, 0, sx, sy, sz), { color, aoHeight: o.ao });
  }
  ico(mk: string, r: number, x: number, y: number, z: number, color: number, sx = 1, sy = 1, sz = 1, ry = 0, d = 1) {
    this.b.add(mk, G.ico(r, d), mat(x, y, z, 0, ry, 0, sx, sy, sz), { color });
  }
  cone(mk: string, r: number, h: number, x: number, y: number, z: number, color: number, seg = 8) {
    this.b.add(mk, G.cyl(0.001, r, h, seg), mat(x, y + h / 2, z), { color });
  }
  /** Flat plane lying on the ground (xz), centred at (x,y,z). */
  floor(mk: string, w: number, d: number, x: number, y: number, z: number, color = 0xffffff, uv: [number, number] = [1, 1], ry = 0) {
    this.b.add(mk, G.plane(w, d), mat(x, y, z, -Math.PI / 2, ry, 0), { color, uvScale: uv });
  }
  /** Upright plane facing +z / -z / ±x via ry. */
  wall(mk: string, w: number, h: number, x: number, y: number, z: number, ry: number, color = 0xffffff, uv: [number, number] = [1, 1]) {
    this.b.add(mk, G.plane(w, h), mat(x, y + h / 2, z, 0, ry, 0), { color, uvScale: uv });
  }
  glow(r: number, x: number, y: number, z: number, color: number) { this.b.add("emissive", G.sphere(r, 6, 5), mat(x, y, z), { color }); }
  sign(spec: Omit<SignSpec, "key"> & { key?: string }) { this.signs.push({ key: spec.key ?? `${spec.text}|${spec.bg}|${spec.fg}|${spec.sub ?? ""}`, ...spec } as SignSpec); }
  emit(e: EmitterSpec) { this.emitters.push(e); }
}

// ───────────────────────── palettes ─────────────────────────
export const PAL = {
  city: [0x6c7b88, 0x8fa0ab, 0x5f6e7a, 0xa9b4b7, 0x7b8a97, 0x9aa7b2],
  brick: [0xb55d44, 0xa04d3a, 0xc4704f, 0x9a5a48],
  paintBright: [0xe8a43a, 0x3d9bd6, 0xd8493a, 0x57b36a, 0xf2f0ea, 0x8f65c9],
  containers: [0xc8452f, 0x2f6db5, 0xd9a02b, 0x3f8a55, 0x8e5a3a, 0xb0b4b8, 0x2b4a6a],
  concrete: [0xb8b4aa, 0xa9a69e, 0xc6c1b6],
  foliage: [0x3f8a45, 0x4c9a4a, 0x357a3e, 0x5aa352, 0x2f6f3b],
};

// ───────────────────────── Structural props ─────────────────────────
export function streetLamp(c: ChunkCtx, x: number, z: number, side: number, h = 7.2, warm = 0xfff1c4, arm = 2.2) {
  c.cyl("metal", 0.11, h, x, 0, z, 0x59626b, { rTop: 0.07, seg: 8 });
  c.box("metal", 0.22, 0.22, 0.22, x, 0, z, 0x4a525a);
  const dir = -side; // arm points toward the road
  c.box("metal", arm, 0.1, 0.1, x + dir * arm / 2, h - 0.1, z, 0x59626b);
  c.box("metal", 0.6, 0.12, 0.3, x + dir * arm, h - 0.12, z, 0x3d444b);
  c.box("emissive", 0.5, 0.05, 0.22, x + dir * arm, h - 0.2, z, warm);
}
export function tree(c: ChunkCtx, x: number, z: number, s = 1, kind: "round" | "tall" | "planter" = "round") {
  const rng = c.rng; const g = PAL.foliage[Math.floor(rng() * PAL.foliage.length)];
  c.cyl("paint", 0.14 * s, 2.2 * s, x, 0, z, 0x6a4a32, { rTop: 0.09 * s, seg: 6 });
  const R = 1.35 * s;
  c.sphere("foliage", R, x, 2.9 * s, z, g, 1, 0.9, 1, { ws: 8, hs: 6 });
  c.sphere("foliage", R * 0.7, x + R * 0.55, 2.55 * s, z + 0.3 * s, PAL.foliage[Math.floor(rng() * 5)], 1, 0.9, 1, { ws: 7, hs: 5 });
  c.sphere("foliage", R * 0.65, x - R * 0.5, 3.3 * s, z - 0.35 * s, PAL.foliage[Math.floor(rng() * 5)], 1, 0.9, 1, { ws: 7, hs: 5 });
  if (kind === "planter") c.box("concrete", 1.2 * s, 0.5, 1.2 * s, x, 0, z, 0x8b8f93, { tile: 2 });
}
export function guardRail(c: ChunkCtx, x: number, z0: number, z1: number, h = 0.95, color = 0xaeb6bd, post = 0x7e868d) {
  const len = Math.abs(z1 - z0), zc = (z0 + z1) / 2;
  c.box("metal", 0.08, 0.1, len, x, h, zc, color); c.box("metal", 0.06, 0.07, len, x, h * 0.55, zc, color);
  for (let z = Math.min(z0, z1); z <= Math.max(z0, z1) + 0.01; z += 3) c.box("metal", 0.1, h, 0.1, x, 0, z, post);
}
export function curb(c: ChunkCtx, x: number, z0: number, z1: number, w = 0.3, h = 0.16, color = 0xc8c4bb) { c.box("concrete", w, h, Math.abs(z1 - z0), x, 0, (z0 + z1) / 2, color, { tile: 2 }); }
export function sidewalk(c: ChunkCtx, x0: number, x1: number, len: number, h = 0.16) {
  const w = Math.abs(x1 - x0); c.box("sidewalk", w, h, len, (x0 + x1) / 2, 0, -len / 2, 0xffffff, { tile: 3 });
}
export function hvac(c: ChunkCtx, x: number, y: number, z: number, s = 1, ry = 0) {
  const w = (2 + c.rng() * 1.5) * s, d = (1.4 + c.rng() * 0.8) * s, h = (1 + c.rng() * 0.6) * s;
  c.box("metal", w, h, d, x, y, z, 0xb9c0c5, { ry, ao: 1.2 });
  c.box("metal", w * 0.9, 0.06, d * 0.9, x, y + h, z, 0x8b939a, { ry });
  const fr = Math.min(w, d) * 0.32; c.cyl("metal", fr, 0.1, x, y + h + 0.06, z, 0x3a4047, { seg: 12 });
  for (let i = 0; i < 4; i++) c.box("metal", fr * 2 * 0.9, 0.025, 0.04, x, y + h + 0.12, z, 0x5b636b, { ry: ry + i * Math.PI / 4 });
  c.box("paint", 0.5, h * 0.6, 0.06, x, y + 0.1, z + d / 2 + 0.01, 0x969da3, { ry });
}
export function waterTank(c: ChunkCtx, x: number, y: number, z: number, s = 1) {
  for (const [dx, dz] of [[-0.9, -0.9], [0.9, -0.9], [-0.9, 0.9], [0.9, 0.9]]) c.box("metal", 0.14 * s, 2.4 * s, 0.14 * s, x + dx * s, y, z + dz * s, 0x6a5a48);
  c.box("metal", 2.2 * s, 0.1 * s, 2.2 * s, x, y + 2.4 * s, z, 0x5f5040);
  c.cyl("paint", 1.25 * s, 2.4 * s, x, y + 2.5 * s, z, 0x8c6a46, { seg: 14 });
  for (let i = 0; i < 3; i++) c.cyl("metal", 1.27 * s, 0.07 * s, x, y + (3.0 + i * 0.8) * s, z, 0x4a3d30, { seg: 14 });
  c.cone("paint", 1.38 * s, 0.9 * s, x, y + 4.9 * s, z, 0x6e553a, 14);
}
export function antenna(c: ChunkCtx, x: number, y: number, z: number, h = 12) {
  c.cyl("metal", 0.12, h, x, y, z, 0x7a828a, { rTop: 0.04, seg: 6 });
  for (let i = 1; i <= 4; i++) c.box("metal", 1.4 - i * 0.22, 0.05, 0.05, x, y + h * (0.35 + i * 0.13), z, 0x7a828a);
  c.glow(0.12, x, y + h + 0.1, z, 0xff3a2f);
}

export function billboard(c: ChunkCtx, x: number, y: number, z: number, w: number, h: number, ry: number, spec: { text: string; bg: string; fg: string; sub?: string; special?: "nexus" }) {
  // two posts + frame + sign
  c.box("metal", 0.25, y, 0.25, x - w * 0.3, 0, z, 0x59626b); c.box("metal", 0.25, y, 0.25, x + w * 0.3, 0, z, 0x59626b);
  c.box("metal", w + 0.3, h + 0.3, 0.22, x, y, z, 0x3d444b, { ry });
  c.sign({ ...spec, w, h, x, y: y + h / 2, z, ry });
  c.box("metal", w, 0.1, 0.5, x, y + h + 0.1, z + 0.12, 0x2e343a, { ry });
}
export function bollards(c: ChunkCtx, x: number, z0: number, z1: number, step = 3, color = 0xf2c230) {
  for (let z = z0; z >= z1; z -= step) { c.cyl("paint", 0.09, 0.8, x, 0, z, color, { seg: 6 }); c.cyl("paint", 0.092, 0.12, x, 0.5, z, 0x222222, { seg: 6 }); }
}
export function scaffold(c: ChunkCtx, x: number, z: number, w = 3, h = 8, d = 2.2, floors = 4) {
  for (const [dx, dz] of [[-w / 2, -d / 2], [w / 2, -d / 2], [-w / 2, d / 2], [w / 2, d / 2]]) c.box("metal", 0.1, h, 0.1, x + dx, 0, z + dz, 0xb8a050);
  for (let i = 1; i <= floors; i++) { const y = (h / floors) * i; c.box("metal", w, 0.1, d, x, y - 0.1, z, 0x8a7a45); c.box("metal", w, 0.06, 0.06, x, y + 0.9, z - d / 2, 0xb8a050); c.box("metal", w, 0.06, 0.06, x, y + 0.9, z + d / 2, 0xb8a050); }
  c.box("paint", w, h * 0.5, 0.03, x, 0.3, z + d / 2 + 0.05, 0x3d6b8f);   // sheeting
}
export function container(c: ChunkCtx, x: number, y: number, z: number, ry = 0, color?: number) {
  const col = color ?? PAL.containers[Math.floor(c.rng() * PAL.containers.length)];
  c.b.add("corrugated", G.box(2.5, 2.6, 6, 2.5), mat(x, y + 1.3, z, 0, ry, 0), { color: col, aoHeight: 1.2 });
  c.box("metal", 2.6, 0.12, 6.1, x, y, z, 0x3a3f44, { ry }); c.box("metal", 2.6, 0.12, 6.1, x, y + 2.55, z, 0x3a3f44, { ry });
}
export function pipeRun(c: ChunkCtx, x: number, y: number, z0: number, z1: number, r = 0.35, color = 0x8a5a3a) {
  const len = Math.abs(z1 - z0), zc = (z0 + z1) / 2;
  c.pipe("metal", r, len, x, y, zc, color, "z", 10);
  for (let z = Math.min(z0, z1) + 2; z < Math.max(z0, z1); z += 6) { c.box("metal", 0.25, y, 0.25, x, 0, z, 0x555c63); c.cyl("metal", r + 0.03, 0.18, x, y - 0.09 + 0.09, z, 0x3c4248, { rz: Math.PI / 2 }); }
}
export function smokestack(c: ChunkCtx, x: number, z: number, h = 28, r = 1.6) {
  c.cyl("paint", r, h, x, 0, z, 0x9b4a3a, { rTop: r * 0.72, seg: 12, ao: 4 });
  for (let i = 0; i < 4; i++) c.cyl("paint", r * (0.95 - i * 0.07) + 0.03, 0.6, x, h * (0.45 + i * 0.12), z, i % 2 ? 0xe8e2d4 : 0xc03a2a, { rTop: r * (0.95 - i * 0.07) + 0.03, seg: 12 });
  c.glow(0.2, x, h + 0.2, z, 0xff3a2f);
  c.emit({ type: "smoke", x, y: h + 0.5, z, rate: 3 });
}
export function crane(c: ChunkCtx, x: number, z: number, h = 18, span = 16) {
  // gantry crane straddling the road side
  c.box("metal", 0.6, h, 0.6, x - span / 2, 0, z, 0xe0a32a, { ao: 3 }); c.box("metal", 0.6, h, 0.6, x + span / 2, 0, z, 0xe0a32a, { ao: 3 });
  c.box("metal", span + 1.2, 0.9, 1.0, x, h, z, 0xe0a32a); c.box("metal", span + 1.2, 0.2, 1.3, x, h + 0.9, z, 0x3a3f44);
  for (let i = 0; i < 6; i++) { c.box("metal", 0.12, h * 0.3, 0.12, x - span / 2 + 0.3, h * 0.1 + i * 0.1, z, 0xc88a1e, { rz: 0.5 * (i % 2 ? 1 : -1) }); }
  c.box("metal", 1.4, 0.8, 1.4, x + 1, h - 0.9, z, 0x3a3f44); c.box("metal", 0.05, h * 0.35, 0.05, x + 1, h * 0.55, z, 0x222a30);
  c.box("paint", 0.7, 0.45, 0.7, x + 1, h * 0.55 - 0.45, z, 0xd8493a);
  c.glow(0.15, x - span / 2, h + 0.3, z, 0xff3a2f); c.glow(0.15, x + span / 2, h + 0.3, z, 0xff3a2f);
}
export function rubble(c: ChunkCtx, x: number, z: number, s = 1) {
  const rng = c.rng;
  for (let i = 0; i < 5 + Math.floor(rng() * 4); i++) c.ico("stone", (0.3 + rng() * 0.5) * s, x + (rng() - 0.5) * 2.4 * s, 0.2 * s, z + (rng() - 0.5) * 2.4 * s, [0x8c887c, 0x7a766b, 0x9a958a][i % 3], 1 + rng(), 0.6 + rng() * 0.5, 1 + rng(), rng() * 3, 0);
}
export function bush(c: ChunkCtx, x: number, z: number, s = 1) { for (let i = 0; i < 3; i++) c.sphere("foliage", (0.5 + c.rng() * 0.3) * s, x + (c.rng() - 0.5) * s, 0.45 * s, z + (c.rng() - 0.5) * s, PAL.foliage[Math.floor(c.rng() * 5)], 1, 0.8, 1, { ws: 6, hs: 5 }); }
export function vine(c: ChunkCtx, x: number, yTop: number, z: number, len: number) {
  c.cyl("foliage", 0.04, len, x, yTop - len, z, 0x3f6a35, { seg: 4 });
  for (let i = 0; i < 5; i++) c.sphere("foliage", 0.16, x + (c.rng() - 0.5) * 0.3, yTop - len * (0.15 + i * 0.18), z + (c.rng() - 0.5) * 0.3, 0x58a24a, 1, 0.4, 1, { ws: 5, hs: 4 });
}
export function stoneArch(c: ChunkCtx, z: number, span = 12, h = 7.5) {
  for (const s of [-1, 1]) { c.box("stone", 1.8, h, 1.8, s * span / 2, 0, z, 0xb4ae9e, { tile: 2.5, ao: 3 }); c.box("stone", 2.3, 0.5, 2.3, s * span / 2, 0, z, 0x948e80, { tile: 2.5 }); c.box("stone", 2.2, 0.5, 2.2, s * span / 2, h, z, 0xa39d8e, { tile: 2.5 }); }
  const seg = 9; for (let i = 0; i <= seg; i++) { const a = Math.PI * (i / seg); const px = Math.cos(a) * span / 2, py = h + Math.sin(a) * 3.2; c.box("stone", 1.7, 1.0, 1.7, px, py - 0.5, z, 0xb4ae9e, { ry: 0, rz: a - Math.PI / 2 + Math.PI / 2, tile: 2.5 }); }
}
export function bench(c: ChunkCtx, x: number, z: number, ry = 0) { c.box("paint", 1.8, 0.1, 0.5, x, 0.45, z, 0x8c6a46, { ry }); c.box("paint", 1.8, 0.4, 0.08, x, 0.55, z + (ry ? 0 : 0.22), 0x8c6a46, { ry }); c.box("metal", 0.1, 0.45, 0.45, x - 0.8, 0, z, 0x3a3f44, { ry }); c.box("metal", 0.1, 0.45, 0.45, x + 0.8, 0, z, 0x3a3f44, { ry }); }
export function cabinet(c: ChunkCtx, x: number, z: number, ry = 0, color = 0x6f7b85) {
  c.box("metal", 1.0, 1.9, 0.5, x, 0, z, color, { ry }); c.box("emissive", 0.12, 0.12, 0.02, x + 0.25, 1.4, z + 0.26, 0x44ff88, { ry }); c.box("emissive", 0.12, 0.12, 0.02, x + 0.05, 1.4, z + 0.26, 0xffb02e, { ry });
  c.box("paint", 0.6, 0.35, 0.02, x, 0.9, z + 0.26, 0xf2c230, { ry }); // hazard plate
}
export function exitSign(c: ChunkCtx, x: number, y: number, z: number, ry: number) { c.box("emissive", 0.9, 0.3, 0.06, x, y, z, 0x38e07a, { ry }); c.box("metal", 0.96, 0.36, 0.04, x, y - 0.03, z - 0.03 * Math.sign(Math.cos(ry) || 1), 0x1f2a24, { ry }); }
export function car(c: ChunkCtx, x: number, z: number, ry: number, color: number, y = 0, s = 1) {
  // low-poly sedan, fits in ~4.2 x 1.8 m
  const m = (px: number, py: number, pz: number) => { const cs = Math.cos(ry), sn = Math.sin(ry); return [x + (px * cs + pz * sn) * s, y + py * s, z + (-px * sn + pz * cs) * s]; };
  const add = (mk: string, w: number, h: number, d: number, px: number, py: number, pz: number, col: number, rx = 0) => { const [a, b, cc] = m(px, py + h / 2, pz); c.b.add(mk, G.box(w * s, h * s, d * s, 2), mat(a, b, cc, rx, ry, 0), { color: col }); };
  add("paint", 1.8, 0.55, 4.2, 0, 0.35, 0, color); add("paint", 1.6, 0.5, 2.1, 0, 0.9, 0.1, color); add("glass", 1.62, 0.42, 2.0, 0, 0.92, 0.1, 0x223344);
  add("rubber", 1.9, 0.18, 4.3, 0, 0.22, 0, 0x1c1f22);
  for (const sx of [-0.85, 0.85]) for (const sz of [-1.3, 1.3]) { const [a, b, cc] = m(sx, 0.34, sz); c.b.add("rubber", G.cyl(0.34 * s, 0.34 * s, 0.24 * s, 10), mat(a, b, cc, 0, ry, Math.PI / 2), { color: 0x15171a }); }
  add("emissive", 1.3, 0.12, 0.05, 0, 0.55, -2.12, 0xff3d2e); add("emissive", 1.3, 0.12, 0.05, 0, 0.55, 2.12, 0xfff2c4);
}
export function truck(c: ChunkCtx, x: number, z: number, ry: number, color: number, y = 0) {
  const cs = Math.cos(ry), sn = Math.sin(ry);
  const add = (mk: string, w: number, h: number, d: number, px: number, py: number, pz: number, col: number) => c.b.add(mk, G.box(w, h, d, 2.5), mat(x + px * cs + pz * sn, y + py + h / 2, z - px * sn + pz * cs, 0, ry, 0), { color: col });
  add("paint", 2.4, 3.0, 7.5, 0, 0.6, 1.6, 0xe8e6e0); add("paint", 2.3, 2.1, 2.1, 0, 0.6, -3.1, color); add("glass", 2.0, 0.8, 0.05, 0, 1.7, -4.18, 0x223344); add("rubber", 2.5, 0.45, 11, 0, 0.35, -0.2, 0x1c1f22);
  add("emissive", 0.4, 0.2, 0.05, -0.8, 0.9, -4.2, 0xfff2c4); add("emissive", 0.4, 0.2, 0.05, 0.8, 0.9, -4.2, 0xfff2c4);
}
export function tower(c: ChunkCtx, x: number, z: number, w: number, d: number, h: number, kind: "glass" | "brick" | "concrete" | "industrial" | "stone", color: number, yBase = 0, crown = true) {
  c.b.add("facade_" + kind, G.box(w, h, d, 12), mat(x, yBase + h / 2, z), { color, aoHeight: 10, aoStrength: 0.5 });
  c.box("concrete", w + 0.3, 0.5, d + 0.3, x, yBase + h, z, 0x9a9a95, { tile: 3 });
  if (crown) {
    const r = c.rng();
    if (r < 0.35) { c.box("metal", w * 0.5, 2.5, d * 0.5, x, yBase + h + 0.5, z, 0x8b939a); c.cyl("metal", 0.1, 6 + c.rng() * 8, x + (c.rng() - 0.5) * w * 0.3, yBase + h + 3, z, 0x7a828a, { rTop: 0.04, seg: 5 }); }
    else if (r < 0.6) { for (let i = 0; i < 2; i++) c.box("metal", w * 0.3, 1.4, d * 0.3, x + (i ? 1 : -1) * w * 0.22, yBase + h + 0.5, z, 0xb9c0c5); }
    else if (r < 0.75) c.cone("paint", Math.min(w, d) * 0.4, 5, x, yBase + h + 0.5, z, 0x6a7380, 4);
  }
}
