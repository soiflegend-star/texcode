/**
 * CharacterAnimator — procedural animation for all 17 states. Pose targets are computed analytically and
 * damped for smooth blends; per-character personality scales stride, bounce, arm swing and lean.
 */
import * as THREE from "three";
import { POSE_KEYS, PoseKey, Rig } from "./CharacterFactory.js";
import { clamp, dampTo } from "../util/rng.js";

export type AnimState = "idle" | "run" | "sprint" | "jump" | "doubleJump" | "fall" | "land" | "slide" | "hit" | "damage" | "death" | "boost" | "railGrind" | "wallRun" | "airDash" | "grapple" | "victory";
export const ANIM_STATES: AnimState[] = ["idle", "run", "sprint", "jump", "doubleJump", "fall", "land", "slide", "hit", "damage", "death", "boost", "railGrind", "wallRun", "airDash", "grapple", "victory"];

export interface AnimInput { state: AnimState; speed: number; vy: number; laneVel: number; wallSide: number; timeInState: number; t: number }

/** Per-character animation personality. */
export const PERSONALITY: Record<string, { stride: number; bounce: number; arm: number; lean: number; cadence: number; sprintLean: number; slideDrop: number; jumpTuck: number; flip: boolean }> = {
  runner:    { stride: 1.0, bounce: 1.0, arm: 1.0, lean: 1.0, cadence: 1.0, sprintLean: 1.0, slideDrop: 1.0, jumpTuck: 1.0, flip: false },
  acrobat:   { stride: 0.95, bounce: 1.2, arm: 0.8, lean: 0.9, cadence: 1.05, sprintLean: 0.9, slideDrop: 0.9, jumpTuck: 1.4, flip: true },
  speedster: { stride: 1.2, bounce: 0.75, arm: 1.15, lean: 1.5, cadence: 1.2, sprintLean: 1.6, slideDrop: 1.0, jumpTuck: 0.8, flip: false },
  heavy:     { stride: 0.8, bounce: 1.35, arm: 0.75, lean: 0.55, cadence: 0.82, sprintLean: 0.6, slideDrop: 1.1, jumpTuck: 0.6, flip: false },
  ninja:     { stride: 1.0, bounce: 0.7, arm: 0.45, lean: 1.3, cadence: 1.1, sprintLean: 1.3, slideDrop: 1.25, jumpTuck: 1.1, flip: true },
  rival:     { stride: 1.0, bounce: 1.0, arm: 1.0, lean: 1.0, cadence: 1.0, sprintLean: 1.0, slideDrop: 1.0, jumpTuck: 1.0, flip: false },
};

const ZERO = (): Record<PoseKey, number> => { const o = {} as Record<PoseKey, number>; for (const k of POSE_KEYS) o[k] = 0; return o; };

export class CharacterAnimator {
  cur = ZERO(); tgt = ZERO();
  phase = 0; private flipAngle = 0; private glowT = 0; private prevState: AnimState = "idle";
  boostGlow = 0; shield = 0; invuln = 0; hitFlash = 0;
  constructor(public rig: Rig, public look: string) {}

  /** Pose targets for a state at the given time. Exposed for tests. */
  computePose(inp: AnimInput, out = ZERO()): Record<PoseKey, number> {
    const P = PERSONALITY[this.look] ?? PERSONALITY.runner;
    for (const k of POSE_KEYS) out[k] = 0;
    const ph = this.phase, s = Math.sin(ph), c = Math.cos(ph);
    const spd = clamp(inp.speed / 22, 0.4, 1.7);
    const swing = (amp: number, kneeBase: number, armAmp: number, lean: number, bounce: number) => {
      out.hipL = -s * amp * P.stride; out.hipR = s * amp * P.stride;
      out.knL = kneeBase + Math.max(0, s) * amp * 1.5 * P.stride; out.knR = kneeBase + Math.max(0, -s) * amp * 1.5 * P.stride;
      out.shL = s * armAmp * P.arm; out.shR = -s * armAmp * P.arm;
      out.elL = -1.25 - Math.max(0, -s) * 0.4 * P.arm; out.elR = -1.25 - Math.max(0, s) * 0.4 * P.arm;
      out.pitch = lean; out.rootY = Math.abs(c) * bounce * P.bounce - bounce * 0.4 * P.bounce; out.spine = lean * 0.4; out.chestTwist = s * 0.18 * P.arm; out.headP = -lean * 0.8;
      out.ankL = -Math.max(0, s) * 0.4; out.ankR = -Math.max(0, -s) * 0.4;
    };
    switch (inp.state) {
      case "idle": { const b = Math.sin(inp.t * 2) * 0.012; out.rootY = b; out.shL = 0.05; out.shR = 0.05; out.shLz = -0.08; out.shRz = 0.08; out.elL = -0.25; out.elR = -0.25; break; }
      case "run": swing(0.9 * spd, 0.25, 1.0 * spd, 0.16 * P.lean, 0.06 * spd); break;
      case "sprint": case "boost": swing(1.1 * spd, 0.35, 1.25 * spd, 0.34 * P.sprintLean, 0.05); out.headP -= 0.1; if (inp.state === "boost") { out.shL = 1.3 + s * 0.2; out.shR = 1.3 - s * 0.2; out.elL = -0.2; out.elR = -0.2; out.pitch += 0.12; } break;
      case "jump": {
        const up = inp.vy > 0; const k = clamp(inp.timeInState / 0.25, 0, 1);
        out.hipL = up ? -0.9 * P.jumpTuck : -0.35; out.knL = up ? 1.5 * P.jumpTuck : 0.5; out.hipR = up ? 0.3 : 0.25; out.knR = up ? 0.55 : 0.4;
        out.shL = up ? -2.3 : -1.5; out.shR = up ? 0.8 : -1.1; out.shLz = -0.4; out.shRz = 0.4; out.elL = -0.5; out.elR = -0.5; out.pitch = up ? 0.12 : 0.06; out.rootY = 0.0; out.ankL = 0.5 * k; out.ankR = 0.3; out.headP = -0.1;
        break;
      }
      case "doubleJump": {
        out.hipL = -1.7; out.hipR = -1.7; out.knL = 2.1; out.knR = 2.1; out.shL = -1.0; out.shR = -1.0; out.shLz = -0.3; out.shRz = 0.3; out.elL = -1.9; out.elR = -1.9; out.spine = 0.35; out.pitch = 0.1; break;
      }
      case "fall": { out.hipL = -0.5 + Math.sin(inp.t * 14) * 0.12; out.hipR = 0.25 - Math.sin(inp.t * 14) * 0.12; out.knL = 0.9; out.knR = 0.6; out.shL = -2.4; out.shR = -2.4; out.shLz = -0.55; out.shRz = 0.55; out.elL = -0.3; out.elR = -0.3; out.pitch = -0.04; out.headP = -0.1; break; }
      case "land": { const k = 1 - clamp(inp.timeInState / 0.22, 0, 1); out.rootY = -0.28 * k; out.hipL = -1.0 * k; out.hipR = -1.0 * k; out.knL = 1.9 * k; out.knR = 1.9 * k; out.pitch = 0.32 * k; out.spine = 0.3 * k; out.shL = -0.5 * k; out.shR = -0.5 * k; out.elL = -0.8 * k; out.elR = -0.8 * k; break; }
      case "slide": {
        const d = P.slideDrop; out.rootY = -0.58 * d; out.pitch = -0.95; out.spine = -0.2; out.hipL = -1.5; out.knL = 0.2; out.hipR = -0.55; out.knR = 1.5; out.shL = -1.9; out.shR = -1.7; out.elL = -0.3; out.elR = -0.3; out.shLz = -0.25; out.shRz = 0.25; out.headP = 0.6; out.roll = 0; break;
      }
      case "hit": case "damage": { const k = clamp(inp.timeInState / 0.5, 0, 1); const sh = 1 - k; out.pitch = -0.38 * sh; out.rootY = -0.1 * sh; out.shL = -0.9 * sh; out.shR = -0.9 * sh; out.elL = -0.6; out.elR = -0.6; out.hipL = -0.45 * sh + s * 0.3 * k; out.hipR = 0.3 * sh - s * 0.3 * k; out.knL = 0.6; out.knR = 0.5; out.headP = 0.4 * sh; out.roll = Math.sin(inp.t * 35) * 0.06 * sh; break; }
      case "death": { const k = clamp(inp.timeInState / 0.9, 0, 1); const e = k * k * (3 - 2 * k); out.pitch = -1.45 * e; out.rootY = -0.45 * e; out.hipL = -0.5 * e; out.hipR = 0.3 * e; out.knL = 0.8 * e; out.knR = 0.4 * e; out.shL = -1.9 * e; out.shR = -1.1 * e; out.shLz = -0.9 * e; out.shRz = 0.9 * e; out.elL = -0.6; out.elR = -0.4; out.headP = 0.5 * e; out.roll = 0.35 * e; break; }
      case "railGrind": { out.rootY = -0.12; out.pitch = 0.12; out.spine = 0.22; out.hipL = -0.45; out.hipR = 0.2; out.knL = 0.7; out.knR = 0.55; out.shL = -0.6; out.shR = -0.15; out.shLz = -1.0; out.shRz = 1.0; out.elL = -0.45; out.elR = -0.45; out.roll = Math.sin(inp.t * 3) * 0.07; out.yaw = 0.45; out.chestTwist = -0.4; break; }
      case "wallRun": { const sd = inp.wallSide || 1; out.roll = -sd * 0.7; out.pitch = 0.12; out.hipL = -s * 0.8; out.hipR = s * 0.8; out.knL = 0.4 + Math.max(0, s) * 0.9; out.knR = 0.4 + Math.max(0, -s) * 0.9; out.shL = s * 0.7; out.shR = -s * 0.7; out.shLz = -0.5; out.shRz = 0.5; out.elL = -0.9; out.elR = -0.9; out.yaw = sd * 0.35; break; }
      case "airDash": { out.pitch = 1.1 + 0.3; out.hipL = 0.3; out.hipR = 0.5; out.knL = 0.2; out.knR = 0.3; out.shL = -3.0; out.shR = -3.0; out.shLz = -0.05; out.shRz = 0.05; out.elL = 0; out.elR = 0; out.headP = -0.6; out.spine = -0.1; break; }
      case "grapple": { out.pitch = 0.1; out.shR = -2.6; out.shRz = 0.15; out.elR = -0.15; out.shL = 0.5; out.elL = -1.3; out.hipL = -0.8 + s * 0.15; out.hipR = 0.15; out.knL = 1.1; out.knR = 0.5; out.spine = -0.12; out.roll = -0.12; break; }
      case "victory": { const j = Math.abs(Math.sin(inp.t * 4)); out.rootY = j * 0.16; out.shL = -2.9 + Math.sin(inp.t * 8) * 0.12; out.shR = -2.9 - Math.sin(inp.t * 8) * 0.12; out.shLz = -0.4; out.shRz = 0.4; out.elL = -0.3; out.elR = -0.3; out.hipL = -0.1 * j; out.hipR = 0.1 * j; out.knL = 0.2 + j * 0.4; out.knR = 0.2 + j * 0.4; out.yaw = Math.sin(inp.t * 1.5) * 0.5; out.headP = -0.1; break; }
    }
    // lane-change lean (additive; ninja/speedster lean harder)
    if (inp.state !== "wallRun" && inp.state !== "railGrind" && inp.state !== "death" && inp.state !== "slide") { out.roll += clamp(-inp.laneVel * 0.05, -0.45, 0.45) * P.lean; out.yaw += clamp(-inp.laneVel * 0.03, -0.3, 0.3); }
    return out;
  }

  update(dt: number, inp: AnimInput) {
    const P = PERSONALITY[this.look] ?? PERSONALITY.runner;
    const run = inp.state === "run" || inp.state === "sprint" || inp.state === "boost" || inp.state === "wallRun";
    if (run) this.phase += dt * (6.2 + inp.speed * 0.42) * P.cadence;
    else this.phase += dt * 6;
    const tgt = this.computePose(inp, this.tgt);
    // acrobat/ninja flips on double jump
    if (inp.state === "doubleJump" && P.flip) this.flipAngle += dt * 13; else if (inp.state !== "doubleJump") this.flipAngle = 0;
    const rate = inp.state === "death" || inp.state === "hit" || inp.state === "damage" || inp.state === "land" ? 26 : inp.state === "slide" ? 22 : 16;
    for (const k of POSE_KEYS) this.cur[k] = dampTo(this.cur[k], tgt[k], rate, dt);
    this.applyPose(inp);
    this.prevState = inp.state;
  }

  private applyPose(inp: AnimInput) {
    const r = this.rig, c = this.cur;
    r.body.position.y = c.rootY; r.body.rotation.set(-c.pitch - (this.flipAngle ? this.flipAngle : 0), c.yaw, c.roll);
    if (this.flipAngle) { r.body.position.y += 0.55; r.body.rotation.x = this.flipAngle; }
    r.hips.rotation.set(0, 0, 0); r.spine.rotation.set(-c.spine, 0, 0); r.chest.rotation.set(0, c.chestTwist, 0); r.head.rotation.set(c.headP, -c.chestTwist * 0.6 + c.headY, 0);
    r.shL.rotation.set(c.shL, 0, c.shLz); r.shR.rotation.set(c.shR, 0, c.shRz); r.elL.rotation.set(c.elL, 0, 0); r.elR.rotation.set(c.elR, 0, 0);
    r.hipL.rotation.set(c.hipL, 0, c.hipLz); r.hipR.rotation.set(c.hipR, 0, c.hipRz); r.knL.rotation.set(c.knL, 0, 0); r.knR.rotation.set(c.knR, 0, 0); r.ankL.rotation.set(c.ankL, 0, 0); r.ankR.rotation.set(c.ankR, 0, 0);
    // secondary motion (scarf / ponytail / sash)
    const wind = clamp(inp.speed / 20, 0.2, 1.8);
    for (const t of r.trails) { const a = t.amp * (0.4 + wind * 0.5) * Math.sin(inp.t * 7 + t.phase); if (t.axis === "x") t.node.rotation.x = 0.55 + wind * 0.25 + a * 0.3; else t.node.rotation.y = a * 0.5; t.node.rotation.z = Math.sin(inp.t * 5 + t.phase) * 0.12; }
    // glow shell
    const g = r.glow; if (g) {
      const want = Math.max(this.boostGlow, this.shield * 0.6, this.invuln * 0.8, this.hitFlash);
      this.glowT = dampTo(this.glowT, want, 12, 1 / 60); g.visible = this.glowT > 0.02;
      const m = g.material as THREE.MeshBasicMaterial; m.opacity = this.glowT * (0.2 + 0.1 * Math.sin(inp.t * 12));
      m.color.setHex(this.hitFlash > 0.05 ? 0xff4040 : this.invuln > 0.05 ? 0xc58bff : this.boostGlow > 0.05 ? 0xffd23f : 0x4fc3ff);
    }
  }
}
