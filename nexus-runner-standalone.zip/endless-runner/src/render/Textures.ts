/**
 * Textures — every texture in the game is generated procedurally on a 2D canvas
 * (no external image files). Height maps are converted to tangent-space normal maps on the CPU.
 * Replace any of these with real image assets by editing Materials.ts (see docs/ARCHITECTURE.md).
 */
import * as THREE from "three";
import { makeRng, Rng } from "../util/rng.js";

export type Cnv = HTMLCanvasElement;
export function canvas(w: number, h = w): Cnv { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; }
const ctx2 = (c: Cnv) => c.getContext("2d")!;

function finish(c: Cnv, opts: { repeat?: [number, number]; srgb?: boolean; aniso?: number } = {}): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (opts.repeat) t.repeat.set(opts.repeat[0], opts.repeat[1]);
  t.colorSpace = opts.srgb === false ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  t.anisotropy = opts.aniso ?? 4;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.needsUpdate = true;
  return t;
}

function grain(g: CanvasRenderingContext2D, w: number, h: number, rng: Rng, n: number, a: number, light = false) {
  for (let i = 0; i < n; i++) {
    const v = light ? 200 + rng() * 55 : rng() * 70;
    g.fillStyle = `rgba(${v | 0},${v | 0},${v | 0},${a * rng()})`;
    const s = 1 + rng() * 2.4; g.fillRect(rng() * w, rng() * h, s, s);
  }
}

/** Convert a grayscale height canvas into a normal-map texture (Sobel). */
export function normalFromHeight(src: Cnv, strength = 2.2): THREE.CanvasTexture {
  const w = src.width, h = src.height;
  const data = ctx2(src).getImageData(0, 0, w, h).data;
  const out = canvas(w, h); const og = ctx2(out); const img = og.createImageData(w, h);
  const H = (x: number, y: number) => data[(((y + h) % h) * w + ((x + w) % w)) * 4] / 255;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const dx = (H(x + 1, y) - H(x - 1, y)) * strength, dy = (H(x, y + 1) - H(x, y - 1)) * strength;
    const inv = 1 / Math.sqrt(dx * dx + dy * dy + 1);
    const i = (y * w + x) * 4;
    img.data[i] = (-dx * inv * 0.5 + 0.5) * 255; img.data[i + 1] = (dy * inv * 0.5 + 0.5) * 255; img.data[i + 2] = (inv * 0.5 + 0.5) * 255; img.data[i + 3] = 255;
  }
  og.putImageData(img, 0, 0);
  return finish(out, { srgb: false });
}

// ───────────────────────── Roads ─────────────────────────
export type RoadKind = "city" | "highway" | "subway" | "industrial" | "ruins";
/** Road texture spans the full road width (u: 0..1 = 8.8 m) and 8 m of length (v). */
export function roadTextures(kind: RoadKind, size: number, aniso: number) {
  const w = size, h = size; const c = canvas(w, h), hc = canvas(w, h); const g = ctx2(c), hg = ctx2(hc);
  const rng = makeRng("road_" + kind);
  const base: Record<RoadKind, string> = { city: "#3b4047", highway: "#33383e", subway: "#4a4540", industrial: "#46484b", ruins: "#4d4f4a" };
  g.fillStyle = base[kind]; g.fillRect(0, 0, w, h);
  hg.fillStyle = "#808080"; hg.fillRect(0, 0, w, h);
  // aggregate noise
  for (let i = 0; i < w * h / 6; i++) { const v = 40 + rng() * 60 | 0; g.fillStyle = `rgba(${v},${v},${v + 4},${0.18 * rng()})`; const s = 1 + rng() * 2; g.fillRect(rng() * w, rng() * h, s, s); const hv = 100 + rng() * 80 | 0; hg.fillStyle = `rgb(${hv},${hv},${hv})`; hg.fillRect(rng() * w, rng() * h, s, s); }
  // tyre-wear darker bands along each lane
  const px = (m: number) => (m / 8.8) * w;       // metres across → px
  const laneW = 2.4;
  for (const lx of [-laneW, 0, laneW]) {
    for (const off of [-0.7, 0.7]) { const x = px(4.4 + lx + off); const gr = g.createLinearGradient(x - px(0.45), 0, x + px(0.45), 0); gr.addColorStop(0, "rgba(0,0,0,0)"); gr.addColorStop(0.5, "rgba(0,0,0,0.16)"); gr.addColorStop(1, "rgba(0,0,0,0)"); g.fillStyle = gr; g.fillRect(x - px(0.45), 0, px(0.9), h); }
  }
  // oil stains / patches
  const patches = kind === "industrial" ? 14 : kind === "subway" ? 4 : 6;
  for (let i = 0; i < patches; i++) { g.fillStyle = `rgba(10,10,12,${0.1 + rng() * 0.12})`; g.beginPath(); g.ellipse(rng() * w, rng() * h, 6 + rng() * 22, 4 + rng() * 14, rng() * 3, 0, 7); g.fill(); }
  // lane markings
  const dash = (x: number, color: string, width: number, dashLen: number, gap: number) => { g.fillStyle = color; for (let y = 0; y < h; y += dashLen + gap) g.fillRect(x - width / 2, y, width, dashLen); };
  const solid = (x: number, color: string, width: number) => { g.fillStyle = color; g.fillRect(x - width / 2, 0, width, h); };
  const wl = size / 512;
  if (kind === "city" || kind === "highway" || kind === "industrial") {
    const white = "rgba(238,238,232,0.92)";
    dash(px(4.4 - laneW / 2), white, 7 * wl, h * 0.28, h * 0.22); dash(px(4.4 + laneW / 2), white, 7 * wl, h * 0.28, h * 0.22);
    const edge = kind === "highway" ? "rgba(240,196,60,0.95)" : kind === "industrial" ? "rgba(240,196,60,0.9)" : white;
    solid(px(4.4 - laneW * 1.5 - 0.15), edge, 6 * wl); solid(px(4.4 + laneW * 1.5 + 0.15), edge, 6 * wl);
    // paint wear
    for (let i = 0; i < 260; i++) { g.fillStyle = `rgba(${base[kind] === "" ? 0 : 60},62,68,${0.25 * rng()})`; g.fillRect(rng() * w, rng() * h, 2 + rng() * 6, 2 + rng() * 6); }
  } else if (kind === "ruins") {
    // cracks & moss on broken tarmac
    g.strokeStyle = "rgba(15,15,15,0.7)"; hg.strokeStyle = "#101010"; g.lineWidth = 1.5 * wl; hg.lineWidth = 3 * wl;
    for (let i = 0; i < 18; i++) { let x = rng() * w, y = rng() * h; g.beginPath(); hg.beginPath(); g.moveTo(x, y); hg.moveTo(x, y); for (let k = 0; k < 7; k++) { x += (rng() - 0.5) * 60; y += (rng() - 0.3) * 50; g.lineTo(x, y); hg.lineTo(x, y); } g.stroke(); hg.stroke(); }
    for (let i = 0; i < 50; i++) { g.fillStyle = `rgba(${50 + rng() * 30 | 0},${90 + rng() * 40 | 0},${40 + rng() * 20 | 0},${0.25 + rng() * 0.3})`; g.beginPath(); g.ellipse(rng() * w, rng() * h, 4 + rng() * 18, 3 + rng() * 10, rng() * 3, 0, 7); g.fill(); }
    g.fillStyle = "rgba(220,220,210,0.35)"; dash(px(4.4 - laneW / 2), "rgba(220,220,210,0.35)", 6 * wl, h * 0.25, h * 0.25);
    dash(px(4.4 + laneW / 2), "rgba(220,220,210,0.35)", 6 * wl, h * 0.25, h * 0.25);
  } else { // subway track bed: ballast
    for (let i = 0; i < w * h / 14; i++) { const v = 70 + rng() * 80 | 0; g.fillStyle = `rgba(${v},${v - 4},${v - 10},0.55)`; g.fillRect(rng() * w, rng() * h, 2 + rng() * 3, 2 + rng() * 3); }
  }
  // soft darkening at the road edges (baked AO against the curb)
  const e = g.createLinearGradient(0, 0, w, 0); e.addColorStop(0, "rgba(0,0,0,0.38)"); e.addColorStop(0.05, "rgba(0,0,0,0)"); e.addColorStop(0.95, "rgba(0,0,0,0)"); e.addColorStop(1, "rgba(0,0,0,0.38)");
  g.fillStyle = e; g.fillRect(0, 0, w, h);
  const map = finish(c, { aniso }); const normal = normalFromHeight(hc, 1.6); normal.anisotropy = aniso;
  return { map, normal };
}

// ───────────────────────── Facades ─────────────────────────
export type FacadeKind = "glass" | "brick" | "concrete" | "industrial" | "stone";
/** One tile = 4 columns × 4 rows of windows (tile is meant to be 12 m wide × 14 m tall). */
export function facadeTextures(kind: FacadeKind, size: number, aniso: number) {
  const c = canvas(size), e = canvas(size); const g = ctx2(c), eg = ctx2(e); const rng = makeRng("facade_" + kind);
  const cols = 4, rows = 4, cw = size / cols, ch = size / rows;
  const wall: Record<FacadeKind, string> = { glass: "#5f7a8c", brick: "#a5543f", concrete: "#c9c3b6", industrial: "#8d9298", stone: "#9a9588" };
  g.fillStyle = wall[kind]; g.fillRect(0, 0, size, size);
  eg.fillStyle = "#000"; eg.fillRect(0, 0, size, size);
  // wall texture
  if (kind === "brick") { for (let y = 0; y < size; y += size / 64) { g.fillStyle = "rgba(255,255,255,0.10)"; g.fillRect(0, y, size, 1); for (let x = ((y / (size / 64)) % 2) * 6; x < size; x += size / 16) { g.fillStyle = "rgba(0,0,0,0.18)"; g.fillRect(x, y, 1, size / 64); } } }
  grain(g, size, size, rng, size * 6, 0.12);
  if (kind === "industrial") { for (let x = 0; x < size; x += size / 64) { g.fillStyle = "rgba(0,0,0,0.13)"; g.fillRect(x, 0, 2, size); g.fillStyle = "rgba(255,255,255,0.07)"; g.fillRect(x + 2, 0, 1, size); } }
  for (let r = 0; r < rows; r++) for (let col = 0; col < cols; col++) {
    const x = col * cw, y = r * ch; const lit = rng() < 0.42; const warm = rng() < 0.7;
    if (kind === "glass") {
      const gr = g.createLinearGradient(x, y, x + cw, y + ch); gr.addColorStop(0, "#8fc4e8"); gr.addColorStop(0.5, "#5a8fb8"); gr.addColorStop(1, "#2f5f86");
      g.fillStyle = gr; g.fillRect(x + 2, y + ch * 0.12, cw - 4, ch * 0.76);
      g.fillStyle = "rgba(255,255,255,0.35)"; g.beginPath(); g.moveTo(x + 4, y + ch * 0.12); g.lineTo(x + cw * 0.5, y + ch * 0.12); g.lineTo(x + 4, y + ch * 0.55); g.fill();
      g.fillStyle = "#2c3640"; g.fillRect(x, y + ch * 0.88, cw, ch * 0.12); g.fillRect(x, y, 2, ch);
      if (lit) { eg.fillStyle = warm ? "#ffd58a" : "#bfe6ff"; eg.fillRect(x + 4, y + ch * 0.14, cw - 8, ch * 0.72); }
    } else {
      const wx = x + cw * 0.2, wy = y + ch * 0.18, ww = cw * 0.6, wh = ch * 0.58;
      g.fillStyle = kind === "brick" ? "#e8e2d2" : "#6d747b"; g.fillRect(wx - 3, wy - 3, ww + 6, wh + 6);   // frame
      const gr = g.createLinearGradient(wx, wy, wx + ww, wy + wh); gr.addColorStop(0, "#8ab3d1"); gr.addColorStop(1, "#3d6786");
      g.fillStyle = gr; g.fillRect(wx, wy, ww, wh);
      g.fillStyle = "rgba(20,30,40,0.55)"; g.fillRect(wx + ww / 2 - 1, wy, 2, wh); g.fillRect(wx, wy + wh / 2 - 1, ww, 2);  // mullions
      g.fillStyle = "rgba(0,0,0,0.25)"; g.fillRect(wx - 3, wy + wh + 3, ww + 6, 4); // sill shadow
      if (lit) { eg.fillStyle = warm ? "#ffcf7a" : "#cde9ff"; eg.fillRect(wx, wy, ww, wh); }
    }
  }
  // floor lines
  g.fillStyle = "rgba(0,0,0,0.12)"; for (let r = 0; r < rows; r++) g.fillRect(0, r * ch, size, 2);
  return { map: finish(c, { aniso }), emissive: finish(e, { aniso }) };
}

// ───────────────────────── Misc surfaces ─────────────────────────
export function tileTexture(kind: "subway" | "sidewalk" | "plaza", size: number, aniso: number) {
  const c = canvas(size), hc = canvas(size); const g = ctx2(c), hg = ctx2(hc); const rng = makeRng("tile_" + kind);
  hg.fillStyle = "#c0c0c0"; hg.fillRect(0, 0, size, size);
  if (kind === "subway") {
    g.fillStyle = "#d8dcd8"; g.fillRect(0, 0, size, size); const n = 8, t = size / n;
    for (let y = 0; y < n * 2; y++) for (let x = 0; x < n; x++) { const v = 214 + rng() * 22 | 0; g.fillStyle = `rgb(${v},${v + 3},${v})`; g.fillRect(x * t + 1, y * (t / 2) + 1, t - 2, t / 2 - 2); }
    g.fillStyle = "rgba(60,60,55,0.5)"; for (let i = 0; i <= n * 2; i++) g.fillRect(0, i * (t / 2), size, 1.5); for (let i = 0; i <= n; i++) g.fillRect(i * t, 0, 1.5, size);
    hg.fillStyle = "#303030"; for (let i = 0; i <= n * 2; i++) hg.fillRect(0, i * (t / 2), size, 2); for (let i = 0; i <= n; i++) hg.fillRect(i * t, 0, 2, size);
    g.fillStyle = "#2e8fa0"; g.fillRect(0, size * 0.42, size, size * 0.06);
    const dirt = g.createLinearGradient(0, size, 0, size * 0.6); dirt.addColorStop(0, "rgba(40,36,30,0.45)"); dirt.addColorStop(1, "rgba(40,36,30,0)"); g.fillStyle = dirt; g.fillRect(0, size * 0.6, size, size * 0.4);
  } else {
    const n = 4, t = size / n; g.fillStyle = kind === "plaza" ? "#a39b8e" : "#b8b2a6"; g.fillRect(0, 0, size, size);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) { const v = (rng() - 0.5) * 24; g.fillStyle = `rgba(${v > 0 ? 255 : 0},${v > 0 ? 255 : 0},${v > 0 ? 255 : 0},${Math.abs(v) / 100})`; g.fillRect(x * t, y * t, t, t); }
    g.fillStyle = "rgba(40,38,34,0.55)"; for (let i = 0; i <= n; i++) { g.fillRect(0, i * t, size, 2); g.fillRect(i * t, 0, 2, size); }
    hg.fillStyle = "#202020"; for (let i = 0; i <= n; i++) { hg.fillRect(0, i * t, size, 3); hg.fillRect(i * t, 0, 3, size); }
    grain(g, size, size, rng, size * 5, 0.1);
  }
  return { map: finish(c, { aniso }), normal: normalFromHeight(hc, 1.4) };
}

export function concreteTexture(size: number, aniso: number, tint = "#b9b6ae") {
  const c = canvas(size), hc = canvas(size); const g = ctx2(c), hg = ctx2(hc); const rng = makeRng("concrete" + tint);
  g.fillStyle = tint; g.fillRect(0, 0, size, size); hg.fillStyle = "#909090"; hg.fillRect(0, 0, size, size);
  grain(g, size, size, rng, size * 10, 0.2); grain(g, size, size, rng, size * 5, 0.15, true);
  for (let i = 0; i < 5; i++) { g.fillStyle = `rgba(50,50,50,${0.04 + rng() * 0.05})`; g.fillRect(rng() * size, 0, 2 + rng() * 30, size); }
  for (let i = 0; i < size * 3; i++) { const v = 100 + rng() * 120 | 0; hg.fillStyle = `rgb(${v},${v},${v})`; hg.fillRect(rng() * size, rng() * size, 2, 2); }
  return { map: finish(c, { aniso }), normal: normalFromHeight(hc, 1.2) };
}

export function corrugatedTexture(size: number, aniso: number, base = "#8f959b") {
  const c = canvas(size), hc = canvas(size); const g = ctx2(c), hg = ctx2(hc); const rng = makeRng("corr" + base);
  g.fillStyle = base; g.fillRect(0, 0, size, size);
  const n = 16; for (let i = 0; i < n; i++) { const x = (i / n) * size; const gr = g.createLinearGradient(x, 0, x + size / n, 0); gr.addColorStop(0, "rgba(255,255,255,0.22)"); gr.addColorStop(0.5, "rgba(0,0,0,0.0)"); gr.addColorStop(1, "rgba(0,0,0,0.26)"); g.fillStyle = gr; g.fillRect(x, 0, size / n, size); const hh = hg.createLinearGradient(x, 0, x + size / n, 0); hh.addColorStop(0, "#fff"); hh.addColorStop(1, "#000"); hg.fillStyle = hh; hg.fillRect(x, 0, size / n, size); }
  grain(g, size, size, rng, size * 6, 0.12);
  for (let i = 0; i < 8; i++) { g.fillStyle = `rgba(120,70,30,${0.06 + rng() * 0.1})`; g.fillRect(rng() * size, rng() * size * 0.6, 3 + rng() * 12, size * (0.1 + rng() * 0.4)); }
  return { map: finish(c, { aniso }), normal: normalFromHeight(hc, 2.2) };
}

export function grassTexture(size: number, aniso: number) {
  const c = canvas(size); const g = ctx2(c); const rng = makeRng("grass");
  g.fillStyle = "#4f7f3d"; g.fillRect(0, 0, size, size);
  for (let i = 0; i < size * 12; i++) { const gr = 70 + rng() * 90 | 0; g.fillStyle = `rgba(${40 + rng() * 40 | 0},${gr},${30 + rng() * 30 | 0},0.5)`; g.fillRect(rng() * size, rng() * size, 1.2, 2 + rng() * 5); }
  for (let i = 0; i < 40; i++) { g.fillStyle = rng() < 0.5 ? "rgba(240,235,120,0.8)" : "rgba(255,255,255,0.7)"; g.fillRect(rng() * size, rng() * size, 2, 2); }
  return finish(c, { aniso });
}

export function waterTexture(size: number, aniso: number) {
  const c = canvas(size), hc = canvas(size); const g = ctx2(c), hg = ctx2(hc); const rng = makeRng("water");
  g.fillStyle = "#2f6f7a"; g.fillRect(0, 0, size, size); hg.fillStyle = "#808080"; hg.fillRect(0, 0, size, size);
  for (let i = 0; i < 70; i++) { const x = rng() * size, y = rng() * size, r = 6 + rng() * 22; g.strokeStyle = `rgba(200,240,240,${0.12 + rng() * 0.2})`; g.lineWidth = 1.4; g.beginPath(); g.ellipse(x, y, r, r * 0.45, 0, 0, 7); g.stroke(); hg.strokeStyle = "#fff"; hg.lineWidth = 3; hg.beginPath(); hg.ellipse(x, y, r, r * 0.45, 0, 0, 7); hg.stroke(); }
  return { map: finish(c, { aniso }), normal: normalFromHeight(hc, 2) };
}

export function stoneTexture(size: number, aniso: number) {
  const c = canvas(size), hc = canvas(size); const g = ctx2(c), hg = ctx2(hc); const rng = makeRng("stone");
  g.fillStyle = "#8c887c"; g.fillRect(0, 0, size, size); hg.fillStyle = "#909090"; hg.fillRect(0, 0, size, size);
  const rows = 6; for (let r = 0; r < rows; r++) { let x = (r % 2) * 20; const y = r * (size / rows); while (x < size) { const w2 = 40 + rng() * 50; const v = 120 + rng() * 40 | 0; g.fillStyle = `rgb(${v},${v - 4},${v - 14})`; g.fillRect(x + 2, y + 2, w2 - 3, size / rows - 3); hg.fillStyle = "#101010"; hg.fillRect(x, y, 2, size / rows); hg.fillRect(x, y, w2, 2); x += w2; } }
  for (let i = 0; i < size * 3; i++) { g.fillStyle = `rgba(${50 + rng() * 30 | 0},${90 + rng() * 40 | 0},${40},${0.1 + rng() * 0.2})`; g.fillRect(rng() * size, rng() * size, 3, 3); }
  grain(g, size, size, rng, size * 5, 0.15);
  return { map: finish(c, { aniso }), normal: normalFromHeight(hc, 2.4) };
}

// ───────────────────────── Signs & decals ─────────────────────────
export function signTexture(text: string, bg: string, fg: string, w = 512, h = 256, sub?: string, accent?: string): THREE.CanvasTexture {
  const c = canvas(w, h); const g = ctx2(c);
  const gr = g.createLinearGradient(0, 0, w, h); gr.addColorStop(0, bg); gr.addColorStop(1, shade(bg, -35)); g.fillStyle = gr; g.fillRect(0, 0, w, h);
  g.strokeStyle = "rgba(255,255,255,0.85)"; g.lineWidth = Math.max(4, h * 0.03); g.strokeRect(h * 0.05, h * 0.05, w - h * 0.1, h - h * 0.1);
  g.fillStyle = fg; g.textAlign = "center"; g.textBaseline = "middle";
  const fs = Math.min(h * (sub ? 0.4 : 0.5), (w * 0.86) / Math.max(4, text.length) * 1.7);
  g.font = `900 ${fs}px system-ui, "Segoe UI", Arial, sans-serif`;
  g.fillText(text, w / 2, sub ? h * 0.42 : h * 0.52);
  if (sub) { g.font = `700 ${h * 0.14}px system-ui, Arial, sans-serif`; g.fillStyle = accent ?? fg; g.fillText(sub, w / 2, h * 0.74); }
  const t = finish(c, { aniso: 4 }); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}
function shade(hex: string, amt: number) { const n = parseInt(hex.slice(1), 16); const r = Math.max(0, Math.min(255, (n >> 16) + amt)), gg = Math.max(0, Math.min(255, ((n >> 8) & 255) + amt)), b = Math.max(0, Math.min(255, (n & 255) + amt)); return `rgb(${r},${gg},${b})`; }

/** NEXUS RUNNER style billboard artwork (italic, gradient, glow) — matches the reference screenshot. */
export function nexusBillboardTexture(): THREE.CanvasTexture {
  const w = 512, h = 640; const c = canvas(w, h); const g = ctx2(c);
  const bg = g.createLinearGradient(0, 0, w, h); bg.addColorStop(0, "#1b2f9c"); bg.addColorStop(1, "#0a1250"); g.fillStyle = bg; g.fillRect(0, 0, w, h);
  g.globalAlpha = 0.25; for (let i = 0; i < 9; i++) { g.fillStyle = "#4aa8ff"; g.beginPath(); g.moveTo(-50 + i * 80, h); g.lineTo(40 + i * 80, 0); g.lineTo(80 + i * 80, 0); g.lineTo(-10 + i * 80, h); g.fill(); } g.globalAlpha = 1;
  g.save(); g.translate(w / 2, h / 2 - 20); g.rotate(-0.12); g.textAlign = "center"; g.textBaseline = "middle";
  g.font = "italic 900 150px system-ui, Arial Black, sans-serif"; g.lineWidth = 12; g.strokeStyle = "#0a1250"; g.strokeText("NEXUS", 0, -80); g.fillStyle = "#f4f7ff"; g.fillText("NEXUS", 0, -80);
  const gr = g.createLinearGradient(0, 20, 0, 160); gr.addColorStop(0, "#ffd84a"); gr.addColorStop(1, "#ff8a1f"); g.font = "italic 900 130px system-ui, Arial Black, sans-serif"; g.strokeText("RUNNER", 0, 80); g.fillStyle = gr; g.fillText("RUNNER", 0, 80);
  g.restore(); g.strokeStyle = "rgba(255,255,255,0.9)"; g.lineWidth = 10; g.strokeRect(8, 8, w - 16, h - 16);
  const t = finish(c, { aniso: 4 }); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}

export function logoNTexture(letter = "N", color = "#111", size = 128): THREE.CanvasTexture {
  const c = canvas(size); const g = ctx2(c); g.clearRect(0, 0, size, size); g.fillStyle = color; g.font = `900 ${size * 0.85}px system-ui, Arial Black, sans-serif`; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(letter, size / 2, size / 2 + size * 0.04);
  const t = finish(c, { aniso: 4 }); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}

export function coinTexture(): THREE.CanvasTexture {
  const s = 256; const c = canvas(s); const g = ctx2(c);
  g.fillStyle = "#d9971a"; g.fillRect(0, 0, s, s);                            // (0,0) corner = plain rim colour
  const gr = g.createRadialGradient(s * 0.42, s * 0.38, s * 0.05, s / 2, s / 2, s * 0.5); gr.addColorStop(0, "#fff2a0"); gr.addColorStop(0.55, "#ffd23f"); gr.addColorStop(1, "#d9971a");
  g.fillStyle = gr; g.beginPath(); g.arc(s / 2, s / 2, s * 0.49, 0, 7); g.fill();
  g.strokeStyle = "#b8780f"; g.lineWidth = s * 0.035; g.beginPath(); g.arc(s / 2, s / 2, s * 0.4, 0, 7); g.stroke();
  g.fillStyle = "#e9a91e"; star(g, s / 2, s / 2 + 3, s * 0.27, s * 0.115); g.fill(); g.strokeStyle = "#b8780f"; g.lineWidth = 3; g.stroke();
  g.fillStyle = "#fff2b0"; star(g, s / 2 - 2, s / 2 - 3, s * 0.21, s * 0.09); g.fill();
  const t = finish(c, { aniso: 4 }); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}
function star(g: CanvasRenderingContext2D, cx: number, cy: number, ro: number, ri: number) { g.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i * Math.PI) / 5; const r = i % 2 ? ri : ro; g.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } g.closePath(); }

// ───────────────────────── Sprites / particles ─────────────────────────
export function softDot(size = 64, inner = "rgba(255,255,255,1)", outer = "rgba(255,255,255,0)"): THREE.CanvasTexture {
  const c = canvas(size); const g = ctx2(c); const gr = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2); gr.addColorStop(0, inner); gr.addColorStop(0.4, inner.replace(/[\d.]+\)$/, "0.45)")); gr.addColorStop(1, outer);
  g.fillStyle = gr; g.fillRect(0, 0, size, size); return finish(c, { aniso: 1 });
}
export function cloudTexture(seed = 1): THREE.CanvasTexture {
  const w = 256, h = 128; const c = canvas(w, h); const g = ctx2(c); const rng = makeRng("cloud" + seed);
  for (let i = 0; i < 26; i++) { const x = 40 + rng() * (w - 80), y = h * 0.55 + (rng() - 0.5) * 24 - Math.abs(x - w / 2) * 0.12, r = 16 + rng() * 26; const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, "rgba(255,255,255,0.55)"); gr.addColorStop(0.6, "rgba(255,255,255,0.22)"); gr.addColorStop(1, "rgba(255,255,255,0)"); g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2); }
  const lg = g.createLinearGradient(0, h * 0.5, 0, h); lg.addColorStop(0, "rgba(180,195,215,0)"); lg.addColorStop(1, "rgba(150,170,200,0.35)"); g.fillStyle = lg; g.globalCompositeOperation = "source-atop"; g.fillRect(0, 0, w, h);
  const t = finish(c, { aniso: 1 }); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t;
}
/** Wide skyline silhouette used as a horizon backdrop (alpha). */
export function skylineTexture(kind: "city" | "industrial" | "ruins" | "highway", color: string): THREE.CanvasTexture {
  const w = 2048, h = 256; const c = canvas(w, h); const g = ctx2(c); const rng = makeRng("skyline" + kind);
  g.fillStyle = color;
  if (kind === "city" || kind === "highway") {
    let x = 0; while (x < w) { const bw = 30 + rng() * 80, bh = 40 + rng() * (kind === "city" ? 170 : 120); g.fillRect(x, h - bh, bw, bh); if (rng() < 0.25) g.fillRect(x + bw * 0.4, h - bh - 20 - rng() * 36, 3 + rng() * 4, 40); if (rng() < 0.15) { g.beginPath(); g.moveTo(x + bw * 0.1, h - bh); g.lineTo(x + bw / 2, h - bh - 30); g.lineTo(x + bw * 0.9, h - bh); g.fill(); } x += bw - rng() * 10; }
  } else if (kind === "industrial") {
    let x = 0; while (x < w) { const bw = 60 + rng() * 120, bh = 30 + rng() * 60; g.fillRect(x, h - bh, bw, bh); if (rng() < 0.4) { const sx = x + rng() * bw; g.fillRect(sx, h - bh - 70 - rng() * 50, 14, 130); } if (rng() < 0.2) { g.fillRect(x + 10, h - bh - 40, bw - 20, 6); g.fillRect(x + 10, h - bh - 40, 5, 40); } x += bw; }
  } else { // ruins: rolling hills + broken towers + trees
    g.beginPath(); g.moveTo(0, h); for (let x = 0; x <= w; x += 16) g.lineTo(x, h - 50 - Math.sin(x * 0.006) * 28 - Math.sin(x * 0.019) * 12 - rng() * 4); g.lineTo(w, h); g.fill();
    for (let i = 0; i < 16; i++) { const x = rng() * w, bh = 60 + rng() * 80, bw = 24 + rng() * 30; g.fillRect(x, h - bh - 40, bw, bh); g.clearRect(x + bw * 0.5, h - bh - 40, bw * 0.6, 14 + rng() * 22); }
    for (let i = 0; i < 70; i++) { const x = rng() * w, r = 10 + rng() * 16; g.beginPath(); g.arc(x, h - 60 - rng() * 14, r, 0, 7); g.fill(); }
  }
  const t = finish(c, { aniso: 2 }); t.wrapS = THREE.RepeatWrapping; t.wrapT = THREE.ClampToEdgeWrapping; return t;
}
export function raindropTexture(): THREE.CanvasTexture {
  const c = canvas(8, 64); const g = ctx2(c); const gr = g.createLinearGradient(0, 0, 0, 64); gr.addColorStop(0, "rgba(200,220,255,0)"); gr.addColorStop(1, "rgba(220,235,255,0.9)"); g.fillStyle = gr; g.fillRect(3, 0, 2, 64); return finish(c, { aniso: 1 });
}
export function vignetteDataURL(): string {
  const c = canvas(256, 256); const g = ctx2(c); const gr = g.createRadialGradient(128, 128, 60, 128, 128, 190); gr.addColorStop(0, "rgba(0,0,0,0)"); gr.addColorStop(1, "rgba(8,14,30,0.55)"); g.fillStyle = gr; g.fillRect(0, 0, 256, 256); return c.toDataURL();
}
