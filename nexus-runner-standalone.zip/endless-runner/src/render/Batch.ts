/**
 * Batch — merges many small geometries into one BufferGeometry per material key.
 * Per-vertex colour carries tint + baked ambient occlusion so a handful of shared
 * materials can render a whole scenery chunk in a few draw calls.
 * No dependency on three/addons.
 */
import * as THREE from "three";
import type { MaterialLibrary } from "./Materials.js";

interface Acc { pos: number[]; nor: number[]; uv: number[]; col: number[]; idx: number[]; base: number }

const _v = new THREE.Vector3(), _n = new THREE.Vector3(), _c = new THREE.Color(), _nm = new THREE.Matrix3();
const _id = new THREE.Matrix4();

export interface AddOpts { color?: number | string; /** ambient-occlusion: darken vertices below this y (metres) */ aoHeight?: number; aoStrength?: number; uvScale?: [number, number]; flatUV?: [number, number] }

export class Batch {
  private acc = new Map<string, Acc>();
  parts = 0;

  add(matKey: string, geo: THREE.BufferGeometry, matrix: THREE.Matrix4 = _id, opts: AddOpts = {}) {
    let a = this.acc.get(matKey);
    if (!a) { a = { pos: [], nor: [], uv: [], col: [], idx: [], base: 0 }; this.acc.set(matKey, a); }
    const P = geo.getAttribute("position"), N = geo.getAttribute("normal"), U = geo.getAttribute("uv");
    const index = geo.getIndex();
    _nm.getNormalMatrix(matrix);
    _c.set(opts.color ?? 0xffffff);
    const aoH = opts.aoHeight ?? 0, aoS = opts.aoStrength ?? 0.55;
    for (let i = 0; i < P.count; i++) {
      _v.fromBufferAttribute(P, i).applyMatrix4(matrix);
      a.pos.push(_v.x, _v.y, _v.z);
      if (N) { _n.fromBufferAttribute(N, i).applyMatrix3(_nm).normalize(); a.nor.push(_n.x, _n.y, _n.z); } else a.nor.push(0, 1, 0);
      if (U) {
        let u = U.getX(i), v = U.getY(i);
        if (opts.flatUV) { u = opts.flatUV[0]; v = opts.flatUV[1]; } else if (opts.uvScale) { u *= opts.uvScale[0]; v *= opts.uvScale[1]; }
        a.uv.push(u, v);
      } else a.uv.push(0, 0);
      let k = 1;
      if (aoH > 0) { const t = Math.min(1, Math.max(0, _v.y / aoH)); k = 1 - aoS * (1 - t * t * (3 - 2 * t)); }
      a.col.push(_c.r * k, _c.g * k, _c.b * k);
    }
    if (index) for (let i = 0; i < index.count; i++) a.idx.push(index.getX(i) + a.base);
    else for (let i = 0; i < P.count; i++) a.idx.push(i + a.base);
    a.base += P.count;
    this.parts++;
  }

  build(lib: MaterialLibrary, opts: { receiveShadow?: boolean; castShadow?: boolean } = {}): THREE.Group {
    const group = new THREE.Group();
    for (const [key, a] of this.acc) {
      if (!a.pos.length) continue;
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute(a.pos, 3));
      g.setAttribute("normal", new THREE.Float32BufferAttribute(a.nor, 3));
      g.setAttribute("uv", new THREE.Float32BufferAttribute(a.uv, 2));
      g.setAttribute("color", new THREE.Float32BufferAttribute(a.col, 3));
      g.setIndex(a.base > 65535 ? new THREE.Uint32BufferAttribute(a.idx, 1) : new THREE.Uint16BufferAttribute(a.idx, 1));
      g.computeBoundingSphere();
      const mesh = new THREE.Mesh(g, lib.get(key));
      mesh.receiveShadow = opts.receiveShadow ?? (key === "asphalt" || key.startsWith("road") || key === "sidewalk" || key === "concrete" || key === "paint");
      mesh.castShadow = opts.castShadow ?? false;
      mesh.name = "batch_" + key;
      group.add(mesh);
    }
    return group;
  }

  stats() { let v = 0; for (const a of this.acc.values()) v += a.pos.length / 3; return { parts: this.parts, vertices: v, materials: this.acc.size }; }
}

// ── Geometry helpers with world-scaled UVs (so facades/tiles keep a constant texel density) ──
export function boxGeo(w: number, h: number, d: number, tile = 4): THREE.BoxGeometry {
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.getAttribute("uv") as THREE.BufferAttribute;
  // BoxGeometry face order: +x, -x, +y, -y, +z, -z (4 vertices each)
  const sizes: Array<[number, number]> = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let i = 0; i < 4; i++) { const k = f * 4 + i; uv.setXY(k, uv.getX(k) * sizes[f][0] / tile, uv.getY(k) * sizes[f][1] / tile); }
  uv.needsUpdate = true;
  return g;
}

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _p = new THREE.Vector3(), _s = new THREE.Vector3();
export function mat(x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = sx, sz = sx): THREE.Matrix4 {
  _e.set(rx, ry, rz); _q.setFromEuler(_e); _p.set(x, y, z); _s.set(sx, sy, sz);
  return new THREE.Matrix4().compose(_p, _q, _s);
}
