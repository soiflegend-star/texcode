/**
 * Regions — procedural scenery builders for the five regions, their landmarks and the
 * physical transition pieces between them. Each builder fills a ChunkCtx (merged geometry).
 * Chunk-local coordinates: x lateral, y up, z in [-60, 0] (0 = near end).
 */
import { makeRng, Rng } from "../util/rng.js";
import { ChunkCtx, PAL, streetLamp, tree, guardRail, curb, sidewalk, hvac, waterTank, antenna, billboard, bollards, scaffold, container, pipeRun, smokestack, crane, rubble, bush, vine, stoneArch, bench, cabinet, exitSign, car, truck, tower } from "./Props.js";
import { G } from "./Props.js";
import { mat } from "./Batch.js";

const L = 60;
const pick = <T,>(r: Rng, a: readonly T[]) => a[Math.floor(r() * a.length)];
const KINDS = ["glass", "brick", "concrete", "stone"] as const;

// ═════════════════════════ Shared road deck ═════════════════════════
function road(c: ChunkCtx, kind: "city" | "highway" | "subway" | "industrial" | "ruins", width = 8.8) {
  c.floor("road_" + kind, width, L, 0, 0.0, -L / 2, 0xffffff, [1, 8]);
}

// ═════════════════════════ 1. NEON ROOFTOPS ═════════════════════════
export function buildRooftops(c: ChunkCtx, v: number) {
  const r = c.rng;
  road(c, "city");
  c.box("concrete", 17.4, 1.3, L, 0, -1.3, -L / 2, 0xaaa79f, { tile: 4 });                   // deck slab
  c.b.add("facade_concrete", G.box(17.4, 46, L, 12), mat(0, -24.3, -L / 2), { color: 0xc8c2b5, aoHeight: 4 });   // building body below
  for (const s of [-1, 1]) {
    curb(c, s * 4.55, 0, -L, 0.3, 0.16); sidewalk(c, s * 4.7, s * 7.7, L);
    c.box("concrete", 0.55, 1.0, L, s * 8.2, 0, -L / 2, 0xb3afa6, { tile: 2 });            // parapet
    c.box("concrete", 0.8, 0.14, L, s * 8.2, 1.0, -L / 2, 0xcfcbc1, { tile: 2 });          // parapet cap
    guardRail(c, s * 7.6, 0, -L, 0.95);
    // sidewalk dressing
    for (let z = -3.5; z > -L; z -= 7.5) {
      const roll = r();
      const x = s * (5.6 + r() * 1.3);
      if (Math.round(z / 7.5) % 2 === (s > 0 ? 0 : 1)) streetLamp(c, s * 7.2, z, s, 7.4);
      else if (roll < 0.28) tree(c, s * 6.3, z, 0.75 + r() * 0.25, "planter");
      else if (roll < 0.44) hvac(c, s * 6.6, 0.16, z, 0.55 + r() * 0.2, 0);
      else if (roll < 0.58) bench(c, s * 6.5, z, Math.PI / 2);
      else if (roll < 0.7) bollards(c, s * 5.0, z + 1, z - 1, 1, 0xf2c230);
      else if (roll < 0.78 && v % 2 === 0) { c.box("metal", 0.5, 1.1, 0.5, x, 0.16, z, 0x7e868d); c.cyl("metal", 0.25, 0.1, x, 1.26, z, 0x5b636b, { seg: 8 }); } // vent
    }
  }
  // surrounding city: towers & lower rooftops on both sides
  for (const s of [-1, 1]) {
    let z = -2 - r() * 4;
    while (z > -L - 6) {
      const near = r() < 0.55;
      const w = 9 + r() * 12, d = 12 + r() * 10, x = s * (near ? 14 + r() * 12 + w / 2 : 30 + r() * 40);
      const top = near ? -26 + r() * 55 : -10 + r() * 90 + (v === 3 ? 25 : 0);
      const kind = pick(r, KINDS); const col = (kind === "glass" ? pick(r, [0xbcd4e6, 0xa9c6dd, 0x9fb8cf, 0xd4e2ee]) : kind === "brick" ? pick(r, PAL.brick) : pick(r, [0xdcd6c8, 0xcfc9bb, 0xe6e0d2]));
      tower(c, x, z - d / 2, w, d, top + 70, kind, col, -70, true);
      if (top < 0 && r() < 0.8) { for (let i = 0; i < 2; i++) hvac(c, x + (r() - 0.5) * w * 0.6, top, z - d / 2 + (r() - 0.5) * d * 0.5, 1.2, r() * 3); if (r() < 0.35) waterTank(c, x + (r() - 0.5) * w * 0.4, top, z - d / 2, 1.1); }
      z -= d + 2 + r() * 5;
    }
    // far skyline (cheap)
    for (let fz = -4; fz > -L; fz -= 20 + r() * 8) { const w = 14 + r() * 14, d = 14 + r() * 12; tower(c, s * (70 + r() * 80), fz - d / 2, w, d, 80 + r() * 130, r() < 0.6 ? "glass" : "concrete", pick(r, [0xb8cfe2, 0xc9d6df, 0xa7bfd4]), -50, true); }
  }
  // a rooftop billboard or garden every few variants
  if (v === 1) billboard(c, -12, 5, -20, 10, 5, Math.PI / 2 - 0.3, { text: "SKYLINE", bg: "#1c6fb5", fg: "#fff", sub: "LIVE ABOVE" });
  if (v === 4) { for (let i = 0; i < 4; i++) tree(c, 11 + r() * 3, -8 - i * 11, 1.1); c.box("grass", 6, 0.3, 50, 12.5, -1.0, -30, 0xffffff, { tile: 3 }); }
  c.emit({ type: "dust", x: 0, y: 1, z: -30, rate: 0.5 });
}

// ═════════════════════════ 2. SKY HIGHWAY ═════════════════════════
export function buildHighway(c: ChunkCtx, v: number) {
  const r = c.rng;
  road(c, "highway");
  const oppo = v % 2 === 0;                                    // opposing carriageway on the right?
  c.box("concrete", oppo ? 31 : 15.2, 1.6, L, oppo ? 5 : 0, -1.6, -L / 2, 0xa9a69e, { tile: 4 });
  c.box("concrete", 3.6, 90, 3.6, 0, -92, -30, 0xb3b0a8, { tile: 4 }); // pier
  for (const s of [-1, 1]) {
    // hard shoulder + barrier
    c.floor("road_highway", 1.6, L, s * 5.2, 0.005, -L / 2, 0x9a9a9a, [0.18, 8]);
    c.box("concrete", 0.7, 0.95, L, s * 6.05, 0, -L / 2, 0xc2beb4, { tile: 2 });
    c.box("concrete", 0.45, 0.4, L, s * 6.05, 0.95, -L / 2, 0xa8a49a, { tile: 2 });
    if (s < 0 || !oppo) guardRail(c, s * 6.05, 0, -L, 1.45, 0xbec6cc);
  }
  // left: noise wall / open; right: median + oncoming carriageway
  if (v === 3) { c.box("glass", 0.1, 3.4, L, -6.4, 0.95, -L / 2, 0x9ccbe8); for (let z = 0; z > -L; z -= 5) c.box("metal", 0.18, 4.3, 0.18, -6.4, 0, z, 0x6d757c); }
  if (oppo) { c.floor("road_highway", 8.8, L, 11.4, 0.0, -L / 2, 0xffffff, [1, 8]); c.box("concrete", 0.7, 0.95, L, 15.9, 0, -L / 2, 0xc2beb4, { tile: 2 }); guardRail(c, 15.9, 0, -L, 1.45); }
  // street lamps on the barrier
  for (let z = -4; z > -L; z -= 15) {
    const sx = oppo ? 6.05 : -6.05; c.cyl("metal", 0.14, 9.5, sx, 0.95, z, 0x7e868d, { rTop: 0.08, seg: 8 });
    c.box("metal", 6.6, 0.12, 0.12, sx - Math.sign(sx) * 3.1, 10.2, z, 0x7e868d);
    for (const k of [-1, 1]) { c.box("metal", 0.9, 0.16, 0.34, sx - Math.sign(sx) * (3.2 + k * 3.0), 10.1, z, 0x3d444b); c.box("emissive", 0.7, 0.05, 0.24, sx - Math.sign(sx) * (3.2 + k * 3.0), 10.0, z, 0xfff4cf); }
    if (oppo) { c.cyl("metal", 0.14, 9.5, -6.05, 0.95, z - 7.5, 0x7e868d, { rTop: 0.08, seg: 8 }); }
  }
  // road signs
  if (v === 1 || v === 4) { c.cyl("metal", 0.1, 4.4, -7.4, 0, -22, 0x7e868d, { seg: 6 }); c.sign({ text: "EXIT 12", bg: "#1d7a4a", fg: "#fff", sub: "METRO  ▸", w: 3.2, h: 2.0, x: -7.4, y: 5.0, z: -22, ry: 0.0 }); }
  // construction cones along the shoulder
  if (v === 2) for (let z = -6; z > -50; z -= 3.2) { c.cone("paint", 0.22, 0.7, -5.2, 0, z, 0xff7a1a, 8); c.cyl("paint", 0.12, 0.13, -5.2, 0.35, z, 0xf2f2f2, { rTop: 0.13, seg: 8 }); }
  // city around the viaduct (below and far)
  for (const s of [-1, 1]) {
    if (s > 0 && oppo) { /* skyline beyond oncoming lanes */ }
    for (let fz = -3; fz > -L; fz -= 14 + r() * 8) {
      const near = r() < 0.4; const w = 10 + r() * 14, d = 10 + r() * 12;
      const x = s * ((oppo && s > 0 ? 26 : 16) + (near ? r() * 16 : 24 + r() * 90));
      const top = near ? -20 + r() * 30 : 10 + r() * 130; const kind = pick(r, ["glass", "glass", "concrete", "brick"] as const);
      tower(c, x, fz - d / 2, w, d, top + 80, kind, kind === "glass" ? pick(r, [0xb8d0e4, 0xa6c4dc, 0x9bb7cd, 0xc9dbea]) : kind === "brick" ? pick(r, PAL.brick) : 0xd8d2c4, -80, true);
    }
  }
  c.emit({ type: "dust", x: 0, y: 0.3, z: -30, rate: 0.4 });
}

// ═════════════════════════ 3. SUBWAY TUNNELS ═════════════════════════
export function tunnelShell(c: ChunkCtx, z0: number, z1: number, station = false) {
  const len = Math.abs(z1 - z0), zc = (z0 + z1) / 2, r = c.rng;
  for (const s of [-1, 1]) {
    c.b.add("tile", G.box(0.5, 6.4, len, 3), mat(s * 6.6, 3.2, zc), { color: 0xe4e8e4, aoHeight: 1.5, aoStrength: 0.4 });
    c.box("concrete", 0.6, 6.4, len, s * 7.1, 0, zc, 0x8f8c84, { tile: 4 });
  }
  c.box("concrete", 15, 1.0, len, 0, 6.4, zc, 0x9a978f, { tile: 4 });
  for (let z = z0 - 3; z > z1; z -= 6) {                                           // ceiling lights
    for (const x of [-3.6, 0, 3.6]) { c.box("emissive", 0.32, 0.07, 2.4, x, 6.33, z, 0xf2fbff); c.box("metal", 0.5, 0.06, 2.6, x, 6.36, z, 0x555c63); }
  }
  for (let z = z0 - 6; z > z1; z -= 12) { for (const s of [-1, 1]) c.box("concrete", 0.9, 6.4, 0.9, s * 5.9, 0, z, 0xb0ada5, { tile: 2, ao: 3 }); c.box("concrete", 12.4, 0.6, 0.9, 0, 5.8, z, 0xa9a69e); }   // ribs
  for (const s of [-1, 1]) { pipeRun(c, s * 5.3, 5.2, z0, z1, 0.14, s > 0 ? 0xcf3b2f : 0x3b6fcf); pipeRun(c, s * 5.6, 4.9, z0, z1, 0.09, 0x888d92); }
  for (let z = z0 - 5; z > z1; z -= 11 + r() * 8) { cabinet(c, (r() < 0.5 ? -1 : 1) * 5.2, z, 0); }
  void station;
}
function trackBed(c: ChunkCtx) {
  road(c, "subway");
  for (const lx of [-2.4, 0, 2.4]) for (const dx of [-0.72, 0.72]) { c.box("metal", 0.11, 0.17, L, lx + dx, 0.0, -L / 2, 0x9aa1a7); c.box("metal", 0.2, 0.05, L, lx + dx, 0.0, -L / 2, 0x6a7178); }
  c.box("metal", 0.1, 0.14, L, -0.9 - 2.4 - 0.4, 0.0, -L / 2, 0x3a3f44);          // third rails
}
export function buildSubway(c: ChunkCtx, v: number, opts: { shell?: [number, number] } = {}) {
  const r = c.rng; trackBed(c);
  const [s0, s1] = opts.shell ?? [0, -L];
  // maintenance catwalks / platforms
  const platform = v === 2 || v === 4;
  for (const s of [-1, 1]) {
    const w = platform ? 2.0 : 1.3;
    c.box("concrete", w, 0.95, L, s * (4.6 + w / 2 + 0.05), 0, -L / 2, 0xa8a59d, { tile: 3 });
    c.box("plaza", w, 0.05, L, s * (4.6 + w / 2 + 0.05), 0.95, -L / 2, 0xffffff, { tile: 3 });
    c.box("paint", 0.18, 0.03, L, s * 4.78, 0.99, -L / 2, 0xf2c230);                 // yellow safety line
  }
  tunnelShell(c, s0, s1, platform);
  // advertisements, doors, exit signs
  const ads = [["NEXUS CITY", "#d9822b", "#fff", "TOURS"], ["AETHER METRO", "#1d6fa5", "#fff", "LINE 7"], ["RUNNER ENERGY", "#bf3a30", "#fff", "BOOST UP"], ["SKY CAFÉ", "#2f8f6a", "#fff", "OPEN 24H"], ["FORGE WORKS", "#6a4a2f", "#ffe", "DISTRICT"]];
  for (let z = -6, i = 0; z > -L; z -= 12, i++) {
    const s = i % 2 ? 1 : -1; const a = ads[(i + v) % ads.length];
    if (z < s1 + 2 && z > s0 - 2 - L) c.sign({ text: a[0], bg: a[1], fg: a[2], sub: a[3], w: 3.4, h: 2.1, x: s * 6.32, y: 2.9, z, ry: s > 0 ? -Math.PI / 2 : Math.PI / 2 });
    if (i % 2 === 1) { c.box("metal", 0.1, 2.3, 1.3, -s * 6.32, 0.95, z - 5, 0x3a4048); exitSign(c, -s * 6.2, 3.5, z - 5, -s * Math.PI / 2); }
  }
  // benches & puddles & steam
  if (platform) for (const s of [-1, 1]) for (let z = -8; z > -L; z -= 10) bench(c, s * 5.7, z, Math.PI / 2);
  for (let i = 0; i < 3; i++) c.floor("water", 1.6 + r() * 1.5, 1.2 + r() * 1.8, (Math.floor(r() * 3) - 1) * 2.4 + (r() - 0.5), 0.012, -r() * L, 0xcfe0e6, [1, 1], r() * 3);
  c.emit({ type: "steam", x: -5.4, y: 0.5, z: -20 - r() * 20, rate: 2 }); c.emit({ type: "spark", x: -3.6, y: 0.4, z: -10 - r() * 40, rate: 0.7 }); c.emit({ type: "drip", x: 3.5, y: 5.8, z: -14 - r() * 30, rate: 0.5 });
}

// ═════════════════════════ 4. INDUSTRIAL ZONE ═════════════════════════
export function buildIndustrial(c: ChunkCtx, v: number) {
  const r = c.rng; road(c, "industrial", 8.8);
  c.floor("concrete", 40, L, 0, -0.04, -L / 2, 0xb5b1a8, [5, 8]);                  // wide apron
  for (const s of [-1, 1]) {
    curb(c, s * 4.55, 0, -L, 0.3, 0.16, 0xd8c35a);
    c.box("concrete", 5.2, 0.12, L, s * 7.1, 0, -L / 2, 0xbab6ac, { tile: 4 });
    // chain-link / jersey barriers
    if (v % 2 === 0) { for (let z = 0; z > -L; z -= 2.5) c.box("concrete", 0.5, 0.8, 2.3, s * 7.2, 0.12, z - 1.2, 0xcfcac0, { tile: 2 }); }
    else { for (let z = 0; z > -L; z -= 4) c.box("metal", 0.08, 2.2, 0.08, s * 7.4, 0.12, z, 0x70787f); c.box("metal", 0.04, 0.05, L, s * 7.4, 2.3, -L / 2, 0x70787f); c.box("glass", 0.02, 1.7, L, s * 7.4, 0.5, -L / 2, 0xb9c4cb); }
    // bollards with hazard stripes
    bollards(c, s * 5.0, -2, -L, 6, 0xf2c230);
    // lamps
    for (let z = -5; z > -L; z -= 20) { const x = s * 7.9; c.cyl("metal", 0.14, 8.2, x, 0.12, z, 0x59626b, { rTop: 0.09, seg: 8 }); c.box("metal", 2.0, 0.1, 0.1, x - s * 1.0, 8.2, z, 0x59626b); c.box("emissive", 0.7, 0.06, 0.3, x - s * 2.0, 8.1, z, 0xffd89a); }
    // warning signs
    for (let z = -9; z > -L; z -= 24 + r() * 6) { c.cyl("metal", 0.06, 2.2, s * 6.1, 0.12, z, 0x59626b, { seg: 5 }); c.sign({ text: "⚠ CAUTION", bg: "#f2c230", fg: "#111", sub: "HEAVY VEHICLES", w: 1.5, h: 1.0, x: s * 6.1, y: 2.4, z, ry: s > 0 ? -Math.PI / 2 : Math.PI / 2 }); }
    // industrial buildings
    let z = -2;
    while (z > -L - 4) {
      const roll = r(); const d = 14 + r() * 16; const x = s * (14 + r() * 8);
      if (roll < 0.34) { const w = 14 + r() * 10; const h = 8 + r() * 6; tower(c, x + s * w / 2, z - d / 2, w, d, h, "industrial", pick(r, [0xb5bcc2, 0xc4b8a2, 0xa9b3ba]), 0, false); c.box("metal", w + 0.2, 0.35, d + 0.2, x + s * w / 2, h, z - d / 2, 0x6a7178); for (let i = 0; i < 3; i++) c.box("metal", 3.4, 3.2, 0.2, x + s * (w / 2) - s * w * 0.35 + i * 0, 0, z - d / 2 + (i - 1) * 4.4 * 1, 0x59626b, { ry: 0 }); c.box("paint", 4, 3.4, 0.2, x - s * 0.1, 0, z - d / 2, 0x3d5e7a); }
      else if (roll < 0.56) { const w = 10 + r() * 8, h = 18 + r() * 14; tower(c, x + s * w / 2, z - d / 2, w, d, h, "brick", pick(r, PAL.brick), 0, true); if (r() < 0.6) smokestack(c, x + s * (w + 3), z - d / 2, 22 + r() * 16, 1.4 + r()); }
      else if (roll < 0.8) { for (let i = 0; i < 3; i++) for (let k = 0; k < 2; k++) { container(c, x + s * (1.7 + k * 2.7), (i % 3 === 2 ? 2.6 : 0), z - 3 - i * 6.3 + (k ? 0.5 : 0), 0); } }
      else { for (let i = 0; i < 2; i++) c.cyl("metal", 3 + r(), 9 + r() * 4, x + s * (4 + i * 8), 0, z - 5 - i * 3, 0xc9cdd0, { seg: 16, ao: 3 }); pipeRun(c, x + s * 2, 3.2, z, z - d, 0.35, 0x8a5a3a); }
      z -= d + 1.5 + r() * 4;
    }
  }
  if (v === 2) { pipeRun(c, -7, 4.4, 0, -L, 0.45, 0xb04a2a); pipeRun(c, -7, 5.3, 0, -L, 0.3, 0x3a6fa0); }
  if (v === 3) { crane(c, 0, -20, 17, 17); }
  // forklift props + steam vents
  if (v === 4) { c.box("paint", 1.4, 1.7, 2.2, 6.6, 0.12, -30, 0xe5a423, { tile: 2 }); c.box("metal", 0.15, 2.2, 0.15, 6.0, 0.12, -31.1, 0x3a3f44); }
  c.emit({ type: "steam", x: 7.5 * (r() < 0.5 ? -1 : 1), y: 0.4, z: -10 - r() * 40, rate: 2.2 });
  c.emit({ type: "spark", x: -8, y: 2, z: -30 - r() * 20, rate: 0.5 });
}

// ═════════════════════════ 5. OVERGROWN RUINS ═════════════════════════
export function buildRuins(c: ChunkCtx, v: number) {
  const r = c.rng; road(c, "ruins");
  c.box("concrete", 15, 0.9, L, 0, -0.95, -L / 2, 0x9b978c, { tile: 3 });
  for (const s of [-1, 1]) {
    // broken sidewalks, overgrown strips
    for (let z = 0; z > -L; z -= 4) { if (r() < 0.62) c.box("sidewalk", 2.6 + r(), 0.16, 3.4, s * (5.5 + r() * 0.5), 0, z - 2, 0xa8a499, { tile: 3, rz: (r() - 0.5) * 0.08 }); }
    c.floor("grass", 5, L, s * 7.8, 0.02, -L / 2, 0xffffff, [3, 14]);
    for (let z = -2; z > -L; z -= 3.6 + r() * 2.5) { const gx = s * (4.4 + r() * 1.2); c.floor("grass", 1.8 + r() * 2.2, 2 + r() * 2.5, gx, 0.015 + r() * 0.01, z, 0xffffff, [1, 1], r() * 3); if (r() < 0.55) bush(c, s * (4.9 + r() * 3.4), z, 0.7 + r() * 0.6); }
    // ruined buildings: broken walls of different heights
    let z = -2;
    while (z > -L - 2) {
      const d = 10 + r() * 12, w = 8 + r() * 8, x = s * (13 + r() * 10); const roll = r();
      if (roll < 0.55) {
        const h = 10 + r() * 26; const col = pick(r, [0xb8b0a0, 0xa7a091, 0xc2bba9]);
        // broken top: stacked partial boxes
        tower(c, x + s * w / 2, z - d / 2, w, d, h * 0.6, "stone", col, 0, false);
        tower(c, x + s * w * 0.3, z - d * 0.3, w * 0.55, d * 0.5, h * 0.4, "stone", col, h * 0.6, false);
        for (let i = 0; i < 4; i++) c.box("stone", 1.2 + r(), 2 + r() * 3, 1.2 + r(), x + s * r() * w, h * 0.55 + r() * 3, z - r() * d, 0x9d9585, { rz: (r() - 0.5) * 0.4 });
        for (let i = 0; i < 5; i++) vine(c, x - s * 0.2, h * 0.6 - r() * 2, z - r() * d, 3 + r() * 8);
        for (let i = 0; i < 4; i++) c.sphere("foliage", 1.4 + r() * 1.2, x - s * (w * 0.5) + (r() - 0.5) * w, h * (0.1 + r() * 0.5), z - r() * d, PAL.foliage[Math.floor(r() * 5)], 1.2, 0.8, 1.2, { ws: 6, hs: 5 });
        rubble(c, x - s * 2, z - d * 0.4, 1.6);
      } else if (roll < 0.8) { for (let i = 0; i < 3; i++) tree(c, x + (r() - 0.5) * 10, z - 3 - i * 4, 2.4 + r() * 1.6); }
      else { // water pool
        c.floor("water", w + 6, d - 3, x - s * 3, -0.35, z - d / 2, 0xffffff, [3, 3], 0);
        c.box("stone", w + 8, 0.9, 1.2, x - s * 3, -1.2, z - 1, 0x8e8a7d, { tile: 3 }); for (let i = 0; i < 6; i++) c.ico("stone", 0.4 + r() * 0.6, x - s * (r() * 8 - 3), -0.2, z - r() * d, 0x7d796c, 1.3, 0.7, 1, r() * 3, 0);
      }
      z -= d + 1 + r() * 4;
    }
    // far hills & towers
    for (let fz = -4; fz > -L; fz -= 14 + r() * 12) { const hh = 8 + r() * 30; c.ico("foliage", 14 + r() * 14, s * (50 + r() * 70), -2, fz, PAL.foliage[Math.floor(r() * 5)], 1.4, hh / 20, 1.2, 0, 1); if (r() < 0.4) tower(c, s * (60 + r() * 60), fz, 12, 12, 40 + r() * 50, "stone", 0xb0a998, -4, false); }
  }
  // fallen/cracked kerb stones, road edge crumbling, puddles
  for (let i = 0; i < 5; i++) c.floor("water", 1.2 + r() * 1.6, 1 + r() * 1.5, (Math.floor(r() * 3) - 1) * 2.4 + (r() - 0.5), 0.012, -r() * L, 0xcfe0e6, [1, 1], r() * 3);
  if (v % 2 === 0) for (let i = 0; i < 2; i++) { c.box("stone", 0.8, 3 + r() * 3, 0.8, (r() < 0.5 ? -1 : 1) * 6.6, 0, -8 - i * 26, 0xaaa393, { tile: 2 }); }
  c.emit({ type: "leaf", x: 0, y: 4, z: -30, rate: 1.5 });
}

// ═════════════════════════ Transitions ═════════════════════════
/** Physical pieces joining region i → i+1, built on top of the outgoing region's own scenery. */
export function addTransition(c: ChunkCtx, fromRegion: number) {
  const r = c.rng;
  switch (fromRegion) {
    case 0: { // Rooftops → Highway: steel skybridge with arches and gate
      for (let i = 0; i < 3; i++) { const z = -10 - i * 18; for (const s of [-1, 1]) { c.box("metal", 0.7, 9.5, 0.7, s * 8.4, 0, z, 0xe6e9ec, { ao: 3 }); c.box("metal", 0.35, 0.35, 11, s * 8.4, 9.4, z - 4.5, 0xe6e9ec, { rx: 0.0 }); } c.box("metal", 17.6, 0.6, 0.7, 0, 9.4, z, 0xe6e9ec); for (let k = -3; k <= 3; k++) c.box("metal", 0.12, 1.8, 0.12, k * 2.2, 7.6, z, 0xcfd5da); }
      for (const s of [-1, 1]) for (let z = -2; z > -L; z -= 3) c.box("metal", 0.05, 8.2, 0.05, s * 8.4, 1.0, z, 0xbfc7ce, { rz: s * 0.12 });   // suspender cables
      c.sign({ text: "SKY HIGHWAY", bg: "#1d6fa5", fg: "#fff", sub: "NEXT 12 KM  ▸", w: 7.2, h: 2.2, x: 0, y: 7.7, z: -44, ry: 0 }); c.box("metal", 7.6, 2.6, 0.2, 0, 6.4, -44.1, 0x30373d); c.box("emissive", 0.9, 0.1, 0.1, 0, 5.2, -44, 0xfff2c4);
      for (let i = 0; i < 12; i++) c.cone("paint", 0.22, 0.7, (i % 2 ? 1 : -1) * 4.8, 0, -4 - i * 4.5, 0xff7a1a, 8);
      break;
    }
    case 1: { // Highway → Subway: cut-and-cover underpass with portal
      for (const s of [-1, 1]) for (let z = -8; z > -L; z -= 8) { const h = Math.min(7, 1.2 + (8 - z) * 0.12); c.box("concrete", 0.8, h, 8, s * 6.5, 0, z - 4, 0xb6b2a8, { tile: 3, ao: 2 }); }
      tunnelShell(c, -34, -L, false);
      c.box("concrete", 16.5, 3.6, 1.8, 0, 6.8, -34, 0xa8a49a, { tile: 3 }); for (const s of [-1, 1]) c.box("concrete", 1.6, 10.4, 1.8, s * 7.4, 0, -34, 0xa8a49a, { tile: 3 });
      c.sign({ text: "METRO", bg: "#1d6fa5", fg: "#fff", sub: "AETHER LINE 7  ▸", w: 6.4, h: 2.0, x: 0, y: 8.5, z: -35, ry: 0 });
      for (let i = 0; i < 5; i++) c.box("paint", 0.3, 0.05, 2.0, 0, 0.01, -30 - i * 3, 0xf2c230);
      break;
    }
    case 2: { // Subway → Industrial: station exit with rolling gate, daylight beyond
      c.box("concrete", 16.5, 3.0, 1.6, 0, 7.4, -30, 0x8d8a82, { tile: 3 }); for (const s of [-1, 1]) c.box("concrete", 1.5, 10.4, 1.6, s * 7.5, 0, -30, 0x8d8a82, { tile: 3 });
      c.box("metal", 14, 1.7, 0.2, 0, 6.5, -30.4, 0xe0a32a); for (let i = 0; i < 6; i++) c.box("paint", 1.4, 1.7, 0.21, -6.5 + i * 2.6, 6.5, -30.5, i % 2 ? 0x1a1a1a : 0xf2c230);
      c.sign({ text: "FORGE DISTRICT", bg: "#d9822b", fg: "#fff", sub: "AUTHORISED ACCESS ▸", w: 6.6, h: 1.8, x: 0, y: 8.4, z: -31, ry: 0 });
      for (const s of [-1, 1]) for (let z = -32; z > -L; z -= 5) { c.box("metal", 0.12, 2.4, 0.12, s * 5.6, 0, z, 0x70787f); } c.box("metal", 0.05, 0.05, 28, -5.6, 2.3, -46, 0x70787f); c.box("metal", 0.05, 0.05, 28, 5.6, 2.3, -46, 0x70787f);
      c.emit({ type: "dust", x: 0, y: 3, z: -40, rate: 2 });
      break;
    }
    case 3: { // Industrial → Ruins: collapsed factory gate, torn fence, creeping grass
      for (const s of [-1, 1]) c.box("facade_brick", 1.6, 9.5, 1.6, s * 7.4, 0, -28, 0xa65b44, { tile: 2.5, rz: s * 0.04 });
      c.box("metal", 16.4, 0.7, 0.7, 1.2, 8.6, -28, 0x6a5a48, { rz: -0.11 }); c.box("metal", 7.5, 0.5, 0.5, -4.2, 6.2, -27, 0x7d6a54, { rz: 0.5, ry: 0.2 });
      c.sign({ text: "FORGE WORKS", bg: "#7a4f2e", fg: "#e8dcc6", sub: "CLOSED", w: 4.8, h: 1.3, x: 3.6, y: 6.8, z: -27.5, ry: 0.1 });
      rubble(c, -5.5, -26, 2.4); rubble(c, 5.0, -30, 1.8); rubble(c, 0.8, -36, 1.2);
      for (let z = -3; z > -L; z -= 2.2) for (const s of [-1, 1]) { if (r() < 0.6) c.box("metal", 0.05, 1.8 + r() * 0.4, 0.05, s * 7.3, 0, z, 0x70787f, { rz: (r() - 0.5) * 0.5 }); }
      for (let i = 0; i < 30; i++) c.floor("grass", 1.4 + r() * 2, 1.4 + r() * 2, (r() - 0.5) * 8.4, 0.02, -30 - r() * 30, 0xffffff, [1, 1], r() * 3);
      for (let i = 0; i < 10; i++) bush(c, (r() - 0.5) * 9, -30 - r() * 28, 0.6 + r() * 0.5);
      break;
    }
    case 4: { // Ruins → Rooftops: ancient arch with a modern gantry attached
      stoneArch(c, -26, 12, 7.5);
      for (const s of [-1, 1]) for (let i = 0; i < 4; i++) vine(c, s * (5.2 + r() * 1.2), 7.5 - r(), -26 + (r() - 0.5), 4 + r() * 3);
      c.box("metal", 12.6, 1.3, 0.2, 0, 11.1, -26.3, 0x2f3a44); c.sign({ text: "NEXUS CITY", bg: "#1d6fa5", fg: "#fff", sub: "WELCOME BACK ▸", w: 11.4, h: 1.2, x: 0, y: 11.1, z: -26.45, ry: 0 });
      for (let z = -34; z > -L; z -= 3) { for (const s of [-1, 1]) { c.box("concrete", 0.55, 1.0, 3, s * 8.2, 0, z - 1, 0xb3afa6, { tile: 2 }); guardRail(c, s * 7.6, z, z - 3, 0.95); } }
      c.floor("sidewalk", 3.2, 26, -6.0, 0.17, -47, 0xffffff, [1, 5]); c.floor("sidewalk", 3.2, 26, 6.0, 0.17, -47, 0xffffff, [1, 5]);
      for (let z = -36; z > -L; z -= 8) { streetLamp(c, -7.2, z, -1, 7.4); streetLamp(c, 7.2, z - 4, 1, 7.4); }
      break;
    }
  }
}

// ═════════════════════════ Landmarks ═════════════════════════
export function addLandmark(c: ChunkCtx, name: string) {
  const r = c.rng;
  switch (name) {
    // ── Rooftops
    case "skybridge": { c.box("glass", 8, 3, 36, 0, 9.5, -30, 0x9fd2ef); c.box("metal", 8.4, 0.5, 36.4, 0, 9.0, -30, 0xaab3ba); c.box("metal", 8.4, 0.4, 36.4, 0, 12.5, -30, 0xaab3ba); for (let z = -12; z > -48; z -= 6) c.box("metal", 8.4, 3.6, 0.25, 0, 9.0, z, 0x8a939a); for (const s of [-1, 1]) c.box("metal", 0.9, 12, 0.9, s * 4.4, 0, -12, 0xc9cfd4, { ao: 4 }); break; }
    case "water_tower_cluster": { for (const s of [-1, 1]) waterTank(c, s * 11.5, 0, -22 - (s > 0 ? 8 : 0), 1.4); antenna(c, -10, 0, -44, 16); break; }
    case "rooftop_garden": { for (const s of [-1, 1]) { c.box("grass", 5, 0.4, 36, s * 11.2, -0.5, -30, 0xffffff, { tile: 3 }); for (let i = 0; i < 6; i++) tree(c, s * (9.5 + r() * 3), -14 - i * 5.5, 1.1 + r() * 0.5); } break; }
    case "construction_site": { scaffold(c, -11.5, -22, 4, 12, 3, 5); scaffold(c, -11.5, -34, 4, 12, 3, 5); crane(c, 12, -28, 24, 8); c.box("paint", 2.6, 2.2, 6, 11, 0, -14, 0xe5a423, { tile: 2 }); break; }
    case "billboard_wall": { billboard(c, -13, 6, -16, 11, 6, Math.PI / 2 - 0.35, { text: "NEXUS RUNNER", bg: "#1b2f9c", fg: "#fff", special: "nexus", w: 0, h: 0 } as any); billboard(c, 13, 6, -38, 10, 5.5, -Math.PI / 2 + 0.35, { text: "SKYLINE", bg: "#d9822b", fg: "#fff", sub: "LIVE ABOVE" }); break; }
    case "helipad": { c.box("concrete", 12, 0.4, 12, -17, -0.4, -30, 0x9b968c, { tile: 3 }); c.cyl("paint", 4.6, 0.06, -17, 0.0, -30, 0x2f3a44, { seg: 24 }); c.box("paint", 0.7, 0.04, 4.2, -18, 0.03, -30, 0xf2f2f2); c.box("paint", 0.7, 0.04, 4.2, -16, 0.03, -30, 0xf2f2f2); c.box("paint", 2.4, 0.04, 0.7, -17, 0.03, -30, 0xf2f2f2); break; }
    // ── Highway
    case "gantry_sign": case "toll_gantry": { for (const s of [-1, 1]) c.box("metal", 0.6, 8, 0.6, s * 7.3, 0, -30, 0x9aa2a8, { ao: 3 }); c.box("metal", 15.2, 0.7, 0.8, 0, 7.6, -30, 0x9aa2a8); c.box("metal", 15.2, 0.3, 0.3, 0, 8.4, -30, 0x7e868d); const sg = name === "gantry_sign"; c.sign({ text: sg ? "NEXUS CITY" : "TOLL PLAZA", bg: "#1d7a4a", fg: "#fff", sub: sg ? "◂ 4 km     ▸ METRO" : "NO STOP · TAG", w: 6.4, h: 2.4, x: -2.6, y: 5.7, z: -30.5, ry: 0 }); c.sign({ text: "SKYWAY", bg: "#1d7a4a", fg: "#fff", sub: "12 ▸", w: 3.6, h: 2.0, x: 3.4, y: 5.8, z: -30.5, ry: 0 }); break; }
    case "cable_pylons": { for (const s of [-1, 1]) { c.box("concrete", 1.4, 52, 1.4, s * 9, -2, -28, 0xd8d4c8, { tile: 3 }); c.box("concrete", 1.9, 1.2, 1.9, s * 9, 28, -28, 0xcbc7bb); for (let i = 0; i < 9; i++) { const dz = (i - 4) * 6.6; const ang = Math.atan2(24, Math.abs(dz) + 0.01); c.b.add("metal", G.cyl(0.06, 0.06, Math.hypot(24, dz), 4), mat(s * 8.2, 17, -28 + dz / 2, 0, 0, 0).clone().multiply(mat(0, 0, 0, Math.atan2(dz, 24) , 0, 0)), { color: 0xe8e8e8 }); void ang; } } break; }
    case "interchange": { c.box("concrete", 7.5, 1.2, 48, 16, 0.1, -30, 0xa9a69e, { tile: 4, ry: 0.0, rz: 0 }); c.floor("road_highway", 6.4, 48, 16, 1.32, -30, 0xffffff, [0.8, 6]); c.box("concrete", 0.5, 1.0, 48, 12.5, 1.3, -30, 0xc2beb4, { tile: 2 }); for (let z = -10; z > -50; z -= 14) c.box("concrete", 2.4, 22, 2.4, 16, -22, z, 0xb3b0a8, { tile: 4 }); break; }
    case "overpass": { c.box("concrete", 20, 1.4, 6, 0, 7.4, -30, 0xaaa79f, { tile: 4 }); for (const s of [-1, 1]) { c.box("concrete", 1.8, 8, 1.8, s * 8.6, 0, -30, 0xb3b0a8, { tile: 3, ao: 3 }); c.box("concrete", 20, 1.0, 0.4, 0, 8.8, -27.2, 0xc2beb4); } c.box("metal", 20, 0.8, 0.2, 0, 9.6, -27, 0x9aa2a8); break; }
    case "skyline_view": { for (let i = 0; i < 5; i++) tower(c, -26 - r() * 6, -8 - i * 11, 14, 12, 50 + r() * 60, "glass", pick(r, [0xb8d0e4, 0xa6c4dc, 0xc9dbea]), -30, true); break; }
    // ── Subway
    case "station": { for (const s of [-1, 1]) { c.box("tile", 0.3, 1.3, 40, s * 6.4, 5.1, -30, 0xf2f4f2, { tile: 3 }); } c.sign({ text: "AETHER CENTRAL", bg: "#1d6fa5", fg: "#fff", sub: "INTERCHANGE · LINE 7 · LINE 3", w: 7, h: 1.3, x: -6.3, y: 4.5, z: -30, ry: Math.PI / 2 }); c.sign({ text: "AETHER CENTRAL", bg: "#1d6fa5", fg: "#fff", sub: "INTERCHANGE · LINE 7 · LINE 3", w: 7, h: 1.3, x: 6.3, y: 4.5, z: -22, ry: -Math.PI / 2 }); for (const s of [-1, 1]) for (let z = -14; z > -48; z -= 6) { c.box("metal", 0.08, 0.6, 3, s * 6.0, 2.8, z, 0x2a3138); c.box("emissive", 0.06, 0.4, 2.8, s * 5.95, 2.8, z, 0xaee9ff); } break; }
    case "maintenance_corridor": { for (const s of [-1, 1]) { c.box("metal", 0.2, 3.2, 10, s * 6.4, 0.95, -30, 0x3a4048); c.box("emissive", 0.05, 0.5, 8, s * 6.28, 3.3, -30, 0xffb23a); } cabinet(c, -5.4, -24, 0); cabinet(c, -5.4, -26, 0); c.emit({ type: "steam", x: 5.2, y: 1, z: -30, rate: 4 }); break; }
    case "junction": { for (let i = 0; i < 4; i++) c.box("metal", 0.22, 0.3, 40, -4.2 + i * 2.8, 0.05, -30, 0x9aa1a7, { ry: (i - 1.5) * 0.04 }); c.box("emissive", 0.2, 0.2, 0.2, 0, 3.2, -30, 0xff3d2e); c.box("emissive", 0.2, 0.2, 0.2, 0.4, 3.2, -30, 0x38e07a); c.box("metal", 1.2, 3.4, 0.1, 0.2, 0.2, -30, 0x2a3138); break; }
    case "ventilation_shaft": { c.cyl("metal", 1.8, 6.2, 0, 0, -30, 0x59626b, { seg: 16 }); for (let i = 0; i < 4; i++) c.box("metal", 3.4, 0.1, 0.25, 0, 5.8, -30, 0x3a4048, { ry: i * Math.PI / 4 }); c.emit({ type: "steam", x: 4, y: 5, z: -30, rate: 3 }); break; }
    case "flooded_section": { c.floor("water", 8.4, 24, 0, 0.03, -30, 0xaaccd6, [4, 5]); for (const s of [-1, 1]) for (let z = -20; z > -40; z -= 6) c.box("emissive", 0.06, 0.06, 1.2, s * 4.8, 0.5, z, 0x7fe1ff); c.emit({ type: "drip", x: 0, y: 5.8, z: -26, rate: 2 }); break; }
    // ── Industrial
    case "crane": { crane(c, 0, -30, 20, 18); crane(c, -14, -44, 26, 6); break; }
    case "container_yard": { for (const s of [-1, 1]) for (let i = 0; i < 4; i++) for (let k = 0; k < 3; k++) container(c, s * (10 + k * 2.8), 0, -12 - i * 6.2, 0); for (let i = 0; i < 4; i++) container(c, -10, 2.6, -12 - i * 6.2, 0); break; }
    case "factory_smokestacks": { for (let i = 0; i < 3; i++) smokestack(c, -13 - i * 4.5, -22 - i * 5, 32 + i * 6, 1.8); tower(c, -16, -36, 20, 16, 14, "industrial", 0xb5bcc2, 0, false); break; }
    case "loading_dock": { c.box("concrete", 9, 1.3, 30, -12, 0, -30, 0xb3afa5, { tile: 3 }); for (let i = 0; i < 4; i++) { c.box("paint", 3.2, 3.6, 0.25, -12.6, 1.3, -18 - i * 7, 0x3d5e7a); c.box("emissive", 3.2, 0.12, 0.1, -12.6, 5.0, -18 - i * 7, 0xffb23a); } truck(c, -8.4, -22, Math.PI / 2, 0xd8493a, 0); c.box("metal", 8, 0.3, 30, -12, 5.2, -30, 0x6a7178); break; }
    case "pipe_bridge": { for (const s of [-1, 1]) c.box("metal", 0.7, 9, 0.7, s * 8, 0, -30, 0x59626b, { ao: 3 }); c.box("metal", 16.6, 0.6, 0.8, 0, 8.6, -30, 0x59626b); for (let i = 0; i < 4; i++) c.pipe("metal", 0.4, 16.6, 0, 9.4 + i * 0.1 + (i % 2) * 0.8, -30 + (i - 1.5) * 0.9, [0xb04a2a, 0x3b6fcf, 0xd9a02b, 0x8a8f94][i], "x", 12); break; }
    // ── Ruins
    case "ruined_bridge": { for (const s of [-1, 1]) { c.box("stone", 2.4, 8, 2.4, s * 8.6, 0, -30, 0xb4ae9e, { tile: 2.5, ao: 3 }); } c.box("stone", 5.6, 1.0, 2.2, -5.6, 8, -30, 0xa39d8e, { tile: 3, rz: 0.06 }); c.box("stone", 3.0, 0.9, 2.2, 6.8, 7.6, -30, 0xa39d8e, { tile: 3, rz: -0.22 }); for (let i = 0; i < 6; i++) vine(c, -5 + r() * 10, 8, -30, 2 + r() * 4); rubble(c, 1, -30, 1.4); break; }
    case "stone_arch": { stoneArch(c, -30, 13, 8); for (let i = 0; i < 8; i++) vine(c, (r() - 0.5) * 12, 8.5, -30, 3 + r() * 4); break; }
    case "collapsed_tower": { const x = r() < 0.5 ? -15 : 15; tower(c, x, -30, 12, 12, 30, "stone", 0xb0a998, 0, false); for (let i = 0; i < 7; i++) c.box("stone", 2 + r() * 2, 1.4 + r() * 2, 2 + r() * 2, x - Math.sign(x) * (3 + r() * 9), 0, -30 + (r() - 0.5) * 16, 0x9d9585, { ry: r() * 3, rz: (r() - 0.5) * 0.5 }); rubble(c, x - Math.sign(x) * 8, -30, 2.4); break; }
    case "waterfall_pool": { const x = -16; c.floor("water", 12, 18, x + 2, -0.3, -30, 0xffffff, [3, 3]); c.box("stone", 4, 16, 6, x - 5, -2, -30, 0x8d8a7e, { tile: 3 }); c.box("glow" in {} ? "paint" : "paint", 1.2, 12, 0.4, x - 2.8, 0.5, -30, 0xdff1f6); c.emit({ type: "steam", x: x - 2.5, y: 0.8, z: -30, rate: 3 }); for (let i = 0; i < 4; i++) tree(c, x - 3 + r() * 5, -22 - r() * 16, 2 + r()); break; }
    case "giant_tree": { const x = r() < 0.5 ? -13 : 13; c.cyl("paint", 2.4, 20, x, 0, -30, 0x6a4a32, { rTop: 1.2, seg: 10, ao: 3 }); for (let i = 0; i < 5; i++) c.sphere("foliage", 5 + r() * 3, x + (r() - 0.5) * 9, 20 + r() * 5, -30 + (r() - 0.5) * 9, PAL.foliage[i % 5], 1, 0.75, 1, { ws: 8, hs: 6 }); for (let i = 0; i < 4; i++) vine(c, x + (r() - 0.5) * 10, 19, -30 + (r() - 0.5) * 8, 6 + r() * 6); break; }
  }
}

export function buildRegionChunk(regionIdx: number, variant: number, lib: any, seedTag: string, opts: { transition?: boolean; landmark?: string | null } = {}): ChunkCtx {
  const rng = makeRng(`${seedTag}|r${regionIdx}|v${variant}|${opts.transition ? "t" : "n"}|${opts.landmark ?? ""}`);
  const c = new ChunkCtx(rng, lib, L);
  switch (regionIdx) {
    case 0: buildRooftops(c, variant); break;
    case 1: buildHighway(c, variant); break;
    case 2: buildSubway(c, variant, opts.transition ? { shell: [0, -30] } : {}); break;
    case 3: buildIndustrial(c, variant); break;
    default: buildRuins(c, variant); break;
  }
  if (opts.transition) addTransition(c, regionIdx);
  else if (opts.landmark) addLandmark(c, opts.landmark);
  return c;
}
