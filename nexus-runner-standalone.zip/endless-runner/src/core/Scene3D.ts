/**
 * Scene3D — the WebGL presentation layer. Reads the simulation (Game) and renders it:
 * streamed scenery chunks, characters, obstacles, collectibles, rival, particles, weather, camera rig.
 * The simulation never depends on this file (headless tests run without it).
 */
import * as THREE from "three";
import type { Game, FxEvent } from "./Game.js";
import { CHARACTERS, CHUNK_LENGTH, LANE_WIDTH, OBSTACLES, POWERUPS, PowerUpId, QUALITY, QualitySettings, QualityTier, REGIONS } from "../data/GameData.js";
import { getChunkPlan } from "../world/ChunkPlan.js";
import { MaterialLibrary } from "../render/Materials.js";
import { Environment, themeAt } from "../render/Environment.js";
import { ChunkLibrary, ChunkInstance } from "../render/ChunkLibrary.js";
import { buildCharacter, Rig } from "../render/CharacterFactory.js";
import { AnimState, CharacterAnimator } from "../render/CharacterAnimator.js";
import { buildBoostPad, buildObstacle, buildPowerup, buildRail, makeCoinMesh, ObstacleModel } from "../render/Models.js";
import { Particles } from "../render/Particles.js";
import { QualityGovernor, detectTier, readDevice } from "../render/Quality.js";
import { softDot } from "../render/Textures.js";
import { Ambient } from "../render/Ambient.js";
import { createPost, Post } from "../render/Post.js";
import { NEUTRAL_ATMOSPHERE } from "../events/EventDirector.js";
import { clamp, dampTo, lerp } from "../util/rng.js";

export type SceneMode = "menu" | "showroom" | "run";
const MAX_COINS = 160;

interface CharInst { rig: Rig; anim: CharacterAnimator; id: string }

export class Scene3D {
  renderer: THREE.WebGLRenderer; scene = new THREE.Scene(); camera: THREE.PerspectiveCamera;
  env!: Environment; lib!: MaterialLibrary; chunkLib!: ChunkLibrary; particles = new Particles(700, 700);
  q: QualitySettings; tier: QualityTier; governor: QualityGovernor | null = null; autoQuality = true;
  mode: SceneMode = "menu";
  private game: Game; private canvas: HTMLCanvasElement;
  private time = 0; private menuDist = 4; private shake = 0; private boostPull = 0; private fov = 62; private flash = 0;
  private camPos = new THREE.Vector3(0, 4, 8); private camLook = new THREE.Vector3(0, 1.2, -10); private roll = 0; private lastLaneX = 0;
  private chunks = new Map<number, ChunkInstance>(); private chunkRoot = new THREE.Group();
  private chars = new Map<string, CharInst>(); private player: CharInst | null = null; private rival: CharInst | null = null;
  private playerRoot = new THREE.Group(); private rivalRoot = new THREE.Group();
  private showcaseId = "runner"; private showcaseSpin = 0; showcaseDrag = 0; private platform: THREE.Group;
  private blob: THREE.Mesh; private rivalBlob: THREE.Mesh;
  private obstacleFree = new Map<string, ObstacleModel[]>(); private obstacleActive = new Map<string, { type: string; m: ObstacleModel }>(); private obstacleRoot = new THREE.Group();
  private puFree = new Map<string, THREE.Group[]>(); private puActive = new Map<string, THREE.Group>(); private railFree: THREE.Group[] = []; private padFree: THREE.Group[] = []; private railActive = new Map<string, THREE.Group>(); private padActive = new Map<string, THREE.Group>();
  private coins: THREE.InstancedMesh; private collRoot = new THREE.Group();
  private stateTimer = 0; private prevAnim: AnimState = "idle"; private lastDust = 0; private doubleJumpT = 0; private landT = 0;
  private fpsAcc = 0; private fpsN = 0; fpsShown = 60; private _m = new THREE.Matrix4(); private _q = new THREE.Quaternion(); private _e = new THREE.Euler(); private _p = new THREE.Vector3(); private _s = new THREE.Vector3(1, 1, 1);
  private ambient: Ambient | null = null; private post: Post | null = null; private rim!: THREE.DirectionalLight; private shafts = new THREE.Group(); private fovKick = 0; private camDip = 0; private railT = 0;
  private buildBudgetMs = 6; private lastRegion = -1; private contextLost = false; private birds: THREE.Group | null = null; private plane: THREE.Mesh | null = null;
  private gradeEl: HTMLElement | null = typeof document !== "undefined" ? document.getElementById("grade") : null;
  stats = { drawCalls: 0, triangles: 0, chunks: 0, obstacles: 0, coins: 0 };

  constructor(canvas: HTMLCanvasElement, game: Game, requested: QualityTier | "AUTO" = "AUTO") {
    this.game = game; this.canvas = canvas;
    // Probe a throw-away context for device info (no GPU-heavy work), then create the real renderer.
    let tier: QualityTier;
    if (requested === "AUTO") { let gl: WebGLRenderingContext | null = null; try { const c = document.createElement("canvas"); gl = c.getContext("webgl") as WebGLRenderingContext | null; } catch { /* ignore */ } tier = detectTier(readDevice(gl)); }
    else tier = requested;
    this.autoQuality = requested === "AUTO"; this.tier = tier; this.q = QUALITY[tier];
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: this.q.antialias, powerPreference: "high-performance", alpha: false, stencil: false });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    canvas.addEventListener("webglcontextlost", (e) => { e.preventDefault(); this.contextLost = true; });
    canvas.addEventListener("webglcontextrestored", () => { this.contextLost = false; this.rebuildQuality(this.tier); });
    this.camera = new THREE.PerspectiveCamera(62, 1, 0.1, 1200);
    this.scene.add(this.chunkRoot, this.obstacleRoot, this.collRoot, this.playerRoot, this.rivalRoot, this.particles.group);
    this.coins = makeCoinMesh(MAX_COINS); this.collRoot.add(this.coins);
    this.blob = this.makeBlob(); this.rivalBlob = this.makeBlob(); this.scene.add(this.blob, this.rivalBlob);
    this.platform = this.makePlatform(); this.scene.add(this.platform); this.platform.visible = false;
    this.initQualityDependent();
    this.governor = this.autoQuality ? new QualityGovernor(this.tier) : null;
    this.onResize();
    this.setCharacter(game.progression.selectedCharacter);
  }

  // ───────────────────────── quality ─────────────────────────
  private initQualityDependent() {
    const q = this.q;
    this.renderer.setPixelRatio(Math.min(typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1, q.pixelRatioCap));
    this.lib?.dispose(); this.lib = new MaterialLibrary(q);
    if (this.env) { this.env.dispose(); this.scene.remove(this.env.sky, this.env.backdrop, ...this.env.clouds, this.env.hemi, this.env.sun, this.env.sun.target, this.env.fill, this.env.headlight); }
    this.env = new Environment(this.scene, this.renderer, q);
    this.chunkLib = new ChunkLibrary(this.lib, "nexus");
    this.particles.amount = q.particles; this.particles.setRainCount(q.rain); this.particles.setScale(this.canvas.height * 0.55);
    this.gradeEl?.classList.toggle("on", q.grading);
    this.ambient?.dispose(); if (this.ambient) this.scene.remove(this.ambient.group);
    this.ambient = q.ambientTraffic > 0 ? new Ambient(q) : null; if (this.ambient) this.scene.add(this.ambient.group);
    if (!this.rim) { this.rim = new THREE.DirectionalLight(0xbfd8ff, 0.9); this.rim.position.set(5, 6, -9); this.rim.target.position.set(0, 1, 0); this.scene.add(this.rim, this.rim.target); this.makeShafts(); }
    this.post?.dispose(); this.post = null;
    createPost(this.renderer, this.scene, this.camera, q).then((p) => { if (q === this.q) { this.post = p; this.onResize(); } else p?.dispose(); });
    this.clearChunks();
    this.lastRegion = -1;
  }
  /** Soft additive light shafts (visible mainly in the Ruins and at sunset). */
  private makeShafts() {
    const tex = softDot(64, "rgba(255,244,200,1)", "rgba(255,244,200,0)");
    for (let i = 0; i < 5; i++) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(5 + i, 40), new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, fog: false, side: THREE.DoubleSide }));
      m.position.set(-10 + i * 5.5, 14, -22 - i * 9); m.rotation.z = -0.35; m.rotation.y = 0.5; m.renderOrder = 4; this.shafts.add(m);
    }
    this.scene.add(this.shafts);
  }
  /** Public: apply a tier (e.g. from settings). "AUTO" re-runs detection. */
  setQuality(t: QualityTier | "AUTO") {
    this.autoQuality = t === "AUTO";
    const tier = t === "AUTO" ? detectTier(readDevice(this.renderer.getContext())) : t;
    this.governor = this.autoQuality ? new QualityGovernor(tier) : null;
    this.rebuildQuality(tier);
  }
  private rebuildQuality(tier: QualityTier) { this.tier = tier; this.q = QUALITY[tier]; this.initQualityDependent(); this.onResize(); }
  get qualityLabel() { return (this.autoQuality ? "AUTO·" : "") + this.tier; }

  // ───────────────────────── characters ─────────────────────────
  private getChar(id: string): CharInst {
    let c = this.chars.get(id);
    if (!c) { const rig = buildCharacter(id); c = { rig, anim: new CharacterAnimator(rig, id), id }; this.chars.set(id, c); }
    return c;
  }
  setCharacter(id: string) {
    const c = this.getChar(id);
    if (this.player && this.player !== c) this.playerRoot.remove(this.player.rig.root);
    this.player = c; this.playerRoot.add(c.rig.root);
  }
  /** Showroom: which character is shown on the turntable. */
  setShowcase(id: string) { this.showcaseId = id; if (this.mode === "showroom") this.setCharacter(id); }
  applyCharacterLook(id: string) { this.setCharacter(id); }
  private makeBlob() { const m = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.5), new THREE.MeshBasicMaterial({ map: softDot(64, "rgba(0,0,0,0.9)", "rgba(0,0,0,0)"), transparent: true, opacity: 0.45, depthWrite: false, fog: false })); m.rotation.x = -Math.PI / 2; m.position.y = 0.04; m.renderOrder = 2; return m; }
  private makePlatform() {
    const g = new THREE.Group(); const base = new THREE.Mesh(new THREE.CylinderGeometry(1.35, 1.5, 0.16, 40), new THREE.MeshStandardMaterial({ color: 0x1f2a3a, roughness: 0.35, metalness: 0.6 })); base.position.y = 0.0; g.add(base);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.32, 0.03, 8, 64), new THREE.MeshBasicMaterial({ color: 0x4fc3ff })); ring.rotation.x = Math.PI / 2; ring.position.y = 0.09; g.add(ring);
    const glow = new THREE.Mesh(new THREE.CircleGeometry(1.9, 40), new THREE.MeshBasicMaterial({ map: softDot(64, "rgba(80,190,255,1)", "rgba(80,190,255,0)"), transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false })); glow.rotation.x = -Math.PI / 2; glow.position.y = 0.01; g.add(glow);
    return g;
  }

  setMode(m: SceneMode) {
    this.mode = m;
    this.platform.visible = m === "showroom";
    if (m === "showroom") this.setCharacter(this.showcaseId);
    else this.setCharacter(m === "menu" ? this.game.progression.selectedCharacter : this.game.player.characterId);
    if (m === "run") { this.shake = 0; this.boostPull = 0; this.camPos.set(0, 4.4, 9.5); }
    this.stateTimer = 0;
  }

  onResize() {
    const w = Math.max(1, typeof window !== "undefined" ? window.innerWidth : 1280), h = Math.max(1, typeof window !== "undefined" ? window.innerHeight : 720);
    this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); this.post?.setSize(w, h, this.renderer.getPixelRatio());
    this.particles.setScale(h * Math.min(this.renderer.getPixelRatio(), this.q.pixelRatioCap) * 0.5);
  }

  // ───────────────────────── chunk streaming ─────────────────────────
  private clearChunks() { for (const c of this.chunks.values()) this.chunkRoot.remove(c.group); this.chunks.clear(); }
  private updateChunks(dist: number, seed: string) {
    const ci = Math.floor(Math.max(0, dist) / CHUNK_LENGTH);
    const ahead = this.q.chunksAhead, behind = 1;
    const t0 = performance.now(); let built = 0;
    for (let i = Math.max(0, ci - behind); i <= ci + ahead; i++) {
      if (this.chunks.has(i)) continue;
      const plan = getChunkPlan(seed, i);
      // always build chunks that are on screen now; defer far ones when over budget
      const need = i <= ci + 2;
      if (!need && (built > 0 && performance.now() - t0 > this.buildBudgetMs)) continue;
      const inst = this.chunkLib.instantiate(plan); built++;
      this.chunks.set(i, inst); this.chunkRoot.add(inst.group);
    }
    for (const [i, c] of this.chunks) if (i < ci - behind - 1 || i > ci + ahead + 2) { this.chunkRoot.remove(c.group); this.chunks.delete(i); }
    for (const [i, c] of this.chunks) { c.group.position.z = dist - c.plan.startDist; c.group.visible = true; void i; }
  }
  /** Prewarm the next region's templates while idle (one template per call). */
  private prewarm(dist: number, seed: string) {
    const ci = Math.floor(Math.max(0, dist) / CHUNK_LENGTH);
    for (let i = ci + this.q.chunksAhead + 1; i <= ci + this.q.chunksAhead + 4; i++) { const p = getChunkPlan(seed, i); if (!this.chunkLib.has(p)) { this.chunkLib.getTemplate(p); return; } }
  }

  // ───────────────────────── frame ─────────────────────────
  update(dt: number, fx: FxEvent[]) {
    if (this.contextLost) return;
    const g = this.game, p = g.player;
    this.time += dt;
    const running = g.phase === "running" || g.phase === "paused";
    const inRun = this.mode === "run" && running;
    const seed = g.seed || "menu";
    if (!inRun) this.menuDist += dt * 2.2;
    const dist = inRun ? g.distance : (this.mode === "run" ? g.distance : this.menuDist);
    const speed = inRun ? g.speed : 8;
    const atm = inRun ? g.events.atmosphere : NEUTRAL_ATMOSPHERE;

    // fps + governor
    this.fpsAcc += dt; this.fpsN++; if (this.fpsAcc > 0.5) { this.fpsShown = this.fpsN / this.fpsAcc; this.fpsAcc = 0; this.fpsN = 0; }
    if (this.governor && inRun && g.phase === "running") { const lower = this.governor.update(dt, true); if (lower) { this.rebuildQuality(lower); g.showToast(`Quality lowered to ${lower} to keep the frame rate up`); } }

    // environment
    const theme = themeAt(dist, atm);
    this.env.applyTheme(theme, atm.lightning);
    this.env.follow(this.camera, dt, speed);
    this.lib.setAtmosphere(atm.wet, atm.night); this.lib.update(dt, this.time, theme.enclosed > 0.5 ? 0.5 : atm.storm * 0.3);
    // rim light (separates the character from the background) + light shafts
    this.rim.intensity = 0.5 + (1 - theme.enclosed) * 0.7 + theme.enclosed * 0.4; this.rim.color.setHex(atm.night > 0.4 ? 0x7f9cff : atm.dusk > 0.4 ? 0xffb070 : 0xbfd8ff);
    const shaftAmt = (regIdx0 => (regIdx0 === 4 ? 0.16 : 0) + atm.dusk * 0.1 * (1 - theme.enclosed))(Math.floor(Math.max(0, dist) / 960) % REGIONS.length) * (1 - atm.storm) * (1 - atm.night);
    this.shafts.children.forEach((m: any, i: number) => { m.material.opacity = shaftAmt * (0.6 + 0.4 * Math.sin(this.time * 0.4 + i * 1.7)) * (this.q.particles > 0.5 ? 1 : 0); m.position.x = -10 + i * 5.5 + Math.sin(this.time * 0.1 + i) * 0.8; });
    this.ambient?.update(dt, Math.floor(Math.max(0, dist) / 960) % REGIONS.length, speed, theme.enclosed > 0.5, this.camera.position);
    const regIdx = Math.floor(Math.max(0, dist) / 960) % REGIONS.length;
    this.env.refreshProbe(this.time, `${regIdx}|${Math.round(atm.night * 3)}|${Math.round(atm.dusk * 3)}|${Math.round(atm.storm * 2)}`, this.lastRegion < 0);
    this.lastRegion = regIdx;
    this.renderer.setClearColor(this.env.fog.color);

    this.updateChunks(dist, seed); this.prewarm(dist, seed); this.emitAmbient(dt, dist);
    this.updateBirds(dt, theme.enclosed < 0.5);

    // characters
    this.updatePlayer(dt, inRun);
    this.updateRival(dt, inRun, dist);
    if (inRun || this.mode === "run") { this.syncObstacles(); this.syncCollectibles(dt); } else { this.hideEntities(); }

    // fx
    for (const e of fx) this.handleFx(e);
    this.updateCamera(dt, inRun, speed);

    this.particles.update(dt, this.camera.position, inRun ? speed : 0, g.boostTimer > 0 || g.powerups.speed > 0 ? 1 : 0, this.q.rain > 0 ? clamp(atm.rain, 0, 1) : 0);
    // lightning / flash tint
    this.flash = dampTo(this.flash, 0, 8, dt);
  }

  render() { if (this.contextLost) return; if (this.post) this.post.render(1 / 60); else this.renderer.render(this.scene, this.camera); const i = this.renderer.info; this.stats.drawCalls = i.render.calls; this.stats.triangles = i.render.triangles; this.stats.chunks = this.chunks.size; }

  // ───────────────────────── player & rival ─────────────────────────
  private animStateFor(): AnimState {
    const g = this.game, p = g.player;
    if (this.mode !== "run") return this.mode === "showroom" ? "idle" : "idle";
    if (g.phase === "results") return "victory";
    switch (p.movementState) {
      case "dead": return "death";
      case "stunned": return "hit";
      case "sliding": return "slide";
      case "wallRunning": case "wallJumping": return "wallRun";
      case "grinding": return "railGrind";
      case "grappling": case "swinging": return "grapple";
      case "airDashing": return "airDash";
      case "jumping": case "falling": case "rolling": return this.doubleJumpT > 0 ? "doubleJump" : p.vy > 0.5 ? "jump" : "fall";
      default: break;
    }
    if (p.landTimer > 0.01 && p.isGrounded) return "land";
    if (g.boostTimer > 0 || g.powerups.speed > 0) return "boost";
    return g.speed > 25 ? "sprint" : "run";
  }
  private updatePlayer(dt: number, inRun: boolean) {
    const c = this.player; if (!c) return; const g = this.game, p = g.player;
    this.doubleJumpT = Math.max(0, this.doubleJumpT - dt);
    const st = this.animStateFor();
    if (st !== this.prevAnim) { this.stateTimer = 0; this.prevAnim = st; } else this.stateTimer += dt;
    const root = this.playerRoot;
    if (this.mode === "run") {
      root.position.set(p.x, p.y, 0); root.rotation.y = 0; root.scale.setScalar(1);
      c.anim.boostGlow = g.boostTimer > 0 || g.powerups.speed > 0 ? 1 : 0; c.anim.shield = p.shieldCharges > 0 ? 1 : 0; c.anim.invuln = g.powerups.invuln > 0 ? 1 : 0; c.anim.hitFlash = clamp(p.hitFlash, 0, 1);
      if (p.invulnTimer > 0 && p.movementState !== "dead") c.rig.root.visible = Math.floor(this.time * 18) % 2 === 0 || g.powerups.invuln > 0; else c.rig.root.visible = true;
      c.anim.update(dt, { state: st, speed: g.speed, vy: p.vy, laneVel: p.laneVelX, wallSide: p.wallSide, timeInState: this.stateTimer, t: this.time });
      this.blob.visible = true; this.blob.position.set(p.x, 0.04 + (p.groundY ?? 0), 0); const hgt = Math.max(0, p.y - (p.groundY ?? 0)); this.blob.scale.setScalar(1 / (1 + hgt * 0.35)); (this.blob.material as THREE.MeshBasicMaterial).opacity = 0.5 / (1 + hgt * 0.5);
    } else if (this.mode === "showroom") {
      this.showcaseSpin += dt * 0.7 + this.showcaseDrag; this.showcaseDrag = 0;
      root.position.set(0, 0.1, 1.2); root.rotation.y = this.showcaseSpin; root.scale.setScalar(1.15); c.rig.root.visible = true;
      this.platform.position.set(0, -0.03, 1.2);
      c.anim.boostGlow = 0; c.anim.shield = 0; c.anim.invuln = 0; c.anim.hitFlash = 0;
      c.anim.update(dt, { state: Math.floor(this.time / 4) % 3 === 1 ? "run" : "idle", speed: 12, vy: 0, laneVel: 0, wallSide: 0, timeInState: this.stateTimer, t: this.time });
      this.blob.visible = false;
    } else {
      root.position.set(0.0, 0, 0); root.rotation.y = Math.PI * 0.12; root.scale.setScalar(1.0); c.rig.root.visible = true;
      c.anim.boostGlow = 0; c.anim.shield = 0; c.anim.invuln = 0; c.anim.hitFlash = 0;
      c.anim.update(dt, { state: "idle", speed: 0, vy: 0, laneVel: 0, wallSide: 0, timeInState: this.stateTimer, t: this.time });
      this.blob.visible = true; this.blob.position.set(0, 0.04, 0); this.blob.scale.setScalar(1);
    }
    // contact trail: dust while running
    if (this.mode === "run" && inRun && g.phase === "running" && p.isGrounded && p.movementState === "running") {
      this.lastDust -= dt; if (this.lastDust <= 0) { this.lastDust = 0.11 / Math.max(0.2, this.q.particles); this.particles.puff(p.x + (Math.random() - 0.5) * 0.2, 0.12, 0.5, this.dustColor(), 1, 0.55, 0.6, 0.5, 2); }
    }
    if (this.mode === "run" && p.movementState === "grinding") this.particles.burst(p.x, 0.55, 0.2, 0xffd27a, 2, 3, 0.3, 0.12, { grav: 9 });
    if (this.mode === "run" && p.movementState === "sliding") this.particles.burst(p.x, 0.1, 0.4, 0xd8d2c4, 1, 2, 0.35, 0.18, { grav: 6 });
    if (g.boostTimer > 0 && this.mode === "run") this.particles.trail(p.x + (Math.random() - 0.5) * 0.5, p.y + 0.9 + (Math.random() - 0.5) * 0.7, 0.6, 0xffc94a, 0.5, 0.4);
  }
  private dustColor() { const r = Math.floor(Math.max(0, this.game.distance) / 960) % 5; return [0xd9d2c3, 0xcfd2d6, 0x9aa0a6, 0xc9b79a, 0xb7c4a3][r]; }

  private updateRival(dt: number, inRun: boolean, dist: number) {
    const g = this.game, r = g.rivals.rival;
    const show = this.mode === "run" && !!r && r.active && !r.defeated && inRun;
    this.rivalRoot.visible = show; this.rivalBlob.visible = show;
    if (!show || !r) return;
    if (!this.rival) { this.rival = this.getChar("rival"); this.rivalRoot.add(this.rival.rig.root); }
    const map: Record<string, AnimState> = { run: "run", sprint: "sprint", jump: "jump", slide: "slide", stumble: "hit", boost: "boost", victory: "victory" };
    const st = map[r.anim] ?? "run";
    this.rivalRoot.position.set(r.x, r.y, -r.z); this.rivalRoot.rotation.y = 0;
    this.rival.anim.boostGlow = r.boostTimer > 0 ? 1 : 0;
    this.rival.anim.update(dt, { state: st, speed: r.speed, vy: r.vy, laneVel: 0, wallSide: 0, timeInState: r.animTimer, t: this.time });
    this.rivalBlob.position.set(r.x, 0.04, -r.z); void dist;
  }

  // ───────────────────────── obstacles & collectibles ─────────────────────────
  private getObstacleModel(type: string): ObstacleModel {
    const free = this.obstacleFree.get(type); const m = free?.pop();
    if (m) { m.group.visible = true; return m; }
    const nm = buildObstacle(type, this.lib); this.obstacleRoot.add(nm.group); return nm;
  }
  private syncObstacles() {
    const g = this.game; const seen = new Set<string>(); let n = 0;
    for (const o of g.world.getObstacles()) {
      if (o.broken) continue;
      if (o.z < -14 || o.z > 260) continue;
      seen.add(o.id); let a = this.obstacleActive.get(o.id);
      if (!a) { a = { type: o.type, m: this.getObstacleModel(o.type) }; this.obstacleActive.set(o.id, a); }
      const gr = a.m.group; gr.position.set(o.x, o.type === "falling_debris" ? o.y : 0, -o.z); gr.rotation.set(0, 0, 0); n++;
      if (o.fall) gr.rotation.y = o.fall.state === 1 ? this.time * 3 : 0;
      for (const an of a.m.anims) if (an.kind === "bob") an.node.position.y = Math.sin(this.time * an.speed * 3) * (an.amp ?? 0.05);
    }
    for (const [id, a] of this.obstacleActive) if (!seen.has(id)) { a.m.group.visible = false; let f = this.obstacleFree.get(a.type); if (!f) this.obstacleFree.set(a.type, f = []); f.push(a.m); this.obstacleActive.delete(id); }
    this.stats.obstacles = n;
  }
  private puModel(id: PowerUpId) { const f = this.puFree.get(id)?.pop(); if (f) { f.visible = true; return f; } const m = buildPowerup(id); this.collRoot.add(m); return m; }
  private syncCollectibles(dt: number) {
    const g = this.game; const seen = new Set<string>(); let nc = 0;
    const t = this.time;
    for (const c of g.world.getCollectibles()) {
      if (c.z < -4 || c.z > 230) continue;
      if (c.type === "coin") {
        if (nc >= MAX_COINS) continue;
        this._e.set(0, t * 3.2 + c.x, 0); this._q.setFromEuler(this._e); this._p.set(c.x, c.y + Math.sin(t * 4 + c.z) * 0.06, -c.z); this._s.set(1, 1, 1);
        this._m.compose(this._p, this._q, this._s); this.coins.setMatrixAt(nc++, this._m);
      } else if (c.type === "rail") {
        seen.add(c.id); let m = this.railActive.get(c.id); if (!m) { m = this.railFree.pop() ?? buildRail(c.depth); m.visible = true; if (!m.parent) this.collRoot.add(m); this.railActive.set(c.id, m); }
        m.position.set(c.x, 0, -c.z);
      } else if (c.type === "pad") {
        seen.add(c.id); let m = this.padActive.get(c.id); if (!m) { m = this.padFree.pop() ?? buildBoostPad(); m.visible = true; if (!m.parent) this.collRoot.add(m); this.padActive.set(c.id, m); }
        m.position.set(c.x, 0, -c.z);
      } else {
        seen.add(c.id); let m = this.puActive.get(c.id); if (!m) { m = this.puModel(c.type as PowerUpId); this.puActive.set(c.id, m); m.userData.id = c.type; }
        m.position.set(c.x, c.y + 0.2 + Math.sin(t * 3 + c.z) * 0.14, -c.z); m.rotation.y = t * 1.8; const h = m.getObjectByName("halo"); if (h) h.scale.setScalar(1.8 + Math.sin(t * 5) * 0.2);
      }
    }
    this.coins.count = nc; this.coins.instanceMatrix.needsUpdate = true; this.stats.coins = nc;
    const rel = (map: Map<string, THREE.Group>, free: THREE.Group[] | Map<string, THREE.Group[]>, keyOf: (m: THREE.Group) => string | null) => {
      for (const [id, m] of map) if (!seen.has(id)) { m.visible = false; map.delete(id); if (free instanceof Map) { const k = keyOf(m)!; let f = free.get(k); if (!f) free.set(k, f = []); f.push(m); } else free.push(m); }
    };
    rel(this.railActive, this.railFree, () => null); rel(this.padActive, this.padFree, () => null); rel(this.puActive, this.puFree, (m) => m.userData.id as string);
    void dt;
  }
  private hideEntities() {
    for (const [id, a] of this.obstacleActive) { a.m.group.visible = false; let f = this.obstacleFree.get(a.type); if (!f) this.obstacleFree.set(a.type, f = []); f.push(a.m); this.obstacleActive.delete(id); }
    for (const [id, m] of this.puActive) { m.visible = false; const k = m.userData.id as string; let f = this.puFree.get(k); if (!f) this.puFree.set(k, f = []); f.push(m); this.puActive.delete(id); }
    for (const [id, m] of this.railActive) { m.visible = false; this.railFree.push(m); this.railActive.delete(id); }
    for (const [id, m] of this.padActive) { m.visible = false; this.padFree.push(m); this.padActive.delete(id); }
    this.coins.count = 0; this.rivalRoot.visible = false; this.rivalBlob.visible = false;
  }

  // ───────────────────────── ambient: chunk emitters, birds, aircraft ─────────────────────────
  private emitAmbient(dt: number, dist: number) {
    const k = this.q.particles; if (k <= 0) return;
    for (const c of this.chunks.values()) {
      const dz = dist - c.plan.startDist; if (dz < -30 || dz > 150) continue;
      for (const e of c.emitters) {
        if (Math.random() > (e.rate ?? 1) * dt * k) continue;
        const x = (c.mirror ? -e.x : e.x), y = e.y, z = dz + e.z;
        switch (e.type) {
          case "steam": this.particles.puff(x, y, z, 0xf2f6fa, 2, 1.3, 1.6, 1.6); break;
          case "smoke": this.particles.puff(x, y, z, 0x6d7278, 2, 1.8, 2.4, 1.2); break;
          case "spark": this.particles.burst(x, y, z, 0xffc86a, 6, 3, 0.5, 0.12, { grav: 9 }); break;
          case "dust": this.particles.puff(x + (Math.random() - 0.5) * 8, y + Math.random() * 3, z + (Math.random() - 0.5) * 10, 0xe8e2d4, 1, 0.5, 2.2, 0.1); break;
          case "drip": this.particles.burst(x, y, z, 0xbfe0f0, 1, 0.2, 0.9, 0.08, { grav: 14, spread: 0.1 }); break;
          case "leaf": this.particles.burst(x + (Math.random() - 0.5) * 10, y, z + (Math.random() - 0.5) * 12, 0x7ab55c, 1, 0.6, 3, 0.16, { grav: 0.6, additive: false }); break;
          case "fire": this.particles.burst(x, y, z, 0xff8a2a, 3, 1.2, 0.6, 0.35, { grav: -2 }); break;
        }
      }
    }
  }
  private updateBirds(dt: number, open: boolean) {
    if (!this.birds) {
      this.birds = new THREE.Group(); const m = new THREE.MeshBasicMaterial({ color: 0x2a3340, side: THREE.DoubleSide, fog: true });
      for (let i = 0; i < 7; i++) { const b = new THREE.Mesh(new THREE.BufferGeometry(), m); const v = new Float32Array([-0.5, 0, 0, 0, 0.08, -0.1, 0, 0, 0.2, 0.5, 0, 0, 0, 0.08, -0.1, 0, 0, 0.2]); b.geometry.setAttribute("position", new THREE.BufferAttribute(v, 3)); b.userData = { ph: Math.random() * 6, r: 40 + Math.random() * 25, y: 20 + Math.random() * 18, a: Math.random() * 6 }; this.birds.add(b); }
      this.scene.add(this.birds);
    }
    this.birds.visible = open && this.q.particles >= 0.6;
    if (!this.birds.visible) return;
    for (const b of this.birds.children) { const u = b.userData; u.a += dt * 0.12; b.position.set(Math.sin(u.a) * u.r, u.y + Math.sin(this.time + u.ph) * 1.2, -Math.cos(u.a) * u.r - 30); b.rotation.y = -u.a; b.scale.set(1, 1 + Math.sin(this.time * 9 + u.ph) * 0.6, 1); }
  }

  // ───────────────────────── fx ─────────────────────────
  private handleFx(e: FxEvent) {
    const P = this.particles, g = this.game; const x = e.x ?? g.player.x, y = e.y ?? 0.8, z = e.z != null ? -e.z : 0;
    switch (e.type) {
      case "coin": P.burst(x, y, z, 0xffd23f, 5, 3, 0.4, 0.22); break;
      case "powerup": { const d = e.id && POWERUPS[e.id as PowerUpId]; P.ring(x, 1, 0, d ? parseInt(d.color.slice(1), 16) : 0xffffff, 22, 0.5, 5, 0.6, 0.35); break; }
      case "hit": this.shake = Math.max(this.shake, 0.9); this.flash = 0.5; P.burst(g.player.x, 1, 0, 0xff5a4a, 16, 5, 0.5, 0.3); break;
      case "shieldBreak": P.ring(g.player.x, 1, 0, 0x4fc3ff, 30, 0.6, 7, 0.6, 0.4); this.shake = Math.max(this.shake, 0.4); break;
      case "smash": P.burst(x, y, z, 0xd9c7a0, 18, 6, 0.7, 0.35, { grav: 12, additive: false }); P.puff(x, y, z, 0xc9c2b4, 4, 1.4, 0.9); this.shake = Math.max(this.shake, 0.35); break;
      case "land": this.camDip = Math.max(this.camDip, (e.value ?? 0.5) * 0.35); P.puff(g.player.x, 0.1, 0, this.dustColor(), e.value && e.value > 0.7 ? 6 : 3, 0.9, 0.7, 0.8); if ((e.value ?? 0) > 0.7) this.shake = Math.max(this.shake, 0.18); break;
      case "jump": P.puff(g.player.x, 0.1, 0, this.dustColor(), 3, 0.7, 0.6, 0.6); break;
      case "doubleJump": this.doubleJumpT = 0.55; P.ring(g.player.x, g.player.y + 0.5, 0, 0xffffff, 20, 0.35, 4.5, 0.4, 0.28); break;
      case "slide": P.puff(g.player.x, 0.1, 0.2, this.dustColor(), 4, 0.8, 0.6, 0.4); break;
      case "dash": P.burst(g.player.x, g.player.y + 0.9, 0.5, 0xbfe9ff, 14, 2, 0.4, 0.3, { spread: 0.4 }); this.shake = Math.max(this.shake, 0.2); break;
      case "wallRun": P.burst(g.player.x, g.player.y + 0.8, 0, 0xe8e2d4, 8, 2.5, 0.4, 0.2); break;
      case "grapple": P.ring(g.player.x, g.player.y + 1.4, 0, 0xffe27a, 14, 0.3, 3, 0.35, 0.22); break;
      case "nearMiss": P.burst(g.player.x, 1, 0, 0xffffff, 6, 3, 0.35, 0.18); this.fovKick = Math.max(this.fovKick, 3.5); break;
      case "boost": P.ring(g.player.x, 0.9, 0, 0xffc94a, 30, 0.4, 8, 0.6, 0.45); this.shake = Math.max(this.shake, 0.25); break;
      case "regionEnter": this.flash = 0.35; this.fovKick = Math.max(this.fovKick, 6); break;
      case "lightning": this.flash = 1; break;
      case "impact": P.burst(x, 0.3, z, 0xcfc8b8, 8, 4, 0.5, 0.3, { grav: 12, additive: false }); this.shake = Math.max(this.shake, 0.3); break;
      case "death": P.burst(g.player.x, 1, 0, 0xff6a4a, 40, 7, 0.9, 0.4); this.shake = 1.2; break;
      case "railStart": P.burst(x, 0.5, 0, 0xffd27a, 10, 3, 0.4, 0.15); this.fovKick = Math.max(this.fovKick, 2); break;
      case "rival": if (e.id === "defeated") P.burst(e.x ?? 0, 1.2, -(e.z ?? 0), 0xffffff, 18, 5, 0.6, 0.3); break;
      default: break;
    }
  }

  // ───────────────────────── camera ─────────────────────────
  private updateCamera(dt: number, inRun: boolean, speed: number) {
    const g = this.game, p = g.player, cam = this.camera; const aspect = cam.aspect;
    const boost = g.boostTimer > 0 || g.powerups.speed > 0 ? 1 : 0;
    this.boostPull = dampTo(this.boostPull, boost, 5, dt);
    let tx: number, ty: number, tz: number, lx: number, ly: number, lz: number, baseFov: number;
    if (this.mode === "run") {
      const dead = p.movementState === "dead";
      tx = p.x * 0.62; ty = 3.55 + p.y * 0.42 - (p.movementState === "sliding" ? 0.35 : 0); tz = 6.7 + this.boostPull * 1.5 + (dead ? 2.5 : 0);
      this.fovKick = dampTo(this.fovKick, 0, 3.5, dt); this.camDip = dampTo(this.camDip, 0, 7, dt); this.railT = dampTo(this.railT, p.movementState === "grinding" ? 1 : 0, 5, dt);
      ty += -this.camDip - this.railT * 0.35 + (p.vy > 0 ? Math.min(0.25, p.vy * 0.02) : 0); tz += this.railT * 0.6;
      lx = p.x * 0.8; ly = 1.25 + p.y * 0.4 - this.camDip * 0.3; lz = -14;
      baseFov = 60 + clamp((speed - 14) * 0.42, 0, 9) + this.boostPull * 9 + this.fovKick;
      if (aspect < 1) baseFov *= 1 + (1 - aspect) * 0.55;
      const laneVel = p.laneVelX; this.roll = dampTo(this.roll, clamp(-laneVel * 0.0042, -0.07, 0.07), 7, dt);
    } else if (this.mode === "showroom") {
      tx = 0; ty = 1.25; tz = aspect < 1 ? 6.2 : 4.6; lx = 0; ly = 0.95; lz = 1.2; baseFov = aspect < 1 ? 42 : 36; this.roll = 0;
    } else {
      const a = this.time * 0.18; tx = Math.sin(a) * 2.4 + 1.2; ty = 1.5 + Math.sin(a * 0.7) * 0.15; tz = 4.6 + Math.cos(a) * 0.5; lx = 0; ly = 1.05; lz = -1; baseFov = aspect < 1 ? 46 : 38; this.roll = 0;
    }
    const kPos = this.mode === "run" ? 9 : 4;
    this.camPos.x = dampTo(this.camPos.x, tx, kPos, dt); this.camPos.y = dampTo(this.camPos.y, ty, kPos * 0.8, dt); this.camPos.z = dampTo(this.camPos.z, tz, 6, dt);
    this.camLook.x = dampTo(this.camLook.x, lx, 10, dt); this.camLook.y = dampTo(this.camLook.y, ly, 8, dt); this.camLook.z = dampTo(this.camLook.z, lz, 8, dt);
    this.fov = dampTo(this.fov, baseFov, 4, dt);
    this.shake = Math.max(0, this.shake - dt * 2.4);
    const s = this.shake * this.shake * 0.28, tt = this.time * 60;
    cam.position.set(this.camPos.x + Math.sin(tt * 1.3) * s, this.camPos.y + Math.cos(tt * 1.7) * s, this.camPos.z);
    cam.lookAt(this.camLook); cam.rotateZ(this.roll + Math.sin(tt * 0.9) * s * 0.05);
    if (Math.abs(cam.fov - this.fov) > 0.01) { cam.fov = this.fov; cam.updateProjectionMatrix(); }
    void inRun;
  }

  dispose() { this.post?.dispose(); this.ambient?.dispose(); this.particles.dispose(); this.lib.dispose(); this.env.dispose(); this.renderer.dispose(); }
}
