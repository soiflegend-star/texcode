/**
 * Nexus Runner — Core Game Loop / orchestrator.
 *
 * Can run fully headless (`new Game(null, { headless: true })`) which is how the
 * automated tests drive the real simulation (player, world generation, events, rivals,
 * missions, progression, AUVYRR) without WebGL.
 */
import { auvyrrBridge } from "../auvyrr/AuvyrrBridge.js";
import { GameStateSnapshot } from "../auvyrr/types.js";
import { Player, NO_ABILITIES } from "../movement/Player.js";
import { WorldGenerator, Obstacle, Collectible } from "../world/WorldGenerator.js";
import { EventDirector } from "../events/EventDirector.js";
import { ProgressionManager, RunOutcome } from "../progression/ProgressionManager.js";
import { InputManager } from "./InputManager.js";
import { Renderer } from "./Renderer.js";
import { AudioManager } from "../audio/AudioManager.js";
import { MissionManager, Mission } from "../progression/MissionManager.js";
import { RivalManager, RivalState } from "../events/RivalManager.js";
import {
  CHARACTERS, EVENTS, EVENT_IDS, POWERUPS, PowerUpId, REGIONS, RIVAL_PERSONALITIES, RivalPersonality,
  regionAtDistance, regionSegment, CHARACTER_IDS, UPGRADES, OBSTACLES,
} from "../data/GameData.js";
import { clamp, damp, makeRng } from "../util/rng.js";
import type { Scene3D } from "./Scene3D.js";

export type GamePhase = "menu" | "characterSelect" | "missions" | "progress" | "settings" | "running" | "paused" | "results";

export type FxType =
  | "coin" | "powerup" | "hit" | "shieldBreak" | "smash" | "land" | "jump" | "doubleJump" | "slide" | "dash" | "wallRun" | "grapple"
  | "nearMiss" | "boost" | "regionEnter" | "lightning" | "impact" | "death" | "rival" | "combo" | "missionDone" | "eventStart" | "eventEnd" | "railStart" | "uiClick" | "start";
export interface FxEvent { type: FxType; x?: number; y?: number; z?: number; id?: string; value?: number; text?: string }

export interface RunSummary {
  score: number; distance: number; coins: number; maxCombo: number; time: number; characterId: string;
  missionsCompleted: Mission[]; missionReward: number; outcome: RunOutcome; rivalsDefeated: number; regionsReached: string[];
  newHighScore: boolean;
}

export interface GameOptions { headless?: boolean; storage?: Storage | null; seed?: string; useAudio?: boolean }

const MAX_SPEED = 36;

export class Game {
  canvas: HTMLCanvasElement | null;
  ctx: CanvasRenderingContext2D | null = null;
  width = 0; height = 0;
  headless: boolean;

  phase: GamePhase = "menu";
  player = new Player();
  world = new WorldGenerator();
  events = new EventDirector();
  progression: ProgressionManager;
  input: InputManager;
  renderer: Renderer;
  scene3d: Scene3D | null = null;
  audio: AudioManager;
  missions: MissionManager;
  rivals = new RivalManager();
  use3D = false;

  // Run state
  runId = "";
  distance = 0; score = 0; coinsF = 0; coins = 0;
  speed = 14; baseSpeed = 14;
  timeElapsed = 0; combo = 0; maxCombo = 0; comboTimer = 0;
  flow = 0; boostTimer = 0;
  riskLevel = 0.3; recentFailures = 0; recentSuccesses = 0;
  seed = ""; dyingTimer = 0; timeScale = 1;
  powerups: Record<PowerUpId, number> = { shield: 0, magnet: 0, speed: 0, coinx2: 0, invuln: 0, slowmo: 0, scorex2: 0 };
  lastSummary: RunSummary | null = null;
  hint = ""; hintTimer = 0;
  rivalsDefeated = 0; powerupsCollected = 0; nearMisses = 0; eventsSurvived = 0;
  regionsReached = new Set<number>();
  fxQueue: FxEvent[] = [];
  toast: { text: string; timer: number } | null = null;
  hitPenalty = 0; // 0..1 temporary speed loss after a hit
  rewardsGranted = 0;
  fps = 60;
  /** fixed-seed override for deterministic tests */
  fixedSeed: string | null;

  // Callbacks used by RivalManager
  onRivalFx: ((r: RivalState, what: string) => void) | null = null;
  /** UI hook: receives every frame's drained fx list (vibration, screen flashes, banners). */
  fxHook: ((list: FxEvent[]) => void) | null = null;

  private lastTime = 0;
  private rafId = 0;
  private isRunning = false;
  private counters = { jumps: 0, slides: 0, advanced: 0 };
  private uiListeners: Array<() => void> = [];
  private frameTimes: number[] = [];

  constructor(canvas: HTMLCanvasElement | null, opts: GameOptions = {}) {
    this.canvas = canvas;
    this.headless = !!opts.headless || typeof window === "undefined";
    this.fixedSeed = opts.seed ?? null;
    this.progression = new ProgressionManager(opts.storage);
    this.missions = new MissionManager(opts.storage);
    this.progression.load();
    this.input = new InputManager(this.headless ? null : canvas);
    this.renderer = new Renderer(this);
    this.audio = new AudioManager(opts.useAudio === false || this.headless);
    this.audio.setMuted(this.progression.settings.muted);

    this.events.onLightning = () => this.fx({ type: "lightning" });
    this.events.onEventStart = (e) => this.fx({ type: "eventStart", id: e.id, text: e.def.name });
    this.events.onEventEnd = (e) => { this.eventsSurvived++; this.missions.add("events", 1); this.fx({ type: "eventEnd", id: e.id }); };
    this.world.onRegionChanged = (reg, seg) => this.onRegionEntered(reg.index, seg);
    this.world.onObstacleImpact = (o) => this.fx({ type: "impact", x: o.x, y: 0, z: o.z });
    this.onRivalFx = (r, what) => this.fx({ type: "rival", id: what, x: r.x, z: r.z });
    this.missions.onComplete = (m) => { this.fx({ type: "missionDone", text: m.title }); this.showToast(`Mission complete: ${m.title}`); };

    this.registerAuvyrr();
    if (!this.headless && canvas) {
      this.resize();
      window.addEventListener("resize", () => this.resize());
      document.addEventListener("visibilitychange", () => { if (document.hidden && this.phase === "running") this.togglePause(); });
      window.addEventListener("blur", () => { if (this.phase === "running") this.togglePause(); });
    }
  }

  /** Called by main.ts after the (optional) 3D scene has been created. */
  attachScene(scene: Scene3D | null) {
    this.scene3d = scene;
    this.use3D = !!scene;
    if (!scene && this.canvas && !this.headless) {
      const ctx = this.canvas.getContext("2d");
      if (ctx) this.ctx = ctx;
    }
  }

  private resize() {
    if (!this.canvas) return;
    this.width = window.innerWidth; this.height = window.innerHeight;
    this.scene3d?.onResize();
    if (!this.use3D && this.ctx) {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.canvas.width = this.width * dpr; this.canvas.height = this.height * dpr;
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
  }

  // ───────────────────────── UI subscription ─────────────────────────
  onChange(fn: () => void) { this.uiListeners.push(fn); }
  private notify() { for (const f of this.uiListeners) f(); }
  fx(e: FxEvent) { if (this.fxQueue.length < 200) this.fxQueue.push(e); }
  drainFx(): FxEvent[] { const q = this.fxQueue; this.fxQueue = []; return q; }
  showToast(text: string, t = 2.6) { this.toast = { text, timer: t }; }

  setPhase(p: GamePhase) {
    if (this.phase === p) return;
    this.phase = p;
    this.scene3d?.setMode(p === "running" || p === "paused" ? "run" : p === "characterSelect" ? "showroom" : "menu");
    this.notify();
  }

  // ───────────────────────── Loop ─────────────────────────
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastTime = typeof performance !== "undefined" ? performance.now() : Date.now();
    if (typeof requestAnimationFrame !== "undefined") this.rafId = requestAnimationFrame(this.loop);
  }
  stop() { this.isRunning = false; if (this.rafId && typeof cancelAnimationFrame !== "undefined") cancelAnimationFrame(this.rafId); }

  private loop = (now: number) => {
    if (!this.isRunning) return;
    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    const dt = clamp(rawDt, 0, 0.05);
    this.trackFps(rawDt);
    this.frame(dt);
    this.rafId = requestAnimationFrame(this.loop);
  };

  private trackFps(rawDt: number) {
    if (rawDt <= 0 || rawDt > 1) return;
    this.frameTimes.push(rawDt);
    if (this.frameTimes.length > 60) this.frameTimes.shift();
    let sum = 0; for (const f of this.frameTimes) sum += f;
    this.fps = this.frameTimes.length / sum;
  }

  /** One render frame: simulate (if running) then render. */
  frame(dt: number) {
    if (this.phase === "running") this.step(dt);
    if (this.toast) { this.toast.timer -= dt; if (this.toast.timer <= 0) this.toast = null; }
    if (this.hintTimer > 0) { this.hintTimer -= dt; if (this.hintTimer <= 0) this.hint = ""; }
    this.render(dt);
  }

  private render(dt: number) {
    const fx = this.drainFx();
    this.audio.onFx(fx, this);
    this.fxHook?.(fx);
    if (this.use3D && this.scene3d) { this.scene3d.update(dt, fx); this.scene3d.render(); }
    else if (!this.headless) this.renderer.draw();
  }

  // ───────────────────────── Simulation ─────────────────────────
  baseSpeedAt(dist = this.distance) {
    const def = this.player.def.sim;
    return Math.min(WorldGenerator.speedAt(dist) * def.speedMult, MAX_SPEED + def.maxSpeedBonus);
  }

  isInvulnerable() { return this.powerups.invuln > 0 || this.powerups.speed > 0 || this.boostTimer > 0 || this.player.invulnTimer > 0; }

  /** Advance the simulation by `rawDt` seconds. */
  step(rawDt: number) {
    if (this.phase !== "running") return;
    const p = this.player;

    // Pause request
    if (this.input.pausePressed) { this.input.consumePause(); this.togglePause(); return; }

    // time scale (slow motion power-up)
    const targetScale = this.powerups.slowmo > 0 ? 0.6 : 1;
    this.timeScale += (targetScale - this.timeScale) * damp(6, rawDt);
    const dt = rawDt * this.timeScale;

    // dying: freeze the world, let the death animation play
    if (this.dyingTimer > 0) {
      this.dyingTimer -= rawDt;
      this.speed = Math.max(0, this.speed - rawDt * 30);
      p.update(dt, this.speed);
      p.clearEvents();
      if (this.dyingTimer <= 0) this.endRun();
      return;
    }

    this.timeElapsed += dt;

    // ── Input → player ──
    p.handleInput(this.input, dt);
    if (this.input.dashPressed) { this.input.consumeDash(); if (!p.isGrounded && p.abilities.airDash && p.dashCooldown <= 0 && p.stamina >= p.def.sim.airDashCost) p.airDash(); }
    if (this.input.grapplePressed) { this.input.consumeGrapple(); p.startGrapple(); }
    if (this.input.boostPressed) { this.input.consumeBoost(); this.tryBoost(); }

    // ── Speed ──
    let target = this.baseSpeedAt();
    target *= this.events.getSpeedMultiplier();
    if (this.powerups.speed > 0) target *= 1.4;
    if (this.boostTimer > 0) target *= 1.3;
    if (p.dashTimer > 0) target *= 1.2;
    target *= 1 - this.hitPenalty * 0.55;
    target = Math.min(target, MAX_SPEED * 1.6);
    this.speed += (target - this.speed) * damp(3.2, dt);
    this.baseSpeed = this.baseSpeedAt();
    this.hitPenalty = Math.max(0, this.hitPenalty - dt * 0.9);

    p.update(dt, this.speed);
    this.distance += this.speed * dt;

    // Score
    this.score += this.speed * dt * this.scoreMultiplier() * 0.9;

    // ── Power-up timers ──
    for (const id of Object.keys(this.powerups) as PowerUpId[]) if (this.powerups[id] > 0 && id !== "shield") this.powerups[id] = Math.max(0, this.powerups[id] - rawDt * (id === "slowmo" ? 1 : this.timeScale));
    if (this.boostTimer > 0) { this.boostTimer -= dt; this.flow = Math.max(0, this.flow - dt * 22); if (this.boostTimer <= 0) this.fx({ type: "boost", value: 0 }); }

    // combo decay
    if (this.combo > 0) { this.comboTimer -= dt; if (this.comboTimer <= 0) this.breakCombo(); }

    // ── World / events / rivals ──
    this.world.update(dt, {
      distance: this.distance, speed: this.speed, player: p, flags: this.events.getWorldFlags(),
      features: { rail: p.abilities.railGrind }, magnet: this.powerups.magnet > 0,
    });
    this.events.update(dt, this);
    this.rivals.update(dt, this);

    this.checkCollisions();
    this.trackNearMiss();

    // Region progress / mission trackers
    this.missions.add("distance", this.speed * dt);
    this.missions.setBest("score", this.score);
    this.syncPlayerCounters();
    this.emitPlayerFx();

    // Flow
    if (this.combo === 0) this.flow = Math.max(0, this.flow - dt * 3);
  }

  scoreMultiplier() { return this.comboMultiplier() * (this.powerups.scorex2 > 0 ? 2 : 1); }
  comboMultiplier() { return clamp(1 + Math.floor(this.combo / 8), 1, 5); }

  private tryBoost() {
    if (this.boostTimer > 0 || this.flow < 100) return false;
    this.boostTimer = 4.2;
    this.fx({ type: "boost", value: 1 });
    auvyrrBridge.emit({ type: "ABILITY_USED", runId: this.runId, payload: { ability: "boost" } });
    return true;
  }
  get boostReady() { return this.flow >= 100 && this.boostTimer <= 0; }

  private syncPlayerCounters() {
    const p = this.player;
    if (p.jumpCount > this.counters.jumps) { this.missions.add("jumps", p.jumpCount - this.counters.jumps); this.counters.jumps = p.jumpCount; }
    if (p.slideCount > this.counters.slides) { this.missions.add("slides", p.slideCount - this.counters.slides); this.counters.slides = p.slideCount; }
    if (p.advancedMoveCount > this.counters.advanced) { this.missions.add("advanced", p.advancedMoveCount - this.counters.advanced); this.counters.advanced = p.advancedMoveCount; }
  }

  private emitPlayerFx() {
    const p = this.player, e = p.ev;
    if (e.jumped) this.fx({ type: "jump", x: p.x, y: p.y });
    if (e.doubleJumped) this.fx({ type: "doubleJump", x: p.x, y: p.y });
    if (e.landed) this.fx({ type: "land", x: p.x, value: p.landTimer > 0.2 ? 1 : 0.5 });
    if (e.slid) this.fx({ type: "slide", x: p.x });
    if (e.dashed) this.fx({ type: "dash", x: p.x, y: p.y });
    if (e.wallRun) this.fx({ type: "wallRun", x: p.x, y: p.y });
    if (e.grapple) this.fx({ type: "grapple", x: p.x, y: p.y });
    p.clearEvents();
  }

  private checkCollisions() {
    const p = this.player;
    if (!p.alive) return;
    for (const o of this.world.getNearbyObstacles(p.z, 8)) {
      if (o.hit || o.broken) continue;
      if (!p.collidesWith({ x: o.x, y: o.y, z: o.z, width: o.width, height: o.height, depth: o.depth })) continue;
      this.onHit(o);
      if (!p.alive) return;
    }
    for (const c of this.world.getNearbyCollectibles(p.z, 6)) {
      if (c.type === "rail") {
        if (p.abilities.railGrind && p.railTimer <= 0 && Math.abs(c.x - p.x) < 1.2 && Math.abs(c.z - p.z) < c.depth / 2 && p.y < 1.8) {
          if (p.startRailGrind(Math.max(0.6, c.depth / Math.max(8, this.speed)))) { this.fx({ type: "railStart", x: c.x }); this.score += c.value; this.world.removeCollectible(c); this.addCombo(2); }
        }
        continue;
      }
      if (c.type === "pad") {
        if (p.y < 1.4 && Math.abs(c.x - p.x) < 1.3 && Math.abs(c.z - p.z) < c.depth / 2 + 0.3) {
          this.world.removeCollectible(c); this.boostTimer = Math.max(this.boostTimer, 2.2); this.score += c.value; this.addCombo(1);
          this.fx({ type: "boost", value: 0.6 });
        }
        continue;
      }
      if (p.collidesWith({ x: c.x, y: c.y - 0.45, z: c.z, width: c.width + 0.3, height: c.height + 1.1, depth: c.depth + 0.2 })) this.onCollect(c);
    }
  }

  private onHit(o: Obstacle) {
    const p = this.player;
    // Invulnerability (power-up / boost / star): plough through
    if (this.powerups.invuln > 0 || this.powerups.speed > 0 || this.boostTimer > 0) { o.broken = true; this.fx({ type: "smash", x: o.x, y: o.y + o.height / 2, z: o.z, id: o.type }); this.score += 40; this.addCombo(1); return; }
    // Heavy smashes low obstacles
    if (p.def.sim.smashLow && o.kind === "jump" && p.smashCooldown <= 0) {
      o.broken = true; p.smashCooldown = 4; this.fx({ type: "smash", x: o.x, y: o.y + o.height / 2, z: o.z, id: o.type }); this.score += 60; this.addCombo(2); return;
    }
    if (p.invulnTimer > 0) return;
    o.hit = true;
    const shieldBefore = p.shieldCharges;
    const dmg = p.takeDamage(o.damage);
    this.recentFailures++;
    this.audio.vibrate?.(dmg ? 120 : 40);
    if (!dmg) {
      if (shieldBefore > 0) { this.fx({ type: "shieldBreak", x: o.x, z: o.z }); this.score += 25; }
      return;
    }
    this.combo = 0; this.flow = Math.max(0, this.flow - 30); this.hitPenalty = 1;
    this.fx({ type: "hit", x: p.x, y: p.y + 1, z: 0, id: o.type });
    auvyrrBridge.emit({ type: "PLAYER_FAILED", runId: this.runId, payload: { obstacleType: o.type, distance: this.distance } });
    if (!p.alive) {
      this.fx({ type: "death", x: p.x });
      auvyrrBridge.emit({ type: "PLAYER_DIED", runId: this.runId, payload: { distance: this.distance, cause: o.type } });
      this.dyingTimer = 1.5;
    }
  }

  private onCollect(c: Collectible) {
    const p = this.player;
    this.world.removeCollectible(c);
    this.recentSuccesses++;
    if (c.type === "coin") {
      const mult = (this.powerups.coinx2 > 0 ? 2 : 1) * (1 + 0.1 * this.progression.getUpgradeLevel("coinval"));
      this.coinsF += c.value * mult;
      this.coins = Math.floor(this.coinsF);
      this.score += 10 * this.scoreMultiplier();
      this.missions.add("coins", c.value * mult >= 2 ? Math.round(c.value * mult) : 1);
      this.addCombo(1); this.flow = Math.min(100, this.flow + 2.2);
      this.fx({ type: "coin", x: c.x, y: c.y, z: c.z });
    } else {
      const id = c.type as PowerUpId;
      const def = POWERUPS[id];
      if (id === "shield") p.shieldCharges = Math.min(2, p.shieldCharges + 1);
      else {
        let d = def.duration;
        if (id === "magnet") d += 2 * this.progression.getUpgradeLevel("magnet");
        this.powerups[id] = d;
        if (id === "slowmo") this.fx({ type: "boost", value: 0 });
      }
      this.powerupsCollected++;
      this.missions.add("powerups", 1);
      this.score += 100; this.addCombo(2); this.flow = Math.min(100, this.flow + 8);
      this.fx({ type: "powerup", x: c.x, y: c.y, z: c.z, id });
    }
    auvyrrBridge.emit({ type: "REWARD_COLLECTED", runId: this.runId, payload: { type: c.type, value: c.value } });
  }

  private addCombo(n: number) {
    const before = this.combo;
    this.combo += n; this.comboTimer = 3.4;
    if (this.combo > this.maxCombo) this.maxCombo = this.combo;
    this.missions.setCombo(this.combo);
    if (before === 0) auvyrrBridge.emit({ type: "COMBO_STARTED", runId: this.runId });
    if (Math.floor(before / 8) !== Math.floor(this.combo / 8)) this.fx({ type: "combo", value: this.comboMultiplier() });
    if (this.flow >= 100 && before < 100) auvyrrBridge.emit({ type: "FLOW_PEAK", runId: this.runId });
  }
  private breakCombo() { if (this.combo > 4) auvyrrBridge.emit({ type: "COMBO_BROKEN", runId: this.runId, payload: { combo: this.combo } }); this.combo = 0; }

  private trackNearMiss() {
    const p = this.player;
    for (const o of this.world.getObstacles()) {
      if (o.nearMissed || o.hit || o.broken) continue;
      if (o.z + o.depth / 2 < -0.3) {
        o.nearMissed = true;
        const lat = Math.abs(p.x - o.x) - o.width / 2 - p.width / 2;
        const vert = o.kind === "jump" ? p.y - (o.y + o.height) : o.kind === "slide" ? o.y - (p.y + p.height) : 9;
        const close = (o.kind === "block" && lat < 0.75 && lat > -0.01) || (o.kind !== "block" && vert < 0.5 && vert > -0.05 && lat < 0.1);
        if (close && p.alive) {
          this.nearMisses++; this.missions.add("nearmiss", 1);
          this.score += 50; this.addCombo(2); this.flow = Math.min(100, this.flow + 6);
          this.fx({ type: "nearMiss", x: p.x, y: p.y + 1 });
          auvyrrBridge.emit({ type: "PLAYER_NEAR_MISSED", runId: this.runId, payload: { obstacle: o.type } });
        }
      }
    }
  }

  private onRegionEntered(index: number, segment: number) {
    const ri = index % REGIONS.length;
    this.regionsReached.add(segment);
    this.missions.setBest("regions", new Set([...this.regionsReached].map((s) => s % REGIONS.length)).size);
    const isNew = this.progression.markRegionDiscovered(ri);
    this.fx({ type: "regionEnter", id: REGIONS[ri].id, text: REGIONS[ri].name });
    this.showToast(`${isNew ? "Discovered: " : "Entering: "}${REGIONS[ri].name}`, 3.2);
    this.events.onRegionChanged(this);
    this.score += 250;
    auvyrrBridge.emit({ type: "NEW_REGION_ENTERED", runId: this.runId, payload: { regionId: REGIONS[ri].id, segment, distance: this.distance, firstTime: isNew } });
  }

  // Rival hooks
  onRivalOvertake(playerOvertook: boolean) { this.fx({ type: "rival", id: playerOvertook ? "playerPass" : "rivalPass" }); if (playerOvertook) { this.score += 150; this.addCombo(3); } }
  onRivalDefeated(r: RivalState) { this.rivalsDefeated++; this.score += 750; this.coinsF += 20; this.coins = Math.floor(this.coinsF); this.showToast(`Rival ${r.name} left behind! +750`, 2.8); this.fx({ type: "rival", id: "defeated" }); }

  // ───────────────────────── Run lifecycle ─────────────────────────
  startRun(characterId?: string) {
    const id = characterId && this.progression.isCharacterUnlocked(characterId) ? characterId : (this.progression.isCharacterUnlocked(this.progression.selectedCharacter) ? this.progression.selectedCharacter : "runner");
    this.runId = `run_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.seed = this.fixedSeed ?? `${Date.now()}`;
    this.distance = 0; this.score = 0; this.coinsF = 0; this.coins = 0;
    this.timeElapsed = 0; this.combo = 0; this.maxCombo = 0; this.comboTimer = 0; this.flow = 0; this.boostTimer = 0;
    this.recentFailures = 0; this.recentSuccesses = 0; this.riskLevel = 0.3; this.dyingTimer = 0; this.timeScale = 1;
    this.hitPenalty = 0; this.rewardsGranted = 0; this.rivalsDefeated = 0; this.powerupsCollected = 0; this.nearMisses = 0; this.eventsSurvived = 0;
    for (const k of Object.keys(this.powerups) as PowerUpId[]) this.powerups[k] = 0;
    this.regionsReached = new Set([0]);
    this.counters = { jumps: 0, slides: 0, advanced: 0 };
    this.input.clearAll();

    this.player.reset(id, this.progression.getAbilityUnlocks(), 8 * this.progression.getUpgradeLevel("stamina"));
    if (this.progression.getUpgradeLevel("shield") >= 3) this.player.shieldCharges = 1;
    this.speed = this.baseSpeedAt(0); this.baseSpeed = this.speed;
    this.world.reset(this.seed);
    this.events.reset(this.seed);
    this.rivals.reset(this.seed);
    this.missions.resetRun();
    this.progression.markRegionDiscovered(0);
    this.fx({ type: "start" });
    this.setPhase("running");
    this.audio.setAmbience(REGIONS[0].ambience);
    auvyrrBridge.emit({ type: "RUN_STARTED", runId: this.runId, payload: { characterId: id, seed: this.seed } });
    // pre-simulate the generator so the first frame already has a track ahead
    this.world.update(0.0001, { distance: 0, speed: this.speed, player: this.player, flags: {}, features: { rail: this.player.abilities.railGrind } });
  }

  togglePause() {
    if (this.phase === "running") { this.setPhase("paused"); this.audio.setPaused(true); }
    else if (this.phase === "paused") { this.setPhase("running"); this.audio.setPaused(false); this.lastTime = typeof performance !== "undefined" ? performance.now() : Date.now(); }
  }

  quitToMenu() { if (this.phase === "paused" || this.phase === "running") { this.audio.setPaused(false); this.endRun(true); } }

  endRun(abandoned = false) {
    if (this.phase !== "running" && this.phase !== "paused") return;
    const missionReward = this.missions.claimCompletedRewards();
    this.missions.flush();
    const completed = [...this.missions.completedThisRun];
    const coinsTotal = Math.floor(this.coinsF) + missionReward;
    const outcome = this.progression.recordRun({
      score: this.score, distance: this.distance, time: this.timeElapsed, maxCombo: this.maxCombo, characterId: this.player.characterId,
      coins: coinsTotal, regionsReached: [...this.regionsReached].map((s) => s % REGIONS.length), missionsCompleted: completed.length,
    });
    this.lastSummary = {
      score: Math.floor(this.score), distance: Math.floor(this.distance), coins: Math.floor(this.coinsF), maxCombo: this.maxCombo, time: this.timeElapsed, characterId: this.player.characterId,
      missionsCompleted: completed, missionReward, outcome, rivalsDefeated: this.rivalsDefeated, regionsReached: [...new Set([...this.regionsReached].map((s) => REGIONS[s % REGIONS.length].name))], newHighScore: outcome.newHighScore,
    };
    this.audio.stopAmbience();
    auvyrrBridge.emit({ type: "RUN_ENDED", runId: this.runId, payload: { score: this.score, distance: this.distance, time: this.timeElapsed, abandoned } });
    this.setPhase(abandoned ? "menu" : "results");
  }

  // ───────────────────────── AUVYRR ─────────────────────────
  buildStateSnapshot(): GameStateSnapshot {
    const p = this.player;
    const rv = this.rivals.rival;
    const activeAbilities = [...p.activeAbilities.filter((a) => a !== "shield")];
    if (p.shieldCharges > 0) activeAbilities.push("shield");
    return {
      version: "2.0.0", timestamp: Date.now(), phase: this.phase,
      player: {
        position: { x: p.x, y: p.y, z: p.z }, velocity: { x: p.vx, y: p.vy, z: p.vz }, lane: p.lane, health: p.health, maxHealth: p.maxHealth,
        stamina: p.stamina, maxStamina: p.maxStamina, movementState: p.movementState, activeAbilities, combo: this.combo, flow: this.flow,
        equipmentIds: p.equipmentIds, modifiers: p.modifiers, characterId: p.characterId,
      },
      world: {
        regionId: this.world.currentRegionId, biomeId: this.world.currentBiomeId, chunkIndex: this.world.currentChunkIndex,
        routeOptions: this.world.getRouteOptions(), activeHazards: this.world.getHazardInfos(), activeEnemies: this.world.getEnemyInfos(),
        visibleRewards: this.world.getRewardInfos(), activeEvents: this.events.activeEventIds, environmentFlags: { ...this.world.environmentFlags, night: this.events.atmosphere.night, rain: this.events.atmosphere.rain },
      },
      run: { distance: this.distance, score: this.score, speed: this.speed, timeElapsed: this.timeElapsed, currentObjective: this.missions.getCurrent()?.title, riskLevel: this.riskLevel, recentFailures: this.recentFailures, recentSuccesses: this.recentSuccesses, seed: this.seed },
      boost: { meter: this.flow, active: this.boostTimer > 0, powerUps: { ...this.powerups, shield: p.shieldCharges } },
      events: { active: this.events.active.map((a) => ({ id: a.id, name: a.def.name, remaining: Math.max(0, a.remaining) })), atmosphere: { night: this.events.atmosphere.night, dusk: this.events.atmosphere.dusk, rain: this.events.atmosphere.rain, fogMul: this.events.atmosphere.fogMul, storm: this.events.atmosphere.storm } },
      rival: rv ? { id: rv.id, name: rv.name, personality: rv.personality, lane: rv.lane, relativeZ: rv.z, speed: rv.speed, score: rv.score, coins: rv.coins, mood: rv.mood, ahead: rv.z > 0 } : null,
      missions: this.missions.getActive().map((m) => ({ id: m.id, title: m.title, kind: m.kind, progress: Math.floor(m.progress), target: m.target, reward: m.reward, completed: m.completed })),
      progression: {
        ...this.progression.getState(), activeMissions: this.missions.getActive().map((m) => `${m.title}: ${Math.floor(m.progress)}/${m.target}`),
        unlockedRegions: this.progression.getState().discoveries, highScore: this.progression.getHighScore(), bestDistance: this.progression.getBestDistance(), coinBank: this.progression.getBank(),
      },
      behavior: { preferredRisk: this.riskLevel, averageReactionTime: 0.25, successfulAdvancedMoves: p.advancedMoveCount, frequentMistakes: [], successfulTechniques: [p.technique].filter((x) => x !== "none") },
    };
  }

  private registerAuvyrr() {
    auvyrrBridge.initialize(() => this.buildStateSnapshot());
    const needRun = () => (this.phase === "running" ? null : { success: false as const, reason: "No active run" });

    // Payload schemas are validated inside the bridge BEFORE a handler ever sees a command.
    auvyrrBridge.registerCommandSchema("requestDifficultyAdjustment", { delta: { type: "number", min: -0.3, max: 0.3, required: true } });
    auvyrrBridge.registerCommandSchema("requestEvent", { eventId: { type: "string", enum: EVENT_IDS, required: true } });
    auvyrrBridge.registerCommandSchema("requestChallenge", { challenge: { type: "string", enum: ["coin_rush", "train_rush", "speed_surge", "rival_chase", "road_closure"], required: true } });
    auvyrrBridge.registerCommandSchema("requestRivalBehavior", { personality: { type: "string", enum: Object.keys(RIVAL_PERSONALITIES), required: true }, spawn: { type: "boolean" } });
    auvyrrBridge.registerCommandSchema("requestMission", { template: { type: "string", enum: ["coins100", "coins250", "dist2k", "dist5k", "combo12", "combo30", "jumps40", "slides30", "adv10", "pu6", "near15", "events4", "regions3", "score10k"], required: true } });
    auvyrrBridge.registerCommandSchema("requestReward", { coins: { type: "number", min: 1, max: 250, required: true } });
    auvyrrBridge.registerCommandSchema("requestRoute", { routeId: { type: "string", enum: ["safe", "risky", "extreme"], required: true } });
    auvyrrBridge.registerCommandSchema("requestTrainingScenario", { scenario: { type: "string", enum: ["jump", "slide", "lanes"], required: true } });
    auvyrrBridge.registerCommandSchema("requestWorldMutation", { mutation: { type: "string", enum: ["fog", "rain", "sunset", "night"], required: true } });
    auvyrrBridge.registerCommandSchema("suggestAction", { action: { type: "string", enum: ["left", "right", "jump", "slide"], required: true } });
    auvyrrBridge.registerCommandSchema("requestCoachingHint", {});

    auvyrrBridge.registerCommandHandler("requestDifficultyAdjustment", async (cmd) => {
      const e = needRun(); if (e) return e;
      this.riskLevel = clamp(this.riskLevel + Number(cmd.payload.delta), 0.1, 0.95);
      return { success: true, result: { newRisk: this.riskLevel } };
    });
    const eventCmd = async (id: string) => {
      const e = needRun(); if (e) return e;
      const region = regionAtDistance(this.distance);
      if (!region.events.includes(id)) return { success: false as const, reason: `Event ${id} is not available in ${region.name}` };
      return this.events.forceEvent(id, this) ? { success: true as const, result: { event: id } } : { success: false as const, reason: "Event already active" };
    };
    auvyrrBridge.registerCommandHandler("requestEvent", (cmd) => eventCmd(String(cmd.payload.eventId)));
    auvyrrBridge.registerCommandHandler("requestChallenge", (cmd) => eventCmd(String(cmd.payload.challenge)));
    auvyrrBridge.registerCommandHandler("requestWorldMutation", (cmd) => eventCmd(String(cmd.payload.mutation)));
    auvyrrBridge.registerCommandHandler("requestRivalBehavior", async (cmd) => {
      const e = needRun(); if (e) return e;
      const p = String(cmd.payload.personality) as RivalPersonality;
      this.rivals.setPersonality(p);
      if (cmd.payload.spawn) this.rivals.forceSpawn(this, p);
      return { success: true, result: { personality: p } };
    });
    auvyrrBridge.registerCommandHandler("requestMission", async (cmd) => {
      const ok = this.missions.requestTemplate(String(cmd.payload.template));
      return ok ? { success: true, result: { active: this.missions.getActive().map((m) => m.title) } } : { success: false, reason: "No replaceable mission slot" };
    });
    auvyrrBridge.registerCommandHandler("requestReward", async (cmd) => {
      const e = needRun(); if (e) return e;
      if (this.rewardsGranted >= 3) return { success: false, reason: "Reward limit reached for this run" };
      this.rewardsGranted++;
      this.coinsF += Number(cmd.payload.coins); this.coins = Math.floor(this.coinsF);
      return { success: true, result: { coins: this.coins } };
    });
    auvyrrBridge.registerCommandHandler("requestRoute", async (cmd) => {
      const e = needRun(); if (e) return e;
      const id = String(cmd.payload.routeId);
      (this.world.environmentFlags as Record<string, boolean | number | string>).route = id;
      this.riskLevel = id === "safe" ? 0.2 : id === "risky" ? 0.55 : 0.8;
      auvyrrBridge.emit({ type: "ROUTE_CHOSEN", runId: this.runId, payload: { routeId: id } });
      return { success: true, result: { route: id, riskLevel: this.riskLevel } };
    });
    auvyrrBridge.registerCommandHandler("requestTrainingScenario", async (cmd) => {
      const e = needRun(); if (e) return e;
      const s = String(cmd.payload.scenario);
      // hand-authored, always-beatable drills placed ahead of the player
      const z0 = 70;
      if (s === "jump") for (const l of [-1, 0, 1]) this.world.injectObstacle({ type: "barricade", z: z0, lane: l });
      else if (s === "slide") for (const l of [-1, 0, 1]) this.world.injectObstacle({ type: "low_beam", z: z0, lane: l });
      else { this.world.injectObstacle({ type: "roadblock", z: z0, lane: -1 }); this.world.injectObstacle({ type: "roadblock", z: z0, lane: 1 }); }
      return { success: true, result: { scenario: s } };
    });
    auvyrrBridge.registerCommandHandler("suggestAction", async (cmd) => {
      // Suggestions are shown as a hint only: AUVYRR never gets direct control of the player.
      this.hint = `Hint: ${String(cmd.payload.action)}`; this.hintTimer = 2;
      return { success: true, result: { displayed: true } };
    });
    auvyrrBridge.registerCommandHandler("requestCoachingHint", async () => {
      const hints = [
        "Slide under beams, jump low barriers, swap lanes for anything tall.",
        "Collect coins in a row to raise your combo multiplier.",
        "Fill the boost bar, then tap Boost for a speed burst with invulnerability.",
        "Near misses build combo and flow quickly.",
      ];
      const hint = this.player.health <= 1 ? "One heart left: pick up a shield before taking risks." : hints[Math.floor(makeRng(String(this.timeElapsed | 0))() * hints.length)];
      this.hint = hint; this.hintTimer = 4;
      return { success: true, result: { hint } };
    });
  }

  // Debug / QA helpers
  debugJumpToRegion(index: number) {
    const d = index * 960 + 5;
    this.distance = d; this.world.jumpToDistance(d);
    this.regionsReached.add(index);
  }
}
