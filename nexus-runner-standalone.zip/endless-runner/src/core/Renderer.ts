/**
 * Renderer — compact Canvas2D fallback used only when WebGL is unavailable.
 * Draws a readable lane view of the live simulation (road, obstacles, coins, player, rival).
 */
import type { Game } from "./Game.js";
import { LANE_WIDTH, REGIONS } from "../data/GameData.js";

const SKY: Record<string, [string, string]> = {
  city_rooftops: ["#8fc3ee", "#dbeaf5"], highway: ["#7fb0dc", "#cfe2f1"], subway: ["#1b2735", "#35465a"], industrial: ["#a9a39a", "#d9c7a8"], forest: ["#8cc7a0", "#d6ecd0"],
};

export class Renderer {
  constructor(private game: Game) {}

  draw() {
    const g = this.game; const ctx = g.ctx; if (!ctx) return;
    const w = g.width, h = g.height;
    const [top, bot] = SKY[g.world.currentRegionId] ?? SKY.city_rooftops;
    const grad = ctx.createLinearGradient(0, 0, 0, h * 0.55); grad.addColorStop(0, top); grad.addColorStop(1, bot);
    ctx.fillStyle = grad; ctx.fillRect(0, 0, w, h);
    const horizon = h * 0.38;
    // road
    ctx.fillStyle = "#3a3f46"; ctx.beginPath();
    ctx.moveTo(w * 0.42, horizon); ctx.lineTo(w * 0.58, horizon); ctx.lineTo(w * 0.98, h); ctx.lineTo(w * 0.02, h); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,.55)"; ctx.lineWidth = 2;
    for (const f of [-1.5, -0.5, 0.5, 1.5]) { ctx.beginPath(); const [x0, y0] = this.proj(f * LANE_WIDTH, 120); const [x1, y1] = this.proj(f * LANE_WIDTH, -2); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
    const items: Array<{ z: number; draw: () => void }> = [];
    for (const o of g.world.getObstacles()) items.push({ z: o.z, draw: () => this.box(ctx, o.x, o.y, o.z, o.width, o.height, o.kind === "block" ? "#c0563b" : o.kind === "slide" ? "#e0a437" : "#d98a3d") });
    for (const c of g.world.getCollectibles()) items.push({ z: c.z, draw: () => this.dot(ctx, c.x, c.y, c.z, c.type === "coin" ? "#ffcf3a" : "#4fc3ff") });
    const rv = g.rivals.rival; if (rv && rv.z > -3) items.push({ z: rv.z, draw: () => this.box(ctx, rv.x, rv.y, rv.z, 0.8, 1.7, rv.color) });
    items.push({ z: 0, draw: () => this.box(ctx, g.player.x, g.player.y, 0.5, 0.8, g.player.height, "#f2f2f2") });
    items.sort((a, b) => b.z - a.z); for (const i of items) if (i.z > -3 && i.z < 120) i.draw();
    ctx.fillStyle = "#fff"; ctx.font = "12px system-ui"; ctx.fillText("Canvas2D fallback — WebGL unavailable · " + (REGIONS.find((r) => r.id === g.world.currentRegionId)?.name ?? ""), 12, h - 12);
  }
  private proj(x: number, z: number): [number, number] {
    const g = this.game; const w = g.width, h = g.height; const horizon = h * 0.38;
    const k = 1 / (1 + Math.max(-2, z) * 0.045);
    return [w / 2 + x * k * w * 0.075, horizon + (h - horizon) * 0.95 * k];
  }
  private box(ctx: CanvasRenderingContext2D, x: number, y: number, z: number, wd: number, ht: number, color: string) {
    const [px, py] = this.proj(x, z); const k = 1 / (1 + Math.max(-2, z) * 0.045);
    const pw = wd * k * this.game.width * 0.075, ph = ht * k * this.game.height * 0.11;
    ctx.fillStyle = color; ctx.fillRect(px - pw / 2, py - ph - y * k * 30, pw, ph);
  }
  private dot(ctx: CanvasRenderingContext2D, x: number, y: number, z: number, color: string) {
    const [px, py] = this.proj(x, z); const k = 1 / (1 + Math.max(-2, z) * 0.045);
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(px, py - y * k * 30, 7 * k + 1, 0, 7); ctx.fill();
  }
}
