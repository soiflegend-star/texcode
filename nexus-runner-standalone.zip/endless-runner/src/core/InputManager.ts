/**
 * InputManager — keyboard + low-latency touch swipes + programmatic injection (UI buttons / tests).
 * Safe to construct in a headless (no DOM) environment.
 */
export type InputAction = "left" | "right" | "jump" | "slide" | "dash" | "grapple" | "pause" | "boost" | "ability";

export class InputManager {
  leftPressed = false;
  rightPressed = false;
  jumpPressed = false;
  slidePressed = false;
  dashPressed = false;
  grapplePressed = false;
  pausePressed = false;
  boostPressed = false;

  private touchId: number | null = null;
  private startX = 0; private startY = 0;
  private fired = false;
  swipeThreshold = 28;
  enabled = true;

  constructor(canvas?: HTMLElement | null) {
    if (typeof window === "undefined") return;
    window.addEventListener("keydown", (e: KeyboardEvent) => {
      if (!this.enabled || e.repeat) return;
      switch (e.code) {
        case "ArrowLeft": case "KeyA": this.inject("left"); break;
        case "ArrowRight": case "KeyD": this.inject("right"); break;
        case "ArrowUp": case "KeyW": case "Space": this.inject("jump"); break;
        case "ArrowDown": case "KeyS": this.inject("slide"); break;
        case "ShiftLeft": case "ShiftRight": this.inject("boost"); break;
        case "KeyE": case "KeyQ": this.inject("grapple"); break;
        case "Escape": case "KeyP": this.inject("pause"); break;
      }
    });
    if (!canvas) return;
    canvas.addEventListener("touchstart", (e: TouchEvent) => {
      if (this.touchId !== null) return;
      const t = e.changedTouches[0];
      this.touchId = t.identifier; this.startX = t.clientX; this.startY = t.clientY; this.fired = false;
      e.preventDefault();
    }, { passive: false });
    canvas.addEventListener("touchmove", (e: TouchEvent) => {
      for (const t of Array.from(e.changedTouches)) {
        if (t.identifier !== this.touchId || this.fired) continue;
        const dx = t.clientX - this.startX, dy = t.clientY - this.startY;
        if (Math.max(Math.abs(dx), Math.abs(dy)) < this.swipeThreshold) continue;
        this.fired = true; // one action per swipe, fired as soon as the threshold is crossed (low latency)
        if (Math.abs(dx) > Math.abs(dy)) this.inject(dx < 0 ? "left" : "right");
        else this.inject(dy < 0 ? "jump" : "slide");
      }
      e.preventDefault();
    }, { passive: false });
    const end = (e: TouchEvent) => {
      for (const t of Array.from(e.changedTouches)) {
        if (t.identifier !== this.touchId) continue;
        if (!this.fired && Math.abs(t.clientX - this.startX) < 10 && Math.abs(t.clientY - this.startY) < 10) { /* tap: reserved */ }
        this.touchId = null;
      }
      e.preventDefault();
    };
    canvas.addEventListener("touchend", end, { passive: false });
    canvas.addEventListener("touchcancel", end, { passive: false });
  }

  /** Programmatic input (on-screen buttons, tests, bots). */
  inject(a: InputAction) {
    switch (a) {
      case "left": this.leftPressed = true; this.rightPressed = false; break;
      case "right": this.rightPressed = true; this.leftPressed = false; break;
      case "jump": this.jumpPressed = true; break;
      case "slide": this.slidePressed = true; break;
      case "dash": this.dashPressed = true; break;
      case "grapple": case "ability": this.grapplePressed = true; break;
      case "pause": this.pausePressed = true; break;
      case "boost": this.boostPressed = true; break;
    }
  }
  clearAll() { this.leftPressed = this.rightPressed = this.jumpPressed = this.slidePressed = this.dashPressed = this.grapplePressed = this.pausePressed = this.boostPressed = false; }

  consumeLeft() { this.leftPressed = false; }
  consumeRight() { this.rightPressed = false; }
  consumeJump() { this.jumpPressed = false; }
  consumeSlide() { this.slidePressed = false; }
  consumeDash() { this.dashPressed = false; }
  consumeGrapple() { this.grapplePressed = false; }
  consumePause() { this.pausePressed = false; }
  consumeBoost() { this.boostPressed = false; }
}
