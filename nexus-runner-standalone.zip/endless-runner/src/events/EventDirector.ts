/**
 * EventDirector — deterministic (seeded, game-time based) world events.
 * Events modify gameplay (speed, spawn flags), lighting/weather (atmosphere) and audio cues.
 * Uses game time, never setTimeout, so pausing / slow-motion are respected.
 */
import type { Game } from "../core/Game.js";
import { auvyrrBridge } from "../auvyrr/AuvyrrBridge.js";
import { EVENTS, EVENT_IDS, EventDef, EventGroup, regionAtDistance } from "../data/GameData.js";
import { makeRng, Rng, clamp } from "../util/rng.js";
import type { EventFlags } from "../world/WorldGenerator.js";

export interface ActiveEvent { id: string; def: EventDef; remaining: number; elapsed: number; forced: boolean }

export interface Atmosphere {
  night: number;      // 0..1 → night
  dusk: number;       // 0..1 → golden hour
  fogMul: number;     // multiplier on fog distance (<1 = denser)
  rain: number;       // 0..1
  wet: number;        // 0..1 surface wetness
  storm: number;      // 0..1 darkness/overcast from storm
  lightning: number;  // current flash intensity 0..1
  speedFx: number;    // 0..1 extra speed-effects
}

export const NEUTRAL_ATMOSPHERE: Atmosphere = { night: 0, dusk: 0, fogMul: 1, rain: 0, wet: 0, storm: 0, lightning: 0, speedFx: 0 };

const FADE = 3; // seconds of fade in/out for atmospheric events

export class EventDirector {
  active: ActiveEvent[] = [];
  private cooldown = 0;
  private recent: string[] = [];
  private rng: Rng = makeRng("events");
  private lightningTimer = 3;
  private lightningFlash = 0;
  private wet = 0;
  /** log for tests / AUVYRR */
  history: Array<{ id: string; atDistance: number; time: number }> = [];
  onEventStart: ((e: ActiveEvent) => void) | null = null;
  onEventEnd: ((e: ActiveEvent) => void) | null = null;
  onLightning: (() => void) | null = null;
  atmosphere: Atmosphere = { ...NEUTRAL_ATMOSPHERE };

  get activeEventIds(): string[] { return this.active.map((a) => a.id); }
  get primaryEventName(): string | null { const a = this.active.find((e) => e.def.group === "hazard") ?? this.active[0]; return a ? a.def.name : null; }
  get primary(): ActiveEvent | null { return this.active.find((e) => e.def.group === "hazard") ?? this.active.find((e) => e.def.group === "boon") ?? this.active[0] ?? null; }

  reset(seed = "events") {
    this.active = []; this.cooldown = 14; this.recent = [];
    this.rng = makeRng(seed + ":events");
    this.history = []; this.lightningTimer = 3; this.lightningFlash = 0; this.wet = 0;
    this.atmosphere = { ...NEUTRAL_ATMOSPHERE };
  }

  has(id: string) { return this.active.some((a) => a.id === id); }
  private groupActive(g: EventGroup) { return this.active.some((a) => a.def.group === g); }

  update(dt: number, game: Game) {
    // advance & expire
    for (const a of this.active) { a.remaining -= dt; a.elapsed += dt; }
    for (const a of this.active.filter((x) => x.remaining <= 0)) this.end(a, game);

    // spawn a new one
    this.cooldown -= dt;
    if (this.cooldown <= 0) {
      const id = this.chooseEvent(game);
      if (id) this.trigger(id, game, false);
      this.cooldown = 9 + this.rng() * 9 - game.riskLevel * 3;
    }
    this.updateAtmosphere(dt, game);
  }

  private chooseEvent(game: Game): string | null {
    const region = regionAtDistance(game.distance);
    const cands = region.events.map((id) => EVENTS[id]).filter((d) => d && game.distance >= d.minDistance && !this.has(d.id) && !this.groupActive(d.group) && !this.recent.includes(d.id));
    if (!cands.length) return null;
    // at most one hazard event at a time and not right on top of a region transition
    const into = game.distance % 960;
    const safe = cands.filter((d) => !(d.group === "hazard" && into > 880));
    const pool = safe.length ? safe : cands.filter((d) => d.group !== "hazard");
    if (!pool.length) return null;
    let sum = 0; for (const d of pool) sum += d.weight;
    let r = this.rng() * sum;
    for (const d of pool) { r -= d.weight; if (r <= 0) return d.id; }
    return pool[0].id;
  }

  /** Called on region change: events that don't belong to the new region are wound down. */
  onRegionChanged(game: Game) {
    const region = regionAtDistance(game.distance);
    for (const a of this.active) if (!region.events.includes(a.id)) a.remaining = Math.min(a.remaining, 2.5);
  }

  trigger(eventId: string, game: Game, forced: boolean): boolean {
    const def = EVENTS[eventId];
    if (!def || this.has(eventId)) return false;
    // enforce one-per-group so combinations stay readable; forced events replace the group occupant
    for (const a of this.active.filter((x) => x.def.group === def.group)) { if (!forced) return false; this.end(a, game); }
    const ev: ActiveEvent = { id: eventId, def, remaining: def.duration, elapsed: 0, forced };
    this.active.push(ev);
    this.recent.push(eventId); if (this.recent.length > 5) this.recent.shift();
    this.history.push({ id: eventId, atDistance: game.distance, time: game.timeElapsed });
    this.onEventStart?.(ev);
    auvyrrBridge.emit({ type: "CUSTOM", runId: game.runId, payload: { name: "EVENT_TRIGGERED", event: eventId, forced } });
    if (eventId === "rival_chase") game.rivals.forceSpawn(game, "aggressive");
    return true;
  }

  forceEvent(eventId: string, game?: Game): boolean {
    if (!EVENTS[eventId]) return false;
    if (!game) return false;
    return this.trigger(eventId, game, true);
  }

  private end(a: ActiveEvent, game: Game) {
    this.active = this.active.filter((x) => x !== a);
    this.onEventEnd?.(a);
    auvyrrBridge.emit({ type: "CUSTOM", runId: game.runId, payload: { name: "EVENT_ENDED", event: a.id } });
  }

  /** Fade factor 0..1 for an active event (smooth in and out). */
  private fade(a: ActiveEvent) { return clamp(Math.min(a.elapsed / FADE, a.remaining / FADE), 0, 1); }
  private fadeOf(id: string) { const a = this.active.find((x) => x.id === id); return a ? this.fade(a) : 0; }

  getSpeedMultiplier(): number {
    let m = 1;
    const surge = this.fadeOf("speed_surge"); if (surge > 0) m *= 1 + 0.2 * Math.min(1, surge * 2);
    const chase = this.fadeOf("rival_chase"); if (chase > 0) m *= 1 + 0.06 * chase;
    return m;
  }

  getWorldFlags(): EventFlags {
    return {
      coinRush: this.has("coin_rush"), trafficBias: this.has("heavy_traffic"), trainBias: this.has("train_rush"),
      closure: this.has("road_closure"), debris: this.has("construction_collapse"), drones: this.has("drone_pursuit"),
    };
  }

  private updateAtmosphere(dt: number, game: Game) {
    const a = this.atmosphere;
    const night = this.fadeOf("night"), dusk = this.fadeOf("sunset");
    const fog = this.fadeOf("fog"), rain = Math.max(this.fadeOf("rain"), this.fadeOf("lightning_storm"));
    const storm = this.fadeOf("lightning_storm");
    a.night = night; a.dusk = dusk * (1 - night);
    a.fogMul = 1 - 0.62 * fog - 0.25 * storm;
    a.rain = rain;
    this.wet += (Math.max(rain, 0) - this.wet) * Math.min(1, dt * (rain > this.wet ? 0.4 : 0.08));
    a.wet = this.wet;
    a.storm = storm;
    a.speedFx = Math.max(this.fadeOf("speed_surge"), this.fadeOf("rival_chase") * 0.4);
    // lightning
    if (this.lightningFlash > 0) this.lightningFlash = Math.max(0, this.lightningFlash - dt * 3.2);
    if (storm > 0.5) {
      this.lightningTimer -= dt;
      if (this.lightningTimer <= 0) { this.lightningFlash = 1; this.lightningTimer = 2.5 + this.rng() * 4.5; this.onLightning?.(); }
    }
    a.lightning = this.lightningFlash;
  }
}
