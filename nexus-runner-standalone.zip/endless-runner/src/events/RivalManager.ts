/**
 * RivalManager — a simulated competing runner (not a decoration).
 * It runs its own lane/jump/slide logic against the real obstacle stream, makes
 * personality-driven mistakes, collects coins, boosts, overtakes / falls behind.
 * Rival z is measured in the player's frame: >0 ahead of the player, <0 behind.
 */
import type { Game } from "../core/Game.js";
import { auvyrrBridge } from "../auvyrr/AuvyrrBridge.js";
import { LANE_WIDTH, RIVAL_PERSONALITIES, RivalPersonality } from "../data/GameData.js";
import { makeRng, Rng, clamp, damp } from "../util/rng.js";

export type RivalAnim = "run" | "sprint" | "jump" | "slide" | "stumble" | "boost" | "victory";

export interface RivalState {
  id: string; name: string; personality: RivalPersonality; color: string;
  lane: number; x: number; y: number; vy: number; z: number;
  speed: number;            // absolute forward speed (m/s)
  score: number; coins: number;
  active: boolean; defeated: boolean;
  anim: RivalAnim; animTimer: number;
  boostTimer: number; stumbleTimer: number; airborne: boolean; slideTimer: number;
  overtakes: number; lastSide: "ahead" | "behind";
  mood: "chasing" | "leading" | "stumbling" | "boosting";
}

export class RivalManager {
  rival: RivalState | null = null;
  private cooldown = 0;
  private rng: Rng = makeRng("rival");
  private decisionTimer = 0;
  private targetLane = 0;
  private lastTargetRow = -1;
  private mistakeRow = -999;
  totalSpawned = 0; totalDefeated = 0; totalOvertakes = 0;
  forcedPersonality: RivalPersonality | null = null;

  reset(seed = "rival") { this.rival = null; this.cooldown = 22; this.rng = makeRng(seed + ":rival"); this.totalSpawned = this.totalDefeated = this.totalOvertakes = 0; this.forcedPersonality = null; }

  forceSpawn(game: Game, personality?: RivalPersonality) {
    if (this.rival) { if (personality) this.applyPersonality(this.rival, personality); return; }
    this.spawn(game, personality ?? this.forcedPersonality ?? undefined);
  }

  setPersonality(p: RivalPersonality) { this.forcedPersonality = p; if (this.rival) this.applyPersonality(this.rival, p); }
  private applyPersonality(r: RivalState, p: RivalPersonality) { r.personality = p; r.name = RIVAL_PERSONALITIES[p].name; r.color = RIVAL_PERSONALITIES[p].color; }

  update(dt: number, game: Game) {
    this.cooldown -= dt;
    if (!this.rival && this.cooldown <= 0 && game.distance > 300) this.spawn(game);
    const r = this.rival; if (!r) return;
    const P = RIVAL_PERSONALITIES[r.personality];

    // ── Speed: personality-scaled, reacts to events and boosts ──
    let target = game.baseSpeedAt() * P.speed;
    if (game.events.has("rival_chase")) target *= 1.08;
    if (game.events.has("fog") || game.events.has("rain")) target *= 0.96;
    if (game.events.has("coin_rush")) target *= 0.94; // gets distracted collecting
    if (game.events.has("speed_surge")) target *= 1.18;
    if (r.stumbleTimer > 0) { r.stumbleTimer -= dt; target *= 0.35; r.anim = "stumble"; r.mood = "stumbling"; }
    else if (r.boostTimer > 0) { r.boostTimer -= dt; target *= 1.4; r.anim = "boost"; r.mood = "boosting"; }
    else {
      r.mood = r.z > 0 ? "leading" : "chasing";
      // rubber-banding: keep the contest alive without being unfair
      const gap = r.z;
      if (gap > 55) target *= 0.9; else if (gap < -10) target *= 1.08;
      // occasionally burn a boost
      if (this.rng() < dt * 0.12 * P.boostChance) r.boostTimer = 1.2 + this.rng();
    }
    r.speed += (target - r.speed) * damp(2.2, dt);
    r.z += (r.speed - game.speed) * dt;
    r.score += dt * r.speed * 8;

    // ── Decision making (obstacle avoidance with reaction delay and mistakes) ──
    this.decisionTimer -= dt;
    if (this.decisionTimer <= 0) { this.decisionTimer = 0.12; this.decide(game, r, P); }

    // lane motion
    const tx = this.targetLane * LANE_WIDTH;
    r.x += (tx - r.x) * damp(10, dt);
    r.lane = Math.round(r.x / LANE_WIDTH);

    // vertical
    if (r.airborne) {
      r.vy -= 32 * dt; r.y += r.vy * dt;
      if (r.y <= 0) { r.y = 0; r.vy = 0; r.airborne = false; }
      if (r.stumbleTimer <= 0 && r.boostTimer <= 0) r.anim = "jump";
    }
    if (r.slideTimer > 0) { r.slideTimer -= dt; if (r.stumbleTimer <= 0 && r.boostTimer <= 0) r.anim = "slide"; }
    if (!r.airborne && r.slideTimer <= 0 && r.stumbleTimer <= 0 && r.boostTimer <= 0) r.anim = r.speed > game.speed * 1.05 ? "sprint" : "run";

    // coin collection (rival really takes coins from the world)
    this.collect(game, r, P);

    // overtake bookkeeping
    const side: "ahead" | "behind" = r.z > 0 ? "ahead" : "behind";
    if (side !== r.lastSide) {
      r.lastSide = side; r.overtakes++; this.totalOvertakes++;
      game.onRivalOvertake(side === "behind");
      auvyrrBridge.emit({ type: "CUSTOM", runId: game.runId, payload: { name: side === "behind" ? "PLAYER_OVERTOOK_RIVAL" : "RIVAL_OVERTOOK_PLAYER", rivalId: r.id } });
    }

    // Defeated when the player has been clearly ahead for a while; leaves otherwise when far behind.
    if (r.z < -24) {
      if (game.score > r.score * 1.0) {
        r.defeated = true;
        game.onRivalDefeated(r);
        auvyrrBridge.emit({ type: "RIVAL_DEFEATED", runId: game.runId, payload: { rivalId: r.id, personality: r.personality } });
        this.totalDefeated++;
      }
      this.rival = null; this.cooldown = 26 + this.rng() * 10;
    } else if (r.z > 140) {
      this.rival = null; this.cooldown = 18; // got away
    }
  }

  private decide(game: Game, r: RivalState, P: { skill: number; reaction: number; coinGreed: number }) {
    // Look ahead at obstacles in front of the rival (in the shared frame)
    const look = r.z + 4 + Math.max(10, r.speed * P.reaction);
    const obs = game.world.getObstacles().filter((o) => o.z > r.z - 1 && o.z - o.depth / 2 < look);
    const rowsAhead = new Map<number, typeof obs>();
    for (const o of obs) { if (!rowsAhead.has(o.rowId)) rowsAhead.set(o.rowId, []); rowsAhead.get(o.rowId)!.push(o); }
    const next = [...rowsAhead.entries()].sort((a, b) => Math.min(...a[1].map((o) => o.z)) - Math.min(...b[1].map((o) => o.z)))[0];
    if (!next || r.stumbleTimer > 0) return;
    const [rowId, row] = next;
    const nearestZ = Math.min(...row.map((o) => o.z - o.depth / 2));
    const dist = nearestZ - r.z;
    if (rowId !== this.lastTargetRow) {
      this.lastTargetRow = rowId;
      // Plan once per row; mistakes are decided here, deterministically from the rng
      const blocked = new Set(row.filter((o) => o.kind === "block").map((o) => o.lane));
      const free = [-1, 0, 1].filter((l) => !blocked.has(l)).sort((a, b) => Math.abs(a - r.lane) - Math.abs(b - r.lane));
      const mistake = this.rng() > P.skill;
      if (mistake) { this.mistakeRow = rowId; }
      else if (blocked.has(r.lane) && free.length) this.targetLane = free[0];
    }
    if (rowId === this.mistakeRow) {
      // ignores the obstacle: will hit it
      if (dist < 1.2 && !r.stumbleTimer && !r.airborne) this.stumble(game, r);
      return;
    }
    const o = row.find((x) => Math.abs(x.x - r.x) < x.width / 2 + 0.3) ?? null;
    if (o && !r.airborne && r.slideTimer <= 0) {
      const react = 3.2 + r.speed * 0.17;
      if (dist < react) {
        if (o.kind === "jump") { r.airborne = true; r.vy = 12.2; this.fx(game, r, "jump"); }
        else if (o.kind === "slide") { r.slideTimer = 0.6; this.fx(game, r, "slide"); }
        else if (o.kind === "block") {
          // too late to dodge → stumble
          const free = [-1, 0, 1].filter((l) => !row.some((q) => q.kind === "block" && q.lane === l));
          if (free.length) this.targetLane = free.sort((a, b) => Math.abs(a - r.lane) - Math.abs(b - r.lane))[0];
          else this.stumble(game, r);
        }
      }
    }
    // coin greed: shift into a lane with coins when nothing blocks
    if (!o && this.rng() < P.coinGreed * 0.05) {
      const coins = game.world.getCollectibles().filter((c) => c.type === "coin" && c.z > r.z + 3 && c.z < r.z + 18);
      if (coins.length) { const c = coins[0]; const safe = !obs.some((q) => q.kind === "block" && q.lane === c.lane); if (safe) this.targetLane = clamp(c.lane, -1, 1); }
    }
  }

  private stumble(game: Game, r: RivalState) {
    r.stumbleTimer = 1.3; r.boostTimer = 0;
    this.fx(game, r, "stumble");
  }
  private fx(game: Game, r: RivalState, what: string) { game.onRivalFx?.(r, what); }

  private collect(game: Game, r: RivalState, P: { coinGreed: number }) {
    for (const c of game.world.getCollectibles()) {
      if (c.type !== "coin") continue;
      if (Math.abs(c.z - r.z) < 1.0 && Math.abs(c.x - r.x) < 1.2 && c.y < r.y + 2.2) {
        game.world.removeCollectible(c); r.coins++; r.score += 12;
        if (r.coins % 6 === 0) r.boostTimer = Math.max(r.boostTimer, 0.0);
      }
    }
  }

  private spawn(game: Game, personality?: RivalPersonality) {
    const personalities: RivalPersonality[] = ["aggressive", "cautious", "speed", "trick"];
    const p = personality ?? personalities[(this.totalSpawned + Math.floor(this.rng() * 4)) % 4];
    const P = RIVAL_PERSONALITIES[p];
    this.totalSpawned++;
    this.targetLane = Math.floor(this.rng() * 3) - 1;
    this.rival = {
      id: `rival_${this.totalSpawned}`, name: P.name, personality: p, color: P.color,
      lane: this.targetLane, x: this.targetLane * LANE_WIDTH, y: 0, vy: 0, z: 46,
      speed: game.speed * P.speed, score: game.score + 1200 + this.rng() * 800, coins: 0,
      active: true, defeated: false, anim: "run", animTimer: 0, boostTimer: 0, stumbleTimer: 0, airborne: false, slideTimer: 0,
      overtakes: 0, lastSide: "ahead", mood: "chasing",
    };
    this.lastTargetRow = -1; this.mistakeRow = -999;
    auvyrrBridge.emit({ type: "RIVAL_APPEARED", runId: game.runId, payload: { rivalId: this.rival.id, name: this.rival.name, personality: p } });
  }
}

