/**
 * Player — responsive lane-based movement with character-specific stats and
 * progressively unlocked advanced techniques (air dash, wall run, rail grind, grapple).
 * Pure logic: no DOM / WebGL, runs headless.
 */
import { MovementStateId } from "../auvyrr/types.js";
import { InputManager } from "../core/InputManager.js";
import { auvyrrBridge } from "../auvyrr/AuvyrrBridge.js";
import { CHARACTERS, CharacterDef, CharacterId, LANE_WIDTH } from "../data/GameData.js";
import { damp } from "../util/rng.js";

export interface AbilityUnlocks { airDash: boolean; wallRun: boolean; railGrind: boolean; grapple: boolean }
export const NO_ABILITIES: AbilityUnlocks = { airDash: false, wallRun: false, railGrind: false, grapple: false };

export class Player {
  // Position: x lateral, y height, z forward (player stays at z=0, the world scrolls)
  x = 0; y = 0; z = 0;
  vx = 0; vy = 0; vz = 0;

  lane = 0;          // current lane (-1,0,1)
  targetLane = 0;
  laneWidth = LANE_WIDTH;
  laneDir = 0;       // -1/0/1: direction of ongoing lane change (for lean/animation)
  laneVelX = 0;

  gravity = 32;
  jumpForce = 12.4;
  groundY = 0;
  isGrounded = true;

  movementState: MovementStateId = "running";
  health = 3; maxHealth = 3;
  shieldCharges = 0;
  stamina = 100; maxStamina = 100;
  characterId: CharacterId = "runner";
  def: CharacterDef = CHARACTERS.runner;
  abilities: AbilityUnlocks = { ...NO_ABILITIES };
  activeAbilities: string[] = [];
  equipmentIds: string[] = [];
  modifiers: Record<string, number> = {};
  advancedMoveCount = 0;
  jumpCount = 0; slideCount = 0;
  airJumpsUsed = 0;

  // Timers
  slideTimer = 0; invulnTimer = 0; stunTimer = 0; landTimer = 0; hitFlash = 0;
  wallRunTimer = 0; railTimer = 0; dashTimer = 0; dashCooldown = 0; grappleTimer = 0; grappleCooldown = 0;
  smashCooldown = 0; evadeTimer = 0;
  wallSide = 0;
  technique = "none";
  jumpBuffer = 0;     // seconds of buffered jump input
  slideBuffer = 0;

  // One-frame event flags consumed by Game (audio / particles)
  ev = { jumped: false, doubleJumped: false, landed: false, slid: false, dashed: false, laneChanged: 0, wallRun: false, grapple: false, hit: false };

  // Collision dimensions
  width = 0.7;
  height = 1.7;
  heightStanding = 1.7;
  heightSliding = 0.8;

  reset(characterId: string, abilities: AbilityUnlocks = NO_ABILITIES, maxStaminaBonus = 0) {
    const def = (CHARACTERS as Record<string, CharacterDef>)[characterId] ?? CHARACTERS.runner;
    this.def = def;
    this.characterId = def.id;
    this.abilities = { ...abilities };
    this.x = 0; this.y = 0; this.z = 0; this.vx = 0; this.vy = 0; this.vz = 0;
    this.lane = 0; this.targetLane = 0; this.laneDir = 0; this.laneVelX = 0;
    this.movementState = "running";
    this.maxHealth = def.sim.maxHealth;
    this.health = this.maxHealth;
    this.shieldCharges = 0;
    this.maxStamina = 100 + maxStaminaBonus;
    this.stamina = this.maxStamina;
    this.isGrounded = true;
    this.slideTimer = this.invulnTimer = this.stunTimer = this.landTimer = this.hitFlash = 0;
    this.wallRunTimer = this.railTimer = this.dashTimer = this.dashCooldown = this.grappleTimer = this.grappleCooldown = 0;
    this.smashCooldown = this.evadeTimer = 0;
    this.advancedMoveCount = this.jumpCount = this.slideCount = this.airJumpsUsed = 0;
    this.heightStanding = def.sim.standHeight;
    this.heightSliding = def.sim.slideHeight;
    this.height = this.heightStanding;
    this.gravity = 32 * def.sim.gravityMult;
    this.jumpForce = def.sim.jumpForce;
    this.technique = "none";
    this.jumpBuffer = this.slideBuffer = 0;
    this.wallSide = 0;
    this.modifiers = {
      speedMult: def.sim.speedMult, control: def.sim.laneSharpness, airControl: def.sim.airControl,
      obstacleBreak: def.sim.smashLow ? 1 : 0, doubleJump: def.sim.doubleJump ? 1 : 0,
    };
    this.activeAbilities = ["jump", "slide", ...(def.sim.doubleJump ? ["doubleJump"] : []),
      ...(abilities.airDash ? ["airDash"] : []), ...(abilities.wallRun ? ["wallRun"] : []),
      ...(abilities.railGrind ? ["railGrind"] : []), ...(abilities.grapple ? ["grapple"] : [])];
  }

  clearEvents() {
    const e = this.ev;
    e.jumped = e.doubleJumped = e.landed = e.slid = e.dashed = e.wallRun = e.grapple = e.hit = false;
    e.laneChanged = 0;
  }

  get alive() { return this.movementState !== "dead"; }
  get canAct() { return this.movementState !== "dead" && this.stunTimer <= 0; }

  handleInput(input: InputManager, dt: number) {
    if (!this.alive) return;
    if (input.jumpPressed) { this.jumpBuffer = 0.14; input.consumeJump(); }
    if (input.slidePressed) { this.slideBuffer = 0.14; input.consumeSlide(); }
    this.jumpBuffer = Math.max(0, this.jumpBuffer - dt);
    this.slideBuffer = Math.max(0, this.slideBuffer - dt);

    if (this.stunTimer > 0) { input.consumeLeft(); input.consumeRight(); return; }

    // Lane change (disabled while wall-running: locked to the wall lane)
    if (input.leftPressed) { this.tryLane(-1); input.consumeLeft(); }
    if (input.rightPressed) { this.tryLane(1); input.consumeRight(); }

    if (this.jumpBuffer > 0) {
      if (this.isGrounded || this.railTimer > 0) { this.jump(); this.jumpBuffer = 0; }
      else if (this.wallRunTimer > 0) { this.endWallRun(); this.jump(); this.jumpBuffer = 0; }
      else if (this.def.sim.doubleJump && this.airJumpsUsed < 1 && this.dashTimer <= 0) { this.doubleJump(); this.jumpBuffer = 0; }
      else if (this.tryWallRun()) { this.jumpBuffer = 0; }
      else if (this.abilities.airDash && this.dashCooldown <= 0 && this.stamina >= this.def.sim.airDashCost) { this.airDash(); this.jumpBuffer = 0; }
    }

    if (this.slideBuffer > 0) {
      if (this.isGrounded && this.movementState !== "sliding") { this.startSlide(); this.slideBuffer = 0; }
      else if (!this.isGrounded && this.wallRunTimer <= 0) { this.vy = Math.min(this.vy, -17); this.slideBuffer = 0; } // fast-fall into a slide
      else if (this.railTimer > 0) { this.endRail(); this.startSlide(); this.slideBuffer = 0; }
    }
  }

  private tryLane(dir: number) {
    if (this.wallRunTimer > 0) return;
    const t = this.targetLane + dir;
    if (t < -1 || t > 1) return;
    this.targetLane = t;
    this.laneDir = dir;
    this.ev.laneChanged = dir;
  }

  jump() {
    this.vy = this.jumpForce;
    this.jumpCount++;
    this.isGrounded = false;
    this.airJumpsUsed = 0;
    this.movementState = "jumping";
    this.height = this.heightStanding;
    this.slideTimer = 0;
    this.ev.jumped = true;
    auvyrrBridge.emit({ type: "PLAYER_JUMPED", runId: "", payload: { fromGround: true } });
  }

  doubleJump() {
    this.vy = this.jumpForce * 0.92;
    this.airJumpsUsed++;
    this.jumpCount++;
    this.movementState = "jumping";
    this.ev.doubleJumped = true;
    this.advancedMoveCount++;
    auvyrrBridge.emit({ type: "ABILITY_USED", runId: "", payload: { ability: "doubleJump" } });
  }

  airDash() {
    this.movementState = "airDashing";
    this.technique = "airDash";
    this.dashTimer = 0.22;
    this.dashCooldown = 0.9;
    this.stamina -= this.def.sim.airDashCost;
    this.vy = Math.max(this.vy, 3);
    this.advancedMoveCount++;
    this.invulnTimer = Math.max(this.invulnTimer, 0.22);
    this.ev.dashed = true;
    auvyrrBridge.emit({ type: "ABILITY_USED", runId: "", payload: { ability: "airDash" } });
  }

  tryWallRun(): boolean {
    if (!this.abilities.wallRun || this.isGrounded || this.wallRunTimer > 0 || this.stamina < 10) return false;
    if (Math.abs(this.targetLane) !== 1) return false;
    this.movementState = "wallRunning";
    this.technique = "wallRun";
    this.wallRunTimer = 0.9;
    this.wallSide = this.targetLane;
    this.stamina -= 10;
    this.vy = 0;
    this.advancedMoveCount++;
    this.ev.wallRun = true;
    auvyrrBridge.emit({ type: "PLAYER_WALL_RAN", runId: "", payload: { duration: this.wallRunTimer } });
    return true;
  }
  private endWallRun() { this.wallRunTimer = 0; this.wallSide = 0; this.technique = "none"; if (!this.isGrounded) this.movementState = "falling"; }

  startRailGrind(duration = 1.6) {
    if (!this.abilities.railGrind || this.railTimer > 0 || this.stamina < 6 || this.y > 1.6) return false;
    this.movementState = "grinding";
    this.technique = "railGrind";
    this.railTimer = duration;
    this.stamina -= 6;
    this.advancedMoveCount++;
    this.isGrounded = false; this.vy = 0; this.y = 0.45;
    auvyrrBridge.emit({ type: "ABILITY_USED", runId: "", payload: { ability: "railGrind" } });
    return true;
  }
  private endRail() { this.railTimer = 0; this.technique = "none"; this.movementState = "falling"; }

  startGrapple() {
    if (!this.abilities.grapple || this.grappleTimer > 0 || this.grappleCooldown > 0 || this.stamina < 14 || !this.canAct) return false;
    this.movementState = "grappling";
    this.technique = "grapple";
    this.grappleTimer = 0.8;
    this.grappleCooldown = 2.5;
    this.stamina -= 14;
    this.advancedMoveCount++;
    this.isGrounded = false;
    this.vy = 0;
    this.slideTimer = 0; this.height = this.heightStanding;
    this.ev.grapple = true;
    auvyrrBridge.emit({ type: "ABILITY_USED", runId: "", payload: { ability: "grapple" } });
    return true;
  }

  startSlide() {
    this.movementState = "sliding";
    this.slideCount++;
    this.slideTimer = this.def.sim.slideTime;
    this.height = this.heightSliding;
    if (this.def.sim.evadeIframes > 0) { this.invulnTimer = Math.max(this.invulnTimer, this.def.sim.evadeIframes); this.evadeTimer = this.def.sim.evadeIframes; }
    this.ev.slid = true;
    auvyrrBridge.emit({ type: "PLAYER_SLID", runId: "", payload: {} });
  }

  update(dt: number, worldSpeed: number) {
    // ── Technique timers ──
    if (this.dashCooldown > 0) this.dashCooldown -= dt;
    if (this.grappleCooldown > 0) this.grappleCooldown -= dt;
    if (this.smashCooldown > 0) this.smashCooldown -= dt;
    if (this.evadeTimer > 0) this.evadeTimer -= dt;
    if (this.landTimer > 0) this.landTimer -= dt;
    if (this.hitFlash > 0) this.hitFlash -= dt;
    if (this.stunTimer > 0) {
      this.stunTimer -= dt;
      if (this.stunTimer <= 0 && this.movementState === "stunned") this.movementState = this.isGrounded ? "running" : "falling";
    }

    if (this.wallRunTimer > 0) {
      this.wallRunTimer -= dt;
      this.vy = 0;
      this.y = Math.max(this.y, 1.1);
      this.x += (this.wallSide * (this.laneWidth + 0.5) - this.x) * damp(14, dt);
      this.stamina = Math.max(0, this.stamina - dt * 7);
      if (this.wallRunTimer <= 0) this.endWallRun();
    }
    if (this.railTimer > 0) {
      this.railTimer -= dt;
      this.vy = 0; this.y = 0.45;
      this.stamina = Math.min(this.maxStamina, this.stamina + dt * 6);
      if (this.railTimer <= 0) this.endRail();
    }
    if (this.grappleTimer > 0) {
      this.grappleTimer -= dt;
      const prog = 1 - this.grappleTimer / 0.8;
      this.y = 0.3 + Math.sin(Math.min(1, prog * 1.25) * Math.PI * 0.5) * 3.6;
      this.vy = 0;
      if (this.grappleTimer <= 0) { this.technique = "none"; this.movementState = "falling"; this.vy = 0; }
    }
    if (this.dashTimer > 0) {
      this.dashTimer -= dt;
      this.vy = Math.max(this.vy, 0.4);
      if (this.dashTimer <= 0) { this.technique = "none"; this.movementState = "falling"; }
    }

    // Stamina regeneration
    if (this.isGrounded && this.movementState !== "sliding") this.stamina = Math.min(this.maxStamina, this.stamina + dt * 16 * this.def.sim.staminaRegen);
    else if (!this.isGrounded) this.stamina = Math.min(this.maxStamina, this.stamina + dt * 3);

    // ── Lateral ──
    if (this.wallRunTimer <= 0) {
      const sharp = this.def.sim.laneSharpness * (this.isGrounded ? 1 : this.def.sim.airControl);
      const targetX = this.targetLane * this.laneWidth;
      const prevX = this.x;
      this.x += (targetX - this.x) * damp(17 * sharp, dt);
      if (Math.abs(targetX - this.x) < 0.02) { this.x = targetX; this.laneDir = 0; }
      this.laneVelX = dt > 0 ? (this.x - prevX) / dt : 0;
      this.lane = Math.round(this.x / this.laneWidth);
    }

    // ── Vertical ──
    const hovering = this.wallRunTimer > 0 || this.railTimer > 0 || this.grappleTimer > 0;
    if (!hovering && !this.isGrounded) {
      this.vy -= this.gravity * dt;
      this.y += this.vy * dt;
      if (this.y <= this.groundY) {
        this.y = this.groundY;
        const impact = -this.vy;
        this.vy = 0;
        this.isGrounded = true;
        this.airJumpsUsed = 0;
        if (this.movementState === "jumping" || this.movementState === "falling" || this.movementState === "airDashing") this.movementState = "running";
        this.landTimer = impact > 7 ? 0.28 : 0.16;
        this.ev.landed = true;
        if (this.slideBuffer > 0) { this.startSlide(); this.slideBuffer = 0; }
      }
    } else if (!hovering && this.isGrounded && this.y > 0) { this.y = 0; }

    // Falling-state detection (walked off / jump apex)
    if (!this.isGrounded && this.vy < -1 && this.movementState === "jumping") this.movementState = "jumping"; // keep "jumping" until landing; animator decides apex/fall from vy

    // ── Slide ──
    if (this.movementState === "sliding") {
      this.slideTimer -= dt;
      if (this.slideTimer <= 0) { this.movementState = "running"; this.height = this.heightStanding; }
    }

    if (this.invulnTimer > 0) this.invulnTimer -= dt;
    this.vz = worldSpeed;
  }

  /** @returns true if damage was applied (not absorbed). */
  takeDamage(amount: number): boolean {
    if (this.invulnTimer > 0 || !this.alive) return false;
    this.ev.hit = true;
    if (this.shieldCharges > 0) { this.shieldCharges--; this.invulnTimer = 0.8; return false; }
    this.health -= amount;
    this.hitFlash = 0.5;
    this.invulnTimer = 1.3;
    if (this.health <= 0) {
      this.health = 0;
      this.movementState = "dead";
    } else {
      this.movementState = "stunned";
      this.stunTimer = 0.45;
      this.wallRunTimer = this.railTimer = this.grappleTimer = this.dashTimer = 0;
      this.slideTimer = 0; this.height = this.heightStanding;
    }
    return true;
  }

  collidesWith(obj: { x: number; y: number; z: number; width: number; height: number; depth: number }) {
    const dx = Math.abs(this.x - obj.x) < (this.width + obj.width) / 2 - 0.05;
    const dy = this.y < obj.y + obj.height - 0.02 && this.y + this.height > obj.y + 0.02;
    const dz = Math.abs(this.z - obj.z) < (0.5 + obj.depth) / 2;
    return dx && dy && dz;
  }
}
