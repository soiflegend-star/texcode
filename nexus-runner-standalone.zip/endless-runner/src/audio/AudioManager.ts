/**
 * AudioManager — fully procedural WebAudio (no audio files required).
 *
 * Architecture:  sfx bus ─┐
 *                ambience bus ─┼─ master ─ compressor ─ destination
 *                music bus ─┘
 * - Short SFX are synthesised from oscillators + filtered noise bursts.
 * - Looping ambience (wind / city / highway traffic / subway hum / industrial / forest) uses
 *   looped noise buffers with per-region filters, plus scheduled "one-shot" details
 *   (distant horns, drips, bird chirps, machinery clanks).
 * - A small generative music loop (optional).
 * Real audio files can replace any of this via `registerSample(id, url)` — the SFX id is looked up first.
 * Safe in headless/node: constructing with `disabled=true` makes every call a no-op.
 */
import type { FxEvent, Game } from "../core/Game.js";

type Ctx = AudioContext;

export class AudioManager {
  private muted = false;
  private ctx: Ctx | null = null;
  private master!: GainNode; private sfxBus!: GainNode; private ambBus!: GainNode; private musicBus!: GainNode;
  private noiseBuf: AudioBuffer | null = null;
  private samples = new Map<string, AudioBuffer>();
  private ambience: { id: string; src: AudioBufferSourceNode; gain: GainNode; filter: BiquadFilterNode } | null = null;
  private ambTimer: any = null;
  private musicTimer: any = null;
  private musicOn = true;
  private paused = false;
  private sfxVolume = 0.8;
  private disabled: boolean;
  private lastStep = 0;
  private continuous: Record<string, { gain: GainNode; src: AudioBufferSourceNode } | undefined> = {};
  private rainGain = 0;
  private vibrationOn = true;

  constructor(disabled = false) { this.disabled = disabled; }

  // ── lifecycle ──
  private ensure(): Ctx | null {
    if (this.disabled || typeof window === "undefined") return null;
    if (!this.ctx) {
      const C = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!C) { this.disabled = true; return null; }
      try {
        this.ctx = new C() as Ctx;
        const c = this.ctx;
        const comp = c.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
        this.master = c.createGain(); this.master.gain.value = this.muted ? 0 : 0.9;
        this.sfxBus = c.createGain(); this.sfxBus.gain.value = this.sfxVolume;
        this.ambBus = c.createGain(); this.ambBus.gain.value = 0.55;
        this.musicBus = c.createGain(); this.musicBus.gain.value = 0.22;
        this.sfxBus.connect(this.master); this.ambBus.connect(this.master); this.musicBus.connect(this.master);
        this.master.connect(comp); comp.connect(c.destination);
        // 2s of white noise reused by everything
        const len = c.sampleRate * 2; const buf = c.createBuffer(1, len, c.sampleRate); const d = buf.getChannelData(0);
        let b0 = 0; for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; b0 = 0.98 * b0 + 0.02 * w; d[i] = w * 0.6 + b0 * 3; }
        this.noiseBuf = buf;
      } catch { this.disabled = true; this.ctx = null; return null; }
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }
  /** Must be called from a user gesture on mobile browsers. */
  unlock() { this.ensure(); }

  setMuted(m: boolean) { this.muted = m; if (this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.05); }
  toggleMuted() { this.setMuted(!this.muted); return this.muted; }
  isMuted() { return this.muted; }
  setSfxVolume(v: number) { this.sfxVolume = v; if (this.ctx) this.sfxBus.gain.value = v; }
  setMusicEnabled(on: boolean) { this.musicOn = on; if (!on) this.stopMusic(); }
  setVibration(on: boolean) { this.vibrationOn = on; }
  setPaused(p: boolean) { this.paused = p; if (this.ctx) { if (p) void this.ctx.suspend(); else void this.ctx.resume(); } }
  vibrate(ms: number) { if (this.vibrationOn && typeof navigator !== "undefined" && (navigator as any).vibrate) { try { (navigator as any).vibrate(ms); } catch { /* ignore */ } } }
  isActive() { return !!this.ctx && !this.disabled; }
  getContextState() { return this.ctx?.state ?? "none"; }

  async registerSample(id: string, url: string) {
    const c = this.ensure(); if (!c) return false;
    try { const r = await fetch(url); const b = await c.decodeAudioData(await r.arrayBuffer()); this.samples.set(id, b); return true; } catch { return false; }
  }

  // ── primitives ──
  private tone(type: OscillatorType, f0: number, f1: number, dur: number, vol = 0.12, delay = 0, bus: AudioNode | null = null) {
    const c = this.ctx!; const t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(bus ?? this.sfxBus); o.start(t); o.stop(t + dur + 0.03);
  }
  private noise(dur: number, vol: number, f0: number, f1: number, q = 1, type: BiquadFilterType = "bandpass", delay = 0, bus: AudioNode | null = null) {
    const c = this.ctx!; const t = c.currentTime + delay;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf!; s.loop = true;
    const f = c.createBiquadFilter(); f.type = type; f.Q.value = q; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.02, dur / 3)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(bus ?? this.sfxBus); s.start(t, Math.random() * 1.5); s.stop(t + dur + 0.05);
  }

  /** Play a named SFX. */
  playSfx(id: string, vol = 1) {
    if (this.muted) return;
    const c = this.ensure(); if (!c) return;
    const sm = this.samples.get(id);
    if (sm) { const s = c.createBufferSource(); s.buffer = sm; const g = c.createGain(); g.gain.value = vol; s.connect(g); g.connect(this.sfxBus); s.start(); return; }
    const v = vol;
    switch (id) {
      case "jump": this.tone("triangle", 300, 620, 0.16, 0.09 * v); this.noise(0.14, 0.05 * v, 900, 2400, 0.8); break;
      case "doubleJump": this.tone("triangle", 480, 980, 0.18, 0.09 * v); this.tone("sine", 960, 1500, 0.14, 0.05 * v, 0.05); break;
      case "land": this.tone("sine", 120, 55, 0.14, 0.18 * v); this.noise(0.09, 0.09 * v, 700, 200, 0.7, "lowpass"); break;
      case "slide": this.noise(0.45, 0.1 * v, 2200, 600, 1.2); break;
      case "step": this.noise(0.05, 0.05 * v, 1600 + Math.random() * 400, 500, 1.4); this.tone("sine", 90 + Math.random() * 20, 60, 0.05, 0.04 * v); break;
      case "coin": this.tone("square", 988, 988, 0.06, 0.05 * v); this.tone("square", 1318, 1318, 0.16, 0.05 * v, 0.055); this.tone("sine", 2637, 2637, 0.12, 0.03 * v, 0.055); break;
      case "hit": this.noise(0.28, 0.28 * v, 1400, 120, 0.6, "lowpass"); this.tone("sawtooth", 150, 45, 0.3, 0.16 * v); break;
      case "smash": this.noise(0.35, 0.3 * v, 3000, 200, 0.5); this.tone("square", 220, 60, 0.2, 0.1 * v); break;
      case "shieldBreak": this.tone("sine", 900, 200, 0.3, 0.12 * v); this.noise(0.2, 0.1 * v, 5000, 1500, 2, "highpass"); break;
      case "boost": this.noise(0.7, 0.14 * v, 300, 4000, 0.7); this.tone("sawtooth", 160, 640, 0.6, 0.07 * v); break;
      case "boostEnd": this.noise(0.4, 0.07 * v, 3000, 300, 0.7); break;
      case "powerup": [523, 659, 784, 1047].forEach((f, i) => this.tone("triangle", f, f, 0.18, 0.08 * v, i * 0.055)); break;
      case "dash": this.noise(0.22, 0.14 * v, 600, 5000, 1); this.tone("sawtooth", 200, 900, 0.16, 0.05 * v); break;
      case "wallRun": this.noise(0.3, 0.08 * v, 1200, 800, 3); break;
      case "grapple": this.tone("sawtooth", 140, 700, 0.15, 0.06 * v); this.noise(0.12, 0.08 * v, 2500, 6000, 2, "highpass"); break;
      case "nearMiss": this.noise(0.18, 0.1 * v, 1800, 5200, 1.5); this.tone("sine", 700, 1200, 0.12, 0.05 * v); break;
      case "regionEnter": [392, 523, 659].forEach((f, i) => this.tone("sine", f, f * 1.01, 0.6, 0.07 * v, i * 0.12)); this.noise(1.0, 0.07 * v, 200, 2000, 0.6); break;
      case "missionDone": [659, 784, 988, 1319].forEach((f, i) => this.tone("triangle", f, f, 0.25, 0.08 * v, i * 0.09)); break;
      case "combo": this.tone("square", 784, 1568, 0.15, 0.05 * v); break;
      case "death": this.tone("sawtooth", 260, 40, 0.9, 0.15 * v); this.noise(0.7, 0.2 * v, 1200, 80, 0.6, "lowpass"); break;
      case "thunder": this.noise(2.4, 0.34 * v, 400, 60, 0.4, "lowpass"); this.noise(0.12, 0.2 * v, 6000, 800, 0.5); break;
      case "siren": this.tone("sawtooth", 600, 900, 0.5, 0.05 * v); this.tone("sawtooth", 900, 600, 0.5, 0.05 * v, 0.5); break;
      case "eventStart": this.tone("sawtooth", 220, 220, 0.14, 0.07 * v); this.tone("sawtooth", 220, 220, 0.14, 0.07 * v, 0.2); this.tone("sawtooth", 330, 330, 0.3, 0.07 * v, 0.4); break;
      case "eventEnd": this.tone("sine", 660, 440, 0.3, 0.05 * v); break;
      case "rail": this.noise(0.22, 0.08 * v, 3500, 3500, 6); this.tone("sawtooth", 1800, 1700, 0.18, 0.03 * v); break;
      case "trainHorn": this.tone("sawtooth", 196, 196, 0.8, 0.07 * v); this.tone("sawtooth", 247, 247, 0.8, 0.07 * v); break;
      case "rivalPass": this.noise(0.4, 0.12 * v, 500, 3000, 0.8); break;
      case "rivalDefeat": this.tone("triangle", 880, 440, 0.3, 0.07 * v); break;
      case "uiClick": this.tone("triangle", 660, 520, 0.06, 0.06 * v); break;
      case "uiBack": this.tone("triangle", 440, 330, 0.07, 0.06 * v); break;
      case "uiConfirm": this.tone("triangle", 520, 780, 0.1, 0.07 * v); this.tone("triangle", 780, 1040, 0.1, 0.06 * v, 0.07); break;
      case "uiDeny": this.tone("square", 160, 120, 0.15, 0.05 * v); break;
      case "start": this.tone("triangle", 330, 660, 0.3, 0.08 * v); this.noise(0.3, 0.06 * v, 500, 3000, 0.7); break;
      default: this.tone("triangle", 300, 400, 0.06, 0.05 * v);
    }
  }
  /** legacy alias */
  playMusic(_id: string) { if (this.musicOn) this.startMusic(); }

  // ── fx → audio mapping ──
  onFx(list: FxEvent[], game: Game) {
    if (this.disabled || !list.length) return;
    for (const e of list) {
      switch (e.type) {
        case "coin": this.playSfx("coin"); break;
        case "powerup": this.playSfx("powerup"); break;
        case "hit": this.playSfx("hit"); break;
        case "shieldBreak": this.playSfx("shieldBreak"); break;
        case "smash": this.playSfx("smash"); break;
        case "land": this.playSfx("land", e.value ?? 1); break;
        case "jump": this.playSfx("jump"); break;
        case "doubleJump": this.playSfx("doubleJump"); break;
        case "slide": this.playSfx("slide"); break;
        case "dash": this.playSfx("dash"); break;
        case "wallRun": this.playSfx("wallRun"); break;
        case "grapple": this.playSfx("grapple"); break;
        case "nearMiss": this.playSfx("nearMiss"); break;
        case "boost": this.playSfx(e.value ? "boost" : "boostEnd"); break;
        case "regionEnter": this.playSfx("regionEnter"); this.setAmbience(game.world.currentRegionId === "city_rooftops" ? "city" : ambienceFor(e.id)); break;
        case "lightning": this.playSfx("thunder"); break;
        case "death": this.playSfx("death"); break;
        case "railStart": this.playSfx("rail"); break;
        case "missionDone": this.playSfx("missionDone"); break;
        case "combo": this.playSfx("combo"); break;
        case "start": this.playSfx("start"); if (this.musicOn) this.startMusic(); break;
        case "uiClick": this.playSfx("uiClick"); break;
        case "eventStart":
          this.playSfx("eventStart");
          if (e.id === "train_rush") this.playSfx("trainHorn");
          if (e.id === "drone_pursuit" || e.id === "road_closure") this.playSfx("siren");
          break;
        case "eventEnd": this.playSfx("eventEnd"); break;
        case "rival": this.playSfx(e.id === "defeated" ? "rivalDefeat" : "rivalPass"); break;
      }
    }
    // footsteps tied to run cadence
    if (game.phase === "running" && game.player.isGrounded && game.player.movementState === "running" && game.player.alive) {
      const cadence = 0.46 - Math.min(0.18, (game.speed - 14) * 0.012);
      this.lastStep += 1 / 60;
      if (this.lastStep > cadence) { this.lastStep = 0; this.playSfx("step", 0.6); }
    }
    // rain intensity follows the atmosphere
    this.setRain(game.events.atmosphere.rain);
    // train rumble / traffic loops depend on region & events
    this.setContinuous("rumble", game.events.has("train_rush") ? 0.22 : 0, 60, 140);
    this.setContinuous("rail", game.player.railTimer > 0 ? 0.08 : 0, 3000, 3800);
    this.setContinuous("boost", game.boostTimer > 0 || game.powerups.speed > 0 ? 0.05 : 0, 1500, 900);
  }

  private setContinuous(id: string, level: number, freq: number, q: number) {
    const c = this.ctx; if (!c || this.disabled) return;
    let n = this.continuous[id];
    if (!n && level > 0) {
      const src = c.createBufferSource(); src.buffer = this.noiseBuf!; src.loop = true;
      const f = c.createBiquadFilter(); f.type = id === "rumble" ? "lowpass" : "bandpass"; f.frequency.value = freq; f.Q.value = id === "rumble" ? 0.7 : 2;
      const g = c.createGain(); g.gain.value = 0; src.connect(f); f.connect(g); g.connect(this.sfxBus); src.start();
      n = { gain: g, src }; this.continuous[id] = n;
    }
    if (n) n.gain.gain.setTargetAtTime(level, c.currentTime, 0.2);
  }

  private setRain(level: number) {
    if (Math.abs(level - this.rainGain) < 0.02) return;
    this.rainGain = level;
    this.setContinuous("rain", level * 0.12, 5200, 1);
  }

  // ── ambience ──
  setAmbience(id: string) {
    const c = this.ensure(); if (!c || !this.noiseBuf) return;
    if (this.ambience?.id === id) return;
    this.stopAmbience(1.2);
    const src = c.createBufferSource(); src.buffer = this.noiseBuf; src.loop = true;
    const filter = c.createBiquadFilter(); const gain = c.createGain(); gain.gain.value = 0;
    const cfg: Record<string, [BiquadFilterType, number, number, number]> = {
      city: ["bandpass", 500, 0.6, 0.16], highway: ["bandpass", 260, 0.5, 0.24], subway: ["lowpass", 160, 0.8, 0.28], industrial: ["bandpass", 220, 0.7, 0.2], forest: ["highpass", 1800, 0.5, 0.05],
    };
    const [type, freq, q, vol] = cfg[id] ?? cfg.city;
    filter.type = type; filter.frequency.value = freq; filter.Q.value = q;
    src.connect(filter); filter.connect(gain); gain.connect(this.ambBus); src.start();
    gain.gain.setTargetAtTime(vol, c.currentTime, 0.8);
    this.ambience = { id, src, gain, filter };
    if (this.ambTimer) clearInterval(this.ambTimer);
    this.ambTimer = setInterval(() => this.ambienceDetail(id), 2600);
  }
  stopAmbience(fade = 0.4) {
    const c = this.ctx; if (this.ambTimer) { clearInterval(this.ambTimer); this.ambTimer = null; }
    if (!c || !this.ambience) return;
    const a = this.ambience; a.gain.gain.setTargetAtTime(0, c.currentTime, fade / 3);
    setTimeout(() => { try { a.src.stop(); } catch { /* ignore */ } }, fade * 1000 + 200);
    this.ambience = null;
    this.setContinuous("rumble", 0, 60, 1); this.setContinuous("rain", 0, 1, 1);
  }
  private ambienceDetail(id: string) {
    if (!this.ctx || this.muted || this.paused) return;
    const r = Math.random();
    switch (id) {
      case "city": if (r < 0.35) this.tone("sawtooth", 330, 320, 0.4, 0.012, 0, this.ambBus); if (r > 0.8) this.noise(0.5, 0.03, 1500, 900, 1, "bandpass", 0, this.ambBus); break;
      case "highway": if (r < 0.6) this.noise(1.2, 0.05, 300, 1100, 1, "bandpass", 0, this.ambBus); if (r > 0.9) this.tone("square", 392, 392, 0.3, 0.012, 0, this.ambBus); break;
      case "subway": if (r < 0.4) this.tone("sine", 900 + Math.random() * 300, 400, 0.08, 0.03, 0, this.ambBus); if (r > 0.7) this.noise(0.4, 0.06, 5000, 2000, 2, "highpass", 0, this.ambBus); break;
      case "industrial": if (r < 0.4) { this.tone("square", 140, 100, 0.12, 0.03, 0, this.ambBus); this.noise(0.4, 0.05, 700, 300, 1, "bandpass", 0, this.ambBus); } break;
      case "forest": if (r < 0.7) { const f = 2200 + Math.random() * 1500; this.tone("sine", f, f * 1.25, 0.09, 0.025, 0, this.ambBus); this.tone("sine", f * 1.1, f * 1.4, 0.07, 0.02, 0.12, this.ambBus); } break;
    }
  }

  // ── music: small generative loop ──
  private startMusic() {
    if (this.musicTimer || !this.ensure() || !this.musicOn) return;
    const scale = [0, 3, 5, 7, 10]; let step = 0; const root = 110;
    this.musicTimer = setInterval(() => {
      if (!this.ctx || this.muted || this.paused) return;
      const bar = Math.floor(step / 8) % 4;
      const base = root * Math.pow(2, [0, 5, 3, 7][bar] / 12);
      if (step % 8 === 0) this.tone("triangle", base, base, 1.2, 0.05, 0, this.musicBus);
      if (step % 2 === 0) { const n = scale[(step * 7 + bar * 3) % scale.length]; const f = base * 4 * Math.pow(2, n / 12); this.tone("sine", f, f, 0.22, 0.03, 0, this.musicBus); }
      if (step % 4 === 2) this.noise(0.04, 0.02, 7000, 7000, 1, "highpass", 0, this.musicBus);
      step++;
    }, 220);
    (this.musicTimer as any).unref?.();
  }
  stopMusic() { if (this.musicTimer) { clearInterval(this.musicTimer); this.musicTimer = null; } }
}

function ambienceFor(regionId?: string): string {
  switch (regionId) { case "highway": return "highway"; case "subway": return "subway"; case "industrial": return "industrial"; case "forest": return "forest"; default: return "city"; }
}
