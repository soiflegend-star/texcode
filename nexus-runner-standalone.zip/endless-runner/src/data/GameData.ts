/**
 * GameData — all static, data-driven definitions: characters, regions,
 * obstacles, collectibles/power-ups, events, quality tiers.
 * Pure data (no DOM / WebGL) so it can be used by headless tests and AUVYRR.
 */

export const LANE_WIDTH = 2.4;
export const REGION_LENGTH = 960;        // metres per region (16 chunks)
export const TRANSITION_LENGTH = 60;     // metres of physical transition piece at end of each region
export const CHUNK_LENGTH = 60;          // metres per scenery chunk

// ───────────────────────── Characters ─────────────────────────
export type CharacterId = "runner" | "acrobat" | "speedster" | "heavy" | "ninja";

export interface CharacterDef {
  id: CharacterId;
  name: string;
  tagline: string;
  abilityName: string;
  abilityText: string;
  /** 1–5 bars shown on the character select screen */
  bars: { speed: number; jump: number; control: number; durability: number; slide: number };
  sim: {
    speedMult: number; maxSpeedBonus: number; jumpForce: number; gravityMult: number;
    maxHealth: number; laneSharpness: number; slideTime: number; slideHeight: number;
    standHeight: number; doubleJump: boolean; airDashCost: number; airControl: number;
    smashLow: boolean; evadeIframes: number; staminaRegen: number;
  };
  unlockCost: number; // 0 = default
}

export const CHARACTERS: Record<CharacterId, CharacterDef> = {
  runner: {
    id: "runner", name: "Runner", tagline: "Balanced starter", abilityName: "Second Wind",
    abilityText: "Recovers stamina faster after every landing.",
    bars: { speed: 3, jump: 3, control: 3, durability: 3, slide: 3 },
    sim: { speedMult: 1, maxSpeedBonus: 0, jumpForce: 12.4, gravityMult: 1, maxHealth: 3, laneSharpness: 1, slideTime: 0.6, slideHeight: 0.8, standHeight: 1.7, doubleJump: false, airDashCost: 18, airControl: 1, smashLow: false, evadeIframes: 0, staminaRegen: 1.25 },
    unlockCost: 0,
  },
  acrobat: {
    id: "acrobat", name: "Acrobat", tagline: "Master of the air", abilityName: "Double Jump",
    abilityText: "Jump again in mid-air. Floatier arcs and cheaper air dashes.",
    bars: { speed: 3, jump: 5, control: 4, durability: 2, slide: 3 },
    sim: { speedMult: 1, maxSpeedBonus: 0, jumpForce: 13.4, gravityMult: 0.86, maxHealth: 3, laneSharpness: 1.05, slideTime: 0.6, slideHeight: 0.8, standHeight: 1.65, doubleJump: true, airDashCost: 12, airControl: 1.3, smashLow: false, evadeIframes: 0, staminaRegen: 1 },
    unlockCost: 300,
  },
  speedster: {
    id: "speedster", name: "Speedster", tagline: "Built for velocity", abilityName: "Overdrive",
    abilityText: "Higher cruising speed and a higher top-speed cap. Slightly less agile.",
    bars: { speed: 5, jump: 3, control: 2, durability: 2, slide: 3 },
    sim: { speedMult: 1.12, maxSpeedBonus: 5, jumpForce: 12.4, gravityMult: 1, maxHealth: 3, laneSharpness: 0.88, slideTime: 0.6, slideHeight: 0.8, standHeight: 1.72, doubleJump: false, airDashCost: 18, airControl: 0.9, smashLow: false, evadeIframes: 0, staminaRegen: 1 },
    unlockCost: 800,
  },
  heavy: {
    id: "heavy", name: "Heavy", tagline: "Hits back", abilityName: "Bulldoze",
    abilityText: "+1 heart and smashes low obstacles instead of taking damage (4s cooldown).",
    bars: { speed: 2, jump: 2, control: 2, durability: 5, slide: 2 },
    sim: { speedMult: 0.95, maxSpeedBonus: 0, jumpForce: 11.6, gravityMult: 1.05, maxHealth: 4, laneSharpness: 0.9, slideTime: 0.55, slideHeight: 0.95, standHeight: 1.85, doubleJump: false, airDashCost: 22, airControl: 0.8, smashLow: true, evadeIframes: 0, staminaRegen: 0.9 },
    unlockCost: 1500,
  },
  ninja: {
    id: "ninja", name: "Ninja", tagline: "Slip through anything", abilityName: "Evade",
    abilityText: "Longer, lower slides with brief invulnerability at slide start. Very quick lane swaps.",
    bars: { speed: 3, jump: 3, control: 5, durability: 2, slide: 5 },
    sim: { speedMult: 1.04, maxSpeedBonus: 1, jumpForce: 12.4, gravityMult: 1, maxHealth: 3, laneSharpness: 1.2, slideTime: 0.85, slideHeight: 0.62, standHeight: 1.72, doubleJump: false, airDashCost: 16, airControl: 1.1, smashLow: false, evadeIframes: 0.28, staminaRegen: 1.1 },
    unlockCost: 2500,
  },
};
export const CHARACTER_IDS = Object.keys(CHARACTERS) as CharacterId[];

// ───────────────────────── Regions ─────────────────────────
export type RegionId = "city_rooftops" | "highway" | "subway" | "industrial" | "forest";

export interface RegionDef {
  id: RegionId;
  name: string;
  shortName: string;
  index: number;
  blurb: string;
  enclosed: boolean;           // tunnel: no sky
  ambience: string;            // audio ambience id
  transitionName: string;      // piece at END of this region that leads to the next
  landmarks: string[];
  events: string[];            // allowed event ids
  obstacleSet: string[];       // obstacle type ids available
  swatch: string;              // UI colour
}

export const REGIONS: RegionDef[] = [
  {
    id: "city_rooftops", name: "Neon Rooftops", shortName: "Rooftops", index: 0, enclosed: false, ambience: "city",
    blurb: "Sun-bleached rooftop roads high above a dense skyline.",
    transitionName: "Skybridge Ramp", swatch: "#4aa3df",
    landmarks: ["skybridge", "water_tower_cluster", "rooftop_garden", "construction_site", "billboard_wall", "helipad"],
    events: ["lightning_storm", "construction_collapse", "drone_pursuit", "road_closure", "fog", "rain", "sunset", "night", "speed_surge", "coin_rush", "rival_chase"],
    obstacleSet: ["barricade", "crate", "crate_stack", "construction_barrier", "roadblock", "low_beam", "drone", "hvac_unit", "overhead_sign", "moving_barrier", "falling_debris"],
  },
  {
    id: "highway", name: "Sky Highway", shortName: "Highway", index: 1, enclosed: false, ambience: "highway",
    blurb: "A multilane elevated highway threading between towers.",
    transitionName: "Metro Underpass", swatch: "#3b7fc4",
    landmarks: ["gantry_sign", "cable_pylons", "interchange", "toll_gantry", "overpass", "skyline_view"],
    events: ["heavy_traffic", "lightning_storm", "construction_collapse", "drone_pursuit", "road_closure", "fog", "rain", "sunset", "night", "speed_surge", "coin_rush", "rival_chase"],
    obstacleSet: ["barricade", "construction_barrier", "jersey_barrier", "car", "van", "truck", "roadblock", "overhead_sign", "low_beam", "drone", "moving_barrier", "falling_debris"],
  },
  {
    id: "subway", name: "Subway Tunnels", shortName: "Subway", index: 2, enclosed: true, ambience: "subway",
    blurb: "Tiled stations, live tracks and trains that do not stop.",
    transitionName: "Station Exit Gate", swatch: "#2f8f9d",
    landmarks: ["station", "maintenance_corridor", "junction", "ventilation_shaft", "flooded_section"],
    events: ["train_rush", "speed_surge", "coin_rush", "rival_chase", "drone_pursuit"],
    obstacleSet: ["train", "bench", "cart", "turnstile", "steel_beam", "low_beam", "roadblock", "crate", "barricade", "moving_barrier", "falling_debris"],
  },
  {
    id: "industrial", name: "Industrial Zone", shortName: "Industrial", index: 3, enclosed: false, ambience: "industrial",
    blurb: "Warehouses, cranes and containers under warm haze.",
    transitionName: "Collapsed Factory Gate", swatch: "#d98a3d",
    landmarks: ["crane", "container_yard", "factory_smokestacks", "loading_dock", "pipe_bridge"],
    events: ["heavy_traffic", "construction_collapse", "drone_pursuit", "road_closure", "fog", "rain", "sunset", "speed_surge", "coin_rush", "rival_chase", "lightning_storm"],
    obstacleSet: ["barricade", "crate", "crate_stack", "container", "forklift", "truck", "pipe_low", "steel_beam", "roadblock", "construction_barrier", "moving_barrier", "falling_debris"],
  },
  {
    id: "forest", name: "Overgrown Ruins", shortName: "Ruins", index: 4, enclosed: false, ambience: "forest",
    blurb: "Nature reclaiming a broken city. Moss, vines and still water.",
    transitionName: "Ancient Arch Ramp", swatch: "#5a9a52",
    landmarks: ["ruined_bridge", "stone_arch", "collapsed_tower", "waterfall_pool", "giant_tree"],
    events: ["fog", "rain", "sunset", "lightning_storm", "speed_surge", "coin_rush", "rival_chase", "construction_collapse"],
    obstacleSet: ["fallen_log", "rock", "ruined_wall", "vine_bar", "barricade", "crate", "low_beam", "moving_barrier", "falling_debris"],
  },
];

export function regionAtDistance(dist: number): RegionDef {
  const idx = Math.floor(Math.max(0, dist) / REGION_LENGTH) % REGIONS.length;
  return REGIONS[idx];
}
/** Index of the region *segment* (not wrapped); loop = floor(i / 5). */
export function regionSegment(dist: number): number { return Math.floor(Math.max(0, dist) / REGION_LENGTH); }
export function inTransition(dist: number): boolean {
  const into = Math.max(0, dist) % REGION_LENGTH;
  return into >= REGION_LENGTH - TRANSITION_LENGTH;
}

// ───────────────────────── Obstacles ─────────────────────────
/** jump: clear by jumping • slide: slide beneath • block: change lane • dodge: lane change only (moving/falling) */
export type ObstacleKind = "jump" | "slide" | "block";
export interface ObstacleDef {
  id: string; kind: ObstacleKind;
  w: number; h: number; d: number; y: number;
  tier: number;               // 0 early, 1 mid, 2 late
  damage: number;
  vz?: number;                // extra approach speed (m/s) toward the player
  fullWidth?: boolean;        // spans all three lanes (only for kind 'slide' / 'jump'-gates)
  dRange?: [number, number];  // depth randomisation
  wobble?: number;            // lateral oscillation amplitude (visual + hitbox centre)
  fall?: { triggerZ: number; height: number; time: number };
  tags: string[];
}

const O = (o: ObstacleDef) => o;
export const OBSTACLES: Record<string, ObstacleDef> = {
  barricade:            O({ id: "barricade", kind: "jump", w: 2.0, h: 0.95, d: 0.7, y: 0, tier: 0, damage: 1, tags: ["barrier"] }),
  crate:                O({ id: "crate", kind: "jump", w: 1.7, h: 1.2, d: 1.5, y: 0, tier: 0, damage: 1, tags: ["crate"] }),
  crate_stack:          O({ id: "crate_stack", kind: "block", w: 1.9, h: 2.5, d: 1.7, y: 0, tier: 1, damage: 1, tags: ["crate"] }),
  construction_barrier: O({ id: "construction_barrier", kind: "jump", w: 2.1, h: 1.0, d: 0.6, y: 0, tier: 0, damage: 1, tags: ["barrier", "construction"] }),
  jersey_barrier:       O({ id: "jersey_barrier", kind: "jump", w: 2.2, h: 0.9, d: 2.4, y: 0, tier: 0, damage: 1, tags: ["barrier"] }),
  roadblock:            O({ id: "roadblock", kind: "block", w: 2.2, h: 1.9, d: 1.0, y: 0, tier: 0, damage: 1, tags: ["barrier"] }),
  low_beam:             O({ id: "low_beam", kind: "slide", w: 2.2, h: 0.9, d: 0.7, y: 1.05, tier: 0, damage: 1, tags: ["beam"] }),
  steel_beam:           O({ id: "steel_beam", kind: "slide", w: 2.2, h: 0.8, d: 0.9, y: 1.08, tier: 1, damage: 1, tags: ["beam"] }),
  pipe_low:             O({ id: "pipe_low", kind: "slide", w: 2.3, h: 0.6, d: 0.7, y: 1.1, tier: 1, damage: 1, tags: ["beam", "pipe"] }),
  vine_bar:             O({ id: "vine_bar", kind: "slide", w: 2.2, h: 0.8, d: 0.6, y: 1.1, tier: 0, damage: 1, tags: ["beam"] }),
  overhead_sign:        O({ id: "overhead_sign", kind: "slide", w: LANE_WIDTH * 3, h: 1.6, d: 0.8, y: 1.15, tier: 1, damage: 1, fullWidth: true, tags: ["sign", "gate"] }),
  drone:                O({ id: "drone", kind: "slide", w: 1.3, h: 0.7, d: 1.3, y: 1.2, tier: 1, damage: 1, tags: ["drone"] }),
  car:                  O({ id: "car", kind: "block", w: 2.0, h: 1.5, d: 4.4, y: 0, tier: 1, damage: 1, vz: 4, tags: ["vehicle"] }),
  van:                  O({ id: "van", kind: "block", w: 2.1, h: 2.4, d: 5.4, y: 0, tier: 1, damage: 1, vz: 3, tags: ["vehicle"] }),
  truck:                O({ id: "truck", kind: "block", w: 2.2, h: 3.0, d: 8.5, y: 0, tier: 2, damage: 1, vz: 2, dRange: [7, 11], tags: ["vehicle"] }),
  container:            O({ id: "container", kind: "block", w: 2.2, h: 2.6, d: 6.0, y: 0, tier: 1, damage: 1, tags: ["container"] }),
  forklift:             O({ id: "forklift", kind: "block", w: 1.7, h: 2.2, d: 3.0, y: 0, tier: 1, damage: 1, vz: 3, tags: ["vehicle"] }),
  train:                O({ id: "train", kind: "block", w: 2.2, h: 3.6, d: 20, y: 0, tier: 1, damage: 1, vz: 11, dRange: [16, 28], tags: ["train"] }),
  bench:                O({ id: "bench", kind: "jump", w: 1.9, h: 0.9, d: 0.7, y: 0, tier: 0, damage: 1, tags: ["station"] }),
  cart:                 O({ id: "cart", kind: "jump", w: 1.6, h: 1.0, d: 1.1, y: 0, tier: 0, damage: 1, tags: ["station"] }),
  turnstile:            O({ id: "turnstile", kind: "jump", w: 2.0, h: 1.0, d: 0.7, y: 0, tier: 0, damage: 1, tags: ["station"] }),
  hvac_unit:            O({ id: "hvac_unit", kind: "block", w: 2.0, h: 2.0, d: 2.2, y: 0, tier: 1, damage: 1, tags: ["rooftop"] }),
  fallen_log:           O({ id: "fallen_log", kind: "jump", w: 2.2, h: 0.95, d: 1.0, y: 0, tier: 0, damage: 1, tags: ["nature"] }),
  rock:                 O({ id: "rock", kind: "block", w: 2.0, h: 1.8, d: 1.8, y: 0, tier: 0, damage: 1, tags: ["nature"] }),
  ruined_wall:          O({ id: "ruined_wall", kind: "block", w: 2.2, h: 2.6, d: 1.0, y: 0, tier: 1, damage: 1, tags: ["ruin"] }),
  moving_barrier:       O({ id: "moving_barrier", kind: "block", w: 1.3, h: 1.8, d: 0.8, y: 0, tier: 2, damage: 1, wobble: 0.45, tags: ["moving"] }),
  falling_debris:       O({ id: "falling_debris", kind: "block", w: 1.7, h: 1.4, d: 1.7, y: 0, tier: 2, damage: 1, fall: { triggerZ: 30, height: 9, time: 0.55 }, tags: ["event", "debris"] }),
};

// ───────────────────────── Collectibles / power-ups ─────────────────────────
export type PowerUpId = "shield" | "magnet" | "speed" | "coinx2" | "invuln" | "slowmo" | "scorex2";
export interface PowerUpDef { id: PowerUpId; name: string; duration: number; color: string; icon: string; blurb: string; weight: number; }
export const POWERUPS: Record<PowerUpId, PowerUpDef> = {
  shield:  { id: "shield",  name: "Shield",           duration: 0,  color: "#4fc3ff", icon: "🛡", blurb: "Absorbs the next hit", weight: 3 },
  magnet:  { id: "magnet",  name: "Magnet",           duration: 9,  color: "#ff5a5a", icon: "🧲", blurb: "Pulls in nearby coins", weight: 3 },
  speed:   { id: "speed",   name: "Speed Boost",      duration: 5,  color: "#ffd23f", icon: "⚡", blurb: "Faster and untouchable", weight: 2 },
  coinx2:  { id: "coinx2",  name: "Coin Multiplier",  duration: 12, color: "#ffb02e", icon: "✖2", blurb: "Coins are worth double", weight: 2 },
  invuln:  { id: "invuln",  name: "Invulnerability",  duration: 5,  color: "#c58bff", icon: "★", blurb: "Smash through anything", weight: 1 },
  slowmo:  { id: "slowmo",  name: "Slow Motion",      duration: 6,  color: "#7ee8d0", icon: "⏱", blurb: "Time slows down", weight: 2 },
  scorex2: { id: "scorex2", name: "Score Multiplier", duration: 12, color: "#ff8bd6", icon: "◆", blurb: "Score gains doubled", weight: 2 },
};
export const POWERUP_IDS = Object.keys(POWERUPS) as PowerUpId[];

// ───────────────────────── Events ─────────────────────────
export type EventGroup = "hazard" | "weather" | "time" | "boon";
export interface EventDef { id: string; name: string; group: EventGroup; duration: number; minDistance: number; weight: number; icon: string; }
export const EVENTS: Record<string, EventDef> = {
  heavy_traffic:         { id: "heavy_traffic", name: "Heavy Traffic", group: "hazard", duration: 18, minDistance: 300, weight: 3, icon: "🚗" },
  lightning_storm:       { id: "lightning_storm", name: "Lightning Storm", group: "weather", duration: 22, minDistance: 500, weight: 2, icon: "⚡" },
  train_rush:            { id: "train_rush", name: "Train Rush", group: "hazard", duration: 16, minDistance: 0, weight: 4, icon: "🚆" },
  construction_collapse: { id: "construction_collapse", name: "Construction Collapse", group: "hazard", duration: 14, minDistance: 500, weight: 2, icon: "🏗" },
  drone_pursuit:         { id: "drone_pursuit", name: "Drone Pursuit", group: "hazard", duration: 15, minDistance: 600, weight: 2, icon: "🛸" },
  road_closure:          { id: "road_closure", name: "Road Closure", group: "hazard", duration: 14, minDistance: 400, weight: 2, icon: "🚧" },
  fog:                   { id: "fog", name: "Dense Fog", group: "weather", duration: 24, minDistance: 200, weight: 2, icon: "🌫" },
  rain:                  { id: "rain", name: "Rain", group: "weather", duration: 28, minDistance: 200, weight: 3, icon: "🌧" },
  sunset:                { id: "sunset", name: "Sunset", group: "time", duration: 30, minDistance: 150, weight: 3, icon: "🌇" },
  night:                 { id: "night", name: "Night Falls", group: "time", duration: 34, minDistance: 700, weight: 2, icon: "🌙" },
  speed_surge:           { id: "speed_surge", name: "Speed Surge", group: "boon", duration: 9, minDistance: 150, weight: 3, icon: "💨" },
  coin_rush:             { id: "coin_rush", name: "Coin Rush", group: "boon", duration: 11, minDistance: 100, weight: 3, icon: "🪙" },
  rival_chase:           { id: "rival_chase", name: "Rival Chase", group: "boon", duration: 22, minDistance: 400, weight: 2, icon: "🏁" },
};
export const EVENT_IDS = Object.keys(EVENTS);

// ───────────────────────── Rival personalities ─────────────────────────
export type RivalPersonality = "aggressive" | "cautious" | "speed" | "trick";
export const RIVAL_PERSONALITIES: Record<RivalPersonality, { name: string; speed: number; skill: number; boostChance: number; coinGreed: number; reaction: number; color: string }> = {
  aggressive: { name: "Blaze",  speed: 1.07, skill: 0.78, boostChance: 0.5, coinGreed: 0.4, reaction: 0.30, color: "#e23b3b" },
  cautious:   { name: "Sage",   speed: 0.97, skill: 0.95, boostChance: 0.15, coinGreed: 0.6, reaction: 0.45, color: "#3fae73" },
  speed:      { name: "Dash",   speed: 1.12, skill: 0.72, boostChance: 0.7, coinGreed: 0.2, reaction: 0.25, color: "#ffb02e" },
  trick:      { name: "Flip",   speed: 1.0,  skill: 0.85, boostChance: 0.3, coinGreed: 0.9, reaction: 0.35, color: "#a46bff" },
};

// ───────────────────────── Quality tiers ─────────────────────────
export type QualityTier = "LOW" | "MEDIUM" | "HIGH" | "ULTRA";
export interface QualitySettings {
  tier: QualityTier; pixelRatioCap: number; shadows: boolean; shadowMap: number; envReflections: boolean;
  chunksAhead: number; fogFar: number; particles: number; rain: number; clouds: number; antialias: boolean;
  texSize: number; ambientTraffic: number; grading: boolean; anisotropy: number; contactShadows: boolean; fpsTarget: number;
}
export const QUALITY: Record<QualityTier, QualitySettings> = {
  LOW:    { tier: "LOW",    pixelRatioCap: 1,    shadows: false, shadowMap: 0,    envReflections: false, chunksAhead: 5, fogFar: 230, particles: 0.35, rain: 250,  clouds: 4,  antialias: false, texSize: 128, ambientTraffic: 3,  grading: false, anisotropy: 1,  contactShadows: true,  fpsTarget: 30 },
  MEDIUM: { tier: "MEDIUM", pixelRatioCap: 1.5,  shadows: true,  shadowMap: 1024, envReflections: false, chunksAhead: 6, fogFar: 300, particles: 0.6,  rain: 450,  clouds: 7,  antialias: false, texSize: 256, ambientTraffic: 6,  grading: false, anisotropy: 2,  contactShadows: true,  fpsTarget: 60 },
  HIGH:   { tier: "HIGH",   pixelRatioCap: 2,    shadows: true,  shadowMap: 2048, envReflections: true,  chunksAhead: 7, fogFar: 380, particles: 1,    rain: 800,  clouds: 11, antialias: true,  texSize: 512, ambientTraffic: 10, grading: true,  anisotropy: 4,  contactShadows: true,  fpsTarget: 60 },
  ULTRA:  { tier: "ULTRA",  pixelRatioCap: 2.5,  shadows: true,  shadowMap: 4096, envReflections: true,  chunksAhead: 8, fogFar: 460, particles: 1.5,  rain: 1400, clouds: 16, antialias: true,  texSize: 512, ambientTraffic: 14, grading: true,  anisotropy: 8,  contactShadows: true,  fpsTarget: 60 },
};
export const QUALITY_ORDER: QualityTier[] = ["LOW", "MEDIUM", "HIGH", "ULTRA"];

// ───────────────────────── Abilities / unlocks ─────────────────────────
export const ABILITY_UNLOCKS: Array<{ id: string; score: number; name: string }> = [
  { id: "airDash",   score: 3000,  name: "Air Dash" },
  { id: "wallRun",   score: 8000,  name: "Wall Run" },
  { id: "railGrind", score: 15000, name: "Rail Grind" },
  { id: "grapple",   score: 25000, name: "Grapple" },
];

export const UPGRADES: Record<string, { name: string; desc: string; max: number; cost: (lvl: number) => number }> = {
  magnet:  { name: "Magnet Duration", desc: "+2s per level",  max: 5, cost: (l) => 200 + l * 200 },
  shield:  { name: "Shield Charges",  desc: "Start run with a shield at level 3+", max: 5, cost: (l) => 300 + l * 250 },
  coinval: { name: "Coin Value",      desc: "+10% coins per level", max: 5, cost: (l) => 250 + l * 250 },
  stamina: { name: "Stamina",         desc: "+8 max stamina per level", max: 5, cost: (l) => 150 + l * 150 },
};
