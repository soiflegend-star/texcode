/**
 * Nexus Runner — entry point. Creates the Game (simulation), tries to create the WebGL scene,
 * falls back to the 2D debug renderer if WebGL is unavailable, then mounts the UI.
 */
import { Game } from "./core/Game.js";
import { auvyrrBridge } from "./auvyrr/AuvyrrBridge.js";
import { UI } from "./ui/UI.js";

const canvas = document.getElementById("game") as HTMLCanvasElement;
if (!canvas) throw new Error("Canvas #game not found");
const loading = document.getElementById("loading");
const msg = document.getElementById("loading-msg");

// Standalone mode: AUVYRR is optional. `?auvyrr=off` makes the bridge a complete no-op.
if (new URLSearchParams(location.search).get("auvyrr") === "off") auvyrrBridge.setEnabled(false);

let wake: any = null;
async function keepAwake() { try { wake = await (navigator as any).wakeLock?.request("screen"); } catch { /* not supported / denied */ } }
document.addEventListener("visibilitychange", () => { if (!document.hidden && wake) void keepAwake(); });
window.addEventListener("pointerdown", () => { if (!wake) void keepAwake(); }, { once: true });

async function boot() {
  const game = new Game(canvas);
  game.progression.load();
  let scene: import("./core/Scene3D.js").Scene3D | null = null;
  let renderError: string | null = null;
  try {
    const { Scene3D } = await import("./core/Scene3D.js");
    const q = game.progression.settings.quality;
    scene = new Scene3D(canvas, game, q as any);
  } catch (err) {
    renderError = String((err as Error)?.message ?? err);
    console.error("[Nexus Runner] 3D renderer failed, using 2D fallback:", err);
    if (msg) msg.textContent = "WebGL unavailable — using 2D fallback";
  }
  game.attachScene(scene);
  const ui = new UI(game, scene);
  game.setPhase("menu");
  scene?.setMode("menu");
  game.start();
  const uiLoop = () => { ui.tick(); requestAnimationFrame(uiLoop); };
  requestAnimationFrame(uiLoop);
  window.setTimeout(() => loading?.classList.add("done"), renderError ? 900 : 350);

  // Debug / test handles (read-only use by the smoke tests and AUVYRR console)
  (window as any).game = game; (window as any).scene3d = scene; (window as any).ui = ui; (window as any).auvyrr = auvyrrBridge;
  console.info("Nexus Runner ready", { renderer: scene ? "WebGL" : "2D fallback", quality: scene?.qualityLabel });
  console.info("AUVYRR Bridge:", auvyrrBridge.getDiagnostics());
}
boot().catch((e) => { console.error(e); if (msg) msg.textContent = "Failed to start: " + (e as Error).message; });
