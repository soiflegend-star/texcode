/**
 * MissionManager — persistent missions. Three active slots; progress accumulates
 * across runs (so "Collect 100 coins 24/100" like the HUD reference) and survives refresh.
 * Completed missions pay coins at the end of the run and are replaced by new ones.
 */
import { makeRng } from "../util/rng.js";

export type MissionKind = "distance" | "coins" | "combo" | "jumps" | "slides" | "advanced" | "powerups" | "nearmiss" | "events" | "regions" | "score";

export interface Mission {
  id: string; title: string; kind: MissionKind; target: number; progress: number; reward: number; completed: boolean; claimed: boolean;
  /** "best" missions track the best single-run value, others accumulate across runs */
  mode: "sum" | "best";
}

interface Template { key: string; title: string; kind: MissionKind; target: number; reward: number; mode: "sum" | "best" }
const POOL: Template[] = [
  { key: "coins100", title: "Collect 100 Coins", kind: "coins", target: 100, reward: 150, mode: "sum" },
  { key: "coins250", title: "Collect 250 Coins", kind: "coins", target: 250, reward: 300, mode: "sum" },
  { key: "dist2k", title: "Run 2,000 m in total", kind: "distance", target: 2000, reward: 200, mode: "sum" },
  { key: "dist5k", title: "Run 5,000 m in total", kind: "distance", target: 5000, reward: 450, mode: "sum" },
  { key: "combo12", title: "Reach a x12 combo", kind: "combo", target: 12, reward: 200, mode: "best" },
  { key: "combo30", title: "Reach a x30 combo", kind: "combo", target: 30, reward: 400, mode: "best" },
  { key: "jumps40", title: "Jump 40 times", kind: "jumps", target: 40, reward: 150, mode: "sum" },
  { key: "slides30", title: "Slide 30 times", kind: "slides", target: 30, reward: 150, mode: "sum" },
  { key: "adv10", title: "Perform 10 advanced moves", kind: "advanced", target: 10, reward: 350, mode: "sum" },
  { key: "pu6", title: "Collect 6 power-ups", kind: "powerups", target: 6, reward: 250, mode: "sum" },
  { key: "near15", title: "15 near misses", kind: "nearmiss", target: 15, reward: 250, mode: "sum" },
  { key: "events4", title: "Survive 4 world events", kind: "events", target: 4, reward: 300, mode: "sum" },
  { key: "regions3", title: "Reach 3 different regions", kind: "regions", target: 3, reward: 400, mode: "best" },
  { key: "score10k", title: "Score 10,000 in one run", kind: "score", target: 10000, reward: 350, mode: "best" },
];

const KEY = "nexus_runner_missions_v2";

export class MissionManager {
  private missions: Mission[] = [];
  private storage: Storage | null;
  private counter = 0;
  /** missions completed during the current run (for results screen) */
  completedThisRun: Mission[] = [];
  onComplete: ((m: Mission) => void) | null = null;

  constructor(storage?: Storage | null) {
    this.storage = storage !== undefined ? storage : (typeof localStorage !== "undefined" ? localStorage : null);
    this.load();
    this.ensureSlots();
  }

  private fromTemplate(t: Template): Mission {
    return { id: `${t.key}_${++this.counter}_${Date.now() % 100000}`, title: t.title, kind: t.kind, target: t.target, progress: 0, reward: t.reward, completed: false, claimed: false, mode: t.mode };
  }

  private ensureSlots() {
    const active = this.missions.filter((m) => !m.claimed);
    const usedKinds = new Set(active.map((m) => m.kind));
    const rng = makeRng(`missions:${this.counter}:${Date.now() % 9973}`);
    let guard = 0;
    while (active.length < 3 && guard++ < 50) {
      const t = rng.pick(POOL);
      if (usedKinds.has(t.kind)) continue;
      const m = this.fromTemplate(t);
      active.push(m); usedKinds.add(t.kind);
    }
    this.missions = active;
    this.save();
  }

  /** AUVYRR / design hook: replace the last incomplete mission slot with a template by key. */
  requestTemplate(key: string): boolean {
    const t = POOL.find((x) => x.key === key);
    if (!t) return false;
    if (this.missions.some((m) => m.kind === t.kind && !m.completed)) return true; // already active
    const idx = [...this.missions.keys()].reverse().find((i) => !this.missions[i].completed);
    if (idx === undefined) return false;
    this.missions[idx] = this.fromTemplate(t);
    this.save();
    return true;
  }

  /** Called at the start of each run. Per-run "best" missions reset their per-run baseline. */
  resetRun() {
    this.completedThisRun = [];
    for (const m of this.missions) if (m.mode === "best" && !m.completed) m.progress = 0;
  }

  add(kind: MissionKind, amount = 1) {
    for (const m of this.missions) {
      if (m.completed || m.kind !== kind) continue;
      m.progress = m.mode === "best" ? Math.max(m.progress, Math.min(m.target, amount)) : Math.min(m.target, m.progress + amount);
      this.check(m);
    }
  }
  setBest(kind: MissionKind, value: number) {
    for (const m of this.missions) {
      if (m.completed || m.kind !== kind) continue;
      m.progress = Math.max(m.progress, Math.min(m.target, value));
      this.check(m);
    }
  }
  setCombo(combo: number) { this.setBest("combo", combo); }

  private check(m: Mission) {
    if (!m.completed && m.progress >= m.target) {
      m.completed = true;
      this.completedThisRun.push(m);
      this.onComplete?.(m);
      this.save();
    }
  }

  getActive(): Mission[] { return this.missions.map((m) => ({ ...m })); }
  getCurrent(): Mission | null { return this.missions.find((m) => !m.completed) ? { ...this.missions.find((m) => !m.completed)! } : null; }
  getCompletedCount() { return this.missions.filter((m) => m.completed).length; }

  /** Pays out completed missions and replaces them. @returns coins earned */
  claimCompletedRewards(): number {
    let total = 0;
    for (const m of this.missions) if (m.completed && !m.claimed) { m.claimed = true; total += m.reward; }
    this.ensureSlots();
    return total;
  }

  /** Discard all missions and draw a fresh set (used by Reset Progress). */
  resetAll() { this.missions = []; this.completedThisRun = []; this.ensureSlots(); }

  /** Persist progress (call at end of run). */
  flush() { this.save(); }

  private save() { try { this.storage?.setItem(KEY, JSON.stringify({ missions: this.missions, counter: this.counter })); } catch { /* ignore */ } }
  private load() {
    try {
      const raw = this.storage?.getItem(KEY);
      if (!raw) return;
      const d = JSON.parse(raw);
      if (Array.isArray(d.missions)) this.missions = d.missions.filter((m: any) => m && typeof m.target === "number" && typeof m.kind === "string");
      this.counter = Number(d.counter) || 0;
    } catch { this.missions = []; }
  }
}
