/**
 * ProgressionManager — persistent multi-layer progression (versioned localStorage save).
 * Tracks: high score, distances, coin bank, character unlocks, ability unlocks, region discovery,
 * per-region records, upgrades, settings. Never throws on missing/corrupt storage.
 */
import { ProgressionState } from "../auvyrr/types.js";
import { ABILITY_UNLOCKS, CHARACTERS, CHARACTER_IDS, REGIONS, UPGRADES, QualityTier } from "../data/GameData.js";
import type { AbilityUnlocks } from "../movement/Player.js";

export interface RunRecord {
  score: number; distance: number; time: number; maxCombo: number; characterId: string; coins: number;
  regionsReached: number[]; missionsCompleted: number;
}

export interface RunOutcome {
  newHighScore: boolean; newBestDistance: boolean; coinsEarned: number;
  newAbilities: string[]; newRegions: string[]; characterUnlockable: string[];
}

export interface Settings { quality: QualityTier | "AUTO"; muted: boolean; music: boolean; sfxVolume: number; vibration: boolean; showFps: boolean }
const DEFAULT_SETTINGS: Settings = { quality: "AUTO", muted: false, music: true, sfxVolume: 0.8, vibration: true, showFps: false };

const KEY = "nexus_runner_progress_v2";
const SAVE_VERSION = 2;

interface SaveData {
  version: number;
  highScore: number; bestDistance: number; maxCombo: number; totalDistance: number; totalCoinsEver: number; runsCompleted: number;
  bank: number; unlockedCharacters: string[]; regionsDiscovered: number[]; regionBest: Record<string, { distance: number; score: number }>;
  upgrades: Record<string, number>; mastery: Record<string, number>; selectedCharacter: string; settings: Settings;
  characterBest: Record<string, number>; storyFlags: Record<string, boolean>;
}

function freshData(): SaveData {
  return {
    version: SAVE_VERSION, highScore: 0, bestDistance: 0, maxCombo: 0, totalDistance: 0, totalCoinsEver: 0, runsCompleted: 0, bank: 0,
    unlockedCharacters: ["runner"], regionsDiscovered: [0], regionBest: {}, upgrades: {}, mastery: { movement: 0, wallRun: 0, railGrind: 0, exploration: 0 },
    selectedCharacter: "runner", settings: { ...DEFAULT_SETTINGS }, characterBest: {}, storyFlags: {},
  };
}

export class ProgressionManager {
  data: SaveData = freshData();
  private storage: Storage | null;

  constructor(storage?: Storage | null) {
    this.storage = storage !== undefined ? storage : (typeof localStorage !== "undefined" ? localStorage : null);
  }

  // ── Queries ──
  getHighScore() { return this.data.highScore; }
  getBestDistance() { return this.data.bestDistance; }
  getBank() { return this.data.bank; }
  get settings(): Settings { return this.data.settings; }
  get selectedCharacter(): string { return this.data.selectedCharacter; }
  isCharacterUnlocked(id: string) { return this.data.unlockedCharacters.includes(id); }
  isRegionDiscovered(index: number) { return this.data.regionsDiscovered.includes(index); }
  getUpgradeLevel(id: string) { return this.data.upgrades[id] ?? 0; }

  getAbilityUnlocks(): AbilityUnlocks {
    const has = (id: string) => this.data.highScore >= (ABILITY_UNLOCKS.find((a) => a.id === id)?.score ?? Infinity);
    return { airDash: has("airDash"), wallRun: has("wallRun"), railGrind: has("railGrind"), grapple: has("grapple") };
  }
  getUnlockedAbilityIds(): string[] {
    const a = this.getAbilityUnlocks();
    return ["jump", "slide", ...Object.entries(a).filter(([, v]) => v).map(([k]) => k)];
  }

  // ── Mutations ──
  setSelectedCharacter(id: string) { if (this.isCharacterUnlocked(id)) { this.data.selectedCharacter = id; this.save(); return true; } return false; }

  buyCharacter(id: string): { ok: boolean; reason?: string } {
    const def = (CHARACTERS as any)[id]; if (!def) return { ok: false, reason: "Unknown character" };
    if (this.isCharacterUnlocked(id)) return { ok: false, reason: "Already unlocked" };
    if (this.data.bank < def.unlockCost) return { ok: false, reason: `Need ${def.unlockCost - this.data.bank} more coins` };
    this.data.bank -= def.unlockCost; this.data.unlockedCharacters.push(id); this.save();
    return { ok: true };
  }

  buyUpgrade(id: string): { ok: boolean; reason?: string } {
    const u = UPGRADES[id]; if (!u) return { ok: false, reason: "Unknown upgrade" };
    const lvl = this.getUpgradeLevel(id);
    if (lvl >= u.max) return { ok: false, reason: "Max level" };
    const cost = u.cost(lvl);
    if (this.data.bank < cost) return { ok: false, reason: `Need ${cost - this.data.bank} more coins` };
    this.data.bank -= cost; this.data.upgrades[id] = lvl + 1; this.save();
    return { ok: true };
  }

  addCoins(n: number) { this.data.bank += Math.max(0, Math.floor(n)); this.save(); }
  markRegionDiscovered(index: number) { if (!this.data.regionsDiscovered.includes(index)) { this.data.regionsDiscovered.push(index); this.data.regionsDiscovered.sort(); this.save(); return true; } return false; }
  updateSettings(patch: Partial<Settings>) { this.data.settings = { ...this.data.settings, ...patch }; this.save(); }
  grantAll() { this.data.unlockedCharacters = [...CHARACTER_IDS]; this.data.regionsDiscovered = REGIONS.map((r) => r.index); this.data.highScore = Math.max(this.data.highScore, 25000); this.save(); }

  recordRun(rec: RunRecord): RunOutcome {
    const d = this.data;
    const before = new Set(this.getUnlockedAbilityIds());
    const outcome: RunOutcome = { newHighScore: rec.score > d.highScore, newBestDistance: rec.distance > d.bestDistance, coinsEarned: rec.coins, newAbilities: [], newRegions: [], characterUnlockable: [] };
    d.runsCompleted++;
    d.totalDistance += rec.distance;
    d.totalCoinsEver += rec.coins;
    d.bank += rec.coins;
    d.maxCombo = Math.max(d.maxCombo, rec.maxCombo);
    if (outcome.newHighScore) d.highScore = Math.floor(rec.score);
    if (outcome.newBestDistance) d.bestDistance = Math.floor(rec.distance);
    d.characterBest[rec.characterId] = Math.max(d.characterBest[rec.characterId] ?? 0, Math.floor(rec.score));
    for (const idx of rec.regionsReached) {
      const ri = idx % REGIONS.length;
      if (this.markRegionDiscovered(ri)) outcome.newRegions.push(REGIONS[ri].name);
      const id = REGIONS[ri].id;
      const prev = d.regionBest[id] ?? { distance: 0, score: 0 };
      d.regionBest[id] = { distance: Math.max(prev.distance, Math.floor(rec.distance)), score: Math.max(prev.score, Math.floor(rec.score)) };
    }
    d.mastery.movement = Math.min(100, d.mastery.movement + Math.floor(rec.distance / 500));
    d.mastery.exploration = Math.min(100, d.regionsDiscovered.length * 20);
    for (const a of this.getUnlockedAbilityIds()) if (!before.has(a)) outcome.newAbilities.push(ABILITY_UNLOCKS.find((x) => x.id === a)?.name ?? a);
    for (const id of CHARACTER_IDS) { const def = CHARACTERS[id]; if (!this.isCharacterUnlocked(id) && d.bank >= def.unlockCost) outcome.characterUnlockable.push(def.name); }
    this.save();
    return outcome;
  }

  getState(): ProgressionState {
    return {
      unlockedCharacters: [...this.data.unlockedCharacters],
      unlockedAbilities: this.getUnlockedAbilityIds(),
      equipmentInventory: Object.entries(this.data.upgrades).filter(([, v]) => v > 0).map(([k, v]) => `${k}:${v}`),
      mastery: { ...this.data.mastery },
      activeMissions: [],
      discoveries: this.data.regionsDiscovered.map((i) => REGIONS[i].id),
      storyFlags: { ...this.data.storyFlags },
    };
  }

  // ── Persistence ──
  save() {
    if (!this.storage) return;
    try { this.storage.setItem(KEY, JSON.stringify(this.data)); } catch { /* quota / private mode */ }
  }

  load() {
    if (!this.storage) return;
    try {
      let raw = this.storage.getItem(KEY);
      if (!raw) { this.migrateV1(); return; }
      const parsed = JSON.parse(raw);
      const base = freshData();
      this.data = {
        ...base, ...parsed, version: SAVE_VERSION,
        settings: { ...base.settings, ...(parsed.settings ?? {}) },
        mastery: { ...base.mastery, ...(parsed.mastery ?? {}) },
        unlockedCharacters: Array.isArray(parsed.unlockedCharacters) && parsed.unlockedCharacters.includes("runner") ? parsed.unlockedCharacters.filter((c: string) => c in CHARACTERS) : ["runner"],
        regionsDiscovered: Array.isArray(parsed.regionsDiscovered) ? parsed.regionsDiscovered.filter((n: any) => Number.isInteger(n) && n >= 0 && n < REGIONS.length) : [0],
      };
      if (!this.data.regionsDiscovered.includes(0)) this.data.regionsDiscovered.unshift(0);
      for (const k of ["highScore", "bestDistance", "bank", "maxCombo", "totalDistance", "runsCompleted", "totalCoinsEver"] as const) if (!Number.isFinite((this.data as any)[k])) (this.data as any)[k] = 0;
    } catch { this.data = freshData(); }
  }

  /** Import the old v1 save format so players don't lose progress after the update. */
  private migrateV1() {
    try {
      const raw = this.storage?.getItem("nexus_runner_progress");
      if (!raw) return;
      const old = JSON.parse(raw);
      this.data.highScore = Number(old.highScore) || 0;
      this.data.totalDistance = Number(old.totalDistance) || 0;
      this.data.runsCompleted = Number(old.runsCompleted) || 0;
      this.save();
    } catch { /* ignore */ }
  }

  reset() { this.data = freshData(); this.save(); }
}
