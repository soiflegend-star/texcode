/**
 * ChunkPlan — deterministic, seeded description of every scenery chunk.
 * The renderer builds visuals from the plan; the generator never needs to know about meshes.
 * Guarantees: same seed → same plan; no identical variant twice in a row; no identical landmark twice in a row.
 */
import { CHUNK_LENGTH, REGIONS, REGION_LENGTH, TRANSITION_LENGTH, RegionDef } from "../data/GameData.js";
import { hashString, makeRng } from "../util/rng.js";

export const VARIANTS_PER_REGION = 5;

export interface ChunkPlan {
  index: number;
  startDist: number;
  endDist: number;
  segment: number;        // un-wrapped region segment index
  region: RegionDef;
  nextRegion: RegionDef;
  kind: "start" | "normal" | "transition";
  variant: number;        // 0..VARIANTS_PER_REGION-1
  mirror: boolean;
  landmark: string | null;
  decorSeed: number;
  /** 0..1 progress through this region (used for gradual colour/landmark build-up) */
  regionProgress: number;
}

const cache = new Map<string, ChunkPlan>();

export function chunkIndexAt(dist: number) { return Math.floor(Math.max(0, dist) / CHUNK_LENGTH); }

export function getChunkPlan(seed: string, index: number): ChunkPlan {
  const key = seed + "|" + index;
  const hit = cache.get(key);
  if (hit) return hit;
  if (cache.size > 4000) cache.clear();

  const startDist = index * CHUNK_LENGTH;
  const segment = Math.floor(startDist / REGION_LENGTH);
  const region = REGIONS[segment % REGIONS.length];
  const nextRegion = REGIONS[(segment + 1) % REGIONS.length];
  const into = startDist - segment * REGION_LENGTH;
  const kind: ChunkPlan["kind"] = index === 0 ? "start" : into >= REGION_LENGTH - TRANSITION_LENGTH - 0.001 ? "transition" : "normal";

  const rng = makeRng(hashString(seed) ^ Math.imul(index + 1, 0x9e3779b1) ^ (region.index * 7919));
  let variant = rng.int(0, VARIANTS_PER_REGION - 1);
  let landmark: string | null = null;
  if (index > 0) {
    const prev = getChunkPlan(seed, index - 1);
    if (prev.region.id === region.id && prev.variant === variant) variant = (variant + 1 + rng.int(0, VARIANTS_PER_REGION - 2)) % VARIANTS_PER_REGION;
    if (kind === "normal" && index % 3 === 1 && rng.chance(0.85)) {
      const options = region.landmarks.filter((l) => l !== prev.landmark && l !== (index > 1 ? getChunkPlan(seed, index - 2).landmark : null) && l !== (index > 3 ? getChunkPlan(seed, index - 3).landmark : null));
      landmark = (options.length ? rng.pick(options) : rng.pick(region.landmarks));
    }
  }
  const plan: ChunkPlan = {
    index, startDist, endDist: startDist + CHUNK_LENGTH, segment, region, nextRegion, kind, variant,
    mirror: rng.chance(0.5), landmark, decorSeed: rng.int(1, 2 ** 30), regionProgress: into / REGION_LENGTH,
  };
  cache.set(key, plan);
  return plan;
}
