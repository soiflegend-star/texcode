/**
 * WorldGenerator — seeded, fairness-validated obstacle / collectible generation.
 *
 * Rows of obstacles are generated against a running "safe lane" model (Solvability.ts),
 * so every emitted route is beatable by construction. Collectible trails follow a safe
 * path through the rows. Scenery is described separately by ChunkPlan (renderer-side).
 */
import { Player } from "../movement/Player.js";
import { RouteOption, HazardInfo, EnemyInfo, RewardInfo } from "../auvyrr/types.js";
import {
  LANE_WIDTH, OBSTACLES, ObstacleDef, REGIONS, REGION_LENGTH, TRANSITION_LENGTH, RegionDef, regionAtDistance,
  regionSegment, POWERUPS, PowerUpId, POWERUP_IDS,
} from "../data/GameData.js";
import { makeRng, Rng, clamp } from "../util/rng.js";
import { CellKind, RowModel, applyRow, expandSafe, passable, MIN_GAP_SECONDS } from "./Solvability.js";

export interface Obstacle {
  id: string; type: string; kind: "jump" | "slide" | "block";
  x: number; y: number; z: number; width: number; height: number; depth: number;
  damage: number; lane: number; vz: number;
  wobble: number; phase: number; baseX: number;
  fall: null | { triggerZ: number; height: number; time: number; state: 0 | 1 | 2; t: number; groundY: number };
  hit: boolean; nearMissed: boolean; broken: boolean; rowId: number; age: number;
}

export type CollectibleType = "coin" | PowerUpId | "rail" | "pad";
export interface Collectible {
  id: string; type: CollectibleType;
  x: number; y: number; z: number; width: number; height: number; depth: number;
  value: number; lane: number; magnetized: boolean;
}

export interface EventFlags {
  coinRush?: boolean; trafficBias?: boolean; trainBias?: boolean; closure?: boolean; debris?: boolean; drones?: boolean;
}
export interface WorldFeatures { rail: boolean }

export interface WorldUpdateCtx {
  distance: number; speed: number; player: Player; flags?: EventFlags; features?: WorldFeatures; magnet?: boolean; difficulty?: number;
}

const SPAWN_HORIZON = 175;
const CULL_Z = -14;
const START_GRACE = 55;   // metres before first obstacle

export class WorldGenerator {
  currentRegionId: string = REGIONS[0].id;
  currentBiomeId: string = REGIONS[0].id;
  currentChunkIndex = 0;
  regionSegment = 0;
  environmentFlags: Record<string, boolean | number> = {};
  /** debug log of every emitted row (used by tests) */
  rowLog: Array<{ rowId: number; absStart: number; absEnd: number; cells: CellKind[]; speed: number; region: string }> | null = null;

  private obstacles: Obstacle[] = [];
  private collectibles: Collectible[] = [];
  private seed = "";
  private rng: Rng = makeRng("init");
  private cursor = START_GRACE;          // relative z of next segment start
  private safe = new Set<number>([0]);
  private pathLane = 0;
  private lastRowEnd = -999;             // relative z of last row end (for gap calc)
  private lastRowSpeed = 14;
  private segIndex = 0;
  private rowCounter = 0;
  private idCounter = 0;
  private recentTypes: string[] = [];
  private recentPatterns: string[] = [];
  private lastPowerupSeg = -10;
  private time = 0;
  private lastDistance = 0;
  onRegionChanged: ((region: RegionDef, segment: number) => void) | null = null;
  onObstacleImpact: ((o: Obstacle) => void) | null = null;

  reset(seed: string) {
    this.seed = seed;
    this.rng = makeRng(seed);
    this.obstacles = []; this.collectibles = [];
    this.cursor = START_GRACE;
    this.safe = new Set([0]);
    this.pathLane = 0;
    this.lastRowEnd = -999;
    this.currentChunkIndex = 0;
    this.regionSegment = 0;
    this.currentRegionId = REGIONS[0].id;
    this.currentBiomeId = REGIONS[0].id;
    this.recentTypes = []; this.recentPatterns = [];
    this.segIndex = 0; this.rowCounter = 0; this.idCounter = 0; this.lastPowerupSeg = -10;
    this.environmentFlags = {};
    this.time = 0; this.lastDistance = 0;
    if (this.rowLog) this.rowLog = [];
  }

  getSeed() { return this.seed; }
  enableRowLog() { this.rowLog = []; }

  /** Jump straight to a region segment start (debug / QA / AUVYRR training scenarios). */
  jumpToDistance(distance: number) {
    this.obstacles = []; this.collectibles = [];
    this.cursor = 40; this.safe = new Set([0]); this.lastRowEnd = -999;
    this.lastDistance = distance;
  }

  update(dt: number, ctx: WorldUpdateCtx) {
    this.time += dt;
    const { distance, speed } = ctx;
    this.lastDistance = distance;
    const move = speed * dt;

    // Scroll
    for (const o of this.obstacles) {
      o.z -= (speed + o.vz) * dt;
      o.age += dt;
      if (o.wobble > 0) o.x = o.baseX + Math.sin(o.age * 2.2 + o.phase) * o.wobble;
      if (o.fall) this.updateFall(o, dt);
    }
    for (const c of this.collectibles) {
      c.z -= move;
      if (ctx.magnet && c.type === "coin" && c.z > -2 && c.z < 11 && Math.abs(c.x - ctx.player.x) < 7.5) {
        c.magnetized = true;
      }
      if (c.magnetized) {
        const k = Math.min(1, dt * 11);
        c.x += (ctx.player.x - c.x) * k;
        c.y += (ctx.player.y + 0.9 - c.y) * k;
        c.z += (ctx.player.z - c.z) * k * 0.9;
      }
    }

    this.lastRowEnd -= move;

    // Cull
    this.obstacles = this.obstacles.filter((o) => o.z + o.depth / 2 > CULL_Z && !o.broken);
    this.collectibles = this.collectibles.filter((c) => c.z > CULL_Z);

    // Spawn ahead
    this.cursor -= move;
    let guard = 0;
    while (this.cursor < SPAWN_HORIZON && guard++ < 24) this.spawnSegment(ctx);

    // Region tracking
    const seg = regionSegment(distance);
    this.currentChunkIndex = Math.floor(distance / 60);
    if (seg !== this.regionSegment) {
      this.regionSegment = seg;
      const reg = regionAtDistance(distance);
      this.currentRegionId = reg.id; this.currentBiomeId = reg.id;
      this.onRegionChanged?.(reg, seg);
    }
  }

  private updateFall(o: Obstacle, dt: number) {
    const f = o.fall!;
    if (f.state === 0 && o.z <= f.triggerZ) f.state = 1;
    if (f.state === 1) {
      f.t += dt;
      const k = clamp(f.t / f.time, 0, 1);
      o.y = f.groundY + (1 - k * k) * f.height;
      if (k >= 1) { f.state = 2; o.y = f.groundY; this.onObstacleImpact?.(o); }
    }
  }

  // ───────────────────────── Difficulty ─────────────────────────
  /** 0..1 difficulty at an absolute distance (also slowly increases with each region loop). */
  difficultyAt(dist: number, override?: number): number {
    if (override !== undefined) return override;
    const loop = Math.floor(regionSegment(dist) / REGIONS.length);
    return clamp(dist / 3600 + loop * 0.18, 0, 1);
  }

  /** Base cruising speed for a distance (used for spawn spacing; Game uses the same curve). */
  static speedAt(dist: number): number { return 14 + Math.min(14, dist / 260); }

  // ───────────────────────── Segment spawning ─────────────────────────
  private spawnSegment(ctx: WorldUpdateCtx) {
    const absStart = this.lastDistance + this.cursor;
    const region = regionAtDistance(absStart);
    const into = ((absStart % REGION_LENGTH) + REGION_LENGTH) % REGION_LENGTH;
    const diff = this.difficultyAt(absStart, ctx.difficulty);
    const flags = ctx.flags ?? {};
    const rng = this.rng;
    const speed = Math.min(WorldGenerator.speedAt(absStart) * 1.0, 38);
    this.segIndex++;

    // Transition pieces and region arrival are obstacle-light travel stretches (coins only).
    const inTransitionZone = into >= REGION_LENGTH - TRANSITION_LENGTH - 20;
    const arrival = into < 30 && absStart > REGION_LENGTH * 0.5;
    if (inTransitionZone || arrival) {
      this.spawnCoinTrail(this.cursor, this.cursor + 22, this.pathLane, this.pathLane);
      this.cursor += 26;
      return;
    }

    // Pattern selection
    const pattern = this.pickPattern(diff, flags);
    this.recentPatterns.push(pattern); if (this.recentPatterns.length > 4) this.recentPatterns.shift();

    // Time gap (seconds) between rows narrows slightly with difficulty
    const gapTime = (1.55 - diff * 0.5) * (flags.coinRush ? 1 : 1);
    const rows = this.buildPattern(pattern, region, diff, flags, speed);
    const prevPath = this.pathLane;
    const pathPerRow: number[] = [];
    let curZ = this.cursor;
    let prevEnd = this.lastRowEnd > -900 ? this.lastRowEnd : curZ - speed * 2;
    const spawned: Array<{ z: number; depth: number; cells: CellKind[]; lane: number }> = [];
    let rowCount = 0;

    for (const row of rows) {
      const depthEff = row.depthEff;
      // enforce time gap vs previous row
      const minGapM = Math.max(MIN_GAP_SECONDS * speed + 0.5, gapTime * speed * (rowCount === 0 ? 1 : row.tight ? 0.72 : 1));
      const startZ = Math.max(curZ, prevEnd + minGapM);
      const centre = startZ + depthEff / 2;
      const gapS = (startZ - prevEnd) / speed;

      // keep the physical transition piece and the arrival stretch free of obstacles
      const absC = absStart + (centre - this.cursor);
      const intoC = ((absC % REGION_LENGTH) + REGION_LENGTH) % REGION_LENGTH;
      if (intoC >= REGION_LENGTH - TRANSITION_LENGTH - 20) break;

      const model: RowModel = { z: centre, depth: depthEff, speed, cells: row.cells.map((c) => (c ? c.kind : "none")) as [CellKind, CellKind, CellKind] };
      const nextSafe = applyRow(this.safe, model, gapS / 1.35); // worst-case speed surge / Speedster factor
      if (nextSafe.size === 0) continue; // generator refuses an unbeatable row (should be pre-filtered by buildPattern)
      this.safe = nextSafe;
      this.emitRow(row, centre, speed, absStart + (centre - this.cursor));
      // choose path lane: closest safe lane to previous path
      const lane = [...this.safe].sort((a, b) => Math.abs(a - this.pathLane) - Math.abs(b - this.pathLane) || (rng() < 0.5 ? -1 : 1))[0];
      pathPerRow.push(lane);
      spawned.push({ z: centre, depth: depthEff, cells: model.cells, lane });
      this.pathLane = lane;
      prevEnd = startZ + depthEff;
      curZ = prevEnd;
      rowCount++;
    }
    this.lastRowEnd = prevEnd; this.lastRowSpeed = speed;

    // Collectibles: follow the safe path
    let z0 = this.cursor + 2;
    let laneFrom = prevPath;
    for (let i = 0; i < spawned.length; i++) {
      const r = spawned[i];
      const zEnd = r.z - r.depth / 2 - 1.5;
      if (zEnd - z0 > 4) this.spawnCoinTrail(z0, zEnd, laneFrom, r.lane, flags.coinRush);
      // arc over jump obstacles on the path lane
      const cell = r.cells[r.lane + 1];
      if (cell === "jump") this.spawnCoinArc(r.z - 1.8, r.z + 1.8, r.lane);
      else if (cell === "slide") this.spawnCoinLine(r.z - 2, r.z + 2, r.lane, 0.55, 3);
      z0 = r.z + r.depth / 2 + 1.5; laneFrom = r.lane;
    }
    // tail after last row
    const tailEnd = Math.min(curZ + speed * gapTime * 0.8, z0 + 26);
    if (tailEnd - z0 > 4) this.spawnCoinTrail(z0, tailEnd, laneFrom, laneFrom, flags.coinRush);

    // Power-up / rail
    this.maybeSpawnPowerup(z0 + 2, laneFrom, ctx, diff);
    if (ctx.features?.rail && rng() < 0.07 && spawned.length === 0) {
      this.collectibles.push({ id: this.nid("rail"), type: "rail", x: laneFrom * LANE_WIDTH, y: 0.3, z: z0 + 6, width: 1.0, height: 0.5, depth: 8, value: 40, lane: laneFrom, magnetized: false });
    }

    // Boost pad (blue chevrons): harmless floor pad that gives a short speed burst
    if (spawned.length === 0 && !flags.coinRush && rng() < 0.06) {
      this.collectibles.push({ id: this.nid("pad"), type: "pad", x: laneFrom * LANE_WIDTH, y: 0.02, z: z0 + 12, width: 1.8, height: 0.1, depth: 2.6, value: 25, lane: laneFrom, magnetized: false });
    }

    this.cursor = Math.max(curZ, this.cursor + 6) + speed * (0.35 + rng() * 0.3);
  }

  // ───────────────────────── Patterns ─────────────────────────
  private pickPattern(diff: number, flags: EventFlags): string {
    const rng = this.rng;
    const tier = diff < 0.22 ? 0 : diff < 0.6 ? 1 : 2;
    const table: Array<[string, number, number]> = [
      // [name, minTier, weight]
      ["single", 0, 5], ["pair", 0, 3], ["gate", 0, 2],
      ["slalom", 1, 3], ["mix", 1, 3], ["blockrun", 1, 2], ["actions", 1, 2],
      ["dense", 2, 3], ["wallgap", 2, 2], ["chain", 2, 2],
    ];
    const weights = table.filter((t) => t[1] <= tier).map((t) => {
      let w = t[2];
      if (this.recentPatterns.includes(t[0])) w *= 0.25;
      if (flags.closure && (t[0] === "pair" || t[0] === "wallgap")) w *= 5;
      if (flags.trainBias && t[0] === "blockrun") w *= 6;
      return [t[0], w] as [string, number];
    });
    let sum = 0; for (const w of weights) sum += w[1];
    let r = rng() * sum;
    for (const [n, w] of weights) { r -= w; if (r <= 0) return n; }
    return "single";
  }

  private pickType(region: RegionDef, tierMax: number, filter: (d: ObstacleDef) => boolean, flags: EventFlags, preferTag?: string): ObstacleDef {
    const rng = this.rng;
    let set = region.obstacleSet.map((id) => OBSTACLES[id]).filter((d) => d && d.tier <= tierMax && filter(d));
    if (flags.drones && filter(OBSTACLES.drone)) set = set.concat(OBSTACLES.drone, OBSTACLES.drone, OBSTACLES.drone);
    if (flags.debris && filter(OBSTACLES.falling_debris)) set = set.concat(OBSTACLES.falling_debris, OBSTACLES.falling_debris, OBSTACLES.falling_debris);
    if (flags.trafficBias) set = set.concat(set.filter((d) => d.tags.includes("vehicle")), set.filter((d) => d.tags.includes("vehicle")));
    if (flags.trainBias) set = set.concat(set.filter((d) => d.tags.includes("train")), set.filter((d) => d.tags.includes("train")));
    if (preferTag) { const pref = set.filter((d) => d.tags.includes(preferTag)); if (pref.length) set = pref; }
    if (set.length === 0) set = [OBSTACLES.barricade];
    // anti repetition
    for (let i = 0; i < 4; i++) {
      const d = set[Math.floor(rng() * set.length)];
      if (!this.recentTypes.includes(d.id) || i === 3) {
        this.recentTypes.push(d.id); if (this.recentTypes.length > 7) this.recentTypes.shift();
        return d;
      }
    }
    return set[0];
  }

  private buildPattern(pattern: string, region: RegionDef, diff: number, flags: EventFlags, speed: number): Array<{ cells: (ObstacleDef | null)[]; depthEff: number; tight?: boolean }> {
    const rng = this.rng;
    const tierMax = diff < 0.22 ? 0 : diff < 0.6 ? 1 : 2;
    const rows: Array<{ cells: (ObstacleDef | null)[]; depthEff: number; tight?: boolean }> = [];
    const eff = (cells: (ObstacleDef | null)[]) => Math.max(0.8, ...cells.map((c) => (c ? (c.vz ? this.depthFor(c) * speed / (speed + c.vz) : this.depthFor(c)) : 0)));
    const isAny = () => true;
    const mk = (cells: (ObstacleDef | null)[], tight = false) => { rows.push({ cells, depthEff: eff(cells), tight }); };
    // Ensure at least one non-block lane inside the reachable set: choose free lane(s) from expand(safe)
    const reach = expandSafe(this.safe, 1);
    const reachArr = [...reach];
    const freeLane = () => reachArr[Math.floor(rng() * reachArr.length)];
    const none: (ObstacleDef | null)[] = [null, null, null];

    switch (pattern) {
      case "single": {
        const lane = rng.int(-1, 1);
        const c = [...none]; c[lane + 1] = this.pickType(region, tierMax, isAny, flags);
        mk(c); break;
      }
      case "pair": {
        const free = freeLane();
        const c = [...none];
        for (let l = -1; l <= 1; l++) if (l !== free) c[l + 1] = this.pickType(region, tierMax, (d) => !d.fullWidth, flags);
        mk(c); break;
      }
      case "gate": {
        // full-width overhead gate (slide) or full-width low barrier line (jump)
        const full = region.obstacleSet.map((id) => OBSTACLES[id]).filter((d) => d.fullWidth);
        if (full.length && rng() < 0.7) { mk([rng.pick(full), null, null]); }
        else {
          const d = this.pickType(region, 0, (x) => x.kind === (rng() < 0.5 ? "jump" : "slide") && !x.fullWidth, flags);
          mk([d, d, d]);
        }
        break;
      }
      case "slalom": {
        let lane = freeLane();
        const n = rng.int(2, 3);
        for (let i = 0; i < n; i++) {
          const c = [...none];
          for (let l = -1; l <= 1; l++) if (l !== lane) c[l + 1] = this.pickType(region, tierMax, (d) => !d.fullWidth, flags);
          mk(c, i > 0);
          lane = clamp(lane + (lane === 0 ? (rng() < 0.5 ? -1 : 1) : -Math.sign(lane)), -1, 1);
        }
        break;
      }
      case "mix": {
        // one jump lane, one slide lane, one blocked lane
        const lanes = [-1, 0, 1].sort(() => rng() - 0.5);
        const c = [...none];
        c[lanes[0] + 1] = this.pickType(region, tierMax, (d) => d.kind === "jump", flags);
        c[lanes[1] + 1] = this.pickType(region, tierMax, (d) => d.kind === "slide" && !d.fullWidth, flags);
        c[lanes[2] + 1] = this.pickType(region, tierMax, (d) => d.kind === "block", flags);
        mk(c); break;
      }
      case "blockrun": {
        // a long block (train/truck/container) in one lane with small stuff in another
        const lane = freeLane();
        const long = this.pickType(region, tierMax, (d) => d.kind === "block" && d.d >= 3 && !d.fullWidth, flags, flags.trainBias ? "train" : undefined);
        const free = [-1, 0, 1].filter((l) => l !== lane);
        const keep = free[Math.floor(rng() * 2)];
        const c = [...none];
        c[lane + 1] = long;
        // block the second lane with long object too when late difficulty, always leaving `keep` free
        const other = free.find((l) => l !== keep)!;
        c[other + 1] = diff > 0.35 && rng() < 0.6 ? this.pickType(region, tierMax, (d) => !d.fullWidth, flags) : null;
        mk(c); break;
      }
      case "actions": {
        // jump row followed by slide row in the same lanes, with a free lane
        const free = freeLane();
        const a = [...none], b = [...none];
        for (let l = -1; l <= 1; l++) if (l !== free) { a[l + 1] = this.pickType(region, tierMax, (d) => d.kind === "jump", flags); b[l + 1] = this.pickType(region, tierMax, (d) => d.kind === "slide" && !d.fullWidth, flags); }
        mk(a); mk(b, false); break;
      }
      case "dense": {
        let lane = freeLane();
        for (let i = 0; i < 3; i++) {
          const c = [...none];
          for (let l = -1; l <= 1; l++) if (l !== lane) c[l + 1] = this.pickType(region, tierMax, (d) => !d.fullWidth && (d.kind !== "block" || rng() < 0.6), flags);
          mk(c, i > 0);
          lane = clamp(lane + rng.int(-1, 1), -1, 1);
        }
        break;
      }
      case "wallgap": {
        const free = freeLane();
        const c = [...none];
        for (let l = -1; l <= 1; l++) if (l !== free) c[l + 1] = this.pickType(region, tierMax, (d) => d.kind === "block" && !d.fullWidth, flags);
        mk(c);
        const c2 = [...none];
        c2[free + 1] = region.obstacleSet.includes("moving_barrier") ? OBSTACLES.moving_barrier : this.pickType(region, tierMax, (d) => d.kind !== "block", flags);
        mk(c2, true); // neighbouring lanes stay free so the row is passable
        break;
      }
      case "chain": {
        const n = rng.int(3, 4);
        let lane = freeLane();
        for (let i = 0; i < n; i++) {
          const c = [...none];
          const nextLane = clamp(lane + rng.int(-1, 1), -1, 1);
          for (let l = -1; l <= 1; l++) if (l !== nextLane) c[l + 1] = this.pickType(region, tierMax, (d) => !d.fullWidth, flags);
          mk(c, true);
          lane = nextLane;
        }
        break;
      }
    }
    return rows;
  }

  private depthFor(d: ObstacleDef): number {
    if (d.dRange) return this.rng.range(d.dRange[0], d.dRange[1]);
    return d.d;
  }

  private emitRow(row: { cells: (ObstacleDef | null)[]; depthEff: number }, centre: number, speed: number, absCentre: number) {
    const rowId = ++this.rowCounter;
    const cells: CellKind[] = [];
    for (let i = 0; i < 3; i++) {
      const def = row.cells[i];
      cells.push(def ? def.kind : "none");
      if (!def) continue;
      const lane = i - 1;
      const depth = def.dRange ? Math.max(def.dRange[0], Math.min(def.dRange[1], row.depthEff * (speed + (def.vz ?? 0)) / speed)) : def.d;
      const vz = def.vz ?? 0;
      // moving obstacles spawn further out so that they arrive at the row time
      const z = vz ? centre * (speed + vz) / speed : centre;
      const fullW = def.fullWidth;
      const x = fullW ? 0 : lane * LANE_WIDTH;
      const o: Obstacle = {
        id: this.nid("obs"), type: def.id, kind: def.kind, x, baseX: x, y: def.fall ? def.fall.height : def.y, z,
        width: def.w, height: def.h, depth, damage: def.damage, lane: fullW ? 0 : lane, vz,
        wobble: def.wobble ?? 0, phase: this.rng() * 6.28,
        fall: def.fall ? { triggerZ: def.fall.triggerZ, height: def.fall.height, time: def.fall.time, state: 0, t: 0, groundY: def.y } : null,
        hit: false, nearMissed: false, broken: false, rowId, age: 0,
      };
      this.obstacles.push(o);
      if (fullW) break; // one object spans all lanes
    }
    if (this.rowLog) {
      // log in absolute distance terms (static-equivalent occupancy)
      this.rowLog.push({ rowId, absStart: absCentre - row.depthEff / 2, absEnd: absCentre + row.depthEff / 2, cells: row.cells[0]?.fullWidth ? [row.cells[0].kind, row.cells[0].kind, row.cells[0].kind] : cells, speed, region: regionAtDistance(absCentre).id });
    }
  }

  // ───────────────────────── Collectibles ─────────────────────────
  private nid(p: string) { return `${p}_${++this.idCounter}`; }

  private pushCoin(x: number, y: number, z: number, lane: number, value = 1) {
    this.collectibles.push({ id: this.nid("coin"), type: "coin", x, y, z, width: 0.8, height: 0.8, depth: 0.8, value, lane, magnetized: false });
  }

  private spawnCoinTrail(z0: number, z1: number, laneA: number, laneB: number, rush = false) {
    const n = Math.max(2, Math.floor((z1 - z0) / 2.0));
    for (let i = 0; i < n; i++) {
      const t = n === 1 ? 0 : i / (n - 1);
      // switch lanes over the middle third
      const k = clamp((t - 0.35) / 0.3, 0, 1);
      const x = (laneA + (laneB - laneA) * k * k * (3 - 2 * k)) * LANE_WIDTH;
      this.pushCoin(x, 0.75, z0 + t * (z1 - z0), laneB);
      if (rush) {
        this.pushCoin(x - LANE_WIDTH, 0.75, z0 + t * (z1 - z0), laneB - 1);
        this.pushCoin(x + LANE_WIDTH, 0.75, z0 + t * (z1 - z0), laneB + 1);
      }
    }
  }
  private spawnCoinLine(z0: number, z1: number, lane: number, y: number, n: number) {
    for (let i = 0; i < n; i++) this.pushCoin(lane * LANE_WIDTH, y, z0 + (z1 - z0) * (i / Math.max(1, n - 1)), lane);
  }
  private spawnCoinArc(z0: number, z1: number, lane: number) {
    const n = 6;
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1);
      this.pushCoin(lane * LANE_WIDTH, 0.8 + Math.sin(t * Math.PI) * 1.6, z0 + (z1 - z0) * t, lane);
    }
  }

  private maybeSpawnPowerup(z: number, lane: number, ctx: WorldUpdateCtx, diff: number) {
    const rng = this.rng;
    if (this.segIndex - this.lastPowerupSeg < 5 || rng() > 0.2) return;
    let sum = 0; for (const id of POWERUP_IDS) sum += POWERUPS[id].weight;
    let r = rng() * sum, pick: PowerUpId = "shield";
    for (const id of POWERUP_IDS) { r -= POWERUPS[id].weight; if (r <= 0) { pick = id; break; } }
    this.lastPowerupSeg = this.segIndex;
    this.collectibles.push({ id: this.nid("pu"), type: pick, x: lane * LANE_WIDTH, y: 1.0, z, width: 1.0, height: 1.0, depth: 1.0, value: 0, lane, magnetized: false });
  }

  // ───────────────────────── Queries ─────────────────────────
  getObstacles(): readonly Obstacle[] { return this.obstacles; }
  getCollectibles(): readonly Collectible[] { return this.collectibles; }
  getNearbyObstacles(playerZ: number, range = 15) { return this.obstacles.filter((o) => Math.abs(o.z - playerZ) < range + o.depth / 2); }
  getNearbyCollectibles(playerZ: number, range = 15) { return this.collectibles.filter((c) => Math.abs(c.z - playerZ) < range + c.depth / 2); }
  removeCollectible(c: Collectible) { const i = this.collectibles.indexOf(c); if (i >= 0) this.collectibles.splice(i, 1); }
  removeObstacle(o: Obstacle) { o.broken = true; }
  /** Debug/test helper: inject a hand-authored obstacle. */
  injectObstacle(o: Partial<Obstacle> & { type: string; z: number; lane: number }) {
    const def = OBSTACLES[o.type];
    this.obstacles.push({
      id: this.nid("inj"), type: o.type, kind: def.kind, x: o.lane * LANE_WIDTH, baseX: o.lane * LANE_WIDTH, y: def.y, z: o.z, width: def.w, height: def.h, depth: def.d,
      damage: 1, lane: o.lane, vz: 0, wobble: 0, phase: 0, fall: null, hit: false, nearMissed: false, broken: false, rowId: -1, age: 0,
    });
  }

  /** The safe lanes for the next upcoming row (what an AI/bot should aim for). */
  getRecommendedLanes(playerZ = 0): number[] {
    const upcoming = this.obstacles.filter((o) => o.z > playerZ - o.depth / 2 && o.kind === "block").sort((a, b) => a.z - b.z);
    if (!upcoming.length) return [-1, 0, 1];
    const rowId = upcoming[0].rowId;
    const blocked = new Set(upcoming.filter((o) => o.rowId === rowId).map((o) => o.lane));
    const ok = [-1, 0, 1].filter((l) => !blocked.has(l));
    return ok.length ? ok : [0];
  }

  getRouteOptions(): RouteOption[] {
    const lanes = this.getRecommendedLanes();
    return [
      { id: "safe", riskLevel: "safe", rewardMultiplier: 1.0, description: `Lane${lanes.length > 1 ? "s" : ""} ${lanes.join(", ")} clear ahead` },
      { id: "risky", riskLevel: "risky", rewardMultiplier: 1.6, description: "Collect coin arcs over jump obstacles" },
      { id: "extreme", riskLevel: "extreme", rewardMultiplier: 2.4, requiredAbility: "wallRun", description: "Edge lanes with wall-run and rail grinds" },
    ];
  }

  getHazardInfos(): HazardInfo[] {
    return this.obstacles.filter((o) => o.z > -2).sort((a, b) => a.z - b.z).slice(0, 10).map((o) => ({ id: o.id, type: o.type, position: { x: o.x, y: o.y, z: o.z }, severity: o.damage }));
  }
  getEnemyInfos(): EnemyInfo[] {
    return this.obstacles.filter((o) => o.type === "drone" || o.type === "train").map((o) => ({ id: o.id, type: o.type, position: { x: o.x, y: o.y, z: o.z }, threatLevel: o.type === "train" ? 2 : 1 }));
  }
  getRewardInfos(): RewardInfo[] {
    return this.collectibles.filter((c) => c.z > 0).sort((a, b) => a.z - b.z).slice(0, 12).map((c) => ({ id: c.id, type: c.type, value: c.value, position: { x: c.x, y: c.y, z: c.z } }));
  }
}
