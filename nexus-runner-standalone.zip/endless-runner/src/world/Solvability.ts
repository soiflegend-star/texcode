/**
 * Solvability — conservative reachability model used by the generator at spawn
 * time AND by the test-suite to audit generated streams.
 *
 * Model: obstacles are grouped into "rows" (a z-slice of up to three lane cells).
 * A cell is passable if it is empty, or needs a jump/slide (always available).
 * A 'block' cell is impassable. The player may shift lanes between rows by up to
 * `maxShift(gapSeconds)` lanes. A route exists iff, after every row, the set of
 * reachable lanes is non-empty.
 */
export type CellKind = "none" | "jump" | "slide" | "block";
export interface RowModel { z: number; depth: number; cells: [CellKind, CellKind, CellKind]; speed: number }

/** How many lanes the player can shift in the time between rows (conservative). */
export function maxShift(gapSeconds: number): number {
  if (gapSeconds >= 0.95) return 2;
  if (gapSeconds >= 0.45) return 1;
  return 0;
}

export function expandSafe(safe: Set<number>, shift: number): Set<number> {
  const out = new Set<number>();
  for (const l of safe) for (let d = -shift; d <= shift; d++) { const n = l + d; if (n >= -1 && n <= 1) out.add(n); }
  return out;
}

export function passable(k: CellKind) { return k !== "block"; }

export function applyRow(safe: Set<number>, row: RowModel, gapSeconds: number): Set<number> {
  const reach = expandSafe(safe, maxShift(gapSeconds));
  const next = new Set<number>();
  for (const l of reach) if (passable(row.cells[l + 1])) next.add(l);
  return next;
}

/** Minimum time (s) between the end of one row and the start of the next. */
export const MIN_GAP_SECONDS = 0.85;
/** Seconds needed between two rows that both need an action in the same lane (jump ≈0.78s airtime). */
export const ACTION_RECOVERY_SECONDS = 0.7;

export interface ValidationReport { ok: boolean; rows: number; failures: string[]; minGapSeconds: number; maxBlockedLanes: number }

export function validateRows(rows: RowModel[]): ValidationReport {
  const failures: string[] = [];
  let safe = new Set<number>([-1, 0, 1]);
  let minGap = Infinity, maxBlocked = 0;
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const blocked = r.cells.filter((c) => c === "block").length;
    maxBlocked = Math.max(maxBlocked, blocked);
    if (blocked >= 3) failures.push(`row ${i}: all lanes blocked`);
    let gapS = 1.2;
    if (i > 0) {
      const p = rows[i - 1];
      const gapM = (r.z - r.depth / 2) - (p.z + p.depth / 2);
      gapS = gapM / Math.max(1, r.speed);
      minGap = Math.min(minGap, gapS);
      if (gapS < MIN_GAP_SECONDS - 0.02) failures.push(`row ${i}: gap ${gapS.toFixed(2)}s < ${MIN_GAP_SECONDS}s`);
    }
    safe = applyRow(safe, r, gapS);
    if (safe.size === 0) { failures.push(`row ${i}: no reachable passable lane`); safe = new Set([-1, 0, 1]); }
  }
  return { ok: failures.length === 0, rows: rows.length, failures, minGapSeconds: isFinite(minGap) ? minGap : 0, maxBlockedLanes: maxBlocked };
}
