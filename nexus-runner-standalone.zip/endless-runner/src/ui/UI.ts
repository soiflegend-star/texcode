/**
 * UI — HUD + all menu screens (DOM overlay). Reads the Game; writes only through public Game/Progression APIs.
 */
import type { Game, FxEvent } from "../core/Game.js";
import type { Scene3D } from "../core/Scene3D.js";
import { ABILITY_UNLOCKS, CHARACTERS, CHARACTER_IDS, EVENTS, POWERUPS, PowerUpId, QUALITY_ORDER, REGIONS, UPGRADES, REGION_LENGTH } from "../data/GameData.js";
import { LOOKS } from "../render/CharacterFactory.js";

const $ = <T extends HTMLElement = HTMLElement>(el: ParentNode, sel: string) => el.querySelector(sel) as T;
const hex = (n: number) => "#" + n.toString(16).padStart(6, "0");
const fmt = (n: number) => Math.floor(n).toLocaleString("en-US");
const ICON_UP = `<svg viewBox="0 0 64 64"><path d="M32 8 L54 34 H40 V56 H24 V34 H10 Z" fill="#fff"/></svg>`;
const ICON_DOWN = `<svg viewBox="0 0 64 64"><path d="M6 20 L34 20 L50 34 L50 46 L12 46 Q6 46 6 40 Z" fill="#fff"/><path d="M40 12 L58 12" stroke="#fff" stroke-width="6" stroke-linecap="round"/></svg>`;
const HEART = (on: boolean) => `<span class="heart"><svg viewBox="0 0 24 22"><path d="M12 21 C-4 9 3 -2 12 6 C21 -2 28 9 12 21Z" fill="${on ? "#ff3d4f" : "rgba(0,0,0,.35)"}" stroke="#fff" stroke-width="1.6"/></svg></span>`;

type Screen = "menu" | "characterSelect" | "missions" | "progress" | "settings" | "running" | "paused" | "results";

export class UI {
  private root: HTMLElement; private hud: HTMLElement; private screen: HTMLElement;
  private refs!: Record<string, HTMLElement>;
  private selIdx = 0; private lastScreen: Screen | "" = ""; private lastCombo = 0; private lastRegion = -1; private bannerT = 0; private toastKey = ""; private lastPuKey = ""; private fpsOn = false;
  private lastHeartKey = "";

  constructor(private game: Game, private scene: Scene3D | null) {
    this.root = document.getElementById("ui-root")!;
    this.root.innerHTML = `<div id="hud" class="hidden"></div><div id="screen"></div>`;
    this.hud = $(this.root, "#hud"); this.screen = $(this.root, "#screen");
    this.buildHud();
    this.root.addEventListener("click", (e) => this.onClick(e));
    this.root.addEventListener("input", (e) => this.onInput(e));
    game.onChange(() => this.render());
    game.fxHook = (fx) => this.onFx(fx);
    window.addEventListener("keydown", (e) => this.onKey(e));
    this.applySettings();
    this.selIdx = Math.max(0, CHARACTER_IDS.indexOf(game.progression.selectedCharacter as any));
    this.render();
  }

  // ───────────────────────── settings ─────────────────────────
  applySettings() {
    const s = this.game.progression.settings, a = this.game.audio;
    a.setMuted(s.muted); a.setMusicEnabled(s.music); a.setSfxVolume(s.sfxVolume); a.setVibration(s.vibration);
    this.fpsOn = s.showFps; this.refs.fps.classList.toggle("hidden", !this.fpsOn);
  }

  // ───────────────────────── HUD ─────────────────────────
  private buildHud() {
    this.hud.innerHTML = `
      <div class="hud-tl">
        <button class="pause-btn" data-act="pause" aria-label="Pause"><i></i><i></i></button>
        <div class="stats shadowtext">
          <div class="row"><span class="lbl">SCORE</span><span class="score" id="h-score">0</span></div>
          <div class="row"><span class="coin"></span><span class="val" id="h-coins">0</span></div>
          <div class="row"><span class="lbl">DISTANCE</span><span class="val" id="h-dist">0 m</span></div>
          <div class="boost" id="h-boost"><div class="lbl2"><span>BOOST</span><span id="h-boost-t"></span></div><div class="track"><i id="h-boost-bar"></i></div></div>
        </div>
      </div>
      <div class="hud-tc"><div class="mission shadowtext"><div class="star">★</div><div class="mt"><b id="h-mt">—</b><div class="track"><i id="h-mbar"></i></div></div><div class="mc" id="h-mc"></div></div></div>
      <div class="hud-tr">
        <div class="hr"><div class="hearts" id="h-hearts"></div><button class="sound-btn" data-act="sound" id="h-sound" aria-label="Sound">🔊</button></div>
        <div class="stamina" id="h-stam"><div class="lbl2 shadowtext">⚡ STAMINA</div><div class="track"><i id="h-stam-bar" style="width:100%"></i></div></div>
      </div>
      <div class="combo shadowtext" id="h-combo"></div>
      <div class="rival-tag" id="h-rival"></div>
      <div class="event-banner" id="h-event"></div>
      <div class="toast" id="h-toast"></div>
      <div class="region-banner shadowtext" id="h-region"></div>
      <div class="pu-row" id="h-pu"></div>
      <button class="ctl mini dashb hidden" data-ctl="dash" id="c-dash" aria-label="Air dash">»</button>
      <button class="ctl mini grapb hidden" data-ctl="grapple" id="c-grap" aria-label="Grapple">⚓</button>
      <button class="ctl mini boostb" data-ctl="boost" id="c-boost" aria-label="Boost">⚡</button>
      <button class="ctl jump" data-ctl="jump" aria-label="Jump">${ICON_UP}<small class="shadowtext">JUMP</small></button>
      <button class="ctl slide" data-ctl="slide" aria-label="Slide">${ICON_DOWN}<small class="shadowtext">SLIDE</small></button>
      <div class="fps hidden" id="h-fps"></div>`;
    this.refs = {
      score: $(this.hud, "#h-score"), coins: $(this.hud, "#h-coins"), dist: $(this.hud, "#h-dist"), boost: $(this.hud, "#h-boost"), boostBar: $(this.hud, "#h-boost-bar"), boostT: $(this.hud, "#h-boost-t"),
      mt: $(this.hud, "#h-mt"), mbar: $(this.hud, "#h-mbar"), mc: $(this.hud, "#h-mc"), hearts: $(this.hud, "#h-hearts"), sound: $(this.hud, "#h-sound"), stam: $(this.hud, "#h-stam"), stamBar: $(this.hud, "#h-stam-bar"),
      combo: $(this.hud, "#h-combo"), rival: $(this.hud, "#h-rival"), event: $(this.hud, "#h-event"), toast: $(this.hud, "#h-toast"), region: $(this.hud, "#h-region"), pu: $(this.hud, "#h-pu"),
      dash: $(this.hud, "#c-dash"), grap: $(this.hud, "#c-grap"), boostBtn: $(this.hud, "#c-boost"), fps: $(this.hud, "#h-fps"),
    };
    // press-and-go controls (pointerdown for minimal latency)
    for (const b of Array.from(this.hud.querySelectorAll<HTMLElement>("[data-ctl]"))) {
      b.addEventListener("pointerdown", (e) => { e.preventDefault(); e.stopPropagation(); const a = b.dataset.ctl as any; this.game.audio.unlock(); this.game.input.inject(a); });
    }
  }

  /** Called every frame by main.ts. */
  tick() {
    const g = this.game, ph = g.phase;
    const showHud = ph === "running" || ph === "paused";
    this.hud.classList.toggle("hidden", !showHud);
    this.refs.fps.textContent = this.scene ? `${this.scene.fpsShown.toFixed(0)} fps · ${this.scene.qualityLabel} · ${this.scene.stats.drawCalls} calls · ${(this.scene.stats.triangles / 1000).toFixed(0)}k tris` : `${g.fps.toFixed(0)} fps · 2D fallback`;
    if (!showHud) return;
    const p = g.player, r = this.refs;
    r.score.textContent = fmt(g.score); r.coins.textContent = fmt(g.coins); r.dist.textContent = fmt(g.distance) + " m";
    r.boostBar.style.width = (g.boostTimer > 0 ? Math.min(100, (g.boostTimer / 4.2) * 100) : g.flow).toFixed(0) + "%";
    r.boost.classList.toggle("ready", g.boostReady || g.boostTimer > 0); r.boostT.textContent = g.boostTimer > 0 ? "ACTIVE" : g.boostReady ? "READY!" : "";
    r.boostBtn.classList.toggle("ready", g.boostReady);
    const m = g.missions.getCurrent();
    if (m) { r.mt.textContent = m.title; const pct = Math.min(100, (m.progress / m.target) * 100); r.mbar.style.width = pct + "%"; r.mc.textContent = `${Math.floor(m.progress)}/${m.target}`; } else { r.mt.textContent = "All missions complete"; r.mbar.style.width = "100%"; r.mc.textContent = ""; }
    const hk = `${p.health}/${p.maxHealth}/${p.shieldCharges}`; if (hk !== this.lastHeartKey) { this.lastHeartKey = hk; let h = ""; for (let i = 0; i < p.maxHealth; i++) h += HEART(i < p.health); if (p.shieldCharges > 0) h += `<span style="margin-left:4px">🛡</span>`; r.hearts.innerHTML = h; }
    const sp = p.stamina / p.maxStamina; r.stamBar.style.width = (sp * 100).toFixed(0) + "%"; r.stam.classList.toggle("low", sp < 0.25);
    // combo
    if (g.combo >= 3) { const mult = g.comboMultiplier(); r.combo.textContent = `x${mult} Combo!  ${g.combo}`; r.combo.classList.add("on"); if (g.combo !== this.lastCombo && g.combo % 8 === 0) { r.combo.classList.remove("pop"); void r.combo.offsetWidth; r.combo.classList.add("pop"); } } else r.combo.classList.remove("on");
    this.lastCombo = g.combo;
    // rival
    const rv = g.rivals.rival; if (rv && rv.active && !rv.defeated) { r.rival.textContent = `🏁 ${rv.name} ${rv.z > 0 ? "ahead " + Math.round(rv.z) + " m" : "behind " + Math.round(-rv.z) + " m"}`; r.rival.classList.add("on"); } else r.rival.classList.remove("on");
    // event
    const ev = g.events.primary; if (ev) { r.event.textContent = `${ev.def.icon} ${ev.def.name.toUpperCase()}`; r.event.className = "event-banner on" + (ev.def.group === "boon" ? " boon" : ""); } else r.event.className = "event-banner";
    // toast
    const t = g.toast; if (t) { if (r.toast.textContent !== t.text) r.toast.textContent = t.text; r.toast.classList.add("on"); } else r.toast.classList.remove("on");
    // region banner
    const seg = Math.floor(g.distance / REGION_LENGTH), ri = seg % REGIONS.length;
    if (ph === "running") { if (ri !== this.lastRegion && g.distance > 20 && this.lastRegion >= 0) { this.bannerT = 3; r.region.innerHTML = `${REGIONS[ri].name.toUpperCase()}<small>${REGIONS[ri].blurb}</small>`; } if (this.lastRegion < 0) { this.bannerT = 2.6; r.region.innerHTML = `${REGIONS[ri].name.toUpperCase()}<small>${REGIONS[ri].blurb}</small>`; } this.lastRegion = ri; this.bannerT = Math.max(0, this.bannerT - 1 / 60); r.region.classList.toggle("show", this.bannerT > 0); }
    // power-ups
    let key = ""; let html = "";
    for (const id of Object.keys(g.powerups) as PowerUpId[]) { const v = g.powerups[id]; if (v > 0) { const d = POWERUPS[id]; key += id + Math.ceil(v); html += `<div class="pu"><b style="background:${d.color}">${d.icon}</b>${Math.ceil(v)}s</div>`; } }
    if (key !== this.lastPuKey) { this.lastPuKey = key; r.pu.innerHTML = html; }
    // ability buttons (unlocked by progression)
    r.dash.classList.toggle("hidden", !p.abilities.airDash); r.grap.classList.toggle("hidden", !p.abilities.grapple);
    r.sound.textContent = g.audio.isMuted() ? "🔇" : "🔊";
  }

  private onFx(list: FxEvent[]) {
    const flash = document.getElementById("flash")!; const a = this.game.audio;
    for (const e of list) {
      if (e.type === "hit") { a.vibrate(70); flash.className = "red"; flash.style.opacity = "0.9"; setTimeout(() => (flash.style.opacity = "0"), 120); }
      else if (e.type === "death") a.vibrate(240);
      else if (e.type === "boost") a.vibrate(35);
      else if (e.type === "lightning") { flash.className = ""; flash.style.opacity = "0.7"; setTimeout(() => (flash.style.opacity = "0"), 90); }
      else if (e.type === "powerup") a.vibrate(20);
      else if (e.type === "regionEnter") { this.lastRegion = -1; }
    }
  }

  // ───────────────────────── input ─────────────────────────
  private onKey(e: KeyboardEvent) {
    const g = this.game;
    if ((e.code === "Escape" || e.code === "KeyP") && (g.phase === "running" || g.phase === "paused")) { g.togglePause(); return; }
    if (g.phase === "menu" && (e.code === "Enter" || e.code === "Space")) { e.preventDefault(); this.act("play"); }
    else if (g.phase === "results" && (e.code === "Enter" || e.code === "Space")) { e.preventDefault(); this.act("again"); }
    else if (g.phase === "characterSelect") { if (e.code === "ArrowLeft") this.act("prev"); if (e.code === "ArrowRight") this.act("next"); if (e.code === "Escape") this.act("back"); }
    else if ((g.phase === "missions" || g.phase === "progress" || g.phase === "settings") && e.code === "Escape") this.act("back");
  }
  private onClick(e: Event) {
    const t = (e.target as HTMLElement).closest("[data-act]") as HTMLElement | null; if (!t) return;
    this.game.audio.unlock(); this.act(t.dataset.act!, t.dataset.arg);
  }
  private onInput(e: Event) { const t = e.target as HTMLInputElement; if (t.dataset.range === "sfx") { const v = parseFloat(t.value); this.game.progression.updateSettings({ sfxVolume: v }); this.game.audio.setSfxVolume(v); } }

  act(a: string, arg?: string) {
    const g = this.game, pr = g.progression;
    g.fx({ type: "uiClick" });
    switch (a) {
      case "play": g.startRun(pr.selectedCharacter); this.lastRegion = -1; break;
      case "again": g.startRun(pr.selectedCharacter); this.lastRegion = -1; break;
      case "menu": g.setPhase("menu"); break;
      case "char": this.selIdx = Math.max(0, CHARACTER_IDS.indexOf(pr.selectedCharacter as any)); g.setPhase("characterSelect"); this.scene?.setShowcase(CHARACTER_IDS[this.selIdx]); break;
      case "missions": g.setPhase("missions"); break;
      case "progress": g.setPhase("progress"); break;
      case "settings": g.setPhase("settings"); break;
      case "back": g.setPhase("menu"); break;
      case "pause": g.togglePause(); break;
      case "resume": g.togglePause(); break;
      case "quit": g.quitToMenu(); break;
      case "sound": { const m = g.audio.toggleMuted(); pr.updateSettings({ muted: m }); break; }
      case "prev": this.selIdx = (this.selIdx + CHARACTER_IDS.length - 1) % CHARACTER_IDS.length; this.scene?.setShowcase(CHARACTER_IDS[this.selIdx]); this.render(true); break;
      case "next": this.selIdx = (this.selIdx + 1) % CHARACTER_IDS.length; this.scene?.setShowcase(CHARACTER_IDS[this.selIdx]); this.render(true); break;
      case "pick": this.selIdx = Math.max(0, CHARACTER_IDS.indexOf(arg as any)); this.scene?.setShowcase(arg!); this.render(true); break;
      case "select": if (arg) { pr.setSelectedCharacter(arg); this.render(true); } break;
      case "buy": if (arg) { const r = pr.buyCharacter(arg); if (r.ok) { pr.setSelectedCharacter(arg); g.showToast("Unlocked " + CHARACTERS[arg as keyof typeof CHARACTERS].name + "!"); } else g.showToast(r.reason ?? "Cannot buy"); this.render(true); } break;
      case "upg": if (arg) { const r = pr.buyUpgrade(arg); if (!r.ok) g.showToast(r.reason ?? "Cannot buy"); this.render(true); } break;
      case "q": if (arg) { pr.updateSettings({ quality: arg as any }); this.scene?.setQuality(arg as any); this.render(true); } break;
      case "tog": if (arg) { const s = pr.settings; if (arg === "muted") pr.updateSettings({ muted: !s.muted }); if (arg === "music") pr.updateSettings({ music: !s.music }); if (arg === "vibration") pr.updateSettings({ vibration: !s.vibration }); if (arg === "showFps") pr.updateSettings({ showFps: !s.showFps }); this.applySettings(); this.render(true); } break;
      case "reset": if (confirm("Erase all progress on this device?")) { pr.reset(); g.missions.resetAll(); this.applySettings(); this.render(true); } break;
    }
  }

  // ───────────────────────── screens ─────────────────────────
  render(force = false) {
    const ph = this.game.phase as Screen;
    if (!force && ph === this.lastScreen && (ph === "running")) return;
    this.lastScreen = ph;
    const sc = this.screen; const g = this.game, pr = g.progression;
    switch (ph) {
      case "menu": sc.innerHTML = this.menuHtml(); break;
      case "characterSelect": sc.innerHTML = this.charHtml(); this.bindDrag(); break;
      case "missions": sc.innerHTML = this.missionsHtml(); break;
      case "progress": sc.innerHTML = this.progressHtml(); break;
      case "settings": sc.innerHTML = this.settingsHtml(); break;
      case "paused": sc.innerHTML = `<div class="dim"></div><div class="panel pause-sheet"><h2>PAUSED</h2><button class="btn play" data-act="resume">RESUME</button><button class="btn ghost" data-act="quit">QUIT TO MENU</button></div>`; break;
      case "results": sc.innerHTML = this.resultsHtml(); break;
      default: sc.innerHTML = "";
    }
    void pr;
  }
  private head(): string { const pr = this.game.progression; return `<div class="topbar"><span class="chip"><span class="coin"></span>${fmt(pr.getBank())}</span><span class="chip">★ BEST ${fmt(pr.getHighScore())}</span></div>`; }
  private menuHtml() {
    const c = CHARACTERS[this.game.progression.selectedCharacter as keyof typeof CHARACTERS] ?? CHARACTERS.runner;
    return `<div class="screen">${this.head()}
      <div class="logo-big">NEXUS<b>RUNNER</b></div><div class="tagline shadowtext">RUN · SLIDE · SURVIVE · ${c.name.toUpperCase()}</div>
      <div class="menu-col"><button class="btn play" data-act="play">▶ PLAY</button>
      <div class="row2"><button class="btn" data-act="char">CHARACTER</button><button class="btn" data-act="missions">MISSIONS</button></div>
      <div class="row2"><button class="btn" data-act="progress">PROGRESS</button><button class="btn" data-act="settings">SETTINGS</button></div></div></div>`;
  }
  private charHtml() {
    const g = this.game, pr = g.progression; const id = CHARACTER_IDS[this.selIdx]; const c = CHARACTERS[id]; const unlocked = pr.isCharacterUnlocked(id); const sel = pr.selectedCharacter === id;
    const pips = (n: number) => `<div class="pips">${[1, 2, 3, 4, 5].map((i) => `<i class="${i <= n ? "on" : ""}"></i>`).join("")}</div>`;
    const bars = Object.entries(c.bars).map(([k, v]) => `<div class="statrow"><span>${k.toUpperCase()}</span>${pips(v)}</div>`).join("");
    const thumbs = CHARACTER_IDS.map((cid, i) => { const d = CHARACTERS[cid]; const L = LOOKS[cid]; return `<button class="thumb ${i === this.selIdx ? "sel" : ""}" data-act="pick" data-arg="${cid}"><div style="height:34px;border-radius:50%;margin:0 auto 4px;width:34px;background:radial-gradient(circle at 35% 30%,#fff7,${hex(L.top)} 55%,${hex(L.top2)});border:2px solid ${hex(L.accent)}"></div>${d.name}${pr.isCharacterUnlocked(cid) ? "" : '<span class="lock">🔒</span>'}</button>`; }).join("");
    const action = unlocked
      ? `<div class="row2">${sel ? `<button class="btn green" data-act="play">▶ RUN AS ${c.name.toUpperCase()}</button>` : `<button class="btn" data-act="select" data-arg="${id}">SELECT</button><button class="btn play" data-act="select" data-arg="${id}">SELECT</button>`}</div>`
      : `<div class="lockmsg">🔒 Locked — ${fmt(c.unlockCost)} coins (you have ${fmt(pr.getBank())})</div><button class="btn ${pr.getBank() >= c.unlockCost ? "green" : "ghost"}" data-act="buy" data-arg="${id}" ${pr.getBank() >= c.unlockCost ? "" : "disabled"}>UNLOCK · ${fmt(c.unlockCost)} <span class="coin"></span></button>`;
    return `<div class="screen"><div class="topbar"><button class="btn small ghost" data-act="back">‹ BACK</button><span class="chip"><span class="coin"></span>${fmt(pr.getBank())}</span></div>
      <div class="drag-zone" id="drag"><div class="rotate-hint" style="margin-top:6px">◂ DRAG TO ROTATE ▸</div></div>
      <div class="charbar"><div class="thumbs">${thumbs}</div>
      <div class="panel charinfo"><div style="display:flex;justify-content:space-between;align-items:center"><button class="btn small ghost" data-act="prev" style="min-width:0">‹</button><div style="text-align:center"><h3>${c.name.toUpperCase()}${sel ? " ✓" : ""}</h3><div class="tag">${c.tagline}</div></div><button class="btn small ghost" data-act="next" style="min-width:0">›</button></div>
      ${bars}<div class="ability"><b>${c.abilityName}</b> — ${c.abilityText}</div><div class="act">${action}</div></div></div></div>`;
  }
  private bindDrag() {
    const d = document.getElementById("drag"); if (!d) return; let last: number | null = null;
    d.addEventListener("pointerdown", (e) => { last = e.clientX; d.setPointerCapture(e.pointerId); });
    d.addEventListener("pointermove", (e) => { if (last !== null && this.scene) { this.scene.showcaseDrag += (e.clientX - last) * 0.012; last = e.clientX; } });
    d.addEventListener("pointerup", () => { last = null; }); d.addEventListener("pointercancel", () => { last = null; });
  }
  private missionsHtml() {
    const g = this.game, pr = g.progression; const ms = g.missions.getActive();
    const mh = ms.map((m) => `<div class="card ${m.completed ? "done" : ""}"><div class="ico">${m.completed ? "✅" : "🎯"}</div><div class="t"><b>${m.title}</b><span>${Math.floor(m.progress)} / ${m.target} · reward ${m.reward} coins</span><div class="bar gold"><i style="width:${Math.min(100, (m.progress / m.target) * 100)}%"></i></div></div></div>`).join("");
    const up = Object.entries(UPGRADES).map(([id, u]) => { const lvl = pr.getUpgradeLevel(id); const maxed = lvl >= u.max; const cost = u.cost(lvl); return `<div class="card"><div class="ico">⬆</div><div class="t"><b>${u.name} · Lv ${lvl}/${u.max}</b><span>${u.desc}</span></div><button class="btn small ${!maxed && pr.getBank() >= cost ? "green" : "ghost"}" data-act="upg" data-arg="${id}" ${maxed || pr.getBank() < cost ? "disabled" : ""}>${maxed ? "MAX" : fmt(cost) + " ●"}</button></div>`; }).join("");
    return `<div class="screen"><div class="topbar"><button class="btn small ghost" data-act="back">‹ BACK</button><span class="chip"><span class="coin"></span>${fmt(pr.getBank())}</span></div><div class="panel sheet"><h2>MISSIONS</h2><div class="scroll">${mh}<h2 style="font-size:18px;margin-top:6px">UPGRADES</h2>${up}<div class="mission-hint">Missions complete during a run and pay out when the run ends.</div></div></div></div>`;
  }
  private progressHtml() {
    const g = this.game, pr = g.progression, d = pr.data;
    const regs = REGIONS.map((r) => { const found = pr.isRegionDiscovered(r.index); const best = d.regionBest[r.id]; return `<div class="reg ${found ? "" : "locked"}" style="background:linear-gradient(90deg,${r.swatch}55,rgba(255,255,255,.06))"><div class="sw" style="background:${found ? r.swatch : "#555"}"></div><div><b>${found ? r.name : "??? Undiscovered"}</b><span>${found ? r.blurb : `Reach ${fmt(r.index * REGION_LENGTH)} m in a single run`}</span>${found && best ? `<span>Best here: ${fmt(best.distance)} m</span>` : ""}</div></div>`; }).join("");
    const unlocked = new Set(pr.getUnlockedAbilityIds());
    const ab = ABILITY_UNLOCKS.map((a) => { const on = unlocked.has(a.id); return `<div class="card ${on ? "done" : "locked"}"><div class="ico">${on ? "✅" : "🔒"}</div><div class="t"><b>${a.name}</b><span>${on ? "Unlocked" : `Reach a score of ${fmt(a.score)} in one run`}</span></div></div>`; }).join("");
    return `<div class="screen"><div class="topbar"><button class="btn small ghost" data-act="back">‹ BACK</button><span class="chip"><span class="coin"></span>${fmt(pr.getBank())}</span></div><div class="panel sheet"><h2>PROGRESS</h2><div class="scroll">
      <div class="kv"><div><small>HIGH SCORE</small><b>${fmt(d.highScore)}</b></div><div><small>BEST DISTANCE</small><b>${fmt(d.bestDistance)} m</b></div><div><small>TOTAL DISTANCE</small><b>${fmt(d.totalDistance)} m</b></div><div><small>RUNS</small><b>${fmt(d.runsCompleted)}</b></div><div><small>BEST COMBO</small><b>x${fmt(d.maxCombo)}</b></div><div><small>COINS EARNED</small><b>${fmt(d.totalCoinsEver)}</b></div></div>
      <h2 style="font-size:18px">MAP</h2><div class="regions">${regs}</div><h2 style="font-size:18px">MOVES</h2>${ab}</div></div></div>`;
  }
  private settingsHtml() {
    const s = this.game.progression.settings; const tog = (k: string, on: boolean) => `<button class="tog ${on ? "on" : ""}" data-act="tog" data-arg="${k}" aria-label="${k}"></button>`;
    const q = ["AUTO", ...QUALITY_ORDER].map((t) => `<button class="${s.quality === t ? "on" : ""}" data-act="q" data-arg="${t}">${t}</button>`).join("");
    return `<div class="screen"><div class="topbar"><button class="btn small ghost" data-act="back">‹ BACK</button></div><div class="panel sheet"><h2>SETTINGS</h2><div class="scroll">
      <div class="setrow"><span>Graphics quality</span><div class="seg">${q}</div></div>
      <div class="mission-hint">${this.scene ? `Active: ${this.scene.qualityLabel}. AUTO picks a tier from device hints and lowers it if the frame rate drops.` : "3D renderer unavailable — using 2D fallback."}</div>
      <div class="setrow"><span>Sound</span>${tog("muted", !s.muted)}</div><div class="setrow"><span>Music</span>${tog("music", s.music)}</div>
      <div class="setrow"><span>SFX volume</span><input type="range" min="0" max="1" step="0.05" value="${s.sfxVolume}" data-range="sfx"/></div>
      <div class="setrow"><span>Vibration</span>${tog("vibration", s.vibration)}</div><div class="setrow"><span>Show FPS / stats</span>${tog("showFps", s.showFps)}</div>
      <button class="btn ghost small" data-act="reset" style="align-self:center">RESET PROGRESS</button></div></div></div>`;
  }
  private resultsHtml() {
    const r = this.game.lastSummary; if (!r) return `<div class="screen"><div class="menu-col"><button class="btn play" data-act="menu">MENU</button></div></div>`;
    const o = r.outcome; const ms = r.missionsCompleted.map((m) => `<div class="card done"><div class="ico">✅</div><div class="t"><b>${m.title}</b><span>+${m.reward} coins</span></div></div>`).join("");
    const un = [...o.newAbilities.map((a) => `Move unlocked: ${a}`), ...o.newRegions.map((a) => `Region discovered: ${a}`), ...o.characterUnlockable.map((a) => `You can now afford ${a}`)].map((t) => `<div class="unlock">🎉 ${t}</div>`).join("");
    return `<div class="screen"><div class="dim"></div><div class="panel sheet" style="margin-top:auto;margin-bottom:auto;max-height:92%"><h2>RUN COMPLETE</h2>
      <div class="res-big">${fmt(r.score)}</div>${r.newHighScore ? '<div class="badge">NEW HIGH SCORE!</div>' : ""}
      <div class="kv"><div><small>DISTANCE</small><b>${fmt(r.distance)} m</b></div><div><small>COINS</small><b>${fmt(r.coins)}${r.missionReward ? ` +${fmt(r.missionReward)}` : ""}</b></div><div><small>BEST COMBO</small><b>x${r.maxCombo}</b></div><div><small>TIME</small><b>${Math.floor(r.time / 60)}:${String(Math.floor(r.time % 60)).padStart(2, "0")}</b></div></div>
      <div class="scroll">${ms}${un}<div class="mission-hint">${r.regionsReached.join(" → ")}${r.rivalsDefeated ? ` · rivals beaten: ${r.rivalsDefeated}` : ""}</div></div>
      <div class="row2"><button class="btn play" data-act="again">RUN AGAIN</button><button class="btn ghost" data-act="menu">MENU</button></div></div></div>`;
  }
}
void EVENTS;
