import { makeGame, Bot } from "./helpers.js";
const [cid, s] = [process.argv[2] ?? "acrobat", process.argv[3] ?? "2"];
const g = makeGame(`bot_${cid}_${s}`); g.progression.grantAll(); g.startRun(cid as any);
const bot = new Bot(g); let hp = g.player.health; let steps = 0;
const hist: string[] = [];
while (g.phase === "running" && g.distance < 4000 && steps < 60 * 300) {
  bot.act(); g.step(1 / 60); steps++;
  hist.push(`${g.player.x.toFixed(2)},${g.player.y.toFixed(2)},${g.player.movementState}`); if (hist.length > 40) hist.shift();
  if (g.player.health < hp) {
    hp = g.player.health;
    const near = g.world.getObstacles().filter((o) => Math.abs(o.z) < 4).map((o) => `${o.type}[lane${o.lane} kind=${o.kind} z=${o.z.toFixed(2)} d=${o.depth.toFixed(1)} y=${o.y.toFixed(1)} h=${o.height} row=${o.rowId} vz=${o.vz}]`);
    const ahead = g.world.getObstacles().filter((o) => o.z > 4 && o.z < 40).sort((a, b) => a.z - b.z).slice(0, 6).map((o) => `${o.type}[l${o.lane} ${o.kind} z=${o.z.toFixed(1)} row=${o.rowId}]`);
    console.log(`HIT @${g.distance.toFixed(0)}m speed=${g.speed.toFixed(1)} lane=${g.player.lane} tgt=${g.player.targetLane} x=${g.player.x.toFixed(2)} state=${g.player.movementState}\n near: ${near.join(" ")}\n ahead: ${ahead.join(" ")}\n hist: ${hist.slice(-14).join(" | ")}`);
  }
}
