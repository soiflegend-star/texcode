import { Game } from "../src/core/Game.js";
import { LANE_WIDTH } from "../src/data/GameData.js";

export class MemStorage implements Storage {
  private m = new Map<string, string>();
  get length() { return this.m.size; }
  clear() { this.m.clear(); }
  getItem(k: string) { return this.m.has(k) ? this.m.get(k)! : null; }
  key(i: number) { return [...this.m.keys()][i] ?? null; }
  removeItem(k: string) { this.m.delete(k); }
  setItem(k: string, v: string) { this.m.set(k, String(v)); }
}

let passed = 0, failed = 0; const failures: string[] = [];
export function check(name: string, cond: boolean, detail = "") {
  if (cond) { passed++; console.log(`  ✔ ${name}`); } else { failed++; failures.push(name + (detail ? ` — ${detail}` : "")); console.log(`  ✘ ${name}${detail ? " — " + detail : ""}`); }
}
export function section(t: string) { console.log(`\n▸ ${t}`); }
export function summary() { console.log(`\n${passed} passed, ${failed} failed`); if (failed) { console.log("FAILURES:\n - " + failures.join("\n - ")); } return failed === 0; }

/** Autopilot: plays using only information a human has (obstacles ahead). Never uses advanced abilities.
 *  Plans a lane per upcoming row (DP over rows, minimal lane changes) and executes jump/slide timing. */
export class Bot {
  private jumpedRow = -1;
  constructor(private g: Game) {}
  act() {
    const g = this.g, p = g.player, w = g.world;
    const speed = Math.max(8, g.speed);
    const obs = w.getObstacles().filter((o) => o.z + o.depth / 2 > -0.3 && !o.broken);
    const byRow = new Map<number, typeof obs>();
    for (const o of obs) { if (o.z - o.depth / 2 > speed * 4.5) continue; if (!byRow.has(o.rowId)) byRow.set(o.rowId, []); byRow.get(o.rowId)!.push(o); }
    type Row = { id: number; f: number; e: number; cell: (l: number) => string };
    const rows: Row[] = [...byRow.entries()].map(([id, list]) => ({
      id, f: Math.min(...list.map((o) => o.z - o.depth / 2)), e: Math.max(...list.map((o) => o.z + o.depth / 2)),
      cell: (l: number) => { const hit = list.filter((o) => o.width > LANE_WIDTH * 2.5 || o.lane === l); if (!hit.length) return "none"; if (hit.some((o) => o.kind === "block")) return "block"; return hit[0].kind; },
    })).sort((a, b) => a.f - b.f).slice(0, 5);

    // Lane we must hold: inside a row right now
    const inside = rows.find((r) => r.f < 1.2 && r.e > -0.3);
    let want = p.targetLane;
    if (!inside) {
      // DP: best[i][lane] = min cost to be passing row i in `lane`
      const lanes = [-1, 0, 1]; const INF = 1e9;
      let prevCost: Record<number, number> = { [-1]: INF, 0: INF, 1: INF }; prevCost[p.targetLane] = 0;
      const back: Array<Record<number, number>> = [];
      for (const r of rows) {
        const cost: Record<number, number> = { [-1]: INF, 0: INF, 1: INF }; const from: Record<number, number> = {};
        for (const l of lanes) {
          if (r.cell(l) === "block") continue;
          for (const pl of lanes) { const c = prevCost[pl] + Math.abs(pl - l) * 1.0 + (r.cell(l) === "none" ? 0 : 0.3); if (c < cost[l]) { cost[l] = c; from[l] = pl; } }
        }
        back.push(from); prevCost = cost;
      }
      if (rows.length) {
        let best = lanes.sort((a, b) => prevCost[a] - prevCost[b])[0];
        if (prevCost[best] < INF) {
          for (let i = rows.length - 1; i > 0; i--) best = back[i][best];
          want = best; // lane for the first row
        }
      }
    }
    if (want < p.targetLane) g.input.inject("left"); else if (want > p.targetLane) g.input.inject("right");

    for (const row of rows) {
      const lane = p.targetLane;
      if (Math.abs(p.x - lane * LANE_WIDTH) > 0.9) continue;
      const k = row.cell(lane);
      if (k === "jump" && this.jumpedRow !== row.id && row.f < speed * 0.34 && row.f > speed * 0.16 && p.isGrounded) { g.input.inject("jump"); this.jumpedRow = row.id; }
      if (k === "slide" && row.f < speed * 0.22 && row.e > 0 && p.isGrounded && p.movementState !== "sliding") g.input.inject("slide");
    }
  }
}
export function makeGame(seed: string, storage = new MemStorage()) {
  return new Game(null, { headless: true, storage, seed, useAudio: false });
}
