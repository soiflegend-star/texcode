// REAL-WebGL verification. Requires: npm install && npm run build (uses the real three package, no stand-in).
// Usage: npm run test:gpu          (headless Chromium; software GL via SwiftShader if no GPU)
//        HEADED=1 npm run test:gpu (use your real GPU in a visible window)
// Writes real screenshots to docs/screenshots/ — those are the only screenshots allowed in the README.
import { chromium } from "playwright"; import { spawn } from "node:child_process"; import fs from "node:fs";
const shots = "docs/screenshots"; fs.mkdirSync(shots, { recursive: true });
const srv = spawn("npx", ["vite", "preview", "--port", "4173", "--strictPort"], { stdio: "ignore" });
await new Promise((r) => setTimeout(r, 3500));
const results = []; const ok = (n, c, d = "") => { results.push(c); console.log((c ? "  ✔ " : "  ✘ ") + n + (c ? "" : "  " + d)); };
const browser = await chromium.launch({ headless: !process.env.HEADED, args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist", "--enable-webgl"] });
const errors = []; const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
page.on("pageerror", (e) => errors.push(e.message)); page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
await page.goto("http://localhost:4173/"); await page.waitForFunction(() => window.game && window.scene3d !== undefined, null, { timeout: 30000 }); await page.waitForTimeout(1500);
const ev = (f, a) => page.evaluate(f, a);
ok("real Three.js WebGLRenderer initialised (not 2D fallback)", await ev(() => !!window.scene3d && !!window.scene3d.renderer.getContext()));
const gl = await ev(() => { const c = window.scene3d.renderer.getContext(); const e = c.getExtension("WEBGL_debug_renderer_info"); return e ? c.getParameter(e.UNMASKED_RENDERER_WEBGL) : "unknown"; }); console.log("  GL renderer:", gl);
// pixel check: a rendered frame must not be a flat colour
async function variance(name) { const buf = await page.screenshot({ path: `${shots}/${name}.png` }); const { default: zlib } = await import("node:zlib"); void zlib; return buf.length; }
const sizeOf = async (n) => (await variance(n));
const menuBytes = await sizeOf("01-menu"); ok("menu frame has detail (PNG > 40 KB)", menuBytes > 40000, String(menuBytes));
for (const id of ["runner", "acrobat", "speedster", "heavy", "ninja"]) { await ev((id) => { window.game.progression.grantAll(); window.game.progression.setSelectedCharacter(id); window.game.setPhase("characterSelect"); window.scene3d.setShowcase(id); }, id); await page.waitForTimeout(900); const b = await sizeOf(`char-${id}`); ok(`character ${id} renders`, b > 40000, String(b)); }
await ev(() => { window.game.progression.setSelectedCharacter("runner"); window.game.startRun("runner"); window.game.player.invulnTimer = 1e9; });
for (let r = 0; r < 5; r++) { await ev((r) => window.game.debugJumpToRegion(r), r); await page.waitForTimeout(2200); await ev(() => { window.game.player.health = window.game.player.maxHealth; }); const st = await ev(() => ({ calls: window.scene3d.stats.drawCalls, tris: window.scene3d.stats.triangles, chunks: window.scene3d.stats.chunks, fps: window.scene3d.fpsShown, q: window.scene3d.qualityLabel })); const b = await sizeOf(`region-${r}`); ok(`region ${r} renders: ${JSON.stringify(st)}`, st.calls > 5 && st.chunks >= 5 && b > 40000); }
for (const q of ["LOW", "MEDIUM", "HIGH", "ULTRA", "AUTO"]) { await ev((q) => window.scene3d.setQuality(q), q); await page.waitForTimeout(1500); const st = await ev(() => ({ calls: window.scene3d.stats.drawCalls, tris: window.scene3d.stats.triangles, fps: Math.round(window.scene3d.fpsShown) })); console.log("  quality", q, JSON.stringify(st)); ok(`quality ${q} renders`, st.calls > 5); await sizeOf(`quality-${q}`); }
await page.setViewportSize({ width: 390, height: 844 }); await page.waitForTimeout(800); ok("resize to phone portrait keeps rendering", await ev(() => window.scene3d.stats.drawCalls > 5)); await sizeOf("phone-portrait");
const d0 = await ev(() => window.game.distance); await page.waitForTimeout(1500); ok("camera/game advance (distance grows)", (await ev(() => window.game.distance)) > d0);
ok("no console/page errors", errors.length === 0, errors.slice(0, 4).join(" | "));
await browser.close(); srv.kill(); const f = results.filter((x) => !x).length; console.log(`\n${results.length - f} passed, ${f} failed. Screenshots: ${shots}/`); process.exit(f ? 1 : 0);
