import { check, section, summary, makeGame, Bot, MemStorage } from "./helpers.js";
import { WorldGenerator } from "../src/world/WorldGenerator.js";
import { validateRows, RowModel, MIN_GAP_SECONDS } from "../src/world/Solvability.js";
import { getChunkPlan } from "../src/world/ChunkPlan.js";
import { CHARACTER_IDS, REGIONS, REGION_LENGTH, EVENT_IDS, OBSTACLES } from "../src/data/GameData.js";
import { Player } from "../src/movement/Player.js";
import { ProgressionManager } from "../src/progression/ProgressionManager.js";
import { MissionManager } from "../src/progression/MissionManager.js";
import { auvyrrBridge } from "../src/auvyrr/AuvyrrBridge.js";

// ───────────────────────── Determinism ─────────────────────────
section("Seeded determinism");
function stream(seed: string, metres = 1500) {
  const w = new WorldGenerator(); w.reset(seed);
  const p = new Player(); p.reset("runner");
  let dist = 0; const out: string[] = [];
  while (dist < metres) { const speed = WorldGenerator.speedAt(dist); w.update(1 / 60, { distance: dist, speed, player: p }); dist += speed / 60; }
  for (const o of w.getObstacles()) out.push(`${o.type}:${o.lane}:${o.z.toFixed(2)}`);
  for (const c of w.getCollectibles()) out.push(`${c.type}:${c.lane}:${c.z.toFixed(2)}`);
  return out.join("|");
}
check("same seed → identical world stream", stream("abc") === stream("abc"));
check("different seed → different stream", stream("abc") !== stream("abd"));
const pa = getChunkPlan("seedX", 20), pb = getChunkPlan("seedX", 20);
check("chunk plans deterministic", JSON.stringify(pa) === JSON.stringify(pb));
let repeats = 0, lmRepeats = 0, prev = getChunkPlan("seedY", 0);
for (let i = 1; i < 400; i++) { const c = getChunkPlan("seedY", i); if (c.region.id === prev.region.id && c.variant === prev.variant && c.kind === "normal") repeats++; if (c.landmark && c.landmark === prev.landmark) lmRepeats++; prev = c; }
check("no identical scenery variant twice in a row", repeats === 0, `repeats=${repeats}`);
check("no identical landmark twice in a row", lmRepeats === 0);
const kinds = new Set<string>(); for (let i = 0; i < 80; i++) kinds.add(getChunkPlan("seedZ", i).kind);
check("transition chunks appear at region ends", kinds.has("transition"));
check("transition chunk is last chunk of each region", [15, 31, 47, 63, 79].every((i) => getChunkPlan("seedZ", i).kind === "transition"));

// ───────────────────────── Solvability audit ─────────────────────────
section("Generated routes are beatable (validator audit, 40 seeds × 6000 m, all regions)");
let totalRows = 0, badRuns = 0, minGapSeen = Infinity, maxBlockedSeen = 0; const regionRows: Record<string, number> = {}; let maxEmpty = 0; const typesSeen = new Set<string>();
for (let s = 0; s < 40; s++) {
  const w = new WorldGenerator(); w.reset("audit" + s); w.enableRowLog();
  const p = new Player(); p.reset("runner");
  let dist = 0; let lastContentZ = 0;
  while (dist < 6000) {
    const speed = WorldGenerator.speedAt(dist);
    w.update(1 / 30, { distance: dist, speed, player: p, difficulty: undefined, features: { rail: true }, flags: s % 4 === 0 ? { coinRush: true } : s % 4 === 1 ? { trafficBias: true, trainBias: true } : s % 4 === 2 ? { debris: true, drones: true, closure: true } : {} });
    dist += speed / 30;
    // empty stretch metric: biggest gap in z among obstacles+collectibles ahead of player (within horizon)
    const zs = [...w.getObstacles().map((o) => o.z), ...w.getCollectibles().map((c) => c.z)].filter((z) => z > 0 && z < 150).sort((a, b) => a - b);
    for (let i = 1; i < zs.length; i++) maxEmpty = Math.max(maxEmpty, zs[i] - zs[i - 1]);
    for (const o of w.getObstacles()) typesSeen.add(o.type);
  }
  const rows: RowModel[] = w.rowLog!.map((r) => ({ z: (r.absStart + r.absEnd) / 2, depth: r.absEnd - r.absStart, cells: r.cells as any, speed: r.speed }));
  rows.sort((a, b) => a.z - b.z);
  for (const r of w.rowLog!) regionRows[r.region] = (regionRows[r.region] ?? 0) + 1;
  const rep = validateRows(rows);
  totalRows += rep.rows; minGapSeen = Math.min(minGapSeen, rep.minGapSeconds); maxBlockedSeen = Math.max(maxBlockedSeen, rep.maxBlockedLanes);
  if (!rep.ok) { badRuns++; if (badRuns < 3) console.log("   ", "seed", s, rep.failures.slice(0, 3)); }
}
check(`validator OK on all runs (${totalRows} rows)`, badRuns === 0, `bad runs ${badRuns}`);
check(`min time gap between rows ≥ ${MIN_GAP_SECONDS}s`, minGapSeen >= MIN_GAP_SECONDS - 0.02, `min=${minGapSeen.toFixed(2)}`);
check("never more than 2 lanes blocked in a row", maxBlockedSeen <= 2, `max=${maxBlockedSeen}`);
check("all 5 regions produced obstacle rows", REGIONS.every((r) => (regionRows[r.id] ?? 0) > 20), JSON.stringify(regionRows));
check("obstacle variety (≥14 distinct types across run)", typesSeen.size >= 14, `types=${typesSeen.size}: ${[...typesSeen].join(",")}`);
check("no empty stretch > 60 m ahead of the player", maxEmpty <= 60, `max gap ${maxEmpty.toFixed(1)}m`);

// ───────────────────────── Bot playthrough ─────────────────────────
section("Autopilot plays the REAL simulation without taking damage (each character, 3 seeds, ≥ 5000 m = all 5 regions)");
let botHits = 0, botRuns = 0; const reached = new Set<string>(); let longest = 0; const botNotes: string[] = [];
for (const cid of CHARACTER_IDS) {
  for (let s = 0; s < 3; s++) {
    const g = makeGame(`bot_${cid}_${s}`);
    g.progression.grantAll();
    g.startRun(cid);
    const bot = new Bot(g);
    const startHp = g.player.health; let hits = 0; let lastHp = startHp; let steps = 0;
    while (g.phase === "running" && g.distance < 5100 && steps < 60 * 400) {
      bot.act(); g.step(1 / 60); steps++;
      if (g.player.health < lastHp) { hits += lastHp - g.player.health; lastHp = g.player.health; if (botNotes.length < 4) botNotes.push(`${cid}#${s} hit @${g.distance.toFixed(0)}m region=${g.world.currentRegionId} speed=${g.speed.toFixed(1)}`); }
      reached.add(g.world.currentRegionId);
    }
    botRuns++; botHits += hits; longest = Math.max(longest, g.distance);
  }
}
check(`bot took 0 hits across ${botRuns} runs`, botHits === 0, `hits=${botHits} ${botNotes.join(" ; ")}`);
check("bot reached all five regions", reached.size === 5, [...reached].join(","));
check("bot travelled ≥ 5000 m", longest >= 5000, `longest=${longest.toFixed(0)}`);

// ───────────────────────── Collisions ─────────────────────────
section("Collisions & player rules");
{
  const g = makeGame("col1"); g.startRun("runner");
  g.world.injectObstacle({ type: "roadblock", z: 6, lane: 0 });
  let hp = g.player.health; for (let i = 0; i < 200 && g.player.health === hp; i++) g.step(1 / 60);
  check("walking into a roadblock costs a heart", g.player.health === hp - 1);
  check("hit enters stunned/invulnerable window", g.player.invulnTimer > 0);
}
{
  const g = makeGame("col2"); g.startRun("runner"); g.world.reset("col2");
  g.world.injectObstacle({ type: "barricade", z: 12, lane: 0 }); const hp = g.player.health;
  let jumped = false;
  for (let i = 0; i < 160; i++) { const o = g.world.getObstacles()[0]; if (o && !jumped && o.z < g.speed * 0.3) { g.input.inject("jump"); jumped = true; } g.step(1 / 60); }
  check("jumping clears a low barricade", g.player.health === hp);
}
{
  const g = makeGame("col3"); g.startRun("runner"); g.world.reset("col3");
  g.world.injectObstacle({ type: "low_beam", z: 12, lane: 0 }); const hp = g.player.health; let s = false;
  for (let i = 0; i < 160; i++) { const o = g.world.getObstacles()[0]; if (o && !s && o.z < g.speed * 0.2) { g.input.inject("slide"); s = true; } g.step(1 / 60); }
  check("sliding passes under a low beam", g.player.health === hp);
}
{
  const g = makeGame("col4"); g.startRun("runner"); g.world.reset("col4");
  g.world.injectObstacle({ type: "low_beam", z: 12, lane: 0 }); const hp = g.player.health;
  for (let i = 0; i < 160; i++) g.step(1 / 60);
  check("running into a low beam hurts", g.player.health < hp);
}
{
  const g = makeGame("col5"); g.progression.grantAll(); g.startRun("heavy"); g.world.reset("col5");
  check("Heavy has 4 hearts", g.player.maxHealth === 4);
  g.world.injectObstacle({ type: "crate", z: 8, lane: 0 }); const hp = g.player.health;
  for (let i = 0; i < 120; i++) g.step(1 / 60);
  check("Heavy smashes a low crate without damage", g.player.health === hp && g.player.smashCooldown > 0);
}
{
  const g = makeGame("col6"); g.progression.grantAll(); g.startRun("acrobat");
  g.input.inject("jump"); for (let i = 0; i < 8; i++) g.step(1 / 60);
  const y1 = g.player.y; g.input.inject("jump"); for (let i = 0; i < 4; i++) g.step(1 / 60);
  check("Acrobat double jump adds height", g.player.airJumpsUsed === 1 && g.player.vy > 5, `y1=${y1.toFixed(2)} vy=${g.player.vy.toFixed(2)}`);
}
{
  const g = makeGame("col7"); g.startRun("runner"); const j = g.player.jumpForce;
  g.progression.grantAll(); g.startRun("runner");
  g.input.inject("jump"); let peak = 0; for (let i = 0; i < 80; i++) { g.step(1 / 60); peak = Math.max(peak, g.player.y); }
  check("jump apex ≈ 2.4 m", peak > 2.1 && peak < 2.7, `peak=${peak.toFixed(2)}`);
}
{
  const g = makeGame("col8"); g.progression.grantAll(); g.startRun("ninja"); g.input.inject("slide"); g.step(1 / 60);
  check("Ninja slide grants brief invulnerability + lower hitbox", g.player.invulnTimer > 0 && g.player.height < 0.7, `h=${g.player.height}`);
}
{
  const g = makeGame("col9"); g.startRun("runner");
  const hp = g.player.maxHealth; for (let k = 0; k < hp; k++) { g.player.invulnTimer = 0; g.player.takeDamage(1); }
  check("death at 0 hearts", g.player.movementState === "dead");
}
{
  const st = new MemStorage(); const g = makeGame("unlk", st);
  check("fresh save: only Runner unlocked; air dash locked", g.progression.isCharacterUnlocked("runner") && !g.progression.isCharacterUnlocked("ninja") && !g.progression.getAbilityUnlocks().airDash);
  g.startRun("ninja");
  check("locked character falls back to Runner", g.player.characterId === "runner");
}

// ───────────────────────── Power-ups ─────────────────────────
section("Power-ups");
{
  const g = makeGame("pu"); g.startRun("runner"); g.world.reset("pu");
  const inject = (type: string) => { (g.world as any).collectibles.push({ id: "t" + type, type, x: 0, y: 1, z: 3, width: 1, height: 1, depth: 1, value: 0, lane: 0, magnetized: false }); };
  for (const t of ["shield", "magnet", "speed", "coinx2", "invuln", "slowmo", "scorex2"]) { inject(t); for (let i = 0; i < 30; i++) g.step(1 / 60); }
  check("shield adds a charge", g.player.shieldCharges >= 1);
  check("timed power-ups activate (magnet, coinx2, scorex2, slowmo)", g.powerups.magnet > 0 && g.powerups.coinx2 > 0 && g.powerups.scorex2 > 0 && g.powerups.slowmo > 0);
  check("speed boost + invulnerability active", g.powerups.speed > 0 && g.powerups.invuln > 0);
  const before = g.player.health; g.world.injectObstacle({ type: "roadblock", z: 5, lane: 0 }); for (let i = 0; i < 60; i++) g.step(1 / 60);
  check("invulnerability smashes through obstacles", g.player.health === before);
  check("slow motion lowers time scale", g.timeScale < 0.95, `ts=${g.timeScale.toFixed(2)}`);
  // coin multiplier
  const g2 = makeGame("pu2"); g2.startRun("runner"); g2.world.reset("pu2"); g2.powerups.coinx2 = 10;
  (g2.world as any).collectibles.push({ id: "c1", type: "coin", x: 0, y: 0.8, z: 2, width: 0.8, height: 0.8, depth: 0.8, value: 1, lane: 0, magnetized: false });
  for (let i = 0; i < 30; i++) g2.step(1 / 60);
  check("coin multiplier doubles coin value", g2.coins === 2, `coins=${g2.coins}`);
  // magnet
  const g3 = makeGame("pu3"); g3.startRun("runner"); g3.world.reset("pu3"); g3.powerups.magnet = 10;
  (g3.world as any).collectibles.push({ id: "c2", type: "coin", x: 2.4, y: 0.8, z: 8, width: 0.8, height: 0.8, depth: 0.8, value: 1, lane: 1, magnetized: false });
  for (let i = 0; i < 60; i++) g3.step(1 / 60);
  check("magnet pulls coins from the next lane", g3.coins >= 1);
}

// ───────────────────────── Events ─────────────────────────
section("Events");
{
  const g = makeGame("ev"); g.startRun("runner");
  const ok: string[] = [];
  for (const id of EVENT_IDS) { g.events.active = []; if (g.events.forceEvent(id, g)) ok.push(id); }
  check("all 13 events can be triggered", ok.length === EVENT_IDS.length, `${ok.length}`);
  g.events.active = [];
  g.events.forceEvent("rain", g); g.events.forceEvent("night", g); g.events.forceEvent("speed_surge", g);
  for (let i = 0; i < 60 * 5; i++) g.step(1 / 60);
  const a = g.events.atmosphere;
  check("rain + night events drive atmosphere", a.rain > 0.5 && a.night > 0.5, JSON.stringify(a));
  check("speed surge raises speed multiplier", g.events.getSpeedMultiplier() > 1.1);
  g.powerups.invuln = 9999; g.events.forceEvent("lightning_storm", g); let flashes = 0; g.events.onLightning = () => flashes++;
  for (let i = 0; i < 60 * 14; i++) g.step(1 / 60);
  check("lightning storm produces lightning flashes", flashes > 0, `flashes=${flashes}`);
  const f = g.events.getWorldFlags(); g.events.forceEvent("construction_collapse", g);
  check("collapse event sets debris flag", g.events.getWorldFlags().debris === true && f.debris === false);
  // events expire with game time (pause-safe: no setTimeout)
  const g2 = makeGame("ev2"); g2.startRun("runner"); g2.events.forceEvent("coin_rush", g2); g2.setPhase("paused");
  for (let i = 0; i < 600; i++) g2.frame(1 / 60);
  check("events do not tick while paused", g2.events.has("coin_rush"));
  g2.setPhase("running"); g2.powerups.invuln = 9999; for (let i = 0; i < 60 * 14; i++) g2.step(1 / 60);
  check("events expire after their duration", !g2.events.has("coin_rush"));
  // natural scheduling over a long bot run
  const g3 = makeGame("ev3"); g3.progression.grantAll(); g3.startRun("runner"); const bot = new Bot(g3);
  for (let i = 0; i < 60 * 240 && g3.phase === "running" && g3.distance < 4000; i++) { bot.act(); g3.step(1 / 60); }
  const names = new Set(g3.events.history.map((h) => h.id));
  check("director schedules events on its own", g3.events.history.length >= 6, `events=${g3.events.history.length}: ${[...names].join(",")}`);
}

// ───────────────────────── Rivals ─────────────────────────
section("Rivals");
{
  const g = makeGame("rv"); g.progression.grantAll(); g.startRun("runner"); const bot = new Bot(g);
  g.rivals.forceSpawn(g, "speed");
  let seenAhead = false, laneChanges = 0, lastLane = g.rivals.rival!.lane, coinsTaken = 0, anims = new Set<string>(), sides = 0;
  for (let i = 0; i < 60 * 90 && g.phase === "running"; i++) {
    bot.act(); g.step(1 / 60);
    const r = g.rivals.rival;
    if (r) { if (r.z > 5) seenAhead = true; if (r.lane !== lastLane) { laneChanges++; lastLane = r.lane; } coinsTaken = Math.max(coinsTaken, r.coins); anims.add(r.anim); }
  }
  check("rival runs ahead of the player", seenAhead);
  check("rival changes lanes on its own", laneChanges > 2, `changes=${laneChanges}`);
  check("rival collects coins from the world", coinsTaken > 0, `coins=${coinsTaken}`);
  check("rival uses several animation states", anims.size >= 2, [...anims].join(","));
  const pers = new Set<string>(); for (const p of ["aggressive", "cautious", "speed", "trick"] as const) { const g2 = makeGame("rvp" + p); g2.startRun("runner"); g2.rivals.forceSpawn(g2, p); pers.add(g2.rivals.rival!.name); }
  check("four rival personalities", pers.size === 4);
  check("overtakes are tracked", g.rivals.totalOvertakes >= 0 && g.rivals.totalSpawned >= 1);
}

// ───────────────────────── Missions & progression ─────────────────────────
section("Missions & progression persistence");
{
  const st = new MemStorage();
  const g = makeGame("pr", st); g.startRun("runner");
  const m0 = g.missions.getActive();
  check("3 active missions", m0.length === 3);
  g.missions.add("coins", 10); g.missions.add("distance", 400); g.missions.add("jumps", 5); g.missions.add("combo", 3);
  g.score = 4321; g.coinsF = 55; g.coins = 55; g.distance = 777; g.maxCombo = 9;
  g.endRun();
  check("results phase after run", g.phase === "results" && g.lastSummary!.score === 4321);
  const g2 = makeGame("pr2", st);
  check("high score persists across reload", g2.progression.getHighScore() === 4321);
  check("coin bank persists", g2.progression.getBank() >= 55);
  check("best distance persists", g2.progression.getBestDistance() === 777);
  const ma = g2.missions.getActive(); check("mission progress persists", ma.some((m) => m.progress > 0) || m0.every((m) => !["coins", "distance", "jumps"].includes(m.kind)));
  // purchase
  g2.progression.addCoins(5000);
  check("buy character with coins", g2.progression.buyCharacter("acrobat").ok && g2.progression.isCharacterUnlocked("acrobat"));
  check("cannot buy when poor", !makeGame("x").progression.buyCharacter("ninja").ok);
  check("buy upgrade", g2.progression.buyUpgrade("magnet").ok && g2.progression.getUpgradeLevel("magnet") === 1);
  const g3 = makeGame("pr3", st);
  check("unlocks + upgrades persist", g3.progression.isCharacterUnlocked("acrobat") && g3.progression.getUpgradeLevel("magnet") === 1);
  // ability unlocks by score
  const p = new ProgressionManager(new MemStorage()); p.recordRun({ score: 9000, distance: 1000, time: 60, maxCombo: 5, characterId: "runner", coins: 0, regionsReached: [0, 1], missionsCompleted: 0 });
  const ab = p.getAbilityUnlocks(); check("abilities unlock by score (airDash+wallRun at 9000)", ab.airDash && ab.wallRun && !ab.railGrind);
  check("regions discovered recorded", p.isRegionDiscovered(1) && !p.isRegionDiscovered(4));
  // corrupted save doesn't crash
  const bad = new MemStorage(); bad.setItem("nexus_runner_progress_v2", "{not json"); const pb = new ProgressionManager(bad); pb.load();
  check("corrupt save recovers to defaults", pb.getHighScore() === 0);
  // mission completes & pays
  const mm = new MissionManager(new MemStorage()); const first = mm.getActive()[0]; mm.add(first.kind, first.target + 1); mm.setBest(first.kind, first.target);
  check("mission completes and pays reward", mm.getCompletedCount() === 1 && mm.claimCompletedRewards() === first.reward);
  check("completed mission replaced by a new one", mm.getActive().length === 3 && mm.getCompletedCount() === 0);
}

// ───────────────────────── Regions & transitions ─────────────────────────
section("Region progression");
{
  const g = makeGame("rg"); g.progression.grantAll(); g.startRun("runner"); const bot = new Bot(g); const seen: string[] = [];
  g.world.onRegionChanged = (r) => { seen.push(r.id); };
  const orig = g.world.onRegionChanged;
  while (g.phase === "running" && g.distance < 4900) { bot.act(); g.step(1 / 60); }
  check("regions enter in order city → highway → subway → industrial → forest", ["highway", "subway", "industrial", "forest"].every((id, i) => seen[i] === id), seen.join(","));
  check("coins appear but no obstacles inside transition zone", (() => { const w = new WorldGenerator(); w.reset("tz"); w.enableRowLog(); const p = new Player(); p.reset("runner"); let d = 0; while (d < 3 * REGION_LENGTH) { const s = WorldGenerator.speedAt(d); w.update(1 / 30, { distance: d, speed: s, player: p }); d += s / 30; } return w.rowLog!.every((r) => ((r.absStart % REGION_LENGTH) + REGION_LENGTH) % REGION_LENGTH < REGION_LENGTH - 80 || r.absStart < 100); })());
}

// ───────────────────────── AUVYRR ─────────────────────────
section("AUVYRR bridge");
(async () => {
  const g = makeGame("au"); g.startRun("runner"); g.rivals.forceSpawn(g, "cautious"); for (let i = 0; i < 60; i++) g.step(1 / 60);
  const snap = auvyrrBridge.getLatestSnapshot()!;
  check("snapshot exposes player/character/region/distance/speed/score/health/stamina", !!snap && snap.player.characterId === "runner" && snap.world.regionId === "city_rooftops" && snap.run.distance > 0 && snap.run.speed > 0 && snap.player.health === 3 && snap.player.stamina > 0 && snap.run.score >= 0);
  check("snapshot exposes boost, events, rival, missions, progression", snap.boost.meter >= 0 && Array.isArray(snap.events.active) && snap.rival?.personality === "cautious" && snap.missions.length === 3 && Array.isArray(snap.progression.unlockedCharacters) && Array.isArray(snap.progression.unlockedRegions));
  const diag = auvyrrBridge.getDiagnostics();
  check("bridge reports NO real connection by default", diag.realConnection === false);
  const mk = (type: string, payload: any) => auvyrrBridge.submitCommand({ id: "t" + Math.random(), type: type as any, timestamp: 0, payload });
  let r: any = await mk("requestDifficultyAdjustment", { delta: 0.1 }); check("valid difficulty command accepted", r.success);
  r = await mk("requestDifficultyAdjustment", { delta: 5 }); check("out-of-range payload rejected", !r.success && /maximum/.test(r.reason));
  r = await mk("requestDifficultyAdjustment", { delta: "0.1" }); check("wrong type rejected", !r.success);
  r = await mk("requestDifficultyAdjustment", {}); check("missing field rejected", !r.success);
  r = await mk("deleteEverything", {}); check("unknown command type rejected", !r.success);
  r = await mk("requestEvent", { eventId: "nuke" }); check("unknown event id rejected", !r.success);
  r = await mk("requestEvent", { eventId: "coin_rush" }); check("valid event forced", r.success && g.events.has("coin_rush"), JSON.stringify(r));
  r = await mk("requestEvent", { eventId: "train_rush" }); check("event not valid for region rejected", !r.success);
  r = await mk("requestRivalBehavior", { personality: "trick" }); check("rival personality command", r.success && g.rivals.rival?.personality === "trick");
  r = await mk("requestReward", { coins: 100 }); check("reward within cap accepted", r.success);
  r = await mk("requestReward", { coins: 100000 }); check("reward above cap rejected", !r.success);
  r = await mk("requestTrainingScenario", { scenario: "jump" }); check("training scenario", r.success);
  r = await mk("suggestAction", { action: "jump" }); check("suggestAction only shows a hint (no control)", r.success && g.hint.includes("jump"));
  r = await mk("requestMission", { template: "coins100" }); check("mission template command", r.success);
  r = await mk("requestCoachingHint", {}); check("coaching hint", r.success && !!(r as any).result.hint);
  r = await mk("requestEvent", { eventId: "fog", __proto__: { evil: 1 }, extra: { nested: 1 } }); check("extra/nested payload keys dropped without crashing", r.success || /available|already/.test(r.reason));
  g.setPhase("menu"); r = await mk("requestEvent", { eventId: "fog" }); check("commands refused when no active run", !r.success);
  // transport loopback (in-process stand-in, NOT a real AUVYRR runtime)
  const sent: string[] = []; let handler: any = null;
  auvyrrBridge.attachTransport({ send: (d) => sent.push(d) }, (h) => { handler = h; });
  check("loopback transport marks connected", auvyrrBridge.isConnected());
  auvyrrBridge.emit({ type: "CUSTOM", runId: "x", payload: { hello: 1 } });
  check("events are forwarded to an attached transport", sent.some((s) => s.includes('"kind":"event"')));
  g.startRun("runner");
  handler({ data: JSON.stringify({ kind: "command", command: { id: "c1", type: "requestCoachingHint", timestamp: 0, payload: {} } }) });
  await new Promise((r2) => setTimeout(r2, 20));
  auvyrrBridge.detachTransport();
  check("detaching transport marks disconnected", !auvyrrBridge.isConnected());

  const ok = summary();
  process.exit(ok ? 0 : 1);
})();
