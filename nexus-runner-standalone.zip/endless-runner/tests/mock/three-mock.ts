/**
 * Minimal Three.js STAND-IN used only by the smoke tests (real three could not be installed offline).
 * It implements enough real maths/scene-graph behaviour to execute every render-layer code path
 * (Batch merging, chunk streaming, pooling, animation, camera rig, UI) but draws nothing.
 * It only validates MY code's internal consistency, not Three.js API correctness.
 */
export const AdditiveBlending = 2, NormalBlending = 1, BackSide = 1, DoubleSide = 2, FrontSide = 0, RepeatWrapping = 1000, ClampToEdgeWrapping = 1001, MirroredRepeatWrapping = 1002, DynamicDrawUsage = 35048, SRGBColorSpace = "srgb", LinearSRGBColorSpace = "srgb-linear", NoColorSpace = "", ACESFilmicToneMapping = 4, PCFSoftShadowMap = 2, LinearFilter = 1006, LinearMipmapLinearFilter = 1008, NearestFilter = 1003, UnsignedByteType = 1009, RGBAFormat = 1023, HalfFloatType = 1016;
export const stats = { meshes: 0, ctor: {} as Record<string, number> };
function count(n: string) { stats.ctor[n] = (stats.ctor[n] ?? 0) + 1; }

export class Vector2 { x = 0; y = 0; constructor(x = 0, y = 0) { this.x = x; this.y = y; } set(x: number, y: number) { this.x = x; this.y = y; return this; } }
export class Vector3 {
  constructor(public x = 0, public y = 0, public z = 0) {}
  set(x: number, y: number, z: number) { this.x = x; this.y = y; this.z = z; return this; } copy(v: Vector3) { return this.set(v.x, v.y, v.z); } clone() { return new Vector3(this.x, this.y, this.z); }
  add(v: Vector3) { this.x += v.x; this.y += v.y; this.z += v.z; return this; } multiplyScalar(s: number) { this.x *= s; this.y *= s; this.z *= s; return this; }
  normalize() { const l = Math.hypot(this.x, this.y, this.z) || 1; return this.multiplyScalar(1 / l); } setScalar(s: number) { return this.set(s, s, s); }
  fromBufferAttribute(a: BufferAttribute, i: number) { return this.set(a.getX(i), a.getY(i), a.getZ(i)); }
  applyMatrix4(m: Matrix4) { const e = m.elements, x = this.x, y = this.y, z = this.z; const w = 1 / (e[3] * x + e[7] * y + e[11] * z + e[15]); this.x = (e[0] * x + e[4] * y + e[8] * z + e[12]) * w; this.y = (e[1] * x + e[5] * y + e[9] * z + e[13]) * w; this.z = (e[2] * x + e[6] * y + e[10] * z + e[14]) * w; return this; }
  applyMatrix3(m: Matrix3) { const e = m.elements, x = this.x, y = this.y, z = this.z; this.x = e[0] * x + e[3] * y + e[6] * z; this.y = e[1] * x + e[4] * y + e[7] * z; this.z = e[2] * x + e[5] * y + e[8] * z; return this; }
}
export class Euler { constructor(public x = 0, public y = 0, public z = 0) {} set(x: number, y: number, z: number) { this.x = x; this.y = y; this.z = z; return this; } }
export class Quaternion {
  x = 0; y = 0; z = 0; w = 1;
  setFromEuler(e: Euler) { const c1 = Math.cos(e.x / 2), c2 = Math.cos(e.y / 2), c3 = Math.cos(e.z / 2), s1 = Math.sin(e.x / 2), s2 = Math.sin(e.y / 2), s3 = Math.sin(e.z / 2); this.x = s1 * c2 * c3 + c1 * s2 * s3; this.y = c1 * s2 * c3 - s1 * c2 * s3; this.z = c1 * c2 * s3 + s1 * s2 * c3; this.w = c1 * c2 * c3 - s1 * s2 * s3; return this; }
}
export class Matrix3 { elements = [1, 0, 0, 0, 1, 0, 0, 0, 1];
  getNormalMatrix(m: Matrix4) { const e = m.elements; const a = [e[0], e[1], e[2], e[4], e[5], e[6], e[8], e[9], e[10]]; const det = a[0] * (a[4] * a[8] - a[5] * a[7]) - a[3] * (a[1] * a[8] - a[2] * a[7]) + a[6] * (a[1] * a[5] - a[2] * a[4]) || 1; const inv = [(a[4] * a[8] - a[5] * a[7]), (a[2] * a[7] - a[1] * a[8]), (a[1] * a[5] - a[2] * a[4]), (a[5] * a[6] - a[3] * a[8]), (a[0] * a[8] - a[2] * a[6]), (a[2] * a[3] - a[0] * a[5]), (a[3] * a[7] - a[4] * a[6]), (a[1] * a[6] - a[0] * a[7]), (a[0] * a[4] - a[1] * a[3])].map((v) => v / det); this.elements = [inv[0], inv[3], inv[6], inv[1], inv[4], inv[7], inv[2], inv[5], inv[8]]; return this; } }
export class Matrix4 { elements = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
  compose(p: Vector3, q: Quaternion, s: Vector3) { const { x, y, z, w } = q; const x2 = x + x, y2 = y + y, z2 = z + z, xx = x * x2, xy = x * y2, xz = x * z2, yy = y * y2, yz = y * z2, zz = z * z2, wx = w * x2, wy = w * y2, wz = w * z2; this.elements = [(1 - (yy + zz)) * s.x, (xy + wz) * s.x, (xz - wy) * s.x, 0, (xy - wz) * s.y, (1 - (xx + zz)) * s.y, (yz + wx) * s.y, 0, (xz + wy) * s.z, (yz - wx) * s.z, (1 - (xx + yy)) * s.z, 0, p.x, p.y, p.z, 1]; return this; }
  multiply(m: Matrix4) { const a = this.elements, b = m.elements, r = new Array(16).fill(0); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) for (let k = 0; k < 4; k++) r[j * 4 + i] += a[k * 4 + i] * b[j * 4 + k]; this.elements = r; return this; }
  clone() { const m = new Matrix4(); m.elements = [...this.elements]; return m; } }
export class Color { r = 1; g = 1; b = 1;
  constructor(c?: any) { if (c !== undefined) this.set(c); }
  set(c: any) { if (typeof c === "number") return this.setHex(c); if (typeof c === "string" && c[0] === "#") return this.setHex(parseInt(c.slice(1), 16)); if (c && c.r !== undefined) { this.r = c.r; this.g = c.g; this.b = c.b; } return this; }
  setHex(h: number) { this.r = ((h >> 16) & 255) / 255; this.g = ((h >> 8) & 255) / 255; this.b = (h & 255) / 255; return this; }
  getHex() { return ((this.r * 255) << 16) | ((this.g * 255) << 8) | (this.b * 255 | 0); }
  copy(c: Color) { this.r = c.r; this.g = c.g; this.b = c.b; return this; } clone() { return new Color().copy(this); } setScalar(s: number) { this.r = this.g = this.b = s; return this; }
  lerp(c: Color, t: number) { this.r += (c.r - this.r) * t; this.g += (c.g - this.g) * t; this.b += (c.b - this.b) * t; return this; } multiplyScalar(s: number) { this.r *= s; this.g *= s; this.b *= s; return this; } }

export class BufferAttribute { constructor(public array: any, public itemSize: number) {} get count() { return this.array.length / this.itemSize; } needsUpdate = false;
  getX(i: number) { return this.array[i * this.itemSize]; } getY(i: number) { return this.array[i * this.itemSize + 1]; } getZ(i: number) { return this.array[i * this.itemSize + 2]; }
  setXY(i: number, x: number, y: number) { this.array[i * 2] = x; this.array[i * 2 + 1] = y; return this; } setUsage(_u: number) { return this; } }
export class Float32BufferAttribute extends BufferAttribute { constructor(a: number[], n: number) { super(Float32Array.from(a), n); } }
export class Uint16BufferAttribute extends BufferAttribute { constructor(a: number[], n: number) { super(Uint16Array.from(a), n); } }
export class Uint32BufferAttribute extends BufferAttribute { constructor(a: number[], n: number) { super(Uint32Array.from(a), n); } }
export class BufferGeometry { attributes: Record<string, BufferAttribute> = {}; index: BufferAttribute | null = null; groups: any[] = [];
  setAttribute(n: string, a: BufferAttribute) { this.attributes[n] = a; return this; } getAttribute(n: string) { return this.attributes[n]; } setIndex(i: BufferAttribute) { this.index = i; return this; } getIndex() { return this.index; }
  computeBoundingSphere() {} dispose() {} translate(_x: number, _y: number, _z: number) { return this; } rotateX(_a: number) { return this; } }
function gen(verts: number, tris: number, scale: number[]): BufferGeometry {
  const g = new BufferGeometry(); const p: number[] = [], n: number[] = [], u: number[] = [], idx: number[] = [];
  for (let i = 0; i < verts; i++) { const a = (i / verts) * Math.PI * 2; p.push(Math.cos(a) * scale[0], (i % 2) * scale[1], Math.sin(a) * scale[2]); n.push(0, 1, 0); u.push(i / verts, (i % 2)); }
  for (let t = 0; t < tris; t++) idx.push(t % verts, (t + 1) % verts, (t + 2) % verts);
  g.setAttribute("position", new Float32BufferAttribute(p, 3)); g.setAttribute("normal", new Float32BufferAttribute(n, 3)); g.setAttribute("uv", new Float32BufferAttribute(u, 2)); g.setIndex(new Uint16BufferAttribute(idx, 1)); return g;
}
export class BoxGeometry extends BufferGeometry { constructor(w = 1, h = 1, d = 1) { super(); const p: number[] = [], n: number[] = [], u: number[] = [], idx: number[] = [];
  for (let f = 0; f < 6; f++) { for (let i = 0; i < 4; i++) { const sx = i & 1 ? 0.5 : -0.5, sy = i & 2 ? 0.5 : -0.5; p.push(sx * w, sy * h, (f % 2 ? 0.5 : -0.5) * d); n.push(0, 0, f % 2 ? 1 : -1); u.push(i & 1, i >> 1); } const b = f * 4; idx.push(b, b + 1, b + 2, b + 2, b + 1, b + 3); }
  this.setAttribute("position", new Float32BufferAttribute(p, 3)); this.setAttribute("normal", new Float32BufferAttribute(n, 3)); this.setAttribute("uv", new Float32BufferAttribute(u, 2)); this.setIndex(new Uint16BufferAttribute(idx, 1)); } }
export class PlaneGeometry extends BufferGeometry { constructor(w = 1, h = 1) { super(); const g = new BoxGeometry(w, h, 0.0001); Object.assign(this, { attributes: g.attributes, index: g.index }); } }
const mk = (v: number, t: number) => class extends BufferGeometry { constructor(...a: any[]) { super(); const g = gen(v, t, [Number(a[0]) || 1, Number(a[1]) || 1, Number(a[0]) || 1]); this.attributes = g.attributes; this.index = g.index; } };
export class CylinderGeometry extends mk(20, 30) {} export class SphereGeometry extends mk(40, 60) {} export class IcosahedronGeometry extends mk(12, 20) {} export class TorusGeometry extends mk(30, 60) {}
export class CircleGeometry extends mk(18, 16) {} export class CapsuleGeometry extends mk(40, 60) {} export class OctahedronGeometry extends mk(6, 8) {} export class ExtrudeGeometry extends mk(24, 40) {}
export class Shape { moveTo(..._a: number[]) { return this; } lineTo(..._a: number[]) { return this; } bezierCurveTo(..._a: number[]) { return this; } closePath() { return this; } }

export class Texture { wrapS = 0; wrapT = 0; repeat = new Vector2(1, 1); offset = new Vector2(); colorSpace = ""; anisotropy = 1; needsUpdate = false; minFilter = 0; magFilter = 0; constructor(public image?: any) { count("Texture"); } dispose() {} }
export class CanvasTexture extends Texture {}
export class Material { transparent = false; opacity = 1; color = new Color(); needsUpdate = false; roughness = 1; envMapIntensity = 1; emissiveIntensity = 0; map: any = null; normalMap: any = null; uniforms: any = {}; side = 0; blending = 1; depthWrite = true; visible = true;
  constructor(p: any = {}) { Object.assign(this, p); if (p.color !== undefined) this.color = new Color(p.color); if (p.emissive !== undefined) (this as any).emissive = new Color(p.emissive); else (this as any).emissive = new Color(0); count("Material"); } dispose() {} clone() { return Object.assign(Object.create(Object.getPrototypeOf(this)), this); } }
export class MeshStandardMaterial extends Material {} export class MeshBasicMaterial extends Material {} export class SpriteMaterial extends Material {} export class LineBasicMaterial extends Material {}
export class ShaderMaterial extends Material { constructor(p: any = {}) { super(p); this.uniforms = p.uniforms ?? {}; } }
export const UniformsUtils = { clone: (u: any) => { const o: any = {}; for (const k of Object.keys(u)) { const v = u[k].value; o[k] = { value: v && v.clone ? v.clone() : v }; } return o; } };

export class Object3D { name = ""; children: Object3D[] = []; parent: Object3D | null = null; position = new Vector3(); rotation = new Euler(); scale = new Vector3(1, 1, 1); visible = true; userData: any = {}; castShadow = false; receiveShadow = false; renderOrder = 0; frustumCulled = true; layers: any;
  add(...o: Object3D[]) { for (const c of o) { if (!c) throw new Error("add(undefined)"); if (c.parent) c.parent.remove(c); c.parent = this; this.children.push(c); } return this; }
  remove(...o: Object3D[]) { for (const c of o) { const i = this.children.indexOf(c); if (i >= 0) { this.children.splice(i, 1); c.parent = null; } } return this; }
  traverse(f: (o: Object3D) => void) { f(this); for (const c of [...this.children]) c.traverse(f); }
  getObjectByName(n: string): Object3D | undefined { if (this.name === n) return this; for (const c of this.children) { const r = c.getObjectByName(n); if (r) return r; } return undefined; }
  clone(rec = true): this { const o: any = Object.create(Object.getPrototypeOf(this)); Object.assign(o, this); o.parent = null; o.position = this.position.clone(); o.rotation = new Euler(this.rotation.x, this.rotation.y, this.rotation.z); o.scale = this.scale.clone(); o.userData = { ...this.userData }; o.children = []; if (rec) for (const c of this.children) o.add(c.clone(true)); return o; }
  lookAt(..._a: any[]) {} rotateZ(a: number) { this.rotation.z += a; } updateMatrixWorld() {} }
export class Group extends Object3D {}
export class Scene extends Object3D { fog: any = null; background: any = null; environment: any = null; }
export class Mesh extends Object3D { constructor(public geometry: any = new BufferGeometry(), public material: any = new Material()) { super(); stats.meshes++; } }
export class InstancedMesh extends Mesh { count: number; instanceMatrix = new BufferAttribute(new Float32Array(16), 16); constructor(g: any, m: any, public max: number) { super(g, m); this.count = max; this.instanceMatrix = new BufferAttribute(new Float32Array(16 * max), 16); } instanceColor: BufferAttribute | null = null; setColorAt(i: number, c: Color) { if (!this.instanceColor) this.instanceColor = new BufferAttribute(new Float32Array(3 * this.max), 3); this.instanceColor.array.set([c.r, c.g, c.b], i * 3); }
  setMatrixAt(i: number, m: Matrix4) { if (i >= this.max) throw new Error("InstancedMesh overflow"); this.instanceMatrix.array.set(m.elements, i * 16); } }
export class Points extends Mesh {} export class LineSegments extends Mesh {} export class Sprite extends Object3D { constructor(public material: any) { super(); } }
export class Camera extends Object3D {} export class PerspectiveCamera extends Camera { constructor(public fov = 50, public aspect = 1, public near = 0.1, public far = 1000) { super(); } updateProjectionMatrix() {} }
export class OrthographicCamera extends Camera { left = 0; right = 0; top = 0; bottom = 0; near = 0; far = 0; updateProjectionMatrix() {} }
export class Fog { color = new Color(); constructor(c: number, public near: number, public far: number) { this.color.setHex(c); } }
export class HemisphereLight extends Object3D { color = new Color(); groundColor = new Color(); intensity = 1; constructor(a?: number, b?: number, i = 1) { super(); if (a !== undefined) this.color.setHex(a); if (b !== undefined) this.groundColor.setHex(b); this.intensity = i; } }
export class DirectionalLight extends Object3D { color = new Color(); intensity = 1; target = new Object3D(); shadow = { mapSize: new Vector2(), camera: new OrthographicCamera(), bias: 0, normalBias: 0, radius: 0, map: null as any }; constructor(c?: number, i = 1) { super(); if (c !== undefined) this.color.setHex(c); this.intensity = i; } }
export class PointLight extends Object3D { color = new Color(); constructor(c?: number, public intensity = 1, public distance = 0, public decay = 2) { super(); } }
export class WebGLRenderTarget { texture = {}; dispose() {} }
export class PMREMGenerator { constructor(_r: any) {} fromScene(_s: any, _sigma?: number) { return new WebGLRenderTarget(); } dispose() {} }
export class WebGLRenderer {
  shadowMap = { enabled: false, type: 0 }; toneMapping = 0; toneMappingExposure = 1; outputColorSpace = ""; info = { render: { calls: 0, triangles: 0 } }; private pr = 1; frames = 0;
  constructor(public p: any) {} setPixelRatio(v: number) { this.pr = v; } getPixelRatio() { return this.pr; } setSize(_w: number, _h: number, _s?: boolean) {} setClearColor(_c: any) {} getContext() { return null; } getSize(v: Vector2) { v.x = 800; v.y = 400; return v; } dispose() {}
  render(scene: Scene, camera: Camera) { this.frames++; let calls = 0, tris = 0; scene.traverse((o: any) => { if (o.isMesh !== false && o instanceof Mesh && o.visible) { let v = true; for (let p: any = o; p; p = p.parent) if (!p.visible) { v = false; break; } if (v) { calls++; tris += (o.geometry.index?.count ?? 0) / 3; } } }); this.info.render.calls = calls; this.info.render.triangles = tris; void camera; } }
