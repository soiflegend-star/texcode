// Stub for three/examples post-processing (smoke test only). Records that bloom setup was attempted.
export class EffectComposer { passes: any[] = []; constructor(public r: any, public rt?: any) {} addPass(p: any) { this.passes.push(p); } render(_dt?: number) { (globalThis as any).__bloomFrames = ((globalThis as any).__bloomFrames ?? 0) + 1; } setSize() {} setPixelRatio() {} dispose() {} }
export class RenderPass { constructor(..._a: any[]) {} }
export class OutputPass { constructor(..._a: any[]) {} }
export class UnrealBloomPass { strength = 0; resolution = { set() {} }; constructor(..._a: any[]) {} }
