// Playwright smoke test: loads the real UI + game + render layer (with the Three.js stand-in) in headless Chromium.
const { chromium } = await import("playwright").catch(() => import("/opt/npm-tools/node_modules/playwright/index.mjs"));
const esb = await import("esbuild").catch(() => import("/opt/npm-tools/node_modules/esbuild/lib/main.js"));
const { build } = esb;
import fs from "node:fs"; import path from "node:path";
const out = path.resolve("test-output"); fs.mkdirSync(out, { recursive: true });
await build({ entryPoints: ["src/main.ts"], bundle: true, format: "iife", platform: "browser", outfile: out + "/main.js", alias: { three: path.resolve("tests/mock/three-mock.ts"), ...Object.fromEntries(["EffectComposer","RenderPass","UnrealBloomPass","OutputPass"].map((m) => [`three/examples/jsm/postprocessing/${m}.js`, path.resolve("tests/mock/examples-stub.ts")])) }, logLevel: "error", target: "es2022" });
fs.writeFileSync(out + "/index.html", fs.readFileSync("index.html", "utf8").replace('./src/ui/ui.css', "ui.css").replace('<script type="module" src="./src/main.ts"></script>', '<script src="main.js"></script>'));
fs.copyFileSync("src/ui/ui.css", out + "/ui.css");
const results = []; const ok = (n, c, d = "") => { results.push({ n, c: !!c }); console.log((c ? "  ✔ " : "  ✘ ") + n + (c ? "" : "  " + d)); };
const browser = await chromium.launch(); const errors = [];
const page = await browser.newPage({ viewport: { width: 844, height: 390 }, hasTouch: true, isMobile: true, deviceScaleFactor: 2 });
page.on("pageerror", (e) => errors.push("pageerror: " + e.message)); page.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
await page.goto("file://" + out + "/index.html"); await page.waitForFunction(() => window.game && window.scene3d, null, { timeout: 15000 });
await page.waitForTimeout(800);
const ev = (f, a) => page.evaluate(f, a);
ok("boots with 3D scene (mock) and menu phase", await ev(() => !!window.scene3d && window.game.phase === "menu"));
await page.screenshot({ path: out + "/01_menu.png" });
for (const [scr, act] of [["characterSelect", "char"], ["missions", "missions"], ["progress", "progress"], ["settings", "settings"]]) {
  await page.click(`[data-act="${act}"]`); await page.waitForTimeout(250);
  ok(`screen ${scr} opens`, await ev((s) => window.game.phase === s, scr)); await page.screenshot({ path: out + `/02_${scr}.png` });
  if (scr === "characterSelect") for (const id of ["acrobat", "speedster", "heavy", "ninja", "runner"]) { await page.click(`[data-act="pick"][data-arg="${id}"]`); await page.waitForTimeout(150); await page.screenshot({ path: out + `/02_char_${id}.png` }); }
  await page.click('[data-act="back"]'); await page.waitForTimeout(150);
}
// every character plays the run (unlock all first)
await ev(() => window.game.progression.grantAll());
let frames = 0;
for (const id of ["runner", "acrobat", "speedster", "heavy", "ninja"]) {
  const r = await ev(async (id) => { const g = window.game; g.progression.setSelectedCharacter(id); g.startRun(id); g.player.invulnTimer = 999; for (let i = 0; i < 240; i++) g.frame(1 / 60); return { phase: g.phase, dist: g.distance, id: g.player.characterId }; }, id);
  ok(`run as ${id} simulates + renders 240 frames`, r.phase === "running" && r.dist > 20 && r.id === id, JSON.stringify(r));
  await ev(() => window.game.endRun(true));
}
// all five regions
const regionStats = [];
await ev(() => { const g = window.game; g.startRun("runner"); g.player.invulnTimer = 1e9; });
for (let r = 0; r < 5; r++) {
  const s = await ev(async (r) => { const g = window.game; g.debugJumpToRegion(r); g.player.invulnTimer = 1e9; for (let i = 0; i < 180; i++) { g.frame(1 / 60); g.player.health = g.player.maxHealth; } return { region: g.world.currentRegionId, chunks: window.scene3d.stats.chunks, calls: window.scene3d.stats.drawCalls, obstacles: window.scene3d.stats.obstacles, lib: window.scene3d.chunkLib.stats() }; }, r);
  regionStats.push(s); ok(`region ${r} (${s.region}) streams chunks and draws`, s.chunks >= 5 && s.calls > 5, JSON.stringify(s)); await page.screenshot({ path: out + `/03_run_region${r}.png` });
}
// transitions: run through the end of each region
const tr = await ev(async () => { const g = window.game; const res = []; for (let r = 0; r < 5; r++) { g.distance = r * 960 + 880; g.world.jumpToDistance(g.distance); for (let i = 0; i < 400; i++) { g.frame(1 / 60); g.player.health = g.player.maxHealth; } res.push(Math.floor(g.distance / 960)); } return res; });
ok("transition zones simulate+render without errors", tr.length === 5, JSON.stringify(tr));
// quality tiers
for (const q of ["LOW", "MEDIUM", "HIGH", "ULTRA", "AUTO"]) { const r = await ev(async (q) => { window.scene3d.setQuality(q); const g = window.game; for (let i = 0; i < 60; i++) g.frame(1 / 60); return { label: window.scene3d.qualityLabel, chunks: window.scene3d.stats.chunks }; }, q); ok(`quality ${q} applies and renders`, r.label.includes(q === "AUTO" ? "AUTO" : q) && r.chunks > 0, JSON.stringify(r)); }
// events/weather forced
const evs = await ev(async () => { const g = window.game; const ids = ["rain", "night", "sunset", "fog", "lightning_storm", "heavy_traffic", "drone_pursuit", "coin_rush", "speed_surge", "rival_chase", "road_closure", "construction_collapse"]; let n = 0; for (const id of ids) { try { g.events.forceEvent?.(id, g); } catch {} for (let i = 0; i < 90; i++) { g.frame(1 / 60); g.player.health = g.player.maxHealth; } n++; } return n; });
ok("event/weather atmosphere frames render", evs > 0);
await page.screenshot({ path: out + "/04_run_event.png" });
// controls + pause + death/results
await page.click('[data-ctl="jump"]').catch(() => {}); await page.click('[data-ctl="slide"]').catch(() => {});
await ev(() => window.game.togglePause()); await page.waitForTimeout(200); ok("pause shows pause sheet", await ev(() => window.game.phase === "paused" && !!document.querySelector('[data-act="resume"]'))); await page.screenshot({ path: out + "/05_pause.png" });
await page.click('[data-act="resume"]', { force: true }); await ev(() => { const g = window.game; g.player.invulnTimer = 0; g.player.health = 1; });
await ev(async () => { const g = window.game; for (let i = 0; i < 4000 && g.phase === "running"; i++) { g.player.invulnTimer = 0; g.world.injectObstacle?.({ type: "roadblock", lane: g.player.lane, z: 3 }); g.frame(1 / 30); } });
await page.waitForTimeout(300); ok("death leads to results screen", await ev(() => window.game.phase === "results")); await page.screenshot({ path: out + "/06_results.png" });
await page.click('[data-act="menu"]', { force: true }); 
// phone portrait layout
await page.setViewportSize({ width: 390, height: 844 }); await page.waitForTimeout(200);
await ev(() => { const g = window.game; g.startRun("runner"); g.player.invulnTimer = 1e9; for (let i = 0; i < 120; i++) g.frame(1 / 60); });
await page.screenshot({ path: out + "/07_portrait_run.png" });
const ov = await ev(() => { const r = (sel) => document.querySelector(sel)?.getBoundingClientRect(); const a = r(".hud-tl .stats"), b = r(".hud-tc"), c = r(".hud-tr"); const hit = (x, y) => !(x.right < y.left || y.right < x.left || x.bottom < y.top || y.bottom < x.top); return { stats_mission: hit(a, b), mission_right: hit(b, c), w: innerWidth }; });
ok("portrait HUD: top-center mission pill does not overlap left or right clusters", !ov.stats_mission && !ov.mission_right, JSON.stringify(ov));
await ev(() => window.game.endRun(true)); await page.waitForTimeout(150); await page.screenshot({ path: out + "/07_portrait_menu.png" });
await page.click('[data-act="char"]', { force: true }); await page.waitForTimeout(200); await page.screenshot({ path: out + "/07_portrait_char.png" });
// 2D fallback still boots without WebGL scene
ok("no uncaught page errors", errors.length === 0, errors.slice(0, 5).join(" | "));
console.log(JSON.stringify({ regionStats }, null, 0).slice(0, 1200));
await browser.close();
const failed = results.filter((r) => !r.c).length; console.log(`\n${results.length - failed} passed, ${failed} failed`); process.exit(failed ? 1 : 0);
