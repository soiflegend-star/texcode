// Generates a LOOSE type shim for "three" (every referenced class is `any`-indexable) so `tsc --noEmit`
// can type-check all project code that is NOT Three.js-specific when @types/three cannot be installed.
// It cannot validate Three.js API usage; use the real @types/three (`npm run typecheck`) for that.
import fs from "node:fs"; import path from "node:path";
const names = new Set();
(function walk(d) { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, f.name); if (f.isDirectory()) walk(p); else if (/\.ts$/.test(f.name)) { const s = fs.readFileSync(p, "utf8"); for (const m of s.matchAll(/THREE\.([A-Za-z0-9_]+)/g)) names.add(m[1]); } } })("src");
const consts = /^(HalfFloatType|AdditiveBlending|NormalBlending|BackSide|DoubleSide|FrontSide|RepeatWrapping|ClampToEdgeWrapping|MirroredRepeatWrapping|DynamicDrawUsage|SRGBColorSpace|LinearSRGBColorSpace|ACESFilmicToneMapping|PCFSoftShadowMap|LinearFilter|LinearMipmapLinearFilter|NearestFilter|UnsignedByteType|RGBAFormat)$/;
let out = "declare module \"three\" {\n";
for (const n of [...names].sort()) {
  if (consts.test(n)) out += `  export const ${n}: number;\n`;
  else if (/Parameters$/.test(n)) out += `  export type ${n} = any;\n`;
  else if (n === "UniformsUtils") out += `  export const UniformsUtils: any;\n`;
  else out += `  export class ${n} { [k: string]: any; constructor(...a: any[]); }\n`;
}
out += "}\n";
for (const m of ["EffectComposer", "RenderPass", "UnrealBloomPass", "OutputPass"]) out += `declare module "three/examples/jsm/postprocessing/${m}.js" { export class ${m} { [k: string]: any; constructor(...a: any[]); } }\n`;
fs.writeFileSync(process.argv[2] ?? "tools/three-shim.d.ts", out);
console.log("shim names:", names.size);
