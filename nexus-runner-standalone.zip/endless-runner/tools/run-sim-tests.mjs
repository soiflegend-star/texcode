import { execFileSync } from "node:child_process"; import fs from "node:fs";
fs.mkdirSync(".tmp", { recursive: true });
execFileSync("node", ["tools/bundle-tests.mjs", "tests/core.test.ts", ".tmp/core.test.mjs"], { stdio: "inherit" });
execFileSync("node", [".tmp/core.test.mjs"], { stdio: "inherit" });
