// Bundles test entry points with esbuild (TypeScript -> ESM) so they run in plain node.
const esb = await import("esbuild").catch(() => import("/opt/npm-tools/node_modules/esbuild/lib/main.js"));
const { build } = esb;
import path from "node:path";
const [,, entry, out, ...rest] = process.argv;
const alias = {};
if (rest.includes("--mock-three")) alias["three"] = path.resolve("tests/mock/three-mock.ts");
await build({ entryPoints: [entry], bundle: true, platform: rest.includes("--browser") ? "browser" : "node", format: rest.includes("--browser") ? "iife" : "esm", outfile: out, alias, logLevel: "error", sourcemap: false, target: "es2022", banner: rest.includes("--browser") ? {} : { js: "import {createRequire} from 'module';const require=createRequire(import.meta.url);" } });
