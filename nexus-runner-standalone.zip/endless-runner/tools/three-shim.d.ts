declare module "three" {
  export const ACESFilmicToneMapping: number;
  export const AdditiveBlending: number;
  export const BackSide: number;
  export class BoxGeometry { [k: string]: any; constructor(...a: any[]); }
  export class BufferAttribute { [k: string]: any; constructor(...a: any[]); }
  export class BufferGeometry { [k: string]: any; constructor(...a: any[]); }
  export class Camera { [k: string]: any; constructor(...a: any[]); }
  export class CanvasTexture { [k: string]: any; constructor(...a: any[]); }
  export class CapsuleGeometry { [k: string]: any; constructor(...a: any[]); }
  export class CircleGeometry { [k: string]: any; constructor(...a: any[]); }
  export const ClampToEdgeWrapping: number;
  export class Color { [k: string]: any; constructor(...a: any[]); }
  export class CylinderGeometry { [k: string]: any; constructor(...a: any[]); }
  export class DirectionalLight { [k: string]: any; constructor(...a: any[]); }
  export const DoubleSide: number;
  export const DynamicDrawUsage: number;
  export class Euler { [k: string]: any; constructor(...a: any[]); }
  export class ExtrudeGeometry { [k: string]: any; constructor(...a: any[]); }
  export class Float32BufferAttribute { [k: string]: any; constructor(...a: any[]); }
  export class Fog { [k: string]: any; constructor(...a: any[]); }
  export class Group { [k: string]: any; constructor(...a: any[]); }
  export const HalfFloatType: number;
  export class HemisphereLight { [k: string]: any; constructor(...a: any[]); }
  export class IcosahedronGeometry { [k: string]: any; constructor(...a: any[]); }
  export class InstancedMesh { [k: string]: any; constructor(...a: any[]); }
  export class LineBasicMaterial { [k: string]: any; constructor(...a: any[]); }
  export class LineSegments { [k: string]: any; constructor(...a: any[]); }
  export const LinearMipmapLinearFilter: number;
  export class Material { [k: string]: any; constructor(...a: any[]); }
  export class Matrix3 { [k: string]: any; constructor(...a: any[]); }
  export class Matrix4 { [k: string]: any; constructor(...a: any[]); }
  export class Mesh { [k: string]: any; constructor(...a: any[]); }
  export class MeshBasicMaterial { [k: string]: any; constructor(...a: any[]); }
  export class MeshStandardMaterial { [k: string]: any; constructor(...a: any[]); }
  export type MeshStandardMaterialParameters = any;
  export class NoColorSpace { [k: string]: any; constructor(...a: any[]); }
  export const NormalBlending: number;
  export class Object3D { [k: string]: any; constructor(...a: any[]); }
  export class OctahedronGeometry { [k: string]: any; constructor(...a: any[]); }
  export class OrthographicCamera { [k: string]: any; constructor(...a: any[]); }
  export const PCFSoftShadowMap: number;
  export class PMREMGenerator { [k: string]: any; constructor(...a: any[]); }
  export class PerspectiveCamera { [k: string]: any; constructor(...a: any[]); }
  export class PlaneGeometry { [k: string]: any; constructor(...a: any[]); }
  export class PointLight { [k: string]: any; constructor(...a: any[]); }
  export class Points { [k: string]: any; constructor(...a: any[]); }
  export class Quaternion { [k: string]: any; constructor(...a: any[]); }
  export const RepeatWrapping: number;
  export const SRGBColorSpace: number;
  export class Scene { [k: string]: any; constructor(...a: any[]); }
  export class ShaderMaterial { [k: string]: any; constructor(...a: any[]); }
  export class Shape { [k: string]: any; constructor(...a: any[]); }
  export class SphereGeometry { [k: string]: any; constructor(...a: any[]); }
  export class Sprite { [k: string]: any; constructor(...a: any[]); }
  export class SpriteMaterial { [k: string]: any; constructor(...a: any[]); }
  export class Texture { [k: string]: any; constructor(...a: any[]); }
  export class TorusGeometry { [k: string]: any; constructor(...a: any[]); }
  export class Uint16BufferAttribute { [k: string]: any; constructor(...a: any[]); }
  export class Uint32BufferAttribute { [k: string]: any; constructor(...a: any[]); }
  export const UniformsUtils: any;
  export class Vector2 { [k: string]: any; constructor(...a: any[]); }
  export class Vector3 { [k: string]: any; constructor(...a: any[]); }
  export class WebGLRenderTarget { [k: string]: any; constructor(...a: any[]); }
  export class WebGLRenderer { [k: string]: any; constructor(...a: any[]); }
}
declare module "three/examples/jsm/postprocessing/EffectComposer.js" { export class EffectComposer { [k: string]: any; constructor(...a: any[]); } }
declare module "three/examples/jsm/postprocessing/RenderPass.js" { export class RenderPass { [k: string]: any; constructor(...a: any[]); } }
declare module "three/examples/jsm/postprocessing/UnrealBloomPass.js" { export class UnrealBloomPass { [k: string]: any; constructor(...a: any[]); } }
declare module "three/examples/jsm/postprocessing/OutputPass.js" { export class OutputPass { [k: string]: any; constructor(...a: any[]); } }
