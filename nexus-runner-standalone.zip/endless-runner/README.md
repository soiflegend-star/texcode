# Nexus Runner

Mobile-first 3D endless runner (Three.js + TypeScript + Vite). Procedural everything: no external art, audio or model files.

```bash
npm install
npm run dev          # http://localhost:5173
npm run build        # production bundle in dist/
npm run typecheck    # strict tsc against real @types/three
npm test             # 90 headless simulation checks
npm run test:smoke   # Playwright UI/render-path smoke test (uses a Three.js stand-in, see docs/VERIFICATION_REPORT.md)
```

## Run it / deploy it
```bash
npm install && npm run dev        # open the printed URL; on a phone use the "Network" URL (same Wi-Fi)
npm run build && npm run preview  # production build on :4173
npm run typecheck                 # strict, real @types/three
npm test                          # 90 simulation checks
npm run test:gpu                  # REAL Three.js + real WebGL check; writes real screenshots to docs/screenshots/ (HEADED=1 for your GPU)
```
**GitHub Pages:** push to `main`; `.github/workflows/pages.yml` type-checks, tests, builds and deploys (Settings → Pages → Source: GitHub Actions). `base: "./"` makes the build work under a project sub-path.
**Phone:** add `?auvyrr=off` to disable the optional AUVYRR bridge entirely (it is already a no-op with no transport). Installable/fullscreen via the web manifest; screen stays awake while playing; layouts verified in landscape (844×390) and portrait (390×844).
Screenshots: none are committed on purpose — run `npm run test:gpu` to produce real ones.

**READ THIS FIRST:** the simulation, fairness, persistence and AUVYRR bridge were tested for real. The WebGL visuals were written and exercised *only against a stand-in for Three.js* because this project was built in an environment without network access (Three.js could not be installed). Expect to spend a first session tuning how it looks on a real GPU. See `docs/VERIFICATION_REPORT.md` for the exact status of every feature.

## What is in the game
- 5 characters (Runner, Acrobat, Speedster, Heavy, Ninja): different proportions, clothing, accessories, stats, abilities and procedural animation personality; 17 animation states.
- 5 regions with 5 scenery variants each, mirrored + landmarks + 5 physical transitions (skybridge, underpass, station gate, collapsed gate, ancient arch).
- Seeded procedural track with a fairness model; 24 obstacle types; 7 power-ups; boost pads, rails, coins.
- Movement: lanes, jump, double jump (Acrobat), slide, air dash, wall run, rail grind, grapple, boost — advanced moves unlock by score.
- Rival with 4 personalities, 13 world events (weather, time of day, hazards, boons), missions, upgrades, persistent save.
- Quality tiers LOW/MEDIUM/HIGH/ULTRA + AUTO (device hint + downward FPS governor).
- AUVYRR bridge: schema-validated commands and state snapshots (no real AUVYRR runtime is bundled).

## Controls
Touch: swipe left/right/up/down, or the JUMP / SLIDE buttons; ⚡ boost when the meter is full. Keyboard: ←/→ or A/D, ↑/Space, ↓/S, Shift boost, E grapple, P/Esc pause.

## Layout
`src/data` static data · `src/movement` player · `src/world` generation (`Solvability`, `ChunkPlan`, `WorldGenerator`) · `src/events`, `src/progression` · `src/render` scenery, characters, particles, materials · `src/core` Game, Scene3D · `src/ui` HUD and menus · `src/auvyrr` · `tests/` · `docs/`.
Docs: `docs/ARCHITECTURE.md`, `docs/AUVYRR_INTEGRATION.md`, `docs/VERIFICATION_REPORT.md`, `docs/COMPLETION_REPORT.md`.
