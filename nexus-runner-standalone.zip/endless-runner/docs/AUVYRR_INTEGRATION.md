# AUVYRR integration

**Status: bridge implemented and tested against a loopback transport. A real AUVYRR runtime was NOT provided and was NOT tested.** `getDiagnostics().realConnection` is `false` until a transport is attached and marks itself connected.

- `src/auvyrr/AuvyrrBridge.ts`: emits events (RUN_STARTED, RUN_ENDED, ABILITY_USED, …), builds `GameStateSnapshot` (player, movement state, stamina, combo, flow, world/hazards/rewards/events, rival), accepts commands.
- Commands are schema-validated (type, payload fields, ranges, unknown keys dropped); refused when no run is active; invalid commands are rejected with a reason, never executed.
- `suggestAction` is a hint only; it never moves the player.
- Attach a transport: `auvyrrBridge.attachTransport({ send(msg){}, onMessage(cb){} })`. Tested: events forwarded, connect/disconnect state, malformed payloads.
- Not done: authentication, network protocol, reconnect policy — define these against the real runtime.
