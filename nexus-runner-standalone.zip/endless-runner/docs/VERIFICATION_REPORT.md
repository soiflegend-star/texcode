# Verification report

Legend: **(1)** implemented and tested · **(2)** implemented, needs external assets/runtime to verify · **(3)** fallback/procedural · **(4)** not implemented.

## How things were tested
- `npm test` — 90 headless checks on the real simulation (Game with `headless:true`): determinism, fairness audit of generated rows, DP bot playthrough with all 5 characters across regions (0 hits), abilities gating, power-ups, events, rival, missions, persistence, AUVYRR validation + loopback. All pass.
- `npm run test:smoke` — 25 checks in headless Chromium: real DOM/CSS/UI, real Game, real render-layer code **with a stand-in for Three.js** (`tests/mock/three-mock.ts`: real vector/matrix maths and scene graph, geometry crude, no drawing). Covers menu, all screens, all 5 characters running, all 5 regions + transitions, 5 quality tiers, 12 events, pause, death→results, no uncaught errors. UI screenshots were inspected; 3D screenshots are blank by construction.
- `typecheck:loose` — tsc strict on all code with a loose Three shim: clean. Does not validate Three.js API usage.

## (1) Implemented and tested
Simulation, movement states and ability gating, seeded world + fairness, 24 obstacle definitions (collision sizes), power-ups logic, events logic, rival logic, missions/upgrades, save/load, AUVYRR validation, HUD and all menu screens (layout inspected at 844×390 landscape), pause/results flow, quality switching code path, chunk streaming/pooling code path, boost pad pickup.
## (2) Implemented, needs a real GPU / Three.js to verify
Every visual: scenery for the 5 regions and transitions, characters and their 17 animation poses, obstacle/power-up models, lighting/shadows/fog/sky/clouds, particles, rain, camera feel, colours matching the reference image, true draw-call counts and frame rate. Stand-in draw-call count was 100–177 meshes per frame (before frustum culling) — the "~100" target is **unconfirmed**. Mirrored chunks rely on negative-scale handling by Three.js. Quality AUTO thresholds are heuristics, not benchmarks. Material keys were audited (a missing key was found and fixed by the smoke test).
## (3) Fallback / procedural
All textures (canvas), normal maps (CPU), audio (WebAudio synthesis), characters/props (primitives, no GLB), skyline backdrop (texture), clouds (sprites), "bloom" (CSS vignette/grade + additive glow sprites, no real post-processing), 2D canvas renderer if WebGL fails.
## (4) Not implemented
GLB models/real textures/audio files; real post-processing bloom/SSAO; ambient traffic vehicles (only birds); aircraft; reflections beyond the PMREM sky probe; automatic antialias change without reload (needs a page reload); real AUVYRR runtime; gamepad support; localisation; accessibility options beyond vibration/sound toggles.

## Phase 2 (visual max-out + standalone) — added honestly
**Still true:** this was authored in an environment with no network, so the real `three` package was never loaded here. Nothing below was seen on a GPU. `npm run test:gpu` (real Three.js, real WebGL, real screenshots) exists for YOU to run; its results are the first real verification.
**(2) Added, unverified on GPU:** UnrealBloom post-processing on HIGH/ULTRA (`src/render/Post.ts`, falls back to plain rendering if it throws; MSAA render target); distant traffic (instanced cars with head/tail lights, rooftops/highway/industrial) and blinking drones (`Ambient.ts`); rim light on characters; additive light shafts (Ruins + sunset); emissive flicker (strong in subway, storms); camera response: near-miss FOV kick, landing dip, jump lift, rail lowering, region-transition FOV widen.
**(1) Added and tested (stand-in renderer + real DOM):** portrait phone HUD with no overlaps (found and fixed an overlap via the test), landscape layout, PWA manifest/meta, `?auvyrr=off`, GitHub Pages workflow file, optional AUVYRR bridge (`setEnabled`), Vite `base: "./"`. Smoke test now 26 checks. The GitHub workflow itself was never executed.
**(4) Requested but NOT done:** holographic ads, animated building windows beyond the night glow, moving trains in tunnel background, sunrise highway variant, vegetation sway, per-instance building variation, redesigned characters (unchanged from phase 1), a visual polish pass on real renders (impossible without seeing them), measured performance numbers, real screenshots.
