# Architecture

**Principle:** the simulation is pure TypeScript and runs headless; rendering only reads it.

```
main.ts ──► Game (orchestrator, headless-capable)
              ├ Player (movement states, abilities)         src/movement
              ├ WorldGenerator (+Solvability, ChunkPlan)     src/world
              ├ EventDirector / RivalManager                 src/events
              ├ ProgressionManager / MissionManager          src/progression
              ├ InputManager, AudioManager (WebAudio, procedural)
              ├ AuvyrrBridge (schema-validated commands)     src/auvyrr
              └ Scene3D? (optional)  ◄── reads Game each frame
                   ├ Environment (sky, lights, fog, themes, PMREM probe)
                   ├ ChunkLibrary → Regions/Props (merged geometry per material, cloned + mirrored)
                   ├ CharacterFactory + CharacterAnimator
                   ├ Models (obstacles, power-ups, coins instanced, rails, pads)
                   ├ Particles (pooled point sprites, speed lines, rain)
                   └ Quality (detect + FPS governor)
UI (DOM overlay): HUD + menus, reads Game, writes via public APIs.
```
**Coordinates:** player fixed at sim z=0, the world scrolls toward it; scene z = −sim z.
**Determinism:** every random decision derives from the run seed (mulberry32). `ChunkPlan` gives each 60 m chunk its variant/mirror/landmark; a region is 16 chunks (960 m), the last chunk is a transition.
**Fairness:** obstacles are emitted as rows; `Solvability` guarantees a reachable lane path with time-gap spacing ≥0.85 s (derated for speed surges); no obstacles in transition zones.
**Performance design:** scenery merged per material with vertex-colour AO; templates built lazily (one prewarmed per frame), instances are clones sharing geometry; obstacle/power-up pools; coins in one InstancedMesh; particle pools preallocated; chunks streamed `chunksAhead` by tier.
**Assets:** none external. Procedural canvas textures + CPU normal maps. A real GLB/texture pipeline would plug in at `MaterialLibrary` (maps) and `CharacterFactory` (replace rig) — not implemented.
