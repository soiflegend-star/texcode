package com.texgen.music.texwave.ui.ref

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R

/** Clean launch screen: logo, wordmark, one thin progress line. ~1.6 s. */
@Composable
fun RefSplashScreen(onFinished: () -> Unit) {
    val done = rememberUpdatedState(onFinished)
    val reveal = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { reveal.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(1500, easing = FastOutSlowInEasing))
        kotlinx.coroutines.delay(150)
        done.value()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Ref.Bg)
            .drawBehind {
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFFBFC8D8).copy(alpha = 0.14f * reveal.value), Color.Transparent),
                        center = Offset(size.width / 2f, size.height * 0.42f),
                        radius = size.width * 0.8f,
                    ),
                    radius = size.width * 0.8f,
                    center = Offset(size.width / 2f, size.height * 0.42f),
                )
            },
    ) {
        Column(
            Modifier.align(Alignment.Center).graphicsLayer {
                alpha = reveal.value
                val s = 0.9f + 0.1f * reveal.value
                scaleX = s; scaleY = s
            },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painterResource(R.drawable.auvyrr_logo_clear), "AUVYRR",
                Modifier.size(170.dp),
                contentScale = ContentScale.Fit,
            )
            Spacer(Modifier.height(22.dp))
            Text("AUVYRR", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
            Spacer(Modifier.height(8.dp))
            Text("Your sound. Your world.", color = Ref.Muted, fontSize = 14.sp)
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 56.dp, start = 64.dp, end = 64.dp)
                .fillMaxWidth()
                .height(3.dp)
                .clip(CircleShape)
                .background(Ref.Line),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(progress.value)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(Ref.Cyan),
            )
        }
    }
}
