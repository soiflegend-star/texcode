package com.texgen.music.texwave.sonara.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.texgen.music.texwave.sonara.artist.SubmissionStore
import com.texgen.music.texwave.sonara.data.Track
import com.texgen.music.texwave.sonara.data.UserProfile
import com.texgen.music.texwave.sonara.data.auth.AuthRepository
import com.texgen.music.texwave.sonara.data.catalog.CatalogueRepository
import com.texgen.music.texwave.sonara.data.catalog.DemoCatalogue
import com.texgen.music.texwave.sonara.data.catalog.RecommendationEngine
import com.texgen.music.texwave.sonara.data.download.DownloadStore
import com.texgen.music.texwave.sonara.data.download.OfflineDownloadManager
import com.texgen.music.texwave.sonara.data.local.LocalMusicScanner
import com.texgen.music.texwave.sonara.data.local.UserLibraryStore
import com.texgen.music.texwave.sonara.data.premium.PremiumManager
import com.texgen.music.texwave.sonara.data.settings.AudioQuality
import com.texgen.music.texwave.sonara.data.settings.UserSettingsStore
import com.texgen.music.texwave.sonara.data.xp.XpStore
import com.texgen.music.texwave.sonara.player.PlayerController
import com.texgen.music.texwave.sonara.rights.ContentSubmission
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SonaraUi(
    val catalogue: List<Track> = emptyList(),
    val local: List<Track> = emptyList(),
    val loading: Boolean = true,
    val likedIds: Set<String> = emptySet(),
    val recents: List<Track> = emptyList(),
    val playlists: List<UserLibraryStore.LocalPlaylist> = emptyList(),
    val genres: List<String> = emptyList(),
    val hasLocalPermission: Boolean = false,
    val loadingLocal: Boolean = false,
) {
    val all: List<Track> get() = catalogue + local
    fun byId(id: String): Track? = all.firstOrNull { it.id == id }
    val liked: List<Track> get() = all.filter { it.id in likedIds }
}

class SonaraViewModel(app: Application) : AndroidViewModel(app) {
    private val catalogueRepo = CatalogueRepository(app)
    private val authRepo = AuthRepository()
    private val scanner = LocalMusicScanner(app)
    private val libraryStore = UserLibraryStore(app)
    private val premium = PremiumManager(app)
    private val xpStore = XpStore(app)
    private val submissionStore = SubmissionStore(app)
    private val settingsStore = UserSettingsStore(app)
    private val downloadStore = DownloadStore(app)
    private val offline = OfflineDownloadManager(app, downloadStore)
    val player = PlayerController(app)

    val downloadProgress = offline.progress
    val downloadIds = downloadStore.downloadIds
    val audioQuality = settingsStore.audioQuality
    val crossfade = settingsStore.crossfadeEnabled
    val normalize = settingsStore.normalizeEnabled
    val wifiOnly = settingsStore.downloadWifiOnly
    val premiumDemo = premium.isLocalPremiumDemo
    val xp = xpStore.xp
    val submissions = submissionStore.submissions
    val user: StateFlow<UserProfile?> = authRepo.session
    val playback = player.state

    private val _catalogue = MutableStateFlow<List<Track>>(emptyList())
    private val _local = MutableStateFlow<List<Track>>(emptyList())
    private val _loading = MutableStateFlow(true)
    private val _loadingLocal = MutableStateFlow(false)
    private val _perm = MutableStateFlow(false)

    val ui: StateFlow<SonaraUi> = combine(
        _catalogue, _local, _loading, libraryStore.likedIds, libraryStore.recentIds,
    ) { cat, local, loading, likes, recentIds ->
        val all = cat + local
        SonaraUi(
            catalogue = cat, local = local, loading = loading, likedIds = likes,
            recents = recentIds.mapNotNull { id -> all.firstOrNull { it.id == id } },
            genres = cat.mapNotNull { it.genre?.takeIf { g -> g.isNotBlank() } }
                .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.map { it.key },
        )
    }.combine(libraryStore.playlists) { s, pl -> s.copy(playlists = pl) }
        .combine(_perm) { s, p -> s.copy(hasLocalPermission = p) }
        .combine(_loadingLocal) { s, l -> s.copy(loadingLocal = l) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SonaraUi())

    init {
        player.connect()
        viewModelScope.launch { authRepo.restoreSession() }
        refreshCatalogue()
        checkLocalPermission()
    }

    fun refreshCatalogue() {
        viewModelScope.launch {
            _loading.value = true
            _catalogue.value = try {
                catalogueRepo.fetchPublished()
            } catch (_: Exception) {
                DemoCatalogue.tracks
            }
            _loading.value = false
        }
    }

    fun checkLocalPermission() {
        val ctx = getApplication<Application>()
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        val granted = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
        _perm.value = granted
        if (granted) refreshLocal()
    }

    fun refreshLocal() {
        viewModelScope.launch {
            _loadingLocal.value = true
            try { _local.value = scanner.scan() } catch (_: Exception) { }
            _loadingLocal.value = false
        }
    }

    // ---- playback
    fun playAll(tracks: List<Track>, startIndex: Int = 0) {
        if (tracks.isEmpty()) return
        val i = startIndex.coerceIn(0, tracks.lastIndex)
        viewModelScope.launch {
            player.playTracks(tracks, i)
            libraryStore.addRecent(tracks[i].id)
            xpStore.onStreamProgress(true)
        }
    }

    fun play(track: Track, queue: List<Track>) {
        val q = queue.ifEmpty { listOf(track) }
        playAll(q, q.indexOfFirst { it.id == track.id }.coerceAtLeast(0))
    }

    fun shufflePlay(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        player.setShuffle(true)
        playAll(tracks.shuffled(), 0)
    }

    fun togglePlayPause() = player.togglePlayPause()
    fun pause() { if (player.state.value.isPlaying) player.togglePlayPause() }
    fun seekTo(ms: Long) = player.seekTo(ms)
    fun next() = player.skipNext()
    fun previous() = player.skipPrevious()
    fun setShuffle(on: Boolean) = player.setShuffle(on)
    fun cycleRepeat() = player.cycleRepeat()
    fun tick() = player.publishPosition()
    fun startRadio(seed: Track) = playAll(RecommendationEngine.radioFrom(seed, _catalogue.value.ifEmpty { DemoCatalogue.tracks }), 0)

    // ---- library
    fun toggleLike(id: String) {
        viewModelScope.launch { libraryStore.toggleLike(id); xpStore.onFirstLike() }
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch { libraryStore.createPlaylist(name); xpStore.onPlaylistCreated() }
    }

    fun addToPlaylist(playlistId: String, trackId: String) {
        viewModelScope.launch { libraryStore.addToPlaylist(playlistId, trackId) }
    }

    // ---- discovery (pure, on-device)
    fun forYou(s: SonaraUi): List<Track> = RecommendationEngine.forYou(s.catalogue, s.likedIds, s.recents.map { it.id })
    fun discoverWeekly(s: SonaraUi): List<Track> = RecommendationEngine.discoverWeekly(s.catalogue, s.likedIds, s.recents.map { it.id })
    fun trending(s: SonaraUi): List<Track> = RecommendationEngine.trending(s.catalogue)
    fun newReleases(s: SonaraUi): List<Track> = RecommendationEngine.newReleases(s.catalogue)
    fun byGenre(s: SonaraUi, g: String): List<Track> = RecommendationEngine.byGenre(s.catalogue, g)
    fun byArtist(s: SonaraUi, a: String): List<Track> = s.all.filter { it.artist.equals(a, ignoreCase = true) }
    fun byAlbum(s: SonaraUi, a: String): List<Track> = s.all.filter { it.album.equals(a, ignoreCase = true) && it.album.isNotBlank() }
    fun artists(s: SonaraUi): List<Pair<String, List<Track>>> = RecommendationEngine.artistsFrom(s.catalogue)
    fun albums(s: SonaraUi): List<Pair<String, List<Track>>> = RecommendationEngine.albumsFrom(s.catalogue)
    fun similar(s: SonaraUi, t: Track): List<Track> = RecommendationEngine.similarTracks(t, s.catalogue)

    fun search(s: SonaraUi, query: String): List<Track> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return s.all.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q) || (it.genre?.lowercase()?.contains(q) == true)
        }
    }

    // ---- downloads
    fun download(track: Track) { viewModelScope.launch { offline.download(track) } }
    fun deleteOffline(id: String) { viewModelScope.launch { offline.delete(id) } }

    // ---- account / settings
    fun signIn(email: String, pass: String, done: (String?) -> Unit) {
        viewModelScope.launch { done(authRepo.signIn(email, pass).exceptionOrNull()?.message) }
    }

    fun signUp(email: String, pass: String, username: String, display: String, done: (String?) -> Unit) {
        viewModelScope.launch { done(authRepo.signUp(email, pass, username, display).exceptionOrNull()?.message) }
    }

    fun signOut() { viewModelScope.launch { authRepo.signOut() } }
    fun setQuality(q: AudioQuality) { viewModelScope.launch { settingsStore.setAudioQuality(q) } }
    fun setCrossfade(v: Boolean) { viewModelScope.launch { settingsStore.setCrossfade(v) } }
    fun setNormalize(v: Boolean) { viewModelScope.launch { settingsStore.setNormalize(v) } }
    fun setWifiOnly(v: Boolean) { viewModelScope.launch { settingsStore.setDownloadWifiOnly(v) } }
    fun setDemoPremium(v: Boolean) { viewModelScope.launch { premium.setDemoPremium(v) } }
    fun submit(s: ContentSubmission) { viewModelScope.launch { submissionStore.submit(s) } }

    override fun onCleared() {
        player.disconnect()
        super.onCleared()
    }
}
