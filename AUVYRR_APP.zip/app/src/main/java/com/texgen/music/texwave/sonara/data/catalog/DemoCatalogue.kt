package com.texgen.music.texwave.sonara.data.catalog

import com.texgen.music.texwave.sonara.data.Track
import com.texgen.music.texwave.sonara.data.TrackSource

/**
 * Authorized DEMO catalogue for development and acceptance testing.
 *
 * All entries use public-domain or Creative Commons Zero (CC0) audio
 * hosted on the Internet Archive, which explicitly permits streaming
 * and redistribution. This is NOT a commercial catalogue substitute.
 *
 * Production deployments must replace this with platform-owned or
 * properly licensed content in Supabase Storage + the tracks table.
 *
 * License notes are stored on each track for transparency.
 */
object DemoCatalogue {

    val artists = listOf(
        "Kevin MacLeod",
        "United States Marine Band",
        "Scott Joplin (public domain performance)",
        "Internet Archive Community",
    )

    val tracks: List<Track> = listOf(
        Track(
            id = "demo_01",
            title = "Carefree",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 213_000,
            artworkUrl = "https://archive.org/services/img/CarefreeKevinMacLeod",
            streamUrl = "https://archive.org/download/CarefreeKevinMacLeod/Carefree.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Acoustic",
            year = 2012,
            isDownloadable = true,
        ),
        Track(
            id = "demo_02",
            title = "Impact Moderato",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 118_000,
            artworkUrl = "https://archive.org/services/img/ImpactModerato",
            streamUrl = "https://archive.org/download/ImpactModerato/Impact%20Moderato.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Cinematic",
            year = 2014,
            isDownloadable = true,
        ),
        Track(
            id = "demo_03",
            title = "Monkeys Spinning Monkeys",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 155_000,
            artworkUrl = "https://archive.org/services/img/MonkeysSpinningMonkeys",
            streamUrl = "https://archive.org/download/MonkeysSpinningMonkeys/Monkeys%20Spinning%20Monkeys.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Comedy",
            year = 2014,
            isDownloadable = true,
        ),
        Track(
            id = "demo_04",
            title = "Funk Game Loop",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 132_000,
            artworkUrl = "https://archive.org/services/img/FunkGameLoop",
            streamUrl = "https://archive.org/download/FunkGameLoop/Funk%20Game%20Loop.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Funk",
            year = 2015,
            isDownloadable = true,
        ),
        Track(
            id = "demo_05",
            title = "Wallpaper",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 226_000,
            artworkUrl = "https://archive.org/services/img/WallpaperKevinMacLeod",
            streamUrl = "https://archive.org/download/WallpaperKevinMacLeod/Wallpaper.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Ambient",
            year = 2011,
            isDownloadable = true,
        ),
        Track(
            id = "demo_06",
            title = "Cipher",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 192_000,
            artworkUrl = "https://archive.org/services/img/CipherKevinMacLeod",
            streamUrl = "https://archive.org/download/CipherKevinMacLeod/Cipher.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Electronic",
            year = 2017,
            isDownloadable = true,
        ),
        Track(
            id = "demo_07",
            title = "Lobby Time",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 148_000,
            artworkUrl = "https://archive.org/services/img/LobbyTime",
            streamUrl = "https://archive.org/download/LobbyTime/Lobby%20Time.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Jazz",
            year = 2016,
            isDownloadable = true,
        ),
        Track(
            id = "demo_08",
            title = "Sneaky Snitch",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 163_000,
            artworkUrl = "https://archive.org/services/img/SneakySnitch",
            streamUrl = "https://archive.org/download/SneakySnitch/Sneaky%20Snitch.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Comedy",
            year = 2010,
            isDownloadable = true,
        ),
        Track(
            id = "demo_09",
            title = "Investigations",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 201_000,
            artworkUrl = "https://archive.org/services/img/InvestigationsKevinMacLeod",
            streamUrl = "https://archive.org/download/InvestigationsKevinMacLeod/Investigations.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Cinematic",
            year = 2012,
            isDownloadable = true,
        ),
        Track(
            id = "demo_10",
            title = "Beauty Flow",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 168_000,
            artworkUrl = "https://archive.org/services/img/BeautyFlow",
            streamUrl = "https://archive.org/download/BeautyFlow/Beauty%20Flow.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Electronic",
            year = 2014,
            isDownloadable = true,
        ),
        Track(
            id = "demo_11",
            title = "The Entertainer",
            artist = "Scott Joplin (public domain)",
            album = "Rags — Public Domain",
            durationMs = 210_000,
            artworkUrl = null,
            streamUrl = "https://archive.org/download/TheEntertainer_201903/The%20Entertainer.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Ragtime",
            year = 1902,
            isDownloadable = true,
        ),
        Track(
            id = "demo_12",
            title = "Maple Leaf Rag",
            artist = "Scott Joplin (public domain)",
            album = "Rags — Public Domain",
            durationMs = 195_000,
            artworkUrl = null,
            streamUrl = "https://archive.org/download/MapleLeafRag_201903/Maple%20Leaf%20Rag.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Ragtime",
            year = 1899,
            isDownloadable = true,
        ),

        Track(
            id = "demo_13",
            title = "Dreams Become Real",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 185_000,
            artworkUrl = null,
            streamUrl = "https://archive.org/download/DreamsBecomeReal/Dreams%20Become%20Real.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Ambient",
            year = 2014,
            isDownloadable = true,
        ),
        Track(
            id = "demo_14",
            title = "Gearhead",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 140_000,
            artworkUrl = null,
            streamUrl = "https://archive.org/download/GearheadKevinMacLeod/Gearhead.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Electronic",
            year = 2015,
            isDownloadable = true,
        ),
        Track(
            id = "demo_15",
            title = "Happy Boy Theme",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 95_000,
            artworkUrl = null,
            streamUrl = "https://archive.org/download/HappyBoyTheme/Happy%20Boy%20Theme.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Comedy",
            year = 2008,
            isDownloadable = true,
        ),
        Track(
            id = "demo_16",
            title = "Whimsy Grove",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 172_000,
            artworkUrl = null,
            streamUrl = "https://archive.org/download/WhimsyGrove/Whimsy%20Grove.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Acoustic",
            year = 2016,
            isDownloadable = true,
        ),
        Track(
            id = "demo_17",
            title = "Space Jazz",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 198_000,
            artworkUrl = null,
            streamUrl = "https://archive.org/download/SpaceJazz/Space%20Jazz.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Jazz",
            year = 2017,
            isDownloadable = true,
        ),
        Track(
            id = "demo_18",
            title = "Danger Storm",
            artist = "Kevin MacLeod",
            album = "Incompetech CC0",
            durationMs = 125_000,
            artworkUrl = null,
            streamUrl = "https://archive.org/download/DangerStorm/Danger%20Storm.mp3",
            source = TrackSource.CATALOGUE,
            genre = "Cinematic",
            year = 2011,
            isDownloadable = true,
        ),
    ).map { it.copy(
        // Ensure every demo track is marked catalogue + downloadable under free allowance testing
    ) }

    fun search(query: String): List<Track> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        return tracks.filter {
            it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q) ||
                (it.genre?.lowercase()?.contains(q) == true)
        }
    }

    fun byArtist(name: String): List<Track> =
        tracks.filter { it.artist.equals(name, ignoreCase = true) }

    fun byGenre(genre: String): List<Track> =
        tracks.filter { it.genre.equals(genre, ignoreCase = true) }

    val genres: List<String> = tracks.mapNotNull { it.genre }.distinct().sorted()
}
