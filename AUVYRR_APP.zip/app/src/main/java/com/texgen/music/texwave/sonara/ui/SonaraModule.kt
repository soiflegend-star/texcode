package com.texgen.music.texwave.sonara.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.texgen.music.texwave.sonara.data.RepeatMode
import com.texgen.music.texwave.sonara.data.Track
import com.texgen.music.texwave.sonara.data.settings.AudioQuality
import com.texgen.music.texwave.sonara.rights.ContentSubmission
import kotlinx.coroutines.delay

private sealed interface SRoute {
    data class Collection(val title: String, val subtitle: String, val tracks: List<Track>) : SRoute
    object NowPlaying : SRoute
    object Queue : SRoute
}

private enum class STab(val label: String) { HOME("Home"), SEARCH("Search"), LIBRARY("Your Library"), PROFILE("Profile") }

/**
 * Sonara music module hosted inside AUVYRR. [onPlay] fires when Sonara starts playback
 * so the host can pause its own player (never two engines at once).
 */
@Composable
fun SonaraModule(onExit: () -> Unit, onPlay: () -> Unit = {}) {
    val vm: SonaraViewModel = viewModel()
    val s by vm.ui.collectAsState()
    val pb by vm.playback.collectAsState()
    var tab by remember { mutableStateOf(STab.HOME) }
    val stack = remember { mutableStateListOf<SRoute>() }
    var more by remember { mutableStateOf<Track?>(null) }

    LaunchedEffect(pb.isPlaying) {
        if (pb.isPlaying) onPlay()
        while (pb.isPlaying) { vm.tick(); delay(500) }
    }

    BackHandler(enabled = stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }
    BackHandler(enabled = stack.isEmpty() && tab != STab.HOME) { tab = STab.HOME }
    BackHandler(enabled = stack.isEmpty() && tab == STab.HOME) { onExit() }

    fun open(title: String, sub: String, tracks: List<Track>) { stack.add(SRoute.Collection(title, sub, tracks)) }
    val current = pb.currentTrack

    Box(Modifier.fillMaxSize().background(SC.Bg)) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    STab.HOME -> HomeScreen(vm, s, onExit, ::open) { t, q -> vm.play(t, q) }
                    STab.SEARCH -> SearchScreen(vm, s, onMore = { more = it })
                    STab.LIBRARY -> LibraryScreen(vm, s, ::open, onMore = { more = it })
                    STab.PROFILE -> ProfileScreen(vm, s)
                }
            }
            if (current != null) MiniPlayer(
                current, pb.isPlaying, pb.positionMs, pb.durationMs, s.likedIds.contains(current.id),
                onOpen = { stack.add(SRoute.NowPlaying) },
                onToggle = { vm.togglePlayPause() }, onLike = { vm.toggleLike(current.id) },
            )
            BottomNav(tab) { tab = it }
        }
        val top = stack.lastOrNull()
        if (top is SRoute.Collection) CollectionScreen(vm, s, top, onBack = { stack.removeAt(stack.lastIndex) }, onMore = { more = it })
        if (top is SRoute.NowPlaying) NowPlayingScreen(vm, s,
            onClose = { stack.removeAt(stack.lastIndex) }, onQueue = { stack.add(SRoute.Queue) })
        if (top is SRoute.Queue) QueueScreen(vm, s, onBack = { stack.removeAt(stack.lastIndex) })
        more?.let { t -> MoreDialog(vm, s, t) { more = null } }
    }
}

@Composable
private fun BottomNav(tab: STab, onTab: (STab) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color.Transparent, SC.Bg)))
            .background(SC.Bg.copy(alpha = 0.96f)).navigationBarsPadding().padding(vertical = 8.dp),
    ) {
        STab.values().forEach { t ->
            val on = t == tab
            val icon = when (t) {
                STab.HOME -> Icons.Filled.Home
                STab.SEARCH -> Icons.Filled.Search
                STab.LIBRARY -> Icons.Filled.LibraryMusic
                STab.PROFILE -> Icons.Filled.Person
            }
            Column(
                Modifier.weight(1f).clickable { onTab(t) }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(icon, t.label, tint = if (on) SC.Accent else SC.Sub, modifier = Modifier.size(24.dp))
                Text(t.label, color = if (on) SC.Text else SC.Sub, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    t: Track, playing: Boolean, pos: Long, dur: Long, liked: Boolean,
    onOpen: () -> Unit, onToggle: () -> Unit, onLike: () -> Unit,
) {
    Column(
        Modifier.padding(horizontal = 8.dp).clip(RoundedCornerShape(12.dp)).background(SC.CardHi).clickable { onOpen() },
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(t.artworkUrl, t.id, 44.dp, 6.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(t.title, color = SC.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, color = SC.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like", tint = if (liked) SC.Accent else SC.Sub,
                modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onLike() }.padding(9.dp))
            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", tint = SC.Text,
                modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onToggle() }.padding(6.dp))
        }
        val frac = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
        Box(Modifier.fillMaxWidth().height(2.dp).background(Color.White.copy(alpha = 0.12f))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(SC.Accent))
        }
    }
    Spacer(Modifier.height(4.dp))
}

// ───────────────────────────── HOME

@Composable
private fun HomeScreen(
    vm: SonaraViewModel, s: SonaraUi, onExit: () -> Unit,
    open: (String, String, List<Track>) -> Unit, play: (Track, List<Track>) -> Unit,
) {
    val pb by vm.playback.collectAsState()
    val user by vm.user.collectAsState()
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val greet = if (hour < 12) "Good morning" else if (hour < 18) "Good afternoon" else "Good evening"
    val quick = (s.liked.take(3) + s.recents).distinctBy { it.id }.ifEmpty { vm.trending(s) }.take(6)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(SC.Accent.copy(alpha = 0.35f), SC.Bg)))) {
                Row(Modifier.statusBarsPadding().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(greet, color = SC.Text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Sonara by AUVYRR" + (user?.displayName?.let { " · $it" } ?: ""), color = SC.Sub, fontSize = 12.sp)
                    }
                    Icon(Icons.Filled.Close, "Close Sonara", tint = SC.Text,
                        modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.3f)).clickable { onExit() }.padding(9.dp))
                }
            }
        }
        if (s.loading && s.catalogue.isEmpty()) item {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = SC.Accent) }
        }
        if (quick.isNotEmpty()) item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                quick.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { t ->
                            Row(
                                Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(8.dp)).background(SC.Card)
                                    .clickable { play(t, quick) },
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Cover(t.artworkUrl, t.id, 54.dp, 0.dp)
                                Text(t.title, color = if (pb.currentTrack?.id == t.id) SC.Accent else SC.Text, fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 10.dp))
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        trackRail("Made for you", vm.forYou(s), open, play)
        s.onlineRows.forEach { (t, tr) -> trackRail(t, tr, open, play) }
        trackRail("Trending now", vm.trending(s), open, play)
        trackRail("Discover weekly", vm.discoverWeekly(s), open, play)
        trackRail("New releases", vm.newReleases(s), open, play)
        if (s.genres.isNotEmpty()) item {
            SectionTitle("Browse by genre")
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(s.genres.take(12)) { g ->
                    Box(
                        Modifier.size(width = 132.dp, height = 76.dp).clip(RoundedCornerShape(10.dp)).background(coverBrush(g))
                            .clickable { open(g, "Genre", vm.byGenre(s, g)) }.padding(10.dp),
                    ) { Text(g, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp) }
                }
            }
        }
        val artists = vm.artists(s)
        if (artists.isNotEmpty()) item {
            SectionTitle("Artists")
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(artists.take(15)) { (name, tr) ->
                    SquareCard(name, "Artist", tr.firstOrNull()?.artworkUrl, name, 120.dp, round = true) { open(name, "Artist", tr) }
                }
            }
        }
        val albums = vm.albums(s)
        if (albums.isNotEmpty()) item {
            SectionTitle("Albums")
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(albums.take(15)) { (name, tr) ->
                    SquareCard(name, tr.firstOrNull()?.artist ?: "", tr.firstOrNull()?.artworkUrl, name, 140.dp) { open(name, "Album", tr) }
                }
            }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.trackRail(
    title: String, tracks: List<Track>, open: (String, String, List<Track>) -> Unit, play: (Track, List<Track>) -> Unit,
) {
    if (tracks.isEmpty()) return
    item {
        SectionTitle(title, action = "See all") { open(title, "Playlist", tracks) }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(tracks.take(15), key = { it.id }) { t ->
                SquareCard(t.title, t.artist, t.artworkUrl, t.id) { play(t, tracks) }
            }
        }
    }
}

// ───────────────────────────── SEARCH

@Composable
private fun SearchScreen(vm: SonaraViewModel, s: SonaraUi, onMore: (Track) -> Unit) {
    var q by remember { mutableStateOf("") }
    val pb by vm.playback.collectAsState()
    LaunchedEffect(q) { delay(400); vm.searchOnline(q) }
    val results = remember(q, s.catalogue, s.local, s.onlineResults) {
        (vm.search(s, q) + s.onlineResults).distinctBy { it.id }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Search", color = SC.Text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 8.dp))
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true,
            placeholder = { Text("What do you want to listen to?", color = SC.Sub) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = SC.Sub) },
            trailingIcon = { if (q.isNotEmpty()) Icon(Icons.Filled.Close, "Clear", tint = SC.Sub, modifier = Modifier.clickable { q = "" }) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SC.CardHi, unfocusedContainerColor = SC.CardHi,
                focusedBorderColor = SC.Accent, unfocusedBorderColor = Color.Transparent,
                focusedTextColor = SC.Text, unfocusedTextColor = SC.Text, cursorColor = SC.Accent,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
        Spacer(Modifier.height(8.dp))
        if (q.isBlank()) {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Text("Browse all", color = SC.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                items(browseGenres(s).chunked(2)) { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { g ->
                            Box(
                                Modifier.weight(1f).height(80.dp).clip(RoundedCornerShape(10.dp)).background(coverBrush(g))
                                    .clickable { q = g }.padding(12.dp),
                            ) { Text(g, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                item {
                    Text(
                        "Search finds full songs from Audius" + (if (com.texgen.music.texwave.sonara.SonaraConfig.JAMENDO_CLIENT_ID.isNotBlank()) " and Jamendo" else "") +
                            ", plus 30-second previews of almost any song from Apple Music's catalogue.",
                        color = SC.Sub, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        } else if (results.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
                if (s.searching) CircularProgressIndicator(color = SC.Accent) else Text("No results for \"$q\"", color = SC.Sub)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                if (s.searching) item { LinearProgressIndicator(color = SC.Accent, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) }
                items(results, key = { it.id }) { t ->
                    TrackRow(t, t.id in s.likedIds, pb.currentTrack?.id == t.id, { vm.play(t, results) }, { vm.toggleLike(t.id) }, { onMore(t) })
                }
            }
        }
    }
}

private val defaultGenres = listOf(
    "Phonk", "Hip-Hop", "Lo-Fi", "Electronic", "Pop", "Rock", "Indie", "Ambient",
    "Jazz", "Classical", "R&B", "Punjabi", "Bollywood", "Metal", "Country", "K-Pop",
)

private fun browseGenres(s: SonaraUi): List<String> = (s.genres + defaultGenres).distinctBy { it.lowercase() }

// ───────────────────────────── LIBRARY

@Composable
private fun LibraryScreen(
    vm: SonaraViewModel, s: SonaraUi, open: (String, String, List<Track>) -> Unit, onMore: (Track) -> Unit,
) {
    var section by remember { mutableStateOf("Playlists") }
    var newDialog by remember { mutableStateOf(false) }
    val pb by vm.playback.collectAsState()
    val dl by vm.downloadIds.collectAsState(initial = emptySet())
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.checkLocalPermission() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(16.dp, 16.dp, 16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Your Library", color = SC.Text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.Add, "New playlist", tint = SC.Text,
                modifier = Modifier.size(40.dp).clip(CircleShape).background(SC.CardHi).clickable { newDialog = true }.padding(9.dp))
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("Playlists", "Liked", "Downloads", "On device", "Artists")) { c ->
                Chip(c, section == c) { section = c }
            }
        }
        Spacer(Modifier.height(8.dp))
        when (section) {
            "Playlists" -> LazyColumn {
                item {
                    LibRow("Liked Songs", "${s.liked.size} songs", Icons.Filled.Favorite) { open("Liked Songs", "Playlist", s.liked) }
                }
                items(s.playlists, key = { it.id }) { p ->
                    val tr = p.trackIds.mapNotNull { s.byId(it) }
                    LibRow(p.name, "Playlist · ${tr.size} songs", Icons.Filled.QueueMusic) { open(p.name, "Playlist", tr) }
                }
            }
            "Liked" -> TrackList(vm, s, s.liked, pb.currentTrack?.id, onMore, "Songs you like appear here.")
            "Downloads" -> TrackList(vm, s, s.all.filter { it.id in dl }, pb.currentTrack?.id, onMore, "Download tracks from the ⋮ menu to keep them here.")
            "On device" -> if (!s.hasLocalPermission) {
                Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Play music stored on this phone", color = SC.Text, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            permLauncher.launch(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SC.Accent),
                    ) { Text("Allow access", color = Color.White) }
                }
            } else TrackList(vm, s, s.local, pb.currentTrack?.id, onMore, if (s.loadingLocal) "Scanning…" else "No audio files found.")
            else -> LazyColumn {
                items(vm.artists(s)) { (name, tr) ->
                    LibRow(name, "Artist · ${tr.size} songs", Icons.Filled.Person) { open(name, "Artist", tr) }
                }
            }
        }
    }
    if (newDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newDialog = false },
            containerColor = SC.Card,
            title = { Text("New playlist", color = SC.Text) },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("My playlist") }) },
            confirmButton = {
                TextButton(onClick = { if (name.isNotBlank()) vm.createPlaylist(name.trim()); newDialog = false }) { Text("Create", color = SC.Accent) }
            },
            dismissButton = { TextButton(onClick = { newDialog = false }) { Text("Cancel", color = SC.Sub) } },
        )
    }
}

@Composable
private fun TrackList(vm: SonaraViewModel, s: SonaraUi, tracks: List<Track>, playingId: String?, onMore: (Track) -> Unit, empty: String) {
    if (tracks.isEmpty()) {
        Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.TopCenter) { Text(empty, color = SC.Sub) }
        return
    }
    LazyColumn {
        items(tracks, key = { it.id }) { t ->
            TrackRow(t, t.id in s.likedIds, playingId == t.id, { vm.play(t, tracks) }, { vm.toggleLike(t.id) }, { onMore(t) })
        }
    }
}

@Composable
private fun LibRow(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(coverBrush(title)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(title, color = SC.Text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(sub, color = SC.Sub, fontSize = 12.sp)
        }
    }
}

// ───────────────────────────── COLLECTION

@Composable
private fun CollectionScreen(vm: SonaraViewModel, s: SonaraUi, c: SRoute.Collection, onBack: () -> Unit, onMore: (Track) -> Unit) {
    val pb by vm.playback.collectAsState()
    LazyColumn(Modifier.fillMaxSize().background(SC.Bg), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(
                Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(coverBrushColor(c.title), SC.Bg)))
                    .statusBarsPadding().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = SC.Text,
                        modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.3f)).clickable { onBack() }.padding(9.dp))
                }
                Spacer(Modifier.height(8.dp))
                Cover(c.tracks.firstOrNull()?.artworkUrl, c.title, 190.dp, 10.dp)
                Spacer(Modifier.height(14.dp))
                Text(c.title, color = SC.Text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${c.subtitle} · ${c.tracks.size} songs", color = SC.Sub, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Icon(Icons.Filled.Shuffle, "Shuffle", tint = SC.Text,
                        modifier = Modifier.size(44.dp).clip(CircleShape).background(SC.CardHi).clickable { vm.shufflePlay(c.tracks) }.padding(11.dp))
                    RoundPlay({ vm.playAll(c.tracks, 0) }, 60.dp)
                }
            }
        }
        if (c.tracks.isEmpty()) item { Text("Nothing here yet.", color = SC.Sub, modifier = Modifier.padding(24.dp)) }
        itemsIndexed(c.tracks, key = { i, t -> "${t.id}#$i" }) { i, t ->
            TrackRow(t, t.id in s.likedIds, pb.currentTrack?.id == t.id, { vm.playAll(c.tracks, i) }, { vm.toggleLike(t.id) }, { onMore(t) }, index = i + 1)
        }
    }
}

private fun coverBrushColor(seed: String): Color {
    val palette = listOf(Color(0xFF4B2BA8), Color(0xFF9C2F63), Color(0xFF0E6F66), Color(0xFF9A5516), Color(0xFF1E4FA8), Color(0xFF7A2160))
    return palette[(seed.hashCode() and 0x7fffffff) % palette.size]
}

// ───────────────────────────── NOW PLAYING

@Composable
private fun NowPlayingScreen(vm: SonaraViewModel, s: SonaraUi, onClose: () -> Unit, onQueue: () -> Unit) {
    val pb by vm.playback.collectAsState()
    val dl by vm.downloadIds.collectAsState(initial = emptySet())
    val prog by vm.downloadProgress.collectAsState()
    val t = pb.currentTrack
    if (t == null) { LaunchedEffect(Unit) { onClose() }; return }
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = pb.durationMs.coerceAtLeast(1L)
    val shown = drag ?: (pb.positionMs.toFloat() / dur).coerceIn(0f, 1f)

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(coverBrushColor(t.id), SC.Bg, SC.Bg)))
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.KeyboardArrowDown, "Close", tint = SC.Text, modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onClose() }.padding(6.dp))
            Text("NOW PLAYING", color = SC.Sub, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
                modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Icon(Icons.Filled.QueueMusic, "Queue", tint = SC.Text, modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onQueue() }.padding(8.dp))
        }
        Spacer(Modifier.weight(1f))
        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Cover(t.artworkUrl, t.id, maxWidth.coerceAtMost(340.dp), 16.dp)
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.title, color = SC.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, color = SC.Sub, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val liked = t.id in s.likedIds
            Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like", tint = if (liked) SC.Accent else SC.Text,
                modifier = Modifier.size(44.dp).clip(CircleShape).clickable { vm.toggleLike(t.id) }.padding(10.dp))
        }
        Slider(
            value = shown, onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { vm.seekTo((it * dur).toLong()) }; drag = null },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = SC.Accent, inactiveTrackColor = Color.White.copy(alpha = 0.18f)),
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmtMs((shown * dur).toLong()), color = SC.Sub, fontSize = 11.sp, modifier = Modifier.weight(1f))
            Text(fmtMs(pb.durationMs), color = SC.Sub, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (pb.shuffle) SC.Accent else SC.Sub,
                modifier = Modifier.size(44.dp).clip(CircleShape).clickable { vm.setShuffle(!pb.shuffle) }.padding(10.dp))
            Icon(Icons.Filled.SkipPrevious, "Previous", tint = SC.Text, modifier = Modifier.size(52.dp).clip(CircleShape).clickable { vm.previous() }.padding(8.dp))
            Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White).clickable { vm.togglePlayPause() }, contentAlignment = Alignment.Center) {
                Icon(if (pb.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", tint = Color.Black, modifier = Modifier.size(40.dp))
            }
            Icon(Icons.Filled.SkipNext, "Next", tint = SC.Text, modifier = Modifier.size(52.dp).clip(CircleShape).clickable { vm.next() }.padding(8.dp))
            Icon(if (pb.repeatMode == RepeatMode.ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Repeat",
                tint = if (pb.repeatMode == RepeatMode.OFF) SC.Sub else SC.Accent,
                modifier = Modifier.size(44.dp).clip(CircleShape).clickable { vm.cycleRepeat() }.padding(10.dp))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            val p = prog[t.id]
            val busy = p?.status == com.texgen.music.texwave.sonara.data.download.DownloadProgress.Status.RUNNING
            Chip(
                if (t.id in dl) "Downloaded" else if (busy) "Downloading ${((p?.fraction ?: 0f) * 100).toInt()}%" else if (t.isDownloadable) "Download" else "Not downloadable",
                t.id in dl,
            ) { if (t.id in dl) vm.deleteOffline(t.id) else if (t.isDownloadable && !busy) vm.download(t) }
            Chip("Start radio", false) { vm.startRadio(t) }
        }
    }
}

// ───────────────────────────── QUEUE

@Composable
private fun QueueScreen(vm: SonaraViewModel, s: SonaraUi, onBack: () -> Unit) {
    val pb by vm.playback.collectAsState()
    Column(Modifier.fillMaxSize().background(SC.Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, "Back", tint = SC.Text, modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onBack() }.padding(9.dp))
            Text("Queue", color = SC.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 8.dp))
        }
        LazyColumn {
            itemsIndexed(pb.queue, key = { i, t -> "${t.id}#$i" }) { i, t ->
                TrackRow(t, t.id in s.likedIds, pb.currentTrack?.id == t.id, { vm.playAll(pb.queue, i) }, { vm.toggleLike(t.id) })
            }
        }
    }
}

// ───────────────────────────── MORE MENU

@Composable
private fun MoreDialog(vm: SonaraViewModel, s: SonaraUi, t: Track, dismiss: () -> Unit) {
    var pick by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = dismiss, containerColor = SC.Card,
        title = { Text(t.title, color = SC.Text, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                if (!pick) {
                    MenuItem("Start radio") { vm.startRadio(t); dismiss() }
                    MenuItem("Add to playlist") { pick = true }
                    if (t.isDownloadable) MenuItem("Download") { vm.download(t); dismiss() }
                } else if (s.playlists.isEmpty()) {
                    Text("Create a playlist in Your Library first.", color = SC.Sub)
                } else s.playlists.forEach { p -> MenuItem(p.name) { vm.addToPlaylist(p.id, t.id); dismiss() } }
            }
        },
        confirmButton = { TextButton(onClick = dismiss) { Text("Close", color = SC.Accent) } },
    )
}

@Composable
private fun MenuItem(text: String, onClick: () -> Unit) {
    Text(text, color = SC.Text, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp))
}

// ───────────────────────────── PROFILE

@Composable
private fun ProfileScreen(vm: SonaraViewModel, s: SonaraUi) {
    val user by vm.user.collectAsState()
    val xp by vm.xp.collectAsState(initial = 0)
    val premium by vm.premiumDemo.collectAsState(initial = false)
    val quality by vm.audioQuality.collectAsState(initial = AudioQuality.NORMAL)
    val crossfade by vm.crossfade.collectAsState(initial = false)
    val normalize by vm.normalize.collectAsState(initial = false)
    val wifi by vm.wifiOnly.collectAsState(initial = true)
    var submitDialog by remember { mutableStateOf(false) }
    var signIn by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Profile", color = SC.Text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(64.dp).clip(CircleShape).background(coverBrush(user?.id ?: "guest")), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(user?.displayName ?: "Guest listener", color = SC.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Level ${xp / 100 + 1} · $xp XP${if (premium) " · Premium" else ""}", color = SC.Sub, fontSize = 13.sp)
            }
            if (user == null) Chip("Sign in", true) { signIn = true } else Chip("Sign out", false) { vm.signOut() }
        }
        Spacer(Modifier.height(10.dp))
        val frac = ((xp % 100) / 100f)
        Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(SC.CardHi)) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(SC.Accent))
        }
        Spacer(Modifier.height(20.dp))
        Text("Audio quality", color = SC.Text, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(AudioQuality.values().toList()) { q -> Chip(q.label, q == quality) { vm.setQuality(q) } }
        }
        Spacer(Modifier.height(12.dp))
        SwitchRow("Crossfade", crossfade) { vm.setCrossfade(it) }
        SwitchRow("Normalize volume", normalize) { vm.setNormalize(it) }
        SwitchRow("Download on Wi-Fi only", wifi) { vm.setWifiOnly(it) }
        SwitchRow("Premium (demo)", premium) { vm.setDemoPremium(it) }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { submitDialog = true }, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = SC.CardHi),
        ) { Text("Submit music for review", color = SC.Text) }
        Spacer(Modifier.height(8.dp))
        val subs by vm.submissions.collectAsState(initial = emptyList())
        subs.forEach { Text("• ${it.title} — ${it.status}", color = SC.Sub, fontSize = 13.sp) }
        Spacer(Modifier.height(24.dp))
    }

    if (signIn) {
        var email by remember { mutableStateOf("") }
        var pass by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { signIn = false }, containerColor = SC.Card,
            title = { Text("Sign in", color = SC.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(email, { email = it }, singleLine = true, label = { Text("Email") })
                    OutlinedTextField(pass, { pass = it }, singleLine = true, label = { Text("Password") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.signIn(email, pass) { e -> if (e == null) signIn = false else err = e } }) { Text("Continue", color = SC.Accent) }
            },
            dismissButton = { TextButton(onClick = { signIn = false }) { Text("Cancel", color = SC.Sub) } },
        )
    }
    if (submitDialog) {
        var title by remember { mutableStateOf("") }
        var artist by remember { mutableStateOf("") }
        var own by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { submitDialog = false }, containerColor = SC.Card,
            title = { Text("Submit a track", color = SC.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, singleLine = true, label = { Text("Title") })
                    OutlinedTextField(artist, { artist = it }, singleLine = true, label = { Text("Artist") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(own, { own = it })
                        Text("I own or control the rights to this music", color = SC.Sub, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = own && title.isNotBlank() && artist.isNotBlank(),
                    onClick = {
                        vm.submit(ContentSubmission(title = title.trim(), artistName = artist.trim(), ownershipDeclaration = "Submitter declares ownership"))
                        submitDialog = false
                    },
                ) { Text("Submit", color = SC.Accent) }
            },
            dismissButton = { TextButton(onClick = { submitDialog = false }) { Text("Cancel", color = SC.Sub) } },
        )
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = SC.Text, modifier = Modifier.weight(1f))
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = SC.Accent, checkedThumbColor = Color.White))
    }
}
