package com.texgen.music.texwave.sonara.data

import kotlinx.serialization.Serializable

/**
 * Core domain models for Sonara.
 * Designed to support both local MediaStore tracks and remote catalogue tracks.
 */

@Serializable
data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val albumId: String = "",
    val durationMs: Long = 0L,
    val artworkUrl: String? = null,
    val streamUrl: String? = null,       // remote stream
    val localUri: String? = null,        // content:// or file path for local
    val source: TrackSource = TrackSource.LOCAL,
    val genre: String? = null,
    val year: Int? = null,
    val trackNumber: Int? = null,
    val isExplicit: Boolean = false,
    val isDownloadable: Boolean = false,
    val ownerId: String? = null,         // for user-uploaded tracks
)

enum class TrackSource {
    LOCAL,      // device MediaStore
    CATALOGUE,  // platform catalogue / streaming
    UPLOADED,   // user / artist upload
}

@Serializable
data class Album(
    val id: String,
    val name: String,
    val artist: String,
    val artworkUrl: String? = null,
    val year: Int? = null,
    val trackCount: Int = 0,
    val tracks: List<Track> = emptyList(),
)

@Serializable
data class Artist(
    val id: String,
    val name: String,
    val imageUrl: String? = null,
    val bio: String? = null,
    val followerCount: Int = 0,
    val monthlyListeners: Int = 0,
)

@Serializable
data class Playlist(
    val id: String,
    val name: String,
    val description: String = "",
    val ownerId: String,
    val ownerName: String = "",
    val artworkUrl: String? = null,
    val isPublic: Boolean = true,
    val isCollaborative: Boolean = false,
    val trackIds: List<String> = emptyList(),
    val trackCount: Int = 0,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
)

@Serializable
data class UserProfile(
    val id: String,
    val username: String,
    val displayName: String,
    val email: String? = null,
    val avatarUrl: String? = null,
    val bio: String = "",
    val isPremium: Boolean = false,
    val freeDownloadsRemaining: Int = 10,
    val followerCount: Int = 0,
    val followingCount: Int = 0,
    val createdAt: Long = 0L,
)

@Serializable
data class PlaybackState(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val queue: List<Track> = emptyList(),
    val shuffle: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
)

enum class RepeatMode { OFF, ONE, ALL }

@Serializable
data class ListeningHistoryEntry(
    val trackId: String,
    val playedAt: Long,
    val durationPlayedMs: Long,
)
