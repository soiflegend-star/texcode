package com.texgen.music.texwave.sonara.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.sonara.data.Track
import com.texgen.music.texwave.ui.theme.Tx

/** Sonara palette: neutral near-black surfaces, AUVYRR accent. */
object SC {
    val Bg get() = Color(0xFF0A0A0C)
    val Card get() = Color(0xFF17171B)
    val CardHi get() = Color(0xFF222228)
    val Text get() = Color(0xFFF4F4F6)
    val Sub get() = Color(0xFFA2A2AD)
    val Accent get() = Tx.Accent
    val Accent2 get() = Tx.Accent2
}

fun fmtMs(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

private val coverPalette = listOf(
    Color(0xFF6C3BFF), Color(0xFFFF4D8D), Color(0xFF16A394), Color(0xFFFF8A2B),
    Color(0xFF2D7DFF), Color(0xFFB4308B), Color(0xFF3FAE4F), Color(0xFFD9423A),
)

fun coverBrush(seed: String): Brush {
    val h = (seed.hashCode() and 0x7fffffff)
    val a = coverPalette[h % coverPalette.size]
    val b = coverPalette[(h / 7) % coverPalette.size]
    return Brush.linearGradient(listOf(a, b.copy(alpha = 0.75f)))
}

@Composable
fun Cover(url: String?, seed: String, size: Dp, radius: Dp = 8.dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(radius)
    Box(modifier.size(size).clip(shape).background(coverBrush(seed)), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.MusicNote, null, tint = Color.White.copy(alpha = 0.55f), modifier = Modifier.size(size * 0.4f))
        if (!url.isNullOrBlank()) {
            AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, action: String? = null, onAction: () -> Unit = {}) {
    Row(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = SC.Text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        if (action != null) Text(action, color = SC.Sub, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onAction() })
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) SC.Accent else SC.CardHi)
            .clickable { onClick() }.padding(horizontal = 14.dp, vertical = 8.dp),
    ) { Text(text, color = if (selected) Color.White else SC.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun TrackRow(
    t: Track, liked: Boolean, playing: Boolean, onClick: () -> Unit, onLike: () -> Unit, onMore: (() -> Unit)? = null,
    index: Int? = null,
) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (index != null) Text("$index", color = SC.Sub, fontSize = 13.sp, modifier = Modifier.width(26.dp))
        Cover(t.artworkUrl, t.id, 48.dp, 6.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, color = if (playing) SC.Accent else SC.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (t.previewOnly) "${t.artist} · 30s preview" else t.artist, color = SC.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(
            if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like",
            tint = if (liked) SC.Accent else SC.Sub,
            modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onLike() }.padding(9.dp),
        )
        if (onMore != null) Icon(
            Icons.Filled.MoreVert, "More", tint = SC.Sub,
            modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onMore() }.padding(9.dp),
        )
    }
}

@Composable
fun SquareCard(title: String, subtitle: String, url: String?, seed: String, size: Dp = 144.dp, round: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.width(size).clickable { onClick() }) {
        Cover(url, seed, size, if (round) size / 2 else 10.dp)
        Spacer(Modifier.height(8.dp))
        Text(title, color = SC.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, color = SC.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun RoundPlay(onClick: () -> Unit, size: Dp = 56.dp, playing: Boolean = false) {
    Box(
        Modifier.size(size).clip(CircleShape).background(SC.Accent).clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(size * 0.55f)) }
}
