package com.texgen.music.texwave.data

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import com.texgen.music.texwave.AlarmRingActivity
import com.texgen.music.texwave.notification.TexwaveAlarmReceiver
import org.json.JSONArray
import java.util.Calendar

/**
 * Industrial alarm scheduler — dual-path (AlarmClock + exact while-idle),
 * boot reschedule, exact-alarm capability checks.
 */
object AlarmEngine {

    private const val PREFS = "texwave_alarms"

    fun ensureExactPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return try {
            if (am.canScheduleExactAlarms()) true
            else {
                runCatching {
                    context.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                            data = android.net.Uri.parse("package:${context.packageName}")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        },
                    )
                }
                Toast.makeText(context, "Allow exact alarms for reliable wake-ups", Toast.LENGTH_LONG).show()
                false
            }
        } catch (_: Exception) {
            true
        }
    }

    /** True when Android lets us set exact alarms right now (no settings screen is opened). */
    fun exactAllowed(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return runCatching {
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        }.getOrDefault(true)
    }

    /** Next moment at hour:minute that is on one of [days] (0 = any day, i.e. the next occurrence). */
    fun nextTrigger(hour: Int, minute: Int, days: Int = 0, from: Long = System.currentTimeMillis()): Long {
        for (add in 0..7) {
            val c = Calendar.getInstance().apply {
                timeInMillis = from
                add(Calendar.DAY_OF_YEAR, add)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis <= from + 2_000L) continue
            if (days == 0 || days and (1 shl Days.bitOf(c.get(Calendar.DAY_OF_WEEK))) != 0) return c.timeInMillis
        }
        return nextTrigger(hour, minute, 0, from)
    }

    /** Schedule one saved alarm at its next occurrence and remember that time. */
    fun schedule(context: Context, rec: AlarmRec): AlarmRec {
        val at = nextTrigger(rec.hour, rec.minute, rec.days)
        schedule(context, rec.id, rec.hour, rec.minute, rec.label, rec.soundUri, at)
        return rec.copy(trigger = at)
    }

    /**
     * Called when an alarm has just fired: repeating alarms are armed for their next day,
     * one-time alarms switch themselves off. Safe to call more than once for the same firing.
     */
    fun onFired(context: Context, id: Int) {
        val rec = AlarmStore.get(context, id) ?: return
        if (!rec.enabled) return
        if (rec.repeating) {
            AlarmStore.update(context, schedule(context, rec))
        } else {
            AlarmStore.update(context, rec.copy(enabled = false))
        }
    }

    /** Timers and focus sessions: one exact alarm that rings even if the app is closed. */
    fun startCountdown(context: Context, id: Int, minutes: Int, label: String): Long {
        val end = System.currentTimeMillis() + minutes * 60_000L
        context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE).edit()
            .putLong("cd_end_$id", end).putString("cd_label_$id", label).putInt("cd_total_$id", minutes).apply()
        schedule(context, id, 0, 0, label, "", end)
        return end
    }

    /** Push a running countdown later (the "+1 min" button). */
    fun extendCountdown(context: Context, id: Int, extraMs: Long) {
        val p = context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE)
        val end = p.getLong("cd_end_$id", 0L)
        if (end <= System.currentTimeMillis()) return
        val label = p.getString("cd_label_$id", "Timer") ?: "Timer"
        p.edit().putLong("cd_end_$id", end + extraMs).putInt("cd_total_$id", p.getInt("cd_total_$id", 1) + (extraMs / 60_000L).toInt()).apply()
        schedule(context, id, 0, 0, label, "", end + extraMs)
    }

    fun cancelCountdown(context: Context, id: Int) {
        context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE).edit()
            .remove("cd_end_$id").remove("cd_label_$id").remove("cd_total_$id").apply()
        cancel(context, id)
    }

    fun schedule(
        context: Context,
        id: Int,
        hour: Int,
        minute: Int,
        label: String,
        soundUri: String?,
        triggerAt: Long = nextTrigger(hour, minute),
    ) {
        ensureExactPermission(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fire = Intent(context, TexwaveAlarmReceiver::class.java).apply {
            action = "com.texgen.music.texwave.ALARM_FIRE"
            putExtra("alarm_id", id)
            putExtra("alarm_label", label)
            putExtra("alarm_sound", soundUri.orEmpty())
            // Explicit component so the system always delivers to us
            setClass(context, TexwaveAlarmReceiver::class.java)
        }
        val broadcast = PendingIntent.getBroadcast(
            context,
            id,
            fire,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        // Backup PendingIntent with different request code (survives some OEM cancel quirks)
        val backup = PendingIntent.getBroadcast(
            context,
            id + 90_000,
            Intent(fire),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val show = PendingIntent.getActivity(
            context,
            id + 50_000,
            Intent(context, AlarmRingActivity::class.java).apply {
                putExtra(AlarmRingActivity.EXTRA_ALARM_ID, id)
                putExtra(AlarmRingActivity.EXTRA_LABEL, label)
                putExtra(AlarmRingActivity.EXTRA_SOUND, soundUri.orEmpty())
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        // Path 1: AlarmClock (shows in system clock, highest reliability when allowed)
        runCatching {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), broadcast)
        }
        // Path 2: exact while-idle backup so Doze cannot silently drop the wake-up
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, backup)
            } else {
                @Suppress("DEPRECATION")
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, backup)
            }
        }.onFailure {
            runCatching { am.set(AlarmManager.RTC_WAKEUP, triggerAt, backup) }
        }
    }

    fun cancel(context: Context, id: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fire = Intent(context, TexwaveAlarmReceiver::class.java)
        listOf(id, id + 90_000).forEach { req ->
            val pi = PendingIntent.getBroadcast(
                context,
                req,
                fire,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            am.cancel(pi)
        }
    }

    /** After reboot, app update, clock or time-zone change: arm everything again from the saved list. */
    fun rescheduleAll(context: Context) {
        val list = AlarmStore.load(context)
        val updated = list.map { rec ->
            if (!rec.enabled) rec else runCatching { schedule(context, rec) }.getOrDefault(rec)
        }
        if (updated != list) AlarmStore.save(context, updated)
        // running timers / focus sessions
        val prefs = context.getSharedPreferences(AlarmStore.PREFS, Context.MODE_PRIVATE)
        listOf(TIMER_ID, FOCUS_ID).forEach { id ->
            val end = prefs.getLong("cd_end_$id", 0L)
            if (end > System.currentTimeMillis()) {
                schedule(context, id, 0, 0, prefs.getString("cd_label_$id", "Timer") ?: "Timer", "", end)
            }
        }
    }

    const val TIMER_ID = 9001
    const val FOCUS_ID = 9002
}
