// Sonara edge function: issue short-lived signed URLs for private audio objects.
// Deploy with: supabase functions deploy stream-url
// Secrets: none beyond project; uses service role only inside the function runtime.
// Client must send user JWT. Never embed service role in the Android app.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors })

  try {
    const authHeader = req.headers.get("Authorization")
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: cors })
    }

    const { track_id } = await req.json()
    if (!track_id) {
      return new Response(JSON.stringify({ error: "track_id required" }), { status: 400, headers: cors })
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    )

    // Verify user JWT
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    )
    const { data: { user } } = await userClient.auth.getUser()
    if (!user) {
      return new Response(JSON.stringify({ error: "invalid session" }), { status: 401, headers: cors })
    }

    const { data: track, error } = await supabase
      .from("tracks")
      .select("id,status,storage_bucket,storage_object_path,external_stream_url")
      .eq("id", track_id)
      .single()

    if (error || !track || track.status !== "published") {
      return new Response(JSON.stringify({ error: "not_available" }), { status: 404, headers: cors })
    }

    // Rights check
    const { data: allowed } = await supabase.rpc("track_stream_allowed", { p_track_id: track_id })
    if (allowed === false) {
      return new Response(JSON.stringify({ error: "rights_denied" }), { status: 403, headers: cors })
    }

    if (track.external_stream_url) {
      return new Response(JSON.stringify({ url: track.external_stream_url, expires_in: null }), {
        headers: { ...cors, "Content-Type": "application/json" },
      })
    }

    if (!track.storage_object_path) {
      return new Response(JSON.stringify({ error: "no_audio" }), { status: 404, headers: cors })
    }

    const bucket = track.storage_bucket || "music"
    const { data: signed, error: signErr } = await supabase.storage
      .from(bucket)
      .createSignedUrl(track.storage_object_path, 3600)

    if (signErr || !signed?.signedUrl) {
      return new Response(JSON.stringify({ error: "sign_failed" }), { status: 500, headers: cors })
    }

    // Audit stream start (best-effort)
    await supabase.from("stream_events").insert({
      user_id: user.id,
      track_id: track_id,
    })

    return new Response(JSON.stringify({ url: signed.signedUrl, expires_in: 3600 }), {
      headers: { ...cors, "Content-Type": "application/json" },
    })
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: cors })
  }
})
