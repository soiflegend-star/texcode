# Build QUBRIX

## Requirements

- Node.js 22 (use the current Node 22 LTS release)
- npm bundled with Node.js
- Git

## Local development

```bash
npm ci
npm run dev
```

Open `http://localhost:8080`.

## Verify before publishing

```bash
npm run typecheck
npm run test:quiz
npm test
npm run build
```

The production build writes the deployable output through Vite/Nitro. The build
runs the migration step after compilation. That step safely skips when
`DATABASE_URL` is not configured; configure it in the deployment environment
when using the PostgreSQL migration path. Never commit database credentials or
other secrets to GitHub.

## GitHub

Push the repository to GitHub. The workflow in `.github/workflows/ci.yml`
installs the exact lockfile dependencies, runs typechecking and tests, and
performs a production build for pushes and pull requests to `main`/`master`.
A green workflow is the build verification signal; a successful local ZIP
creation alone is not proof that the app compiles.
