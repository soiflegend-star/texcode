# QUBRIX PRISM — Max-level Learning Intelligence

**PRISM** = Personalized Retrieval, Intelligence, Sequencing & Motivation

Integrated into existing QUBRIX (glass UI, curriculum, generators, progress preserved).

## Performance (speed)

| Optimisation | Detail |
|---|---|
| **ExposureIndex** | Built once per plan; O(1) id + fingerprint lookups |
| **checkNoveltyFast** | Hot path used by `collectTopic` — no re-scan of full exposure map |
| **Fingerprint WeakMap cache** | Structural + primary FP cached per question object |
| **Single-pass normalize** | Digit/punctuation stripping without intermediate regex allocations |
| **Tight miss bound** | Generator scan stops earlier when unproductive (`missLimit`) |
| **Shared index** | `planTopic` / `planQuick` / `planAdaptive` / `planMixed` share one index |
| **Snappier victory** | Pulse 0.45s, overlay ~1.4s, reduced-motion ~0.5s |

## Capability (max level)

### Novelty Guard
- Exact ID, structural fingerprint, session seen-set
- Lifetime exposure via `questions` + `prism.exposures`
- Fresh vs revision separation; honest exhaustion messaging

### Adaptive Brain
- Accuracy + recent accuracy blend; weak/strong topic lists
- Gradual promote/demote; micro-promote after sustained medium success
- Weighted topic selection in adaptive sessions

### Variety Engine
- Family rotation, type rotation, challenge rounds after strong sessions

### Victory Experience
- Correct: glow, pulse, particles, XP counter
- Session/perfect: crystal + energy rings overlay
- Motion preferences respected

### Question Intelligence
- Multi-level fingerprints for near-duplicate control
- Analytics for honest bank diversity measurement

## Module map

```
src/lib/prism/
  fingerprint.ts   — fast normalize + cached fingerprints
  novelty.ts       — ExposureIndex + checkNoveltyFast
  adaptive.ts      — signals + difficulty controller
  variety.ts       — sequencing / challenge
  victory.ts       — celebration levels
  analytics.ts     — distinct-FP bank stats
  types.ts / index.ts / prism.test.ts
src/components/qx/prism-effects.tsx
src/lib/learn/selection.ts   — integrated planners
```

## Tests
```
npm run test:quiz   # includes prism (88+ tests)
```

## Wiring completion update (2026-11-20)

- **Persistent exposure ledger is now part of AppState** (`prism.exposures`), is sanitized on load/import, and survives save/export/import round trips. Older v3 saves remain compatible because the ledger defaults to empty.
- **Exposure recording is wired to real learning events**: practice answers, revealed answers, and submitted mock-exam answers. `recordExposure` only writes the PRISM ledger; normal answer statistics remain owned by `recordAnswer`, avoiding duplicate attempt counts.
- **Variety sequencing is wired into shared plan finalization**: selected questions are stably reordered to avoid three identical question types in a row when another type is available. No question is removed or duplicated.
- **Analytics remains an exported analysis API**, not a student-facing dashboard. It is deliberately not presented as an active UI feature.
- **Challenge-round gate remains a utility**, not an automatic post-session flow. The app does not currently launch a separate hard-only challenge round.

## Verification

- PRISM tests: 19/19 pass.
- Learning engine tests: 32/32 pass.
- Full `test:quiz` was attempted but exceeded the available run window; a full TypeScript/build check could not be completed because dependency installation did not finish.
