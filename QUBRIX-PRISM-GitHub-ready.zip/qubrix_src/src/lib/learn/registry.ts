import { BOARDS, type BoardInfo } from "../quiz/catalog.ts";
import { curriculumFor, type CurriculumSubject, type CurriculumTopic } from "../quiz/curriculum.ts";
import { authoredFor } from "./content/authored-wbbse10.ts";
import { GEN_SUPPLY } from "./supply.data.ts";

export type Readiness = "available" | "partial" | "preparing" | "unsupported";
export const READINESS_LABEL: Record<Readiness, string> = {
  available: "Available",
  partial: "Partially available",
  preparing: "Content being prepared",
  unsupported: "Not yet supported",
};
export const CLASS_LEVELS = [5, 6, 7, 8, 9, 10, 11] as const;
/** Topics with fewer total questions than this are shown as "partially available". */
export const THIN_TOPIC_LIMIT = 100;

export type TopicInfo = CurriculumTopic & {
  subjectId: string;
  order: number;
  authored: number;
  generated: number;
  readiness: Readiness;
};
export type SubjectInfoV3 = { id: string; title: string; order: number; topics: TopicInfo[]; readiness: Readiness };

export function generatedSupply(subjectId: string, tags: string[]): number {
  const table = GEN_SUPPLY[subjectId] ?? {};
  return tags.reduce((n, t) => n + (table[t] ?? 0), 0);
}

function topicReadiness(authored: number, generated: number): Readiness {
  const total = authored + generated;
  if (total === 0) return "preparing";
  return total < THIN_TOPIC_LIMIT ? "partial" : "available";
}

export function subjectsOf(board: string, grade: number): SubjectInfoV3[] {
  return curriculumFor(board, grade).map((s: CurriculumSubject, si) => {
    const topics: TopicInfo[] = s.topics.map((t, ti) => {
      const authored = authoredFor(board, grade, s.id, t.id).length;
      const generated = generatedSupply(s.id, t.generatorTags);
      return { ...t, subjectId: s.id, order: ti + 1, authored, generated, readiness: topicReadiness(authored, generated) };
    });
    const ready = topics.filter((t) => t.readiness !== "preparing").length;
    const full = topics.filter((t) => t.readiness === "available").length;
    const readiness: Readiness = ready === 0 ? "preparing" : full === topics.length ? "available" : "partial";
    return { id: s.id, title: s.title, order: si + 1, topics, readiness };
  });
}

export function availability(board: string, grade: number): { state: Readiness; note: string } {
  const subjects = subjectsOf(board, grade);
  if (subjects.length === 0) {
    return { state: "unsupported", note: "No verified syllabus mapping or question bank has been added for this board and class yet." };
  }
  const usable = subjects.filter((s) => s.readiness !== "preparing").length;
  if (usable === 0) return { state: "preparing", note: "Syllabus mapped; questions are being prepared." };
  const allFull = subjects.every((s) => s.readiness === "available");
  return {
    state: allFull ? "available" : "partial",
    note: `${usable} of ${subjects.length} subjects have practice questions. Chapter coverage is still being reviewed.`,
  };
}

export function isSupported(board: string, grade: number): boolean {
  return subjectsOf(board, grade).length > 0;
}
export function findSubject(board: string, grade: number, subjectId: string): SubjectInfoV3 | undefined {
  return subjectsOf(board, grade).find((s) => s.id === subjectId);
}
export function findTopic(board: string, grade: number, subjectId: string, topicId: string): TopicInfo | undefined {
  return findSubject(board, grade, subjectId)?.topics.find((t) => t.id === topicId);
}
export function practiceTopics(board: string, grade: number): TopicInfo[] {
  return subjectsOf(board, grade).flatMap((s) => s.topics.filter((t) => t.readiness !== "preparing"));
}
export function boardList(): (BoardInfo & { classes: { grade: number; state: Readiness; note: string }[] })[] {
  return BOARDS.map((b) => ({ ...b, classes: CLASS_LEVELS.map((g) => ({ grade: g, ...availability(b.id, g) })) }));
}
