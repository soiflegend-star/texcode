import { topicsFor } from "../quiz/bank.ts";
import { WBBSE_CLASS_10_2026_27 } from "../quiz/curriculum.ts";
import { AUTHORED_WBBSE10 } from "./content/authored-wbbse10.ts";
import { boardList } from "./registry.ts";
import { streamQuestion, tagsFor } from "./resolve.ts";
import { findDuplicates, validateQuestion, type Issue } from "./validate.ts";
import type { QuestionRecord } from "./types.ts";

export type TopicReport = { subjectId: string; topicId: string; status: string; authored: number; generatedSupply: number; sampled: number; unreviewedFlag: string };
export type ContentReport = {
  topics: TopicReport[];
  structural: Issue[]; // fail CI
  leakage: string[]; // fail CI
  missingTags: string[]; // fail CI
  duplicateCandidates: { authored: [string, string, number][]; generatedExactRepeats: number };
  gaps: string[]; // reported, not failures
  unsupported: string[];
};

export function buildReport(sampleSize = 150): ContentReport {
  const structural: Issue[] = [];
  const leakage: string[] = [];
  const missingTags: string[] = [];
  const gaps: string[] = [];
  const topics: TopicReport[] = [];
  let exactRepeats = 0;
  for (const s of WBBSE_CLASS_10_2026_27) {
    const known = new Set(topicsFor(s.id, "wbbse", 10));
    for (const t of s.topics) {
      for (const tag of t.generatorTags) if (!known.has(tag)) missingTags.push(`${s.id}/${t.id}: tag "${tag}" does not exist in generators`);
      const authored = AUTHORED_WBBSE10.filter((a) => a.subjectId === s.id && a.topicId === t.id);
      for (const a of authored) structural.push(...validateQuestion(a));
      const sigs = new Set<string>();
      let sampled = 0;
      const tags = tagsFor("wbbse", 10, s.id, t.id);
      if (tags.length) {
        for (let n = 0; n < sampleSize; n++) {
          const q: QuestionRecord | null = streamQuestion("wbbse", 10, s.id, t.id, n);
          if (!q) break;
          sampled++;
          structural.push(...validateQuestion(q));
          if (!q.generatorTag || !tags.includes(q.generatorTag)) leakage.push(`${q.id}: tag ${q.generatorTag} not in ${tags.join(",")}`);
          const sig = `${q.prompt}@@${q.options[q.answer[0]!]}`;
          if (sigs.has(sig)) exactRepeats++;
          sigs.add(sig);
        }
      }
      const status = t.contentStatus;
      if (!authored.length && !tags.length) gaps.push(`${s.title} › ${t.title}: no questions (content needed)`);
      else if (!authored.length) gaps.push(`${s.title} › ${t.title}: generator-backed only; needs authored, source-checked questions`);
      topics.push({ subjectId: s.id, topicId: t.id, status, authored: authored.length, generatedSupply: 0, sampled, unreviewedFlag: "machine-validated only" });
    }
  }
  const unsupported: string[] = [];
  for (const b of boardList()) for (const c of b.classes) if (c.state === "unsupported") unsupported.push(`${b.id}:${c.grade}`);
  return {
    topics, structural, leakage, missingTags,
    duplicateCandidates: { authored: findDuplicates(AUTHORED_WBBSE10), generatedExactRepeats: exactRepeats },
    gaps, unsupported,
  };
}
