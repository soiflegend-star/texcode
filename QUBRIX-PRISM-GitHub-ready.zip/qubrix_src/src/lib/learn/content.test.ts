import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { topicsFor, topicQuestionCount, BANK_SIZE } from "../quiz/bank.ts";
import { WBBSE_CLASS_10_2026_27 } from "../quiz/curriculum.ts";
import { AUTHORED_WBBSE10 } from "./content/authored-wbbse10.ts";
import { NOTES_WBBSE10, REFERENCE_WBBSE10 } from "./content/reference-wbbse10.ts";
import { availability, boardList, practiceTopics, subjectsOf } from "./registry.ts";
import { buildReport } from "./report.ts";
import { resolveQuestion, streamQuestion, genKey, parseKey } from "./resolve.ts";
import { search } from "./search.ts";
import { GEN_SUPPLY } from "./supply.data.ts";
import { findDuplicates, validateQuestion } from "./validate.ts";
import type { QuestionRecord } from "./types.ts";

describe("question schema validation", () => {
  const base = AUTHORED_WBBSE10[0]!;
  it("accepts every authored question", () => {
    for (const q of AUTHORED_WBBSE10) assert.deepEqual(validateQuestion(q), [], q.id);
  });
  it("rejects broken MCQs", () => {
    const codes = (r: QuestionRecord) => validateQuestion(r).map((i) => i.code);
    assert.ok(codes({ ...base, options: ["a", "a", "b", "c"] }).includes("options"));
    assert.ok(codes({ ...base, options: ["a", "b", "c"] }).includes("options"));
    assert.ok(codes({ ...base, answer: [4] }).includes("answer"));
    assert.ok(codes({ ...base, explanation: "" }).includes("explanation"));
    assert.ok(codes({ ...base, prompt: "" }).includes("prompt"));
    assert.ok(codes({ ...base, sources: [] }).includes("source"));
    assert.ok(codes({ ...base, topicId: "" }).includes("association"));
  });
  it("refuses unearned review badges", () => {
    assert.ok(validateQuestion({ ...base, review: "human-reviewed" }).some((i) => i.code === "review-claim"));
  });
  it("detects near-duplicate authored questions", () => {
    const dup = { ...base, id: "a:dup" };
    assert.equal(findDuplicates([base, dup]).length, 1);
    assert.equal(findDuplicates(AUTHORED_WBBSE10).length, 0);
  });
  it("authored ids are unique", () => {
    assert.equal(new Set(AUTHORED_WBBSE10.map((q) => q.id)).size, AUTHORED_WBBSE10.length);
  });
});

describe("curriculum isolation", () => {
  it("every mapped generator tag exists (no phantom tags)", () => {
    for (const s of WBBSE_CLASS_10_2026_27) {
      const known = new Set(topicsFor(s.id, "wbbse", 10));
      for (const t of s.topics) for (const tag of t.generatorTags) assert.ok(known.has(tag), `${s.id}/${t.id}: ${tag}`);
    }
  });
  it("supply snapshot matches the generators", () => {
    for (const [subject, tags] of Object.entries(GEN_SUPPLY)) {
      const board = subject === "gk" ? "general" : "wbbse";
      for (const [tag, n] of Object.entries(tags)) assert.equal(topicQuestionCount(board, subject, tag, 10), n, `${subject}/${tag}`);
    }
  });
  it("served generated questions carry only tags of the requested chapter", () => {
    const r = buildReport(80);
    assert.deepEqual(r.leakage, []);
    assert.deepEqual(r.missingTags, []);
    assert.deepEqual(r.structural, []);
    assert.deepEqual(r.duplicateCandidates.authored, []);
  });
  it("unknown or content-needed topics return null, never a fallback", () => {
    assert.equal(streamQuestion("wbbse", 10, "maths", "no-such-topic", 0), null);
    assert.equal(streamQuestion("wbbse", 10, "history", "history-syllabus-pending", 0), null);
    assert.equal(streamQuestion("wbbse", 10, "geography", "atmosphere", 3), null);
    assert.equal(streamQuestion("cbse", 10, "maths", "arithmetic", 0), null);
    assert.equal(streamQuestion("wbbse", 9, "maths", "arithmetic", 0), null);
    assert.equal(resolveQuestion("g|wbbse|10|maths|nope|1"), null);
    assert.equal(resolveQuestion("garbage"), null);
    assert.equal(parseKey("g|wbbse|x|maths|a|1"), null);
  });
  it("only WBBSE class 10 is supported; others are gated", () => {
    assert.notEqual(availability("wbbse", 10).state, "unsupported");
    assert.equal(availability("wbbse", 9).state, "unsupported");
    for (const b of boardList()) for (const c of b.classes) if (!(b.id === "wbbse" && c.grade === 10)) assert.equal(c.state, "unsupported");
    assert.equal(practiceTopics("cbse", 10).length, 0);
  });
  it("History and Bengali are 'being prepared', not quiz-enabled", () => {
    const subs = subjectsOf("wbbse", 10);
    assert.equal(subs.find((s) => s.id === "history")!.readiness, "preparing");
    assert.equal(subs.find((s) => s.id === "bengali")!.readiness, "preparing");
  });
  it("reference and notes point at real topics", () => {
    const ids = new Set(WBBSE_CLASS_10_2026_27.flatMap((s) => s.topics.map((t) => `${s.id}/${t.id}`)));
    for (const e of REFERENCE_WBBSE10) assert.ok(ids.has(`${e.subjectId}/${e.topicId}`), e.id);
    for (const n of NOTES_WBBSE10) assert.ok(ids.has(`${n.subjectId}/${n.topicId}`));
    assert.equal(new Set(REFERENCE_WBBSE10.map((e) => e.id)).size, REFERENCE_WBBSE10.length);
  });
  it("search respects the selected curriculum", () => {
    assert.ok(search("wbbse", 10, "quadratic").length > 0);
    assert.equal(search("cbse", 10, "quadratic").length, 0);
    assert.equal(search("wbbse", 10, "   ").length, 0);
  });
});

describe("deterministic generation", () => {
  it("same key always gives the same question, also beyond the 30,000 milestone", () => {
    const key = genKey("wbbse", 10, "maths", "arithmetic", 5);
    assert.deepEqual(resolveQuestion(key), resolveQuestion(key));
    const total = topicQuestionCount("wbbse", "maths", "Simple interest", 10);
    assert.ok(total > 0);
    const far = streamQuestion("wbbse", 10, "maths", "algebra", BANK_SIZE + 123);
    assert.ok(far, "stream continues past BANK_SIZE");
    assert.deepEqual(far, streamQuestion("wbbse", 10, "maths", "algebra", BANK_SIZE + 123));
    assert.equal(validateQuestion(far!).length, 0);
  });
});
