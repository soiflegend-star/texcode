import { newReviewItem, scheduleReview, dateKeyOf, addDays, type ReviewItem } from "./review.ts";
import { parseKey } from "./resolve.ts";
import type { Session, SessionResult } from "./types.ts";
import type { ExposureRecord } from "../prism/types.ts";

export const STATE_VERSION = 3;
export const STORAGE_KEY = "qubrix-state-v3";
export const LEGACY_KEY = "qubrix-progress-v2";

export type TopicStat = { attempts: number; correct: number; recent: string; lastAt: number; cursor: number };
export type QStat = { attempts: number; correct: number; lastAt: number; correctRun: number };
export type DayStat = { answered: number; correct: number; xp: number };
export type TestSummary = {
  id: string; at: number; title: string; total: number; correct: number; attempted: number;
  scorePct: number; timeUsedSec: number; reason: "manual" | "timeout";
};
export type Profile = {
  onboarded: boolean;
  board: string;
  grade: number;
  medium: "en";
  lastSubject: string | null;
  lastTopic: string | null;
  dailyTarget: number;
  motion: "system" | "reduce" | "full";
  sound: boolean;
};
export type AppState = {
  version: 3;
  rev: number;
  profile: Profile;
  xp: number;
  totals: { answered: number; correct: number; sessions: number; hints: number; reviews: number };
  streak: { current: number; best: number; lastDate: string | null };
  bestAnswerStreak: number;
  days: Record<string, DayStat>;
  topics: Record<string, TopicStat>;
  questions: Record<string, QStat>;
  awarded: string[];
  bookmarks: string[];
  mistakes: Record<string, { count: number; lastAt: number; resolved: boolean }>;
  reviews: Record<string, ReviewItem>;
  notes: { chapter: Record<string, string>; question: Record<string, string> };
  reports: { key: string; reason: string; at: number }[];
  daily: Record<string, { done: boolean; correct: number; total: number; sessionId: string }>;
  tests: TestSummary[];
  active: Session | null;
  /** PRISM's bounded lifetime exposure ledger; optional in older v3 saves. */
  prism: { exposures: Record<string, ExposureRecord> };
  achievements: Record<string, number>;
  legacy: { migratedFrom: "v2" | null; answered: number; correct: number; byKey: Record<string, { answered: number; correct: number; xp: number; index: number }> };
};

export const topicKey = (board: string, grade: number, subjectId: string, topicId: string): string => `${board}:${grade}:${subjectId}:${topicId}`;
export { dateKeyOf };

export function defaultState(): AppState {
  return {
    version: 3, rev: 0,
    profile: { onboarded: false, board: "wbbse", grade: 10, medium: "en", lastSubject: null, lastTopic: null, dailyTarget: 10, motion: "system", sound: false },
    xp: 0,
    totals: { answered: 0, correct: 0, sessions: 0, hints: 0, reviews: 0 },
    streak: { current: 0, best: 0, lastDate: null },
    bestAnswerStreak: 0,
    days: {}, topics: {}, questions: {}, awarded: [], bookmarks: [], mistakes: {}, reviews: {},
    notes: { chapter: {}, question: {} }, reports: [], daily: {}, tests: [], active: null, prism: { exposures: {} }, achievements: {},
    legacy: { migratedFrom: null, answered: 0, correct: 0, byKey: {} },
  };
}

// ---------- sanitising (used for storage loads and imports) ----------
const isObj = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);
const num = (v: unknown, d = 0): number => (typeof v === "number" && Number.isFinite(v) ? v : d);
const str = (v: unknown, d = ""): string => (typeof v === "string" ? v : d);
const nonNeg = (v: unknown): number => Math.max(0, Math.floor(num(v)));
function rec<T>(v: unknown, f: (x: unknown) => T | null, max = 5000): Record<string, T> {
  const out: Record<string, T> = {};
  if (!isObj(v)) return out;
  for (const k of Object.keys(v).slice(0, max)) {
    if (k === "__proto__" || k === "constructor" || k === "prototype") continue;
    const x = f(v[k]);
    if (x !== null) out[k] = x;
  }
  return out;
}
const strs = (v: unknown, max: number): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string").slice(-max) : []);

export function isSessionShape(v: unknown): v is Session {
  if (!isObj(v)) return false;
  const items = v.items;
  if (!Array.isArray(items) || items.length === 0 || items.length > 200) return false;
  if (!items.every((i) => isObj(i) && typeof i.key === "string" && parseKey(i.key) !== null)) return false;
  for (const f of ["answers", "hints", "marked"] as const) if (!Array.isArray(v[f]) || (v[f] as unknown[]).length !== items.length) return false;
  const kinds = ["practice", "quick", "adaptive", "revision", "daily", "mixed", "exam"];
  return typeof v.id === "string" && kinds.includes(str(v.kind)) && typeof v.startedAt === "number" && (v.status === "active" || v.status === "submitted") && Number.isInteger(v.current) && (v.current as number) >= 0 && (v.current as number) < items.length;
}

export function sanitizeState(raw: unknown): AppState | null {
  if (!isObj(raw) || raw.version !== 3) return null;
  const d = defaultState();
  const p = isObj(raw.profile) ? raw.profile : {};
  const motion = str(p.motion);
  const profile: Profile = {
    onboarded: p.onboarded === true,
    board: str(p.board, d.profile.board) || d.profile.board,
    grade: Math.min(12, Math.max(1, Math.floor(num(p.grade, 10)))),
    medium: "en",
    lastSubject: typeof p.lastSubject === "string" ? p.lastSubject : null,
    lastTopic: typeof p.lastTopic === "string" ? p.lastTopic : null,
    dailyTarget: Math.min(100, Math.max(1, Math.floor(num(p.dailyTarget, 10)))),
    motion: motion === "reduce" || motion === "full" ? motion : "system",
    sound: p.sound === true,
  };
  const t = isObj(raw.totals) ? raw.totals : {};
  const sk = isObj(raw.streak) ? raw.streak : {};
  const lg = isObj(raw.legacy) ? raw.legacy : {};
  const nts = isObj(raw.notes) ? raw.notes : {};
  const prismRaw = isObj(raw.prism) ? raw.prism : {};
  const exposureRaw = isObj(prismRaw.exposures) ? prismRaw.exposures : {};
  const prismExposures: Record<string, ExposureRecord> = {};
  for (const [id, value] of Object.entries(exposureRaw).slice(-8000)) {
    if (!isObj(value) || typeof value.id !== "string" || typeof value.fingerprint !== "string") continue;
    prismExposures[id] = {
      id: value.id, fingerprint: value.fingerprint, subjectId: str(value.subjectId), topicId: str(value.topicId),
      firstAt: nonNeg(value.firstAt), lastAt: nonNeg(value.lastAt), count: Math.max(1, nonNeg(value.count)),
      sessionIds: strs(value.sessionIds, 8),
    };
  }
  return {
    version: 3, rev: nonNeg(raw.rev), profile,
    xp: nonNeg(raw.xp),
    totals: { answered: nonNeg(t.answered), correct: nonNeg(t.correct), sessions: nonNeg(t.sessions), hints: nonNeg(t.hints), reviews: nonNeg(t.reviews) },
    streak: { current: nonNeg(sk.current), best: nonNeg(sk.best), lastDate: typeof sk.lastDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(sk.lastDate) ? sk.lastDate : null },
    bestAnswerStreak: nonNeg(raw.bestAnswerStreak),
    days: rec(raw.days, (x) => (isObj(x) ? { answered: nonNeg(x.answered), correct: nonNeg(x.correct), xp: nonNeg(x.xp) } : null), 400),
    topics: rec(raw.topics, (x) => (isObj(x) ? { attempts: nonNeg(x.attempts), correct: nonNeg(x.correct), recent: str(x.recent).replace(/[^01]/g, "").slice(-12), lastAt: nonNeg(x.lastAt), cursor: nonNeg(x.cursor) } : null)),
    questions: rec(raw.questions, (x) => (isObj(x) ? { attempts: nonNeg(x.attempts), correct: nonNeg(x.correct), lastAt: nonNeg(x.lastAt), correctRun: nonNeg(x.correctRun) } : null), 4000),
    awarded: strs(raw.awarded, 3000),
    bookmarks: [...new Set(strs(raw.bookmarks, 2000))],
    mistakes: rec(raw.mistakes, (x) => (isObj(x) ? { count: nonNeg(x.count), lastAt: nonNeg(x.lastAt), resolved: x.resolved === true } : null), 3000),
    reviews: rec(raw.reviews, (x) => {
      if (!isObj(x) || typeof x.id !== "string" || typeof x.ref !== "string" || typeof x.due !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(x.due)) return null;
      return { id: x.id, kind: x.kind === "card" ? "card" : "question", ref: x.ref, box: Math.min(5, Math.max(1, nonNeg(x.box) || 1)), due: x.due, reps: nonNeg(x.reps), lapses: nonNeg(x.lapses) } as ReviewItem;
    }, 4000),
    notes: {
      chapter: rec(nts.chapter, (x) => (typeof x === "string" ? x.slice(0, 5000) : null), 500),
      question: rec(nts.question, (x) => (typeof x === "string" ? x.slice(0, 2000) : null), 2000),
    },
    reports: Array.isArray(raw.reports) ? raw.reports.filter(isObj).slice(-200).map((r) => ({ key: str(r.key), reason: str(r.reason).slice(0, 500), at: nonNeg(r.at) })) : [],
    daily: rec(raw.daily, (x) => (isObj(x) ? { done: x.done === true, correct: nonNeg(x.correct), total: nonNeg(x.total), sessionId: str(x.sessionId) } : null), 400),
    tests: Array.isArray(raw.tests) ? raw.tests.filter(isObj).slice(-50).map((x) => ({ id: str(x.id), at: nonNeg(x.at), title: str(x.title), total: nonNeg(x.total), correct: nonNeg(x.correct), attempted: nonNeg(x.attempted), scorePct: Math.min(100, nonNeg(x.scorePct)), timeUsedSec: nonNeg(x.timeUsedSec), reason: x.reason === "timeout" ? "timeout" as const : "manual" as const })) : [],
    active: isSessionShape(raw.active) ? (raw.active as Session) : null,
    prism: { exposures: prismExposures },
    achievements: rec(raw.achievements, (x) => (typeof x === "number" ? x : null), 100),
    legacy: {
      migratedFrom: lg.migratedFrom === "v2" ? "v2" : null,
      answered: nonNeg(lg.answered), correct: nonNeg(lg.correct),
      byKey: rec(lg.byKey, (x) => (isObj(x) ? { answered: nonNeg(x.answered), correct: nonNeg(x.correct), xp: nonNeg(x.xp), index: nonNeg(x.index) } : null), 2000),
    },
  };
}

// ---------- legacy migration: qubrix-progress-v2 ----------
export function migrateLegacyV2(raw: unknown, tagToTopic: (board: string, grade: number, tag: string) => { subjectId: string; topicId: string } | null): AppState | null {
  if (!isObj(raw)) return null;
  const s = defaultState();
  let found = false;
  for (const [k, v] of Object.entries(raw)) {
    if (!isObj(v)) continue;
    found = true;
    const answered = nonNeg(v.answered), correct = Math.min(answered, nonNeg(v.correct)), xp = nonNeg(v.xp);
    s.xp += xp;
    s.totals.answered += answered;
    s.totals.correct += correct;
    s.legacy.answered += answered;
    s.legacy.correct += correct;
    s.bestAnswerStreak = Math.max(s.bestAnswerStreak, nonNeg(v.best));
    s.legacy.byKey[k] = { answered, correct, xp, index: nonNeg(v.index) };
    const [board, grade, subject, ...rest] = k.split(":");
    const tag = rest.join(":");
    if (board && subject && tag && tag !== "all") {
      const m = tagToTopic(board, Number(grade), tag);
      if (m && answered > 0) {
        const key = topicKey(board, Number(grade), m.subjectId, m.topicId);
        const cur = s.topics[key] ?? { attempts: 0, correct: 0, recent: "", lastAt: 0, cursor: 0 };
        s.topics[key] = { ...cur, attempts: cur.attempts + answered, correct: cur.correct + correct, cursor: cur.cursor + nonNeg(v.index) };
      }
    }
  }
  if (!found) return null;
  s.legacy.migratedFrom = "v2";
  return s;
}

// ---------- pure transitions ----------
function trim<T>(arr: T[], max: number): T[] { return arr.length > max ? arr.slice(arr.length - max) : arr; }

export function touchDay(s: AppState, now: number): AppState {
  const today = dateKeyOf(now);
  if (s.streak.lastDate === today) return s;
  const cur = s.streak.lastDate === addDays(today, -1) ? s.streak.current + 1 : 1;
  return { ...s, streak: { current: cur, best: Math.max(s.streak.best, cur), lastDate: today } };
}

/** Awards XP at most once per eventId. Returns the same state object on a repeat. */
export function awardOnce(s: AppState, eventId: string, xp: number, now: number): AppState {
  if (s.awarded.includes(eventId)) return s;
  const today = dateKeyOf(now);
  const day = s.days[today] ?? { answered: 0, correct: 0, xp: 0 };
  return { ...s, xp: s.xp + xp, awarded: trim([...s.awarded, eventId], 3000), days: { ...s.days, [today]: { ...day, xp: day.xp + xp } } };
}

export type AnswerEvent = {
  eventId: string; key: string; board: string; grade: number; subjectId: string; topicId: string;
  correct: boolean; hinted: boolean; revealed: boolean; xp: number; now: number; streakAfter?: number;
};

/** The one place an answered question changes learner state. Idempotent per eventId. */
export function recordAnswer(s0: AppState, e: AnswerEvent): AppState {
  const evId = `ans:${e.eventId}`;
  if (s0.awarded.includes(evId)) return s0;
  let s = touchDay(s0, e.now);
  const today = dateKeyOf(e.now);
  const tk = topicKey(e.board, e.grade, e.subjectId, e.topicId);
  const ts = s.topics[tk] ?? { attempts: 0, correct: 0, recent: "", lastAt: 0, cursor: 0 };
  const qs = s.questions[e.key] ?? { attempts: 0, correct: 0, lastAt: 0, correctRun: 0 };
  const run = e.correct ? qs.correctRun + 1 : 0;
  const day = s.days[today] ?? { answered: 0, correct: 0, xp: 0 };
  const mistakes = { ...s.mistakes };
  if (!e.correct) mistakes[e.key] = { count: (mistakes[e.key]?.count ?? 0) + 1, lastAt: e.now, resolved: false };
  else if (mistakes[e.key] && run >= 2) mistakes[e.key] = { ...mistakes[e.key]!, resolved: true };
  const existing = s.reviews[`q:${e.key}`];
  const reviews = { ...s.reviews };
  if (!e.correct) reviews[`q:${e.key}`] = existing ? scheduleReview(existing, false, today) : newReviewItem(`q:${e.key}`, "question", e.key, today);
  else if (existing) reviews[`q:${e.key}`] = scheduleReview(existing, true, today);
  s = {
    ...s,
    totals: { ...s.totals, answered: s.totals.answered + 1, correct: s.totals.correct + (e.correct ? 1 : 0), hints: s.totals.hints + (e.hinted ? 1 : 0) },
    topics: { ...s.topics, [tk]: { ...ts, attempts: ts.attempts + 1, correct: ts.correct + (e.correct ? 1 : 0), recent: (ts.recent + (e.correct ? "1" : "0")).slice(-12), lastAt: e.now } },
    questions: { ...s.questions, [e.key]: { attempts: qs.attempts + 1, correct: qs.correct + (e.correct ? 1 : 0), lastAt: e.now, correctRun: run } },
    days: { ...s.days, [today]: { ...day, answered: day.answered + 1, correct: day.correct + (e.correct ? 1 : 0) } },
    mistakes, reviews,
    bestAnswerStreak: Math.max(s.bestAnswerStreak, e.streakAfter ?? 0),
    profile: { ...s.profile, lastSubject: e.subjectId, lastTopic: e.topicId },
    awarded: trim([...s.awarded, evId], 3000),
  };
  // Anti-farming: a given question earns XP at most once per calendar day.
  if (e.xp > 0) s = awardOnce(s, `xp:${e.key}:${today}`, e.xp, e.now);
  return s;
}

export function advanceCursor(s: AppState, tk: string, by: number): AppState {
  const ts = s.topics[tk] ?? { attempts: 0, correct: 0, recent: "", lastAt: 0, cursor: 0 };
  return { ...s, topics: { ...s.topics, [tk]: { ...ts, cursor: ts.cursor + by } } };
}

export function toggleBookmark(s: AppState, key: string): AppState {
  return { ...s, bookmarks: s.bookmarks.includes(key) ? s.bookmarks.filter((k) => k !== key) : [...s.bookmarks, key].slice(-2000) };
}
export function addToMistakes(s: AppState, key: string, now: number): AppState {
  if (s.mistakes[key] && !s.mistakes[key]!.resolved) return s;
  const today = dateKeyOf(now);
  return { ...s, mistakes: { ...s.mistakes, [key]: { count: s.mistakes[key]?.count ?? 1, lastAt: now, resolved: false } }, reviews: s.reviews[`q:${key}`] ? s.reviews : { ...s.reviews, [`q:${key}`]: newReviewItem(`q:${key}`, "question", key, today) } };
}
export function setQuestionNote(s: AppState, key: string, text: string): AppState {
  const q = { ...s.notes.question };
  if (text.trim()) q[key] = text.slice(0, 2000); else delete q[key];
  return { ...s, notes: { ...s.notes, question: q } };
}
export function setChapterNote(s: AppState, tk: string, text: string): AppState {
  const c = { ...s.notes.chapter };
  if (text.trim()) c[tk] = text.slice(0, 5000); else delete c[tk];
  return { ...s, notes: { ...s.notes, chapter: c } };
}
export function reportQuestion(s: AppState, key: string, reason: string, now: number): AppState {
  return { ...s, reports: trim([...s.reports, { key, reason: reason.slice(0, 500), at: now }], 200) };
}
export function reviewCard(s: AppState, id: string, correct: boolean, now: number): AppState {
  const today = dateKeyOf(now);
  const it = s.reviews[id];
  if (!it) return s;
  s = touchDay(s, now);
  return { ...s, reviews: { ...s.reviews, [id]: scheduleReview(it, correct, today) }, totals: { ...s.totals, reviews: s.totals.reviews + 1 } };
}
export function ensureCard(s: AppState, id: string, ref: string, now: number): AppState {
  return s.reviews[id] ? s : { ...s, reviews: { ...s.reviews, [id]: newReviewItem(id, "card", ref, dateKeyOf(now)) } };
}

export function finishSessionState(s: AppState, session: Session, result: SessionResult, now: number): AppState {
  const sid = `done:${session.id}`;
  if (s.awarded.includes(sid)) return s;
  let n: AppState = { ...s, awarded: trim([...s.awarded, sid], 3000), totals: { ...s.totals, sessions: s.totals.sessions + 1 } };
  if (session.kind === "daily" && session.dateKey) {
    n = { ...n, daily: { ...n.daily, [session.dateKey]: { done: true, correct: result.correct, total: result.total, sessionId: session.id } } };
  }
  if (session.kind === "exam") {
    n = awardOnce(n, `exam:${session.id}`, result.correct * 5, now);
    n = { ...n, tests: trim([...n.tests, { id: session.id, at: now, title: session.title, total: result.total, correct: result.correct, attempted: result.attempted, scorePct: result.scorePct, timeUsedSec: result.timeUsedSec, reason: session.submitReason ?? "manual" }], 50) };
  }
  return n;
}
