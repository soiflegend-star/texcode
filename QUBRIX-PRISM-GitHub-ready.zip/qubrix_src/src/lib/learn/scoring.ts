import type { QuestionRecord, Response } from "./types.ts";

/** Single source of truth for grading and XP. Practice, daily, adaptive and exams all use these. */
export function isCorrect(q: QuestionRecord, r: Response | null): boolean {
  if (!r) return false;
  switch (q.type) {
    case "mcq":
    case "true-false":
      return r.type === "choice" && Number.isInteger(r.index) && q.answer.length === 1 && r.index === q.answer[0];
    case "multi-select": {
      if (r.type !== "multi") return false;
      const got = [...new Set(r.indexes)].sort((a, b) => a - b);
      const want = [...q.answer].sort((a, b) => a - b);
      return got.length === want.length && got.every((v, i) => v === want[i]);
    }
    case "numeric": {
      if (r.type !== "numeric" || !q.numeric || !Number.isFinite(r.value)) return false;
      return Math.abs(r.value - q.numeric.value) <= q.numeric.tolerance + 1e-9;
    }
  }
}

export const XP = { correct: 10, hinted: 5, streakBonusEvery: 5, streakBonus: 10, examPerCorrect: 5 } as const;

/** XP for a practice answer. Revealed or wrong answers earn nothing; hints halve the reward. */
export function answerXp(correct: boolean, hinted: boolean, revealed: boolean, streakAfter: number): number {
  if (!correct || revealed) return 0;
  const base = hinted ? XP.hinted : XP.correct;
  const bonus = !hinted && streakAfter > 0 && streakAfter % XP.streakBonusEvery === 0 ? XP.streakBonus : 0;
  return base + bonus;
}

/** Cumulative XP needed to reach `level` (level 1 = 0 XP). */
export function xpForLevel(level: number): number {
  return 50 * (level - 1) * level;
}
export function levelFor(xp: number): { level: number; into: number; span: number } {
  let level = 1;
  while (xp >= xpForLevel(level + 1)) level++;
  const start = xpForLevel(level);
  return { level, into: xp - start, span: xpForLevel(level + 1) - start };
}
