import { masteryOf } from "./review.ts";
import type { AppState } from "./state.ts";

export type Achievement = { id: string; title: string; text: string; test: (s: AppState) => boolean };
export const ACHIEVEMENTS: Achievement[] = [
  { id: "first-answer", title: "First step", text: "Answer your first question.", test: (s) => s.totals.answered >= 1 },
  { id: "answers-100", title: "Hundred strong", text: "Answer 100 questions.", test: (s) => s.totals.answered >= 100 },
  { id: "streak-3", title: "Three-day habit", text: "Study on 3 days in a row.", test: (s) => s.streak.best >= 3 },
  { id: "streak-7", title: "A full week", text: "Study on 7 days in a row.", test: (s) => s.streak.best >= 7 },
  { id: "answer-streak-10", title: "On a roll", text: "Get 10 correct answers in a row.", test: (s) => s.bestAnswerStreak >= 10 },
  { id: "topic-strong", title: "Topic mastered", text: "Reach Strong mastery in any topic.", test: (s) => Object.values(s.topics).some((t) => masteryOf(t) === "strong") },
  { id: "revision-10", title: "Reviser", text: "Complete 10 review or flashcard reviews.", test: (s) => s.totals.reviews >= 10 },
  { id: "daily-3", title: "Daily regular", text: "Complete 3 daily challenges.", test: (s) => Object.values(s.daily).filter((d) => d.done).length >= 3 },
  { id: "mock-80", title: "Mock test ace", text: "Score 80% or more in a mock test of 10+ questions.", test: (s) => s.tests.some((t) => t.total >= 10 && t.scorePct >= 80) },
  { id: "first-perfect", title: "First Perfect Session", text: "Complete a practice session with every answer correct (5+ questions).", test: (s) => s.tests.some((t) => t.total >= 5 && t.scorePct === 100) || (s.totals.sessions >= 1 && s.bestAnswerStreak >= 5) },
  { id: "concept-explorer", title: "Concept Explorer", text: "Answer questions across 5 different topics.", test: (s) => Object.keys(s.topics).filter((k) => (s.topics[k]?.attempts ?? 0) > 0).length >= 5 },
  { id: "analytical-thinker", title: "Analytical Thinker", text: "Get 20 questions correct.", test: (s) => s.totals.correct >= 20 },
  { id: "consistent-learner", title: "Consistent Learner", text: "Study on 5 different days.", test: (s) => Object.keys(s.days).length >= 5 },
  { id: "challenge-completed", title: "Challenge Completed", text: "Finish a daily challenge.", test: (s) => Object.values(s.daily).some((d) => d.done) },
  { id: "variety-explorer", title: "Question Variety Explorer", text: "Answer 50 distinct questions.", test: (s) => Object.keys(s.questions).length >= 50 },
];
export function unlockNew(s: AppState, now: number): AppState {
  const add: Record<string, number> = {};
  for (const a of ACHIEVEMENTS) if (!s.achievements[a.id] && a.test(s)) add[a.id] = now;
  return Object.keys(add).length ? { ...s, achievements: { ...s.achievements, ...add } } : s;
}
