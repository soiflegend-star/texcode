import type { QuestionRecord } from "./types.ts";

export type Issue = { id: string; code: string; message: string };

const tokens = (s: string): Set<string> => new Set(s.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").split(" ").filter(Boolean));
export function similarity(a: string, b: string): number {
  const x = tokens(a), y = tokens(b);
  if (!x.size || !y.size) return 0;
  let inter = 0;
  for (const t of x) if (y.has(t)) inter++;
  return inter / (x.size + y.size - inter);
}

export function validateQuestion(r: QuestionRecord): Issue[] {
  const out: Issue[] = [];
  const bad = (code: string, message: string) => out.push({ id: r.id, code, message });
  if (!r.id || !/^(a:|g\|)/.test(r.id)) bad("id", "missing or unstable id");
  if (!r.prompt || r.prompt.trim().length < 8) bad("prompt", "prompt is empty or too short");
  if (!r.explanation || r.explanation.trim().length < 8) bad("explanation", "missing explanation");
  if (!r.topicId || !r.subjectId || !r.board || !Number.isInteger(r.grade)) bad("association", "missing curriculum association");
  if (!r.sources.length) bad("source", "missing source reference");
  if (r.origin === "authored" && !r.objective) bad("objective", "authored question needs a learning objective");
  if (r.review === "human-reviewed" || r.review === "source-checked") {
    if (!r.sources.some((s) => s.kind === "textbook" || s.kind === "official-document")) bad("review-claim", `${r.review} requires a textbook/official source`);
  }
  if (r.examLabel === "exam-style practice" && r.origin !== "authored") bad("label", "only authored questions may be labelled exam-style");
  switch (r.type) {
    case "mcq": {
      if (r.options.length !== 4) bad("options", "MCQ needs exactly four options");
      if (r.options.some((o) => !o || !o.trim())) bad("options", "empty option");
      if (new Set(r.options.map((o) => o.trim())).size !== r.options.length) bad("options", "options are not distinct");
      if (r.answer.length !== 1 || !(r.answer[0]! >= 0 && r.answer[0]! < r.options.length)) bad("answer", "answer index out of range");
      break;
    }
    case "true-false":
      if (r.options.length !== 2 || r.answer.length !== 1 || !(r.answer[0]! >= 0 && r.answer[0]! < 2)) bad("options", "true/false needs two options and one valid answer");
      break;
    case "multi-select": {
      if (r.options.length < 3 || r.options.length > 6) bad("options", "multi-select needs 3-6 options");
      if (new Set(r.options.map((o) => o.trim())).size !== r.options.length) bad("options", "options are not distinct");
      if (r.answer.length < 1 || r.answer.length >= r.options.length || r.answer.some((i) => i < 0 || i >= r.options.length) || new Set(r.answer).size !== r.answer.length) bad("answer", "invalid multi-select answer set");
      break;
    }
    case "numeric":
      if (!r.numeric || !Number.isFinite(r.numeric.value) || !(r.numeric.tolerance >= 0)) bad("numeric", "numeric answer/tolerance invalid");
      break;
  }
  if (r.distractorNotes && r.distractorNotes.length !== r.options.length) bad("distractors", "distractorNotes length must match options");
  return out;
}

export function findDuplicates(rs: QuestionRecord[], threshold = 0.85): [string, string, number][] {
  const out: [string, string, number][] = [];
  for (let i = 0; i < rs.length; i++)
    for (let j = i + 1; j < rs.length; j++) {
      const a = rs[i]!, b = rs[j]!;
      if (a.topicId !== b.topicId || a.subjectId !== b.subjectId) continue;
      const s = similarity(a.prompt, b.prompt);
      if (s >= threshold) out.push([a.id, b.id, s]);
    }
  return out;
}
