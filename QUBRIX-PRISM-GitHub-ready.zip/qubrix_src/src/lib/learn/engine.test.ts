import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { AUTHORED_WBBSE10 } from "./content/authored-wbbse10.ts";
import { planAdaptive, planDaily, planExam, planMixed, planQuick, planRevision, planTopic } from "./selection.ts";
import { masteryOf, scheduleReview, newReviewItem, addDays } from "./review.ts";
import { resolveQuestion, signature } from "./resolve.ts";
import { answerXp, isCorrect, levelFor, xpForLevel } from "./scoring.ts";
import * as S from "./session.ts";
import { awardOnce, defaultState, finishSessionState, migrateLegacyV2, recordAnswer, sanitizeState, toggleBookmark, topicKey } from "./state.ts";
import { exportState, importState, loadState, memoryKV, saveState, tagToTopic } from "./storage.ts";
import { unlockNew } from "./achievements.ts";

const NOW = new Date(2026, 10, 20, 10, 0, 0).getTime();
const day = (n: number) => NOW + n * 86400000;
const mcq = AUTHORED_WBBSE10.find((q) => q.id === "a:wb10-maths-arithmetic-01")!;
const T = { board: "wbbse", grade: 10, subjectId: "maths", topicId: "arithmetic" };

function ev(over: Partial<Parameters<typeof recordAnswer>[1]> = {}) {
  return { eventId: "s1:0", key: mcq.id, ...T, correct: true, hinted: false, revealed: false, xp: 10, now: NOW, ...over };
}

describe("grading", () => {
  it("grades every question type", () => {
    assert.equal(isCorrect(mcq, { type: "choice", index: 0 }), true);
    assert.equal(isCorrect(mcq, { type: "choice", index: 1 }), false);
    assert.equal(isCorrect(mcq, null), false);
    assert.equal(isCorrect(mcq, { type: "numeric", value: 900 }), false);
    const multi = AUTHORED_WBBSE10.find((q) => q.type === "multi-select")!;
    assert.equal(isCorrect(multi, { type: "multi", indexes: [2, 1] }), true);
    assert.equal(isCorrect(multi, { type: "multi", indexes: [1] }), false);
    assert.equal(isCorrect(multi, { type: "multi", indexes: [1, 2, 3] }), false);
    const num = AUTHORED_WBBSE10.find((q) => q.type === "numeric")!;
    assert.equal(isCorrect(num, { type: "numeric", value: 400 }), true);
    assert.equal(isCorrect(num, { type: "numeric", value: 401 }), false);
    assert.equal(isCorrect(num, { type: "numeric", value: NaN }), false);
    const tf = AUTHORED_WBBSE10.find((q) => q.type === "true-false")!;
    assert.equal(isCorrect(tf, { type: "choice", index: 0 }), true);
  });
  it("xp rules: no xp for wrong/revealed, hints halve, streak bonus every 5", () => {
    assert.equal(answerXp(true, false, false, 1), 10);
    assert.equal(answerXp(true, true, false, 1), 5);
    assert.equal(answerXp(false, false, false, 0), 0);
    assert.equal(answerXp(true, false, true, 1), 0);
    assert.equal(answerXp(true, false, false, 5), 20);
    assert.equal(answerXp(true, true, false, 5), 5);
  });
  it("levels are monotonic", () => {
    assert.equal(levelFor(0).level, 1);
    assert.equal(levelFor(xpForLevel(4)).level, 4);
    assert.equal(levelFor(xpForLevel(4) - 1).level, 3);
  });
});

describe("answer recording", () => {
  it("is idempotent per event and never double-awards XP", () => {
    let s = recordAnswer(defaultState(), ev());
    const again = recordAnswer(s, ev());
    assert.equal(again, s);
    assert.equal(s.xp, 10);
    assert.equal(s.totals.answered, 1);
    s = recordAnswer(s, ev({ eventId: "s2:0" })); // same question, same day, new session
    assert.equal(s.totals.answered, 2);
    assert.equal(s.xp, 10, "same question earns XP once per day");
    s = recordAnswer(s, ev({ eventId: "s3:0", now: day(1) }));
    assert.equal(s.xp, 20, "earns again the next day");
  });
  it("wrong answers go to mistakes and the review queue; two correct in a row resolve them", () => {
    let s = recordAnswer(defaultState(), ev({ correct: false, xp: 0 }));
    assert.equal(s.mistakes[mcq.id]?.resolved, false);
    assert.ok(s.reviews[`q:${mcq.id}`]);
    s = recordAnswer(s, ev({ eventId: "b", now: day(1) }));
    s = recordAnswer(s, ev({ eventId: "c", now: day(2) }));
    assert.equal(s.mistakes[mcq.id]?.resolved, true);
  });
  it("day streak counts consecutive days only", () => {
    let s = recordAnswer(defaultState(), ev());
    s = recordAnswer(s, ev({ eventId: "2", now: day(1) }));
    assert.equal(s.streak.current, 2);
    s = recordAnswer(s, ev({ eventId: "3", now: day(4) }));
    assert.equal(s.streak.current, 1);
    assert.equal(s.streak.best, 2);
  });
  it("awardOnce is idempotent", () => {
    const s = awardOnce(defaultState(), "x", 5, NOW);
    assert.equal(awardOnce(s, "x", 5, NOW), s);
  });
});

describe("practice session", () => {
  const items = [{ key: mcq.id }, { key: "a:wb10-maths-arithmetic-02" }];
  const mk = () => S.newSession({ id: "p1", kind: "practice", title: "t", board: "wbbse", grade: 10, items, now: NOW });
  it("locks after answering; hints and reveal never score", () => {
    let s = mk();
    s = S.useHint(s, 0);
    s = S.answerPractice(s, 0, mcq, { type: "choice", index: 0 }, NOW);
    assert.equal(s.answers[0]!.correct, true);
    assert.equal(s.answers[0]!.hinted, true);
    assert.equal(S.xpForItem(s, 0), 5);
    const frozen = S.answerPractice(s, 0, mcq, { type: "choice", index: 1 }, NOW);
    assert.equal(frozen, s);
    let r = S.revealPractice(mk(), 1, NOW);
    assert.equal(r.answers[1]!.revealed, true);
    assert.equal(S.xpForItem(r, 1), 0);
    r = S.answerPractice(r, 1, mcq, { type: "choice", index: 0 }, NOW);
    assert.equal(r.answers[1]!.revealed, true, "cannot answer after reveal");
  });
  it("navigation is bounds-checked", () => {
    const s = mk();
    assert.equal(S.goTo(s, 5), s);
    assert.equal(S.goTo(s, 1).current, 1);
  });
  it("finishing a session twice counts once", () => {
    let s = defaultState();
    const sess = S.submit(mk(), NOW);
    const res = S.computeResult(sess);
    s = finishSessionState(s, sess, res, NOW);
    const again = finishSessionState(s, sess, res, NOW);
    assert.equal(again.totals.sessions, 1);
  });
});

describe("exam session", () => {
  const plan = planExam("wbbse", 10, 6, "seed-1");
  const mk = () => S.newSession({ id: "e1", kind: "exam", title: "Mock", board: "wbbse", grade: 10, items: plan.items, now: NOW, durationSec: 600 });
  it("hides correctness until submit and allows changing answers", () => {
    let s = mk();
    const q0 = resolveQuestion(s.items[0]!.key)!;
    s = S.setExamResponse(s, 0, { type: "choice", index: 3 }, NOW);
    assert.equal(s.answers[0]!.correct, false, "not evaluated during the exam");
    s = S.setExamResponse(s, 0, q0.type === "numeric" ? { type: "numeric", value: q0.numeric!.value } : q0.type === "multi-select" ? { type: "multi", indexes: q0.answer } : { type: "choice", index: q0.answer[0]! }, NOW);
    s = S.toggleMark(s, 1);
    assert.equal(s.marked[1], true);
    const done = S.submit(s, NOW + 60000);
    assert.equal(done.answers[0]!.correct, true);
    const res = S.computeResult(done);
    assert.equal(res.correct, 1);
    assert.equal(res.attempted, 1);
    assert.equal(res.skipped, plan.items.length - 1);
    assert.equal(res.timeUsedSec, 60);
    assert.ok(res.byTopic.length > 0);
  });
  it("timeout and double-submit are safe; edits after submit are ignored", () => {
    let s = mk();
    assert.equal(S.remainingSec(s, NOW + 599000), 1);
    assert.equal(S.isExpired(s, NOW + 601000), true);
    const t = S.submit(s, NOW + 900000, "timeout");
    assert.equal(t.submittedAt, NOW + 600000, "timestamp clamps to the deadline");
    assert.equal(S.submit(t, NOW + 999999), t);
    assert.equal(S.setExamResponse(t, 0, { type: "choice", index: 0 }, NOW), t);
    assert.equal(S.isExpired(t, NOW + 999999), false);
    s = S.submit(mk(), NOW);
    let st = defaultState();
    const res = S.computeResult(s);
    st = finishSessionState(st, s, res, NOW);
    st = finishSessionState(st, s, res, NOW);
    assert.equal(st.tests.length, 1);
  });
  it("exam xp is awarded once", () => {
    let s = S.submit(S.setExamResponse(mk(), 0, { type: "choice", index: 0 }, NOW), NOW);
    const res = { ...S.computeResult(s), correct: 3 };
    let st = finishSessionState(defaultState(), s, res, NOW);
    assert.equal(st.xp, 15);
    s = { ...s };
    st = finishSessionState(st, s, res, NOW);
    assert.equal(st.xp, 15);
  });
});

describe("selection", () => {
  const st = defaultState();
  it("topic plans stay inside the topic and have no repeated questions", () => {
    const p = planTopic(st, T, 12);
    const sigs = p.items.map((i) => signature(resolveQuestion(i.key)!));
    assert.equal(new Set(sigs).size, sigs.length);
    for (const i of p.items) { const q = resolveQuestion(i.key)!; assert.equal(q.topicId, "arithmetic"); assert.equal(q.subjectId, "maths"); }
    assert.equal(p.items.length, 12);
  });
  it("cursor advances so the next session brings new questions", () => {
    const p1 = planTopic(st, T, 8);
    const s2 = { ...st, topics: { [topicKey("wbbse", 10, "maths", "arithmetic")]: { attempts: 8, correct: 8, recent: "11111111", lastAt: NOW, cursor: p1.cursorAdvance[topicKey("wbbse", 10, "maths", "arithmetic")]! } }, questions: Object.fromEntries(p1.items.map((i) => [i.key, { attempts: 1, correct: 1, lastAt: NOW, correctRun: 1 }])) };
    const p2 = planTopic(s2, T, 8);
    assert.equal(p2.items.filter((i) => p1.items.some((j) => j.key === i.key)).length, 0);
  });
  it("thin topics report fewer questions honestly", () => {
    const p = planTopic(st, { board: "wbbse", grade: 10, subjectId: "life", topicId: "evolution-adaptation" }, 10);
    assert.ok(p.items.length >= 1);
  });
  it("unsupported curricula yield empty plans", () => {
    assert.equal(planDaily("2026-11-20", "cbse", 10).items.length, 0);
    assert.equal(planExam("cbse", 10, 10, "x").items.length, 0);
    assert.equal(planMixed(st, "cbse", 10, 5).items.length, 0);
    assert.equal(planAdaptive(st, "cbse", 10, 5, "2026-11-20").items.length, 0);
  });
  it("daily challenge is deterministic per date and differs across dates", () => {
    const a = planDaily("2026-11-20", "wbbse", 10), b = planDaily("2026-11-20", "wbbse", 10), c = planDaily("2026-11-21", "wbbse", 10);
    assert.deepEqual(a.items, b.items);
    assert.equal(a.items.length, 5);
    assert.notDeepEqual(a.items, c.items);
  });
  it("mixed challenge labels topics and draws from several subjects", () => {
    const p = planMixed(st, "wbbse", 10, 8);
    const subjects = new Set(p.items.map((i) => resolveQuestion(i.key)!.subjectId));
    assert.ok(subjects.size >= 3);
    assert.ok(p.items.every((i) => i.reason));
    for (const i of p.items) assert.notEqual(resolveQuestion(i.key)!.subjectId, "history");
  });
  it("quick practice spreads across selected topics", () => {
    const p = planQuick(st, [T, { ...T, subjectId: "physical-science", topicId: "light" }], 6);
    assert.equal(p.items.length, 6);
    assert.equal(new Set(p.items.map((i) => resolveQuestion(i.key)!.subjectId)).size, 2);
  });
  it("adaptive favours weak topics and explains why", () => {
    const weak = { ...st, totals: { ...st.totals, answered: 40 }, topics: {
      [topicKey("wbbse", 10, "maths", "arithmetic")]: { attempts: 12, correct: 2, recent: "000100000100", lastAt: NOW, cursor: 0 },
      ...Object.fromEntries(["algebra", "geometry", "trigonometry", "mensuration", "statistics"].map((t) => [topicKey("wbbse", 10, "maths", t), { attempts: 12, correct: 12, recent: "111111111111", lastAt: NOW, cursor: 0 }])) } };
    const p = planAdaptive(weak, "wbbse", 10, 12, "2026-11-20", "maths");
    const n = p.items.filter((i) => resolveQuestion(i.key)!.topicId === "arithmetic").length;
    assert.ok(n >= 4, `weak topic share ${n}/12`);
    assert.ok(p.items.every((i) => i.reason));
    assert.deepEqual(planAdaptive(weak, "wbbse", 10, 12, "2026-11-20", "maths"), p);
  });
  it("revision draws from due reviews, mistakes and bookmarks without duplicates", () => {
    let s = recordAnswer(defaultState(), ev({ correct: false, xp: 0 }));
    s = toggleBookmark(s, "a:wb10-maths-algebra-01");
    const p = planRevision(s, 10, addDays("2026-11-20", 3));
    assert.deepEqual(p.items.map((i) => i.key).sort(), [mcq.id, "a:wb10-maths-algebra-01"].sort());
    assert.equal(planRevision(defaultState(), 10, "2026-11-20").items.length, 0);
  });
});

describe("mastery and spaced repetition", () => {
  it("one lucky answer is never mastery", () => {
    assert.equal(masteryOf(undefined), "not-started");
    assert.equal(masteryOf({ attempts: 1, correct: 1, recent: "1" }), "learning");
    assert.equal(masteryOf({ attempts: 10, correct: 8, recent: "1111111011" }), "practising");
    assert.equal(masteryOf({ attempts: 20, correct: 19, recent: "111111111111" }), "strong");
    assert.equal(masteryOf({ attempts: 20, correct: 19, recent: "111111111111" }, 1), "practising");
  });
  it("Leitner boxes step up on success and reset on failure", () => {
    let it = newReviewItem("q:x", "question", "x", "2026-11-20");
    assert.equal(it.due, "2026-11-21");
    it = scheduleReview(it, true, "2026-11-21");
    assert.deepEqual([it.box, it.due], [2, "2026-11-23"]);
    it = scheduleReview(it, true, "2026-11-23");
    assert.deepEqual([it.box, it.due], [3, "2026-11-27"]);
    it = scheduleReview(it, false, "2026-11-27");
    assert.deepEqual([it.box, it.due, it.lapses], [1, "2026-11-28", 1]);
    for (let i = 0; i < 10; i++) it = scheduleReview(it, true, "2026-12-01");
    assert.equal(it.box, 5);
  });
});

describe("persistence", () => {
  it("round-trips state", () => {
    const kv = memoryKV();
    const s = recordAnswer(defaultState(), ev());
    assert.equal(saveState(kv, s).ok, true);
    const r = loadState(kv);
    assert.equal(r.status, "loaded");
    assert.deepEqual(r.state, s);
  });
  it("migrates qubrix-progress-v2 without losing XP, answers or best streak, and keeps the old key", () => {
    const legacy = {
      "wbbse:10:maths:all": { index: 12, answered: 12, correct: 9, streak: 2, best: 6, picked: null, xp: 120 },
      "wbbse:10:maths:Simple interest": { index: 5, answered: 5, correct: 4, streak: 1, best: 3, picked: 1, xp: 40 },
      "general:10:gk:all": { index: 3, answered: 3, correct: 3, streak: 3, best: 3, picked: null, xp: 30 },
    };
    const kv = memoryKV({ "qubrix-progress-v2": JSON.stringify(legacy) });
    const r = loadState(kv);
    assert.equal(r.status, "migrated");
    assert.equal(r.state.xp, 190);
    assert.equal(r.state.totals.answered, 20);
    assert.equal(r.state.totals.correct, 16);
    assert.equal(r.state.bestAnswerStreak, 6);
    assert.equal(r.state.topics[topicKey("wbbse", 10, "maths", "arithmetic")]?.attempts, 5);
    assert.equal(Object.keys(r.state.legacy.byKey).length, 3);
    assert.ok(kv.data.has("qubrix-progress-v2"), "old data is kept as a backup");
    assert.ok(kv.data.has("qubrix-state-v3"));
    assert.equal(tagToTopic("wbbse", 10, "Atmosphere"), null);
  });
  it("recovers from corrupted storage and keeps a copy", () => {
    const kv = memoryKV({ "qubrix-state-v3": "{not json" });
    const r = loadState(kv);
    assert.equal(r.status, "recovered");
    assert.equal(kv.data.get("qubrix-state-v3.corrupt"), "{not json");
    const kv2 = memoryKV({ "qubrix-state-v3": JSON.stringify({ version: 3, xp: "lots", topics: 5 }) });
    const r2 = loadState(kv2);
    assert.ok(["loaded", "recovered"].includes(r2.status));
    assert.equal(r2.state.xp, 0);
  });
  it("works without storage", () => {
    assert.equal(loadState(null).state.xp, 0);
    assert.equal(saveState(null, defaultState()).ok, false);
    const full = { getItem: () => null, setItem: () => { throw new Error("quota"); }, removeItem: () => {} };
    assert.equal(saveState(full, defaultState()).ok, false);
  });
  it("sanitises hostile input", () => {
    const evil = JSON.parse('{"version":3,"xp":-5,"topics":{"__proto__":{"attempts":9},"ok":{"attempts":"x","recent":"10abc1"}},"active":{"items":[{"key":"nope"}]},"profile":{"grade":99,"board":3}}');
    const s = sanitizeState(evil)!;
    assert.equal(s.xp, 0);
    assert.equal(s.topics["ok"]!.recent, "101");
    assert.equal(({} as Record<string, unknown>)["attempts"], undefined);
    assert.equal(s.active, null);
    assert.equal(s.profile.grade, 12);
    assert.equal(sanitizeState({ version: 2 }), null);
  });
  it("export/import validates schema and never executes content", () => {
    const s = recordAnswer(defaultState(), ev());
    const ok = importState(exportState(s));
    assert.equal(ok.ok, true);
    if (ok.ok) assert.deepEqual(ok.state, s);
    assert.equal(importState("nope").ok, false);
    assert.equal(importState('{"format":"other"}').ok, false);
    assert.equal(importState(JSON.stringify({ format: "qubrix-export", version: 99, state: {} })).ok, false);
    assert.equal(importState(JSON.stringify({ format: "qubrix-export", version: 3, state: { version: 2 } })).ok, false);
    assert.equal(importState("x".repeat(5_000_001)).ok, false);
  });
  it("migrateLegacyV2 rejects non-objects", () => {
    assert.equal(migrateLegacyV2(null, tagToTopic), null);
    assert.equal(migrateLegacyV2({}, tagToTopic), null);
  });
});

describe("achievements", () => {
  it("unlock from real evidence only", () => {
    assert.deepEqual(Object.keys(unlockNew(defaultState(), NOW).achievements), []);
    const s = unlockNew(recordAnswer(defaultState(), ev()), NOW);
    assert.ok(s.achievements["first-answer"]);
    assert.equal(s.achievements["answers-100"], undefined);
  });
});
