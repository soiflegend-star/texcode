/** UI strings. Only languages with real translations are offered in the selector. */
export const LANGUAGES = [
  { id: "en", label: "English", available: true },
  { id: "bn", label: "বাংলা (Bengali)", available: false },
] as const;
export const STRINGS = {
  en: {
    "nav.home": "Home", "nav.learn": "Learn", "nav.practice": "Practice", "nav.tests": "Tests", "nav.revise": "Revise", "nav.me": "Profile",
    "common.back": "Back", "common.next": "Next", "common.start": "Start", "common.cancel": "Cancel", "common.confirm": "Confirm",
  },
} as const;
export type StringKey = keyof (typeof STRINGS)["en"];
export function t(key: StringKey, lang: "en" = "en"): string { return STRINGS[lang][key]; }
