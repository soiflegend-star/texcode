import { curriculumFor } from "../quiz/curriculum.ts";
import { defaultState, LEGACY_KEY, migrateLegacyV2, sanitizeState, STATE_VERSION, STORAGE_KEY, type AppState } from "./state.ts";

export type KV = { getItem(k: string): string | null; setItem(k: string, v: string): void; removeItem(k: string): void };

export function memoryKV(seed: Record<string, string> = {}): KV & { data: Map<string, string> } {
  const data = new Map(Object.entries(seed));
  return { data, getItem: (k) => data.get(k) ?? null, setItem: (k, v) => void data.set(k, v), removeItem: (k) => void data.delete(k) };
}
/** localStorage wrapped so that blocked storage (private mode, quota) never throws. */
export function browserKV(): KV | null {
  try {
    const ls = globalThis.localStorage;
    ls.setItem("qubrix-probe", "1");
    ls.removeItem("qubrix-probe");
    return ls;
  } catch { return null; }
}

export function tagToTopic(board: string, grade: number, tag: string): { subjectId: string; topicId: string } | null {
  for (const s of curriculumFor(board, grade)) for (const t of s.topics) if (t.generatorTags.includes(tag)) return { subjectId: s.id, topicId: t.id };
  return null;
}

export type LoadStatus = "fresh" | "loaded" | "migrated" | "recovered";
export type LoadResult = { state: AppState; status: LoadStatus; message?: string };

export function loadState(kv: KV | null): LoadResult {
  if (!kv) return { state: defaultState(), status: "fresh", message: "Storage is unavailable in this browser; progress will not be saved." };
  let recovered = false;
  try {
    const raw = kv.getItem(STORAGE_KEY);
    if (raw) {
      const s = sanitizeState(JSON.parse(raw));
      if (s) return { state: s, status: "loaded" };
      recovered = true;
    }
  } catch { recovered = true; }
  if (recovered) {
    try { const raw = kv.getItem(STORAGE_KEY); if (raw) kv.setItem(`${STORAGE_KEY}.corrupt`, raw); } catch { /* best effort */ }
  }
  try {
    const legacy = kv.getItem(LEGACY_KEY);
    if (legacy) {
      const m = migrateLegacyV2(JSON.parse(legacy), tagToTopic);
      if (m) { const state = { ...m, profile: { ...m.profile, onboarded: false } }; saveState(kv, state); return { state, status: "migrated", message: "Your earlier progress was carried over." }; }
    }
  } catch { /* fall through */ }
  return recovered
    ? { state: defaultState(), status: "recovered", message: "Saved data could not be read, so QUBRIX started fresh. A copy of the unreadable data was kept." }
    : { state: defaultState(), status: "fresh" };
}

export function saveState(kv: KV | null, s: AppState): { ok: boolean; error?: string } {
  if (!kv) return { ok: false, error: "storage unavailable" };
  try { kv.setItem(STORAGE_KEY, JSON.stringify(s)); return { ok: true }; }
  catch (e) { return { ok: false, error: e instanceof Error ? e.message : "write failed" }; }
}

export const EXPORT_FORMAT = "qubrix-export";
export function exportState(s: AppState, now = Date.now()): string {
  return JSON.stringify({ format: EXPORT_FORMAT, version: STATE_VERSION, exportedAt: new Date(now).toISOString(), state: s }, null, 2);
}
export type ImportResult = { ok: true; state: AppState } | { ok: false; error: string };
export function importState(text: string): ImportResult {
  if (text.length > 5_000_000) return { ok: false, error: "That file is too large to be a QUBRIX export." };
  let data: unknown;
  try { data = JSON.parse(text); } catch { return { ok: false, error: "That file is not valid JSON." }; }
  if (typeof data !== "object" || data === null || (data as Record<string, unknown>).format !== EXPORT_FORMAT) return { ok: false, error: "This is not a QUBRIX export file." };
  const d = data as Record<string, unknown>;
  if (d.version !== STATE_VERSION) return { ok: false, error: `Unsupported export version (${String(d.version)}). Expected ${STATE_VERSION}.` };
  const state = sanitizeState(d.state);
  if (!state) return { ok: false, error: "The export file's data is not in the expected shape." };
  return { ok: true, state };
}
export function resetAll(kv: KV | null): void {
  if (!kv) return;
  try { kv.removeItem(STORAGE_KEY); } catch { /* ignore */ }
}
