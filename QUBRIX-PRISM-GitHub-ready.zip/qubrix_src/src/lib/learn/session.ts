import { resolveQuestion } from "./resolve.ts";
import { answerXp, isCorrect } from "./scoring.ts";
import type { QuestionRecord, Response, Session, SessionItem, SessionKind, SessionResult } from "./types.ts";

export function newSession(p: { id: string; kind: SessionKind; title: string; board: string; grade: number; items: SessionItem[]; now: number; durationSec?: number; notes?: string[]; dateKey?: string }): Session {
  const n = p.items.length;
  return {
    id: p.id, kind: p.kind, title: p.title, board: p.board, grade: p.grade, items: p.items,
    answers: Array(n).fill(null), hints: Array(n).fill(false), marked: Array(n).fill(false),
    current: 0, startedAt: p.now, durationSec: p.durationSec, status: "active", notes: p.notes ?? [], dateKey: p.dateKey,
  };
}
const inRange = (s: Session, i: number) => Number.isInteger(i) && i >= 0 && i < s.items.length;
const set = <T,>(arr: T[], i: number, v: T): T[] => arr.map((x, j) => (j === i ? v : x));
export const isExam = (s: Session): boolean => s.kind === "exam";

export function goTo(s: Session, i: number): Session { return inRange(s, i) ? { ...s, current: i } : s; }
export function toggleMark(s: Session, i: number): Session { return inRange(s, i) && s.status === "active" ? { ...s, marked: set(s.marked, i, !s.marked[i]) } : s; }
export function useHint(s: Session, i: number): Session {
  if (!inRange(s, i) || s.status !== "active" || s.answers[i]) return s;
  return s.hints[i] ? s : { ...s, hints: set(s.hints, i, true) };
}

/** Practice-style answer: locks immediately, cannot be changed or repeated. */
export function answerPractice(s: Session, i: number, q: QuestionRecord, r: Response, now: number): Session {
  if (!inRange(s, i) || s.status !== "active" || s.answers[i] || isExam(s)) return s;
  return { ...s, answers: set(s.answers, i, { response: r, correct: isCorrect(q, r), hinted: s.hints[i] ?? false, revealed: false, at: now }) };
}
export function revealPractice(s: Session, i: number, now: number): Session {
  if (!inRange(s, i) || s.status !== "active" || s.answers[i] || isExam(s)) return s;
  return { ...s, answers: set(s.answers, i, { response: null, correct: false, hinted: s.hints[i] ?? false, revealed: true, at: now }) };
}
/** Exam answer: editable until submit; null clears it. Correctness is computed at submit. */
export function setExamResponse(s: Session, i: number, r: Response | null, now: number): Session {
  if (!inRange(s, i) || s.status !== "active" || !isExam(s)) return s;
  return { ...s, answers: set(s.answers, i, r ? { response: r, correct: false, hinted: false, revealed: false, at: now } : null) };
}

export function remainingSec(s: Session, now: number): number | null {
  if (s.durationSec == null) return null;
  return Math.max(0, Math.ceil(s.durationSec - (now - s.startedAt) / 1000));
}
export const isExpired = (s: Session, now: number): boolean => s.status === "active" && remainingSec(s, now) === 0;

/** Idempotent: submitting twice (or after timeout) returns the same session. */
export function submit(s: Session, now: number, reason: "manual" | "timeout" = "manual"): Session {
  if (s.status === "submitted") return s;
  const at = reason === "timeout" && s.durationSec != null ? Math.min(now, s.startedAt + s.durationSec * 1000) : now;
  const answers = s.answers.map((a, i) => {
    if (!a || !a.response) return a;
    const q = resolveQuestion(s.items[i]!.key);
    return q ? { ...a, correct: isCorrect(q, a.response) } : a;
  });
  return { ...s, answers, status: "submitted", submittedAt: at, submitReason: reason };
}

/** Per-answer facts the store turns into recordAnswer events (practice-style sessions). */
export function streakAfter(s: Session, i: number): number {
  let n = 0;
  for (let j = i; j >= 0; j--) { const a = s.answers[j]; if (a && a.correct && !a.revealed) n++; else break; }
  return n;
}
export function xpForItem(s: Session, i: number): number {
  const a = s.answers[i];
  return a ? answerXp(a.correct, a.hinted, a.revealed, streakAfter(s, i)) : 0;
}

export function computeResult(s: Session): SessionResult {
  const total = s.items.length;
  let attempted = 0, correct = 0;
  const topics = new Map<string, { subjectId: string; topicId: string; total: number; correct: number }>();
  s.items.forEach((it, i) => {
    const q = resolveQuestion(it.key);
    const a = s.answers[i];
    const tid = q ? `${q.subjectId}|${q.topicId}` : "unknown|unknown";
    const row = topics.get(tid) ?? { subjectId: q?.subjectId ?? "unknown", topicId: q?.topicId ?? "unknown", total: 0, correct: 0 };
    row.total++;
    if (a?.response) attempted++;
    if (a?.correct) { correct++; row.correct++; }
    topics.set(tid, row);
  });
  const end = s.submittedAt ?? s.startedAt;
  return {
    total, attempted, correct, skipped: total - attempted,
    accuracy: attempted ? Math.round((correct / attempted) * 100) : 0,
    scorePct: total ? Math.round((correct / total) * 100) : 0,
    timeUsedSec: Math.max(0, Math.round((end - s.startedAt) / 1000)),
    byTopic: [...topics.values()],
  };
}
export const answeredCount = (s: Session): number => s.answers.filter((a) => a && (a.response || a.revealed)).length;
