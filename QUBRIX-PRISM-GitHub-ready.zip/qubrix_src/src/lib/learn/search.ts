import { authoredFor } from "./content/authored-wbbse10.ts";
import { referenceFor } from "./content/reference-wbbse10.ts";
import { subjectsOf } from "./registry.ts";

export type SearchHit =
  | { kind: "subject"; subjectId: string; title: string }
  | { kind: "topic"; subjectId: string; topicId: string; title: string; detail: string }
  | { kind: "question"; key: string; subjectId: string; topicId: string; title: string }
  | { kind: "reference"; subjectId: string; topicId: string; title: string; detail: string };

/** Searches only the learner's selected curriculum. Case-insensitive substring match on every word. */
export function search(board: string, grade: number, query: string, limit = 30): SearchHit[] {
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  if (!words.length) return [];
  const match = (s: string) => { const l = s.toLowerCase(); return words.every((w) => l.includes(w)); };
  const hits: SearchHit[] = [];
  for (const s of subjectsOf(board, grade)) {
    if (match(s.title)) hits.push({ kind: "subject", subjectId: s.id, title: s.title });
    for (const t of s.topics) {
      if (match(`${t.title} ${t.syllabusLabel}`)) hits.push({ kind: "topic", subjectId: s.id, topicId: t.id, title: t.title, detail: s.title });
      for (const e of referenceFor(s.id, t.id)) if (match(`${e.term} ${e.body}`)) hits.push({ kind: "reference", subjectId: s.id, topicId: t.id, title: e.term, detail: e.body });
      for (const q of authoredFor(board, grade, s.id, t.id)) if (match(q.prompt)) hits.push({ kind: "question", key: q.id, subjectId: s.id, topicId: t.id, title: q.prompt });
    }
  }
  return hits.slice(0, limit);
}
