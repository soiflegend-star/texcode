/** Mastery states and a transparent Leitner scheduler. */
export type Mastery = "not-started" | "learning" | "practising" | "strong";
export const MASTERY_LABEL: Record<Mastery, string> = {
  "not-started": "Not started", learning: "Learning", practising: "Practising", strong: "Strong",
};

export type TopicStatLike = { attempts: number; correct: number; recent: string };

export function recentAccuracy(s: TopicStatLike | undefined): number | null {
  if (!s || !s.recent) return null;
  const ones = [...s.recent].filter((c) => c === "1").length;
  return ones / s.recent.length;
}

/**
 * Evidence-based: "strong" needs 15+ attempts, >=85% over the last 10-12 answers and no
 * overdue mistakes in the topic. One lucky answer can never lift a topic above "learning".
 */
export function masteryOf(s: TopicStatLike | undefined, overdueMistakes = 0): Mastery {
  if (!s || s.attempts === 0) return "not-started";
  const acc = recentAccuracy(s) ?? s.correct / s.attempts;
  if (s.attempts >= 15 && acc >= 0.85 && overdueMistakes === 0) return "strong";
  if (s.attempts >= 8 && acc >= 0.6) return "practising";
  return "learning";
}

export const BOX_DAYS = [1, 2, 4, 8, 16] as const;
export type ReviewItem = {
  id: string;
  kind: "question" | "card";
  ref: string;
  box: number;
  due: string;
  reps: number;
  lapses: number;
};

export function addDays(dateKey: string, n: number): string {
  const [y, m, d] = dateKey.split("-").map(Number) as [number, number, number];
  const t = new Date(Date.UTC(y, m - 1, d + n));
  return t.toISOString().slice(0, 10);
}
export function dateKeyOf(ms: number): string {
  const d = new Date(ms);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export function newReviewItem(id: string, kind: ReviewItem["kind"], ref: string, today: string): ReviewItem {
  return { id, kind, ref, box: 1, due: addDays(today, kind === "question" ? 1 : 0), reps: 0, lapses: 0 };
}
/** Correct: move up one box (max 5). Wrong: back to box 1, due tomorrow. */
export function scheduleReview(item: ReviewItem, correct: boolean, today: string): ReviewItem {
  if (correct) {
    const box = Math.min(BOX_DAYS.length, item.box + 1);
    return { ...item, box, reps: item.reps + 1, due: addDays(today, BOX_DAYS[box - 1]!) };
  }
  return { ...item, box: 1, reps: item.reps + 1, lapses: item.lapses + 1, due: addDays(today, 1) };
}
export const isDue = (item: ReviewItem, today: string): boolean => item.due <= today;
