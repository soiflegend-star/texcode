import { getTopicQuestion } from "../quiz/bank.ts";
import type { Question } from "../quiz/core.ts";
import { curriculumFor } from "../quiz/curriculum.ts";
import { AUTHORED_WBBSE10 } from "./content/authored-wbbse10.ts";
import type { QuestionRecord } from "./types.ts";

/**
 * Question keys are stable and reproducible:
 *   a:<authored id>                              an individually written question
 *   g|board|grade|subject|topic|n                n-th question of a curriculum topic stream
 * A generated key always re-resolves to the same question (deterministic generators).
 */
export const authoredKey = (id: string): string => (id.startsWith("a:") ? id : `a:${id}`);
export const genKey = (board: string, grade: number, subjectId: string, topicId: string, n: number): string =>
  `g|${board}|${grade}|${subjectId}|${topicId}|${n}`;

export type ParsedKey =
  | { kind: "authored"; id: string }
  | { kind: "gen"; board: string; grade: number; subjectId: string; topicId: string; n: number };

export function parseKey(key: string): ParsedKey | null {
  if (key.startsWith("a:")) return { kind: "authored", id: key };
  const p = key.split("|");
  if (p[0] !== "g" || p.length !== 6) return null;
  const grade = Number(p[2]);
  const n = Number(p[5]);
  if (!Number.isInteger(grade) || !Number.isInteger(n) || n < 0) return null;
  return { kind: "gen", board: p[1]!, grade, subjectId: p[3]!, topicId: p[4]!, n };
}

const authoredIndex = new Map(AUTHORED_WBBSE10.map((r) => [r.id, r] as const));

/** Tags for a topic; GK topics are the generator tags themselves. */
export function tagsFor(board: string, grade: number, subjectId: string, topicId: string): string[] {
  if (subjectId === "gk") return [topicId];
  return curriculumFor(board, grade).find((s) => s.id === subjectId)?.topics.find((t) => t.id === topicId)?.generatorTags ?? [];
}

function fromGenerated(q: Question, key: string, board: string, grade: number, subjectId: string, topicId: string): QuestionRecord {
  return {
    id: key,
    type: "mcq",
    board, grade, subjectId, topicId,
    prompt: q.prompt,
    options: [...q.options],
    answer: [q.answer],
    explanation: q.explanation,
    language: "en",
    sources: [{ kind: "generator", label: `QUBRIX deterministic generator · ${q.topic}` }],
    origin: "generated-variant",
    review: "machine-validated",
    version: 1,
    generatorTag: q.topic,
    examLabel: "practice",
  };
}

/** Never falls back: an unknown topic or an exhausted stream returns null. */
export function streamQuestion(board: string, grade: number, subjectId: string, topicId: string, n: number): QuestionRecord | null {
  const tags = tagsFor(board, grade, subjectId, topicId);
  if (tags.length === 0 || n < 0) return null;
  const tag = tags[n % tags.length]!;
  const idx = Math.floor(n / tags.length);
  const source = subjectId === "gk" ? "gk" : subjectId;
  const q = getTopicQuestion(board, source, tag, idx, grade);
  if (!q || q.topic !== tag) return null;
  return fromGenerated(q, genKey(board, grade, subjectId, topicId, n), board, grade, subjectId, topicId);
}

export function resolveQuestion(key: string): QuestionRecord | null {
  const p = parseKey(key);
  if (!p) return null;
  if (p.kind === "authored") return authoredIndex.get(p.id) ?? null;
  return streamQuestion(p.board, p.grade, p.subjectId, p.topicId, p.n);
}

export function signature(r: QuestionRecord): string {
  return `${r.prompt.trim().toLowerCase()}@@${[...r.options].map((o) => o.toLowerCase()).sort().join("|")}`;
}
