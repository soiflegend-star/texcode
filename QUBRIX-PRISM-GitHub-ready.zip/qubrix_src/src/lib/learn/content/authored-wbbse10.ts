import type { Difficulty, QuestionRecord, QuestionType, Skill } from "../types.ts";

/**
 * Individually written practice questions for WBBSE Class X (2026-27).
 * Wording and explanations are original. Facts are standard textbook-level results.
 * Review state is "machine-validated" only (structure checked by tests); a subject
 * teacher still needs to check every item against the prescribed textbook before any
 * "source-checked" or "human-reviewed" label may be applied.
 */
const SYLLABUS_SOURCE = (chapter: string) => ({
  kind: "syllabus" as const,
  label: "WBBSE Class X 2026-27 syllabus topic list (third-party summary, provisional)",
  chapter,
});

type Spec = {
  n: number;
  subject: string;
  topic: string;
  chapter: string;
  prompt: string;
  options: string[];
  answer: number[];
  explanation: string;
  type?: QuestionType;
  hint?: string;
  difficulty?: Difficulty;
  skill?: Skill;
  objective: string;
  wrong?: (string | null)[];
  numeric?: { value: number; tolerance: number; unit?: string };
};

function q(s: Spec): QuestionRecord {
  return {
    id: `a:wb10-${s.subject}-${s.topic}-${String(s.n).padStart(2, "0")}`,
    type: s.type ?? "mcq",
    board: "wbbse",
    grade: 10,
    subjectId: s.subject,
    topicId: s.topic,
    prompt: s.prompt,
    options: s.options,
    answer: s.answer,
    numeric: s.numeric,
    explanation: s.explanation,
    distractorNotes: s.wrong,
    hint: s.hint,
    difficulty: s.difficulty ?? "medium",
    skill: s.skill ?? "apply",
    objective: s.objective,
    language: "en",
    sources: [SYLLABUS_SOURCE(s.chapter)],
    origin: "authored",
    review: "machine-validated",
    version: 1,
    examLabel: "exam-style practice",
  };
}

const M = "maths";
const PS = "physical-science";
const LS = "life";

export const AUTHORED_WBBSE10: QuestionRecord[] = [
  // ---- Mathematics
  q({ n: 1, subject: M, topic: "arithmetic", chapter: "Simple interest", prompt: "What is the simple interest on ₹5,000 at 6% per annum for 3 years?", options: ["₹900", "₹300", "₹1,000", "₹1,800"], answer: [0], hint: "SI = P × r × t / 100.", difficulty: "easy", objective: "Compute simple interest from principal, rate and time.", explanation: "SI = 5000 × 6 × 3 / 100 = ₹900.", wrong: [null, "₹300 is one year's interest at 6% on ₹5,000 — time was ignored.", "₹1,000 would need a 6.67% rate.", "₹1,800 doubles the time."] }),
  q({ n: 2, subject: M, topic: "arithmetic", chapter: "Profit and loss", prompt: "An article bought for ₹800 is sold for ₹920. What is the profit percent?", options: ["12%", "15%", "13.04%", "20%"], answer: [1], hint: "Profit % is measured on the cost price.", objective: "Compute profit percent on cost price.", explanation: "Profit = 920 − 800 = ₹120. Profit % = 120 / 800 × 100 = 15%.", wrong: ["12% does not match 120/800.", null, "13.04% results from dividing by the selling price (120/920).", "20% is not 120/800."] }),
  q({ n: 3, subject: M, topic: "arithmetic", chapter: "Compound interest", prompt: "What is the compound interest on ₹10,000 for 2 years at 10% per annum, compounded annually?", options: ["₹2,000", "₹2,100", "₹2,200", "₹1,000"], answer: [1], hint: "Amount = P(1 + r/100)ⁿ; interest = amount − principal.", difficulty: "medium", objective: "Compute compound interest over two years.", explanation: "Amount = 10000 × 1.1 × 1.1 = ₹12,100. Compound interest = 12,100 − 10,000 = ₹2,100.", wrong: ["₹2,000 is the simple interest for 2 years.", null, "₹2,200 over-counts the second year's interest.", "₹1,000 is only one year's interest."] }),
  q({ n: 4, subject: M, topic: "arithmetic", chapter: "Simple interest", type: "numeric", prompt: "Find the simple interest (in ₹) on ₹2,000 at 5% per annum for 4 years.", options: [], answer: [], numeric: { value: 400, tolerance: 0, unit: "₹" }, hint: "SI = P × r × t / 100.", difficulty: "easy", objective: "Compute simple interest as a numeric answer.", explanation: "SI = 2000 × 5 × 4 / 100 = ₹400." }),
  q({ n: 1, subject: M, topic: "algebra", chapter: "Quadratic equation in one variable", prompt: "What are the roots of x² − 5x + 6 = 0?", options: ["1 and 6", "2 and 3", "−2 and −3", "−1 and 6"], answer: [1], hint: "Find two numbers with sum 5 and product 6.", difficulty: "easy", objective: "Solve a quadratic equation by factorisation.", explanation: "x² − 5x + 6 = (x − 2)(x − 3), so x = 2 or x = 3.", wrong: ["1 and 6 multiply to 6 but add to 7.", null, "−2 and −3 add to −5; the signs are reversed.", "−1 and 6 give product −6."] }),
  q({ n: 2, subject: M, topic: "algebra", chapter: "Quadratic equation in one variable", prompt: "What is the nature of the roots of x² + 4x + 4 = 0?", options: ["Two distinct real roots", "Equal real roots", "No real roots", "Two distinct irrational roots"], answer: [1], hint: "Compute the discriminant b² − 4ac.", objective: "Use the discriminant to decide the nature of roots.", explanation: "Discriminant = 4² − 4·1·4 = 0, so the roots are real and equal (x = −2 twice).", wrong: ["A positive discriminant would be needed.", null, "A negative discriminant would be needed.", "A non-square positive discriminant would be needed."] }),
  q({ n: 3, subject: M, topic: "algebra", chapter: "Variation", prompt: "If y varies directly as x, and y = 12 when x = 3, what is y when x = 5?", options: ["15", "20", "36", "7.2"], answer: [1], hint: "Direct variation means y = kx for a constant k.", objective: "Solve a direct variation problem.", explanation: "k = 12/3 = 4, so y = 4 × 5 = 20.", wrong: ["15 assumes y = 3x.", null, "36 multiplies 12 by 3.", "7.2 treats it as inverse variation (12×3/5)."] }),
  q({ n: 4, subject: M, topic: "algebra", chapter: "Quadratic equation in one variable", type: "multi-select", prompt: "Select ALL the roots of x² − 5x + 6 = 0.", options: ["1", "2", "3", "6"], answer: [1, 2], hint: "Substitute each value or factorise.", difficulty: "easy", objective: "Identify every root of a quadratic equation.", explanation: "x² − 5x + 6 = (x − 2)(x − 3). Both 2 and 3 satisfy it; 1 gives 2 and 6 gives 12." }),
  q({ n: 1, subject: M, topic: "geometry", chapter: "Application of theorems", prompt: "What is the angle subtended by a diameter at any point on the circle (the angle in a semicircle)?", options: ["60°", "90°", "180°", "45°"], answer: [1], difficulty: "easy", skill: "recall", objective: "Recall the angle-in-a-semicircle theorem.", explanation: "The angle in a semicircle is a right angle, 90°." }),
  q({ n: 2, subject: M, topic: "geometry", chapter: "Application of theorems", prompt: "A tangent touches a circle at point P and O is the centre. What is the angle between the tangent and the radius OP?", options: ["45°", "60°", "90°", "180°"], answer: [2], difficulty: "easy", skill: "recall", objective: "Recall the tangent–radius theorem.", explanation: "A tangent is perpendicular to the radius drawn to the point of contact, so the angle is 90°." }),
  q({ n: 1, subject: M, topic: "trigonometry", chapter: "Trigonometric ratios and identities", prompt: "Which identity is true for every angle θ?", options: ["sin θ + cos θ = 1", "sin²θ + cos²θ = 1", "sin²θ − cos²θ = 1", "tan θ + cot θ = 1"], answer: [1], difficulty: "easy", skill: "recall", objective: "Recall the fundamental trigonometric identity.", explanation: "sin²θ + cos²θ = 1 follows from the Pythagorean theorem on a right triangle with hypotenuse 1." }),
  q({ n: 2, subject: M, topic: "trigonometry", chapter: "Trigonometric ratios and identities", prompt: "What is the value of sin 30° + cos 60°?", options: ["1/2", "1", "√3/2", "√3"], answer: [1], hint: "Use the standard values for 30° and 60°.", objective: "Use standard trigonometric ratio values.", explanation: "sin 30° = 1/2 and cos 60° = 1/2, so the sum is 1.", wrong: ["1/2 is just one of the two terms.", null, "√3/2 is sin 60°, not required here.", "√3 is not a sum of these values."] }),
  q({ n: 3, subject: M, topic: "trigonometry", chapter: "Heights and distances", prompt: "The angle of elevation of the top of a tower from a point 20 m from its foot is 45°. What is the height of the tower?", options: ["10 m", "20 m", "20√3 m", "40 m"], answer: [1], hint: "tan 45° = height / distance.", objective: "Solve a simple heights-and-distances problem.", explanation: "tan 45° = h / 20 and tan 45° = 1, so h = 20 m.", wrong: ["10 m would need tan θ = 1/2.", null, "20√3 m would need θ = 60°.", "40 m would need tan θ = 2."] }),
  q({ n: 1, subject: M, topic: "mensuration", chapter: "Cuboid", prompt: "What is the volume of a cuboid of length 5 cm, breadth 4 cm and height 3 cm?", options: ["12 cm³", "47 cm³", "60 cm³", "94 cm³"], answer: [2], difficulty: "easy", objective: "Compute the volume of a cuboid.", explanation: "Volume = l × b × h = 5 × 4 × 3 = 60 cm³.", wrong: ["12 cm³ multiplies only 4 × 3.", "47 cm³ adds instead of multiplying.", null, "94 cm² is the total surface area (a different quantity, in cm²)."] }),
  q({ n: 2, subject: M, topic: "mensuration", chapter: "Right circular cylinder", prompt: "Using π = 22/7, what is the curved surface area of a cylinder with radius 7 cm and height 10 cm?", options: ["220 cm²", "440 cm²", "1,540 cm²", "154 cm²"], answer: [1], hint: "Curved surface area = 2πrh.", objective: "Compute the curved surface area of a cylinder.", explanation: "CSA = 2 × 22/7 × 7 × 10 = 440 cm².", wrong: ["220 cm² uses πrh and misses the factor 2.", null, "1,540 cm³ is the volume πr²h, not the area.", "154 cm² is the area of the circular base."] }),
  q({ n: 3, subject: M, topic: "mensuration", chapter: "Sphere", prompt: "What is the volume of a sphere of radius 3 cm?", options: ["12π cm³", "27π cm³", "36π cm³", "108π cm³"], answer: [2], hint: "V = (4/3)πr³.", objective: "Compute the volume of a sphere.", explanation: "V = (4/3) × π × 27 = 36π cm³.", wrong: ["12π cm³ is not (4/3)π × 27.", "27π cm³ drops the factor 4/3.", null, "108π cm³ multiplies by 4 instead of 4/3."] }),
  q({ n: 1, subject: M, topic: "statistics", chapter: "Mean", prompt: "What is the mean of 2, 4, 6, 8 and 10?", options: ["5", "6", "7", "30"], answer: [1], difficulty: "easy", objective: "Compute an arithmetic mean.", explanation: "Mean = (2 + 4 + 6 + 8 + 10) / 5 = 30 / 5 = 6.", wrong: ["5 is not the average of these values.", null, "7 is not the average of these values.", "30 is the sum, not the mean."] }),
  q({ n: 2, subject: M, topic: "statistics", chapter: "Median", prompt: "What is the median of 3, 5, 7, 9, 11 and 13?", options: ["7", "8", "9", "8.67"], answer: [1], hint: "With an even number of values, average the two middle ones.", objective: "Compute the median of an even-sized data set.", explanation: "The middle values are 7 and 9, so the median is (7 + 9) / 2 = 8.", wrong: ["7 is only the lower middle value.", null, "9 is only the upper middle value.", "8.67 is the mean of the whole data set, not the median."] }),
  // ---- Physical science
  q({ n: 1, subject: PS, topic: "chemical-calculations", chapter: "Chemical Calculations", prompt: "What is the molar mass of water (H₂O)? (H = 1, O = 16)", options: ["17 g/mol", "18 g/mol", "16 g/mol", "34 g/mol"], answer: [1], difficulty: "easy", objective: "Compute molar mass from atomic masses.", explanation: "2 × 1 + 16 = 18 g/mol.", wrong: ["17 g/mol counts only one hydrogen atom.", null, "16 g/mol is the mass of oxygen alone.", "34 g/mol is the molar mass of hydrogen peroxide."] }),
  q({ n: 2, subject: PS, topic: "chemical-calculations", chapter: "Chemical Calculations", prompt: "How many moles are present in 44 g of carbon dioxide? (C = 12, O = 16)", options: ["0.5 mol", "1 mol", "2 mol", "44 mol"], answer: [1], hint: "Moles = mass / molar mass.", objective: "Convert mass to moles.", explanation: "Molar mass of CO₂ = 12 + 32 = 44 g/mol, so 44 g is 1 mol.", wrong: [null, null, "2 mol would need 88 g.", "44 mol confuses mass with moles."] }),
  q({ n: 1, subject: PS, topic: "thermal-phenomena", chapter: "Thermal Phenomena", prompt: "What is the SI unit of specific heat capacity?", options: ["J kg⁻¹ K⁻¹", "J K⁻¹", "J kg", "W m⁻¹ K⁻¹"], answer: [0], difficulty: "easy", skill: "recall", objective: "Recall the unit of specific heat capacity.", explanation: "c = Q / (m ΔT), so its unit is J / (kg · K) = J kg⁻¹ K⁻¹.", wrong: [null, "J K⁻¹ is the unit of heat capacity (not per kilogram).", "J kg is not a unit of any heat quantity here.", "W m⁻¹ K⁻¹ is the unit of thermal conductivity."] }),
  q({ n: 2, subject: PS, topic: "thermal-phenomena", chapter: "Thermal Phenomena", prompt: "How much heat is needed to raise the temperature of 2 kg of water by 5 °C? (specific heat of water = 4200 J kg⁻¹ K⁻¹)", options: ["2,100 J", "42,000 J", "8,400 J", "21,000 J"], answer: [1], hint: "Q = m c ΔT.", objective: "Use Q = mcΔT.", explanation: "Q = 2 × 4200 × 5 = 42,000 J.", wrong: ["2,100 J halves the answer.", null, "8,400 J omits the temperature change.", "21,000 J omits the mass."] }),
  q({ n: 1, subject: PS, topic: "light", chapter: "Light", prompt: "A concave mirror has a radius of curvature of 40 cm. What is its focal length?", options: ["10 cm", "20 cm", "40 cm", "80 cm"], answer: [1], hint: "f = R / 2.", objective: "Relate focal length and radius of curvature.", explanation: "f = R / 2 = 20 cm.", wrong: ["10 cm halves twice.", null, "40 cm is the radius itself.", "80 cm doubles instead of halves."] }),
  q({ n: 2, subject: PS, topic: "light", chapter: "Light", prompt: "Light travels at 3 × 10⁸ m/s in vacuum and 2 × 10⁸ m/s in a glass. What is the refractive index of the glass?", options: ["0.67", "1.5", "2", "6"], answer: [1], hint: "n = c / v.", objective: "Compute refractive index from speeds.", explanation: "n = c / v = (3 × 10⁸) / (2 × 10⁸) = 1.5.", wrong: ["0.67 inverts the ratio.", null, "2 uses the wrong numbers.", "6 multiplies the speeds."] }),
  q({ n: 1, subject: PS, topic: "current-electricity", chapter: "Current Electricity", prompt: "A 12 V battery is connected across a 4 Ω resistor. What current flows?", options: ["0.33 A", "3 A", "8 A", "48 A"], answer: [1], hint: "I = V / R.", difficulty: "easy", objective: "Apply Ohm's law.", explanation: "I = V / R = 12 / 4 = 3 A.", wrong: ["0.33 A inverts the ratio.", null, "8 A subtracts instead of divides.", "48 A multiplies V by R."] }),
  q({ n: 2, subject: PS, topic: "current-electricity", chapter: "Current Electricity", prompt: "Two resistors of 2 Ω and 3 Ω are connected in series. What is the equivalent resistance?", options: ["1.2 Ω", "5 Ω", "6 Ω", "0.83 Ω"], answer: [1], objective: "Add resistances in series.", explanation: "In series, resistances add: 2 + 3 = 5 Ω.", wrong: ["1.2 Ω is the parallel combination.", null, "6 Ω is the product.", "0.83 Ω is 1/2 + 1/3 without inverting."] }),
  q({ n: 3, subject: PS, topic: "current-electricity", chapter: "Current Electricity", prompt: "Two resistors of 6 Ω and 3 Ω are connected in parallel. What is the equivalent resistance?", options: ["9 Ω", "4.5 Ω", "2 Ω", "18 Ω"], answer: [2], hint: "1/R = 1/R₁ + 1/R₂.", objective: "Combine resistances in parallel.", explanation: "1/R = 1/6 + 1/3 = 1/2, so R = 2 Ω.", wrong: ["9 Ω is the series value.", "4.5 Ω is the average, not the parallel value.", null, "18 Ω is the product."] }),
  q({ n: 1, subject: PS, topic: "periodic-table", chapter: "Periodic Table and Periodicity", prompt: "An element has the electronic configuration 2, 8, 1. What is its atomic number?", options: ["1", "8", "11", "12"], answer: [2], difficulty: "easy", objective: "Find atomic number from electron configuration.", explanation: "A neutral atom has as many electrons as its atomic number: 2 + 8 + 1 = 11 (sodium).", wrong: ["1 counts only the outer electron.", "8 counts only the middle shell.", null, "12 adds an extra electron."] }),
  q({ n: 2, subject: PS, topic: "periodic-table", chapter: "Periodic Table and Periodicity", type: "true-false", prompt: "True or false: elements in the same group of the periodic table have the same number of valence electrons.", options: ["True", "False"], answer: [0], difficulty: "easy", skill: "understand", objective: "Relate group number to valence electrons.", explanation: "Elements in a group have the same outer-shell electron count, which is why they share chemical properties." }),
  // ---- Life science
  q({ n: 1, subject: LS, topic: "heredity", chapter: "Heredity", prompt: "Who is regarded as the father of genetics?", options: ["Charles Darwin", "Gregor Mendel", "Louis Pasteur", "Robert Hooke"], answer: [1], difficulty: "easy", skill: "recall", objective: "Recall the founder of genetics.", explanation: "Gregor Mendel's pea-plant experiments established the basic laws of inheritance." }),
  q({ n: 2, subject: LS, topic: "heredity", chapter: "Heredity", prompt: "In a monohybrid cross between two heterozygous (Tt × Tt) parents, what is the phenotypic ratio in the F₂ generation?", options: ["1 : 1", "3 : 1", "9 : 3 : 3 : 1", "1 : 2 : 1"], answer: [1], hint: "Tall (dominant) versus dwarf (recessive).", objective: "Predict the monohybrid phenotypic ratio.", explanation: "Offspring genotypes are 1 TT : 2 Tt : 1 tt, giving 3 dominant : 1 recessive phenotypes.", wrong: ["1 : 1 is a test-cross ratio.", null, "9 : 3 : 3 : 1 is the dihybrid ratio.", "1 : 2 : 1 is the genotypic, not phenotypic, ratio."] }),
  q({ n: 3, subject: LS, topic: "heredity", chapter: "Heredity", prompt: "A homozygous tall plant (TT) is crossed with a dwarf plant (tt). What is the genotype of the F₁ plants?", options: ["TT", "Tt", "tt", "Tt and tt in equal numbers"], answer: [1], objective: "Predict F₁ genotype.", explanation: "Each F₁ plant receives T from one parent and t from the other, so all are Tt.", wrong: ["TT needs both gametes to carry T.", null, "tt needs both gametes to carry t.", "That ratio appears in a test cross, not here."] }),
  q({ n: 1, subject: LS, topic: "control-coordination", chapter: "Control and Coordination", prompt: "Which gland secretes insulin?", options: ["Thyroid", "Pancreas", "Adrenal", "Pituitary"], answer: [1], difficulty: "easy", skill: "recall", objective: "Recall the source of insulin.", explanation: "Insulin is secreted by the beta cells of the islets of Langerhans in the pancreas." }),
  q({ n: 2, subject: LS, topic: "control-coordination", chapter: "Control and Coordination", prompt: "Which part of the human brain is mainly responsible for maintaining body balance and posture?", options: ["Cerebrum", "Cerebellum", "Medulla oblongata", "Hypothalamus"], answer: [1], skill: "recall", objective: "Recall the function of the cerebellum.", explanation: "The cerebellum coordinates voluntary movement, posture and balance.", wrong: ["The cerebrum handles thinking and voluntary action.", null, "The medulla controls involuntary actions such as breathing.", "The hypothalamus regulates temperature and hunger."] }),
  q({ n: 1, subject: LS, topic: "environment-conservation", chapter: "Environment and Conservation", prompt: "Which gas released by burning fossil fuels is the main contributor to the enhanced greenhouse effect?", options: ["Oxygen", "Nitrogen", "Carbon dioxide", "Argon"], answer: [2], difficulty: "easy", skill: "understand", objective: "Identify the main anthropogenic greenhouse gas.", explanation: "Burning fossil fuels releases large amounts of carbon dioxide, which traps heat in the atmosphere." }),
  q({ n: 2, subject: LS, topic: "environment-conservation", chapter: "Environment and Conservation", prompt: "Which set correctly names the three 'R's of waste management?", options: ["Reduce, Reuse, Recycle", "Remove, Repair, Replace", "Reduce, Refill, Reject", "Recover, Reuse, Resell"], answer: [0], difficulty: "easy", skill: "recall", objective: "Recall the three Rs.", explanation: "The standard three Rs are Reduce, Reuse and Recycle." }),
  // ---- Geography
  q({ n: 1, subject: "geography", topic: "india", chapter: "India", type: "true-false", prompt: "True or false: the Tropic of Cancer passes through West Bengal.", options: ["True", "False"], answer: [0], difficulty: "easy", skill: "recall", objective: "Locate the Tropic of Cancer in India.", explanation: "The Tropic of Cancer (23.5° N) passes through eight Indian states, including West Bengal." }),
  // ---- English
  q({ n: 1, subject: "english", topic: "grammar-rhetoric", chapter: "Grammar", prompt: "Choose the correct form: She ___ to school every day.", options: ["go", "goes", "going", "gone"], answer: [1], difficulty: "easy", objective: "Use subject-verb agreement in the simple present.", explanation: "A third-person singular subject takes the -s form of the verb in the simple present: 'goes'." }),
  q({ n: 2, subject: "english", topic: "grammar-rhetoric", chapter: "Grammar", prompt: "Which sentence is the correct passive voice of 'The cat chased the mouse.'?", options: ["The mouse chased the cat.", "The mouse was chased by the cat.", "The mouse is chased by the cat.", "The mouse has chased the cat."], answer: [1], hint: "Keep the simple past tense and use 'was/were + past participle'.", objective: "Transform active voice to passive voice.", explanation: "The object becomes the subject and the verb becomes 'was chased', followed by 'by the cat'." }),
  q({ n: 3, subject: "english", topic: "grammar-rhetoric", chapter: "Grammar", prompt: "Choose the correct article: He is ___ honest man.", options: ["a", "an", "the", "no article"], answer: [1], hint: "Listen to the first sound of 'honest', not its first letter.", objective: "Choose a/an by sound.", explanation: "'Honest' begins with a vowel sound (the h is silent), so 'an' is used." }),
];

export function authoredFor(board: string, grade: number, subjectId?: string, topicId?: string): QuestionRecord[] {
  return AUTHORED_WBBSE10.filter(
    (r) => r.board === board && r.grade === grade && (!subjectId || r.subjectId === subjectId) && (!topicId || r.topicId === topicId),
  );
}
