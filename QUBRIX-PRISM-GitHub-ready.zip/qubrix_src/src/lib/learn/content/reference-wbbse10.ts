/**
 * Original study notes and quick-reference entries for WBBSE Class X.
 * Written by QUBRIX as short summaries of standard results; NOT copied from, and
 * NOT yet checked against, the prescribed textbooks. Shown with an "unreviewed" label.
 */
export type RefEntry = { id: string; subjectId: string; topicId: string; kind: "formula" | "definition"; term: string; body: string };
export type TopicNote = {
  subjectId: string; topicId: string; summary: string; keyPoints: string[];
  example?: { problem: string; steps: string[] };
};

const r = (subjectId: string, topicId: string, kind: RefEntry["kind"], term: string, body: string): RefEntry => ({
  id: `ref:${subjectId}:${topicId}:${term.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`, subjectId, topicId, kind, term, body,
});

export const REFERENCE_WBBSE10: RefEntry[] = [
  r("maths", "arithmetic", "formula", "Simple interest", "SI = P × r × t / 100, where P is the principal, r the yearly rate (%) and t the time in years. Amount = P + SI."),
  r("maths", "arithmetic", "formula", "Compound interest (annual)", "A = P (1 + r/100)ⁿ and CI = A − P."),
  r("maths", "arithmetic", "formula", "Profit and loss percent", "Profit % = (SP − CP) / CP × 100; Loss % = (CP − SP) / CP × 100. Both are measured on the cost price."),
  r("maths", "algebra", "formula", "Quadratic formula", "For ax² + bx + c = 0 (a ≠ 0): x = (−b ± √(b² − 4ac)) / 2a."),
  r("maths", "algebra", "definition", "Discriminant", "D = b² − 4ac. D > 0: two distinct real roots; D = 0: equal real roots; D < 0: no real roots."),
  r("maths", "algebra", "formula", "Direct variation", "y ∝ x means y = kx for a constant k. For inverse variation, y ∝ 1/x means xy = k."),
  r("maths", "geometry", "definition", "Angle in a semicircle", "The angle subtended by a diameter at any point on the circle is 90°."),
  r("maths", "geometry", "definition", "Tangent and radius", "A tangent to a circle is perpendicular to the radius at the point of contact."),
  r("maths", "geometry", "formula", "Pythagoras' theorem", "In a right triangle, (hypotenuse)² = (base)² + (perpendicular)²."),
  r("maths", "trigonometry", "formula", "Fundamental identities", "sin²θ + cos²θ = 1; 1 + tan²θ = sec²θ; 1 + cot²θ = cosec²θ; tan θ = sin θ / cos θ."),
  r("maths", "trigonometry", "formula", "Standard values", "sin 30° = 1/2, sin 45° = 1/√2, sin 60° = √3/2; cos 30° = √3/2, cos 45° = 1/√2, cos 60° = 1/2; tan 30° = 1/√3, tan 45° = 1, tan 60° = √3."),
  r("maths", "trigonometry", "formula", "Complementary angles", "sin(90° − θ) = cos θ; cos(90° − θ) = sin θ; tan(90° − θ) = cot θ."),
  r("maths", "mensuration", "formula", "Cuboid", "Volume = l × b × h; total surface area = 2(lb + bh + hl); diagonal = √(l² + b² + h²)."),
  r("maths", "mensuration", "formula", "Cylinder", "Curved surface area = 2πrh; total surface area = 2πr(r + h); volume = πr²h."),
  r("maths", "mensuration", "formula", "Cone", "Slant height l = √(r² + h²); curved surface area = πrl; volume = (1/3)πr²h."),
  r("maths", "mensuration", "formula", "Sphere", "Surface area = 4πr²; volume = (4/3)πr³."),
  r("maths", "statistics", "formula", "Mean, median, mode", "Mean = sum of values / number of values. Median is the middle value of ordered data (average of the two middle values if the count is even). Mode is the most frequent value."),
  r("physical-science", "chemical-calculations", "definition", "Mole", "One mole contains 6.022 × 10²³ particles (Avogadro's number). Moles = mass / molar mass."),
  r("physical-science", "chemical-calculations", "formula", "Molar volume at STP", "One mole of any ideal gas occupies 22.4 litres at standard temperature and pressure."),
  r("physical-science", "thermal-phenomena", "formula", "Heat transfer", "Q = m c ΔT, where c is the specific heat capacity (J kg⁻¹ K⁻¹). For a change of state, Q = m L."),
  r("physical-science", "light", "formula", "Mirror formula", "1/v + 1/u = 1/f, and f = R / 2 for a spherical mirror."),
  r("physical-science", "light", "formula", "Refractive index", "n = c / v = sin i / sin r (Snell's law between two media, with the usual sign conventions)."),
  r("physical-science", "current-electricity", "formula", "Ohm's law", "V = I R at constant temperature."),
  r("physical-science", "current-electricity", "formula", "Resistors", "Series: R = R₁ + R₂ + … Parallel: 1/R = 1/R₁ + 1/R₂ + …"),
  r("physical-science", "current-electricity", "formula", "Electrical power and energy", "P = V I = I² R = V² / R. Energy = P × t."),
  r("physical-science", "periodic-table", "definition", "Periodic law (modern)", "Properties of elements are a periodic function of their atomic numbers."),
  r("physical-science", "periodic-table", "definition", "Group and period", "A group is a vertical column (same number of valence electrons); a period is a horizontal row (same number of shells)."),
  r("life", "heredity", "definition", "Dominant and recessive", "A dominant allele shows its effect in the heterozygote; a recessive allele shows only when both alleles are recessive."),
  r("life", "heredity", "formula", "Monohybrid cross (F₂)", "Tt × Tt gives genotypes 1 TT : 2 Tt : 1 tt and a phenotypic ratio of 3 : 1."),
  r("life", "control-coordination", "definition", "Reflex action", "A rapid, involuntary response to a stimulus, carried out through a reflex arc, often without the brain's conscious involvement."),
  r("life", "control-coordination", "definition", "Hormone", "A chemical messenger secreted by an endocrine gland into the blood that acts on target organs."),
  r("life", "environment-conservation", "definition", "Greenhouse effect", "Gases such as carbon dioxide and methane trap heat in the atmosphere, warming the Earth's surface."),
  r("life", "environment-conservation", "definition", "Three Rs", "Reduce, Reuse and Recycle — the basic hierarchy for managing waste and conserving resources."),
  r("english", "grammar-rhetoric", "definition", "Active to passive voice", "Object becomes subject; verb becomes a form of 'be' + past participle; the old subject follows 'by'."),
  r("english", "grammar-rhetoric", "definition", "A or an", "Use 'an' before a vowel sound (an hour, an umbrella) and 'a' before a consonant sound (a university)."),
];

export const NOTES_WBBSE10: TopicNote[] = [
  { subjectId: "maths", topicId: "arithmetic", summary: "Money problems all reduce to a few relationships between principal, rate, time, cost price and selling price.", keyPoints: ["Simple interest grows in a straight line; compound interest earns interest on interest.", "Profit and loss percent are always taken on the cost price.", "For compound interest over n years, multiply the principal by (1 + r/100) n times."], example: { problem: "Find the compound interest on ₹10,000 for 2 years at 10% p.a.", steps: ["A = 10000 × 1.1 × 1.1 = 12,100", "CI = 12,100 − 10,000 = ₹2,100"] } },
  { subjectId: "maths", topicId: "algebra", summary: "A quadratic equation has at most two roots; the discriminant tells you how many real ones.", keyPoints: ["Factorise when the numbers are friendly; otherwise use the quadratic formula.", "D = b² − 4ac decides the nature of the roots.", "In direct variation the ratio y/x is constant; in inverse variation the product xy is constant."], example: { problem: "Solve x² − 5x + 6 = 0.", steps: ["Find two numbers with sum 5 and product 6: 2 and 3", "(x − 2)(x − 3) = 0, so x = 2 or 3"] } },
  { subjectId: "maths", topicId: "geometry", summary: "Circle theorems turn angles and tangents into simple equations.", keyPoints: ["The angle in a semicircle is 90°.", "A tangent is perpendicular to the radius at the point of contact.", "Tangents drawn from one external point are equal in length."] },
  { subjectId: "maths", topicId: "trigonometry", summary: "Trigonometric ratios link angles to side lengths of right triangles.", keyPoints: ["sin = opposite / hypotenuse, cos = adjacent / hypotenuse, tan = opposite / adjacent.", "Learn the table of values for 30°, 45° and 60°.", "In heights-and-distances problems, draw the right triangle first and mark the angle of elevation."], example: { problem: "A tower casts angle of elevation 45° from 20 m away. Find its height.", steps: ["tan 45° = h / 20", "h = 20 × 1 = 20 m"] } },
  { subjectId: "maths", topicId: "mensuration", summary: "Each solid has a surface-area and a volume formula; match the unit to the quantity (cm² versus cm³).", keyPoints: ["Curved surface area excludes the flat ends; total surface area includes them.", "Volume of a cone is one third of the cylinder with the same base and height.", "Convert all lengths to one unit before substituting."] },
  { subjectId: "maths", topicId: "statistics", summary: "Mean, median and mode describe the centre of data in different ways.", keyPoints: ["The mean uses every value; the median is not affected by extreme values.", "Order the data before finding the median.", "The mode is the most frequent value."] },
  { subjectId: "physical-science", topicId: "chemical-calculations", summary: "The mole links the mass of a substance to the number of particles it contains.", keyPoints: ["Moles = mass / molar mass.", "One mole of any gas is 22.4 L at STP.", "Molar mass is the sum of the atomic masses in the formula."] },
  { subjectId: "physical-science", topicId: "thermal-phenomena", summary: "Heat added to a body raises its temperature in proportion to its mass and specific heat.", keyPoints: ["Q = m c ΔT.", "Water has a high specific heat capacity.", "Heat given out by a hot body equals heat taken in by a cold one (no losses)."] },
  { subjectId: "physical-science", topicId: "light", summary: "Mirrors reflect and lenses refract light; sign conventions decide the signs of u, v and f.", keyPoints: ["For a spherical mirror f = R/2.", "Refractive index is the ratio of the speed of light in vacuum to that in the medium.", "Always apply the sign convention consistently."] },
  { subjectId: "physical-science", topicId: "current-electricity", summary: "Ohm's law and the series/parallel rules solve most circuit problems.", keyPoints: ["V = IR.", "Series resistors add; parallel resistors add as reciprocals.", "Power P = VI."], example: { problem: "6 Ω and 3 Ω in parallel: find R.", steps: ["1/R = 1/6 + 1/3 = 1/2", "R = 2 Ω"] } },
  { subjectId: "physical-science", topicId: "periodic-table", summary: "An element's position reflects its electron arrangement.", keyPoints: ["Atomic number = number of protons = electrons in a neutral atom.", "Elements in a group have the same valence electron count.", "Properties change gradually across a period."] },
  { subjectId: "physical-science", topicId: "metallurgy", summary: "Metals differ in reactivity, which decides how they are extracted.", keyPoints: ["More reactive metals need electrolysis; less reactive ones can be reduced chemically.", "Metals are generally good conductors, malleable and ductile."] },
  { subjectId: "life", topicId: "heredity", summary: "Mendel's experiments showed that traits are inherited as separate units.", keyPoints: ["A dominant allele masks a recessive one in a heterozygote.", "A monohybrid F₂ phenotypic ratio is 3 : 1; the genotypic ratio is 1 : 2 : 1.", "A test cross with a homozygous recessive reveals an unknown genotype."] },
  { subjectId: "life", topicId: "control-coordination", summary: "The nervous system gives fast control and the endocrine system gives slower, longer-lasting control.", keyPoints: ["The cerebellum maintains balance and posture.", "Insulin from the pancreas lowers blood sugar.", "A reflex arc bypasses conscious thought."] },
  { subjectId: "life", topicId: "environment-conservation", summary: "Human activity changes ecosystems, so resources must be used and protected carefully.", keyPoints: ["Burning fossil fuels raises atmospheric carbon dioxide.", "Reduce, reuse and recycle lower waste.", "Conservation keeps resources available for the future."] },
  { subjectId: "english", topicId: "grammar-rhetoric", summary: "Correct grammar depends on matching subject and verb, choosing the right tense and voice, and using articles by sound.", keyPoints: ["Third-person singular subjects take -s in the simple present.", "Choose 'an' before a vowel sound.", "In the passive voice the object becomes the subject."] },
];
export const noteFor = (subjectId: string, topicId: string): TopicNote | undefined => NOTES_WBBSE10.find((n) => n.subjectId === subjectId && n.topicId === topicId);
export const referenceFor = (subjectId?: string, topicId?: string): RefEntry[] => REFERENCE_WBBSE10.filter((e) => (!subjectId || e.subjectId === subjectId) && (!topicId || e.topicId === topicId));
