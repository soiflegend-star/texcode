/** PRISM Performance Monitor — honest bank diversity metrics */
import { streamQuestion } from "../learn/resolve.ts";
import { practiceTopics } from "../learn/registry.ts";
import type { Difficulty } from "../learn/types.ts";
import { questionFingerprint, structuralFingerprint } from "./fingerprint.ts";
import type { BankAnalytics } from "./types.ts";

const SAMPLE_CAP = 400;

export function analyseTopic(
  board: string, grade: number, subjectId: string, topicId: string, sampleSize = SAMPLE_CAP,
): BankAnalytics {
  const fingerprints = new Set<string>();
  const answers = new Set<string>();
  const families: Record<string, number> = {};
  const difficulty: Record<Difficulty, number> = { easy: 0, medium: 0, hard: 0 };
  const sampleIds: string[] = [];
  let total = 0;
  for (let i = 0; i < sampleSize; i++) {
    const q = streamQuestion(board, grade, subjectId, topicId, i);
    if (!q) continue;
    total++;
    fingerprints.add(questionFingerprint(q));
    fingerprints.add(structuralFingerprint(q));
    if (q.type === "numeric" && q.numeric) answers.add(`n:${q.numeric.value}`);
    else answers.add(q.answer.slice().sort().join(","));
    const fam = q.generatorTag ?? "untagged";
    families[fam] = (families[fam] ?? 0) + 1;
    const d = (q.difficulty ?? "medium") as Difficulty;
    difficulty[d] = (difficulty[d] ?? 0) + 1;
    if (sampleIds.length < 8) sampleIds.push(q.id);
  }
  return {
    subjectId, topicId, totalGenerated: total,
    distinctFingerprints: fingerprints.size, distinctAnswers: answers.size,
    families, difficulty, sampleIds,
  };
}

export function analyseBoard(board: string, grade: number, perTopic = 200): BankAnalytics[] {
  return practiceTopics(board, grade).map((t) =>
    analyseTopic(board, grade, t.subjectId, t.id, perTopic),
  );
}

export function summarise(rows: BankAnalytics[]) {
  const bySubject: Record<string, { topics: number; distinctFp: number }> = {};
  let total = 0;
  let sumFp = 0;
  for (const r of rows) {
    total += r.totalGenerated;
    sumFp += r.distinctFingerprints;
    const s = bySubject[r.subjectId] ?? { topics: 0, distinctFp: 0 };
    s.topics++;
    s.distinctFp += r.distinctFingerprints;
    bySubject[r.subjectId] = s;
  }
  return {
    topics: rows.length,
    totalSampled: total,
    meanDistinctFp: rows.length ? Math.round(sumFp / rows.length) : 0,
    bySubject,
  };
}
