/**
 * PRISM Adaptive Brain & Difficulty Controller — max-capability, hot-path friendly.
 */
import { masteryOf, recentAccuracy } from "../learn/review.ts";
import type { AppState } from "../learn/state.ts";
import { topicKey } from "../learn/state.ts";
import type { Difficulty, SessionKind } from "../learn/types.ts";
import type { AdaptiveSignals, PrismFamily } from "./types.ts";

const RANK: Record<Difficulty, number> = { easy: 0, medium: 1, hard: 2 };
const BY_RANK: Difficulty[] = ["easy", "medium", "hard"];

export function computeSignals(
  state: AppState | null,
  board: string,
  grade: number,
  subjectId?: string,
  topicId?: string,
): AdaptiveSignals {
  if (!state) {
    return {
      accuracy: 0.5, recentAccuracy: 0.5, weakTopics: [], strongTopics: [],
      recentMistakes: [], preferredDifficulty: "medium", exposureCount: 0,
    };
  }
  const total = Math.max(1, state.totals.answered);
  const accuracy = state.totals.correct / total;
  let recent = 0.5;
  let exposureCount = 0;
  const weak: string[] = [];
  const strong: string[] = [];
  const prefix = `${board}|${grade}|`;
  const subjNeedle = subjectId ? `|${subjectId}|` : null;

  for (const tk of Object.keys(state.topics)) {
    if (!tk.startsWith(prefix)) continue;
    if (subjNeedle && !tk.includes(subjNeedle)) continue;
    const t = state.topics[tk]!;
    exposureCount += t.attempts ?? 0;
    const m = masteryOf(t);
    const tid = tk.split("|")[3] ?? tk;
    if (m === "learning" || m === "not-started") {
      if (weak.length < 8) weak.push(tid);
    } else if (m === "strong") {
      if (strong.length < 8) strong.push(tid);
    }
    const ra = recentAccuracy(t);
    if (ra !== null) recent = ra;
  }

  if (topicId) {
    const tk = topicKey(board, grade, subjectId ?? "", topicId);
    const t = state.topics[tk];
    if (t) {
      const ra = recentAccuracy(t);
      if (ra !== null) recent = ra;
    }
  }

  const mistakes: string[] = [];
  if (state.mistakes) {
    // Take up to 12 most recent without full sort when small
    const entries = Object.entries(state.mistakes);
    if (entries.length <= 16) {
      entries
        .filter(([, v]) => (v?.count ?? 0) > 0)
        .sort((a, b) => (b[1].lastAt ?? 0) - (a[1].lastAt ?? 0))
        .slice(0, 12)
        .forEach(([k]) => mistakes.push(k));
    } else {
      // partial: first 24 keys is good enough for adaptive bias
      for (const [k, v] of entries) {
        if ((v?.count ?? 0) > 0) {
          mistakes.push(k);
          if (mistakes.length >= 12) break;
        }
      }
    }
  }

  return {
    accuracy,
    recentAccuracy: recent,
    weakTopics: weak,
    strongTopics: strong,
    recentMistakes: mistakes,
    preferredDifficulty: preferDifficulty(accuracy, recent),
    exposureCount,
  };
}

/** Gradual difficulty — never punish with endless easy. */
export function preferDifficulty(overall: number, recent: number): Difficulty {
  const score = 0.35 * overall + 0.65 * recent;
  if (score >= 0.78) return "hard";
  if (score >= 0.52) return "medium";
  return "easy";
}

export function nextDifficulty(
  current: Difficulty,
  lastCorrect: boolean,
  consecutiveCorrect: number,
  consecutiveWrong: number,
): Difficulty {
  const r = RANK[current];
  if (lastCorrect && consecutiveCorrect >= 3 && r < 2) return BY_RANK[r + 1]!;
  if (!lastCorrect && consecutiveWrong >= 3 && r > 0) return BY_RANK[r - 1]!;
  // Micro-promote after 5 correct at medium
  if (lastCorrect && consecutiveCorrect >= 5 && current === "medium") return "hard";
  return current;
}

export function scoreCandidate(
  signals: AdaptiveSignals,
  difficulty: Difficulty | undefined,
  topicId: string,
  family?: PrismFamily,
  lastFamilies: PrismFamily[] = [],
): number {
  let score = 50;
  const d = difficulty ?? "medium";
  score -= Math.abs(RANK[d] - RANK[signals.preferredDifficulty]) * 12;
  if (signals.weakTopics.includes(topicId)) score += 18;
  if (signals.strongTopics.includes(topicId) && d === "hard") score += 8;
  if (family && lastFamilies.length) {
    let same = 0;
    for (let i = lastFamilies.length - 1; i >= 0 && i >= lastFamilies.length - 3; i--) {
      if (lastFamilies[i] === family) same++;
    }
    score -= same * 15;
  }
  return score;
}

export function modeDifficultyBias(kind: SessionKind): Difficulty {
  switch (kind) {
    case "quick":
    case "daily":
      return "medium";
    case "exam":
      return "hard";
    case "revision":
      return "easy";
    default:
      return "medium";
  }
}
