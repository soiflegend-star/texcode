/**
 * PRISM question fingerprinting — multi-level novelty detection.
 * Optimised hot path: single-pass normalize, FNV-1a, WeakMap caches.
 */
import type { QuestionRecord } from "../learn/types.ts";

const fpCache = new WeakMap<object, string>();
const structCache = new WeakMap<object, string>();

export function normalizePrompt(prompt: string): string {
  let out = "";
  let prevSpace = true;
  for (let i = 0; i < prompt.length; i++) {
    const c = prompt.charCodeAt(i);
    if (c >= 48 && c <= 57) {
      if (out.length === 0 || out.charCodeAt(out.length - 1) !== 35) out += "#";
      prevSpace = false;
      while (i + 1 < prompt.length) {
        const n = prompt.charCodeAt(i + 1);
        if ((n >= 48 && n <= 57) || n === 46) i++;
        else break;
      }
      continue;
    }
    const lower = c >= 65 && c <= 90 ? c + 32 : c;
    const isLetter = (lower >= 97 && lower <= 122) || lower > 127;
    const isSpace = c === 32 || c === 9 || c === 10 || c === 13;
    if (isLetter) {
      out += String.fromCharCode(lower);
      prevSpace = false;
    } else if (isSpace) {
      if (!prevSpace) {
        out += " ";
        prevSpace = true;
      }
    }
  }
  return prevSpace && out.length ? out.slice(0, -1) : out;
}

export function fnv1a(s: string): string {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(36);
}

export function structuralFingerprint(q: QuestionRecord): string {
  const cached = structCache.get(q as object);
  if (cached) return cached;
  const norm = normalizePrompt(q.prompt);
  const lens: number[] = new Array(q.options.length);
  for (let i = 0; i < q.options.length; i++) lens[i] = q.options[i]!.length;
  lens.sort((a, b) => a - b);
  let optLens = "";
  for (let i = 0; i < lens.length; i++) {
    if (i) optLens += ",";
    optLens += String(lens[i]);
  }
  const ansShape =
    q.type === "numeric"
      ? `n:${q.numeric?.value ?? 0}:${q.numeric?.tolerance ?? 0}`
      : `c:${q.answer.slice().sort((x, y) => x - y).join(",")}`;
  const fp = fnv1a(`${q.type}|${q.subjectId}|${q.topicId}|${norm}|${optLens}|${ansShape}`);
  structCache.set(q as object, fp);
  return fp;
}

export function parameterFingerprint(q: QuestionRecord): string {
  const nums = (q.prompt.match(/-?\d+(\.\d+)?/g) ?? []).slice(0, 8).join(",");
  return fnv1a(`${q.subjectId}|${q.topicId}|${q.generatorTag ?? "none"}|${nums}|${q.type}`);
}

export function questionFingerprint(q: QuestionRecord): string {
  const cached = fpCache.get(q as object);
  if (cached) return cached;
  const fp = structuralFingerprint(q) || fnv1a(q.id);
  fpCache.set(q as object, fp);
  return fp;
}

export function isNearDuplicate(a: QuestionRecord, b: QuestionRecord): boolean {
  if (a.id === b.id) return true;
  if (structuralFingerprint(a) === structuralFingerprint(b)) return true;
  if (a.generatorTag && b.generatorTag && parameterFingerprint(a) === parameterFingerprint(b)) return true;
  return false;
}

export function isNormalizedDuplicate(a: QuestionRecord, b: QuestionRecord): boolean {
  return a.type === b.type && normalizePrompt(a.prompt) === normalizePrompt(b.prompt);
}
