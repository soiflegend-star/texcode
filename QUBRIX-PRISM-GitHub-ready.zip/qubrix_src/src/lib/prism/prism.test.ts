import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  normalizePrompt, structuralFingerprint, questionFingerprint, isNearDuplicate,
} from "./fingerprint.ts";
import {
  checkNovelty, checkNoveltyFast, markSeen, poolExhaustedMessage,
  exposuresFromState, buildExposureIndex, recordExposure,
} from "./novelty.ts";
import { preferDifficulty, nextDifficulty, computeSignals } from "./adaptive.ts";
import { pickFamily, offerChallenge } from "./variety.ts";
import { levelForCorrect, levelForSession, intensityOf } from "./victory.ts";
import { defaultState, sanitizeState } from "../learn/state.ts";
import type { QuestionRecord } from "../learn/types.ts";

function sampleQ(over: Partial<QuestionRecord> = {}): QuestionRecord {
  return {
    id: "gen:wbbse|10|maths|quadratic|0",
    type: "mcq", board: "wbbse", grade: 10, subjectId: "maths", topicId: "quadratic",
    prompt: "For x² - 5x + 6 = 0, what is the sum of the roots?",
    options: ["5", "6", "-5", "11"], answer: [0], explanation: "Sum = 5.",
    language: "en", sources: [{ kind: "generator", label: "maths" }],
    origin: "generated-variant", review: "machine-validated", version: 1,
    examLabel: "practice", difficulty: "medium", generatorTag: "Quadratic equations",
    ...over,
  };
}

describe("PRISM fingerprint", () => {
  it("normalizes prompts by stripping numbers", () => {
    assert.equal(
      normalizePrompt("Sum of roots of x² - 5x + 6 = 0?"),
      normalizePrompt("Sum of roots of x² - 7x + 12 = 0?"),
    );
  });
  it("structural fingerprint is stable and cached", () => {
    const q = sampleQ();
    assert.equal(structuralFingerprint(q), structuralFingerprint(q));
    assert.equal(questionFingerprint(q), questionFingerprint(q));
  });
  it("detects near-duplicates", () => {
    assert.equal(isNearDuplicate(sampleQ(), sampleQ({ id: "other" })), true);
  });
  it("distinct prompts can differ", () => {
    const a = sampleQ();
    const b = sampleQ({ id: "x", prompt: "What is the capital of France?", options: ["Paris", "Lyon", "Nice", "Lille"], answer: [0] });
    assert.notEqual(structuralFingerprint(a), structuralFingerprint(b));
  });
});

describe("PRISM novelty guard", () => {
  it("rejects exact duplicate in fresh practice", () => {
    const q = sampleQ();
    const state = defaultState();
    state.questions[q.id] = { attempts: 1, correct: 1, lastAt: 1, correctRun: 1 };
    assert.equal(checkNovelty(state, q, "practice", new Set()).ok, false);
  });
  it("allows the same question in revision mode", () => {
    const q = sampleQ();
    const state = defaultState();
    state.questions[q.id] = { attempts: 2, correct: 1, lastAt: 2, correctRun: 0 };
    const d = checkNovelty(state, q, "revision", new Set());
    assert.equal(d.ok, true);
    assert.equal(d.reason, "revision-allowed");
  });
  it("rejects session-level fingerprint collision", () => {
    const q = sampleQ();
    const seen = new Set<string>();
    markSeen(seen, q);
    assert.equal(checkNovelty(null, sampleQ({ id: "clone" }), "practice", seen).ok, false);
  });
  it("accepts valid distinct questions", () => {
    const d = checkNovelty(defaultState(), sampleQ({ id: "fresh", prompt: "What is 2+2?" }), "practice", new Set());
    assert.equal(d.ok, true);
  });
  it("pool exhausted message is honest", () => {
    assert.match(poolExhaustedMessage("Quadratic equations"), /Revision mode/);
  });
  it("exposuresFromState reads attempt history", () => {
    const s = defaultState();
    s.questions["x"] = { attempts: 3, correct: 2, lastAt: 20, correctRun: 1 };
    assert.equal(exposuresFromState(s).get("x")?.count, 3);
  });
  it("records a durable exposure without double-counting attempts", () => {
    const s = defaultState();
    s.questions["q1"] = { attempts: 1, correct: 1, lastAt: 10, correctRun: 1 };
    const next = recordExposure(s, sampleQ({ id: "q1" }), "session-1", 20);
    assert.equal(next.questions["q1"]?.attempts, 1);
    assert.equal(next.prism.exposures["q1"]?.count, 1);
    assert.equal(next.prism.exposures["q1"]?.sessionIds[0], "session-1");
    const restored = sanitizeState(JSON.parse(JSON.stringify(next)));
    assert.equal(restored?.prism.exposures["q1"]?.fingerprint, next.prism.exposures["q1"]?.fingerprint);
  });
  it("buildExposureIndex is O(1) for known ids", () => {
    const s = defaultState();
    s.questions["a"] = { attempts: 1, correct: 1, lastAt: 1, correctRun: 1 };
    s.questions["b"] = { attempts: 2, correct: 0, lastAt: 2, correctRun: 0 };
    const idx = buildExposureIndex(s);
    assert.equal(idx.byId.has("a"), true);
    assert.equal(idx.byId.has("missing"), false);
    const q = sampleQ({ id: "a" });
    assert.equal(checkNoveltyFast(idx, q, "practice", new Set()).ok, false);
    assert.equal(checkNoveltyFast(idx, sampleQ({ id: "brand-new", prompt: "Unique?" }), "practice", new Set()).ok, true);
  });
});

describe("PRISM adaptive brain", () => {
  it("preferDifficulty steps gradually", () => {
    assert.equal(preferDifficulty(0.9, 0.9), "hard");
    assert.equal(preferDifficulty(0.6, 0.6), "medium");
    assert.equal(preferDifficulty(0.3, 0.3), "easy");
  });
  it("nextDifficulty promotes and soft-demotes", () => {
    assert.equal(nextDifficulty("easy", true, 3, 0), "medium");
    assert.equal(nextDifficulty("hard", false, 0, 3), "medium");
    assert.equal(nextDifficulty("easy", false, 0, 5), "easy");
  });
  it("computeSignals returns sane defaults", () => {
    assert.equal(computeSignals(null, "wbbse", 10).preferredDifficulty, "medium");
  });
});

describe("PRISM variety & victory", () => {
  it("pickFamily and challenge gates work", () => {
    assert.ok(typeof pickFamily([]) === "string");
    assert.equal(offerChallenge(0.8, 10), true);
    assert.equal(offerChallenge(0.5, 10), false);
  });
  it("victory intensity scales", () => {
    assert.ok(intensityOf("correct") < intensityOf("perfect-session"));
    assert.equal(levelForCorrect(12), "streak");
    assert.equal(levelForSession({ perfect: true, accuracyRecord: false, kind: "practice" }), "perfect-session");
  });
});

describe("PRISM speed invariants", () => {
  it("fingerprint cache returns identical reference string", () => {
    const q = sampleQ();
    const a = questionFingerprint(q);
    const b = questionFingerprint(q);
    assert.equal(a, b);
  });
  it("index build scales with questions map", () => {
    const s = defaultState();
    for (let i = 0; i < 200; i++) {
      s.questions[`id-${i}`] = { attempts: 1, correct: 0, lastAt: i, correctRun: 0 };
    }
    const t0 = performance.now();
    const idx = buildExposureIndex(s);
    const t1 = performance.now();
    assert.equal(idx.byId.size, 200);
    assert.ok(t1 - t0 < 50, `index build too slow: ${t1 - t0}ms`);
  });
});
