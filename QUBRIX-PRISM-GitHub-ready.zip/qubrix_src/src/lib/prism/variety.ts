/** PRISM Learning Variety Engine */
import type { QuestionType } from "../learn/types.ts";
import type { PrismFamily, SessionMode } from "./types.ts";

export const FAMILIES: PrismFamily[] = [
  "direct", "conceptual", "application", "calculation", "reverse",
  "comparison", "cause-effect", "identify-error", "scenario",
  "analytical", "multi-step", "exam-style",
];

export function pickFamily(recent: PrismFamily[], available: PrismFamily[] = FAMILIES): PrismFamily {
  const pool = available.length ? available : FAMILIES;
  for (let i = 0; i < pool.length; i++) {
    const f = pool[(recent.length + i) % pool.length]!;
    if (!recent.slice(-2).includes(f)) return f;
  }
  return pool[recent.length % pool.length]!;
}

export function shouldRotateType(recentTypes: QuestionType[], candidate: QuestionType): boolean {
  if (recentTypes.length < 2) return true;
  return recentTypes.slice(-3).filter((t) => t === candidate).length < 2;
}

export function sequenceHint(mode: SessionMode, index: number, total: number): string {
  const phase = index / Math.max(1, total);
  switch (mode) {
    case "concept-mastery":
      return phase < 0.4 ? "Building understanding" : phase < 0.7 ? "Applying concepts" : "Analysing";
    case "adaptive-practice": return "Matched to your recent performance";
    case "mock-exam": return "Exam-style timing and mix";
    case "revision": return "Reinforcing previously seen material";
    case "daily-challenge": return "Today's focused challenge";
    case "mixed-practice": return "Rotating subjects and skills";
    default: return "Practising this topic";
  }
}

export function offerChallenge(accuracy: number, answered: number): boolean {
  return answered >= 8 && accuracy >= 0.75;
}

export function challengeLabel(): string {
  return "Optional challenge round — a few harder questions. Skip anytime.";
}
