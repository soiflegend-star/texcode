/**
 * PRISM — Personalized Retrieval, Intelligence, Sequencing & Motivation
 * Shared types for the learning-intelligence upgrade.
 */
import type { Difficulty, Skill } from "../learn/types.ts";

export type PrismFamily =
  | "direct" | "conceptual" | "application" | "calculation" | "reverse"
  | "comparison" | "cause-effect" | "identify-error" | "scenario"
  | "analytical" | "multi-step" | "exam-style";

export type ExposureRecord = {
  id: string;
  fingerprint: string;
  subjectId: string;
  topicId: string;
  family?: PrismFamily;
  firstAt: number;
  lastAt: number;
  count: number;
  sessionIds: string[];
};

export type NoveltyDecision =
  | { ok: true; reason: "fresh" | "revision-allowed" }
  | { ok: false; reason: "exact-duplicate" | "fingerprint-duplicate" | "near-duplicate" | "pool-exhausted" };

export type AdaptiveSignals = {
  accuracy: number;
  recentAccuracy: number;
  weakTopics: string[];
  strongTopics: string[];
  recentMistakes: string[];
  preferredDifficulty: Difficulty;
  exposureCount: number;
  timeSpentMs?: number;
};

export type SessionMode =
  | "topic-practice" | "quick-practice" | "adaptive-practice" | "mixed-practice"
  | "daily-challenge" | "mock-exam" | "revision" | "concept-mastery";

export type VictoryLevel =
  | "correct" | "streak" | "perfect-session" | "accuracy-record"
  | "achievement" | "topic-mastery" | "daily-complete" | "mock-complete" | "milestone";

export type BankAnalytics = {
  subjectId: string;
  topicId?: string;
  totalGenerated: number;
  distinctFingerprints: number;
  distinctAnswers: number;
  families: Record<string, number>;
  difficulty: Record<Difficulty, number>;
  sampleIds: string[];
};

export type PrismConfig = {
  noveltyStrict: boolean;
  allowRevisionRepeats: boolean;
  maxConsecutiveSameFamily: number;
  maxConsecutiveSameType: number;
  adaptiveWindow: number;
};
