/** PRISM Victory Experience — celebration level logic */
import type { VictoryLevel } from "./types.ts";

export type VictoryEvent = {
  level: VictoryLevel;
  title: string;
  subtitle?: string;
  xpDelta?: number;
  achievementId?: string;
};

export function levelForCorrect(streak: number): VictoryLevel {
  return streak >= 10 ? "streak" : "correct";
}

export function levelForSession(opts: {
  perfect: boolean;
  accuracyRecord: boolean;
  kind: string;
  masteryUnlocked?: boolean;
  achievementUnlocked?: string;
}): VictoryLevel {
  if (opts.perfect) return "perfect-session";
  if (opts.accuracyRecord) return "accuracy-record";
  if (opts.masteryUnlocked) return "topic-mastery";
  if (opts.achievementUnlocked) return "achievement";
  if (opts.kind === "daily") return "daily-complete";
  if (opts.kind === "exam") return "mock-complete";
  return "milestone";
}

export function eventFor(level: VictoryLevel, extra?: Partial<VictoryEvent>): VictoryEvent {
  const base: Record<VictoryLevel, { title: string; subtitle?: string }> = {
    correct: { title: "Correct", subtitle: "Keep going" },
    streak: { title: "On a roll", subtitle: "Streak growing" },
    "perfect-session": { title: "Perfect session", subtitle: "Every answer correct" },
    "accuracy-record": { title: "Personal best", subtitle: "New accuracy record" },
    achievement: { title: "Achievement unlocked", subtitle: extra?.title },
    "topic-mastery": { title: "Topic mastered", subtitle: "Strong understanding" },
    "daily-complete": { title: "Daily challenge done", subtitle: "Come back tomorrow" },
    "mock-complete": { title: "Mock test complete", subtitle: "Review your results" },
    milestone: { title: "Session complete", subtitle: "Progress saved" },
  };
  return { level, ...base[level], ...extra };
}

export function intensityOf(level: VictoryLevel): number {
  switch (level) {
    case "correct": return 0.25;
    case "streak": return 0.45;
    case "achievement":
    case "topic-mastery": return 0.7;
    case "perfect-session":
    case "accuracy-record":
    case "mock-complete": return 0.9;
    case "daily-complete":
    case "milestone": return 0.55;
    default: return 0.3;
  }
}
