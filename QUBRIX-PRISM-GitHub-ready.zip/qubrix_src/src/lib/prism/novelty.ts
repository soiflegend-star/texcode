/**
 * PRISM Novelty Guard — persistent exposure + multi-level dedup.
 * Speed: ExposureIndex with O(1) id and fingerprint sets; built once per plan.
 */
import type { AppState } from "../learn/state.ts";
import type { QuestionRecord, SessionKind } from "../learn/types.ts";
import { questionFingerprint, structuralFingerprint } from "./fingerprint.ts";
import type { ExposureRecord, NoveltyDecision } from "./types.ts";

const MAX_SESSION_IDS = 8;
const MAX_EXPOSURES = 8000;

/** Fast lookup structure for a planning pass. */
export type ExposureIndex = {
  byId: Set<string>;
  byFp: Set<string>;
};

/** Build O(1) index once; reuse across collectTopic calls in a session plan. */
export function buildExposureIndex(state: AppState | null): ExposureIndex {
  const byId = new Set<string>();
  const byFp = new Set<string>();
  if (!state?.questions) return { byId, byFp };
  for (const [id, q] of Object.entries(state.questions)) {
    if (!q || (q.attempts ?? 0) <= 0) continue;
    byId.add(id);
  }
  const prism = (state as { prism?: { exposures?: Record<string, ExposureRecord> } }).prism;
  if (prism?.exposures) {
    for (const [id, rec] of Object.entries(prism.exposures)) {
      if (!rec || typeof rec.id !== "string") continue;
      byId.add(id);
      if (rec.fingerprint) byFp.add(rec.fingerprint);
    }
  }
  // For learners without prism.exposures yet, ids alone still block exact repeats.
  return { byId, byFp };
}

export function exposuresFromState(state: AppState | null): Map<string, ExposureRecord> {
  const map = new Map<string, ExposureRecord>();
  if (!state?.questions) return map;
  for (const [id, q] of Object.entries(state.questions)) {
    if (!q || (q.attempts ?? 0) <= 0) continue;
    map.set(id, {
      id,
      fingerprint: id,
      subjectId: "",
      topicId: "",
      firstAt: q.lastAt ?? 0,
      lastAt: q.lastAt ?? 0,
      count: q.attempts ?? 1,
      sessionIds: [],
    });
  }
  const prism = (state as { prism?: { exposures?: Record<string, ExposureRecord> } }).prism;
  if (prism?.exposures) {
    for (const [id, rec] of Object.entries(prism.exposures)) {
      if (rec && typeof rec.id === "string") map.set(id, rec);
    }
  }
  return map;
}

export function recordExposure(state: AppState, q: QuestionRecord, sessionId: string, now: number): AppState {
  const fp = questionFingerprint(q);
  // Attempt statistics are owned by learn/state.recordAnswer. This function
  // records the PRISM exposure ledger only, preventing double-counting.
  const prism = (state as { prism?: { exposures?: Record<string, ExposureRecord> } }).prism ?? {};
  const exposures = { ...(prism.exposures ?? {}) };
  const prev = exposures[q.id];
  const sessionIds = prev?.sessionIds ? [...prev.sessionIds] : [];
  if (!sessionIds.includes(sessionId)) {
    sessionIds.push(sessionId);
    if (sessionIds.length > MAX_SESSION_IDS) sessionIds.shift();
  }
  exposures[q.id] = {
    id: q.id,
    fingerprint: fp,
    subjectId: q.subjectId,
    topicId: q.topicId,
    firstAt: prev?.firstAt ?? now,
    lastAt: now,
    count: (prev?.count ?? 0) + 1,
    sessionIds,
  };

  const keys = Object.keys(exposures);
  if (keys.length > MAX_EXPOSURES) {
    keys
      .sort((a, b) => exposures[a]!.lastAt - exposures[b]!.lastAt)
      .slice(0, keys.length - MAX_EXPOSURES)
      .forEach((k) => delete exposures[k]);
  }

  return {
    ...state,
    prism: { ...prism, exposures },
  } as AppState;
}

/**
 * Fast novelty check using prebuilt index + session seen set.
 * Prefer checkNoveltyFast in planning loops.
 */
export function checkNoveltyFast(
  index: ExposureIndex | null,
  q: QuestionRecord,
  kind: SessionKind,
  seenInSession: Set<string>,
): NoveltyDecision {
  const isRevision = kind === "revision";
  const fp = questionFingerprint(q);
  const sig = structuralFingerprint(q);

  if (seenInSession.has(q.id) || seenInSession.has(fp) || seenInSession.has(sig)) {
    return { ok: false, reason: "exact-duplicate" };
  }
  if (isRevision) return { ok: true, reason: "revision-allowed" };

  if (index) {
    if (index.byId.has(q.id)) return { ok: false, reason: "exact-duplicate" };
    if (index.byFp.has(fp) || index.byFp.has(sig)) return { ok: false, reason: "fingerprint-duplicate" };
  }
  return { ok: true, reason: "fresh" };
}

/** Compatibility wrapper — builds index if none provided (slower). */
export function checkNovelty(
  state: AppState | null,
  q: QuestionRecord,
  kind: SessionKind,
  seenInSession: Set<string>,
): NoveltyDecision {
  const index = state ? buildExposureIndex(state) : null;
  return checkNoveltyFast(index, q, kind, seenInSession);
}

export function markSeen(seen: Set<string>, q: QuestionRecord): void {
  seen.add(q.id);
  seen.add(questionFingerprint(q));
  seen.add(structuralFingerprint(q));
}

export function poolExhaustedMessage(topicTitle?: string): string {
  const where = topicTitle ? ` for ${topicTitle}` : "";
  return `You have practised all currently available distinct questions${where}. Switch to Revision mode to reinforce memory, or try another topic.`;
}

export function isFreshPractice(kind: SessionKind): boolean {
  return kind !== "revision";
}
