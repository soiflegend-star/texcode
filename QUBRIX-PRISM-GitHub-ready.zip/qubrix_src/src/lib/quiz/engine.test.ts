import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { getQuestion, getTopicQuestion, topicsFor, topicQuestionCount, BANK_SIZE } from "./bank.ts";
import { binom, combinadic } from "./core.ts";
import { EVENTS } from "./history.ts";
import { organisms } from "./life.ts";
import { BOARDS, subjectsFor } from "./catalog.ts";

function signature(q: { prompt: string; options: string[]; answer: number }) {
  const correct = q.options[q.answer];
  return `${q.prompt}@@${correct}@@${[...q.options].sort().join("|")}`;
}

function assertQuestion(label: string) {
  return (index: number, board = "wbbse", subject = "maths") => {
    const q = getQuestion(board, subject, index);
    assert.equal(q.options.length, 4, label);
    assert.ok(q.answer >= 0 && q.answer < 4, label);
    assert.equal(new Set(q.options.map((o) => o.toLowerCase())).size, 4, `${label} ${q.prompt} :: ${q.options.join(" | ")}`);
    assert.equal(q.topic === "Recovery", false, `${label} recovery ${q.prompt}`);
    for (const opt of q.options) {
      assert.equal(opt.includes("None of these"), false, `${label} filler :: ${q.prompt} :: ${q.options.join(" | ")}`);
    }
    assert.ok(q.prompt.length > 8, label);
    assert.ok(q.explanation.length > 8, label);
    return q;
  };
}

describe("combinadic", () => {
  it("lists every 3-subset of 5 once", () => {
    const seen = new Set<string>();
    for (let i = 0; i < binom(5, 3); i++) {
      const c = combinadic(3, i);
      assert.deepEqual(
        [...c].sort((a, b) => a - b),
        c,
      );
      assert.ok(c.every((n) => n >= 0 && n < 5));
      seen.add(c.join(","));
    }
    assert.equal(seen.size, 10);
  });
});

describe("history data", () => {
  it("uses a unique year for every event", () => {
    const years = EVENTS.map((e) => e.year);
    assert.equal(new Set(years).size, years.length);
  });
});

describe("question banks", () => {
  const subjects = [
    "maths",
    "physics",
    "chemistry",
    "life",
    "physical-science",
    "science",
    "history",
    "geography",
    "english",
  ] as const;

  for (const subject of subjects) {
    it(`${subject} serves a valid MCQ across the bank`, () => {
      const check = assertQuestion(subject);
      const indexes = [0, 1, 2, 3, 17, 47, 100, 499, 1500, 7499, 14999, BANK_SIZE - 1];
      for (let index = 0; index < 180; index++) check(index, "wbbse", subject);
      for (const index of indexes) check(index, "wbbse", subject);
      check(8, "cbse", subject);
    });
  }

  it("serves four-option practice across every listed board and class", () => {
    for (const board of BOARDS) {
      for (const grade of [5, 6, 7, 8, 9, 10, 11]) {
        const subjectIds = grade === 11
          ? ["physics", "chemistry", "maths", "life"]
          : subjectsFor(board.id).map((subject) => subject.id);
        for (const subject of subjectIds) {
          for (const index of [0, 20, 999, BANK_SIZE - 1, BANK_SIZE + 20]) {
            const q = getQuestion(board.id, subject, index, grade);
            assert.equal(q.options.length, 4, `${board.id} class ${grade} ${subject}`);
            assert.ok(q.prompt.length > 8);
            assert.ok(q.explanation.length > 8);
            assert.notEqual(q.topic, "Recovery");
          }
        }
      }
    }
  });

  it("creates class-scoped and continuing practice cycles", () => {
    const classFive = getQuestion("wbbse", "physics", 20, 5);
    const classTen = getQuestion("wbbse", "physics", 20, 10);
    const nextCycle = getQuestion("wbbse", "physics", BANK_SIZE + 20, 10);
    assert.notEqual(signature(classFive), signature(classTen));
    assert.notEqual(signature(classTen), signature(nextCycle));
  });

  it("mixed challenge rotates across subject families", () => {
    const topics = new Set<string>();
    for (let i = 0; i < 35; i++) {
      const q = getQuestion("wbbse", "mixed", i, 10);
      assert.equal(q.options.length, 4);
      topics.add(q.topic);
    }
    assert.ok(topics.size >= 4);
  });

  it("gk serves a valid MCQ", () => {
    const check = assertQuestion("gk");
    for (const index of [0, 1, 4, 5, 20, 100, 4000, BANK_SIZE - 1]) {
      const q = check(index, "general", "gk");
      assert.ok(q.prompt.length > 0);
    }
  });

  it("life classification marks a real mammal", () => {
    const mammals = new Set(organisms.filter((o) => o.group === "mammal").map((o) => o.name));
    let seen = 0;
    for (let i = 0; i < 400 && seen < 8; i++) {
      const q = getQuestion("wbbse", "life", i);
      if (q.prompt === "Which of the following is a mammal?") {
        assert.ok(mammals.has(q.options[q.answer] ?? ""));
        for (let k = 0; k < 4; k++) {
          if (k !== q.answer) assert.equal(mammals.has(q.options[k] ?? ""), false);
        }
        seen++;
      }
    }
    assert.ok(seen > 0);
  });

  it("maths prompts do not repeat in the first 400", () => {
    const seen = new Set<string>();
    for (let i = 0; i < 400; i++) {
      const q = getQuestion("wbbse", "maths", i);
      const sig = signature(q);
      assert.equal(seen.has(sig), false, q.prompt);
      seen.add(sig);
    }
  });
});


describe("topic-only continuous practice", () => {
  it("shows only topic tags actually emitted by the selected bank", () => {
    for (const subject of ["physics", "maths", "chemistry", "life", "history", "geography", "english", "gk"]) {
      const topics = topicsFor(subject, "wbbse", 10);
      assert.ok(topics.length > 0, `${subject} should expose at least one real topic`);
      for (const topic of topics) {
        assert.ok(topicQuestionCount("wbbse", subject, topic, 10) > 0);
        const q = getTopicQuestion("wbbse", subject, topic, 0, 10);
        assert.ok(q, `${subject}/${topic} should have a question`);
        assert.equal(q.topic, topic, `${subject}/${topic} must never cross into another topic`);
        const later = getTopicQuestion("wbbse", subject, topic, topicQuestionCount("wbbse", subject, topic, 10), 10);
        assert.ok(later, `${subject}/${topic} should continue after its first topic sequence`);
        assert.equal(later.topic, topic, `${subject}/${topic} must stay isolated in later cycles`);
      }
    }
  });

  it("continues topic sequences into later parameter ranges", () => {
    const subject = "physics";
    const topic = "Density";
    const count = topicQuestionCount("wbbse", subject, topic, 10);
    assert.ok(count > 0);
    const first = getTopicQuestion("wbbse", subject, topic, 0, 10)!;
    const nextCycle = getTopicQuestion("wbbse", subject, topic, count, 10)!;
    assert.equal(first.topic, topic);
    assert.equal(nextCycle.topic, topic);
    assert.notEqual(first.prompt, nextCycle.prompt);
  });

  it("continues the mixed challenge into a new subject sequence after each milestone", () => {
    const first = getQuestion("wbbse", "mixed", 0, 10);
    const nextCycle = getQuestion("wbbse", "mixed", BANK_SIZE, 10);
    assert.equal(first.options.length, 4);
    assert.equal(nextCycle.options.length, 4);
    assert.notEqual(`${first.prompt}|${first.options[first.answer]}`, `${nextCycle.prompt}|${nextCycle.options[nextCycle.answer]}`);
  });

  it("keeps MCQ structure valid well beyond the first 30,000-slot milestone", () => {
    for (const subject of ["maths", "physics", "chemistry", "life", "history", "geography", "english", "gk"]) {
      for (const index of [BANK_SIZE, BANK_SIZE * 2, BANK_SIZE * 10, BANK_SIZE * 33]) {
        const q = getQuestion("wbbse", subject, index, 10);
        assert.equal(q.options.length, 4, `${subject} at ${index}`);
        assert.equal(new Set(q.options.map((o) => o.toLowerCase())).size, 4, `${subject} at ${index}`);
        assert.ok(q.prompt.length > 8);
        assert.ok(q.explanation.length > 8);
      }
    }
  });
});
