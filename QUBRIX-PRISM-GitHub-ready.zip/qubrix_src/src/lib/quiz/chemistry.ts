import { buildMcq, frac, nearMiss, questionRng, type Question } from "./core.ts";

const FAMILIES = 6;

const COMPOUNDS: Array<{ name: string; formula: string; M: number; atoms: Record<string, number> }> = [
  { name: "water", formula: "H₂O", M: 18, atoms: { hydrogen: 2, oxygen: 1 } },
  { name: "carbon dioxide", formula: "CO₂", M: 44, atoms: { carbon: 1, oxygen: 2 } },
  { name: "oxygen gas", formula: "O₂", M: 32, atoms: { oxygen: 2 } },
  { name: "methane", formula: "CH₄", M: 16, atoms: { carbon: 1, hydrogen: 4 } },
  { name: "ammonia", formula: "NH₃", M: 17, atoms: { nitrogen: 1, hydrogen: 3 } },
  { name: "nitrogen gas", formula: "N₂", M: 28, atoms: { nitrogen: 2 } },
  { name: "sodium hydroxide", formula: "NaOH", M: 40, atoms: { sodium: 1, oxygen: 1, hydrogen: 1 } },
  { name: "calcium carbonate", formula: "CaCO₃", M: 100, atoms: { calcium: 1, carbon: 1, oxygen: 3 } },
  { name: "glucose", formula: "C₆H₁₂O₆", M: 180, atoms: { carbon: 6, hydrogen: 12, oxygen: 6 } },
  { name: "sulphuric acid", formula: "H₂SO₄", M: 98, atoms: { hydrogen: 2, sulphur: 1, oxygen: 4 } },
  { name: "calcium oxide", formula: "CaO", M: 56, atoms: { calcium: 1, oxygen: 1 } },
  { name: "hydrogen gas", formula: "H₂", M: 2, atoms: { hydrogen: 2 } },
];

const ELEMENTS: Array<{ z: number; name: string }> = [
  { z: 1, name: "hydrogen" },
  { z: 2, name: "helium" },
  { z: 3, name: "lithium" },
  { z: 4, name: "beryllium" },
  { z: 5, name: "boron" },
  { z: 6, name: "carbon" },
  { z: 7, name: "nitrogen" },
  { z: 8, name: "oxygen" },
  { z: 9, name: "fluorine" },
  { z: 10, name: "neon" },
  { z: 11, name: "sodium" },
  { z: 12, name: "magnesium" },
  { z: 13, name: "aluminium" },
  { z: 14, name: "silicon" },
  { z: 15, name: "phosphorus" },
  { z: 16, name: "sulphur" },
  { z: 17, name: "chlorine" },
  { z: 18, name: "argon" },
  { z: 19, name: "potassium" },
  { z: 20, name: "calcium" },
];

const METALS = [
  { name: "zinc", mass: 65, acid: 2, hydrogenMoles: 1 },
  { name: "magnesium", mass: 24, acid: 2, hydrogenMoles: 1 },
  { name: "iron", mass: 56, acid: 2, hydrogenMoles: 1 },
  { name: "calcium", mass: 40, acid: 2, hydrogenMoles: 1 },
  { name: "aluminium", mass: 27, acid: 6, hydrogenMoles: 3, formulaMoles: 2 },
];

function rngFor(board: string, index: number) {
  return questionRng(`chem|${board}|${index}`);
}

function shells(z: number): number[] {
  const caps = [2, 8, 8, 2];
  const out: number[] = [];
  let left = z;
  for (const cap of caps) {
    if (left <= 0) break;
    const take = Math.min(cap, left);
    out.push(take);
    left -= take;
  }
  return out;
}

function molesFamily(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 3;
  const n0 = Math.floor(local / 3);
  const compound = COMPOUNDS[n0 % COMPOUNDS.length]!;
  const moles = Math.floor(n0 / COMPOUNDS.length) + 1;
  const mass = moles * compound.M;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `mol-${index}`,
      topic: "Mole concept",
      prompt: `How many moles are there in ${mass} g of ${compound.name} (${compound.formula}, molar mass ${compound.M} g/mol)?`,
      correct: String(moles),
      distractors: nearMiss(moles, [mass, compound.M, 1]),
      explanation: `Moles = mass / molar mass = ${mass} / ${compound.M} = ${moles} mol.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id: `mol-${index}`,
      topic: "Mole concept",
      prompt: `What is the mass of ${moles} mol of ${compound.name} (${compound.formula})? Molar mass = ${compound.M} g/mol.`,
      correct: `${mass} g`,
      distractors: nearMiss(mass, [moles, compound.M, mass + compound.M]).map((s) => `${s} g`),
      explanation: `Mass = ${moles} × ${compound.M} = ${mass} g.`,
    });
  }
  return buildMcq(rng, {
    id: `mol-${index}`,
    topic: "Mole concept",
    prompt: `How many molecules are present in ${moles} mol of ${compound.name} (${compound.formula})? Give the answer in terms of Avogadro’s number Nₐ.`,
    correct: `${moles} Nₐ`,
    distractors: [`${moles + 1} Nₐ`, `${compound.M} Nₐ`, `${mass} Nₐ`, `Nₐ/${moles === 1 ? 2 : moles}`],
    explanation: `Particles = moles × Nₐ = ${moles} Nₐ. Nₐ is 6.022 × 10²³ mol⁻¹.`,
  });
}

function atoms(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 4;
  const n = Math.floor(local / 4);
  const el = ELEMENTS[n % ELEMENTS.length]!;
  const neutrons = Math.floor(n / ELEMENTS.length);
  const A = el.z + neutrons;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `atom-${index}`,
      topic: "Structure of the atom",
      prompt: `An atom of ${el.name} has atomic number ${el.z} and mass number ${A}. How many neutrons does it have?`,
      correct: String(neutrons),
      distractors: nearMiss(neutrons, [el.z, A, neutrons + el.z]),
      explanation: `Neutrons = A − Z = ${A} − ${el.z} = ${neutrons}.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id: `atom-${index}`,
      topic: "Structure of the atom",
      prompt: `How many protons are present in a neutral ${el.name} atom of mass number ${A}?`,
      correct: String(el.z),
      distractors: nearMiss(el.z, [neutrons, A, el.z + neutrons]),
      explanation: `Protons = atomic number = ${el.z}, whatever the mass number is.`,
    });
  }
  if (kind === 2) {
    return buildMcq(rng, {
      id: `atom-${index}`,
      topic: "Structure of the atom",
      prompt: `A neutral atom has Z = ${el.z} and A = ${A}. How many electrons does it have?`,
      correct: String(el.z),
      distractors: nearMiss(el.z, [neutrons, A, Math.max(0, el.z - 1)]),
      explanation: `In a neutral atom, electrons = protons = ${el.z}.`,
    });
  }
  const electrons = Math.max(0, el.z - 1);
  return buildMcq(rng, {
    id: `atom-${index}`,
    topic: "Structure of the atom",
    prompt: `A +1 ion is made from an atom with Z = ${el.z} and A = ${A}. How many electrons are in the ion?`,
    correct: String(electrons),
    distractors: nearMiss(electrons, [el.z, neutrons, el.z + 1, A]),
    explanation: `The neutral atom has ${el.z} electrons. A +1 ion has lost one, so ${electrons} remain.`,
  });
}

function inventory(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const compound = COMPOUNDS[local % COMPOUNDS.length]!;
  const keys = Object.keys(compound.atoms);
  const n = Math.floor(local / COMPOUNDS.length);
  const element = keys[n % keys.length]!;
  const moles = Math.floor(n / keys.length) + 1;
  const per = compound.atoms[element]!;
  const total = moles * per;
  return buildMcq(rng, {
    id: `inv-${index}`,
    topic: "Mole concept",
    prompt: `How many moles of ${element} atoms are there in ${moles} mol of ${compound.name} (${compound.formula})?`,
    correct: String(total),
    distractors: nearMiss(total, [moles, per, moles + per, total + 1]),
    explanation: `Each molecule of ${compound.formula} contains ${per} ${element} atom${per > 1 ? "s" : ""}. ${moles} mol therefore contains ${total} mol of ${element} atoms.`,
  });
}

function molarity(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const compound = COMPOUNDS[local % COMPOUNDS.length]!;
  const n = Math.floor(local / COMPOUNDS.length);
  const moles = (n % 15) + 1;
  const litres = Math.floor(n / 15) + 1;
  const mass = moles * compound.M;
  return buildMcq(rng, {
    id: `M-${index}`,
    topic: "Mole concept",
    prompt: `${mass} g of ${compound.name} (${compound.formula}, molar mass ${compound.M} g/mol) is dissolved to make ${litres} L of solution. What is the molarity?`,
    correct: `${frac(moles, litres)} mol/L`,
    distractors: [
      `${frac(mass, litres)} mol/L`,
      `${frac(moles, litres + 1)} mol/L`,
      `${moles + litres} mol/L`,
      `${frac(mass, compound.M + litres)} mol/L`,
      "0 mol/L",
    ],
    explanation: `Moles = ${mass} / ${compound.M} = ${moles}. Molarity = ${moles} / ${litres} = ${frac(moles, litres)} mol/L.`,
  });
}

function composition(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const rows = [
    { name: "calcium carbonate", formula: "CaCO₃", part: "calcium", mass: 40, total: 100 },
    { name: "calcium oxide", formula: "CaO", part: "calcium", mass: 40, total: 56 },
    { name: "methane", formula: "CH₄", part: "carbon", mass: 12, total: 16 },
    { name: "carbon dioxide", formula: "CO₂", part: "carbon", mass: 12, total: 44 },
    { name: "carbon dioxide", formula: "CO₂", part: "oxygen", mass: 32, total: 44 },
    { name: "water", formula: "H₂O", part: "oxygen", mass: 16, total: 18 },
    { name: "ammonia", formula: "NH₃", part: "nitrogen", mass: 14, total: 17 },
    { name: "sulphuric acid", formula: "H₂SO₄", part: "sulphur", mass: 32, total: 98 },
  ];
  const row = rows[local % rows.length]!;
  const scale = Math.floor(local / rows.length) + 1;
  const percent = frac(row.mass * 100, row.total);
  return buildMcq(rng, {
    id: `pct-${index}`,
    topic: "Mole concept",
    prompt: `A ${row.total * scale} g sample of ${row.name} (${row.formula}) contains ${row.mass * scale} g of ${row.part}. What is the percentage of ${row.part}?`,
    correct: `${percent}%`,
    distractors: [`${row.mass}%`, `${row.total}%`, `${scale}%`, `${frac(row.mass * scale, row.total)}%`, `${100 - Number(percent) || 50}%`],
    explanation: `Percentage = (${row.mass} / ${row.total}) × 100 = ${percent}%. Scaling the sample does not change the percentage.`,
  });
}

function hydrogen(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const metal = METALS[local % METALS.length]!;
  const k = Math.floor(local / METALS.length) + 1;
  const formulaMoles = "formulaMoles" in metal ? metal.formulaMoles! : 1;
  const metalMoles = formulaMoles * k;
  const h2Moles = metal.hydrogenMoles * k;
  const metalMass = metal.mass * metalMoles;
  const h2Mass = 2 * h2Moles;
  const kind = k % 2;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `h2-${index}`,
      topic: "Acids, bases and salts",
      prompt: `${metalMass} g of ${metal.name} reacts completely with dilute hydrochloric acid. How many grams of hydrogen are produced? (Molar mass of ${metal.name} = ${metal.mass} g/mol; H₂ = 2 g/mol.)`,
      correct: `${h2Mass} g`,
      distractors: nearMiss(h2Mass, [metalMass, h2Moles, metalMoles, 2]).map((s) => `${s} g`),
      explanation: `${metalMoles} mol of ${metal.name} liberates ${h2Moles} mol of H₂. Mass of H₂ = ${h2Moles} × 2 = ${h2Mass} g. The balanced acid coefficient used here is ${metal.acid}.`,
    });
  }
  return buildMcq(rng, {
    id: `h2-${index}`,
    topic: "Acids, bases and salts",
    prompt: `How many moles of hydrogen gas form when ${metalMoles} mol of ${metal.name} reacts completely with dilute HCl?`,
    correct: String(h2Moles),
    distractors: nearMiss(h2Moles, [metalMoles, metal.acid, h2Mass, 2]),
    explanation: `From the balanced equation, ${formulaMoles} mol of ${metal.name} produces ${metal.hydrogenMoles} mol of H₂. So ${metalMoles} mol produces ${h2Moles} mol of H₂.`,
  });
}

const FACTS: Array<{ topic: string; prompt: string; correct: string; distractors: string[]; explanation: string }> = [
  { topic: "Periodic table", prompt: "The modern periodic law arranges elements by", correct: "atomic number", distractors: ["atomic mass", "density", "valency alone"], explanation: "After Moseley, elements are arranged by increasing atomic number." },
  { topic: "Acids, bases and salts", prompt: "The pH of a neutral aqueous solution at 25°C is", correct: "7", distractors: ["0", "14", "1"], explanation: "Below 7 is acidic, above 7 is basic, and 7 is neutral." },
  { topic: "Acids, bases and salts", prompt: "Vinegar contains", correct: "acetic acid", distractors: ["hydrochloric acid", "sulphuric acid", "nitric acid"], explanation: "The acid in vinegar is ethanoic (acetic) acid." },
  { topic: "Acids, bases and salts", prompt: "Washing soda is chemically", correct: "sodium carbonate", distractors: ["sodium chloride", "sodium hydroxide", "baking soda"], explanation: "Washing soda is Na₂CO₃·10H₂O. Baking soda is sodium hydrogencarbonate." },
  { topic: "Acids, bases and salts", prompt: "Baking soda is", correct: "sodium hydrogencarbonate", distractors: ["sodium carbonate", "calcium oxide", "gypsum"], explanation: "Baking soda is NaHCO₃." },
  { topic: "Metals", prompt: "Which metal is kept under kerosene?", correct: "sodium", distractors: ["copper", "iron", "silver"], explanation: "Sodium reacts quickly with moisture and air, so it is stored under kerosene." },
  { topic: "Metals", prompt: "Bauxite is an ore of", correct: "aluminium", distractors: ["iron", "mercury", "copper"], explanation: "Bauxite is impure hydrated aluminium oxide." },
  { topic: "Metals", prompt: "Haematite is an ore of", correct: "iron", distractors: ["aluminium", "zinc", "gold"], explanation: "Haematite is Fe₂O₃." },
  { topic: "Metals", prompt: "Cinnabar is an ore of", correct: "mercury", distractors: ["iron", "tin", "lead"], explanation: "Cinnabar is HgS." },
  { topic: "Carbon", prompt: "The functional group of an alcohol is", correct: "–OH", distractors: ["–COOH", "–CHO", "–Cl"], explanation: "Alcohols have a hydroxyl group. Carboxylic acids have –COOH." },
  { topic: "Carbon", prompt: "The functional group of a carboxylic acid is", correct: "–COOH", distractors: ["–OH", "–CHO", "C=C"], explanation: "Carboxylic acids contain –COOH." },
  { topic: "Chemical reactions", prompt: "The gas that turns limewater milky is", correct: "carbon dioxide", distractors: ["oxygen", "hydrogen", "ammonia"], explanation: "Carbon dioxide forms insoluble calcium carbonate with limewater." },
  { topic: "Atoms", prompt: "Isotopes of an element have the same", correct: "atomic number", distractors: ["mass number", "neutron number", "mass"], explanation: "Isotopes differ in neutrons and mass number, not in proton number." },
  { topic: "Metals", prompt: "Rust is best described as", correct: "hydrated iron(III) oxide", distractors: ["iron sulphide", "pure iron", "copper oxide"], explanation: "Rust is Fe₂O₃·xH₂O, formed when iron is exposed to air and moisture." },
  { topic: "Acids, bases and salts", prompt: "Brine is an aqueous solution of", correct: "sodium chloride", distractors: ["sodium hydroxide", "calcium carbonate", "ethanol"], explanation: "Electrolysis of brine produces chlorine, hydrogen and sodium hydroxide." },
  { topic: "Periodic table", prompt: "A horizontal row in the periodic table is called a", correct: "period", distractors: ["group", "shell only", "triad"], explanation: "Periods are rows. Groups are columns." },
  { topic: "Periodic table", prompt: "A vertical column in the periodic table is called a", correct: "group", distractors: ["period", "orbit", "mole"], explanation: "Elements in a group have the same number of valence electrons." },
  { topic: "Metals", prompt: "Plaster of Paris is made by heating", correct: "gypsum", distractors: ["limestone", "bauxite", "common salt"], explanation: "Gypsum (CaSO₄·2H₂O) gives plaster of Paris (CaSO₄·½H₂O) on careful heating." },
  { topic: "Chemical reactions", prompt: "Copper does not liberate hydrogen from dilute hydrochloric acid because copper is", correct: "less reactive than hydrogen", distractors: ["more reactive than potassium", "a non-metal", "an acid"], explanation: "Metals below hydrogen in the reactivity series do not displace it from dilute acids." },
  { topic: "Atoms", prompt: "The maximum number of electrons in the K shell is", correct: "2", distractors: ["8", "18", "32"], explanation: "The first shell holds at most 2 electrons. The next two shells hold up to 8 in the Class 10 treatment of the first 20 elements." },
];

function factAt(board: string, index: number, n: number): Question {
  const rng = rngFor(board, index);
  const fact = FACTS[n]!;
  return buildMcq(rng, { id: `fact-${index}`, ...fact });
}

const FNS = [molesFamily, atoms, inventory, molarity, composition, hydrogen];

export function chemistryQuestion(board: string, index: number): Question {
  const i = Math.max(0, Math.floor(index));
  if (i % 1500 === 0) {
    const n = Math.floor(i / 1500) % FACTS.length;
    return factAt(board, i, n);
  }
  const family = i % FAMILIES;
  const local = Math.floor(i / FAMILIES);
  return FNS[family]!(board, i, local);
}

export function shellConfiguration(z: number): string {
  return shells(z).join(", ");
}
