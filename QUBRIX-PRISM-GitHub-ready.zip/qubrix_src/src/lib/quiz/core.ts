export const BANK_SIZE = 30000;

export type Question = {
  id: string;
  prompt: string;
  options: [string, string, string, string];
  answer: 0 | 1 | 2 | 3;
  explanation: string;
  topic: string;
};

export function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function questionRng(parts: string): () => number {
  return mulberry32(hashString(parts) || 1);
}

export function wrapIndex(index: number): number {
  return ((index % BANK_SIZE) + BANK_SIZE) % BANK_SIZE;
}

export function gcd(a: number, b: number): number {
  let x = Math.abs(Math.round(a));
  let y = Math.abs(Math.round(b));
  while (y) {
    const t = y;
    y = x % y;
    x = t;
  }
  return x || 1;
}

export function frac(n: number, d: number): string {
  if (d < 0) {
    n = -n;
    d = -d;
  }
  const g = gcd(n, d);
  n = Math.round(n / g);
  d = Math.round(d / g);
  if (d === 1) return String(n);
  return `${n}/${d}`;
}

const binomCache = new Map<string, number>();

export function binom(n: number, k: number): number {
  if (k < 0 || n < 0 || k > n) return 0;
  if (k === 0 || k === n) return 1;
  if (k > n - k) k = n - k;
  const key = `${n},${k}`;
  const hit = binomCache.get(key);
  if (hit !== undefined) return hit;
  let r = 1;
  for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i;
  r = Math.round(r);
  binomCache.set(key, r);
  return r;
}

/** k-combination in colex order. Values are ascending. */
export function combinadic(k: number, index: number): number[] {
  const combo: number[] = [];
  let remaining = index;
  for (let i = k; i >= 1; i--) {
    let c = i - 1;
    while (binom(c + 1, i) <= remaining) c++;
    combo.push(c);
    remaining -= binom(c, i);
  }
  return combo.reverse();
}

export function factorial(n: number): number {
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

export function shuffle<T>(rng: () => number, arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = a[i];
    a[i] = a[j]!;
    a[j] = tmp!;
  }
  return a;
}

function nudgeOption(correct: string, step: number): string | null {
  const plain = correct.match(/^(-?\d+)(.*)$/);
  if (plain) {
    const next = Number(plain[1]) + step;
    return `${next}${plain[2]}`;
  }
  const pi = correct.match(/^(₹)?(-?\d*)π(.*)$/);
  if (pi) {
    const raw = pi[2] ?? "";
    const coef = raw === "" || raw === "-" ? (raw === "-" ? -1 : 1) : Number(raw);
    if (!Number.isFinite(coef)) return null;
    const next = coef + step;
    const body = `${next === 1 ? "" : next === -1 ? "-" : String(next)}π${pi[3] ?? ""}`;
    return `${pi[1] ?? ""}${body}`;
  }
  return null;
}

function clean(s: string): string {
  return s.replace(/\s+/g, " ").trim();
}

export function buildMcq(
  rng: () => number,
  spec: {
    id: string;
    prompt: string;
    correct: string;
    distractors: string[];
    explanation: string;
    topic: string;
  },
): Question {
  const correct = clean(spec.correct);
  const distractors: string[] = [];
  const seen = new Set<string>([correct.toLowerCase()]);
  for (const raw of spec.distractors) {
    const d = clean(raw);
    if (!d || seen.has(d.toLowerCase())) continue;
    seen.add(d.toLowerCase());
    distractors.push(d);
    if (distractors.length === 3) break;
  }
  let n = 1;
  while (distractors.length < 3 && n < 12) {
    const nudged = nudgeOption(correct, n + 1);
    n++;
    if (!nudged || seen.has(nudged.toLowerCase())) continue;
    seen.add(nudged.toLowerCase());
    distractors.push(nudged);
  }
  if (distractors.length < 3) {
    throw new Error(`Not enough distractors for ${spec.id}: ${spec.prompt} [${correct}]`);
  }
  const paired = shuffle(rng, [
    { text: correct, ok: true as const },
    ...distractors.slice(0, 3).map((text) => ({ text, ok: false as const })),
  ]);
  const answer = paired.findIndex((p) => p.ok);
  if (answer < 0) throw new Error(`answer missing: ${spec.id}`);
  return {
    id: spec.id,
    prompt: clean(spec.prompt),
    options: paired.map((p) => p.text) as [string, string, string, string],
    answer: answer as 0 | 1 | 2 | 3,
    explanation: clean(spec.explanation),
    topic: spec.topic,
  };
}

export function nearMiss(correct: number, extras: number[] = []): string[] {
  const cands = [
    correct + 1,
    correct - 1,
    correct + 2,
    correct - 2,
    correct + 10,
    correct * 2,
    correct + 5,
    Math.abs(correct) === correct ? correct + 3 : -correct,
    ...extras,
  ];
  const out: string[] = [];
  const seen = new Set<string>([String(correct)]);
  for (const c of cands) {
    if (!Number.isFinite(c)) continue;
    const s = String(Math.round(c));
    if (seen.has(s)) continue;
    seen.add(s);
    out.push(s);
  }
  return out;
}

export function withUnit(n: number | string, unit: string): string {
  return `${n} ${unit}`;
}

export function unitMiss(correct: number, unit: string, extras: number[] = []): string[] {
  return nearMiss(correct, extras).map((s) => withUnit(s, unit));
}

/** Mixed radix. Product of radices should exceed every local you pass. */
export function digits(local: number, radices: number[]): number[] {
  const out: number[] = [];
  let x = local;
  for (const r of radices) {
    if (r <= 0) throw new Error("radix");
    out.push(x % r);
    x = Math.floor(x / r);
  }
  return out;
}

export function pairAt(span: number, index: number): [number, number] {
  let left = index;
  for (let p = 0; p < span; p++) {
    const count = span - p;
    if (left < count) return [p, p + left];
    left -= count;
  }
  throw new Error(`pairAt out of range ${index}`);
}

export function pickFromPools<T>(
  correctPool: readonly T[],
  wrongPool: readonly T[],
  local: number,
): { right: T; wrongs: [T, T, T]; span: number } {
  if (correctPool.length < 1 || wrongPool.length < 3) {
    throw new Error("pools too small");
  }
  const ways = binom(wrongPool.length, 3);
  const span = correctPool.length * ways;
  const m = local % span;
  const ci = m % correctPool.length;
  const wi = Math.floor(m / correctPool.length) % ways;
  const idxs = combinadic(3, wi);
  const wrongs = idxs.map((i) => wrongPool[i]!) as [T, T, T];
  return { right: correctPool[ci]!, wrongs, span };
}

export function scene(board: string, options: string[]): string {
  return options[hashString(board) % options.length]!;
}

export function fallbackQuestion(subject: string, index: number): Question {
  const a = (index % 50) + 2;
  const b = ((index * 7) % 40) + 3;
  const sum = a + b;
  const rng = questionRng(`fallback|${subject}|${index}`);
  return buildMcq(rng, {
    id: `fallback-${subject}-${index}`,
    topic: "Recovery",
    prompt: `What is ${a} + ${b}?`,
    correct: String(sum),
    distractors: nearMiss(sum),
    explanation: `${a} + ${b} = ${sum}.`,
  });
}
