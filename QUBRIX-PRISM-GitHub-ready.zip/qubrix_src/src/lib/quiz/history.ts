import {
  binom,
  buildMcq,
  combinadic,
  nearMiss,
  pickFromPools,
  questionRng,
  type Question,
} from "./core.ts";

type Event = {
  year: number;
  title: string;
  place: string;
  gandhi: boolean;
  note: string;
};

const EVENTS: Event[] = [
  { year: 1789, title: "Outbreak of the French Revolution", place: "Paris", gandhi: false, note: "The storming of the Bastille became the symbol of the revolution." },
  { year: 1804, title: "Napoleonic Code issued", place: "France", gandhi: false, note: "The civil code spread ideas of equality before the law, while removing rights Napoleon did not support." },
  { year: 1815, title: "Congress of Vienna", place: "Vienna", gandhi: false, note: "After Napoleon, conservative powers redrew Europe." },
  { year: 1821, title: "Start of the Greek struggle for independence", place: "Greece", gandhi: false, note: "Greek nationalists fought the Ottoman Empire." },
  { year: 1830, title: "July Revolution in France", place: "Paris", gandhi: false, note: "Charles X was overthrown and Louis Philippe became king." },
  { year: 1848, title: "Revolutions across Europe", place: "Europe", gandhi: false, note: "Liberals and nationalists rose in France, the German states, the Italian states and the Austrian empire." },
  { year: 1857, title: "The revolt of 1857", place: "Meerut", gandhi: false, note: "The uprising began at Meerut and spread across northern India. Bahadur Shah Zafar was declared the symbolic leader." },
  { year: 1858, title: "British Crown takes over India", place: "London", gandhi: false, note: "After the revolt, the East India Company’s rule ended and the Crown took charge." },
  { year: 1861, title: "Kingdom of Italy proclaimed", place: "Italy", gandhi: false, note: "Victor Emmanuel II became king. Cavour, Mazzini and Garibaldi had pushed the unification in different ways." },
  { year: 1871, title: "German Empire proclaimed", place: "Versailles", gandhi: false, note: "Prussia under Bismarck led the unification. The empire was proclaimed in the Hall of Mirrors." },
  { year: 1878, title: "Vernacular Press Act", place: "India", gandhi: false, note: "Lytton’s act tried to silence criticism in the Indian-language press." },
  { year: 1885, title: "Indian National Congress founded", place: "Bombay", gandhi: false, note: "A. O. Hume was a key organiser of the first session." },
  { year: 1905, title: "Partition of Bengal", place: "Bengal", gandhi: false, note: "Lord Curzon’s partition set off the Swadeshi movement." },
  { year: 1906, title: "All-India Muslim League founded", place: "Dhaka", gandhi: false, note: "The League was formed during the politics that followed the partition of Bengal." },
  { year: 1907, title: "Surat split in the Congress", place: "Surat", gandhi: false, note: "Moderates and Extremists split at the Surat session." },
  { year: 1909, title: "Morley-Minto reforms", place: "India", gandhi: false, note: "The Indian Councils Act of 1909 enlarged the councils and introduced separate electorates." },
  { year: 1913, title: "Ghadar Party founded", place: "San Francisco", gandhi: false, note: "Indian expatriates organised the Ghadar movement against British rule." },
  { year: 1914, title: "First World War begins", place: "Europe", gandhi: false, note: "The war redrew empires and sharpened colonial demands." },
  { year: 1915, title: "Gandhi returns to India", place: "India", gandhi: true, note: "Gandhi returned from South Africa and soon began local satyagrahas." },
  { year: 1916, title: "Lucknow Pact", place: "Lucknow", gandhi: false, note: "Congress and the Muslim League agreed on a joint constitutional scheme." },
  { year: 1917, title: "Champaran satyagraha", place: "Champaran", gandhi: true, note: "Gandhi took up the cause of indigo peasants in Bihar." },
  { year: 1918, title: "Ahmedabad mill strike", place: "Ahmedabad", gandhi: true, note: "Gandhi supported the textile workers in a dispute over wages." },
  { year: 1919, title: "Jallianwala Bagh massacre", place: "Amritsar", gandhi: false, note: "On 13 April 1919 General Dyer ordered troops to fire on an unarmed crowd. The Rowlatt Act had been passed the same year." },
  { year: 1920, title: "Non-Cooperation Movement launched", place: "India", gandhi: true, note: "Gandhi linked non-cooperation with the Khilafat demand." },
  { year: 1921, title: "Malabar rebellion", place: "Malabar", gandhi: false, note: "The Moplah uprising in Malabar shook the Madras presidency." },
  { year: 1922, title: "Chauri Chaura and withdrawal of Non-Cooperation", place: "Chauri Chaura", gandhi: true, note: "After protesters killed policemen, Gandhi called off the movement." },
  { year: 1923, title: "Swaraj Party formed", place: "India", gandhi: false, note: "C. R. Das and Motilal Nehru wanted to enter the councils." },
  { year: 1928, title: "Boycott of the Simon Commission", place: "India", gandhi: false, note: "The all-white commission was met with the slogan “Simon Go Back”." },
  { year: 1929, title: "Lahore Congress and Purna Swaraj", place: "Lahore", gandhi: false, note: "Under Jawaharlal Nehru as president, Congress declared complete independence. 26 January 1930 was celebrated as Independence Day." },
  { year: 1930, title: "Dandi March", place: "Dandi", gandhi: true, note: "Gandhi walked from Sabarmati to Dandi and broke the salt law, opening the Civil Disobedience Movement." },
  { year: 1931, title: "Gandhi-Irwin Pact", place: "Delhi", gandhi: true, note: "Civil disobedience was suspended and Gandhi agreed to attend the Second Round Table Conference." },
  { year: 1932, title: "Poona Pact", place: "Poona", gandhi: true, note: "Gandhi and B. R. Ambedkar agreed on reserved seats instead of separate electorates for the Depressed Classes." },
  { year: 1935, title: "Government of India Act", place: "London", gandhi: false, note: "The Act offered provincial autonomy and a federal scheme that was only partly used." },
  { year: 1939, title: "Congress ministries resign", place: "India", gandhi: false, note: "Congress ministries quit after the British declared India at war without consultation." },
  { year: 1940, title: "Lahore Resolution of the Muslim League", place: "Lahore", gandhi: false, note: "The League demanded separate states in the Muslim-majority areas. It is often called the Pakistan Resolution." },
  { year: 1942, title: "Quit India Movement", place: "Bombay", gandhi: true, note: "On 8 August 1942 Gandhi gave the call “Do or Die”." },
  { year: 1943, title: "Bengal famine", place: "Bengal", gandhi: false, note: "Wartime policies and hoarding turned a shortage into a catastrophic famine." },
  { year: 1945, title: "Second World War ends", place: "the world", gandhi: false, note: "The end of the war made British withdrawal from India a matter of time." },
  { year: 1946, title: "Cabinet Mission to India", place: "India", gandhi: false, note: "The mission proposed a federal plan. The same year saw the Royal Indian Navy mutiny." },
  { year: 1947, title: "Independence and Partition", place: "India", gandhi: false, note: "India and Pakistan became independent on 15 August 1947. Mountbatten was the last Viceroy." },
  { year: 1950, title: "Constitution of India comes into force", place: "New Delhi", gandhi: false, note: "India became a republic on 26 January 1950. B. R. Ambedkar had chaired the Drafting Committee." },
];

function rngFor(board: string, index: number) {
  return questionRng(`hist|${board}|${index}`);
}

function whichFirst(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const ways = binom(EVENTS.length, 4);
  const idxs = combinadic(4, local % ways);
  const chosen = idxs.map((i) => EVENTS[i]!);
  const earliest = chosen.reduce((a, b) => (a.year < b.year ? a : b));
  return buildMcq(rng, {
    id: `first-${index}`,
    topic: "Timeline",
    prompt: "Which of these happened first?",
    correct: earliest.title,
    distractors: chosen.filter((e) => e !== earliest).map((e) => e.title),
    explanation: `${earliest.title} was in ${earliest.year}, at ${earliest.place}. ${earliest.note}`,
  });
}

function yearOf(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const event = EVENTS[local % EVENTS.length]!;
  const pool = EVENTS.filter((e) => e.year !== event.year).map((e) => String(e.year));
  const uniqueYears = [...new Set(pool)];
  const ways = binom(uniqueYears.length, 3);
  const wi = Math.floor(local / EVENTS.length) % ways;
  const distractors = combinadic(3, wi).map((i) => uniqueYears[i]!);
  return buildMcq(rng, {
    id: `year-${index}`,
    topic: "Timeline",
    prompt: `In which year did this happen: ${event.title}?`,
    correct: String(event.year),
    distractors,
    explanation: `${event.title} took place in ${event.year} (${event.place}). ${event.note}`,
  });
}

function placeOf(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const event = EVENTS[local % EVENTS.length]!;
  const places = [...new Set(EVENTS.map((e) => e.place))].filter((p) => p !== event.place);
  const ways = binom(places.length, 3);
  const wi = Math.floor(local / EVENTS.length) % ways;
  return buildMcq(rng, {
    id: `place-${index}`,
    topic: "Timeline",
    prompt: `Where is ${event.title} (${event.year}) chiefly associated?`,
    correct: event.place,
    distractors: combinadic(3, wi).map((i) => places[i]!),
    explanation: `${event.note}`,
  });
}

function gandhiQuestion(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const yes = EVENTS.filter((e) => e.gandhi);
  const no = EVENTS.filter((e) => !e.gandhi);
  const picked = pickFromPools(yes, no, local);
  return buildMcq(rng, {
    id: `gan-${index}`,
    topic: "National movement",
    prompt: "Which of these is directly associated with Mahatma Gandhi?",
    correct: picked.right.title,
    distractors: picked.wrongs.map((e) => e.title),
    explanation: `${picked.right.title} (${picked.right.year}) involved Gandhi. ${picked.right.note}`,
  });
}

function gapQuestion(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const ways = binom(EVENTS.length, 2);
  const [i, j] = combinadic(2, local % ways);
  const a = EVENTS[i]!;
  const b = EVENTS[j]!;
  const gap = Math.abs(a.year - b.year);
  const earlier = a.year < b.year ? a : b;
  const later = a.year < b.year ? b : a;
  return buildMcq(rng, {
    id: `gap-${index}`,
    topic: "Timeline",
    prompt: `How many years separate “${earlier.title}” (${earlier.year}) and “${later.title}” (${later.year})?`,
    correct: String(gap),
    distractors: nearMiss(gap, [later.year, earlier.year, gap + 10, Math.abs(gap - 7)]),
    explanation: `${later.year} − ${earlier.year} = ${gap} years.`,
  });
}

export function historyQuestion(board: string, index: number): Question {
  const i = Math.max(0, Math.floor(index));
  const family = i % 5;
  const local = Math.floor(i / 5);
  if (family === 0) return whichFirst(board, i, local);
  if (family === 1) return yearOf(board, i, local);
  if (family === 2) return placeOf(board, i, local);
  if (family === 3) return gandhiQuestion(board, i, local);
  return gapQuestion(board, i, local);
}

export { EVENTS };
