import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { curriculumFor, curriculumTopicStatus, WBBSE_CLASS_10_2026_27 } from "./curriculum.ts";

describe("WBBSE Class 10 curriculum map", () => {
  it("is scoped only to WBBSE Class 10", () => {
    assert.equal(curriculumFor("cbse", 10).length, 0);
    assert.equal(curriculumFor("wbbse", 9).length, 0);
    assert.equal(curriculumFor("wbbse", 10).length, WBBSE_CLASS_10_2026_27.length);
  });
  it("has stable unique subject and topic identifiers", () => {
    const subjectIds = WBBSE_CLASS_10_2026_27.map((s) => s.id);
    assert.equal(new Set(subjectIds).size, subjectIds.length);
    for (const subject of WBBSE_CLASS_10_2026_27) {
      const ids = subject.topics.map((t) => t.id);
      assert.equal(new Set(ids).size, ids.length, subject.id);
      for (const t of subject.topics) {
        assert.ok(t.title.trim().length > 0);
        assert.ok(t.syllabusLabel.trim().length > 0);
        assert.equal(t.contentStatus === "seeded-needs-review", t.generatorTags.length > 0);
      }
    }
  });
  it("does not claim pending chapters are quiz-ready", () => {
    assert.equal(curriculumTopicStatus("wbbse", 10, "history", "history-syllabus-pending"), "content-needed");
  });
});
