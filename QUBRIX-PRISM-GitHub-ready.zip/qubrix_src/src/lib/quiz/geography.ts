import {
  binom,
  buildMcq,
  combinadic,
  pickFromPools,
  questionRng,
  type Question,
} from "./core.ts";

type River = {
  name: string;
  system: "himalayan" | "peninsular";
  sea: "Bay of Bengal" | "Arabian Sea";
  note: string;
};

const RIVERS: River[] = [
  { name: "Ganga", system: "himalayan", sea: "Bay of Bengal", note: "The Ganga rises at the Gangotri glacier and drains into the Bay of Bengal." },
  { name: "Yamuna", system: "himalayan", sea: "Bay of Bengal", note: "The Yamuna rises at Yamunotri and joins the Ganga, so its water reaches the Bay of Bengal." },
  { name: "Brahmaputra", system: "himalayan", sea: "Bay of Bengal", note: "The Brahmaputra rises in Tibet, where it is called the Tsangpo, and enters the Bay of Bengal." },
  { name: "Indus", system: "himalayan", sea: "Arabian Sea", note: "The Indus rises in Tibet and empties into the Arabian Sea." },
  { name: "Sutlej", system: "himalayan", sea: "Arabian Sea", note: "The Sutlej is part of the Indus system and its water reaches the Arabian Sea." },
  { name: "Ghaghara", system: "himalayan", sea: "Bay of Bengal", note: "The Ghaghara is a Himalayan tributary of the Ganga." },
  { name: "Kosi", system: "himalayan", sea: "Bay of Bengal", note: "The Kosi rises in the Himalayas and joins the Ganga." },
  { name: "Gandak", system: "himalayan", sea: "Bay of Bengal", note: "The Gandak is a Himalayan tributary of the Ganga." },
  { name: "Narmada", system: "peninsular", sea: "Arabian Sea", note: "The Narmada rises at Amarkantak and flows west into the Arabian Sea." },
  { name: "Tapi", system: "peninsular", sea: "Arabian Sea", note: "The Tapi flows west, parallel to the Narmada, into the Arabian Sea." },
  { name: "Godavari", system: "peninsular", sea: "Bay of Bengal", note: "The Godavari is the longest peninsular river and drains east into the Bay of Bengal." },
  { name: "Krishna", system: "peninsular", sea: "Bay of Bengal", note: "The Krishna flows east across the Deccan into the Bay of Bengal." },
  { name: "Kaveri", system: "peninsular", sea: "Bay of Bengal", note: "The Kaveri rises in the Western Ghats and reaches the Bay of Bengal." },
  { name: "Mahanadi", system: "peninsular", sea: "Bay of Bengal", note: "The Mahanadi drains part of Chhattisgarh and Odisha into the Bay of Bengal." },
];

const CROPS = {
  rabi: ["wheat", "gram", "mustard", "barley", "pea"],
  kharif: ["rice", "maize", "cotton", "jute", "groundnut", "bajra", "soyabean", "tur"],
};

const TROPIC = [
  "Gujarat",
  "Rajasthan",
  "Madhya Pradesh",
  "Chhattisgarh",
  "Jharkhand",
  "West Bengal",
  "Tripura",
  "Mizoram",
];

const NOT_TROPIC = [
  "Kerala",
  "Punjab",
  "Tamil Nadu",
  "Bihar",
  "Assam",
  "Goa",
  "Haryana",
  "Himachal Pradesh",
  "Karnataka",
  "Odisha",
  "Sikkim",
  "Uttarakhand",
];

const RENEWABLE = ["solar energy", "wind energy", "tidal energy", "hydel power", "geothermal energy", "biomass"];
const NON_RENEWABLE = ["coal", "petroleum", "natural gas"];

const MINERALS: Array<{ site: string; state: string; mineral: string }> = [
  { site: "Jharia", state: "Jharkhand", mineral: "coal" },
  { site: "Raniganj", state: "West Bengal", mineral: "coal" },
  { site: "Bokaro", state: "Jharkhand", mineral: "coal" },
  { site: "Bailadila", state: "Chhattisgarh", mineral: "iron ore" },
  { site: "Mayurbhanj", state: "Odisha", mineral: "iron ore" },
  { site: "Singhbhum", state: "Jharkhand", mineral: "iron ore" },
  { site: "Digboi", state: "Assam", mineral: "petroleum" },
  { site: "Mumbai High", state: "offshore Maharashtra", mineral: "petroleum" },
  { site: "Ankleshwar", state: "Gujarat", mineral: "petroleum" },
];

const FACTS: Array<{ topic: string; prompt: string; correct: string; distractors: string[]; explanation: string }> = [
  { topic: "Soils", prompt: "Black soil is also called", correct: "regur", distractors: ["alluvium", "laterite", "loess"], explanation: "Regur, or black cotton soil, is typical of the Deccan and holds moisture well." },
  { topic: "Soils", prompt: "Which soil is best known for cotton cultivation?", correct: "black soil", distractors: ["laterite soil", "arid soil", "forest soil"], explanation: "Cotton grows well on the moisture-retentive black soil of the Deccan." },
  { topic: "Soils", prompt: "Alluvial soil is most widespread in", correct: "the northern plains", distractors: ["the Thar desert only", "the Western Ghats crest", "Ladakh"], explanation: "Rivers such as the Ganga and the Brahmaputra have laid down deep alluvium in the northern plains." },
  { topic: "Soils", prompt: "Laterite soil forms where", correct: "heavy rain leaches the soil", distractors: ["rainfall is almost absent", "only wheat is grown", "the land is permanently frozen"], explanation: "Intense leaching in wet regions leaves a soil rich in iron and aluminium." },
  { topic: "Agriculture", prompt: "The ‘golden fibre’ is", correct: "jute", distractors: ["cotton", "silk", "wool"], explanation: "Jute is called the golden fibre. West Bengal is a leading producer." },
  { topic: "Agriculture", prompt: "Coffee in India is grown mainly in", correct: "Karnataka", distractors: ["Punjab", "Rajasthan", "Haryana"], explanation: "Karnataka, especially the hills of the south, leads Indian coffee production. Kerala and Tamil Nadu also grow it." },
  { topic: "Agriculture", prompt: "Tea is a major plantation crop of", correct: "Assam", distractors: ["Rajasthan", "Punjab", "Gujarat"], explanation: "Assam and the Darjeeling hills of West Bengal are classic Indian tea regions." },
  { topic: "West Bengal", prompt: "The Sundarbans are famous for", correct: "mangrove forests", distractors: ["alpine meadows", "coral atolls", "black-soil cotton"], explanation: "The Sundarbans delta has the largest mangrove forest, and the Royal Bengal tiger lives there." },
  { topic: "Resources", prompt: "Mumbai High is associated with", correct: "petroleum", distractors: ["bauxite", "mica", "tea"], explanation: "Mumbai High is an offshore oilfield in the Arabian Sea." },
  { topic: "Resources", prompt: "The oldest oilfield among these is", correct: "Digboi", distractors: ["Bailadila", "Jharia", "Raniganj"], explanation: "Digboi in Assam is one of the oldest oil-producing centres in India. Jharia and Raniganj are coalfields. Bailadila is iron ore." },
];

function rngFor(board: string, index: number) {
  return questionRng(`geo|${board}|${index}`);
}

function riverSystem(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const wantPen = local % 2 === 0;
  const sub = Math.floor(local / 2);
  const pen = RIVERS.filter((r) => r.system === "peninsular");
  const him = RIVERS.filter((r) => r.system === "himalayan");
  const picked = wantPen ? pickFromPools(pen, him, sub) : pickFromPools(him, pen, sub);
  const label = wantPen ? "peninsular" : "Himalayan";
  return buildMcq(rng, {
    id: `riv-${index}`,
    topic: "Rivers",
    prompt: [
      `Which of these is a ${label} river?`,
      `Select the river that belongs to the ${label} river system.`,
      `A geography student is classifying rivers. Which option is ${label}?`,
      `Which river should be placed in the ${label} category?`,
    ][Math.floor(local / 2) % 4]!,
    correct: picked.right.name,
    distractors: picked.wrongs.map((r) => r.name),
    explanation: picked.right.note,
  });
}

function riverSea(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const wantArabian = local % 2 === 0;
  const sub = Math.floor(local / 2);
  const arab = RIVERS.filter((r) => r.sea === "Arabian Sea");
  const bay = RIVERS.filter((r) => r.sea === "Bay of Bengal");
  const picked = wantArabian ? pickFromPools(arab, bay, sub) : pickFromPools(bay, arab, sub);
  const sea = wantArabian ? "the Arabian Sea" : "the Bay of Bengal";
  return buildMcq(rng, {
    id: `sea-${index}`,
    topic: "Rivers",
    prompt: [
      `Which of these rivers drains into ${sea}?`,
      `Choose the river whose mouth is in ${sea}.`,
      `Which river carries its water towards ${sea}?`,
      `A river flowing into ${sea} is`,
    ][Math.floor(local / 2) % 4]!,
    correct: picked.right.name,
    distractors: picked.wrongs.map((r) => r.name),
    explanation: picked.right.note,
  });
}

function crops(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const wantRabi = local % 2 === 0;
  const sub = Math.floor(local / 2);
  const rabi = CROPS.rabi.map((name) => ({ name }));
  const kharif = CROPS.kharif.map((name) => ({ name }));
  const picked = wantRabi ? pickFromPools(rabi, kharif, sub) : pickFromPools(kharif, rabi, sub);
  const season = wantRabi ? "rabi" : "kharif";
  return buildMcq(rng, {
    id: `crop-${index}`,
    topic: "Agriculture",
    prompt: [
      `Which of these is a ${season} crop?`,
      `Which crop is normally grown in the ${season} season?`,
      `Select the crop classified as ${season} in Indian agriculture.`,
      `A farmer is choosing a ${season} crop. Which option fits?`,
    ][Math.floor(local / 2) % 4]!,
    correct: picked.right.name,
    distractors: picked.wrongs.map((c) => c.name),
    explanation: wantRabi
      ? `${picked.right.name} is a rabi crop, sown in winter and harvested in summer. Rice, maize, cotton and jute are kharif crops.`
      : `${picked.right.name} is a kharif crop, sown with the monsoon. Wheat, gram and mustard are rabi crops.`,
  });
}

function tropic(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const inside = TROPIC.map((name) => ({ name }));
  const outside = NOT_TROPIC.map((name) => ({ name }));
  const picked = pickFromPools(outside, inside, local);
  return buildMcq(rng, {
    id: `trop-${index}`,
    topic: "India",
    prompt: [
      "The Tropic of Cancer does not pass through which of these states?",
      "Which state is outside the route of the Tropic of Cancer?",
      "Identify the Indian state not crossed by the Tropic of Cancer.",
      "The Tropic of Cancer crosses all these states except",
    ][Math.floor(local / 4) % 4]!,
    correct: picked.right.name,
    distractors: picked.wrongs.map((s) => s.name),
    explanation: `The Tropic of Cancer passes through Gujarat, Rajasthan, Madhya Pradesh, Chhattisgarh, Jharkhand, West Bengal, Tripura and Mizoram. It does not pass through ${picked.right.name}.`,
  });
}

function resources(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const wantRenew = local % 2 === 0;
  const sub = Math.floor(local / 2);
  const ren = RENEWABLE.map((name) => ({ name }));
  const non = NON_RENEWABLE.map((name) => ({ name }));
  const picked = wantRenew ? pickFromPools(ren, non, sub) : pickFromPools(non, ren, sub);
  return buildMcq(rng, {
    id: `res-${index}`,
    topic: "Resources",
    prompt: wantRenew
      ? [
          "Which of these is a renewable source of energy?",
          "Which resource can be replenished on a human timescale?",
          "Choose the renewable energy source.",
          "Which option is an example of renewable energy?",
        ][Math.floor(local / 2) % 4]!
      : [
          "Which of these is a non-renewable resource?",
          "Which resource cannot be replenished on a human timescale?",
          "Choose the non-renewable energy resource.",
          "Which option is a finite fossil resource?",
        ][Math.floor(local / 2) % 4]!,
    correct: picked.right.name,
    distractors: picked.wrongs.map((r) => r.name),
    explanation: wantRenew
      ? `${picked.right.name} can be used without being used up in the way coal, petroleum and natural gas are.`
      : `${picked.right.name} formed over geological time and is not replaced on a human timescale. Solar, wind and hydel power are renewable.`,
  });
}

function mineralSite(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const site = MINERALS[local % MINERALS.length]!;
  const pool = [...new Set(MINERALS.map((m) => m.state))].filter((s) => s !== site.state);
  const ways = binom(pool.length, 3);
  const wi = Math.floor(local / MINERALS.length) % ways;
  return buildMcq(rng, {
    id: `min-${index}`,
    topic: "Minerals",
    prompt: `The ${site.mineral} centre ${site.site} is in`,
    correct: site.state,
    distractors: combinadic(3, wi).map((i) => pool[i]!),
    explanation: `${site.site} is known for ${site.mineral} and is located in ${site.state}.`,
  });
}

export function geographyQuestion(board: string, index: number): Question {
  const i = Math.max(0, Math.floor(index));
  const family = i % 6;
  const local = Math.floor(i / 6);
  if (family === 5 && local % 2 === 0) {
    const fact = FACTS[Math.floor(local / 2) % FACTS.length]!;
    const variant = Math.floor(local / (2 * FACTS.length));
    return buildMcq(rngFor(board, i), {
      id: `gf-${i}`,
      ...fact,
      prompt: variant === 0 ? fact.prompt : `Geography check ${variant + 1}: ${fact.prompt}`,
    });
  }
  if (family === 0) return riverSystem(board, i, local);
  if (family === 1) return riverSea(board, i, local);
  if (family === 2) return crops(board, i, local);
  if (family === 3) return tropic(board, i, local);
  if (family === 4) return resources(board, i, local);
  return mineralSite(board, i, local);
}
