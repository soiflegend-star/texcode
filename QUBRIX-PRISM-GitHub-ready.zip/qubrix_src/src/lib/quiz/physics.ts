import {
  buildMcq,
  frac,
  nearMiss,
  questionRng,
  scene,
  type Question,
  unitMiss,
  withUnit,
} from "./core.ts";

const FAMILIES = 10;

function rngFor(board: string, index: number) {
  return questionRng(`physics|${board}|${index}`);
}

function vehicle(board: string): string {
  return scene(board, ["car", "bus", "trolley", "truck", "scooter"]);
}

function kinematics(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 4;
  const n = Math.floor(local / 4);
  const u = n % 20;
  const a = (Math.floor(n / 20) % 8) + 1;
  const t = (Math.floor(n / 160) % 5) + 1;
  const who = vehicle(board);
  const v = u + a * t;
  const sNum = 2 * u * t + a * t * t;
  const s = sNum % 2 === 0 ? String(sNum / 2) : `${sNum}/2`;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `kin-${index}`,
      topic: "Motion",
      prompt: `A ${who} starts at ${u} m/s and accelerates at ${a} m/s² for ${t} s. What is its speed then?`,
      correct: withUnit(v, "m/s"),
      distractors: unitMiss(v, "m/s", [u, u + a, v + t]),
      explanation: `v = u + at = ${u} + ${a}×${t} = ${v} m/s.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id: `kin-${index}`,
      topic: "Motion",
      prompt: `A ${who} has initial speed ${u} m/s and acceleration ${a} m/s². How far does it travel in ${t} s?`,
      correct: `${s} m`,
      distractors: [`${v} m`, `${u * t} m`, `${a * t * t} m`, `${sNum} m`].filter((d) => d !== `${s} m`),
      explanation: `s = ut + ½at² = ${u}×${t} + ½×${a}×${t}² = ${s} m.`,
    });
  }
  if (kind === 2) {
    return buildMcq(rng, {
      id: `kin-${index}`,
      topic: "Motion",
      prompt: `A ${who} speeds up from ${u} m/s to ${v} m/s in ${t} s. What is its acceleration?`,
      correct: withUnit(a, "m/s²"),
      distractors: unitMiss(a, "m/s²", [v, t, u]),
      explanation: `a = (v − u)/t = (${v} − ${u})/${t} = ${a} m/s².`,
    });
  }
  return buildMcq(rng, {
    id: `kin-${index}`,
    topic: "Motion",
    prompt: `Moving at ${v} m/s after accelerating at ${a} m/s² for ${t} s, what was the initial speed of the ${who}?`,
    correct: withUnit(u, "m/s"),
    distractors: unitMiss(u, "m/s", [v, a, t]),
    explanation: `u = v − at = ${v} − ${a}×${t} = ${u} m/s.`,
  });
}

function force(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 4;
  const n = Math.floor(local / 4);
  const m = (n % 25) + 1;
  const a = (Math.floor(n / 25) % 12) + 1;
  const t = Math.floor(n / 300) + 1;
  const F = m * a;
  const W = m * 10;
  const p = m * a;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `force-${index}`,
      topic: "Force",
      prompt: `A body of mass ${m} kg accelerates at ${a} m/s² for ${t} s. The force acting on it is`,
      correct: `${F} N`,
      distractors: [`${W} N`, `${m + a} N`, `${F + t + 1} N`, `${a} N`, `${F * 10} N`],
      explanation: `F = ma = ${m} × ${a} = ${F} N. Take the duration as how long the force acts; it does not change F = ma. g is not used.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id: `force-${index}`,
      topic: "Gravitation",
      prompt: `Take g = 10 m/s². The weight of a ${m} kg bag (it can accelerate at ${a} m/s² in another experiment lasting ${t} s) on Earth is`,
      correct: `${W} N`,
      distractors: [`${F} N`, `${m} N`, `${W + a} N`, `${m * a} kg`],
      explanation: `Weight = mg = ${m} × 10 = ${W} N. The other figures are not part of the weight.`,
    });
  }
  if (kind === 2) {
    return buildMcq(rng, {
      id: `force-${index}`,
      topic: "Force",
      prompt: `A body of mass ${m} kg is observed for ${t} s while it moves at a steady ${a} m/s. Its momentum is`,
      correct: `${p} kg m/s`,
      distractors: [`${m + a} kg m/s`, `${m * 10} kg m/s`, `${a} kg m/s`, `${p + t} kg m/s`],
      explanation: `Momentum p = mv = ${m} × ${a} = ${p} kg m/s. A steady speed means the time of observation does not change the momentum.`,
    });
  }
  const impulse = F * t;
  return buildMcq(rng, {
    id: `force-${index}`,
    topic: "Force",
    prompt: `A force of ${F} N acts for ${t} s on a ${m} kg body that was able to accelerate at ${a} m/s². The impulse is`,
    correct: `${impulse} N s`,
    distractors: nearMiss(impulse, [F, t, m]).map((s) => `${s} N s`),
    explanation: `Impulse = force × time = ${F} × ${t} = ${impulse} N s. The same impulse equals change in momentum.`,
  });
}

function energy(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 3;
  const n = Math.floor(local / 3);
  const m = (n % 20) + 1;
  const v = ((Math.floor(n / 20) % 10) + 1) * 2;
  const h = Math.floor(n / 200) + 1;
  const ke = (m * v * v) / 2;
  const pe = m * 10 * h;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `en-${index}`,
      topic: "Work and energy",
      prompt: `A ${m} kg body moves at ${v} m/s at a height of ${h} m. Its kinetic energy is (g = 10 m/s²)`,
      correct: `${ke} J`,
      distractors: [`${pe} J`, `${m * v} J`, `${ke * 2} J`, `${v * v} J`],
      explanation: `KE = ½mv² = ½ × ${m} × ${v}² = ${ke} J. Height is not used for kinetic energy.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id: `en-${index}`,
      topic: "Work and energy",
      prompt: `A ${m} kg body is ${h} m above the ground and moves at ${v} m/s. Its gravitational potential energy is (g = 10 m/s²)`,
      correct: `${pe} J`,
      distractors: [`${ke} J`, `${m * h} J`, `${m * 10} J`, `${pe + v} J`],
      explanation: `PE = mgh = ${m} × 10 × ${h} = ${pe} J. Speed does not change this choice of PE.`,
    });
  }
  const power = frac(ke, h);
  return buildMcq(rng, {
    id: `en-${index}`,
    topic: "Work and energy",
    prompt: `A ${m} kg body moving at ${v} m/s delivers its entire kinetic energy in ${h} s. The average power is`,
    correct: `${power} W`,
    distractors: [`${ke} W`, `${frac(ke, h + 1)} W`, `${frac(ke * 2, h)} W`, `${m} W`],
    explanation: `KE = ${ke} J. Power = energy/time = ${ke}/${h} = ${power} W.`,
  });
}

function seriesCircuit(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 3;
  const n = Math.floor(local / 3);
  const I = (n % 12) + 1;
  const R = (Math.floor(n / 12) % 12) + 1;
  const R2 = Math.floor(n / 144) + 1;
  const req = R + R2;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `ser-${index}`,
      topic: "Electricity",
      prompt: `Resistors of ${R} Ω and ${R2} Ω are joined in series and carry ${I} A. The equivalent resistance is`,
      correct: `${req} Ω`,
      distractors: [`${R} Ω`, `${R2} Ω`, `${R * R2} Ω`, `${Math.abs(R2 - R) || R + 1} Ω`],
      explanation: `In series, R = R₁ + R₂ = ${R} + ${R2} = ${req} Ω. Current is the same through both but is not added into R.`,
    });
  }
  if (kind === 1) {
    const V = I * req;
    return buildMcq(rng, {
      id: `ser-${index}`,
      topic: "Electricity",
      prompt: `A current of ${I} A flows through ${R} Ω and ${R2} Ω in series. The voltage of the source is`,
      correct: `${V} V`,
      distractors: [`${I * R} V`, `${I * R2} V`, `${req} V`, `${V + I} V`],
      explanation: `Equivalent resistance = ${req} Ω. V = IR = ${I} × ${req} = ${V} V.`,
    });
  }
  const v1 = I * R;
  return buildMcq(rng, {
    id: `ser-${index}`,
    topic: "Electricity",
    prompt: `${R} Ω and ${R2} Ω are in series and carry ${I} A. The potential drop across the ${R} Ω resistor is`,
    correct: `${v1} V`,
    distractors: [`${I * R2} V`, `${I * req} V`, `${R} V`, `${v1 + R2} V`],
    explanation: `V₁ = IR₁ = ${I} × ${R} = ${v1} V.`,
  });
}

function moreElectric(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 3;
  const n = Math.floor(local / 3);
  const R = (n % 12) + 1;
  const R2 = (Math.floor(n / 12) % 12) + 1;
  const I = Math.floor(n / 144) + 1;
  if (kind === 0) {
    const correct = `${frac(R * R2, R + R2)} Ω`;
    return buildMcq(rng, {
      id: `par-${index}`,
      topic: "Electricity",
      prompt: `${R} Ω and ${R2} Ω are connected in parallel. A current of ${I} A enters the combination. The equivalent resistance is`,
      correct,
      distractors: [
        `${R + R2} Ω`,
        `${frac(R * R2, Math.abs(R - R2) || 1)} Ω`,
        `${frac(R + R2, R * R2)} Ω`,
        `${I} Ω`,
      ],
      explanation: `1/R = 1/${R} + 1/${R2}, so R = ${R}×${R2}/(${R}+${R2}) = ${correct}.`,
    });
  }
  if (kind === 1) {
    const H = I * I * R * R2;
    return buildMcq(rng, {
      id: `heat-${index}`,
      topic: "Electricity",
      prompt: `A current of ${I} A flows through a ${R} Ω heater for ${R2} s. Heat produced is`,
      correct: `${H} J`,
      distractors: nearMiss(H, [I * R * R2, I * I * R, R * R2]).map((s) => `${s} J`),
      explanation: `H = I²Rt = ${I}² × ${R} × ${R2} = ${H} J.`,
    });
  }
  const Q = I * R2;
  return buildMcq(rng, {
    id: `chg-${index}`,
    topic: "Electricity",
    prompt: `A current of ${I} A flows for ${R2} s through a ${R} Ω resistor. The charge that passes a point in the wire is`,
    correct: `${Q} C`,
    distractors: [`${I * R} C`, `${R2} C`, `${Q + R} C`, `${I * I * R2} C`],
    explanation: `Q = It = ${I} × ${R2} = ${Q} C. Resistance does not change the charge that the current carries in that time.`,
  });
}

function waves(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 2;
  const n = Math.floor(local / 2);
  const f = (n % 40) + 1;
  const lam = Math.floor(n / 40) + 1;
  const v = f * lam;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `wave-${index}`,
      topic: "Sound and waves",
      prompt: `A wave has frequency ${f} Hz and wavelength ${lam} m. Its speed is`,
      correct: `${v} m/s`,
      distractors: [`${f + lam} m/s`, `${f} m/s`, `${lam} m/s`, `${v + f} m/s`],
      explanation: `v = fλ = ${f} × ${lam} = ${v} m/s.`,
    });
  }
  const half = lam % 2 === 0 ? String(lam / 2) : `${lam}/2`;
  return buildMcq(rng, {
    id: `wave-${index}`,
    topic: "Sound and waves",
    prompt: `A wave of frequency ${f} Hz and wavelength ${lam} m keeps the same speed while its frequency is doubled. The new wavelength is`,
    correct: `${half} m`,
    distractors: [`${lam * 2} m`, `${lam} m`, `${v} m`, `${f * 2} m`],
    explanation: `Speed v = ${v} m/s stays the same, so λ = v/f. Doubling f halves λ. New wavelength = ${half} m.`,
  });
}

function lenses(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const sign = local % 2 === 0 ? 1 : -1;
  const f = Math.floor(local / 2) + 1;
  const word = sign > 0 ? "convex" : "concave";
  const p = `${sign > 0 ? "" : "-"}${frac(100, f)}`;
  const wrongSign = `${sign > 0 ? "-" : ""}${frac(100, f)}`;
  return buildMcq(rng, {
    id: `lens-${index}`,
    topic: "Light",
    prompt: `A ${word} lens has focal length ${f} cm. Its power is`,
    correct: `${p} D`,
    distractors: [`${wrongSign} D`, `${sign > 0 ? "" : "-"}${f} D`, `${frac(1, f)} D`, `${sign * f} D`],
    explanation: `Power (dioptre) = 1/f with f in metres. f = ${sign > 0 ? "" : "-"}${f}/100 m, so P = ${p} D. A ${word} lens is taken as ${sign > 0 ? "positive" : "negative"}.`,
  });
}

function densityPressure(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 2;
  const n = Math.floor(local / 2);
  const m = (n % 30) + 1;
  const V = (Math.floor(n / 30) % 12) + 1;
  const A = Math.floor(n / 360) + 1;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `den-${index}`,
      topic: "Density",
      prompt: `A block of mass ${m} g and volume ${V} cm³ rests on a face of area ${A} cm². Its density is`,
      correct: `${frac(m, V)} g/cm³`,
      distractors: [`${frac(m, A)} g/cm³`, `${frac(V, m)} g/cm³`, `${m + V} g/cm³`, `${m} g/cm³`],
      explanation: `Density = mass/volume = ${m}/${V} = ${frac(m, V)} g/cm³. Area is not used.`,
    });
  }
  const P = frac(10 * m, A);
  return buildMcq(rng, {
    id: `pre-${index}`,
    topic: "Pressure",
    prompt: `A ${m} kg block (volume ${V} m³) stands on a base of area ${A} m². Take g = 10 m/s². The pressure on the base is`,
    correct: `${P} Pa`,
    distractors: [`${frac(m, A)} Pa`, `${frac(10 * m, V)} Pa`, `${10 * m} Pa`, `${frac(10 * m, A + 1)} Pa`],
    explanation: `Force = weight = ${m} × 10 = ${10 * m} N. Pressure = F/A = ${10 * m}/${A} = ${P} Pa. Volume is not required.`,
  });
}

const MATERIALS = [
  { name: "water", c: 4200 },
  { name: "ice", c: 2100 },
  { name: "aluminium", c: 900 },
  { name: "copper", c: 390 },
  { name: "iron", c: 450 },
  { name: "glass", c: 840 },
];

function heat(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const mat = MATERIALS[local % MATERIALS.length]!;
  const n = Math.floor(local / MATERIALS.length);
  const m = (n % 20) + 1;
  const dT = Math.floor(n / 20) + 1;
  const Q = m * mat.c * dT;
  return buildMcq(rng, {
    id: `heat-${index}`,
    topic: "Heat",
    prompt: `How much heat raises the temperature of ${m} kg of ${mat.name} by ${dT}°C? Specific heat of ${mat.name} = ${mat.c} J/kg°C.`,
    correct: `${Q} J`,
    distractors: nearMiss(Q, [mat.c * dT, m * mat.c, m * dT, Q + mat.c]).map((s) => `${s} J`),
    explanation: `Q = mcΔT = ${m} × ${mat.c} × ${dT} = ${Q} J.`,
  });
}

function echo(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 2;
  const n = Math.floor(local / 2);
  const t = (n % 20) + 1;
  const speed = 300 + Math.floor(n / 20) * 2;
  const round = speed * t;
  const oneWay = round / 2;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `echo-${index}`,
      topic: "Sound",
      prompt: `Sound travels at ${speed} m/s. An echo from a cliff returns in ${t} s. How far away is the cliff?`,
      correct: `${oneWay} m`,
      distractors: [`${round} m`, `${speed} m`, `${oneWay + t} m`, `${Math.max(1, oneWay - speed)} m`],
      explanation: `The sound goes to the cliff and back, so distance = vt/2 = ${speed} × ${t} / 2 = ${oneWay} m.`,
    });
  }
  return buildMcq(rng, {
    id: `echo-${index}`,
    topic: "Sound",
    prompt: `Sound travels at ${speed} m/s. In ${t} s, how far does the sound itself travel on the way to a cliff and back?`,
    correct: `${round} m`,
    distractors: [`${oneWay} m`, `${speed} m`, `${round + t} m`, `${t} m`],
    explanation: `Distance travelled by the sound = speed × time = ${speed} × ${t} = ${round} m (the round trip).`,
  });
}

const PHYSICS_FACTS: Array<{ prompt: string; correct: string; distractors: string[]; explanation: string; topic: string }> = [
  { topic: "Units", prompt: "The SI unit of force is the", correct: "newton", distractors: ["joule", "watt", "pascal"], explanation: "Force is measured in newtons. 1 N = 1 kg m/s²." },
  { topic: "Units", prompt: "The SI unit of energy is the", correct: "joule", distractors: ["watt", "newton", "ampere"], explanation: "Energy and work are measured in joules." },
  { topic: "Units", prompt: "The SI unit of power is the", correct: "watt", distractors: ["joule", "volt", "ohm"], explanation: "Power is the rate of doing work, measured in watts. 1 W = 1 J/s." },
  { topic: "Units", prompt: "The SI unit of electric current is the", correct: "ampere", distractors: ["volt", "ohm", "coulomb"], explanation: "Current is measured in amperes." },
  { topic: "Units", prompt: "The SI unit of electric resistance is the", correct: "ohm", distractors: ["volt", "ampere", "watt"], explanation: "Resistance is measured in ohms, symbol Ω." },
  { topic: "Units", prompt: "The SI unit of potential difference is the", correct: "volt", distractors: ["ampere", "ohm", "joule"], explanation: "Potential difference is measured in volts." },
  { topic: "Electricity", prompt: "Ohm's law states that, at constant temperature,", correct: "V = IR", distractors: ["V = I/R", "R = VI", "P = I/V"], explanation: "If temperature does not change, potential difference is proportional to current: V = IR." },
  { topic: "Light", prompt: "A concave lens is a", correct: "diverging lens", distractors: ["converging lens", "plane mirror", "prism"], explanation: "A concave lens diverges a parallel beam of light." },
  { topic: "Light", prompt: "A convex lens is a", correct: "converging lens", distractors: ["diverging lens", "plane mirror", "concave mirror only"], explanation: "A convex lens converges a parallel beam of light." },
  { topic: "Light", prompt: "Short-sightedness (myopia) is corrected by a", correct: "concave lens", distractors: ["convex lens", "plane mirror", "prism"], explanation: "A concave lens spreads the rays so the image of a distant object falls on the retina." },
  { topic: "Light", prompt: "Long-sightedness (hypermetropia) is corrected by a", correct: "convex lens", distractors: ["concave lens", "concave mirror", "glass slab"], explanation: "A convex lens gives the extra convergence needed for near objects." },
  { topic: "Light", prompt: "The speed of light in vacuum is about", correct: "3 × 10⁸ m/s", distractors: ["3 × 10⁶ m/s", "340 m/s", "3 × 10⁸ km/s"], explanation: "c ≈ 3 × 10⁸ m/s. Sound in air is only about 340 m/s." },
  { topic: "Sound", prompt: "Sound cannot travel through", correct: "a vacuum", distractors: ["water", "steel", "air"], explanation: "Sound needs a material medium. It travels fastest in solids, slower in liquids, slowest in gases, and not at all in vacuum." },
  { topic: "Electricity", prompt: "In a parallel circuit of resistors, the quantity that is the same across each branch is", correct: "potential difference", distractors: ["current", "resistance", "charge stored"], explanation: "Each parallel branch is connected across the same two points, so the potential difference is common. Currents split." },
  { topic: "Electricity", prompt: "In a series circuit, the quantity that is the same in every resistor is", correct: "current", distractors: ["potential difference", "power in each resistor", "resistance"], explanation: "There is only one path, so the current is the same. The potential drops add up." },
  { topic: "Magnetism", prompt: "The magnetic field inside a long current-carrying solenoid is", correct: "nearly uniform and along the axis", distractors: ["zero", "circular around the axis only", "strongest at the ends and zero in the middle"], explanation: "Class 10 treats the field inside a long solenoid as uniform and parallel to the axis." },
  { topic: "Light", prompt: "The power of a lens is positive when the lens is", correct: "convex", distractors: ["concave", "plane", "opaque"], explanation: "A converging (convex) lens is given a positive focal length, so its power is positive." },
  { topic: "Heat", prompt: "The SI unit of specific heat capacity is", correct: "J/kg°C", distractors: ["J", "J/kg", "°C"], explanation: "Specific heat is heat per unit mass per degree rise in temperature." },
  { topic: "Motion", prompt: "A body with zero acceleration", correct: "moves with constant velocity or stays at rest", distractors: ["must be at rest", "must be speeding up", "moves in a circle"], explanation: "Zero acceleration means the velocity is not changing." },
  { topic: "Electricity", prompt: "The commercial unit of electrical energy is the", correct: "kilowatt hour", distractors: ["watt", "joule only", "volt"], explanation: "1 kWh = 3.6 × 10⁶ J. Household meters record kilowatt hours." },
];

function concepts(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const fact = PHYSICS_FACTS[local % PHYSICS_FACTS.length]!;
  const round = Math.floor(local / PHYSICS_FACTS.length);
  if (round === 0) {
    return buildMcq(rng, { id: `pf-${index}`, ...fact });
  }
  return buildMcq(rng, {
    id: `pf-${index}`,
    topic: fact.topic,
    prompt: `${fact.prompt} (practice ${round + 1})`,
    correct: fact.correct,
    distractors: fact.distractors,
    explanation: fact.explanation,
  });
}

const FNS = [
  kinematics,
  force,
  energy,
  seriesCircuit,
  moreElectric,
  waves,
  lenses,
  densityPressure,
  heat,
  echo,
];

export function physicsQuestion(board: string, index: number): Question {
  const i = Math.max(0, Math.floor(index));
  if (i % 47 === 0) {
    const n = Math.floor(i / 47) % PHYSICS_FACTS.length;
    return concepts(board, i, n);
  }
  const family = i % FAMILIES;
  const local = Math.floor(i / FAMILIES);
  return FNS[family]!(board, i, local);
}
