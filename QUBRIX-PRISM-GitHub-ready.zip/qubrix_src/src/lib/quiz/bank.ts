import { BANK_SIZE, fallbackQuestion, type Question } from "./core.ts";
import { chemistryQuestion } from "./chemistry.ts";
import { englishQuestion } from "./english.ts";
import { geographyQuestion } from "./geography.ts";
import { gkQuestion } from "./gk.ts";
import { historyQuestion } from "./history.ts";
import { lifeQuestion } from "./life.ts";
import { mathsQuestion } from "./maths.ts";
import { physicsQuestion } from "./physics.ts";

export { BANK_SIZE };
export const PRACTICE_SUBJECTS = ["maths", "physics", "chemistry", "life", "history", "geography", "english"] as const;

/**
 * Generates a deterministic, unbounded practice sequence. BANK_SIZE is a UI milestone,
 * not a hard generator limit: later cycles continue with larger parameter domains.
 * This is generator-backed practice, not a claim of 30,000 authored questions.
 */
export function getQuestion(board: string, subject: string, index: number, grade = 10): Question {
  const safeIndex = Math.max(0, Math.floor(index));
  const cycle = Math.floor(safeIndex / BANK_SIZE);
  const scope = `${board}|class-${grade}|cycle-${cycle}`;
  try {
    if (subject === "mixed") {
      const withinCycle = safeIndex % BANK_SIZE;
      const subjectId = PRACTICE_SUBJECTS[withinCycle % PRACTICE_SUBJECTS.length]!;
      const local = cycle * BANK_SIZE + Math.floor(withinCycle / PRACTICE_SUBJECTS.length);
      return getQuestion(board, subjectId, local, grade);
    }
    switch (subject) {
      case "maths": return mathsQuestion(scope, safeIndex);
      case "physics": return physicsQuestion(scope, safeIndex);
      case "chemistry": return chemistryQuestion(scope, safeIndex);
      case "life":
      case "biology": return lifeQuestion(scope, safeIndex);
      case "physical-science": return safeIndex % 2 === 0
        ? physicsQuestion(scope, Math.floor(safeIndex / 2))
        : chemistryQuestion(scope, Math.floor(safeIndex / 2));
      case "science": {
        const lane = safeIndex % 3;
        const local = Math.floor(safeIndex / 3);
        if (lane === 0) return physicsQuestion(scope, local);
        if (lane === 1) return chemistryQuestion(scope, local);
        return lifeQuestion(scope, local);
      }
      case "gk": return gkQuestion(safeIndex);
      case "history": return historyQuestion(scope, safeIndex);
      case "geography": return geographyQuestion(scope, safeIndex);
      case "english": return englishQuestion(scope, safeIndex);
      default: return mathsQuestion(scope, safeIndex);
    }
  } catch (err) {
    console.error(`QUBRIX question generation failed (${board}/${grade}/${subject}/${safeIndex})`, err);
    return fallbackQuestion(subject, safeIndex);
  }
}

// Topic lists are derived from actual generated tags. This prevents invented or
// mismatched topic buttons from appearing in the UI.
const topicIndexCache = new Map<string, Map<string, number[]>>();

function sourceSubject(subject: string): string[] {
  if (subject === "physical-science") return ["physics", "chemistry"];
  if (subject === "science") return ["physics", "chemistry", "life"];
  if (subject === "mixed") return [...PRACTICE_SUBJECTS];
  return [subject];
}

function buildTopicIndex(board: string, subject: string, grade: number, cycle = 0): Map<string, number[]> {
  // Topic tags are generator-family metadata and currently do not vary by board/class.
  const key = `${subject}|cycle-${cycle}`;
  const cached = topicIndexCache.get(key);
  if (cached) return cached;
  const map = new Map<string, number[]>();
  const subjects = sourceSubject(subject);
  for (const source of subjects) {
    for (let i = 0; i < BANK_SIZE; i++) {
      const q = getQuestion(board, source, cycle * BANK_SIZE + i, grade);
      const list = map.get(q.topic) ?? [];
      list.push(i * subjects.length + subjects.indexOf(source));
      map.set(q.topic, list);
    }
  }
  topicIndexCache.set(key, map);
  return map;
}

export function topicsFor(subject: string, board = "wbbse", grade = 10): string[] {
  return [...buildTopicIndex(board, subject, grade).keys()].sort((a, b) => a.localeCompare(b));
}

export function topicQuestionCount(board: string, subject: string, topic: string, grade = 10): number {
  return buildTopicIndex(board, subject, grade).get(topic)?.length ?? 0;
}

/** Returns only a question carrying the exact selected topic tag. */
export function getTopicQuestion(board: string, subject: string, topic: string, topicIndex: number, grade = 10): Question | null {
  let remaining = Math.max(0, Math.floor(topicIndex));
  let cycle = 0;
  let indexes = buildTopicIndex(board, subject, grade, cycle).get(topic) ?? [];
  // Consume each cycle's actual topic count. This remains correct when a topic's
  // distribution changes slightly because of interleaved fact/concept generators.
  while (indexes.length && remaining >= indexes.length && cycle < 10000) {
    remaining -= indexes.length;
    cycle += 1;
    indexes = buildTopicIndex(board, subject, grade, cycle).get(topic) ?? [];
  }
  if (!indexes.length) return null;
  const encoded = indexes[remaining]!;
  const sources = sourceSubject(subject);
  let sourceSubjectId = subject;
  let sourceIndex = cycle * BANK_SIZE + encoded;
  if (sources.length > 1) {
    const lane = encoded % sources.length;
    sourceSubjectId = sources[lane]!;
    sourceIndex = cycle * BANK_SIZE + Math.floor(encoded / sources.length);
  }
  const q = getQuestion(board, sourceSubjectId, sourceIndex, grade);
  return q.topic === topic ? q : null;
}
