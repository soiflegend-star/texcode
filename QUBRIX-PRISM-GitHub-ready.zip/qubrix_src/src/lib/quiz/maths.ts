import {
  buildMcq,
  digits,
  frac,
  gcd,
  nearMiss,
  pairAt,
  questionRng,
  type Question,
} from "./core.ts";

const FAMILIES = 16;

function rngFor(board: string, index: number) {
  return questionRng(`maths|${board}|${index}`);
}

function quadEq(sum: number, prod: number): string {
  const b = -sum;
  let s = "x²";
  s += term(b, "x");
  s += term(prod, "");
  return `${s} = 0`;
}

function term(coef: number, variable: string): string {
  if (coef === 0) return "";
  const sign = coef > 0 ? " + " : " - ";
  const mag = Math.abs(coef);
  if (!variable) return sign + String(mag);
  if (mag === 1) return sign + variable;
  return sign + mag + variable;
}

function quadratic(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const span = 31;
  const pairs = (span * (span + 1)) / 2;
  const [ip, iq] = pairAt(span, local % pairs);
  const kind = Math.floor(local / pairs) % 4;
  const p = ip - 15;
  const q = iq - 15;
  const sum = p + q;
  const prod = p * q;
  const disc = (p - q) * (p - q);
  const eq = quadEq(sum, prod);
  const id = `quad-${index}`;
  if (kind === 0) {
    return buildMcq(rng, {
      id,
      topic: "Quadratic equations",
      prompt: `For ${eq}, what is the sum of the roots?`,
      correct: String(sum),
      distractors: nearMiss(sum, [prod, -sum, disc]),
      explanation: `The equation is x² - (sum)x + (product) = 0. Sum of roots = ${sum}. Roots: ${p} and ${q}.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id,
      topic: "Quadratic equations",
      prompt: `For ${eq}, what is the product of the roots?`,
      correct: String(prod),
      distractors: nearMiss(prod, [sum, -prod, disc]),
      explanation: `Product of the roots = ${prod}. The roots are ${p} and ${q}.`,
    });
  }
  if (kind === 2) {
    return buildMcq(rng, {
      id,
      topic: "Quadratic equations",
      prompt: `What is the discriminant of ${eq}?`,
      correct: String(disc),
      distractors: nearMiss(disc, [sum, prod, p - q]),
      explanation: `Discriminant = (difference of roots)² = (${p} - ${q})² = ${disc}. ${disc === 0 ? "The roots are real and equal." : "The roots are real and unequal."}`,
    });
  }
  return buildMcq(rng, {
    id,
    topic: "Quadratic equations",
    prompt: `One root of ${eq} is ${p}. What is the other root?`,
    correct: String(q),
    distractors: nearMiss(q, [p, sum, prod]),
    explanation: `The roots are ${p} and ${q}, because they add to ${sum} and multiply to ${prod}.`,
  });
}

function linear(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const [x0d, y0d, ad, bd] = digits(local, [10, 10, 5, 4]);
  const x0 = x0d - 3;
  const y0 = y0d - 3;
  const a = ad + 1;
  const b = bd + 1;
  const d = 1;
  const e = b + 1;
  const c = a * x0 + b * y0;
  const f = d * x0 + e * y0;
  const askX = Math.floor(local / 2000) % 2 === 0 || local < 2000;
  const unknown = local % 2 === 0 ? "x" : "y";
  const answer = unknown === "x" ? x0 : y0;
  void askX;
  return buildMcq(rng, {
    id: `lin-${index}`,
    topic: "Linear equations",
    prompt: `Solve ${coef(a, "x")} + ${coef(b, "y", true)} = ${c} and ${coef(d, "x")} + ${coef(e, "y", true)} = ${f}. The value of ${unknown} is`,
    correct: String(answer),
    distractors: nearMiss(answer, [x0 + y0, x0 - y0, unknown === "x" ? y0 : x0]),
    explanation: `Substitution or elimination gives x = ${x0} and y = ${y0}. Check: ${a}(${x0}) + ${b}(${y0}) = ${c}.`,
  });
}

function coef(n: number, variable: string, bare = false): string {
  if (n === 1) return bare ? variable : variable;
  return `${n}${variable}`;
}

function ap(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const [ad, dd, nd, kind] = digits(local, [12, 8, 10, 2]);
  const a = ad + 1;
  const d = dd + 1;
  const n = nd + 4;
  const termN = a + (n - 1) * d;
  const sum = Math.round((n * (2 * a + (n - 1) * d)) / 2);
  if (kind === 0) {
    return buildMcq(rng, {
      id: `ap-${index}`,
      topic: "Arithmetic progressions",
      prompt: `In the AP ${a}, ${a + d}, ${a + 2 * d}, … what is the ${nth(n)} term?`,
      correct: String(termN),
      distractors: nearMiss(termN, [a + n * d, sum, a + (n - 2) * d]),
      explanation: `nth term = a + (n - 1)d = ${a} + ${n - 1}×${d} = ${termN}.`,
    });
  }
  return buildMcq(rng, {
    id: `ap-${index}`,
    topic: "Arithmetic progressions",
    prompt: `Find the sum of the first ${n} terms of the AP with first term ${a} and common difference ${d}.`,
    correct: String(sum),
    distractors: nearMiss(sum, [termN, sum + d, n * a]),
    explanation: `Sₙ = n/2 × [2a + (n - 1)d] = ${n}/2 × [${2 * a} + ${n - 1}×${d}] = ${sum}.`,
  });
}

function nth(n: number): string {
  const v = n % 100;
  if (v >= 11 && v <= 13) return `${n}th`;
  switch (n % 10) {
    case 1:
      return `${n}st`;
    case 2:
      return `${n}nd`;
    case 3:
      return `${n}rd`;
    default:
      return `${n}th`;
  }
}

const TRIPLES: Array<[number, number, number]> = [
  [3, 4, 5],
  [5, 12, 13],
  [8, 15, 17],
  [7, 24, 25],
  [20, 21, 29],
  [12, 35, 37],
  [9, 40, 41],
  [11, 60, 61],
];

function distance(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const [ti, sc, sign, xd, yd] = digits(local, [8, 5, 4, 5, 3]);
  const triple = TRIPLES[ti]!;
  const scale = sc + 1;
  const dx = scale * triple[0] * (sign % 2 === 0 ? 1 : -1);
  const dy = scale * triple[1] * (sign < 2 ? 1 : -1);
  const x1 = xd - 2;
  const y1 = yd - 1;
  const x2 = x1 + dx;
  const y2 = y1 + dy;
  const dist = scale * triple[2];
  return buildMcq(rng, {
    id: `dist-${index}`,
    topic: "Coordinate geometry",
    prompt: `What is the distance between (${x1}, ${y1}) and (${x2}, ${y2})?`,
    correct: String(dist),
    distractors: nearMiss(dist, [Math.abs(dx), Math.abs(dy), Math.abs(dx) + Math.abs(dy)]),
    explanation: `Distance = √[(${x2} - ${x1})² + (${y2} - ${y1})²] = √[${dx * dx} + ${dy * dy}] = ${dist}.`,
  });
}

function pythagoras(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const ask = local % 3;
  const ti = Math.floor(local / 3) % 8;
  const scale = Math.floor(local / 24) + 1;
  const [a0, b0, c0] = TRIPLES[ti]!;
  const a = scale * a0;
  const b = scale * b0;
  const c = scale * c0;
  if (ask === 0) {
    return buildMcq(rng, {
      id: `py-${index}`,
      topic: "Right triangles",
      prompt: `A right triangle has legs ${a} cm and ${b} cm. What is the hypotenuse?`,
      correct: `${c} cm`,
      distractors: [`${a + b} cm`, `${c + scale} cm`, `${Math.abs(b - a)} cm`, `${a * b} cm`],
      explanation: `By Pythagoras, hypotenuse = √(${a}² + ${b}²) = √${c * c} = ${c} cm.`,
    });
  }
  const known = ask === 1 ? b : a;
  const missing = ask === 1 ? a : b;
  const side = ask === 1 ? "the other leg" : "the remaining leg";
  return buildMcq(rng, {
    id: `py-${index}`,
    topic: "Right triangles",
    prompt: `A right triangle has hypotenuse ${c} cm and one leg ${known} cm. What is ${side}?`,
    correct: `${missing} cm`,
    distractors: unitish(missing, [known, c, Math.abs(c - known), missing + scale]),
    explanation: `The missing leg is √(${c}² − ${known}²) = √${c * c - known * known} = ${missing} cm.`,
  });
}

function unitish(correct: number, extras: number[]): string[] {
  return nearMiss(correct, extras).map((s) => `${s} cm`);
}

function mean(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const [a, b, c, d] = digits(local, [12, 10, 8, 2]);
  const vals = [a, b + 1, c + 2, d + 3];
  const sum4 = vals.reduce((s, n) => s + n, 0);
  const e = (5 - (sum4 % 5)) % 5;
  const nums = [...vals, e];
  const total = sum4 + e;
  const avg = total / 5;
  return buildMcq(rng, {
    id: `mean-${index}`,
    topic: "Statistics",
    prompt: `The mean of ${nums.join(", ")} is`,
    correct: String(avg),
    distractors: nearMiss(avg, [total, avg + 1, nums[0]!]),
    explanation: `Mean = (${nums.join(" + ")}) / 5 = ${total} / 5 = ${avg}.`,
  });
}

function probability(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const [rd, bd, gd, kind] = digits(local, [10, 10, 5, 4]);
  const R = rd + 1;
  const B = bd + 1;
  const G = gd + 1;
  const total = R + B + G;
  const specs = [
    { label: "red", n: R },
    { label: "blue", n: B },
    { label: "green", n: G },
    { label: "red or blue", n: R + B },
  ];
  const spec = specs[kind]!;
  const correct = frac(spec.n, total);
  return buildMcq(rng, {
    id: `prob-${index}`,
    topic: "Probability",
    prompt: `A bag has ${R} red, ${B} blue and ${G} green marbles. One marble is drawn at random. The probability that it is ${spec.label} is`,
    correct,
    distractors: [frac(spec.n + 1, total), frac(spec.n, total + 1), frac(total - spec.n, total), frac(spec.n, R + B), "1", "0"].filter(
      (s) => s !== correct,
    ),
    explanation: `Favourable outcomes = ${spec.n}. Total = ${total}. Probability = ${correct}.`,
  });
}

function simpleInterest(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const [pd, rd, td, kind] = digits(local, [20, 10, 6, 2]);
  const P = (pd + 1) * 100;
  const R = rd + 1;
  const T = td + 1;
  const SI = (P * R * T) / 100;
  const amount = P + SI;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `si-${index}`,
      topic: "Simple interest",
      prompt: `Simple interest on ₹${P} for ${T} year${T > 1 ? "s" : ""} at ${R}% per annum is`,
      correct: `₹${SI}`,
      distractors: nearMiss(SI, [amount, P, SI + P]).map((s) => (s.startsWith("₹") ? s : `₹${s}`)),
      explanation: `SI = PRT/100 = ${P} × ${R} × ${T} / 100 = ₹${SI}.`,
    });
  }
  return buildMcq(rng, {
    id: `si-${index}`,
    topic: "Simple interest",
    prompt: `₹${P} is kept for ${T} year${T > 1 ? "s" : ""} at ${R}% simple interest per annum. The amount is`,
    correct: `₹${amount}`,
    distractors: [`₹${SI}`, `₹${P}`, `₹${amount + R}`, `₹${amount - R}`],
    explanation: `SI = ₹${SI}. Amount = Principal + SI = ${P} + ${SI} = ₹${amount}.`,
  });
}

function commercial(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const ps = [5, 10, 20, 25, 50];
  const [cd, pi, kind] = digits(local, [50, 5, 8]);
  const cp = (cd + 1) * 20;
  const p = ps[pi]!;
  const profit = (cp * p) / 100;
  const spGain = cp + profit;
  const spLoss = cp - profit;
  const money = (n: number) => `₹${n}`;
  const misses = (n: number) => [money(n + 10), money(n - 10), money(cp), money(profit), money(n + p)].filter((s) => s !== money(n));
  if (kind === 0) {
    return buildMcq(rng, {
      id: `com-${index}`,
      topic: "Profit and loss",
      prompt: `Cost price is ${money(cp)}. What is the selling price at a profit of ${p}%?`,
      correct: money(spGain),
      distractors: misses(spGain),
      explanation: `Profit = ${p}% of ${cp} = ₹${profit}. SP = ${cp} + ${profit} = ₹${spGain}.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id: `com-${index}`,
      topic: "Profit and loss",
      prompt: `Cost price is ${money(cp)}. What is the selling price at a loss of ${p}%?`,
      correct: money(spLoss),
      distractors: misses(spLoss),
      explanation: `Loss = ₹${profit}. SP = ${cp} - ${profit} = ₹${spLoss}.`,
    });
  }
  if (kind === 2) {
    return buildMcq(rng, {
      id: `com-${index}`,
      topic: "Profit and loss",
      prompt: `How much profit is earned on ${money(cp)} at ${p}% profit?`,
      correct: money(profit),
      distractors: misses(profit),
      explanation: `Profit = ${p}/100 × ${cp} = ₹${profit}.`,
    });
  }
  if (kind === 3) {
    return buildMcq(rng, {
      id: `com-${index}`,
      topic: "Profit and loss",
      prompt: `How much is lost on ${money(cp)} at a loss of ${p}%?`,
      correct: money(profit),
      distractors: misses(profit),
      explanation: `Loss = ${p}/100 × ${cp} = ₹${profit}.`,
    });
  }
  if (kind === 4) {
    return buildMcq(rng, {
      id: `com-${index}`,
      topic: "Profit and loss",
      prompt: `Marked price is ${money(cp)}. After a discount of ${p}%, the selling price is`,
      correct: money(spLoss),
      distractors: misses(spLoss),
      explanation: `Discount = ₹${profit}. SP = ${cp} - ${profit} = ₹${spLoss}.`,
    });
  }
  if (kind === 5) {
    return buildMcq(rng, {
      id: `com-${index}`,
      topic: "Profit and loss",
      prompt: `An article is sold for ${money(spGain)} at a profit of ${p}%. What was the cost price?`,
      correct: money(cp),
      distractors: misses(cp),
      explanation: `SP = CP × (100 + ${p})/100. CP = ${spGain} × 100/${100 + p} = ₹${cp}.`,
    });
  }
  if (kind === 6) {
    return buildMcq(rng, {
      id: `com-${index}`,
      topic: "Profit and loss",
      prompt: `An article is sold for ${money(spLoss)} at a loss of ${p}%. What was the cost price?`,
      correct: money(cp),
      distractors: misses(cp),
      explanation: `SP = CP × (100 - ${p})/100. CP = ${spLoss} × 100/${100 - p} = ₹${cp}.`,
    });
  }
  return buildMcq(rng, {
    id: `com-${index}`,
    topic: "Percentage",
    prompt: `What percent of ${money(cp)} is ${money(profit)}?`,
    correct: `${p}%`,
    distractors: [`${p + 5}%`, `${p - 5 === 0 ? 1 : Math.abs(p - 5)}%`, `${100 - p}%`, `${p * 2}%`],
    explanation: `(${profit} / ${cp}) × 100 = ${p}%.`,
  });
}

function piTimes(numer: number, denom = 1): string {
  const g = gcd(numer, denom);
  const n = numer / g;
  const d = denom / g;
  if (d === 1) return n === 1 ? "π" : `${n}π`;
  if (n === 1) return `π/${d}`;
  return `${n}π/${d}`;
}

function circles(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  if (local < CIRCLE_FACTS.length) return factMcq(rng, CIRCLE_FACTS[local]!, `circ-fact-${index}`);
  const L = local - CIRCLE_FACTS.length;
  const kind = L % 8;
  const r = Math.floor(L / 8) + 1;
  const area = piTimes(r * r);
  const circ = piTimes(2 * r);
  const semi = piTimes(r * r, 2);
  const quad = piTimes(r * r, 4);
  const table: Array<{ prompt: string; correct: string; wrong: string[]; why: string }> = [
    {
      prompt: `A circle has radius ${r} cm. Its area is`,
      correct: `${area} cm²`,
      wrong: [`${circ} cm`, `${piTimes(2 * r * r)} cm²`, `${piTimes(r)} cm²`, `${r * r} cm²`],
      why: `Area = πr² = π × ${r}² = ${area} cm².`,
    },
    {
      prompt: `A circle has radius ${r} cm. Its circumference is`,
      correct: `${circ} cm`,
      wrong: [`${area} cm²`, `${piTimes(r)} cm`, `${2 * r} cm`, `${piTimes(r * r)} cm`],
      why: `Circumference = 2πr = ${circ} cm.`,
    },
    {
      prompt: `The diameter of a circle of radius ${r} cm is`,
      correct: `${2 * r} cm`,
      wrong: [`${r} cm`, `${r * r} cm`, `${2 * r * r} cm`, `${r + 2} cm`],
      why: `Diameter = 2 × radius = ${2 * r} cm.`,
    },
    {
      prompt: `A semicircle has radius ${r} cm. Its area is`,
      correct: `${semi} cm²`,
      wrong: [`${area} cm²`, `${quad} cm²`, `${circ} cm`, `${piTimes(r * r, 3)} cm²`],
      why: `Area of a semicircle = ½πr² = ${semi} cm².`,
    },
    {
      prompt: `A quadrant of a circle has radius ${r} cm. Its area is`,
      correct: `${quad} cm²`,
      wrong: [`${semi} cm²`, `${area} cm²`, `${piTimes(r * r, 8)} cm²`, `${circ} cm`],
      why: `A quadrant is a quarter circle. Area = ¼πr² = ${quad} cm².`,
    },
    {
      prompt: `The length of a 90° arc in a circle of radius ${r} cm is`,
      correct: `${piTimes(r, 2)} cm`,
      wrong: [`${circ} cm`, `${piTimes(r)} cm`, `${area} cm²`, `${r} cm`],
      why: `Arc = (90/360) × 2πr = ½πr = ${piTimes(r, 2)} cm.`,
    },
    {
      prompt: `A wheel of radius ${r} m rolls once. The distance it travels is`,
      correct: `${circ} m`,
      wrong: [`${area} m²`, `${2 * r} m`, `${piTimes(r)} m`, `${piTimes(r * r)} m`],
      why: `One revolution covers the circumference, 2πr = ${circ} m.`,
    },
    {
      prompt: `Fencing a circular park of radius ${r} m costs ₹10 per metre. The cost is`,
      correct: `₹${10 * 2 * r}π`,
      wrong: [`₹${10 * r * r}π`, `₹${2 * r}π`, `₹${20 * r}`, `₹${5 * r}π`],
      why: `Perimeter = 2πr m. Cost = 10 × 2πr = ₹${20 * r}π.`,
    },
  ];
  const row = table[kind % table.length]!;
  return buildMcq(rng, {
    id: `circ-${index}`,
    topic: "Circles",
    prompt: row.prompt,
    correct: row.correct,
    distractors: row.wrong,
    explanation: row.why,
  });
}

const CIRCLE_FACTS: Array<{ topic: string; prompt: string; correct: string; distractors: string[]; explanation: string }> = [
  {
    topic: "Circles",
    prompt: "The angle in a semicircle is",
    correct: "90°",
    distractors: ["60°", "180°", "45°"],
    explanation: "The angle subtended by a diameter at any point on the remaining circumference is a right angle.",
  },
  {
    topic: "Circles",
    prompt: "A tangent to a circle is perpendicular to the",
    correct: "radius at the point of contact",
    distractors: ["chord through the centre only", "diameter at the far end", "secant at two points"],
    explanation: "The radius to the point of contact is perpendicular to the tangent.",
  },
  {
    topic: "Circles",
    prompt: "The angle at the centre is how related to the angle at the circumference standing on the same arc?",
    correct: "Twice the angle at the circumference",
    distractors: ["Equal to it", "Half of it", "Three times it"],
    explanation: "The angle subtended by an arc at the centre is double the angle subtended at the circumference.",
  },
  {
    topic: "Circles",
    prompt: "Equal chords of a circle are",
    correct: "equidistant from the centre",
    distractors: ["always diameters", "perpendicular", "of length equal to the radius"],
    explanation: "Equal chords are at equal distances from the centre.",
  },
];

function factMcq(
  rng: () => number,
  fact: { topic: string; prompt: string; correct: string; distractors: string[]; explanation: string },
  id: string,
): Question {
  return buildMcq(rng, { id, ...fact });
}

function solids(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 8;
  const r = Math.floor(local / 8) + 1;
  const h = r + 2;
  const rows: Array<{ prompt: string; correct: string; wrong: string[]; why: string; topic: string }> = [
    {
      topic: "Surface areas and volumes",
      prompt: `Volume of a cylinder of radius ${r} cm and height ${h} cm is`,
      correct: `${piTimes(r * r * h)} cm³`,
      wrong: [`${piTimes(2 * r * h)} cm³`, `${piTimes(r * h)} cm³`, `${piTimes(2 * r * r * h)} cm³`],
      why: `V = πr²h = ${piTimes(r * r * h)} cm³.`,
    },
    {
      topic: "Surface areas and volumes",
      prompt: `Curved surface area of a cylinder of radius ${r} cm and height ${h} cm is`,
      correct: `${piTimes(2 * r * h)} cm²`,
      wrong: [`${piTimes(r * r * h)} cm²`, `${piTimes(2 * r * (r + h))} cm²`, `${piTimes(r * h)} cm²`],
      why: `CSA = 2πrh = ${piTimes(2 * r * h)} cm².`,
    },
    {
      topic: "Surface areas and volumes",
      prompt: `Total surface area of a cylinder of radius ${r} cm and height ${h} cm is`,
      correct: `${piTimes(2 * r * (r + h))} cm²`,
      wrong: [`${piTimes(2 * r * h)} cm²`, `${piTimes(r * r * h)} cm²`, `${piTimes(2 * r * r + h)} cm²`],
      why: `TSA = 2πr(h + r) = ${piTimes(2 * r * (r + h))} cm².`,
    },
    {
      topic: "Surface areas and volumes",
      prompt: `Volume of a cone of radius ${r} cm and height ${h} cm is`,
      correct: `${piTimes(r * r * h, 3)} cm³`,
      wrong: [`${piTimes(r * r * h)} cm³`, `${piTimes(r * h)} cm³`, `${piTimes(r * r * h, 2)} cm³`],
      why: `V = ⅓πr²h = ${piTimes(r * r * h, 3)} cm³.`,
    },
    {
      topic: "Surface areas and volumes",
      prompt: `A cone has base radius ${r} cm and slant height ${h} cm. Its curved surface area is`,
      correct: `${piTimes(r * h)} cm²`,
      wrong: [`${piTimes(r * r * h, 3)} cm²`, `${piTimes(2 * r * h)} cm²`, `${piTimes(r + h)} cm²`],
      why: `CSA of a cone = πrl = ${piTimes(r * h)} cm².`,
    },
    {
      topic: "Surface areas and volumes",
      prompt: `Surface area of a sphere of radius ${r} cm (a cone beside it has height ${h} cm) is`,
      correct: `${piTimes(4 * r * r)} cm²`,
      wrong: [`${piTimes(4 * h * h)} cm²`, `${piTimes(2 * r * r)} cm²`, `${piTimes(4 * r * r * r, 3)} cm³`],
      why: `Surface area of a sphere is 4πr² = ${piTimes(4 * r * r)} cm². The cone's height is not needed.`,
    },
    {
      topic: "Surface areas and volumes",
      prompt: `Volume of a sphere of radius ${r} cm is`,
      correct: `${piTimes(4 * r * r * r, 3)} cm³`,
      wrong: [`${piTimes(4 * r * r)} cm³`, `${piTimes(2 * r * r * r, 3)} cm³`, `${piTimes(r * r * r)} cm³`],
      why: `V = 4/3 πr³ = ${piTimes(4 * r * r * r, 3)} cm³.`,
    },
    {
      topic: "Surface areas and volumes",
      prompt: `A cuboid measures ${r} cm × ${h} cm × ${r + h} cm. Its volume is`,
      correct: `${r * h * (r + h)} cm³`,
      wrong: [`${r * h} cm³`, `${2 * (r * h + h * (r + h) + (r + h) * r)} cm³`, `${r + h + r + h} cm³`],
      why: `Volume = length × breadth × height = ${r} × ${h} × ${r + h} = ${r * h * (r + h)} cm³.`,
    },
  ];
  const row = rows[kind]!;
  return buildMcq(rng, {
    id: `solid-${index}`,
    topic: row.topic,
    prompt: row.prompt,
    correct: row.correct,
    distractors: row.wrong,
    explanation: row.why,
  });
}

function mulSqrt3(n: number): string {
  const g = gcd(n, 1);
  void g;
  if (n === 0) return "0";
  if (n === 1) return "√3";
  if (n === -1) return "-√3";
  return `${n}√3`;
}

function divSqrt3(n: number): string {
  const g = gcd(n, 3);
  const num = n / g;
  const den = 3 / g;
  if (den === 1) return mulSqrt3(num);
  if (num === 1) return `√3/${den}`;
  return `${num}√3/${den}`;
}

const TRIG_FACTS: Array<{ prompt: string; correct: string; distractors: string[]; explanation: string }> = [
  { prompt: "The value of sin 0° is", correct: "0", distractors: ["1", "1/2", "√3/2"], explanation: "sin 0° = 0." },
  { prompt: "The value of sin 30° is", correct: "1/2", distractors: ["√3/2", "1", "1/√2"], explanation: "sin 30° = 1/2." },
  { prompt: "The value of sin 45° is", correct: "1/√2", distractors: ["1/2", "√3/2", "1"], explanation: "sin 45° = cos 45° = 1/√2." },
  { prompt: "The value of sin 60° is", correct: "√3/2", distractors: ["1/2", "1/√2", "√3"], explanation: "sin 60° = √3/2." },
  { prompt: "The value of sin 90° is", correct: "1", distractors: ["0", "1/2", "√3/2"], explanation: "sin 90° = 1." },
  { prompt: "The value of cos 0° is", correct: "1", distractors: ["0", "1/2", "√3/2"], explanation: "cos 0° = 1." },
  { prompt: "The value of cos 60° is", correct: "1/2", distractors: ["√3/2", "1", "0"], explanation: "cos 60° = 1/2." },
  { prompt: "The value of tan 45° is", correct: "1", distractors: ["0", "√3", "1/√3"], explanation: "tan 45° = 1." },
  { prompt: "The value of tan 30° is", correct: "1/√3", distractors: ["√3", "1", "1/2"], explanation: "tan 30° = 1/√3." },
  { prompt: "The value of tan 60° is", correct: "√3", distractors: ["1/√3", "1", "√3/2"], explanation: "tan 60° = √3." },
  { prompt: "sin²θ + cos²θ equals", correct: "1", distractors: ["0", "2", "tan θ"], explanation: "The identity sin²θ + cos²θ = 1 holds for every θ where both are defined." },
  { prompt: "1 + tan²θ equals", correct: "sec²θ", distractors: ["cos²θ", "sin²θ", "cosec²θ"], explanation: "1 + tan²θ = sec²θ." },
];

function heights(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const trigSlot = local % 200;
  if (trigSlot < TRIG_FACTS.length) {
    const fact = TRIG_FACTS[trigSlot]!;
    const round = Math.floor(local / 200);
    return factMcq(rng, {
      topic: "Trigonometry",
      ...fact,
      prompt: round === 0 ? fact.prompt : `Trigonometry practice ${round + 1}: ${fact.prompt}`,
    }, `trig-${index}`);
  }
  const L = local - (Math.floor(local / 200) + 1) * TRIG_FACTS.length;
  const ask = L % 2;
  const angI = Math.floor(L / 2) % 3;
  const objI = Math.floor(L / 6) % 5;
  const known = Math.floor(L / 30) + 6;
  const objects = ["tower", "lighthouse", "building", "cliff", "pole"];
  const angles = [30, 45, 60] as const;
  const obj = objects[objI]!;
  const ang = angles[angI]!;
  const findHeight = ask === 0;
  let correct = "";
  let working = "";
  if (ang === 45) {
    correct = `${known} m`;
    working = findHeight
      ? `tan 45° = 1, so height = distance = ${known} m.`
      : `tan 45° = 1, so distance = height = ${known} m.`;
  } else if (ang === 30) {
    correct = findHeight ? `${divSqrt3(known)} m` : `${mulSqrt3(known)} m`;
    working = findHeight
      ? `tan 30° = 1/√3 = height/distance, so height = ${known}/√3 = ${divSqrt3(known)} m.`
      : `tan 30° = 1/√3 = height/distance, so distance = height × √3 = ${mulSqrt3(known)} m.`;
  } else {
    correct = findHeight ? `${mulSqrt3(known)} m` : `${divSqrt3(known)} m`;
    working = findHeight
      ? `tan 60° = √3 = height/distance, so height = ${known}√3 = ${mulSqrt3(known)} m.`
      : `tan 60° = √3 = height/distance, so distance = height/√3 = ${divSqrt3(known)} m.`;
  }
  const wrong = new Set<string>([
    `${known} m`,
    `${mulSqrt3(known)} m`,
    `${divSqrt3(known)} m`,
    `${known * 2} m`,
    `${mulSqrt3(known * 3)} m`,
    `${known}√2 m`,
  ]);
  wrong.delete(correct);
  const prompt = findHeight
    ? `From a point ${known} m away on level ground, the angle of elevation of the top of a ${obj} is ${ang}°. The height of the ${obj} is`
    : `The angle of elevation of the top of a ${obj} of height ${known} m, from a point on level ground, is ${ang}°. The distance of the point from the foot of the ${obj} is`;
  return buildMcq(rng, {
    id: `ht-${index}`,
    topic: "Heights and distances",
    prompt,
    correct,
    distractors: [...wrong],
    explanation: working,
  });
}

function hcfLcm(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const [ad, bd, kind] = digits(local, [40, 24, 2]);
  const a = ad + 2;
  const b = bd + 2;
  const g = gcd(a, b);
  const l = (a / g) * b;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `hcf-${index}`,
      topic: "Real numbers",
      prompt: `The HCF of ${a} and ${b} is`,
      correct: String(g),
      distractors: nearMiss(g, [l, a, b, 1]),
      explanation: `By Euclid's algorithm, HCF(${a}, ${b}) = ${g}.`,
    });
  }
  return buildMcq(rng, {
    id: `lcm-${index}`,
    topic: "Real numbers",
    prompt: `The LCM of ${a} and ${b} is`,
    correct: String(l),
    distractors: nearMiss(l, [g, a * b, a + b]),
    explanation: `LCM × HCF = product of the numbers. LCM = ${a} × ${b} / ${g} = ${l}.`,
  });
}

function variation(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const [md, y1d, y2d, kind] = digits(local, [10, 10, 10, 2]);
  const m = md + 1;
  const y1 = y1d + 2;
  const y2 = y2d + 2;
  if (kind === 0) {
    const x1 = m * y1;
    const x2 = m * y2;
    return buildMcq(rng, {
      id: `var-${index}`,
      topic: "Variation",
      prompt: `x varies directly as y. When y = ${y1}, x = ${x1}. What is x when y = ${y2}?`,
      correct: String(x2),
      distractors: nearMiss(x2, [x1, y2, m, x1 + y2]),
      explanation: `x/y is constant. ${x1}/${y1} = ${x2}/${y2}, so x = ${x2}.`,
    });
  }
  const x1 = m * y2;
  const x2 = m * y1;
  return buildMcq(rng, {
    id: `var-${index}`,
    topic: "Variation",
    prompt: `x varies inversely as y. When y = ${y1}, x = ${x1}. What is x when y = ${y2}?`,
    correct: String(x2),
    distractors: nearMiss(x2, [x1, y2, m * y2 * y1, x1 + x2]),
    explanation: `xy is constant. ${x1} × ${y1} = ${x1 * y1}. So when y = ${y2}, x = ${x2}.`,
  });
}

function motion(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 3;
  const who = ["train", "bus", "cyclist", "boat", "car"][local % 5];
  if (kind === 2) {
    const k = Math.floor(local / 3) + 1;
    const kmh = k * 18;
    const ms = k * 5;
    return buildMcq(rng, {
      id: `mot-${index}`,
      topic: "Speed, distance, time",
      prompt: `A ${who} moves at ${kmh} km/h. What is that speed in m/s?`,
      correct: `${ms} m/s`,
      distractors: [`${kmh} m/s`, `${k} m/s`, `${ms * 2} m/s`, `${k * 18} m/s`],
      explanation: `Multiply km/h by 5/18. ${kmh} × 5/18 = ${ms} m/s.`,
    });
  }
  const speed = (Math.floor(local / 3) % 25) + 4;
  const time = Math.floor(local / 75) + 1;
  const distanceKm = speed * time;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `mot-${index}`,
      topic: "Speed, distance, time",
      prompt: `A ${who} travels at ${speed} km/h for ${time} hour${time > 1 ? "s" : ""}. How far does it go?`,
      correct: `${distanceKm} km`,
      distractors: [`${speed + time} km`, `${speed} km`, `${distanceKm + speed} km`, `${time} km`],
      explanation: `Distance = speed × time = ${speed} × ${time} = ${distanceKm} km.`,
    });
  }
  return buildMcq(rng, {
    id: `mot-${index}`,
    topic: "Speed, distance, time",
    prompt: `A ${who} covers ${distanceKm} km at ${speed} km/h. How long does the journey take?`,
    correct: `${time} h`,
    distractors: [`${time + 1} h`, `${speed} h`, `${distanceKm} h`, `${Math.max(1, time - 1)} h`],
    explanation: `Time = distance / speed = ${distanceKm} / ${speed} = ${time} h.`,
  });
}

const SQUARE_FREE = [2, 3, 5, 6, 7, 10, 11, 13, 14, 15];

function surds(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 3;
  const bi = Math.floor(local / 3) % 10;
  const k = Math.floor(local / 30) + 2;
  const b = SQUARE_FREE[bi]!;
  const inside = k * k * b;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `surd-${index}`,
      topic: "Quadratic surds",
      prompt: `Simplify √${inside}.`,
      correct: `${k}√${b}`,
      distractors: [`${k * k}√${b}`, `√${k * b}`, `${k * b}`, `${2 * k}√${b}`, `${k}√${inside}`],
      explanation: `√${inside} = √(${k * k} × ${b}) = ${k}√${b}.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id: `surd-${index}`,
      topic: "Quadratic surds",
      prompt: `The value of ${k}√${b} × √${b} is`,
      correct: String(k * b),
      distractors: nearMiss(k * b, [k, b, k * k * b]),
      explanation: `√${b} × √${b} = ${b}, so ${k}√${b} × √${b} = ${k * b}.`,
    });
  }
  return buildMcq(rng, {
    id: `surd-${index}`,
    topic: "Quadratic surds",
    prompt: `(${k}√${b})² equals`,
    correct: String(k * k * b),
    distractors: nearMiss(k * k * b, [k * b, k * k, inside + k]),
    explanation: `(${k}√${b})² = ${k * k} × ${b} = ${k * k * b}.`,
  });
}

const FAMILIES_FN = [
  quadratic,
  linear,
  ap,
  distance,
  pythagoras,
  mean,
  probability,
  simpleInterest,
  commercial,
  circles,
  solids,
  heights,
  hcfLcm,
  variation,
  motion,
  surds,
];

export function mathsQuestion(board: string, index: number): Question {
  const i = Math.max(0, Math.floor(index));
  const family = i % FAMILIES;
  const local = Math.floor(i / FAMILIES);
  return FAMILIES_FN[family]!(board, i, local);
}
