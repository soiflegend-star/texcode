import {
  binom,
  buildMcq,
  combinadic,
  pickFromPools,
  questionRng,
  type Question,
} from "./core.ts";

type Country = { name: string; capital: string; continent: string; currency: string };

const COUNTRIES: Country[] = [
  ["India", "New Delhi", "Asia", "Indian rupee"],
  ["China", "Beijing", "Asia", "yuan"],
  ["Japan", "Tokyo", "Asia", "yen"],
  ["South Korea", "Seoul", "Asia", "won"],
  ["Indonesia", "Jakarta", "Asia", "Indonesian rupiah"],
  ["Thailand", "Bangkok", "Asia", "baht"],
  ["Vietnam", "Hanoi", "Asia", "dong"],
  ["Malaysia", "Kuala Lumpur", "Asia", "ringgit"],
  ["Singapore", "Singapore", "Asia", "Singapore dollar"],
  ["Philippines", "Manila", "Asia", "Philippine peso"],
  ["Bangladesh", "Dhaka", "Asia", "taka"],
  ["Pakistan", "Islamabad", "Asia", "Pakistani rupee"],
  ["Nepal", "Kathmandu", "Asia", "Nepalese rupee"],
  ["Bhutan", "Thimphu", "Asia", "ngultrum"],
  ["Sri Lanka", "Sri Jayawardenepura Kotte", "Asia", "Sri Lankan rupee"],
  ["Myanmar", "Naypyidaw", "Asia", "kyat"],
  ["Afghanistan", "Kabul", "Asia", "afghani"],
  ["Iran", "Tehran", "Asia", "Iranian rial"],
  ["Iraq", "Baghdad", "Asia", "Iraqi dinar"],
  ["Saudi Arabia", "Riyadh", "Asia", "Saudi riyal"],
  ["United Arab Emirates", "Abu Dhabi", "Asia", "dirham"],
  ["Qatar", "Doha", "Asia", "Qatari riyal"],
  ["Turkey", "Ankara", "Asia", "lira"],
  ["France", "Paris", "Europe", "euro"],
  ["Germany", "Berlin", "Europe", "euro"],
  ["Italy", "Rome", "Europe", "euro"],
  ["Spain", "Madrid", "Europe", "euro"],
  ["United Kingdom", "London", "Europe", "pound sterling"],
  ["Russia", "Moscow", "Europe", "rouble"],
  ["Portugal", "Lisbon", "Europe", "euro"],
  ["Netherlands", "Amsterdam", "Europe", "euro"],
  ["Belgium", "Brussels", "Europe", "euro"],
  ["Switzerland", "Bern", "Europe", "Swiss franc"],
  ["Sweden", "Stockholm", "Europe", "Swedish krona"],
  ["Norway", "Oslo", "Europe", "Norwegian krone"],
  ["Poland", "Warsaw", "Europe", "zloty"],
  ["Greece", "Athens", "Europe", "euro"],
  ["Austria", "Vienna", "Europe", "euro"],
  ["Ireland", "Dublin", "Europe", "euro"],
  ["Ukraine", "Kyiv", "Europe", "hryvnia"],
  ["Egypt", "Cairo", "Africa", "Egyptian pound"],
  ["Nigeria", "Abuja", "Africa", "naira"],
  ["Kenya", "Nairobi", "Africa", "Kenyan shilling"],
  ["South Africa", "Pretoria", "Africa", "rand"],
  ["Morocco", "Rabat", "Africa", "Moroccan dirham"],
  ["Ethiopia", "Addis Ababa", "Africa", "birr"],
  ["Ghana", "Accra", "Africa", "cedi"],
  ["Tanzania", "Dodoma", "Africa", "Tanzanian shilling"],
  ["United States", "Washington, D.C.", "North America", "US dollar"],
  ["Canada", "Ottawa", "North America", "Canadian dollar"],
  ["Mexico", "Mexico City", "North America", "Mexican peso"],
  ["Cuba", "Havana", "North America", "Cuban peso"],
  ["Brazil", "Brasília", "South America", "real"],
  ["Argentina", "Buenos Aires", "South America", "Argentine peso"],
  ["Chile", "Santiago", "South America", "Chilean peso"],
  ["Peru", "Lima", "South America", "sol"],
  ["Colombia", "Bogotá", "South America", "Colombian peso"],
  ["Australia", "Canberra", "Oceania", "Australian dollar"],
  ["New Zealand", "Wellington", "Oceania", "New Zealand dollar"],
].map(([name, capital, continent, currency]) => ({ name, capital, continent, currency }));

const STATES: Array<{ name: string; capital: string }> = [
  ["Andhra Pradesh", "Amaravati"],
  ["Arunachal Pradesh", "Itanagar"],
  ["Assam", "Dispur"],
  ["Bihar", "Patna"],
  ["Chhattisgarh", "Raipur"],
  ["Goa", "Panaji"],
  ["Gujarat", "Gandhinagar"],
  ["Haryana", "Chandigarh"],
  ["Himachal Pradesh", "Shimla"],
  ["Jharkhand", "Ranchi"],
  ["Karnataka", "Bengaluru"],
  ["Kerala", "Thiruvananthapuram"],
  ["Madhya Pradesh", "Bhopal"],
  ["Maharashtra", "Mumbai"],
  ["Manipur", "Imphal"],
  ["Meghalaya", "Shillong"],
  ["Mizoram", "Aizawl"],
  ["Nagaland", "Kohima"],
  ["Odisha", "Bhubaneswar"],
  ["Punjab", "Chandigarh"],
  ["Rajasthan", "Jaipur"],
  ["Sikkim", "Gangtok"],
  ["Tamil Nadu", "Chennai"],
  ["Telangana", "Hyderabad"],
  ["Tripura", "Agartala"],
  ["Uttar Pradesh", "Lucknow"],
  ["Uttarakhand", "Dehradun"],
  ["West Bengal", "Kolkata"],
].map(([name, capital]) => ({ name, capital }));

const FACTS: Array<{ topic: string; prompt: string; correct: string; distractors: string[]; explanation: string }> = [
  { topic: "India", prompt: "The national anthem of India was written by", correct: "Rabindranath Tagore", distractors: ["Bankim Chandra Chatterjee", "Mahatma Gandhi", "Sarojini Naidu"], explanation: "Jana Gana Mana was written by Rabindranath Tagore. Vande Mataram was written by Bankim Chandra Chatterjee." },
  { topic: "India", prompt: "India became a republic on", correct: "26 January 1950", distractors: ["15 August 1947", "26 January 1930", "2 October 1869"], explanation: "The Constitution came into force on 26 January 1950. Independence Day is 15 August 1947." },
  { topic: "India", prompt: "The first President of India was", correct: "Rajendra Prasad", distractors: ["Jawaharlal Nehru", "S. Radhakrishnan", "B. R. Ambedkar"], explanation: "Dr Rajendra Prasad was the first President. Nehru was the first Prime Minister." },
  { topic: "India", prompt: "The first Prime Minister of India was", correct: "Jawaharlal Nehru", distractors: ["Sardar Patel", "Rajendra Prasad", "Lal Bahadur Shastri"], explanation: "Jawaharlal Nehru became Prime Minister in 1947." },
  { topic: "India", prompt: "The chairman of the Drafting Committee of the Indian Constitution was", correct: "B. R. Ambedkar", distractors: ["Rajendra Prasad", "Jawaharlal Nehru", "Alladi Krishnaswamy"], explanation: "Dr B. R. Ambedkar chaired the Drafting Committee." },
  { topic: "World", prompt: "The largest planet in the solar system is", correct: "Jupiter", distractors: ["Saturn", "Earth", "Neptune"], explanation: "Jupiter is the largest planet. Saturn is next, with its rings." },
  { topic: "World", prompt: "The planet closest to the Sun is", correct: "Mercury", distractors: ["Venus", "Earth", "Mars"], explanation: "Order from the Sun: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune." },
  { topic: "World", prompt: "The Red Planet is", correct: "Mars", distractors: ["Venus", "Jupiter", "Mercury"], explanation: "Mars looks reddish because of iron oxide on its surface." },
  { topic: "Science", prompt: "The SI unit of force is the", correct: "newton", distractors: ["joule", "watt", "dyne as the SI unit"], explanation: "The newton is the SI unit of force. The dyne is an older CGS unit." },
  { topic: "Science", prompt: "Penicillin was discovered by", correct: "Alexander Fleming", distractors: ["Edward Jenner", "Louis Pasteur", "Robert Koch"], explanation: "Fleming observed that a Penicillium mould killed nearby bacteria." },
  { topic: "Books", prompt: "The Discovery of India was written by", correct: "Jawaharlal Nehru", distractors: ["Mahatma Gandhi", "Rabindranath Tagore", "B. R. Ambedkar"], explanation: "Nehru wrote The Discovery of India while in prison." },
  { topic: "Books", prompt: "My Experiments with Truth is the autobiography of", correct: "Mahatma Gandhi", distractors: ["Jawaharlal Nehru", "Subhas Chandra Bose", "A. P. J. Abdul Kalam"], explanation: "Gandhi’s autobiography is The Story of My Experiments with Truth." },
  { topic: "India", prompt: "The national bird of India is the", correct: "peacock", distractors: ["parrot", "eagle", "swan"], explanation: "The Indian peafowl is the national bird. The tiger is the national animal and the lotus the national flower." },
  { topic: "India", prompt: "The national animal of India is the", correct: "tiger", distractors: ["lion", "elephant", "peacock"], explanation: "The Bengal tiger is the national animal." },
  { topic: "India", prompt: "The national flower of India is the", correct: "lotus", distractors: ["rose", "jasmine", "sunflower"], explanation: "The lotus is the national flower." },
];

function rngFor(index: number) {
  return questionRng(`gk|${index}`);
}

function capitalQuestion(index: number, local: number): Question {
  const rng = rngFor(index);
  const ways = binom(COUNTRIES.length - 1, 3);
  const m = local % (COUNTRIES.length * ways);
  const ci = m % COUNTRIES.length;
  const wi = Math.floor(m / COUNTRIES.length);
  const country = COUNTRIES[ci]!;
  const pool = COUNTRIES.filter((_, i) => i !== ci).map((c) => c.capital);
  const distractors = combinadic(3, wi).map((i) => pool[i]!);
  return buildMcq(rng, {
    id: `cap-${index}`,
    topic: "World capitals",
    prompt: `What is the capital of ${country.name}?`,
    correct: country.capital,
    distractors,
    explanation: `The capital of ${country.name} is ${country.capital}.`,
  });
}

function reverseCapital(index: number, local: number): Question {
  const rng = rngFor(index);
  const ways = binom(COUNTRIES.length - 1, 3);
  const m = local % (COUNTRIES.length * ways);
  const ci = m % COUNTRIES.length;
  const wi = Math.floor(m / COUNTRIES.length);
  const country = COUNTRIES[ci]!;
  const pool = COUNTRIES.filter((_, i) => i !== ci).map((c) => c.name);
  const distractors = combinadic(3, wi).map((i) => pool[i]!);
  return buildMcq(rng, {
    id: `rcap-${index}`,
    topic: "World capitals",
    prompt: `${country.capital} is the capital of which country?`,
    correct: country.name,
    distractors,
    explanation: `${country.capital} is the capital of ${country.name}.`,
  });
}

function currencyQuestion(index: number, local: number): Question {
  const rng = rngFor(index);
  const currencies = [...new Set(COUNTRIES.map((c) => c.currency))];
  const ways = binom(currencies.length - 1, 3);
  const m = local % (COUNTRIES.length * ways);
  const country = COUNTRIES[m % COUNTRIES.length]!;
  const wi = Math.floor(m / COUNTRIES.length) % ways;
  const pool = currencies.filter((c) => c !== country.currency);
  const distractors = combinadic(3, wi).map((i) => pool[i]!);
  return buildMcq(rng, {
    id: `cur-${index}`,
    topic: "Currency",
    prompt: `What is the currency of ${country.name}?`,
    correct: country.currency,
    distractors,
    explanation: `${country.name} uses the ${country.currency}.`,
  });
}

function continentOdd(index: number, local: number): Question {
  const rng = rngFor(index);
  const groups = ["Asia", "Europe", "Africa"];
  const group = groups[local % groups.length]!;
  const sub = Math.floor(local / groups.length);
  const inside = COUNTRIES.filter((c) => c.continent === group);
  const outside = COUNTRIES.filter((c) => c.continent !== group);
  const picked = pickFromPools(outside, inside, sub);
  return buildMcq(rng, {
    id: `cont-${index}`,
    topic: "Continents",
    prompt: `Which of these countries is not in ${group}?`,
    correct: picked.right.name,
    distractors: picked.wrongs.map((c) => c.name),
    explanation: `${picked.right.name} is in ${picked.right.continent}. The other three are in ${group}.`,
  });
}

function stateCapital(index: number, local: number): Question {
  const rng = rngFor(index);
  const capitals = [...new Set(STATES.map((s) => s.capital))];
  const state = STATES[local % STATES.length]!;
  const pool = capitals.filter((c) => c !== state.capital);
  const ways = binom(pool.length, 3);
  const wi = Math.floor(local / STATES.length) % ways;
  const distractors = combinadic(3, wi).map((i) => pool[i]!);
  return buildMcq(rng, {
    id: `st-${index}`,
    topic: "Indian states",
    prompt: `What is the capital of ${state.name}?`,
    correct: state.capital,
    distractors,
    explanation: `The capital of ${state.name} is ${state.capital}.`,
  });
}

export function gkQuestion(index: number): Question {
  const i = Math.max(0, Math.floor(index));
  const mode = i % 5;
  const local = Math.floor(i / 5);
  if (mode === 4) {
    const fact = FACTS[local % FACTS.length]!;
    const variant = Math.floor(local / FACTS.length);
    return buildMcq(rngFor(i), {
      id: `gf-${i}`,
      ...fact,
      prompt: variant === 0 ? fact.prompt : `Knowledge check ${variant + 1}: ${fact.prompt}`,
    });
  }
  if (mode === 0) return capitalQuestion(i, local);
  if (mode === 1) return reverseCapital(i, local);
  if (mode === 2) return currencyQuestion(i, local);
  if (mode === 3) return continentOdd(i, local);
  return stateCapital(i, local);
}
