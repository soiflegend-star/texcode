/**
 * Curated syllabus map for QUBRIX.
 *
 * Scope: WBBSE Class X (2026-27 summary cross-checked against the published
 * subject-wise syllabus overview). This is a curriculum index, NOT a claim
 * that the current generators already contain a verified question for every
 * listed item. `generatorTags` are exact existing engine tags only; an empty
 * list means content must be authored/reviewed before the topic is quiz-enabled.
 */
export type CurriculumTopic = {
  id: string;
  title: string;
  syllabusLabel: string;
  /** Exact generator tags (as produced by topicsFor(subject)) that belong to this chapter. */
  generatorTags: string[];
  contentStatus: "seeded-needs-review" | "content-needed";
  /** What a learner should be able to do. Written by QUBRIX from the syllabus label, not copied from a textbook. */
  objective: string;
};
export type CurriculumSubject = {
  id: string;
  title: string;
  topics: CurriculumTopic[];
};

const topic = (id: string, title: string, syllabusLabel: string, generatorTags: string[] = [], objective = ""): CurriculumTopic => ({
  id, title, syllabusLabel, generatorTags,
  objective: objective || `Practise and revise: ${syllabusLabel}.`,
  contentStatus: generatorTags.length ? "seeded-needs-review" : "content-needed",
});

/**
 * Tag mapping rules (v3): a generator tag is attached to a chapter only when its
 * name clearly belongs to that chapter. Tags that exist in the generators but are not
 * part of the Class X syllabus summary (e.g. Probability, Gravitation) are NOT mapped,
 * so they never appear under WBBSE Class X. Chapters with no clearly matching tag are
 * `content-needed` and serve no generated questions.
 */
export const WBBSE_CLASS_10_2026_27: CurriculumSubject[] = [
  {
    id: "maths", title: "Mathematics", topics: [
      topic("arithmetic", "Arithmetic", "Simple interest; compound interest and uniform rate of increase or decrease; partnership business", ["Simple interest", "Profit and loss", "Percentage"], "Solve interest, profit-and-loss and percentage problems. (Compound interest and partnership questions are authored only; the generators do not cover them.)"),
      topic("algebra", "Algebra", "Quadratic equation in one variable; variation; quadratic surd; ratio and proportion", ["Quadratic equations", "Quadratic surds", "Variation"], "Solve quadratic equations, simplify quadratic surds and work with direct and inverse variation."),
      topic("geometry", "Geometry", "Application of theorems; construction of circumcircle and incircle of a triangle", ["Circles", "Right triangles"], "Apply circle and right-triangle theorems. (Constructions are not testable as MCQs.)"),
      topic("trigonometry", "Trigonometry", "Measurement of angles; trigonometric ratios and identities; complementary angles; heights and distances", ["Trigonometry", "Heights and distances"], "Use trigonometric ratios and identities and solve heights-and-distances problems."),
      topic("mensuration", "Mensuration", "Cuboid; right circular cylinder; sphere; right circular cone; solids", ["Surface areas and volumes"], "Compute surface areas and volumes of standard solids."),
      topic("statistics", "Statistics", "Mean; median; ogive; mode", ["Statistics"], "Find and interpret the mean, median and mode of data."),
    ],
  },
  {
    id: "physical-science", title: "Physical Science & Environment", topics: [
      topic("environment", "Concerns about Our Environment", "Concerns about Our Environment"),
      topic("gases", "Behaviour of Gases", "Behaviour of Gases"),
      topic("chemical-calculations", "Chemical Calculations", "Chemical Calculations", ["Mole concept"], "Use the mole concept and molar masses in chemical calculations."),
      topic("thermal-phenomena", "Thermal Phenomena", "Thermal Phenomena", ["Heat"], "Apply specific heat, latent heat and heat transfer ideas."),
      topic("light", "Light", "Light", ["Light"], "Apply reflection, refraction, mirrors and lenses."),
      topic("current-electricity", "Current Electricity", "Current Electricity", ["Electricity"], "Apply Ohm's law, resistance combinations, power and energy."),
      topic("atomic-nucleus", "Atomic Nucleus", "Atomic Nucleus"),
      topic("periodic-table", "Periodic Table and Periodicity", "Periodic Table and Periodicity of the Properties of Elements", ["Periodic table"], "Relate position in the periodic table to properties."),
      topic("bonding", "Ionic and Covalent Bonding", "Ionic and Covalent Bonding"),
      topic("electricity-chemical-reactions", "Electricity and Chemical Reactions", "Electricity and Chemical Reactions"),
      topic("inorganic-lab-industry", "Inorganic Chemistry in the Laboratory and in Industry", "Inorganic Chemistry in the Laboratory and in Industry"),
      topic("metallurgy", "Metallurgy", "Metallurgy", ["Metals"], "Describe the properties, extraction and reactivity of metals."),
      topic("organic-chemistry", "Organic Chemistry", "Organic Chemistry", ["Carbon"], "Describe carbon compounds and their classification."),
    ],
  },
  {
    id: "life", title: "Life Science & Environment", topics: [
      topic("control-coordination", "Control and Coordination in Living Organisms", "Control and Coordination in Living Organisms", ["Control and coordination"], "Describe nervous and hormonal control in organisms."),
      topic("continuity-life", "Continuity of Life", "Continuity of life", ["Reproduction"], "Explain reproduction and the continuity of life."),
      topic("heredity", "Heredity and Genetic Diseases", "Heredity and some common genetic diseases", ["Heredity"], "Apply Mendel's laws and explain inheritance."),
      topic("evolution-adaptation", "Evolution and Adaptation", "Evolution and adaptation", ["Evolution"], "Explain evidence for evolution and adaptation."),
      topic("environment-conservation", "Environment and Conservation", "Environment, its resources and their conservation", ["Our environment"], "Explain ecosystems, resources and conservation."),
    ],
  },
  {
    id: "geography", title: "Geography & Environment", topics: [
      topic("exogenetic-processes", "Exogenetic Processes and Landforms", "Exogenetic processes and resultant landforms"),
      topic("atmosphere", "Atmosphere", "Atmosphere"),
      topic("hydrosphere", "Hydrosphere", "Hydrosphere"),
      topic("waste-management", "Waste Management", "Waste management"),
      topic("india", "India", "India", ["India", "Rivers", "Agriculture", "Minerals", "Resources", "Soils"], "Describe India's rivers, soils, agriculture, minerals and resources."),
      topic("maps-imagery", "Satellite Imagery and Topographical Map", "Satellite imagery and Topographical map"),
      topic("map-work", "Map Work (India)", "Map work (India)"),
    ],
  },
  {
    id: "english", title: "English", topics: [
      topic("prose", "Prose", "Prescribed prose from Splendour"),
      topic("poetry", "Poetry", "Prescribed poetry from Splendour"),
      topic("rapid-reader", "Rapid Reader", "The Hound of the Baskervilles"),
      topic("grammar-rhetoric", "Grammar and Rhetoric", "Grammar and Rhetoric", ["Tense", "Articles", "Prepositions", "Subject-verb agreement", "Active and passive voice"], "Use tenses, articles, prepositions, agreement and voice correctly."),
      topic("writing", "Writing", "Writing skills"),
    ],
  },
  {
    id: "history", title: "History & Environment", topics: [
      topic("history-syllabus-pending", "Chapter mapping required", "Use the current WBBSE prescribed History & Environment syllabus before authoring chapter questions"),
    ],
  },
  {
    id: "bengali", title: "Bengali (First Language)", topics: [
      topic("bengali-syllabus-pending", "Chapter mapping required", "Use the current WBBSE prescribed First Language syllabus and textbook before authoring chapter questions"),
    ],
  },
];

export function curriculumFor(boardId: string, grade: number): CurriculumSubject[] {
  return boardId === "wbbse" && grade === 10 ? WBBSE_CLASS_10_2026_27 : [];
}

export function curriculumTopicStatus(boardId: string, grade: number, subjectId: string, topicId: string): CurriculumTopic["contentStatus"] | undefined {
  return curriculumFor(boardId, grade).find((s) => s.id === subjectId)?.topics.find((t) => t.id === topicId)?.contentStatus;
}
