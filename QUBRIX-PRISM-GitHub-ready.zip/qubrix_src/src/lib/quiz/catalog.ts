export type BoardInfo = {
  id: string;
  name: string;
  exam: string;
  region: string;
};

export type SubjectInfo = {
  id: string;
  name: string;
  blurb: string;
};

export const BOARDS: BoardInfo[] = [
  { id: "wbbse", name: "WBBSE", exam: "Madhyamik", region: "West Bengal" },
  { id: "crt", name: "CRT", exam: "Curriculum mapping pending", region: "Board catalogue" },
  { id: "cbse", name: "CBSE", exam: "Class 10 board", region: "National" },
  { id: "icse", name: "ICSE", exam: "Class 10", region: "National" },
  { id: "bseb", name: "BSEB", exam: "Matriculation", region: "Bihar" },
  { id: "upmsp", name: "UP Board", exam: "High school", region: "Uttar Pradesh" },
  { id: "msbshse", name: "Maharashtra SSC", exam: "SSC", region: "Maharashtra" },
  { id: "tn", name: "Tamil Nadu Board", exam: "SSLC", region: "Tamil Nadu" },
  { id: "kerala", name: "Kerala Board", exam: "SSLC", region: "Kerala" },
];

const MATHS: SubjectInfo = {
  id: "maths",
  name: "Mathematics",
  blurb: "Quadratics, variation, mensuration, trigonometry, statistics",
};

const PHYSICS: SubjectInfo = {
  id: "physics",
  name: "Physics",
  blurb: "Motion, force, light, electricity, heat and sound",
};

const CHEMISTRY: SubjectInfo = {
  id: "chemistry",
  name: "Chemistry",
  blurb: "Atoms, moles, reactions, acids and the periodic table",
};

const HISTORY: SubjectInfo = {
  id: "history",
  name: "History",
  blurb: "National movement and the making of the modern world",
};

const GEOGRAPHY: SubjectInfo = {
  id: "geography",
  name: "Geography",
  blurb: "Rivers, resources, crops, soils and the Tropic of Cancer",
};

const ENGLISH: SubjectInfo = {
  id: "english",
  name: "English",
  blurb: "Grammar: articles, tense, agreement, voice, prepositions",
};

export function subjectsFor(boardId: string): SubjectInfo[] {
  const lifeName = boardId === "wbbse" ? "Life Science" : "Biology";
  const life: SubjectInfo = {
    id: "life",
    name: lifeName,
    blurb: "Life processes, control, heredity, environment",
  };
  const physical: SubjectInfo = {
    id: "physical-science",
    name: "Physical Science",
    blurb: "Madhyamik mix of physics and chemistry",
  };
  const science: SubjectInfo = {
    id: "science",
    name: "Science",
    blurb: "Physics, chemistry and biology in one paper",
  };
  if (boardId === "wbbse") {
    return [MATHS, physical, PHYSICS, CHEMISTRY, life, HISTORY, GEOGRAPHY, ENGLISH];
  }
  return [MATHS, science, PHYSICS, CHEMISTRY, life, HISTORY, GEOGRAPHY, ENGLISH];
}

export function boardById(id: string): BoardInfo | undefined {
  return BOARDS.find((b) => b.id === id);
}

export function subjectById(boardId: string, subjectId: string): SubjectInfo | undefined {
  if (subjectId === "gk") {
    return {
      id: "gk",
      name: "General knowledge",
      blurb: "Capitals, currency, India and the world",
    };
  }
  return subjectsFor(boardId).find((s) => s.id === subjectId);
}
