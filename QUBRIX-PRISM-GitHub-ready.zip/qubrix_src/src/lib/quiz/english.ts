import { buildMcq, questionRng, type Question } from "./core.ts";

const PEOPLE = [
  "Riya",
  "Arjun",
  "The teacher",
  "The nurse",
  "The farmer",
  "The clerk",
  "My uncle",
  "The artist",
  "The coach",
  "The scientist",
  "Amina",
  "The librarian",
  "The pilot",
  "The gardener",
  "The captain",
  "Neha",
  "The poet",
  "The mechanic",
  "The doctor",
  "The student",
];

const GROUPS = [
  "The students",
  "The players",
  "The workers",
  "The children",
  "The birds",
  "The nurses",
  "The farmers",
  "My friends",
  "The artists",
  "The clerks",
];

const VERBS = [
  { s: "writes", p: "write", ing: "writing", pp: "written", past: "wrote", rest: "a letter" },
  { s: "paints", p: "paint", ing: "painting", pp: "painted", past: "painted", rest: "a mural" },
  { s: "carries", p: "carry", ing: "carrying", pp: "carried", past: "carried", rest: "the parcels" },
  { s: "checks", p: "check", ing: "checking", pp: "checked", past: "checked", rest: "the notebooks" },
  { s: "repairs", p: "repair", ing: "repairing", pp: "repaired", past: "repaired", rest: "the bicycle" },
  { s: "collects", p: "collect", ing: "collecting", pp: "collected", past: "collected", rest: "the samples" },
  { s: "opens", p: "open", ing: "opening", pp: "opened", past: "opened", rest: "the window" },
  { s: "delivers", p: "deliver", ing: "delivering", pp: "delivered", past: "delivered", rest: "the letters" },
];

const PASS_VERBS = [
  { past: "checked", pp: "checked" },
  { past: "collected", pp: "collected" },
  { past: "painted", pp: "painted" },
  { past: "cleaned", pp: "cleaned" },
  { past: "repaired", pp: "repaired" },
  { past: "counted", pp: "counted" },
  { past: "delivered", pp: "delivered" },
  { past: "opened", pp: "opened" },
  { past: "closed", pp: "closed" },
  { past: "observed", pp: "observed" },
];

const OBJECTS = [
  { text: "the notebook", plural: false },
  { text: "the window", plural: false },
  { text: "the bicycle", plural: false },
  { text: "the parcel", plural: false },
  { text: "the letter", plural: false },
  { text: "the notebooks", plural: true },
  { text: "the windows", plural: true },
  { text: "the bicycles", plural: true },
  { text: "the parcels", plural: true },
  { text: "the letters", plural: true },
  { text: "the samples", plural: true },
  { text: "the mural", plural: false },
];

const ARTICLES: Array<{ noun: string; article: "a" | "an"; why: string }> = [
  { noun: "owl", article: "an", why: "Owl begins with a vowel sound." },
  { noun: "hour", article: "an", why: "The h in hour is silent, so the word begins with a vowel sound." },
  { noun: "university", article: "a", why: "University begins with a “yoo” sound, which is a consonant sound." },
  { noun: "umbrella", article: "an", why: "Umbrella begins with a vowel sound." },
  { noun: "uniform", article: "a", why: "Uniform begins with a “yoo” sound." },
  { noun: "elephant", article: "an", why: "Elephant begins with a vowel sound." },
  { noun: "apple", article: "an", why: "Apple begins with a vowel sound." },
  { noun: "book", article: "a", why: "Book begins with a consonant sound." },
  { noun: "honest answer", article: "an", why: "The h in honest is silent." },
  { noun: "European tour", article: "a", why: "European begins with a “yoo” sound." },
  { noun: "X-ray", article: "an", why: "X-ray begins with an “eks” sound." },
  { noun: "one-rupee coin", article: "a", why: "One begins with a “w” sound." },
  { noun: "heir", article: "an", why: "The h in heir is silent." },
  { noun: "house", article: "a", why: "House begins with a pronounced h." },
  { noun: "orange", article: "an", why: "Orange begins with a vowel sound." },
  { noun: "useful tool", article: "a", why: "Useful begins with a “yoo” sound." },
  { noun: "igloo", article: "an", why: "Igloo begins with a vowel sound." },
  { noun: "year", article: "a", why: "Year begins with a consonant sound." },
  { noun: "M.A. degree", article: "an", why: "M is said “em”, a vowel sound." },
  { noun: "red pen", article: "a", why: "Red begins with a consonant sound." },
];

const PREPS: Array<{ sentence: string; answer: string; why: string }> = [
  { sentence: "She is good ___ mathematics.", answer: "at", why: "We say good at a subject." },
  { sentence: "He is interested ___ music.", answer: "in", why: "Interested is followed by in." },
  { sentence: "They are fond ___ cricket.", answer: "of", why: "Fond is followed by of." },
  { sentence: "I am proud ___ my school.", answer: "of", why: "Proud is followed by of." },
  { sentence: "The child is afraid ___ the dark.", answer: "of", why: "Afraid is followed by of." },
  { sentence: "Please listen ___ the announcement.", answer: "to", why: "Listen is followed by to." },
  { sentence: "We depend ___ the monsoon.", answer: "on", why: "Depend is followed by on." },
  { sentence: "This book belongs ___ Neha.", answer: "to", why: "Belong is followed by to." },
  { sentence: "The team consists ___ eleven players.", answer: "of", why: "Consist is followed by of." },
  { sentence: "The jar is full ___ water.", answer: "of", why: "Full is followed by of." },
  { sentence: "She is capable ___ hard work.", answer: "of", why: "Capable is followed by of." },
  { sentence: "Kolkata is famous ___ its sweets.", answer: "for", why: "Famous is followed by for." },
  { sentence: "He is married ___ a doctor.", answer: "to", why: "Married is followed by to." },
  { sentence: "I agree ___ my teacher.", answer: "with", why: "Agree with a person. Agree to a proposal." },
  { sentence: "She is suffering ___ a cold.", answer: "from", why: "Suffer is followed by from." },
  { sentence: "Please look ___ the baby.", answer: "after", why: "Look after means to take care of." },
];

const TENSES = ["simple present", "present continuous", "present perfect", "simple past", "past continuous", "simple future", "past perfect"] as const;

function rngFor(board: string, index: number) {
  return questionRng(`eng|${board}|${index}`);
}

function sentenceFor(subject: string, plural: boolean, verb: (typeof VERBS)[number], tense: (typeof TENSES)[number]): string {
  const be = plural ? "are" : "is";
  const was = plural ? "were" : "was";
  const has = plural ? "have" : "has";
  const main = plural ? verb.p : verb.s;
  switch (tense) {
    case "simple present":
      return `${subject} ${main} ${verb.rest}.`;
    case "present continuous":
      return `${subject} ${be} ${verb.ing} ${verb.rest}.`;
    case "present perfect":
      return `${subject} ${has} ${verb.pp} ${verb.rest}.`;
    case "simple past":
      return `${subject} ${verb.past} ${verb.rest}.`;
    case "past continuous":
      return `${subject} ${was} ${verb.ing} ${verb.rest}.`;
    case "simple future":
      return `${subject} will ${verb.p} ${verb.rest}.`;
    case "past perfect":
      return `${subject} had ${verb.pp} ${verb.rest}.`;
  }
}

function tenseQuestion(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const tense = TENSES[local % TENSES.length]!;
  const n = Math.floor(local / TENSES.length);
  const plural = n % 2 === 1;
  const people = plural ? GROUPS : PEOPLE;
  const subject = people[Math.floor(n / 2) % people.length]!;
  const verb = VERBS[Math.floor(n / (2 * people.length)) % VERBS.length]!;
  const line = sentenceFor(subject, plural, verb, tense);
  const distractors = TENSES.filter((t) => t !== tense).slice(0, 3);
  return buildMcq(rng, {
    id: `ten-${index}`,
    topic: "Tense",
    prompt: `Name the tense: “${line}”`,
    correct: tense,
    distractors: [...distractors],
    explanation: `“${line}” is ${tense}.`,
  });
}

function agreement(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const plural = local % 2 === 1;
  const n = Math.floor(local / 2);
  const people = plural ? GROUPS : PEOPLE;
  const subject = people[n % people.length]!;
  const verb = VERBS[Math.floor(n / people.length) % VERBS.length]!;
  const correct = `${subject} ${plural ? verb.p : verb.s} ${verb.rest}.`;
  const wrongVerb = `${subject} ${plural ? verb.s : verb.p} ${verb.rest}.`;
  const broken = `${subject} ${verb.ing} ${verb.rest}.`;
  const broken2 = plural
    ? `${subject} doesn't ${verb.p} ${verb.rest}.`
    : `${subject} don't ${verb.s} ${verb.rest}.`;
  return buildMcq(rng, {
    id: `agr-${index}`,
    topic: "Subject-verb agreement",
    prompt: "Which sentence is grammatically correct?",
    correct,
    distractors: [wrongVerb, broken, broken2],
    explanation: plural
      ? `A plural subject takes the plural verb “${verb.p}”. ${correct}`
      : `A singular subject takes “${verb.s}”. ${correct}`,
  });
}

function passive(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const toPassiveVoice = local % 2 === 0;
  const n = Math.floor(local / 2);
  const subject = PEOPLE[n % PEOPLE.length]!;
  const verb = PASS_VERBS[Math.floor(n / PEOPLE.length) % PASS_VERBS.length]!;
  const object = OBJECTS[Math.floor(n / (PEOPLE.length * PASS_VERBS.length)) % OBJECTS.length]!;
  const was = object.plural ? "were" : "was";
  const active = `${subject} ${verb.past} ${object.text}.`;
  const passiveLine = `${cap(object.text)} ${was} ${verb.pp} by ${subject}.`;
  const badWas = `${cap(object.text)} ${object.plural ? "was" : "were"} ${verb.pp} by ${subject}.`;
  if (toPassiveVoice) {
    return buildMcq(rng, {
      id: `pas-${index}`,
      topic: "Active and passive voice",
      prompt: `Choose the correct passive form of “${active}”`,
      correct: passiveLine,
      distractors: [
        badWas,
        `${subject} ${was} ${verb.pp} by ${object.text}.`,
        `${cap(object.text)} ${was} ${verb.pp} ${subject}.`,
      ],
      explanation: `The object becomes the subject. ${passiveLine}`,
    });
  }
  return buildMcq(rng, {
    id: `pas-${index}`,
    topic: "Active and passive voice",
    prompt: `Choose the correct active form of “${passiveLine}”`,
    correct: active,
    distractors: [
      `${cap(object.text)} ${verb.past} ${subject}.`,
      `${subject} ${was} ${verb.pp} by ${object.text}.`,
      `${object.text} ${verb.past} by ${subject}.`,
    ],
    explanation: `The doer comes back to the front of the sentence. ${active}`,
  });
}

function cap(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function articles(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const row = ARTICLES[local % ARTICLES.length]!;
  const frame = Math.floor(local / ARTICLES.length);
  const frames = [
    `She saw ___ ${row.noun}.`,
    `Please bring ___ ${row.noun}.`,
    `This is ___ ${row.noun}.`,
    `He bought ___ ${row.noun}.`,
  ];
  const prompt = frames[frame % frames.length]!;
  const round = Math.floor(frame / frames.length);
  return buildMcq(rng, {
    id: `art-${index}`,
    topic: "Articles",
    prompt: `For a first mention, choose the article: “${prompt}”${round ? ` (${round + 1})` : ""}`,
    correct: row.article,
    distractors: ["a", "an", "the", "no article"].filter((x) => x !== row.article),
    explanation: `${row.why} Use “${row.article}” for the first mention of one item. “The” would mean it is already known.`,
  });
}

function prepositions(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const row = PREPS[local % PREPS.length]!;
  const who = PEOPLE[Math.floor(local / PREPS.length) % PEOPLE.length];
  const sentence = row.sentence.replace("She", who).replace("He", who).replace("They", who).replace("I", who);
  const round = Math.floor(local / (PREPS.length * PEOPLE.length));
  const options = ["at", "in", "on", "of", "to", "for", "with", "from", "after"];
  const distractors = options.filter((o) => o !== row.answer).slice(0, 3);
  return buildMcq(rng, {
    id: `prep-${index}`,
    topic: "Prepositions",
    prompt: `Fill the blank: “${sentence}”${round ? ` (practice ${round + 1})` : ""}`,
    correct: row.answer,
    distractors,
    explanation: row.why,
  });
}

function spelling(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const rows = [
    { correct: "necessary", wrong: ["neccessary", "necessery", "necesary"] },
    { correct: "separate", wrong: ["seperate", "separete", "seperete"] },
    { correct: "definite", wrong: ["definate", "definiete", "defenite"] },
    { correct: "occurrence", wrong: ["occurence", "ocurrance", "occurance"] },
    { correct: "accommodate", wrong: ["acommodate", "accomodate", "acomodate"] },
    { correct: "receive", wrong: ["recieve", "receeve", "recive"] },
    { correct: "believe", wrong: ["beleive", "belive", "beleave"] },
    { correct: "grammar", wrong: ["grammer", "gramar", "grammor"] },
    { correct: "environment", wrong: ["enviroment", "enviornment", "environmant"] },
    { correct: "immediately", wrong: ["immediatly", "imediately", "immedietly"] },
    { correct: "beginning", wrong: ["begining", "beggining", "begening"] },
    { correct: "knowledge", wrong: ["knowlege", "knowladge", "knowlidge"] },
  ];
  const row = rows[local % rows.length]!;
  const round = Math.floor(local / rows.length);
  return buildMcq(rng, {
    id: `sp-${index}`,
    topic: "Spelling",
    prompt: `Choose the correct spelling${round ? ` (set ${round + 1})` : ""}.`,
    correct: row.correct,
    distractors: row.wrong,
    explanation: `The correct spelling is “${row.correct}”.`,
  });
}

export function englishQuestion(board: string, index: number): Question {
  const i = Math.max(0, Math.floor(index));
  const family = i % 6;
  const local = Math.floor(i / 6);
  if (family === 0) return passive(board, i, local);
  if (family === 1) return agreement(board, i, local);
  if (family === 2) return tenseQuestion(board, i, local);
  if (family === 3) return articles(board, i, local);
  if (family === 4) return prepositions(board, i, local);
  return spelling(board, i, local);
}
