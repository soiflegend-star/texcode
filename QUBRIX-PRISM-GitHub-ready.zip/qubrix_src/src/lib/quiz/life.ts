import {
  buildMcq,
  factorial,
  frac,
  combinadic,
  binom,
  nearMiss,
  pickFromPools,
  questionRng,
  type Question,
} from "./core.ts";

export type Org = {
  name: string;
  group: string;
  animal: boolean;
  warm: boolean;
  heart: 2 | 3 | 4 | null;
  eggs: boolean | null;
  nutrition: "autotroph" | "heterotroph" | "saprophyte" | "parasite";
};

export const organisms: Org[] = [
  ...["human", "tiger", "cow", "whale", "bat", "dolphin", "rat", "elephant", "dog", "cat", "horse", "goat", "rabbit", "monkey", "deer"].map(
    (name) => org(name, "mammal", true, true, 4, false, "heterotroph"),
  ),
  ...["sparrow", "crow", "pigeon", "ostrich", "penguin", "parrot", "peacock", "duck", "owl", "hen", "eagle"].map((name) =>
    org(name, "bird", true, true, 4, true, "heterotroph"),
  ),
  org("lizard", "reptile", true, false, 3, true, "heterotroph"),
  org("snake", "reptile", true, false, 3, true, "heterotroph"),
  org("turtle", "reptile", true, false, 3, true, "heterotroph"),
  org("crocodile", "reptile", true, false, 4, true, "heterotroph"),
  org("chameleon", "reptile", true, false, 3, true, "heterotroph"),
  org("frog", "amphibian", true, false, 3, true, "heterotroph"),
  org("toad", "amphibian", true, false, 3, true, "heterotroph"),
  org("salamander", "amphibian", true, false, 3, true, "heterotroph"),
  org("rohu", "fish", true, false, 2, true, "heterotroph"),
  org("hilsa", "fish", true, false, 2, true, "heterotroph"),
  org("goldfish", "fish", true, false, 2, true, "heterotroph"),
  org("shark", "fish", true, false, 2, null, "heterotroph"),
  ...["butterfly", "honeybee", "mosquito", "cockroach", "ant", "housefly", "silkworm"].map((name) =>
    org(name, "insect", true, false, null, true, "heterotroph"),
  ),
  ...["mango", "neem", "rice plant", "wheat plant", "cactus", "lotus", "banyan", "rose", "fern", "moss"].map((name) =>
    org(name, "plant", false, false, null, null, "autotroph"),
  ),
  org("cuscuta", "plant", false, false, null, null, "parasite"),
  org("yeast", "fungus", false, false, null, null, "saprophyte"),
  org("mushroom", "fungus", false, false, null, null, "saprophyte"),
  org("bread mould", "fungus", false, false, null, null, "saprophyte"),
  org("Penicillium", "fungus", false, false, null, null, "saprophyte"),
  org("Lactobacillus", "bacterium", false, false, null, null, "heterotroph"),
  org("Rhizobium", "bacterium", false, false, null, null, "heterotroph"),
  org("Vibrio cholerae", "bacterium", false, false, null, null, "parasite"),
  org("Amoeba", "protist", false, false, null, null, "heterotroph"),
  org("Plasmodium", "protist", false, false, null, null, "parasite"),
];

function org(
  name: string,
  group: string,
  animal: boolean,
  warm: boolean,
  heart: 2 | 3 | 4 | null,
  eggs: boolean | null,
  nutrition: Org["nutrition"],
): Org {
  return { name, group, animal, warm, heart, eggs, nutrition };
}

const PLURAL: Record<string, string> = {
  mammal: "mammals",
  bird: "birds",
  reptile: "reptiles",
  amphibian: "amphibians",
  fish: "fish",
  insect: "insects",
  plant: "plants",
  fungus: "fungi",
  bacterium: "bacteria",
};
const GROUP_LABEL: Record<string, string> = {
  mammal: "mammal",
  bird: "bird",
  reptile: "reptile",
  amphibian: "amphibian",
  fish: "fish",
  insect: "insect",
  plant: "plant",
  fungus: "fungus",
  bacterium: "bacterium",
};

const FAMILIES = 8;

function rngFor(board: string, index: number) {
  return questionRng(`life|${board}|${index}`);
}

function classQuestion(board: string, index: number, local: number, negate: boolean): Question {
  const rng = rngFor(board, index);
  const groups = Object.keys(GROUP_LABEL);
  const group = groups[local % groups.length]!;
  const sub = Math.floor(local / groups.length);
  const label = GROUP_LABEL[group]!;
  const match = organisms.filter((o) => o.group === group);
  const rest = organisms.filter((o) => o.group !== group);
  const picked = negate
    ? pickFromPools(rest, match, sub)
    : pickFromPools(match, rest, sub);
  const right = picked.right;
  return buildMcq(rng, {
    id: `cls-${index}`,
    topic: "Classification",
    prompt: negate
      ? `Which of the following is not a ${label}?`
      : `Which of the following is a ${label}?`,
    correct: right.name,
    distractors: picked.wrongs.map((o) => o.name),
    explanation: negate
      ? `${right.name} is a ${right.group}, so it is not a ${label}. The other three are ${PLURAL[group]}.`
      : `${right.name} is a ${label}. The other three are not.`,
  });
}

type Trait = {
  label: string;
  yes: (o: Org) => boolean;
  no: (o: Org) => boolean;
  because: (o: Org) => string;
};

const TRAITS: Trait[] = [
  {
    label: "warm-blooded",
    yes: (o) => o.animal && o.warm,
    no: (o) => o.animal && !o.warm,
    because: (o) =>
      `${o.name} is warm-blooded. Birds and mammals keep a steady body temperature; the other animals here do not.`,
  },
  {
    label: "an animal with a four-chambered heart",
    yes: (o) => o.heart === 4,
    no: (o) => o.heart === 2 || o.heart === 3,
    because: (o) =>
      o.name === "crocodile"
        ? "The crocodile is the familiar reptile whose heart has four chambers. Mammals and birds also do. Fish have two, and amphibians and most reptiles have three."
        : `${o.name} has a four-chambered heart. Fish have two chambers; amphibians and most reptiles have three.`,
  },
  {
    label: "an egg-laying animal",
    yes: (o) => o.eggs === true,
    no: (o) => o.eggs === false,
    because: (o) =>
      `${o.name} lays eggs. The mammals in the other options give birth to young ones.`,
  },
  {
    label: "an autotroph",
    yes: (o) => o.nutrition === "autotroph",
    no: (o) => o.nutrition !== "autotroph",
    because: (o) =>
      `${o.name} makes its own food by photosynthesis. Cuscuta is a parasitic plant and does not, and animals and fungi do not either.`,
  },
  {
    label: "a saprophyte",
    yes: (o) => o.nutrition === "saprophyte",
    no: (o) => o.nutrition !== "saprophyte",
    because: (o) => `${o.name} feeds on dead organic matter, which is what a saprophyte does.`,
  },
  {
    label: "a parasite",
    yes: (o) => o.nutrition === "parasite",
    no: (o) => o.nutrition !== "parasite",
    because: (o) => `${o.name} lives at the expense of a host, so it is a parasite.`,
  },
];

function traitQuestion(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const trait = TRAITS[local % TRAITS.length]!;
  const sub = Math.floor(local / TRAITS.length);
  const yes = organisms.filter(trait.yes);
  const no = organisms.filter(trait.no);
  const picked = pickFromPools(yes, no, sub);
  return buildMcq(rng, {
    id: `trait-${index}`,
    topic: "Classification",
    prompt: `Which of the following is ${trait.label}?`,
    correct: picked.right.name,
    distractors: picked.wrongs.map((o) => o.name),
    explanation: trait.because(picked.right),
  });
}

const TRAIT_WORDS = [
  { dom: "tall", rec: "short", gene: "height in a pea plant" },
  { dom: "yellow-seeded", rec: "green-seeded", gene: "seed colour in a pea plant" },
  { dom: "purple-flowered", rec: "white-flowered", gene: "flower colour in a pea plant" },
];

function punnett(a: string, b: string): { TT: number; Tt: number; tt: number } {
  const kids = { TT: 0, Tt: 0, tt: 0 };
  for (const x of [a[0], a[1]]) {
    for (const y of [b[0], b[1]]) {
      const hasT = x === "T" || y === "T";
      const hast = x === "t" || y === "t";
      if (hasT && hast) kids.Tt++;
      else if (hasT) kids.TT++;
      else kids.tt++;
    }
  }
  return kids;
}

function mendel(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const gts = ["TT", "Tt", "tt"];
  const kind = local % 3;
  const cross = Math.floor(local / 3) % 9;
  const ti = Math.floor(local / 27) % 3;
  const nMul = Math.floor(local / 81) + 1;
  const N = nMul * 4;
  const A = gts[Math.floor(cross / 3)]!;
  const B = gts[cross % 3]!;
  const trait = TRAIT_WORDS[ti]!;
  const kids = punnett(A, B);
  const dom = kids.TT + kids.Tt;
  const stem = `In ${trait.gene}, T is dominant (${trait.dom}) and t is recessive (${trait.rec}). A ${A} plant is crossed with a ${B} plant. Among ${N} offspring,`;
  if (kind === 0) {
    const expected = (kids.tt * N) / 4;
    return buildMcq(rng, {
      id: `men-${index}`,
      topic: "Heredity",
      prompt: `${stem} how many are expected to be ${trait.rec}?`,
      correct: String(expected),
      distractors: nearMiss(expected, [(dom * N) / 4, N, N / 2, kids.tt]),
      explanation: `The four equally likely gamete combinations give recessive genotype tt in ${kids.tt} of 4 cases. Expected ${trait.rec} offspring = ${kids.tt}/4 × ${N} = ${expected}.`,
    });
  }
  if (kind === 1) {
    const expected = (dom * N) / 4;
    return buildMcq(rng, {
      id: `men-${index}`,
      topic: "Heredity",
      prompt: `${stem} how many are expected to show the dominant phenotype (${trait.dom})?`,
      correct: String(expected),
      distractors: nearMiss(expected, [(kids.tt * N) / 4, N, kids.TT, N / 4]),
      explanation: `Dominant phenotype comes from TT or Tt, which is ${dom} of the 4 combinations. Expected = ${dom}/4 × ${N} = ${expected}.`,
    });
  }
  const percent = (kids.tt / 4) * 100;
  const choices = ["0%", "25%", "50%", "75%", "100%"].filter((s) => s !== `${percent}%`);
  return buildMcq(rng, {
    id: `men-${index}`,
    topic: "Heredity",
    prompt: `${stem} what percentage of the offspring are expected to be ${trait.rec}?`,
    correct: `${percent}%`,
    distractors: choices,
    explanation: `Probability of tt = ${kids.tt}/4 = ${percent}%. The count ${N} does not change the percentage.`,
  });
}

function energy(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const level = local % 3;
  const producer = (Math.floor(local / 3) + 1) * 1000;
  const names = ["primary consumers", "secondary consumers", "tertiary consumers"];
  const steps = level + 1;
  const answer = producer / 10 ** steps;
  return buildMcq(rng, {
    id: `en-${index}`,
    topic: "Our environment",
    prompt: `Producers in a food chain hold ${producer} kJ. Using the 10% law taught in Class 10, the energy available to ${names[level]} is about`,
    correct: `${answer} kJ`,
    distractors: nearMiss(answer, [producer, producer / 10, answer * 10, answer / 10]).map((s) => `${s} kJ`),
    explanation: `About 10% of the energy passes to the next trophic level. After ${steps} step${steps > 1 ? "s" : ""}, energy ≈ ${producer} / ${10 ** steps} = ${answer} kJ.`,
  });
}

const GENO = [
  { id: "IᴬIᴬ", a: ["IA", "IA"], ph: "A" },
  { id: "Iᴬi", a: ["IA", "i"], ph: "A" },
  { id: "IᴮIᴮ", a: ["IB", "IB"], ph: "B" },
  { id: "Iᴮi", a: ["IB", "i"], ph: "B" },
  { id: "IᴬIᴮ", a: ["IA", "IB"], ph: "AB" },
  { id: "ii", a: ["i", "i"], ph: "O" },
];

function phenotype(x: string, y: string): string {
  const both = `${x}|${y}`;
  if (both.includes("IA") && both.includes("IB")) return "AB";
  if (x === "IA" || y === "IA") return "A";
  if (x === "IB" || y === "IB") return "B";
  return "O";
}

function blood(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const groups = ["A", "B", "AB", "O"];
  const ask = groups[local % 4]!;
  const cross = Math.floor(local / 4) % 36;
  const nMul = Math.floor(local / 144) + 1;
  const N = nMul * 4;
  const p = GENO[Math.floor(cross / 6)]!;
  const q = GENO[cross % 6]!;
  let count = 0;
  for (const x of p.a) for (const y of q.a) if (phenotype(x, y) === ask) count++;
  const expected = (count * N) / 4;
  return buildMcq(rng, {
    id: `bld-${index}`,
    topic: "Heredity",
    prompt: `One parent has blood-group genotype ${p.id} (group ${p.ph}) and the other has ${q.id} (group ${q.ph}). In ${N} children, how many are expected to have blood group ${ask}?`,
    correct: String(expected),
    distractors: nearMiss(expected, [N, N / 2, N / 4, count, expected + 4]),
    explanation: `${count} of the 4 equally likely allele combinations give group ${ask}. Expected children = ${count}/4 × ${N} = ${expected}.`,
  });
}

function stoichiometry(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const kind = local % 3;
  const n = Math.floor(local / 3) + 1;
  if (kind === 0) {
    return buildMcq(rng, {
      id: `photo-${index}`,
      topic: "Life processes",
      prompt: `Photosynthesis: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂. If a leaf uses ${6 * n} molecules of carbon dioxide, how many molecules of glucose can it form?`,
      correct: String(n),
      distractors: nearMiss(n, [6 * n, n * 6, n + 6, 6]),
      explanation: `Six CO₂ molecules are needed for one glucose. ${6 * n} / 6 = ${n} glucose molecules. Light and chlorophyll are also required.`,
    });
  }
  if (kind === 1) {
    return buildMcq(rng, {
      id: `resp-${index}`,
      topic: "Life processes",
      prompt: `Aerobic respiration: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O. How many molecules of oxygen are used to break down ${n} glucose molecules?`,
      correct: String(6 * n),
      distractors: nearMiss(6 * n, [n, 6, 12 * n, n + 6]),
      explanation: `Each glucose molecule uses 6 oxygen molecules. ${n} × 6 = ${6 * n}.`,
    });
  }
  return buildMcq(rng, {
    id: `ferm-${index}`,
    topic: "Life processes",
    prompt: `Yeast ferments glucose to ethanol and carbon dioxide: one glucose gives two ethanol. From ${n} glucose molecules, how many ethanol molecules are produced?`,
    correct: String(2 * n),
    distractors: nearMiss(2 * n, [n, 6 * n, n + 2, 2]),
    explanation: `Alcoholic fermentation yields 2 ethanol per glucose. ${n} × 2 = ${2 * n}. It also releases CO₂.`,
  });
}

const PROCESSES: Array<{ name: string; steps: string[] }> = [
  {
    name: "the path of food in human digestion",
    steps: ["mouth", "oesophagus", "stomach", "small intestine", "large intestine"],
  },
  {
    name: "a reflex arc",
    steps: ["receptor", "sensory neuron", "spinal cord", "motor neuron", "effector"],
  },
  {
    name: "blood leaving the body and returning through the heart",
    steps: ["right atrium", "right ventricle", "lungs", "left atrium", "left ventricle"],
  },
  {
    name: "mitosis",
    steps: ["prophase", "metaphase", "anaphase", "telophase"],
  },
  {
    name: "urine formation",
    steps: ["filtration in the glomerulus", "reabsorption in the tubule", "secretion into the tubule", "storage in the bladder"],
  },
];

function permAt(n: number, index: number): number[] {
  const items = Array.from({ length: n }, (_, i) => i);
  let x = index;
  const out: number[] = [];
  for (let size = n; size >= 1; size--) {
    const f = factorial(size - 1);
    const d = Math.floor(x / f);
    x %= f;
    out.push(items.splice(d, 1)[0]!);
  }
  return out;
}

function orderQuestion(board: string, index: number, local: number): Question {
  const rng = rngFor(board, index);
  const proc = PROCESSES[local % PROCESSES.length]!;
  const sub = Math.floor(local / PROCESSES.length);
  const n = proc.steps.length;
  const ways = binom(factorial(n) - 1, 3);
  const ids = combinadic(3, sub % ways).map((k) => k + 1);
  const correct = proc.steps.join(" → ");
  const distractors = ids.map((id) => permAt(n, id).map((i) => proc.steps[i]!).join(" → "));
  return buildMcq(rng, {
    id: `ord-${index}`,
    topic: "Life processes",
    prompt: `Which is the correct order of ${proc.name}?`,
    correct,
    distractors,
    explanation: `The correct order is ${correct}.`,
  });
}

const FACTS: Array<{ topic: string; prompt: string; correct: string; distractors: string[]; explanation: string }> = [
  { topic: "Life processes", prompt: "The site of photosynthesis in a leaf cell is the", correct: "chloroplast", distractors: ["mitochondrion", "nucleus", "ribosome"], explanation: "Chlorophyll in the chloroplast traps light energy." },
  { topic: "Life processes", prompt: "Most aerobic respiration in a cell is completed in the", correct: "mitochondrion", distractors: ["chloroplast", "vacuole", "cell wall"], explanation: "The mitochondrion is where the stages that need oxygen release most of the energy." },
  { topic: "Life processes", prompt: "In human beings, oxygen is carried mainly by", correct: "haemoglobin in red blood cells", distractors: ["plasma alone", "platelets", "white blood cells"], explanation: "Haemoglobin binds oxygen in the lungs and releases it in the tissues." },
  { topic: "Life processes", prompt: "The functional unit of the kidney is the", correct: "nephron", distractors: ["alveolus", "neuron", "villus"], explanation: "Each nephron filters blood and forms urine." },
  { topic: "Life processes", prompt: "Water and minerals move up a plant mainly through the", correct: "xylem", distractors: ["phloem", "stomata only", "cambium"], explanation: "Xylem transports water. Phloem transports food." },
  { topic: "Life processes", prompt: "Food made in the leaves is transported by the", correct: "phloem", distractors: ["xylem", "root hair", "cuticle"], explanation: "Translocation of sugar happens in the phloem." },
  { topic: "Control and coordination", prompt: "Insulin is secreted by the", correct: "pancreas", distractors: ["thyroid", "adrenal gland", "pituitary"], explanation: "Insulin lowers blood glucose. Lack of it is linked with diabetes." },
  { topic: "Control and coordination", prompt: "Thyroxine is secreted by the", correct: "thyroid gland", distractors: ["pancreas", "liver", "adrenal gland"], explanation: "The thyroid needs iodine to make thyroxine. Deficiency can cause goitre." },
  { topic: "Control and coordination", prompt: "Which part of the brain keeps balance and posture?", correct: "cerebellum", distractors: ["cerebrum", "medulla", "spinal cord"], explanation: "The cerebellum coordinates voluntary movement and balance. The medulla handles many involuntary actions." },
  { topic: "Control and coordination", prompt: "A reflex action is controlled mainly by the", correct: "spinal cord", distractors: ["cerebrum", "thyroid", "heart"], explanation: "The reflex arc passes through the spinal cord so the response is quick." },
  { topic: "Control and coordination", prompt: "The plant hormone associated with bending towards light is", correct: "auxin", distractors: ["insulin", "thyroxine", "adrenaline"], explanation: "Auxin collects on the shaded side and the shoot bends towards light. This is phototropism." },
  { topic: "Reproduction", prompt: "Binary fission is the usual reproduction of", correct: "Amoeba", distractors: ["yeast", "hydra", "a fern only"], explanation: "Amoeba divides into two. Yeast and Hydra commonly reproduce by budding." },
  { topic: "Reproduction", prompt: "Yeast commonly reproduces asexually by", correct: "budding", distractors: ["binary fission of a seed", "fragmentation of a leaf", "spore formation only in flowers"], explanation: "A bud forms on the yeast cell, grows, and separates." },
  { topic: "Reproduction", prompt: "After fertilisation in a flower, the ovary becomes the", correct: "fruit", distractors: ["seed", "pollen", "sepal"], explanation: "The ovary ripens into the fruit. Each ovule becomes a seed." },
  { topic: "Reproduction", prompt: "In humans, the sex of a child is determined by the", correct: "sperm, which may carry X or Y", distractors: ["egg, which may carry Y", "placenta", "number of meals"], explanation: "Eggs carry X. Sperm carry X or Y. XX is female and XY is male, so the sperm decides." },
  { topic: "Heredity", prompt: "Mendel is called the father of", correct: "genetics", distractors: ["evolution only", "microbiology", "ecology"], explanation: "His pea experiments established the basic rules of inheritance." },
  { topic: "Our environment", prompt: "Ozone high in the atmosphere is depleted by", correct: "chlorofluorocarbons", distractors: ["oxygen released by plants", "nitrogen in proteins", "glucose"], explanation: "CFCs release chlorine atoms that break ozone molecules." },
  { topic: "Our environment", prompt: "Which of these is biodegradable?", correct: "vegetable peel", distractors: ["polythene bag", "glass bottle", "aluminium can"], explanation: "Vegetable peels are broken down by microbes. Plastic, glass and metal are not biodegradable in that sense." },
  { topic: "Life processes", prompt: "The tiny air sacs where gas exchange occurs in the lungs are", correct: "alveoli", distractors: ["nephrons", "villi", "bronchi only"], explanation: "Alveoli give the lungs a huge surface for oxygen and carbon dioxide to diffuse." },
  { topic: "Life processes", prompt: "Bile, which emulsifies fat, is made in the", correct: "liver", distractors: ["stomach", "pancreas", "kidney"], explanation: "The liver makes bile. It is stored in the gall bladder." },
  { topic: "Evolution", prompt: "Organs that have the same basic structure but may do different jobs, such as a human arm and a whale’s flipper, are", correct: "homologous organs", distractors: ["analogous organs", "vestigial only", "fossils"], explanation: "Homologous organs share a structure and suggest a common ancestry. Analogous organs share a function but not the structure." },
  { topic: "Life processes", prompt: "Stomata in leaves are used mainly for", correct: "gas exchange", distractors: ["absorbing soil water", "making blood", "storing starch only"], explanation: "Stomata let carbon dioxide in and oxygen and water vapour out." },
];

function factQuestion(board: string, index: number, n: number): Question {
  const rng = rngFor(board, index);
  const fact = FACTS[n]!;
  return buildMcq(rng, { id: `lf-${index}`, ...fact });
}

export function lifeQuestion(board: string, index: number): Question {
  const i = Math.max(0, Math.floor(index));
  if (i % 750 === 0) {
    const n = Math.floor(i / 750) % FACTS.length;
    return factQuestion(board, i, n);
  }
  const family = i % FAMILIES;
  const local = Math.floor(i / FAMILIES);
  if (family === 0) return classQuestion(board, i, local, false);
  if (family === 1) return classQuestion(board, i, local, true);
  if (family === 2) return traitQuestion(board, i, local);
  if (family === 3) return mendel(board, i, local);
  if (family === 4) return energy(board, i, local);
  if (family === 5) return blood(board, i, local);
  if (family === 6) return stoichiometry(board, i, local);
  return orderQuestion(board, i, local);
}
