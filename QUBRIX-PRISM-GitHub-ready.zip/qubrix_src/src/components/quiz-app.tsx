export { QubrixApp as QuizApp } from "./qx/app";
