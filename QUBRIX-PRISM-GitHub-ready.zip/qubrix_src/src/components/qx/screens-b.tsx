import { useEffect, useMemo, useRef, useState } from "react";
import { Award, Bookmark, ChevronRight, Download, Layers, Lock, PlayCircle, Sparkles, Target, Timer, Trash2, Upload, Zap } from "lucide-react";
import { ACHIEVEMENTS } from "@/lib/learn/achievements";
import { REFERENCE_WBBSE10 } from "@/lib/learn/content/reference-wbbse10";
import { availability, boardList, findTopic, practiceTopics, subjectsOf } from "@/lib/learn/registry";
import { resolveQuestion } from "@/lib/learn/resolve";
import { dateKeyOf, isDue, masteryOf, addDays } from "@/lib/learn/review";
import { levelFor } from "@/lib/learn/scoring";
import { LANGUAGES } from "@/lib/learn/strings";
import { GEN_SUPPLY } from "@/lib/learn/supply.data";
import type { Difficulty } from "@/lib/learn/types";
import { Confirm, Empty, fmtTime, MasteryChip, PageHead, Progress, Stat } from "./common";
import { boardLabel, inTopic } from "./screens-a";
import { useStore } from "./store";

// ---------------- Practice hub ----------------
export function PracticeHub() {
  const { state, start, nav } = useStore();
  const { board, grade } = state.profile;
  const topics = practiceTopics(board, grade);
  const subs = subjectsOf(board, grade).filter((s) => s.readiness !== "preparing");
  const [mode, setMode] = useState<"topic" | "quick" | "adaptive" | "mixed" | "gk">("topic");
  const [sel, setSel] = useState(topics[0] ? `${topics[0].subjectId}|${topics[0].id}` : "");
  const [picked, setPicked] = useState<string[]>([]);
  const [count, setCount] = useState(10);
  const [gk, setGk] = useState(Object.keys(GEN_SUPPLY.gk ?? {})[0] ?? "");
  const today = dateKeyOf(Date.now());
  if (topics.length === 0) return <Empty icon={Lock} title="Not yet supported" text={availability(board, grade).note} action={<button className="qx-btn primary" onClick={() => nav({ name: "settings" })}>Change curriculum</button>} />;
  const ref = (v: string) => { const [subjectId, topicId] = v.split("|") as [string, string]; return { board, grade, subjectId, topicId }; };
  const MODES = [["topic", "Topic"], ["quick", "Quick"], ["adaptive", "Adaptive"], ["mixed", "Mixed"], ["gk", "General knowledge"]] as const;
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow={`${boardLabel(board)} · Class ${grade}`} title="Practice" sub="Untimed, with feedback after every answer." />
      <button className="qx-card glass qx-link" onClick={() => (state.daily[today]?.done ? undefined : start({ kind: "daily" }))} disabled={!!state.daily[today]?.done}><span className="qx-ico"><Target size={20} /></span><span className="qx-grow"><b>Daily challenge</b><div className="qx-small">{state.daily[today]?.done ? "Completed today — back tomorrow" : "Today's 5 questions"}</div></span>{!state.daily[today]?.done && <ChevronRight />}</button>
      <div className="qx-tabs" role="group" aria-label="Practice mode">{MODES.map(([id, label]) => <button key={id} aria-pressed={mode === id} onClick={() => setMode(id)}>{label}</button>)}</div>
      <div className="qx-card qx-stack">
        {mode === "topic" && <>
          <p className="qx-muted" style={{ margin: 0 }}>Practise one chapter. Questions come only from that chapter.</p>
          <label className="qx-sr" htmlFor="tsel">Chapter</label>
          <select id="tsel" className="qx-input" value={sel} onChange={(e) => setSel(e.target.value)}>{subs.map((s) => <optgroup key={s.id} label={s.title}>{s.topics.filter((t) => t.readiness !== "preparing").map((t) => <option key={t.id} value={`${s.id}|${t.id}`}>{t.title}</option>)}</optgroup>)}</select>
          <button className="qx-btn primary block" onClick={() => start({ kind: "practice", topic: ref(sel), count: 10 })}><PlayCircle size={18} /> Start · 10 questions</button>
        </>}
        {mode === "quick" && <>
          <p className="qx-muted" style={{ margin: 0 }}>A short session across the chapters you pick.</p>
          <div className="qx-seg" role="group" aria-label="Number of questions">{[5, 10, 20].map((n) => <button key={n} aria-pressed={count === n} onClick={() => setCount(n)}>{n}</button>)}</div>
          <div className="qx-tabs" role="group" aria-label="Chapters" style={{ flexWrap: "wrap", overflow: "visible" }}>{topics.map((t) => { const v = `${t.subjectId}|${t.id}`; return <button key={v} aria-pressed={picked.includes(v)} onClick={() => setPicked((p) => (p.includes(v) ? p.filter((x) => x !== v) : [...p, v]))}>{t.title}</button>; })}</div>
          <button className="qx-btn primary block" disabled={!picked.length} onClick={() => start({ kind: "quick", topics: picked.map(ref), count })}><Zap size={18} /> Start {count} questions{picked.length ? ` from ${picked.length} chapter${picked.length === 1 ? "" : "s"}` : ""}</button>
          {!picked.length && <p className="qx-small" style={{ margin: 0 }}>Choose at least one chapter.</p>}
        </>}
        {mode === "adaptive" && <>
          <p className="qx-muted" style={{ margin: 0 }}>QUBRIX picks more questions from chapters where your recent accuracy is low, revisits missed questions that are due, and raises difficulty after consistent success. Each question tells you why it was chosen.</p>
          <button className="qx-btn primary block" onClick={() => start({ kind: "adaptive", count: 10 })}><Sparkles size={18} /> Start adaptive · 10 questions</button>
        </>}
        {mode === "mixed" && <>
          <p className="qx-muted" style={{ margin: 0 }}>Rotates through every subject that has questions in your curriculum. Each question is labelled with its subject and chapter.</p>
          <button className="qx-btn primary block" onClick={() => start({ kind: "mixed", count: 10 })}><Layers size={18} /> Start mixed · 10 questions</button>
        </>}
        {mode === "gk" && <>
          <p className="qx-muted" style={{ margin: 0 }}>Open general-knowledge practice. It is not part of any board syllabus.</p>
          <label className="qx-sr" htmlFor="gsel">Topic</label>
          <select id="gsel" className="qx-input" value={gk} onChange={(e) => setGk(e.target.value)}>{Object.keys(GEN_SUPPLY.gk ?? {}).map((t) => <option key={t}>{t}</option>)}</select>
          <button className="qx-btn primary block" disabled={!gk} onClick={() => start({ kind: "practice", topic: { board: "general", grade: 10, subjectId: "gk", topicId: gk }, count: 10 })}><PlayCircle size={18} /> Start · 10 questions</button>
        </>}
      </div>
    </div>
  );
}

// ---------------- Tests ----------------
export function TestsScreen() {
  const { state, start, nav } = useStore();
  const { board, grade } = state.profile;
  const subs = subjectsOf(board, grade).filter((s) => s.readiness !== "preparing");
  const [count, setCount] = useState(10);
  const [minutes, setMinutes] = useState(15);
  const [picked, setPicked] = useState<string[]>([]);
  const a = state.active;
  const total = subs.reduce((n, s) => n + s.topics.reduce((m, t) => m + t.authored + t.generated, 0), 0);
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow={`${boardLabel(board)} · Class ${grade}`} title="Mock tests" sub="Timed exam practice. Answers stay hidden until you submit." />
      {a && a.kind === "exam" && a.status === "active" && <button className="qx-card glass qx-link" onClick={() => nav({ name: "session" })}><span className="qx-ico"><Timer size={20} /></span><span className="qx-grow"><b>Resume your test</b><div className="qx-small">{a.title} · {a.answers.filter(Boolean).length}/{a.items.length} answered</div></span><ChevronRight /></button>}
      {a && a.kind === "exam" && a.status === "submitted" && <button className="qx-card qx-link" onClick={() => nav({ name: "session" })}><span className="qx-grow"><b>View your last result</b></span><ChevronRight /></button>}
      {subs.length === 0 || total === 0 ? <Empty icon={Lock} title="Tests aren't available yet" text="Mock tests need a curriculum with questions. Only WBBSE Class 10 has them today." /> : (
        <div className="qx-card qx-stack">
          <b>Number of questions</b><div className="qx-seg" role="group" aria-label="Number of questions">{[10, 20, 30].map((n) => <button key={n} aria-pressed={count === n} onClick={() => setCount(n)}>{n}</button>)}</div>
          <b>Duration</b><div className="qx-seg" role="group" aria-label="Duration in minutes">{[15, 30, 45, 60].map((n) => <button key={n} aria-pressed={minutes === n} onClick={() => setMinutes(n)}>{n} min</button>)}</div>
          <b>Subjects</b><div className="qx-tabs" role="group" aria-label="Subjects" style={{ flexWrap: "wrap", overflow: "visible" }}>{subs.map((s) => <button key={s.id} aria-pressed={picked.includes(s.id)} onClick={() => setPicked((p) => (p.includes(s.id) ? p.filter((x) => x !== s.id) : [...p, s.id]))}>{s.title.split(" ")[0]}</button>)}</div>
          <p className="qx-small" style={{ margin: 0 }}>{picked.length ? "Only the selected subjects." : "All subjects with questions."} Questions never repeat inside a test.</p>
          <button className="qx-btn primary block" onClick={() => start({ kind: "exam", count, minutes, subjectIds: picked.length ? picked : undefined })}><Timer size={18} /> Start test</button>
        </div>
      )}
      <h2 className="qx-h2">Completed tests</h2>
      {state.tests.length === 0 ? <p className="qx-muted">No completed tests yet.</p> : <div className="qx-stack">{[...state.tests].reverse().map((t) => <div key={t.id} className="qx-card"><div className="qx-row" style={{ justifyContent: "space-between" }}><b>{t.title}</b><span className={`qx-chip ${t.scorePct >= 60 ? "ok" : "warn"}`}>{t.scorePct}%</span></div><div className="qx-small">{new Date(t.at).toLocaleString()} · {t.correct}/{t.total} correct · {fmtTime(t.timeUsedSec)}{t.reason === "timeout" ? " · auto-submitted" : ""}</div></div>)}</div>}
    </div>
  );
}

// ---------------- Revision ----------------
export function ReviseScreen() {
  const { state, start, nav } = useStore();
  const today = dateKeyOf(Date.now());
  const dueQ = Object.values(state.reviews).filter((r) => r.kind === "question" && isDue(r, today)).length;
  const dueC = Object.values(state.reviews).filter((r) => r.kind === "card" && isDue(r, today)).length;
  const open = Object.values(state.mistakes).filter((m) => !m.resolved).length;
  const cards = REFERENCE_WBBSE10.length;
  const supported = availability(state.profile.board, state.profile.grade).state !== "unsupported";
  return (
    <div className="qx-view qx-stack">
      <PageHead title="Revision" sub="Spaced review of what you missed, bookmarked and need to remember." />
      <div className="qx-card"><div className="qx-grid2 keep"><Stat label="Due questions" value={dueQ} /><Stat label="Open mistakes" value={open} /><Stat label="Bookmarks" value={state.bookmarks.length} /><Stat label="Cards due" value={supported ? dueC || cards - Object.values(state.reviews).filter((r) => r.kind === "card").length + dueC : 0} /></div></div>
      <button className="qx-btn primary block" disabled={open + dueQ + state.bookmarks.length === 0} onClick={() => start({ kind: "revision", count: 15 })}><PlayCircle size={18} /> Start revision session</button>
      {open + dueQ + state.bookmarks.length === 0 && <Empty icon={Layers} title="Nothing to revise yet" text="Wrong answers, skipped test questions and bookmarks appear here. Answer a few questions first." action={<button className="qx-btn" onClick={() => nav({ name: "practice" })}>Go to Practice</button>} />}
      <button className="qx-card qx-link" onClick={() => nav({ name: "notebook" })}><span className="qx-ico"><Bookmark size={20} /></span><span className="qx-grow"><b>Mistakes &amp; bookmarks</b><div className="qx-small">Filter by subject, chapter and difficulty</div></span><ChevronRight /></button>
      <button className="qx-card qx-link" onClick={() => nav({ name: "cards" })} disabled={!supported}><span className="qx-ico"><Layers size={20} /></span><span className="qx-grow"><b>Flashcards</b><div className="qx-small">Formulas and definitions, Leitner schedule (1, 2, 4, 8, 16 days)</div></span><ChevronRight /></button>
    </div>
  );
}

export function NotebookScreen() {
  const { state, bookmark, nav } = useStore();
  const { board, grade } = state.profile;
  const [tab, setTab] = useState<"mistakes" | "bookmarks">("mistakes");
  const [subject, setSubject] = useState("all");
  const [topic, setTopic] = useState("all");
  const [diff, setDiff] = useState<"all" | Difficulty>("all");
  const [open, setOpen] = useState<string | null>(null);
  const subs = subjectsOf(board, grade);
  const keys = tab === "mistakes" ? Object.entries(state.mistakes).filter(([, m]) => !m.resolved).sort((a, b) => b[1].lastAt - a[1].lastAt).map(([k]) => k) : state.bookmarks;
  const rows = keys.map((k) => resolveQuestion(k)).filter((q): q is NonNullable<typeof q> => !!q).filter((q) => q.board === board && q.grade === grade && (subject === "all" || q.subjectId === subject) && (topic === "all" || q.topicId === topic) && (diff === "all" || q.difficulty === diff));
  const topicOpts = subject === "all" ? [] : subs.find((s) => s.id === subject)?.topics ?? [];
  return (
    <div className="qx-view qx-stack">
      <PageHead title="Mistakes & bookmarks" sub="Missed and skipped questions, and the ones you saved." />
      <div className="qx-tabs" role="group" aria-label="List"><button aria-pressed={tab === "mistakes"} onClick={() => setTab("mistakes")}>Mistakes ({Object.values(state.mistakes).filter((m) => !m.resolved).length})</button><button aria-pressed={tab === "bookmarks"} onClick={() => setTab("bookmarks")}>Bookmarks ({state.bookmarks.length})</button></div>
      <div className="qx-grid2 keep">
        <div><label className="qx-small" htmlFor="fs">Subject</label><select id="fs" className="qx-input" value={subject} onChange={(e) => { setSubject(e.target.value); setTopic("all"); }}><option value="all">All subjects</option>{subs.map((s) => <option key={s.id} value={s.id}>{s.title}</option>)}</select></div>
        <div><label className="qx-small" htmlFor="ft">Chapter</label><select id="ft" className="qx-input" value={topic} disabled={subject === "all"} onChange={(e) => setTopic(e.target.value)}><option value="all">All chapters</option>{topicOpts.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</select></div>
      </div>
      <div><label className="qx-small" htmlFor="fd">Difficulty (written questions only)</label><select id="fd" className="qx-input" value={diff} onChange={(e) => setDiff(e.target.value as typeof diff)}><option value="all">Any</option><option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option></select></div>
      {rows.length === 0 ? <Empty icon={Bookmark} title={tab === "mistakes" ? "No mistakes here" : "No bookmarks here"} text={keys.length ? "No items match these filters." : tab === "mistakes" ? "Wrong or skipped questions will appear here." : "Tap the bookmark icon on any question to save it."} action={<button className="qx-btn" onClick={() => nav({ name: "practice" })}>Practice</button>} /> : (
        <div className="qx-stack">{rows.map((q) => { const t = findTopic(q.board, q.grade, q.subjectId, q.topicId); const o = open === q.id; return (
          <div key={q.id} className="qx-card"><button className="qx-link" style={{ background: "none", border: 0, padding: 0, minHeight: 44, color: "inherit" }} aria-expanded={o} onClick={() => setOpen(o ? null : q.id)}><span className="qx-grow"><div className="qx-small">{t?.title}{q.difficulty ? ` · ${q.difficulty}` : ""}</div>{q.prompt}</span><ChevronRight size={16} style={{ transform: o ? "rotate(90deg)" : undefined }} /></button>
            {o && <div style={{ marginTop: 10 }}><p className="qx-small" style={{ margin: 0 }}>Answer: {q.type === "numeric" ? q.numeric?.value : q.answer.map((i) => q.options[i]).join(", ")}</p><p className="qx-muted">{q.explanation}</p>{state.notes.question[q.id] && <div className="qx-feedback info">Your note: {state.notes.question[q.id]}</div>}<button className="qx-btn sm" style={{ marginTop: 8 }} onClick={() => bookmark(q.id)}>{state.bookmarks.includes(q.id) ? "Remove bookmark" : "Bookmark"}</button></div>}
          </div>); })}</div>
      )}
    </div>
  );
}

export function CardsScreen() {
  const { state, cardReview, ensureCards, nav } = useStore();
  const today = dateKeyOf(Date.now());
  const [show, setShow] = useState(false);
  const [doneIds, setDoneIds] = useState<string[]>([]);
  const entries = useMemo(() => { const known = new Set(subjectsOf(state.profile.board, state.profile.grade).flatMap((s) => s.topics.map((t) => `${s.id}/${t.id}`))); return REFERENCE_WBBSE10.filter((e) => known.has(`${e.subjectId}/${e.topicId}`)); }, [state.profile.board, state.profile.grade]);
  const seeded = useRef(false);
  useEffect(() => { if (seeded.current) return; seeded.current = true; const missing = entries.filter((e) => !state.reviews[e.id]).map((e) => ({ id: e.id, ref: e.id })); if (missing.length) ensureCards(missing); }, [entries, state.reviews, ensureCards]);
  const due = entries.filter((e) => { const r = state.reviews[e.id]; return (!r || isDue(r, today)) && !doneIds.includes(e.id); });
  const card = due[0];
  if (!card) return <div className="qx-view qx-stack"><PageHead title="Flashcards" /><Empty icon={Award} title="All caught up" text={`No cards are due. Reviewed ${state.totals.reviews} times so far; the next card comes back on its schedule.`} action={<button className="qx-btn" onClick={() => nav({ name: "revise" }, { replace: true })}>Back to revision</button>} /></div>;
  const box = state.reviews[card.id]?.box ?? 1;
  return (
    <div className="qx-view qx-stack">
      <PageHead title="Flashcards" sub={`${due.length} due · box ${box} of 5`} />
      <div className="qx-card glass" style={{ minHeight: 190 }}><span className="qx-chip info">{card.kind}</span><h2 className="qx-qtext" style={{ margin: "12px 0" }}>{card.term}</h2>{show ? <p className="qx-muted" style={{ fontSize: 16 }}>{card.body}</p> : <p className="qx-small">Try to recall it, then reveal.</p>}</div>
      {!show ? <button className="qx-btn primary block" onClick={() => setShow(true)}>Reveal</button> : (
        <div className="qx-row"><button className="qx-btn qx-grow" onClick={() => { cardReview(card.id, card.id, false); setDoneIds((d) => [...d, card.id]); setShow(false); }}>Again (tomorrow)</button><button className="qx-btn primary qx-grow" onClick={() => { cardReview(card.id, card.id, true); setDoneIds((d) => [...d, card.id]); setShow(false); }}>Got it</button></div>
      )}
    </div>
  );
}

// ---------------- Profile & settings ----------------
export function MeScreen() {
  const { state, nav } = useStore();
  const lv = levelFor(state.xp);
  const today = dateKeyOf(Date.now());
  const days = Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));
  const counts = days.map((d) => state.days[d]?.answered ?? 0);
  const max = Math.max(1, ...counts);
  const week = counts.reduce((a, b) => a + b, 0);
  const bySubject = new Map<string, { a: number; c: number }>();
  for (const [k, v] of Object.entries(state.topics)) { const sid = k.split(":")[2] ?? "?"; const cur = bySubject.get(sid) ?? { a: 0, c: 0 }; bySubject.set(sid, { a: cur.a + v.attempts, c: cur.c + v.correct }); }
  const subs = subjectsOf(state.profile.board, state.profile.grade);
  const strong = Object.values(state.topics).filter((t) => masteryOf(t) === "strong").length;
  const unlocked = ACHIEVEMENTS.filter((a) => state.achievements[a.id]);
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow="Private to this device" title="Your progress" />
      <div className="qx-card glass"><div className="qx-row" style={{ justifyContent: "space-between" }}><Stat label={`Level ${lv.level}`} value={`${state.xp} XP`} /><Stat label="Best day streak" value={state.streak.best} /></div><div style={{ marginTop: 10 }}><Progress value={(lv.into / lv.span) * 100} label="Progress to next level" /></div><p className="qx-small" style={{ margin: "6px 0 0" }}>{lv.span - lv.into} XP to level {lv.level + 1}</p></div>
      <div className="qx-card"><div className="qx-grid2 keep"><Stat label="Questions answered" value={state.totals.answered} /><Stat label="Accuracy" value={state.totals.answered ? `${Math.round((state.totals.correct / state.totals.answered) * 100)}%` : "—"} /><Stat label="Sessions" value={state.totals.sessions} /><Stat label="Revision reviews" value={state.totals.reviews} /><Stat label="Strong chapters" value={strong} /><Stat label="Best answer streak" value={state.bestAnswerStreak} /></div></div>
      <div className="qx-card"><h2 className="qx-h2" style={{ marginTop: 0 }}>Last 7 days</h2><div className="qx-row" style={{ alignItems: "flex-end", height: 90, gap: 6 }} role="img" aria-label={`Questions answered per day: ${counts.join(", ")}`}>{counts.map((c, i) => <div key={i} className="qx-grow" style={{ textAlign: "center" }}><div style={{ height: Math.max(4, (c / max) * 64), borderRadius: 6, background: "linear-gradient(#8a55f5,#36d3e3)", opacity: c ? 1 : 0.25 }} /><div className="qx-small">{days[i]!.slice(8)}</div></div>)}</div><p className="qx-small" style={{ margin: "8px 0 0" }}>Weekly goal: {week}/{state.profile.dailyTarget * 7} questions</p><div style={{ marginTop: 6 }}><Progress value={(week / (state.profile.dailyTarget * 7)) * 100} label="Weekly goal" /></div></div>
      {bySubject.size > 0 && <div className="qx-card"><h2 className="qx-h2" style={{ marginTop: 0 }}>Accuracy by subject</h2><div className="qx-stack">{[...bySubject.entries()].map(([sid, v]) => <div key={sid}><div className="qx-row" style={{ justifyContent: "space-between" }}><span>{subs.find((s) => s.id === sid)?.title ?? (sid === "gk" ? "General knowledge" : sid)}</span><span className="qx-small">{v.c}/{v.a}</span></div><Progress value={v.a ? (v.c / v.a) * 100 : 0} label={`${sid} accuracy`} /></div>)}</div></div>}
      <div className="qx-card"><h2 className="qx-h2" style={{ marginTop: 0 }}>Achievements ({unlocked.length}/{ACHIEVEMENTS.length})</h2><div className="qx-stack">{ACHIEVEMENTS.map((a) => <div key={a.id} className="qx-row" style={{ opacity: state.achievements[a.id] ? 1 : 0.55 }}><span className="qx-ico"><Award size={18} /></span><span className="qx-grow"><b>{a.title}</b><div className="qx-small">{a.text}</div></span>{state.achievements[a.id] ? <span className="qx-chip ok">Unlocked</span> : <span className="qx-chip">Locked</span>}</div>)}</div></div>
      <button className="qx-btn block" onClick={() => nav({ name: "settings" })}>Settings &amp; data</button>
    </div>
  );
}

export function SettingsScreen() {
  const { state, patchProfile, exportJson, importJson, resetData, say, storageOk, loadMessage } = useStore();
  const [confirm, setConfirm] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const file = useRef<HTMLInputElement>(null);
  const { board, grade } = state.profile;
  const boards = boardList();
  const download = () => { const blob = new Blob([exportJson()], { type: "application/json" }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = `qubrix-progress-${dateKeyOf(Date.now())}.json`; a.click(); URL.revokeObjectURL(url); say("Export downloaded."); };
  const onFile = async (f: File | undefined) => { if (!f) return; const e = importJson(await f.text()); setErr(e); if (!e) say("Progress imported."); if (file.current) file.current.value = ""; };
  return (
    <div className="qx-view qx-stack">
      <PageHead title="Settings" sub="Everything stays on this device unless you export it." />
      {!storageOk && <div className="qx-banner">Browser storage is unavailable, so progress can't be saved in this window.</div>}
      {loadMessage && <div className="qx-banner">{loadMessage}</div>}
      <div className="qx-card qx-stack"><b>Curriculum</b>
        <label className="qx-small" htmlFor="sb">Board</label><select id="sb" className="qx-input" value={board} onChange={(e) => patchProfile({ board: e.target.value, lastSubject: null, lastTopic: null })}>{boards.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select>
        <label className="qx-small" htmlFor="sc">Class</label><select id="sc" className="qx-input" value={grade} onChange={(e) => patchProfile({ grade: Number(e.target.value), lastSubject: null, lastTopic: null })}>{[5, 6, 7, 8, 9, 10, 11].map((g) => <option key={g} value={g}>Class {g}</option>)}</select>
        <p className="qx-small" style={{ margin: 0 }}>{availability(board, grade).note}</p>
        <label className="qx-small" htmlFor="sl">Language</label><select id="sl" className="qx-input" value="en" onChange={() => undefined}>{LANGUAGES.map((l) => <option key={l.id} value={l.id} disabled={!l.available}>{l.label}{l.available ? "" : " — not translated yet"}</option>)}</select>
      </div>
      <div className="qx-card qx-stack"><b>Daily goal</b><div className="qx-seg" role="group" aria-label="Daily question target">{[5, 10, 20, 30].map((n) => <button key={n} aria-pressed={state.profile.dailyTarget === n} onClick={() => patchProfile({ dailyTarget: n })}>{n}</button>)}</div>
        <b>Motion</b><div className="qx-seg" role="group" aria-label="Motion preference">{([["system", "System"], ["reduce", "Reduce"], ["full", "Full"]] as const).map(([v, l]) => <button key={v} aria-pressed={state.profile.motion === v} onClick={() => patchProfile({ motion: v })}>{l}</button>)}</div></div>
      <div className="qx-card qx-stack"><b>Your data</b><p className="qx-small" style={{ margin: 0 }}>Export includes progress, bookmarks, notes and reports as versioned JSON.</p>
        <button className="qx-btn block" onClick={download}><Download size={18} /> Export progress</button>
        <button className="qx-btn block" onClick={() => file.current?.click()}><Upload size={18} /> Import progress</button>
        <input ref={file} type="file" accept="application/json,.json" hidden aria-label="Import progress file" onChange={(e) => void onFile(e.target.files?.[0])} />
        {err && <div className="qx-feedback bad" role="alert">{err}</div>}
        <button className="qx-btn danger block" onClick={() => setConfirm(true)}><Trash2 size={18} /> Reset all progress</button></div>
      {confirm && <Confirm danger title="Reset all progress?" text="This permanently deletes XP, streaks, notes, bookmarks and history on this device. Export first if you want a backup." confirmLabel="Delete everything" onCancel={() => setConfirm(false)} onConfirm={() => { setConfirm(false); resetData(); say("Progress reset."); }} />}
      <p className="qx-small">QUBRIX collects no personal data, accounts or analytics. Generated questions are practice variations; written questions are not yet human-reviewed.</p>
    </div>
  );
}
