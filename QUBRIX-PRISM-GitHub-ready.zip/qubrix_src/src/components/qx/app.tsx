import { useEffect } from "react";
import { BookOpen, Home as HomeIcon, Layers, Search, Target, Timer, User, WifiOff, Zap } from "lucide-react";
import { levelFor } from "@/lib/learn/scoring";
import { ErrorBoundary, Skeleton } from "./common";
import { SessionScreen } from "./question";
import { CurriculumScreen, Home, Learn, Onboarding, ReferenceScreen, SearchScreen, SubjectScreen, TopicScreen } from "./screens-a";
import { CardsScreen, MeScreen, NotebookScreen, PracticeHub, ReviseScreen, SettingsScreen, TestsScreen } from "./screens-b";
import { StoreProvider, useStore, type View } from "./store";

const TABS = [
  { id: "home", label: "Home", icon: HomeIcon, match: ["home"] },
  { id: "learn", label: "Learn", icon: BookOpen, match: ["learn", "subject", "topic", "curriculum", "search", "reference"] },
  { id: "practice", label: "Practice", icon: Target, match: ["practice", "session"] },
  { id: "tests", label: "Tests", icon: Timer, match: ["tests"] },
  { id: "revise", label: "Revise", icon: Layers, match: ["revise", "cards", "notebook"] },
  { id: "me", label: "Profile", icon: User, match: ["me", "settings"] },
] as const;

function Screen({ view }: { view: View }) {
  switch (view.name) {
    case "home": return <Home />;
    case "learn": return <Learn />;
    case "subject": return <SubjectScreen subjectId={view.subjectId} />;
    case "topic": return <TopicScreen subjectId={view.subjectId} topicId={view.topicId} />;
    case "practice": return <PracticeHub />;
    case "session": return <SessionScreen />;
    case "tests": return <TestsScreen />;
    case "revise": return <ReviseScreen />;
    case "cards": return <CardsScreen />;
    case "notebook": return <NotebookScreen />;
    case "me": return <MeScreen />;
    case "settings": return <SettingsScreen />;
    case "search": return <SearchScreen />;
    case "reference": return <ReferenceScreen />;
    case "curriculum": return <CurriculumScreen />;
  }
}

function Shell() {
  const { ready, state, view, nav, back, busy, toast, online } = useStore();
  const reduce = state.profile.motion === "reduce";
  useEffect(() => { document.documentElement.classList.toggle("qx-motion-reduce", reduce); }, [reduce]);
  const lv = levelFor(state.xp);
  const inSession = view.name === "session" && state.active?.status === "active";
  return (
    <div className="qx-shell">
      <header className="qx-top">
        <div className="qx-brand"><img src="/qubrix-icon.png" alt="" /><b>QUBRIX</b></div>
        {ready && state.profile.onboarded && <>
          <button className="qx-icon-btn" aria-label="Search" onClick={() => nav({ name: "search" })}><Search size={18} /></button>
          <button className="qx-chip info" style={{ minHeight: 44, padding: "0 12px" }} onClick={() => nav({ name: "me" })} aria-label={`Level ${lv.level}, ${state.xp} XP. Open profile`}><Zap size={14} /> L{lv.level} · {state.xp} XP</button>
        </>}
      </header>
      <main className="qx-body" id="main">
        {!online && <div className="qx-banner" style={{ marginBottom: 12 }} role="status"><WifiOff size={14} style={{ verticalAlign: "-2px" }} /> You're offline. Questions you've already loaded and all your progress still work.</div>}
        {busy && <div className="qx-banner" role="status" style={{ marginBottom: 12 }}>{busy}</div>}
        {!ready ? <Skeleton /> : !state.profile.onboarded ? <Onboarding /> : (
          <ErrorBoundary key={view.name} onReset={() => nav({ name: "home" }, { replace: true })}><Screen view={view} /></ErrorBoundary>
        )}
        {ready && state.profile.onboarded && view.name !== "home" && !["learn", "practice", "tests", "revise", "me"].includes(view.name) && !inSession && (
          <div style={{ marginTop: 16 }}><button className="qx-btn" onClick={back}>← Back</button></div>
        )}
      </main>
      {ready && state.profile.onboarded && (
        <nav className="qx-nav" aria-label="Main">
          {TABS.map((t) => { const Icon = t.icon; const active = (t.match as readonly string[]).includes(view.name); return <button key={t.id} aria-current={active ? "page" : undefined} onClick={() => nav({ name: t.id } as View)}><Icon /> {t.label}</button>; })}
        </nav>
      )}
      {toast && <div className="qx-toast" role="status">{toast}</div>}
    </div>
  );
}

export function QubrixApp() {
  return <StoreProvider><Shell /></StoreProvider>;
}
