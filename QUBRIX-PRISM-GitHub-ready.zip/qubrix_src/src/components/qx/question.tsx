import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Bookmark, Check, ChevronLeft, ChevronRight, Clock, Flag, Lightbulb, NotebookPen, ShieldAlert, X } from "lucide-react";
import { resolveQuestion } from "@/lib/learn/resolve";
import { findTopic } from "@/lib/learn/registry";
import * as S from "@/lib/learn/session";
import type { Answer, QuestionRecord, Response, Session } from "@/lib/learn/types";
import { Confirm, Empty, fmtTime, Modal, PageHead, Progress, Stat } from "./common";
import { useStore } from "./store";
import { PrismAnswerEffect, PrismVictoryOverlay, PrismXPCounter } from "./prism-effects";
import { eventFor, levelForSession } from "@/lib/prism/victory";

const LETTERS = ["A", "B", "C", "D", "E", "F"];

function Badges({ q }: { q: QuestionRecord }) {
  return (
    <div className="qx-row qx-wrap" style={{ gap: 6 }}>
      <span className="qx-chip info">{q.origin === "authored" ? "Written question" : "Generated practice"}</span>
      {q.difficulty && <span className="qx-chip">{q.difficulty}</span>}
      <span className="qx-chip">{q.examLabel}</span>
      <span className="qx-chip warn">{q.review === "machine-validated" ? "Not yet human-reviewed" : q.review}</span>
    </div>
  );
}

function ReportDialog({ qKey, onClose }: { qKey: string; onClose: () => void }) {
  const { report } = useStore();
  const [text, setText] = useState("");
  return (
    <Modal title="Report a problem" onClose={onClose}>
      <p className="qx-muted">Describe what looks wrong (wrong answer, unclear wording, off-topic). The report is saved on this device and included in your export.</p>
      <label className="qx-small" htmlFor="rep">What is wrong?</label>
      <textarea id="rep" className="qx-textarea" value={text} onChange={(e) => setText(e.target.value)} maxLength={500} />
      <div className="qx-row" style={{ justifyContent: "flex-end", marginTop: 12 }}>
        <button className="qx-btn" onClick={onClose}>Cancel</button>
        <button className="qx-btn primary" disabled={!text.trim()} onClick={() => { report(qKey, text.trim()); onClose(); }}>Save report</button>
      </div>
    </Modal>
  );
}

function NoteBox({ qKey }: { qKey: string }) {
  const { state, qNote } = useStore();
  return (
    <div>
      <label className="qx-small" htmlFor={`note-${qKey}`}>Your private note (saved on this device)</label>
      <textarea id={`note-${qKey}`} className="qx-textarea" style={{ minHeight: 64 }} defaultValue={state.notes.question[qKey] ?? ""} onBlur={(e) => qNote(qKey, e.target.value)} maxLength={2000} key={qKey} />
    </div>
  );
}

type Mode = "feedback" | "exam";

/** One question. In "exam" mode there is no feedback; selection stays editable. */
export function QuestionView({ q, index, total, answer, mode, hinted, onAnswer, onReveal, onHint, onClear }: {
  q: QuestionRecord; index: number; total: number; answer: Answer | null; mode: Mode; hinted: boolean;
  onAnswer: (r: Response) => void; onReveal?: () => void; onHint?: () => void; onClear?: () => void;
}) {
  const { state, bookmark, addMistake } = useStore();
  const [multi, setMulti] = useState<number[]>([]);
  const [num, setNum] = useState("");
  const [reporting, setReporting] = useState(false);
  const [noting, setNoting] = useState(false);
  const locked = mode === "feedback" && answer !== null;
  const given = answer?.response ?? null;
  const topic = findTopic(q.board, q.grade, q.subjectId, q.topicId);
  const bookmarked = state.bookmarks.includes(q.id);

  useEffect(() => {
    setMulti(given?.type === "multi" ? given.indexes : []);
    setNum(given?.type === "numeric" ? String(given.value) : "");
  }, [q.id, given]);

  useEffect(() => {
    if (q.type === "numeric" || q.type === "multi-select") return;
    const on = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.tagName === "TEXTAREA" || t.tagName === "INPUT") return;
      const n = Number(e.key);
      if (Number.isInteger(n) && n >= 1 && n <= q.options.length && !locked) onAnswer({ type: "choice", index: n - 1 });
    };
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, [q, locked, onAnswer]);

  const chosen = (i: number): boolean => (given?.type === "choice" ? given.index === i : given?.type === "multi" ? given.indexes.includes(i) : false);
  const submitMulti = () => onAnswer({ type: "multi", indexes: multi });
  const submitNum = () => { const v = Number(num); if (num.trim() !== "" && Number.isFinite(v)) onAnswer({ type: "numeric", value: v }); };

  return (
    <article className="qx-card glass" aria-labelledby="qtext">
      <div className="qx-row qx-wrap" style={{ justifyContent: "space-between", marginBottom: 10 }}>
        <span className="qx-small">Question {index + 1} of {total}{topic ? ` · ${topic.title}` : ""}</span>
        <div className="qx-row" style={{ gap: 4 }}>
          <button className="qx-icon-btn" aria-pressed={bookmarked} aria-label={bookmarked ? "Remove bookmark" : "Bookmark this question"} onClick={() => bookmark(q.id)}><Bookmark size={18} fill={bookmarked ? "currentColor" : "none"} /></button>
          <button className="qx-icon-btn" aria-label="Add a private note" onClick={() => setNoting((v) => !v)}><NotebookPen size={18} /></button>
          <button className="qx-icon-btn" aria-label="Report a problem with this question" onClick={() => setReporting(true)}><ShieldAlert size={18} /></button>
        </div>
      </div>
      <Badges q={q} />
      <h2 id="qtext" className="qx-qtext" style={{ margin: "14px 0" }}>{q.prompt}</h2>
      {q.media && <p className="qx-small">Figure: {q.media.alt}</p>}
      {q.type === "multi-select" && <p className="qx-small" style={{ margin: "0 0 8px" }}>Select all that apply.</p>}

      {q.type === "numeric" ? (
        <div className="qx-row">
          <div className="qx-grow">
            <label className="qx-sr" htmlFor="num">Your answer</label>
            <input id="num" className="qx-input" inputMode="decimal" value={num} disabled={locked} placeholder={q.numeric?.unit ? `Answer (${q.numeric.unit})` : "Your answer"} onChange={(e) => { setNum(e.target.value); if (mode === "exam") { const v = Number(e.target.value); if (e.target.value.trim() === "") onClear?.(); else if (Number.isFinite(v)) onAnswer({ type: "numeric", value: v }); } }} onKeyDown={(e) => { if (e.key === "Enter" && mode === "feedback" && !locked) submitNum(); }} />
          </div>
          {mode === "feedback" && !locked && <button className="qx-btn primary" onClick={submitNum} disabled={num.trim() === "" || !Number.isFinite(Number(num))}>Check</button>}
        </div>
      ) : (
        <div className="qx-stack" role={q.type === "multi-select" ? "group" : "radiogroup"} aria-label="Answer choices">
          {q.options.map((opt, i) => {
            const isRight = q.answer.includes(i);
            const sel = q.type === "multi-select" ? multi.includes(i) : chosen(i);
            let cls = "qx-opt";
            if (locked && isRight) cls += " good"; else if (locked && sel && !isRight) cls += " bad"; else if (sel) cls += " sel";
            return (
              <button key={i} type="button" className={cls} disabled={locked} role={q.type === "multi-select" ? "checkbox" : "radio"} aria-checked={sel}
                onClick={() => {
                  if (q.type === "multi-select") { const next = multi.includes(i) ? multi.filter((x) => x !== i) : [...multi, i]; setMulti(next); if (mode === "exam") { if (next.length) onAnswer({ type: "multi", indexes: next }); else onClear?.(); } }
                  else if (mode === "exam" && sel) onClear?.();
                  else onAnswer({ type: "choice", index: i });
                }}>
                <span className="key">{LETTERS[i]}</span><span className="qx-grow">{opt}</span>
                {locked && isRight && <Check size={20} aria-label="Correct answer" />}
                {locked && sel && !isRight && <X size={20} aria-label="Your wrong answer" />}
              </button>
            );
          })}
        </div>
      )}
      {mode === "feedback" && q.type === "multi-select" && !locked && <button className="qx-btn primary block" style={{ marginTop: 12 }} disabled={!multi.length} onClick={submitMulti}>Check answer</button>}

      {mode === "feedback" && !locked && (
        <div className="qx-row qx-wrap" style={{ marginTop: 14 }}>
          {q.hint && onHint && !hinted && <button className="qx-btn sm" onClick={onHint}><Lightbulb size={16} /> Show hint</button>}
          {onReveal && <button className="qx-btn sm" onClick={onReveal}>Reveal answer</button>}
        </div>
      )}
      {mode === "feedback" && !locked && hinted && q.hint && <div className="qx-feedback info" style={{ marginTop: 12 }} aria-live="polite"><b>Hint:</b> {q.hint} <span className="qx-small">(a correct answer after a hint earns half XP)</span></div>}

      {locked && answer && (
        <PrismAnswerEffect active={!!answer.correct && !answer.revealed} motion={state.profile.motion}>
          <div className={`qx-feedback ${answer.revealed ? "info" : answer.correct ? "ok" : "bad"}`} style={{ marginTop: 14 }} role="status" aria-live="polite">
            <b>{answer.revealed ? "Answer revealed — no XP for this one" : answer.correct ? (answer.hinted ? "Correct (with hint)" : "Correct!") : "Not quite"}</b>
            {answer.correct && !answer.revealed && (
              <span style={{ marginLeft: 8 }}><PrismXPCounter delta={answer.hinted ? 5 : 10} motion={state.profile.motion} /></span>
            )}
            {!answer.correct && <p style={{ margin: "6px 0 0" }}>Answer: {q.type === "numeric" ? `${q.numeric?.value}${q.numeric?.unit ? ` ${q.numeric.unit}` : ""}` : q.answer.map((i) => q.options[i]).join(", ")}</p>}
            <p className="qx-muted" style={{ margin: "8px 0 0" }}><b>Why is this correct?</b> {q.explanation}</p>
            {q.distractorNotes && q.distractorNotes.some(Boolean) && (
              <details style={{ marginTop: 8 }}><summary style={{ cursor: "pointer", minHeight: 32 }}>Why are the other options wrong?</summary>
                <ul className="qx-muted" style={{ margin: "6px 0 0", paddingLeft: 18 }}>{q.distractorNotes.map((n, i) => (n && !q.answer.includes(i) ? <li key={i}><b>{LETTERS[i]}.</b> {n}</li> : null))}</ul>
              </details>
            )}
            {!answer.correct && <button className="qx-btn sm" style={{ marginTop: 10 }} onClick={() => addMistake(q.id)}>Add to mistakes notebook</button>}
          </div>
        </PrismAnswerEffect>
      )}
      {noting && <div style={{ marginTop: 12 }}><NoteBox qKey={q.id} /></div>}
      {reporting && <ReportDialog qKey={q.id} onClose={() => setReporting(false)} />}
    </article>
  );
}

function useNow(active: boolean): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { if (!active) return; const t = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(t); }, [active]);
  return now;
}

export function SessionScreen() {
  const { state, answer, clear, reveal, hint, mark, goto, submitExam, finishPractice, nav, dismissActive } = useStore();
  const s = state.active;
  const [confirm, setConfirm] = useState<null | "submit" | "leave">(null);
  const [navOpen, setNavOpen] = useState(false);
  const exam = s?.kind === "exam";
  const now = useNow(!!s && s.status === "active" && !!s.durationSec);
  useEffect(() => { if (s && exam && s.status === "active" && S.isExpired(s, now)) submitExam("timeout"); }, [s, exam, now, submitExam]);

  const q = useMemo(() => (s ? resolveQuestion(s.items[s.current]!.key) : null), [s]);
  if (!s) return <Empty icon={Flag} title="No active session" text="Start a practice session or a mock test from the Practice tab." action={<button className="qx-btn primary" onClick={() => nav({ name: "practice" })}>Go to Practice</button>} />;
  if (s.status === "submitted") return <ResultScreen session={s} onDone={dismissActive} />;
  const i = s.current;
  const answered = S.answeredCount(s);
  const rem = S.remainingSec(s, now);
  const a = s.answers[i];
  const item = s.items[i]!;
  const last = i === s.items.length - 1;

  return (
    <div className="qx-view qx-stack">
      <div className="qx-row" style={{ justifyContent: "space-between" }}>
        <button className="qx-btn sm" onClick={() => (exam ? setConfirm("leave") : nav({ name: "practice" }))} aria-label="Pause and leave"><ArrowLeft size={16} /> {exam ? "Pause" : "Back"}</button>
        <div className="qx-grow"><div className="qx-small" style={{ textAlign: "center" }}>{s.title}</div></div>
        {rem !== null ? <span className={`qx-chip ${rem < 60 ? "bad" : ""}`} role="timer" aria-label={`Time remaining ${fmtTime(rem)}`}><Clock size={13} /> {fmtTime(rem)}</span> : <span className="qx-chip">{answered}/{s.items.length}</span>}
      </div>
      <Progress value={(answered / s.items.length) * 100} label="Session progress" />
      {s.notes.map((n) => <div key={n} className="qx-banner">{n}</div>)}
      {item.reason && <div className="qx-small">Why this question: {item.reason}</div>}
      {!q ? <Empty icon={Flag} title="This question can't be loaded" text="It may come from content that is no longer available. Skip to the next one." /> : (
        <QuestionView key={`${s.id}-${i}`} q={q} index={i} total={s.items.length} answer={a ?? null} mode={exam ? "exam" : "feedback"} hinted={s.hints[i] ?? false}
          onAnswer={(r) => answer(i, r)} onReveal={() => reveal(i)} onHint={() => hint(i)} onClear={() => clear(i)} />
      )}
      {exam && (
        <div className="qx-row qx-wrap">
          <button className="qx-btn sm" aria-pressed={s.marked[i]} onClick={() => mark(i)}><Flag size={16} fill={s.marked[i] ? "currentColor" : "none"} /> {s.marked[i] ? "Marked for review" : "Mark for review"}</button>
          <button className="qx-btn sm" onClick={() => setNavOpen((v) => !v)}>Question navigator ({answered}/{s.items.length} answered)</button>
        </div>
      )}
      {exam && navOpen && (
        <div className="qx-card"><div className="qx-navgrid">{s.items.map((_, n) => <button key={n} className={`${s.answers[n]?.response ? "answered" : ""} ${n === i ? "current" : ""} ${s.marked[n] ? "marked" : ""}`} aria-label={`Question ${n + 1}${s.answers[n]?.response ? ", answered" : ", unanswered"}${s.marked[n] ? ", marked for review" : ""}`} onClick={() => goto(n)}>{n + 1}</button>)}</div></div>
      )}
      <div className="qx-actions">
        {exam ? (
          <>
            <button className="qx-btn" disabled={i === 0} onClick={() => goto(i - 1)} aria-label="Previous question"><ChevronLeft size={18} /></button>
            {!last ? <button className="qx-btn primary qx-grow" onClick={() => goto(i + 1)}>Next <ChevronRight size={18} /></button> : <button className="qx-btn primary qx-grow" onClick={() => setConfirm("submit")}>Review &amp; submit</button>}
            {!last && <button className="qx-btn" onClick={() => setConfirm("submit")}>Submit</button>}
          </>
        ) : (
          <>
            <button className="qx-btn" disabled={i === 0} onClick={() => goto(i - 1)} aria-label="Previous question"><ChevronLeft size={18} /></button>
            {!last ? <button className="qx-btn primary qx-grow" disabled={!a} onClick={() => goto(i + 1)}>Next question <ArrowRight size={18} /></button> : <button className="qx-btn primary qx-grow" disabled={!a} onClick={finishPractice}>Finish session</button>}
            {!last && <button className="qx-btn" onClick={() => setConfirm("leave")}>End</button>}
          </>
        )}
      </div>
      {confirm === "submit" && <Confirm title="Submit this test?" text={`You have answered ${answered} of ${s.items.length} questions${s.items.length - answered ? `, so ${s.items.length - answered} will count as unanswered` : ""}. Answers are revealed after you submit and you cannot change them.`} confirmLabel="Submit test" onCancel={() => setConfirm(null)} onConfirm={() => { setConfirm(null); submitExam("manual"); }} />}
      {confirm === "leave" && <Confirm title={exam ? "Pause the test?" : "End this session?"} text={exam ? "Your answers and the timer are saved. The clock keeps running, and you can resume from the Tests tab until time runs out." : "Questions you have answered are already saved. Ending shows your session summary."} confirmLabel={exam ? "Pause and leave" : "End session"} onCancel={() => setConfirm(null)} onConfirm={() => { setConfirm(null); if (exam) nav({ name: "tests" }); else finishPractice(); }} />}
    </div>
  );
}

export function ResultScreen({ session, onDone }: { session: Session; onDone: () => void }) {
  const r = S.computeResult(session);
  const { nav, state } = useStore();
  const [review, setReview] = useState(false);
  const [showVictory, setShowVictory] = useState(true);
  const exam = session.kind === "exam";
  const perfect = r.total >= 5 && r.correct === r.total;
  const victoryEvent = eventFor(
    levelForSession({ perfect, accuracyRecord: false, kind: session.kind }),
    { xpDelta: r.correct * 10, subtitle: perfect ? "Every answer correct" : `${r.accuracy}% accuracy` },
  );
  return (
    <div className="qx-view qx-stack">
      {showVictory && (perfect || r.total >= 5) && (
        <PrismVictoryOverlay event={victoryEvent} motion={state.profile.motion} onDone={() => setShowVictory(false)} />
      )}
      <PageHead eyebrow={exam ? "Mock test result" : "Session summary"} title={exam ? `${r.scorePct}% score` : `${r.correct} of ${r.total} correct`} sub={session.submitReason === "timeout" ? "Time ran out, so the test was submitted automatically." : session.title} />
      <div className="qx-card glass"><div className="qx-grid2"><Stat label="Correct" value={`${r.correct}/${r.total}`} /><Stat label="Accuracy" value={`${r.accuracy}%`} /><Stat label="Unanswered" value={r.skipped} /><Stat label="Time used" value={fmtTime(r.timeUsedSec)} /></div></div>
      {r.byTopic.length > 1 && (
        <div className="qx-card"><h2 className="qx-h2" style={{ marginTop: 0 }}>Topic breakdown</h2><div className="qx-stack">
          {r.byTopic.map((t) => { const info = findTopic(session.board, session.grade, t.subjectId, t.topicId); return <div key={`${t.subjectId}${t.topicId}`}><div className="qx-row" style={{ justifyContent: "space-between" }}><span>{info?.title ?? t.topicId}</span><span className="qx-small">{t.correct}/{t.total}</span></div><Progress value={(t.correct / t.total) * 100} label={`${info?.title ?? t.topicId} score`} /></div>; })}
        </div></div>
      )}
      <div className="qx-row qx-wrap">
        <button className="qx-btn primary" onClick={() => setReview((v) => !v)}>{review ? "Hide" : "Review all"} questions</button>
        <button className="qx-btn" onClick={() => { nav({ name: "revise" }); }}>Go to revision</button>
        <button className="qx-btn" onClick={onDone}>Done</button>
      </div>
      {review && <div className="qx-stack">{session.items.map((it, n) => { const q = resolveQuestion(it.key); const a = session.answers[n]; if (!q) return null; return (
        <div key={it.key + n} className="qx-card"><div className="qx-row" style={{ justifyContent: "space-between" }}><span className="qx-small">Q{n + 1}</span><span className={`qx-chip ${a?.correct ? "ok" : a?.response ? "bad" : "warn"}`}>{a?.correct ? "Correct" : a?.response ? "Wrong" : "Unanswered"}</span></div>
          <p style={{ margin: "8px 0" }}>{q.prompt}</p><p className="qx-small" style={{ margin: 0 }}>Answer: {q.type === "numeric" ? q.numeric?.value : q.answer.map((i) => q.options[i]).join(", ")}</p><p className="qx-muted" style={{ margin: "6px 0 0" }}>{q.explanation}</p></div>); })}</div>}
    </div>
  );
}
