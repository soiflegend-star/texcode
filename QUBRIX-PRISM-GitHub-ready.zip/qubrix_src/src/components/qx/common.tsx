import { Component, useEffect, useRef, type ErrorInfo, type ReactNode } from "react";
import { Atom, BookOpen, Brain, Calculator, FlaskConical, Globe2, History, Languages, Leaf, Library, type LucideIcon } from "lucide-react";
import { READINESS_LABEL, type Readiness } from "@/lib/learn/registry";
import { MASTERY_LABEL, type Mastery } from "@/lib/learn/review";

export const SUBJECT_ICON: Record<string, LucideIcon> = {
  maths: Calculator, "physical-science": Atom, life: Leaf, geography: Globe2, english: Languages, history: History, bengali: BookOpen, gk: Library, mixed: Brain, science: FlaskConical,
};
export const READY_TONE: Record<Readiness, string> = { available: "ok", partial: "info", preparing: "warn", unsupported: "" };

export function ReadyChip({ r }: { r: Readiness }) { return <span className={`qx-chip ${READY_TONE[r]}`}>{READINESS_LABEL[r]}</span>; }
export function MasteryChip({ m }: { m: Mastery }) { return <span className={`qx-chip ${m === "strong" ? "ok" : m === "practising" ? "info" : m === "learning" ? "warn" : ""}`}>{MASTERY_LABEL[m]}</span>; }
export function Progress({ value, label }: { value: number; label: string }) {
  const v = Math.max(0, Math.min(100, value));
  return <div className="qx-progress" role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(v)}><i style={{ width: `${v}%` }} /></div>;
}
export function Stat({ label, value }: { label: string; value: string | number }) { return <div className="qx-stat"><b>{value}</b><span>{label}</span></div>; }
export function Empty({ icon: Icon, title, text, action }: { icon: LucideIcon; title: string; text: string; action?: ReactNode }) {
  return <div className="qx-card qx-empty"><span className="qx-ico"><Icon size={24} /></span><h2 className="qx-h2" style={{ margin: "0 0 6px" }}>{title}</h2><p className="qx-muted" style={{ margin: "0 auto 14px", maxWidth: 360 }}>{text}</p>{action}</div>;
}
export function Skeleton() { return <div className="qx-stack" aria-busy="true" aria-label="Loading"><div className="qx-skel" style={{ height: 120 }} /><div className="qx-skel" style={{ height: 72 }} /><div className="qx-skel" style={{ height: 72 }} /></div>; }
export function PageHead({ eyebrow, title, sub }: { eyebrow?: string; title: string; sub?: string }) {
  return <div style={{ marginBottom: 12 }}>{eyebrow && <div className="qx-eyebrow">{eyebrow}</div>}<h1 className="qx-h1">{title}</h1>{sub && <p className="qx-muted" style={{ margin: 0 }}>{sub}</p>}</div>;
}

export function Modal({ title, children, onClose, labelledBy = "qx-modal-title" }: { title: string; children: ReactNode; onClose: () => void; labelledBy?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>("button, input, textarea")?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab" && ref.current) {
        const f = [...ref.current.querySelectorAll<HTMLElement>("button, input, textarea, [href]")].filter((x) => !x.hasAttribute("disabled"));
        if (!f.length) return;
        const first = f[0]!, last = f[f.length - 1]!;
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", key);
    return () => { document.removeEventListener("keydown", key); prev?.focus(); };
  }, [onClose]);
  return (
    <div className="qx-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div ref={ref} className="qx-card glass qx-modal" role="dialog" aria-modal="true" aria-labelledby={labelledBy}>
        <h2 id={labelledBy} className="qx-h2" style={{ marginTop: 0 }}>{title}</h2>
        {children}
      </div>
    </div>
  );
}
export function Confirm({ title, text, confirmLabel, danger, onConfirm, onCancel }: { title: string; text: string; confirmLabel: string; danger?: boolean; onConfirm: () => void; onCancel: () => void }) {
  return <Modal title={title} onClose={onCancel}><p className="qx-muted">{text}</p><div className="qx-row" style={{ justifyContent: "flex-end", marginTop: 14 }}><button className="qx-btn" onClick={onCancel}>Cancel</button><button className={`qx-btn ${danger ? "danger" : "primary"}`} onClick={onConfirm}>{confirmLabel}</button></div></Modal>;
}

export class ErrorBoundary extends Component<{ children: ReactNode; onReset?: () => void }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error("QUBRIX screen error", error, info.componentStack); }
  render() {
    if (!this.state.error) return this.props.children;
    return <div className="qx-card qx-empty" role="alert"><h2 className="qx-h2">Something went wrong on this screen</h2><p className="qx-muted">Your saved progress is safe. Try again, or go back to Home.</p><div className="qx-row" style={{ justifyContent: "center" }}><button className="qx-btn primary" onClick={() => { this.setState({ error: null }); this.props.onReset?.(); }}>Back to Home</button></div></div>;
  }
}

export const fmtTime = (sec: number): string => `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`;
