import { useMemo, useState } from "react";
import { ArrowRight, BookOpen, CalendarCheck, ChevronRight, Flame, GraduationCap, Layers, Lock, PlayCircle, Search as SearchIcon, Sparkles, Target, Timer, TrendingDown, Zap } from "lucide-react";
import { noteFor, referenceFor } from "@/lib/learn/content/reference-wbbse10";
import { availability, boardList, findSubject, findTopic, practiceTopics, READINESS_LABEL, subjectsOf, type TopicInfo } from "@/lib/learn/registry";
import { dateKeyOf, isDue, masteryOf, recentAccuracy } from "@/lib/learn/review";
import { levelFor } from "@/lib/learn/scoring";
import { search } from "@/lib/learn/search";
import { topicKey, type AppState } from "@/lib/learn/state";
import { Empty, MasteryChip, PageHead, Progress, ReadyChip, Stat, SUBJECT_ICON } from "./common";
import { useStore } from "./store";

export function boardLabel(id: string): string { return boardList().find((b) => b.id === id)?.name ?? id; }
function stat(state: AppState, board: string, grade: number, subjectId: string, topicId: string) { return state.topics[topicKey(board, grade, subjectId, topicId)]; }
export function inTopic(key: string, subjectId: string, topicId: string): boolean {
  if (key.startsWith("g|")) { const p = key.split("|"); return p[3] === subjectId && p[4] === topicId; }
  return key.startsWith(`a:wb10-${subjectId}-${topicId}-`);
}
function overdueMistakes(state: AppState, subjectId: string, topicId: string): number {
  return Object.entries(state.mistakes).filter(([k, m]) => !m.resolved && inTopic(k, subjectId, topicId)).length;
}

// ---------------- Onboarding ----------------
export function Onboarding() {
  const { state, patchProfile } = useStore();
  const [board, setBoard] = useState(state.profile.board);
  const [grade, setGrade] = useState(state.profile.grade);
  const boards = boardList();
  const info = availability(board, grade);
  return (
    <div className="qx-view qx-stack" style={{ maxWidth: 560, margin: "0 auto" }}>
      <div style={{ textAlign: "center", paddingTop: 10 }}><img src="/qubrix-icon.png" alt="QUBRIX" width={72} height={72} style={{ borderRadius: 18, boxShadow: "0 0 0 1px rgba(255,255,255,.14), 0 12px 40px rgba(111,94,255,.35)" }} /></div>
      <PageHead eyebrow="Welcome to QUBRIX" title="Set up your learning path" sub="Pick your board and class. Nothing to sign up for — your progress stays on this device." />
      <div className="qx-card"><label className="qx-eyebrow" htmlFor="ob-board">Board</label>
        <select id="ob-board" className="qx-input" style={{ marginTop: 6 }} value={board} onChange={(e) => setBoard(e.target.value)}>
          {boards.map((b) => <option key={b.id} value={b.id}>{b.name}{b.classes.every((c) => c.state === "unsupported") ? " — not yet supported" : ""}</option>)}
        </select>
        <label className="qx-eyebrow" htmlFor="ob-class" style={{ display: "block", marginTop: 14 }}>Class</label>
        <select id="ob-class" className="qx-input" style={{ marginTop: 6 }} value={grade} onChange={(e) => setGrade(Number(e.target.value))}>
          {[5, 6, 7, 8, 9, 10, 11].map((g) => <option key={g} value={g}>Class {g}{availability(board, g).state === "unsupported" ? " — not yet supported" : ""}</option>)}
        </select>
        <label className="qx-eyebrow" htmlFor="ob-med" style={{ display: "block", marginTop: 14 }}>Medium</label>
        <select id="ob-med" className="qx-input" style={{ marginTop: 6 }} defaultValue="en"><option value="en">English</option><option value="bn" disabled>বাংলা — not available yet</option></select>
        <div style={{ marginTop: 14 }} className="qx-row qx-wrap"><span className={`qx-chip ${info.state === "unsupported" ? "warn" : "ok"}`}>{READINESS_LABEL[info.state]}</span></div>
        <p className="qx-small" style={{ margin: "8px 0 0" }}>{info.note}</p>
      </div>
      {info.state === "unsupported" && <div className="qx-banner">QUBRIX can't offer verified practice for {boardLabel(board)} Class {grade} yet. You can continue, but only WBBSE Class 10 has questions today.</div>}
      <button className="qx-btn primary block" onClick={() => patchProfile({ onboarded: true, board, grade, medium: "en" })}>Continue <ArrowRight size={18} /></button>
      <button className="qx-btn block" onClick={() => patchProfile({ onboarded: true, board: "wbbse", grade: 10, medium: "en" })}>Continue as guest with WBBSE · Class 10</button>
    </div>
  );
}

// ---------------- Home ----------------
export function Home() {
  const { state, start, nav } = useStore();
  const { board, grade } = state.profile;
  const today = dateKeyOf(Date.now());
  const lv = levelFor(state.xp);
  const topics = practiceTopics(board, grade);
  const acc = state.totals.answered ? Math.round((state.totals.correct / state.totals.answered) * 100) : null;
  const todays = state.days[today]?.answered ?? 0;
  const dueCount = Object.values(state.reviews).filter((r) => isDue(r, today)).length;
  const last = state.profile.lastSubject && state.profile.lastTopic ? findTopic(board, grade, state.profile.lastSubject, state.profile.lastTopic) : undefined;
  const first = topics[0];
  const cont = last && last.readiness !== "preparing" ? last : first;
  const weak = useMemo(() => topics.map((t) => ({ t, s: stat(state, board, grade, t.subjectId, t.id) })).filter((x) => x.s && x.s.attempts >= 3 && (recentAccuracy(x.s) ?? 1) < 0.65).sort((a, b) => (recentAccuracy(a.s) ?? 0) - (recentAccuracy(b.s) ?? 0)).slice(0, 3), [state, topics, board, grade]);
  const recent = Object.entries(state.days).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 5);
  const daily = state.daily[today];
  const supported = topics.length > 0;
  const a = state.active;

  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow={`${boardLabel(board)} · Class ${grade}`} title={state.totals.answered ? "Welcome back" : "Let's start learning"} sub={supported ? availability(board, grade).note : "This board and class doesn't have verified practice yet."} />
      {a && a.status === "active" && (
        <button className="qx-card glass qx-link" onClick={() => nav({ name: "session" })}><span className="qx-ico"><PlayCircle size={22} /></span><span className="qx-grow"><b>Resume {a.kind === "exam" ? "your mock test" : "your session"}</b><div className="qx-small">{a.title} · {a.answers.filter(Boolean).length}/{a.items.length} answered</div></span><ChevronRight /></button>
      )}
      {!supported ? (
        <Empty icon={Lock} title="Not yet supported" text="Only WBBSE Class 10 has a mapped syllabus and practice questions today. Switch your curriculum in Settings." action={<button className="qx-btn primary" onClick={() => nav({ name: "settings" })}>Open settings</button>} />
      ) : (
        <>
          <div className="qx-card glass">
            <div className="qx-eyebrow">{state.totals.answered ? "Continue learning" : "Your starting path"}</div>
            {cont && <>
              <h2 className="qx-h2" style={{ margin: "6px 0 4px" }}>{cont.title}</h2>
              <p className="qx-muted" style={{ margin: "0 0 12px" }}>{findSubject(board, grade, cont.subjectId)?.title} · {state.totals.answered ? "pick up where you left off" : "a good first chapter: 10 questions, no timer"}</p>
              <div className="qx-row qx-wrap">
                <button className="qx-btn primary" onClick={() => start({ kind: "practice", topic: { board, grade, subjectId: cont.subjectId, topicId: cont.id }, count: 10 })}><PlayCircle size={18} /> Practise 10 questions</button>
                <button className="qx-btn" onClick={() => nav({ name: "topic", subjectId: cont.subjectId, topicId: cont.id })}>Open chapter</button>
              </div>
            </>}
            {!state.totals.answered && <ol className="qx-muted" style={{ margin: "14px 0 0", paddingLeft: 18 }}><li>Read the chapter summary in Learn.</li><li>Practise 10 questions and read each explanation.</li><li>Try the Daily Challenge, then a short mock test.</li></ol>}
          </div>
          <div className="qx-card"><div className="qx-grid2 keep">
            <Stat label={`Level ${lv.level}`} value={`${state.xp} XP`} />
            <Stat label="Day streak" value={state.streak.current ? `${state.streak.current} ${state.streak.current === 1 ? "day" : "days"}` : "—"} />
            <Stat label="Accuracy" value={acc === null ? "—" : `${acc}%`} />
            <Stat label="Today's goal" value={`${Math.min(todays, state.profile.dailyTarget)}/${state.profile.dailyTarget}`} />
          </div>
            <div style={{ marginTop: 12 }}><Progress value={(todays / state.profile.dailyTarget) * 100} label="Daily goal" /></div>
            <p className="qx-small" style={{ margin: "8px 0 0" }}>{lv.span - lv.into} XP to level {lv.level + 1}. A missed day never erases your XP.</p>
          </div>
          <div className="qx-grid2 keep">
            <button className="qx-card qx-link" style={{ flexDirection: "column", alignItems: "flex-start" }} onClick={() => nav({ name: "practice" })}><span className="qx-ico"><Target size={20} /></span><b>Practice</b><span className="qx-small">Topic, quick, adaptive</span></button>
            <button className="qx-card qx-link" style={{ flexDirection: "column", alignItems: "flex-start" }} onClick={() => nav({ name: "tests" })}><span className="qx-ico"><Timer size={20} /></span><b>Mock test</b><span className="qx-small">Timed, with results</span></button>
          </div>
          <button className="qx-card qx-link" onClick={() => (daily?.done ? nav({ name: "me" }) : start({ kind: "daily" }))}><span className="qx-ico"><CalendarCheck size={20} /></span><span className="qx-grow"><b>Daily challenge</b><div className="qx-small">{daily?.done ? `Done today — ${daily.correct}/${daily.total} correct` : "5 questions, same for everyone on this curriculum today"}</div></span>{daily?.done ? <span className="qx-chip ok">Done</span> : <ChevronRight />}</button>
          <button className="qx-card qx-link" onClick={() => nav({ name: "revise" })}><span className="qx-ico"><Layers size={20} /></span><span className="qx-grow"><b>Revision</b><div className="qx-small">{dueCount ? `${dueCount} item${dueCount === 1 ? "" : "s"} due for review` : "Nothing due right now"}</div></span><ChevronRight /></button>
          {weak.length > 0 && <div className="qx-card"><h2 className="qx-h2" style={{ marginTop: 0 }}><TrendingDown size={16} style={{ verticalAlign: "-2px" }} /> Weak topics</h2><div className="qx-stack">{weak.map(({ t, s }) => <button key={t.id} className="qx-link" style={{ background: "none", border: 0, padding: 0, minHeight: 44 }} onClick={() => nav({ name: "topic", subjectId: t.subjectId, topicId: t.id })}><span className="qx-grow">{t.title}</span><span className="qx-chip bad">{Math.round((recentAccuracy(s) ?? 0) * 100)}% recent</span><ChevronRight size={16} /></button>)}</div></div>}
          {recent.length > 0 && <div className="qx-card"><h2 className="qx-h2" style={{ marginTop: 0 }}>Recent activity</h2><div className="qx-stack">{recent.map(([d, v]) => <div key={d} className="qx-row" style={{ justifyContent: "space-between" }}><span>{d === today ? "Today" : d}</span><span className="qx-small">{v.answered} answered · {v.correct} correct · {v.xp} XP</span></div>)}</div></div>}
        </>
      )}
    </div>
  );
}

// ---------------- Learn ----------------
export function Learn() {
  const { state, nav } = useStore();
  const { board, grade } = state.profile;
  const subjects = subjectsOf(board, grade);
  const [q, setQ] = useState("");
  const info = availability(board, grade);
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow={`${boardLabel(board)} · Class ${grade}`} title="Learn" sub="Board → class → subject → chapter" />
      <div className="qx-row"><div className="qx-grow"><label className="qx-sr" htmlFor="q">Search</label><input id="q" className="qx-input" placeholder="Search subjects, chapters, formulas, questions" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && q.trim()) nav({ name: "search" }); }} /></div><button className="qx-icon-btn" aria-label="Open search" onClick={() => nav({ name: "search" })}><SearchIcon size={18} /></button></div>
      <div className="qx-row qx-wrap"><ReadyChip r={info.state} /><button className="qx-btn sm" onClick={() => nav({ name: "curriculum" })}>All boards &amp; classes</button><button className="qx-btn sm" onClick={() => nav({ name: "reference" })}>Formulas &amp; definitions</button></div>
      {subjects.length === 0 ? <Empty icon={Lock} title="Not yet supported" text={info.note} action={<button className="qx-btn primary" onClick={() => nav({ name: "settings" })}>Change curriculum</button>} /> : (
        <div className="qx-grid-auto">{subjects.map((s) => {
          const Icon = SUBJECT_ICON[s.id] ?? BookOpen;
          const strong = s.topics.filter((t) => masteryOf(stat(state, board, grade, s.id, t.id)) === "strong").length;
          const live = s.topics.filter((t) => t.readiness !== "preparing").length;
          return <button key={s.id} className="qx-card qx-link" onClick={() => nav({ name: "subject", subjectId: s.id })}><span className="qx-ico"><Icon size={20} /></span><span className="qx-grow"><b>{s.title}</b><div className="qx-small">{live} of {s.topics.length} chapters have questions{strong ? ` · ${strong} strong` : ""}</div><div style={{ marginTop: 6 }}><ReadyChip r={s.readiness} /></div></span><ChevronRight size={18} /></button>;
        })}</div>
      )}
    </div>
  );
}

export function SubjectScreen({ subjectId }: { subjectId: string }) {
  const { state, nav, start } = useStore();
  const { board, grade } = state.profile;
  const s = findSubject(board, grade, subjectId);
  if (!s) return <Empty icon={Lock} title="Subject not available" text="That subject is not part of your selected curriculum." action={<button className="qx-btn" onClick={() => nav({ name: "learn" }, { replace: true })}>Back to Learn</button>} />;
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow={`${boardLabel(board)} · Class ${grade}`} title={s.title} sub={s.readiness === "preparing" ? "Questions for this subject are being prepared. The chapter structure is shown once it is mapped from the official syllabus." : undefined} />
      <div className="qx-row qx-wrap"><ReadyChip r={s.readiness} />{s.readiness !== "preparing" && <button className="qx-btn sm" onClick={() => start({ kind: "adaptive", count: 10, subjectId })}><Sparkles size={16} /> Adaptive practice</button>}</div>
      <div className="qx-stack">{s.topics.map((t) => {
        const st = stat(state, board, grade, s.id, t.id);
        const m = masteryOf(st, overdueMistakes(state, s.id, t.id));
        const ok = t.readiness !== "preparing";
        return <button key={t.id} className="qx-card qx-link" onClick={() => nav({ name: "topic", subjectId: s.id, topicId: t.id })}><span className="qx-ico" style={{ fontWeight: 700 }}>{String(t.order).padStart(2, "0")}</span><span className="qx-grow"><b>{t.title}</b><div className="qx-row qx-wrap" style={{ gap: 6, marginTop: 6 }}><ReadyChip r={t.readiness} />{ok && <MasteryChip m={m} />}</div></span><ChevronRight size={18} /></button>;
      })}</div>
    </div>
  );
}

export function TopicScreen({ subjectId, topicId }: { subjectId: string; topicId: string }) {
  const { state, nav, start, chapterNote } = useStore();
  const { board, grade } = state.profile;
  const t = findTopic(board, grade, subjectId, topicId);
  const [tab, setTab] = useState<"learn" | "practise">("learn");
  if (!t) return <Empty icon={Lock} title="Chapter not available" text="That chapter isn't part of your selected curriculum." action={<button className="qx-btn" onClick={() => nav({ name: "learn" }, { replace: true })}>Back to Learn</button>} />;
  const tk = topicKey(board, grade, subjectId, topicId);
  const st = state.topics[tk];
  const note = noteFor(subjectId, topicId);
  const refs = referenceFor(subjectId, topicId);
  const m = masteryOf(st, overdueMistakes(state, subjectId, topicId));
  const ready = t.readiness !== "preparing";
  const ref = { board, grade, subjectId, topicId };
  const mistakes = overdueMistakes(state, subjectId, topicId);
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow={findSubject(board, grade, subjectId)?.title} title={t.title} sub={t.syllabusLabel} />
      <div className="qx-row qx-wrap"><ReadyChip r={t.readiness} />{ready && <MasteryChip m={m} />}<span className="qx-chip">{t.contentStatus === "seeded-needs-review" ? "Needs subject review" : "Content needed"}</span></div>
      <div className="qx-card"><div className="qx-eyebrow">Learning goal</div><p style={{ margin: "6px 0 0" }}>{t.objective}</p></div>
      {!ready ? <Empty icon={Lock} title="Content being prepared" text="There are no verified questions for this chapter yet, so QUBRIX won't show unrelated ones. Check back after the next content update." /> : (
        <>
          <div className="qx-card"><div className="qx-grid2 keep"><Stat label="Written questions" value={t.authored} /><Stat label="Generated slots" value={t.generated.toLocaleString("en-IN")} /><Stat label="Attempted" value={st?.attempts ?? 0} /><Stat label="Recent accuracy" value={recentAccuracy(st) === null ? "—" : `${Math.round((recentAccuracy(st) ?? 0) * 100)}%`} /></div>
            <p className="qx-small" style={{ margin: "10px 0 0" }}>Generated slots come from deterministic templates — they are practice variations, not separately written or reviewed questions.{t.readiness === "partial" ? " This chapter has a small pool, so sessions may repeat or be shorter." : ""} {mistakes ? `${mistakes} unresolved mistake${mistakes === 1 ? "" : "s"} in this chapter.` : ""}</p></div>
          <div className="qx-tabs" role="group" aria-label="Chapter sections"><button aria-pressed={tab === "learn"} onClick={() => setTab("learn")}>Learn</button><button aria-pressed={tab === "practise"} onClick={() => setTab("practise")}>Practise</button></div>
          {tab === "learn" ? (
            <div className="qx-stack">
              {note ? <div className="qx-card"><p style={{ marginTop: 0 }}>{note.summary}</p><ul className="qx-muted" style={{ paddingLeft: 18, margin: 0 }}>{note.keyPoints.map((k) => <li key={k}>{k}</li>)}</ul>
                {note.example && <div className="qx-feedback info" style={{ marginTop: 12 }}><b>Worked example.</b> {note.example.problem}<ol style={{ margin: "6px 0 0", paddingLeft: 18 }}>{note.example.steps.map((x) => <li key={x}>{x}</li>)}</ol></div>}
                <p className="qx-small" style={{ marginBottom: 0 }}>Original summary by QUBRIX — not yet checked against the prescribed textbook.</p></div>
                : <div className="qx-card"><p className="qx-muted" style={{ margin: 0 }}>A written chapter summary hasn't been added for this chapter yet.</p></div>}
              {refs.length > 0 && <div className="qx-card"><h2 className="qx-h2" style={{ marginTop: 0 }}>Formulas &amp; definitions</h2><div className="qx-stack">{refs.map((e) => <div key={e.id}><b>{e.term}</b><div className="qx-muted">{e.body}</div></div>)}</div></div>}
              <div className="qx-card"><label className="qx-eyebrow" htmlFor="cn">My notes for this chapter</label><textarea id="cn" className="qx-textarea" style={{ marginTop: 8 }} defaultValue={state.notes.chapter[tk] ?? ""} onBlur={(e) => chapterNote(tk, e.target.value)} maxLength={5000} placeholder="Private, saved on this device" /></div>
            </div>
          ) : (
            <div className="qx-stack">
              <button className="qx-btn primary block" onClick={() => start({ kind: "practice", topic: ref, count: 10 })}><PlayCircle size={18} /> Practice · 10 questions</button>
              <button className="qx-btn block" onClick={() => start({ kind: "quick", topics: [ref], count: 5 })}><Zap size={18} /> Quick · 5 questions</button>
              <button className="qx-btn block" onClick={() => start({ kind: "quick", topics: [ref], count: 20 })}><Flame size={18} /> Quick · 20 questions</button>
              {mistakes > 0 && <button className="qx-btn block" onClick={() => nav({ name: "notebook" })}>Review my mistakes</button>}
            </div>
          )}
        </>
      )}
    </div>
  );
}

export function CurriculumScreen() {
  const { state } = useStore();
  const boards = boardList();
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow="Curriculum explorer" title="Boards & classes" sub="Only combinations with a mapped syllabus and real questions can be practised." />
      {boards.map((b) => <div key={b.id} className="qx-card"><div className="qx-row" style={{ justifyContent: "space-between" }}><b>{b.name}</b><span className="qx-small">{b.exam} · {b.region}</span></div>
        <div className="qx-row qx-wrap" style={{ marginTop: 10, gap: 6 }}>{b.classes.map((c) => <span key={c.grade} className={`qx-chip ${c.state === "unsupported" ? "" : c.state === "available" ? "ok" : "info"}`} title={c.note}>Class {c.grade}: {READINESS_LABEL[c.state]}</span>)}</div>
        {b.id === state.profile.board && <p className="qx-small" style={{ margin: "8px 0 0" }}>Your current board.</p>}</div>)}
      <p className="qx-small">Change your board and class in Settings.</p>
    </div>
  );
}

export function SearchScreen() {
  const { state, nav } = useStore();
  const { board, grade } = state.profile;
  const [q, setQ] = useState("");
  const hits = useMemo(() => search(board, grade, q), [board, grade, q]);
  const go = (h: (typeof hits)[number]) => (h.kind === "subject" ? nav({ name: "subject", subjectId: h.subjectId }) : nav({ name: "topic", subjectId: h.subjectId, topicId: h.topicId }));
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow={`${boardLabel(board)} · Class ${grade}`} title="Search" />
      <label className="qx-sr" htmlFor="sq">Search</label>
      <input id="sq" className="qx-input" autoFocus placeholder="e.g. quadratic, Ohm, mole, passive" value={q} onChange={(e) => setQ(e.target.value)} />
      {q.trim() && hits.length === 0 && <Empty icon={SearchIcon} title="No results" text="Search covers your selected curriculum: subjects, chapters, formulas and written questions." />}
      <div className="qx-stack" aria-live="polite">{hits.map((h, i) => <button key={i} className="qx-card qx-link" onClick={() => go(h)}><span className="qx-grow"><span className="qx-chip info">{h.kind}</span><div style={{ marginTop: 4 }}>{h.title}</div>{"detail" in h && <div className="qx-small">{h.detail.slice(0, 120)}</div>}</span><ChevronRight size={16} /></button>)}</div>
    </div>
  );
}

export function ReferenceScreen() {
  const { state } = useStore();
  const { board, grade } = state.profile;
  const [q, setQ] = useState("");
  const [subject, setSubject] = useState("all");
  const subs = subjectsOf(board, grade);
  const all = subs.flatMap((s) => referenceFor(s.id).map((e) => ({ e, s })));
  const words = q.toLowerCase().split(/\s+/).filter(Boolean);
  const rows = all.filter(({ e, s }) => (subject === "all" || s.id === subject) && words.every((w) => `${e.term} ${e.body}`.toLowerCase().includes(w)));
  return (
    <div className="qx-view qx-stack">
      <PageHead eyebrow={`${boardLabel(board)} · Class ${grade}`} title="Formulas & definitions" sub="Unreviewed summaries — check against your textbook." />
      <input className="qx-input" aria-label="Search formulas and definitions" placeholder="Search" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="qx-tabs" role="group" aria-label="Subject filter"><button aria-pressed={subject === "all"} onClick={() => setSubject("all")}>All</button>{subs.filter((s) => referenceFor(s.id).length).map((s) => <button key={s.id} aria-pressed={subject === s.id} onClick={() => setSubject(s.id)}>{s.title.split(" ")[0]}</button>)}</div>
      {rows.length === 0 ? <Empty icon={GraduationCap} title="Nothing found" text="Try a different word or subject." /> : <div className="qx-stack">{rows.map(({ e, s }) => <div key={e.id} className="qx-card"><div className="qx-row qx-wrap" style={{ gap: 6 }}><span className="qx-chip">{s.title.split(" ")[0]}</span><span className="qx-chip info">{e.kind}</span></div><b style={{ display: "block", marginTop: 6 }}>{e.term}</b><div className="qx-muted">{e.body}</div></div>)}</div>}
    </div>
  );
}
export type { TopicInfo };
