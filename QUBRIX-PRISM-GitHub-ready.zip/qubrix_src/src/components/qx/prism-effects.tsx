/**
 * PRISM Victory Experience UI — CSS + React, respects motion preferences.
 */
import { useEffect, useState, type ReactNode, type CSSProperties } from "react";
import type { VictoryLevel } from "@/lib/prism/types";
import { intensityOf, type VictoryEvent } from "@/lib/prism/victory";

const PARTICLE_COUNT = 10;

function useReducedMotion(profileMotion?: string): boolean {
  const [sys, setSys] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setSys(mq.matches);
    const fn = () => setSys(mq.matches);
    mq.addEventListener?.("change", fn);
    return () => mq.removeEventListener?.("change", fn);
  }, []);
  if (profileMotion === "reduce" || profileMotion === "reduced") return true;
  if (profileMotion === "full") return false;
  return sys;
}

export function PrismAnswerEffect({
  active, motion, children,
}: { active: boolean; motion?: string; children: ReactNode }) {
  const reduced = useReducedMotion(motion);
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (!active) { setShow(false); return; }
    setShow(true);
    const t = window.setTimeout(() => setShow(false), reduced ? 120 : 420);
    return () => clearTimeout(t);
  }, [active, reduced]);
  return (
    <div className={`prism-answer-ok ${show ? "prism-glow" : ""}`} style={{ position: "relative" }}>
      {children}
      {show && !reduced && <span className="prism-pulse" aria-hidden />}
      {show && !reduced && (
        <span className="prism-particles" aria-hidden>
          {Array.from({ length: PARTICLE_COUNT }, (_, i) => {
            const angle = (i / PARTICLE_COUNT) * Math.PI * 2;
            const dist = 28 + (i % 3) * 10;
            return (
              <i key={i} className="prism-particle" style={{
                left: "50%", top: "50%",
                "--dx": `${Math.cos(angle) * dist}px`,
                "--dy": `${Math.sin(angle) * dist}px`,
                animationDelay: `${i * 18}ms`,
              } as CSSProperties} />
            );
          })}
        </span>
      )}
    </div>
  );
}

export function PrismXPCounter({ delta, motion }: { delta: number; motion?: string }) {
  const reduced = useReducedMotion(motion);
  if (delta <= 0) return null;
  return (
    <span className="prism-xp" aria-live="polite">
      <span className={reduced ? undefined : "prism-xp-delta"}>+{delta} XP</span>
    </span>
  );
}

export function PrismVictoryOverlay({
  event, motion, onDone, durationMs = 1400,
}: { event: VictoryEvent; motion?: string; onDone?: () => void; durationMs?: number }) {
  const reduced = useReducedMotion(motion);
  const intensity = intensityOf(event.level);
  useEffect(() => {
    if (!onDone) return;
    const t = window.setTimeout(onDone, reduced ? 500 : durationMs);
    return () => clearTimeout(t);
  }, [onDone, reduced, durationMs]);
  if (event.level === "correct" && intensity < 0.3) return null;
  return (
    <div className="prism-victory-overlay" role="status" aria-live="polite">
      <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center" }}>
        {!reduced && (<><span className="prism-rings" /><span className="prism-rings" /><span className="prism-rings" /></>)}
        <div className="prism-crystal" aria-hidden>
          <svg viewBox="0 0 64 64" fill="none">
            <defs>
              <linearGradient id="prism-g" x1="8" y1="4" x2="56" y2="60">
                <stop stopColor="#ad7bff" /><stop offset=".5" stopColor="#53e6f4" /><stop offset="1" stopColor="#f28bdf" />
              </linearGradient>
            </defs>
            <path d="M32 4 L56 24 L48 56 L16 56 L8 24 Z" fill="url(#prism-g)" fillOpacity=".35" stroke="url(#prism-g)" strokeWidth="1.5" />
            <path d="M32 4 L32 56 M8 24 L56 24 M16 56 L32 24 L48 56" stroke="rgba(255,255,255,.35)" strokeWidth="1" />
          </svg>
        </div>
        <div className="prism-victory-title">{event.title}</div>
        {event.subtitle && <div className="prism-victory-sub">{event.subtitle}</div>}
        {event.xpDelta != null && event.xpDelta > 0 && (
          <div style={{ marginTop: 10 }}><PrismXPCounter delta={event.xpDelta} motion={motion} /></div>
        )}
      </div>
    </div>
  );
}

export function PrismAchievementReveal({
  title, text, motion, onDone,
}: { title: string; text: string; motion?: string; onDone?: () => void }) {
  return (
    <PrismVictoryOverlay
      event={{ level: "achievement", title, subtitle: text }}
      motion={motion} onDone={onDone} durationMs={1600}
    />
  );
}

export type { VictoryLevel };
