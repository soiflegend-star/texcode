// Usage: node --experimental-strip-types scripts/validate-content.ts
// Exits non-zero on structural defects. Content-review gaps are reported but do not fail.
import { buildReport } from "../src/lib/learn/report.ts";
const r = buildReport(200);
console.log("QUBRIX content validation — WBBSE Class 10 (2026-27)\n");
for (const t of r.topics) console.log(`${t.subjectId.padEnd(17)} ${t.topicId.padEnd(30)} ${t.status.padEnd(20)} authored=${t.authored} sampled=${t.sampled}`);
console.log(`\nStructural defects: ${r.structural.length}\nTopic leakage: ${r.leakage.length}\nMissing generator tags: ${r.missingTags.length}`);
console.log(`Authored duplicate candidates: ${r.duplicateCandidates.authored.length}\nGenerated exact repeats within samples: ${r.duplicateCandidates.generatedExactRepeats}`);
console.log(`Unsupported board/class combinations: ${r.unsupported.length}`);
console.log(`\nReview / coverage gaps (${r.gaps.length}):`); r.gaps.forEach((g) => console.log(" -", g));
for (const i of r.structural.slice(0, 20)) console.error("DEFECT", i.id, i.code, i.message);
for (const l of [...r.leakage, ...r.missingTags].slice(0, 20)) console.error("DEFECT", l);
process.exit(r.structural.length || r.leakage.length || r.missingTags.length || r.duplicateCandidates.authored.length ? 1 : 0);
