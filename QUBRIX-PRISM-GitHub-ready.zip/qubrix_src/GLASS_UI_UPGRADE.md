# QUBRIX Glass UI Upgrade

This update is a presentation-only refinement of the existing QUBRIX v3 interface.

## What changed

- Upgraded the shared `.qx-card` surface used throughout the existing screens with layered translucent gradients, stronger glass blur/saturation, fine borders, inset highlights, and softer depth shadows.
- Refined the shared top bar and bottom navigation to use a more transparent frosted-glass treatment.
- Refined shared buttons, answer options, inputs, tabs, segmented controls, chips, progress bars, feedback panels, modals, and toast surfaces so the glass style stays consistent across screens.
- Preserved existing screen components, routes, app state, question logic, curriculum data, and interactions. No new screens or features were added.
- Added a reduced-transparency accessibility fallback and retained reduced-motion support.

## Scope

The upgrade is implemented in `src/styles.css`. It applies to the existing onboarding, home, learn, subject, topic, curriculum explorer, search, reference, practice, question session, mock tests, revision, mistakes/bookmarks notebook, flashcards, progress/profile, and settings screens through their shared QUBRIX classes.

## Validation

A production build was not completed in this environment because `npm ci` timed out during dependency installation. The project source and lockfile are unchanged except for the stylesheet and this note. Re-run `npm ci`, then `npm run build:dev` and `npm run typecheck` in an environment with package registry access.
