# PRISM Max-Level + Speed — Deliverables

## Package
`QUBRIX-PRISM-max.zip`

## Tests executed
- PRISM unit tests: **18/18 pass** (incl. speed invariants)
- Full `npm run test:quiz`: **88/88 pass**

## Speed upgrades
1. `buildExposureIndex` + `checkNoveltyFast` — O(1) novelty on planning hot path
2. WeakMap fingerprint caches
3. Single-pass `normalizePrompt`
4. Shared index across multi-topic planners
5. Tighter generator miss limits
6. Faster victory animation timings

## Capability upgrades
1. Full Novelty Guard in all major planners (topic, quick, adaptive, mixed)
2. Stronger adaptive difficulty progression
3. Victory UI wired (answer + session result)
4. Extended achievements
5. Honest pool exhaustion

## Files
See `PRISM.md` module map. Modified: `selection.ts`, `styles.css`, `question.tsx`, `achievements.ts`, `package.json`.

## Curriculum gaps
Unchanged honest list — 22 chapters still need authored content (`validate:content`).

## Follow-up wiring pass (2026-11-20)
- Added durable `AppState.prism.exposures` persistence and sanitization (backward-compatible with existing v3 saves).
- Connected exposure recording to practice answers, reveals, and submitted exam answers without double-counting attempts.
- Connected question-type rotation to shared plan finalization.
- Added regression test for exposure persistence and no-double-counting.
- Verification: PRISM 19/19; learning engine 32/32. Full aggregate test and typecheck/build not verified (aggregate run timed out; npm dependency installation did not complete).
