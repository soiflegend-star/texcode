# QUBRIX question banks

## Layers

1. **Generators** (`src/lib/quiz/*.ts`) — deterministic template families per subject. `BANK_SIZE = 30000` is a *milestone per family*, not 30,000 separately authored questions; families differ in variation capacity (some tags have 1–10 distinct slots, which repeat). Generation continues deterministically beyond the milestone.
2. **Authored bank** (`src/lib/learn/content/authored-wbbse10.ts`) — individually written `QuestionRecord`s (mcq, true-false, multi-select, numeric) with explanation, optional hint and distractor notes, difficulty, skill, objective, language, sources, origin, review state, version.
3. **Curriculum registry** (`src/lib/quiz/curriculum.ts` + `src/lib/learn/registry.ts`) — maps chapters to exact generator tags and computes readiness (*Available / Partially available / Content being prepared / Not yet supported*). Thin pools (<100 questions) are *Partially available*.
4. **Resolver** (`src/lib/learn/resolve.ts`) — stable keys: `a:<id>` for written questions, `g|board|grade|subject|topic|n` for the n-th question of a chapter stream. A key always re-resolves to the same question, so a reported question can be reproduced. Unknown topics or exhausted streams return `null`; there is **no fallback** to Maths or any other subject.

## Question types and grading

`src/lib/learn/scoring.ts` is the only grader: mcq, true-false, multi-select (exact set match) and numeric (tolerance). Short-answer is intentionally not offered — it cannot be graded reliably.

## Selection (`selection.ts`)

Topic, quick, adaptive (weakness-weighted, reproducible, explains each pick; difficulty stepping only affects written questions), revision (due → open mistakes → bookmarks), daily (seeded by date + curriculum, independent of learner state), mixed (rotates subjects that have questions), exam (seeded, no repeats). Sessions never repeat a question or near-identical prompt; thin chapters return fewer questions and say so.

## Validation

`npm run validate:content` (and `src/lib/learn/content.test.ts`) check: schema and four-distinct-option invariants, answer index, explanation, source reference, topic association, review-badge honesty, topic leakage, missing generator tags, authored near-duplicates, and unsupported board/class combinations. Structural defects fail; coverage gaps are printed as a report. Generated exact repeats inside thin pools are reported, not failed.

`src/lib/learn/supply.data.ts` is a generated snapshot of generator pool sizes (`node --experimental-strip-types scripts/gen-supply.ts`), verified by a test.

## Not done

Spaced-repetition scheduling, mastery and XP rules are covered by tests; **account sync and server storage are intentionally not built** (guest-first). Question content has not been reviewed by a subject teacher.
