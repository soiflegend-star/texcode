# QUBRIX curriculum status

_Last updated with the v3 learning-engine build._

## What is supported

| Board / class | State | Notes |
|---|---|---|
| WBBSE Class 10 (2026-27) | **Partially available** | 5 of 7 subjects have practice questions; History and Bengali are *content being prepared*. |
| WBBSE other classes; CRT, CBSE, ICSE, BSEB, UP Board, Maharashtra SSC, Tamil Nadu, Kerala (all classes) | **Not yet supported** | Catalogue entries only. No syllabus mapping, no questions. The UI gates them and serves nothing. |

## WBBSE Class 10 chapter coverage

Chapter structure comes from `src/lib/quiz/curriculum.ts` (third-party summary, provisional — see *Source basis*).

- **Mathematics (6 chapters)** — all have generator-backed practice; Arithmetic, Algebra, Geometry, Trigonometry, Mensuration and Statistics also have written questions. Compound interest and partnership are only covered by written questions.
- **Physical Science (13 chapters)** — Chemical Calculations, Thermal Phenomena, Light, Current Electricity, Periodic Table, Metallurgy, Organic Chemistry have questions (Periodic Table, Metallurgy and Organic Chemistry have very small generator pools; Periodic Table also has written questions). Environment, Gases, Atomic Nucleus, Bonding, Electricity & Chemical Reactions, Inorganic Chemistry have **no questions**.
- **Life Science (5 chapters)** — all have questions; Continuity of Life and Evolution have tiny pools (a handful of distinct questions) and are labelled *Partially available*.
- **Geography (7 chapters)** — only *India* has questions. Exogenetic processes, Atmosphere, Hydrosphere, Waste management, Maps/imagery and Map work have none.
- **English (5 chapters)** — only *Grammar and Rhetoric*. Prose, Poetry, Rapid Reader and Writing need textbook-based content.
- **History, Bengali** — chapter mapping not done; no questions are served.

## Corrections made in v3

The earlier registry listed generator tags that do not exist (e.g. "Atmosphere", "Landforms", "Arithmetic", "Environment" for Physical Science). Those chapters were never actually served. v3 maps only tags that exist and clearly belong to the chapter, and `src/lib/learn/content.test.ts` fails if a mapped tag disappears or a served question carries a foreign tag. Generator families outside the Class X summary (Probability, Gravitation, Density, Classification, …) are deliberately **not** shown under WBBSE Class 10.

## Review state of content

| Content | Real state |
|---|---|
| Generated questions | machine-validated (structure, four distinct options, valid answer, topic tag) |
| 40 written questions (`src/lib/learn/content/authored-wbbse10.ts`) | machine-validated; wording is original; facts are standard results. **Not** checked against the prescribed textbook. Source reference is the syllabus topic only (no page numbers). |
| Chapter summaries and formula/definition cards (`reference-wbbse10.ts`) | original, **unreviewed** |
| Nothing | is `source-checked` or `human-reviewed` — the validator rejects those labels without a textbook/official source |

No question is labelled a previous-year question. Written questions say *exam-style practice*; generated ones say *practice*.

## Source basis

- Careers360, *West Bengal Madhyamik Syllabus 2026-27* (third-party, provisional): https://school.careers360.com/boards/wbbse/west-bengal-madhyamik-syllabus
- Banglar Shiksha portal lists Class X textbooks by subject: https://banglarshiksha.wb.gov.in/Frontend/online_guidelines_activities_beng

The board's own syllabus PDF and the prescribed textbooks are the final authority and **were not accessible in the build environment**. A search for History chapter lists returned only third-party sites, so History was left unmapped rather than guessed.

## Remaining human work

1. Obtain the official WBBSE Class X syllabus; confirm/adjust the chapter list (especially History and Bengali).
2. A subject teacher reviews every written question and summary against the textbooks, adds page references, then promotes `review` to `source-checked` / `human-reviewed`.
3. Author chapter-specific questions for the 22 chapters listed as gaps by `npm run validate:content`.
4. Bengali medium: translations and Bengali-subject content need native-speaker authoring; the language selector offers only English until then.
