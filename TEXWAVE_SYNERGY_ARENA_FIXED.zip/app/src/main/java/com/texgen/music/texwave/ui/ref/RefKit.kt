package com.texgen.music.texwave.ui.ref

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.components.LocalCustomArt
import java.io.File

/** Palette + shared constants sampled from the 12-screen TEXWAVE reference. */
object Ref {
    val Bg = Color(0xFF02040C)
    val Bg2 = Color(0xFF050A1B)
    val Card = Color(0xFF09122E)
    val CardHi = Color(0xFF0E1A42)
    val Line = Color(0xFF1A2B63)
    val LineHi = Color(0xFF2B4A9C)
    val Cyan = Color(0xFF19D3F2)
    val Blue = Color(0xFF2F7BFF)
    val Violet = Color(0xFF9B6BFF)
    val Purple = Color(0xFF6D3FF0)
    val Magenta = Color(0xFFFF58D8)
    val Text = Color(0xFFF4F6FF)
    val Sub = Color(0xFF5F7FD6)
    val Muted = Color(0xFF8FA0CC)
    val Faint = Color(0xFF3A4C86)
    val Lavender = Color(0xFFC3A8FF)

    /** Name shown in "Good evening, X" and Phantom greeting. */
    const val UserName = "SOIF"
}

val RefThumbs = intArrayOf(
    R.drawable.ref_th_afterdark, R.drawable.ref_th_nights, R.drawable.ref_th_faded,
    R.drawable.ref_th_legends, R.drawable.ref_th_smells, R.drawable.ref_th_believer,
    R.drawable.ref_th_arcade, R.drawable.ref_pl_chill, R.drawable.ref_pl_focus, R.drawable.ref_pl_workout,
)

fun refThumbFor(key: String): Int = RefThumbs[(key.hashCode() and 0x7fffffff) % RefThumbs.size]

/** Dark navy gradient with a violet corner glow, like every reference screen. */
@Composable
fun RefBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ref.Bg, Ref.Bg2, Ref.Bg)))
            .drawBehind {
                val r = size.width * 0.75f
                val c = Offset(size.width * 0.98f, size.height * 0.03f)
                drawCircle(
                    Brush.radialGradient(listOf(Ref.Violet.copy(alpha = 0.18f), Color.Transparent), center = c, radius = r),
                    radius = r, center = c,
                )
                val r2 = size.width * 0.6f
                val c2 = Offset(0f, size.height * 0.55f)
                drawCircle(
                    Brush.radialGradient(listOf(Ref.Blue.copy(alpha = 0.10f), Color.Transparent), center = c2, radius = r2),
                    radius = r2, center = c2,
                )
            },
        content = content,
    )
}

/** Rounded navy card with thin blue glow border. */
fun Modifier.refCard(radius: Dp = 16.dp, hot: Boolean = false): Modifier {
    val s = RoundedCornerShape(radius)
    val edge = if (hot) listOf(Ref.Violet.copy(alpha = 0.8f), Ref.Cyan.copy(alpha = 0.7f))
    else listOf(Ref.Line, Ref.Line.copy(alpha = 0.6f))
    return this
        .clip(s)
        .background(Brush.verticalGradient(listOf(Ref.CardHi.copy(alpha = 0.9f), Ref.Card)))
        .drawBehind {
            // soft top sheen + faint colour bloom: gives cards depth instead of a flat fill
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.07f), Color.Transparent), endY = size.height * 0.55f))
            drawRect(
                Brush.radialGradient(
                    listOf(Ref.Violet.copy(alpha = if (hot) 0.22f else 0.08f), Color.Transparent),
                    center = Offset(size.width * 0.9f, 0f), radius = size.width * 0.7f,
                ),
            )
        }
        .border(1.dp, Brush.verticalGradient(listOf(edge.first().copy(alpha = if (hot) 0.9f else 0.8f), edge.last())), s)
}

@Composable
fun RefImage(
    @DrawableRes id: Int,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(0.dp),
    scale: ContentScale = ContentScale.Crop,
    alignment: Alignment = Alignment.Center,
) {
    Image(
        painter = painterResource(id),
        contentDescription = null,
        modifier = modifier.clip(shape),
        contentScale = scale,
        alignment = alignment,
    )
}

/** Song cover: real album art when present, otherwise a reference-style cover.
 *  Crop fills the frame (no stretch / no letterbox). High-res decode keeps it sharp. */
@Composable
fun SongThumb(
    song: Song?,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    @DrawableRes fallback: Int? = null,
    artOverride: String? = null,
    hiRes: Int = 2560,
) {
    val custom = LocalCustomArt.current
    val raw = artOverride ?: song?.let { custom[it.id] } ?: song?.artUri
    val model: Any? = when {
        raw == null -> null
        raw.startsWith("/") -> File(raw)
        raw.startsWith("file:") -> File(android.net.Uri.parse(raw).path ?: raw)
        else -> raw
    }
    val fb = fallback ?: refThumbFor(song?.album ?: song?.title ?: "texwave")
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // Sharp art: pull the embedded cover (full resolution) instead of the tiny MediaStore thumbnail.
    val hi by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, song?.id, raw, hiRes) {
        value = if (song != null && artOverride == null && custom[song.id] == null) HiResArt.load(ctx, song, hiRes) else null
    }
    val coilModel = if (model != null) {
        coil.request.ImageRequest.Builder(ctx)
            .data(model)
            .size(coil.size.Size(hiRes, hiRes))
            .allowHardware(true)
            .crossfade(180)
            .build()
    } else null
    Box(
        modifier
            .clip(shape)
            .background(Color(0xFF0A0C14)),
        contentAlignment = Alignment.Center,
    ) {
        Image(painterResource(fb), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (hi != null) {
            Image(
                bitmap = hi!!.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.High, modifier = Modifier.fillMaxSize(),
            )
        } else if (coilModel != null) {
            AsyncImage(
                model = coilModel,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                filterQuality = FilterQuality.High,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/** In-memory cache of full-resolution cover art, keyed by song + size bucket. */
object HiResArt {
    private val cache = object : android.util.LruCache<String, android.graphics.Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: String, value: android.graphics.Bitmap) = value.byteCount
    }
    private val misses = java.util.Collections.synchronizedSet(HashSet<String>())

    suspend fun load(ctx: android.content.Context, song: Song, px: Int): android.graphics.Bitmap? {
        val key = "${song.id}@$px"
        cache.get(key)?.let { return it }
        if (key in misses || !song.contentUri.startsWith("content:")) return null
        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val uri = android.net.Uri.parse(song.contentUri)
            var bmp: android.graphics.Bitmap? = null
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                bmp = runCatching { ctx.contentResolver.loadThumbnail(uri, android.util.Size(px, px), null) }.getOrNull()
            }
            if (bmp == null) {
                bmp = runCatching {
                    val r = android.media.MediaMetadataRetriever()
                    try {
                        r.setDataSource(ctx, uri)
                        r.embeddedPicture?.let { b ->
                            val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            android.graphics.BitmapFactory.decodeByteArray(b, 0, b.size, o)
                            var sample = 1
                            while (o.outWidth / (sample * 2) >= px) sample *= 2
                            android.graphics.BitmapFactory.decodeByteArray(b, 0, b.size, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
                        }
                    } finally { runCatching { r.release() } }
                }.getOrNull()
            }
            if (bmp != null) cache.put(key, bmp) else misses.add(key)
            bmp
        }
    }
}

/** "TEXWAVE" wide gradient wordmark. */
@Composable
fun RefWordmark(fontSize: TextUnit = 24.sp, modifier: Modifier = Modifier) {
    Text(
        "TEXWAVE",
        modifier = modifier,
        style = TextStyle(
            brush = Brush.horizontalGradient(
                listOf(Color(0xFF22E0F5), Color(0xFF35B8FF), Color(0xFFB784FF), Color(0xFFD9CCFF)),
            ),
            fontSize = fontSize,
            fontWeight = FontWeight.Medium,
            fontFamily = FontFamily.SansSerif,
            letterSpacing = fontSize * 0.2f,
        ),
    )
}


@Composable
fun IconCircle(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0x22FFFFFF))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun ScreenTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        color = Color.White,
        fontSize = 28.sp,
        fontWeight = FontWeight.Medium,
    )
}

@Composable
fun SectionTitle(title: String, action: String? = "See All", onAction: () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text(
                action, color = Ref.Cyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable(onClick = onAction),
            )
        }
    }
}

/** Standard list row: thumb + title + subtitle + chevron, inside a glow card. */
@Composable
fun RefRow(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    card: Boolean = true,
    thumbBorder: Boolean = false,
    chevron: Boolean = true,
    onChevron: (() -> Unit)? = null,
    onClick: () -> Unit,
    thumb: @Composable () -> Unit,
) {
    Row(
        modifier
            .let { if (card) it.refCard(18.dp) else it }
            .clickable(onClick = onClick)
            .padding(horizontal = if (card) 10.dp else 0.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.let {
                if (thumbBorder) it.border(1.5.dp, Ref.Cyan.copy(alpha = 0.85f), RoundedCornerShape(14.dp)) else it
            }
        ) { thumb() }
        Box(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            Text(subtitle, color = Ref.Sub, fontSize = 13.sp, maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
        if (chevron) {
            Box(
                Modifier
                    .size(36.dp)
                    .let { if (onChevron != null) it.clickable(onClick = onChevron) else it },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.ChevronRight, null, tint = Color(0xFFBFD0FF), modifier = Modifier.size(24.dp))
            }
        }
    }
}

/** Slowly rotating glowing ring used behind orbs. */
@Composable
fun GlowRing(modifier: Modifier = Modifier, strokeDp: Dp = 3.dp, speedMs: Int = 9000) {
    val t = rememberInfiniteTransition(label = "ring")
    val a by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(speedMs, easing = LinearEasing), RepeatMode.Restart),
        label = "ringA",
    )
    Canvas(modifier) {
        val sw = strokeDp.toPx()
        val brush = Brush.sweepGradient(
            listOf(Ref.Cyan, Ref.Blue, Ref.Violet, Ref.Magenta.copy(alpha = 0.7f), Ref.Blue, Ref.Cyan),
            center = center,
        )
        rotate(a) {
            drawCircle(brush, radius = size.minDimension / 2f - sw, style = Stroke(sw, cap = StrokeCap.Round))
        }
        drawCircle(
            Ref.Cyan.copy(alpha = 0.10f),
            radius = size.minDimension / 2f - sw * 0.2f,
            style = Stroke(sw * 3f),
        )
    }
}

/** Small round glass icon button (reference header buttons). */
@Composable
fun GlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 42.dp,
    tint: Color = Color.White,
    square: Boolean = false,
) {
    val shape: Shape = if (square) RoundedCornerShape(14.dp) else CircleShape
    Box(
        modifier
            .size(size)
            .clip(shape)
            .background(Brush.linearGradient(listOf(Ref.Purple.copy(alpha = 0.55f), Ref.CardHi)))
            .border(1.dp, Ref.Violet.copy(alpha = 0.5f), shape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

/** Gradient-bordered rounded square (search categories, highlights). */
@Composable
fun NeonTile(
    modifier: Modifier = Modifier,
    corner: Dp = 18.dp,
    colors: List<Color>,
    content: @Composable BoxScope.() -> Unit,
) {
    val s = RoundedCornerShape(corner)
    Box(
        modifier
            .clip(s)
            .background(Brush.verticalGradient(listOf(colors.first().copy(alpha = 0.16f), Ref.Card)))
            .border(1.5.dp, Brush.linearGradient(colors), s),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

/** Reference artist photos, matched by name only (never shown for other artists). */
fun artistPhotoRes(name: String): Int? {
    val n = name.lowercase()
    return when {
        "weeknd" in n -> R.drawable.ref_artist_weeknd
        "imagine dragons" in n -> R.drawable.ref_artist_dragons
        "alan walker" in n -> R.drawable.ref_artist_walker
        "arijit" in n -> R.drawable.ref_artist_arijit
        else -> null
    }
}

/** Round avatar: photo if known, otherwise gradient with initials. */
@Composable
fun InitialsAvatar(name: String, modifier: Modifier = Modifier, ringColors: List<Color> = listOf(Ref.Violet, Ref.Blue)) {
    val photo = artistPhotoRes(name)
    Box(
        modifier
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Ref.Purple.copy(alpha = 0.7f), Ref.Blue.copy(alpha = 0.5f))))
            .border(2.dp, Brush.linearGradient(ringColors), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (photo != null) {
            Image(painterResource(photo), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            val ini = name.trim().split(" ").filter { it.isNotEmpty() }.take(2)
                .joinToString("") { it.first().uppercase() }.ifEmpty { "T" }
            Text(ini, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        }
    }
}

/** Crisp typeface bundled with the app (Inter). */
val RefFont = androidx.compose.ui.text.font.FontFamily(
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_light, androidx.compose.ui.text.font.FontWeight.Light),
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_regular, androidx.compose.ui.text.font.FontWeight.Normal),
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_medium, androidx.compose.ui.text.font.FontWeight.Medium),
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_semibold, androidx.compose.ui.text.font.FontWeight.SemiBold),
    androidx.compose.ui.text.font.Font(com.texgen.music.texwave.R.font.inter_bold, androidx.compose.ui.text.font.FontWeight.Bold),
)

/**
 * App-wide polish: the mockup was designed for a ~400dp canvas, so scale density down a touch on
 * narrower phones (sharper, less oversized UI) and apply the Inter typeface everywhere.
 */
@androidx.compose.runtime.Composable
fun RefPolish(content: @androidx.compose.runtime.Composable () -> Unit) {
    val d = androidx.compose.ui.platform.LocalDensity.current
    val widthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val k = (widthDp / 400f).coerceIn(0.86f, 1f)
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(d.density * k, d.fontScale.coerceAtMost(1.15f)),
    ) {
        androidx.compose.material3.ProvideTextStyle(
            androidx.compose.ui.text.TextStyle(fontFamily = RefFont, letterSpacing = 0.sp),
            content,
        )
    }
}
