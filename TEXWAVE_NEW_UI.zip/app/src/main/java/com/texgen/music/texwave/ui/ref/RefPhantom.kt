package com.texgen.music.texwave.ui.ref

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import kotlinx.coroutines.launch

private data class Bubble(val mine: Boolean, val text: String, val error: Boolean = false)

/**
 * Reference screen 6 — Phantom, "Your AI Companion".
 * Chats inline through [onSend]; the full studio (images, voice, API key) stays one tap away via [onOpenStudio].
 */
@Composable
fun RefPhantomScreen(
    onBack: () -> Unit,
    onSend: suspend (text: String, history: List<Pair<String, String>>) -> Result<String>,
    onOpenStudio: () -> Unit,
    onQuickHome: () -> Unit,
    onQuickReels: () -> Unit,
    onQuickSearch: () -> Unit,
    onQuickShare: () -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("texwave_ui", android.content.Context.MODE_PRIVATE) }
    val msgs = remember {
        mutableStateListOf<Bubble>().also { l ->
            runCatching {
                val arr = org.json.JSONArray(prefs.getString("phantom_chat", "[]"))
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    l.add(Bubble(o.getBoolean("m"), o.getString("t"), o.optBoolean("e")))
                }
            }
        }
    }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var speakReplies by remember { mutableStateOf(prefs.getBoolean("phantom_speak", false)) }
    val speech = remember { com.texgen.music.texwave.util.SpeechOut(context) }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { runCatching { speech.stop() } } }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current

    fun persist() {
        val arr = org.json.JSONArray()
        msgs.takeLast(60).forEach { arr.put(org.json.JSONObject().put("m", it.mine).put("t", it.text).put("e", it.error)) }
        prefs.edit().putString("phantom_chat", arr.toString()).apply()
    }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        val history = msgs.filter { !it.error }.takeLast(16).map { (if (it.mine) "user" else "assistant") to it.text }
        msgs.add(Bubble(true, text))
        draft = ""
        busy = true
        persist()
        scope.launch {
            val r = try { onSend(text, history) } catch (e: Exception) { Result.failure(e) }
            val ok = r.getOrNull()
            if (ok != null) {
                val reply = ok.ifBlank { "Done." }
                msgs.add(Bubble(false, reply))
                if (speakReplies) runCatching { speech.speak(reply.take(600)) }
            } else {
                val m = r.exceptionOrNull()?.message?.takeIf { it.isNotBlank() } ?: "Something went wrong"
                msgs.add(Bubble(false, m, error = true))
            }
            busy = false
            persist()
        }
    }

    val micLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
    ) { res ->
        val said = res.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == android.app.Activity.RESULT_OK && !said.isNullOrBlank()) send(said)
    }
    fun startMic() {
        val i = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Talk to Phantom")
        }
        try { micLauncher.launch(i) } catch (_: Exception) {
            android.widget.Toast.makeText(context, "Voice input isn't available on this phone", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    LaunchedEffect(msgs.size, busy) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size)
    }

    val t = rememberInfiniteTransition(label = "orb")
    val spin by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart), label = "spin",
    )
    val breathe by t.animateFloat(
        0.96f, 1.04f, infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "breathe",
    )
    val chatting = msgs.isNotEmpty()

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)) {
                Box(
                    Modifier.align(Alignment.CenterStart).size(44.dp).clip(CircleShape)
                        .background(Color(0xFF17181D)).border(1.dp, Ref.Line, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(22.dp)) }
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Phantom",
                        style = TextStyle(
                            brush = Brush.horizontalGradient(listOf(Color(0xFFE9DFFF), Color(0xFFB9A0FF), Color(0xFFE9DFFF))),
                            fontSize = 30.sp, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Medium,
                        ),
                    )
                    Text("Your AI Companion", color = Color.White, fontSize = 14.sp)
                }
                Row(Modifier.align(Alignment.CenterEnd), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (speakReplies) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff,
                        "Speak replies", tint = if (speakReplies) Ref.Cyan else Ref.Muted,
                        modifier = Modifier.size(24.dp).clickable {
                            speakReplies = !speakReplies
                            prefs.edit().putBoolean("phantom_speak", speakReplies).apply()
                            if (!speakReplies) runCatching { speech.stop() }
                        },
                    )
                    if (chatting) Icon(
                        Icons.Rounded.DeleteSweep, "New chat", tint = Ref.Muted,
                        modifier = Modifier.size(24.dp).clickable { msgs.clear(); persist(); runCatching { speech.stop() } },
                    )
                    Icon(
                        Icons.Rounded.OpenInNew, "Open studio", tint = Ref.Muted,
                        modifier = Modifier.size(24.dp).clickable(onClick = onOpenStudio),
                    )
                }
            }

            if (!chatting) {
                Column(Modifier.weight(1f).padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    val shape = RoundedCornerShape(24.dp)
                    Column(
                        Modifier.fillMaxWidth().padding(top = 8.dp).clip(shape)
                            .background(Brush.verticalGradient(listOf(Color(0xFF1B1C22), Color(0xFF17181D))))
                            .border(1.2.dp, Brush.horizontalGradient(listOf(Ref.Violet.copy(alpha = 0.8f), Ref.Blue.copy(alpha = 0.7f))), shape)
                            .padding(20.dp),
                    ) {
                        Text("Hey ${Ref.UserName} 💜", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "I'm Phantom. Your AI companion.\nAsk me anything, create, explore,\nor just talk...",
                            color = Color.White, fontSize = 15.sp, lineHeight = 22.sp,
                        )
                    }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        NebulaOrb(Modifier.fillMaxWidth(0.9f), energy = if (busy) 2.4f else 1f)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Chip("Explain something", null, listOf(Ref.Violet, Ref.Purple), Modifier.weight(1.15f)) { send("Explain something interesting to me") }
                        Chip("Give me ideas", null, listOf(Ref.Blue, Ref.Violet), Modifier.weight(1f)) { send("Give me some ideas") }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Chip("Help me create", Icons.Rounded.Create, listOf(Ref.Cyan, Ref.Violet), Modifier.weight(1.1f)) { send("Help me create something") }
                        Chip("Just chat", Icons.Rounded.Chat, listOf(Ref.Cyan, Ref.Blue), Modifier.weight(1f)) { send("Hey Phantom, just chat with me") }
                    }
                    Spacer(Modifier.height(18.dp))
                }
            } else {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 6.dp, bottom = 8.dp),
                ) {
                    item {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            NebulaOrb(Modifier.size(78.dp), energy = if (busy) 2.4f else 1f)
                            Text("Phantom", color = Color(0xFFB9A0FF), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    items(msgs.size) { i ->
                        val m = msgs[i]
                        val shape = if (m.mine) RoundedCornerShape(20.dp, 20.dp, 5.dp, 20.dp) else RoundedCornerShape(20.dp, 20.dp, 20.dp, 5.dp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Bottom) {
                            if (!m.mine) {
                                Box(
                                    Modifier.size(28.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Ref.Violet, Ref.Blue))),
                                    contentAlignment = Alignment.Center,
                                ) { Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                                Spacer(Modifier.size(8.dp))
                            }
                            Column(horizontalAlignment = if (m.mine) Alignment.End else Alignment.Start) {
                                Text(
                                    chatText(m.text), color = if (m.error) Color(0xFFFFB4C6) else Color.White,
                                    fontSize = 15.sp, lineHeight = 22.sp,
                                    modifier = Modifier
                                        .widthIn(max = 300.dp)
                                        .clip(shape)
                                        .background(
                                            when {
                                                m.error -> Brush.verticalGradient(listOf(Color(0xFF3A1226), Color(0xFF2A0D1D)))
                                                m.mine -> Brush.linearGradient(listOf(Color(0xFF5530D8), Color(0xFF2D46B4)))
                                                else -> Brush.verticalGradient(listOf(Color(0xFF111F54), Color(0xFF0B1439)))
                                            },
                                        )
                                        .border(1.dp, when { m.error -> Color(0xFFFF5A7A).copy(alpha = 0.5f); m.mine -> Ref.Violet.copy(alpha = 0.5f); else -> Ref.Line }, shape)
                                        .clickable {
                                            clipboard.setText(androidx.compose.ui.text.AnnotatedString(m.text))
                                            android.widget.Toast.makeText(context, "Copied", android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                )
                                if (m.error && i == msgs.lastIndex && !busy) {
                                    val lastUser = msgs.lastOrNull { it.mine }?.text
                                    if (lastUser != null) Text(
                                        "Tap to retry", color = Ref.Cyan, fontSize = 12.sp,
                                        modifier = Modifier.padding(top = 4.dp, start = 4.dp).clickable {
                                            msgs.removeAt(msgs.lastIndex)
                                            msgs.removeAt(msgs.lastIndex)
                                            send(lastUser)
                                        },
                                    )
                                }
                            }
                        }
                    }
                    if (busy) item { TypingDots() }
                }
            }

            // Quick commands (all handled by Phantom's offline brain, no internet needed)
            androidx.compose.foundation.lazy.LazyRow(
                Modifier.fillMaxWidth().padding(bottom = 10.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                val cmds = listOf("What's playing?", "Next", "Previous", "Pause", "Infinite mix", "Weather", "My stats")
                items(cmds.size) { i ->
                    val c = cmds[i]
                    val cs = RoundedCornerShape(18.dp)
                    Text(
                        c, color = Color(0xFFDCE5FF), fontSize = 13.sp,
                        modifier = Modifier.clip(cs).background(Color(0xFF17181D)).border(1.dp, Ref.Line, cs)
                            .clickable { send(c) }.padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                }
            }

            // Input pill with mic + send
            val pill = RoundedCornerShape(28.dp)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).heightIn(min = 54.dp).clip(pill)
                    .background(Brush.horizontalGradient(listOf(Color(0xFF17181D), Color(0xFF17181D))))
                    .border(1.2.dp, Brush.horizontalGradient(listOf(Ref.LineHi, Ref.Violet.copy(alpha = 0.6f), Ref.Cyan.copy(alpha = 0.5f))), pill)
                    .padding(start = 18.dp, end = 5.dp, top = 5.dp, bottom = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = draft, onValueChange = { draft = it }, maxLines = 4,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(Ref.Cyan),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Send),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSend = { send(draft) }),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (draft.isEmpty()) Text("Message Phantom...", color = Color(0xFF8FA0E0), fontSize = 15.sp)
                            inner()
                        }
                    },
                )
                Box(Modifier.size(42.dp).clip(CircleShape).clickable { startMic() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Mic, "Voice", tint = Ref.Cyan, modifier = Modifier.size(22.dp))
                }
                Box(
                    Modifier.size(42.dp).clip(CircleShape)
                        .background(if (draft.isBlank() || busy) Color(0xFF3A4580) else Color(0xFF6B7BE0))
                        .clickable { send(draft) },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Send, "Send", tint = Color.White, modifier = Modifier.size(20.dp)) }
            }

            // Faint 4-icon quick bar from the reference
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 36.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                QuickIcon(Icons.Rounded.Home, onQuickHome)
                QuickIcon(Icons.Rounded.Download, onQuickReels)
                QuickIcon(Icons.Rounded.Public, onQuickSearch)
                QuickIcon(Icons.Rounded.Share, onQuickShare)
            }
        }
    }
}

@Composable
private fun QuickIcon(icon: ImageVector, onClick: () -> Unit) {
    Icon(icon, null, tint = Ref.Faint, modifier = Modifier.size(24.dp).clickable(onClick = onClick))
}

@Composable
private fun Chip(label: String, icon: ImageVector?, colors: List<Color>, modifier: Modifier, onClick: () -> Unit) {
    val s = RoundedCornerShape(26.dp)
    Row(
        modifier.height(50.dp).clip(s)
            .background(Brush.horizontalGradient(listOf(Color(0xFF17181D), Color(0xFF17181D))))
            .border(1.5.dp, Brush.horizontalGradient(colors), s)
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Ref.Cyan, modifier = Modifier.size(16.dp))
            Spacer(Modifier.size(6.dp))
        }
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Tiny markdown: **bold** and "- " / "* " bullets become real formatting. */
private fun chatText(raw: String): androidx.compose.ui.text.AnnotatedString =
    androidx.compose.ui.text.buildAnnotatedString {
        raw.lines().forEachIndexed { li, line0 ->
            if (li > 0) append("\n")
            val line = when {
                line0.startsWith("- ") || line0.startsWith("* ") -> "• " + line0.drop(2)
                else -> line0
            }
            var rest = line
            while (true) {
                val a = rest.indexOf("**")
                val b = if (a >= 0) rest.indexOf("**", a + 2) else -1
                if (a < 0 || b < 0) { append(rest); break }
                append(rest.substring(0, a))
                pushStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.Bold))
                append(rest.substring(a + 2, b))
                pop()
                rest = rest.substring(b + 2)
            }
        }
    }

@Composable
private fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    val shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 5.dp)
    Row(
        Modifier.padding(start = 36.dp).clip(shape).background(Color(0xFF1B1C22)).border(1.dp, Ref.Line, shape)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        for (i in 0 until 3) {
            val a by t.animateFloat(
                0.25f, 1f,
                infiniteRepeatable(tween(600, delayMillis = i * 160), RepeatMode.Reverse), label = "d$i",
            )
            Box(Modifier.size(8.dp).clip(CircleShape).background(Ref.Cyan.copy(alpha = a)))
        }
    }
}
