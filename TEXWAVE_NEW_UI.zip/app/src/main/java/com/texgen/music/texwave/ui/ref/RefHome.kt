package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import java.util.Calendar

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 5 -> "Good night"
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

/** Home: continue listening, quick shortcuts and EVERY feature, grouped, one tap away. */
@Composable
fun RefHomeScreen(
    lib: LibraryState,
    player: PlayerState,
    userName: String = Ref.UserName,
    onPlay: (List<Song>, Int) -> Unit,
    onOpenNowPlaying: () -> Unit,
    onShuffle: () -> Unit,
    onSeeAll: () -> Unit,
    items: List<MoreItem> = emptyList(),
    onSearch: () -> Unit = {},
    onOpenMenu: () -> Unit = {},
) {
    val recent = remember(lib.songs, lib.recents) {
        val byId = lib.songs.associateBy { it.id }
        val r = lib.recents.mapNotNull { byId[it] }.distinctBy { it.id }
        (if (r.isEmpty()) lib.songs else r).take(8)
    }
    val heroSong = player.current ?: recent.firstOrNull()
    val display = userName.trim().ifBlank { Ref.UserName }
    val grouped = remember(items) { items.groupBy { it.section.ifBlank { "MORE" } } }
    val quickNames = listOf("Chats", "Chat", "Phantom", "Synergy Arena", "Discover", "Equalizer", "Alarms", "Downloads")
    val quick = remember(items) {
        quickNames.mapNotNull { q -> items.firstOrNull { it.label.equals(q, true) } }.distinctBy { it.label }
    }

    RefBackground {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 12.dp, top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(greeting(), color = Ref.Muted, fontSize = 14.sp)
                        Text(display, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    }
                    GlassIconButton(Icons.Rounded.Shuffle, onShuffle, size = 44.dp, square = true)
                }
            }
            item {
                val shape = RoundedCornerShape(14.dp)
                Row(
                    Modifier
                        .padding(horizontal = 20.dp, vertical = 16.dp)
                        .fillMaxWidth()
                        .height(50.dp)
                        .clip(shape)
                        .background(Ref.Card)
                        .border(1.dp, Ref.Line, shape)
                        .clickable(onClick = onSearch)
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Search, null, tint = Ref.Muted, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Search songs, artists, playlists, features…", color = Ref.Muted, fontSize = 14.sp, maxLines = 1)
                }
            }
            if (heroSong != null) {
                item {
                    val shape = RoundedCornerShape(20.dp)
                    Row(
                        Modifier
                            .padding(horizontal = 20.dp)
                            .fillMaxWidth()
                            .clip(shape)
                            .background(Brush.horizontalGradient(listOf(Ref.Violet.copy(alpha = 0.28f), Ref.Card)))
                            .border(1.dp, Ref.Line, shape)
                            .clickable {
                                if (player.current != null) onOpenNowPlaying()
                                else onPlay(lib.songs, lib.songs.indexOfFirst { it.id == heroSong.id }.coerceAtLeast(0))
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SongThumb(heroSong, Modifier.size(84.dp), RoundedCornerShape(14.dp))
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (player.current != null) "NOW PLAYING" else "JUMP BACK IN",
                                color = Ref.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                heroSong.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            )
                            Text(
                                heroSong.artist, color = Ref.Muted, fontSize = 14.sp,
                                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            )
                        }
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(Ref.Cyan),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Rounded.PlayArrow, "Play", tint = Color(0xFF04120C), modifier = Modifier.size(32.dp))
                        }
                    }
                }
            }
            if (quick.isNotEmpty()) {
                item { Spacer(Modifier.height(18.dp)) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
                    ) {
                        items(quick.size) { i ->
                            val q = quick[i]
                            Row(
                                Modifier
                                    .clip(CircleShape)
                                    .background(Ref.Card)
                                    .border(1.dp, Ref.Line, CircleShape)
                                    .clickable(onClick = q.onClick)
                                    .padding(horizontal = 14.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(q.icon, null, tint = Ref.Cyan, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(q.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
            item { SectionTitle("Recently Played", "See All", onSeeAll) }
            item { Spacer(Modifier.height(10.dp)) }
            itemsIndexed(recent.take(5), key = { _, s -> s.id }) { i, s ->
                RefRow(
                    title = s.title,
                    subtitle = s.artist,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    thumbBorder = false,
                    onClick = { onPlay(recent, i) },
                ) {
                    SongThumb(s, Modifier.size(52.dp), RoundedCornerShape(10.dp))
                }
            }
            item { Spacer(Modifier.height(26.dp)) }
            item { SectionTitle("Everything in TEXWAVE", "Open menu", onOpenMenu) }
            item {
                Text(
                    "Every screen lives here. Tap a tile to open it.",
                    color = Ref.Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                )
            }
            grouped.forEach { (section, list) ->
                item(key = "h_$section") {
                    Text(
                        section, color = Ref.Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp,
                        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 8.dp),
                    )
                }
                val rows = list.chunked(2)
                items(rows.size, key = { "r_${section}_$it" }) { r ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
                    ) {
                        rows[r].forEach { it2 -> FeatureTile(it2, Modifier.weight(1f)) }
                        if (rows[r].size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureTile(item: MoreItem, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .height(64.dp)
            .clip(shape)
            .background(Ref.Card)
            .border(1.dp, Ref.Line, shape)
            .clickable(onClick = item.onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(Ref.Cyan.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(item.icon, null, tint = Ref.Cyan, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            )
            if (item.subtitle.isNotBlank()) {
                Text(
                    item.subtitle, color = Ref.Muted, fontSize = 11.sp, maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                )
            }
        }
    }
}
