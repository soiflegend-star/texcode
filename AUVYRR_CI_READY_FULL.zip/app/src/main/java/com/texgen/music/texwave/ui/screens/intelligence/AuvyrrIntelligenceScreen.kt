package com.texgen.music.texwave.ui.screens.intelligence

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens

/**
 * AUVYRR INTELLIGENCE
 *
 * Not a generic chatbot.
 * Contextual assistant surface that routes into / explains existing AUVYRR capabilities.
 * Prefer offline / on-device paths when available.
 */
@Composable
fun AuvyrrIntelligenceScreen(
    onSuggestAction: (IntelligenceAction) -> Unit = {},
    onBack: () -> Unit = {},
) {
    var input by remember { mutableStateOf("") }
    val suggestions = remember {
        listOf(
            IntelligenceAction("Explain this planet", "Cosmic Explorer", Icons.Rounded.Public, IntelligenceRoute.CosmicExplain),
            IntelligenceAction("Help with Music Editor", "Creator", Icons.Rounded.MusicNote, IntelligenceRoute.MusicEditorHelp),
            IntelligenceAction("Generate Veltrix flow idea", "Automate", Icons.Rounded.AutoAwesome, IntelligenceRoute.VeltrixAssist),
            IntelligenceAction("What can my device do?", "Device Hub", Icons.Rounded.Headphones, IntelligenceRoute.DeviceCapabilities),
            IntelligenceAction("Security overview", "Protect", Icons.Rounded.Shield, IntelligenceRoute.SecuritySummary),
            IntelligenceAction("Find my last project", "Vault", Icons.Rounded.Folder, IntelligenceRoute.VaultSearch),
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(TexTokens.Bg)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = TexTokens.space20, vertical = TexTokens.space16),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(TexTokens.Elevated.copy(alpha = 0.85f))
            ) {
                Icon(Icons.Rounded.ArrowBack, null, tint = TexTokens.TextPrimary, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "INTELLIGENCE",
                    color = TexTokens.Success,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
                Text(
                    "AUVYRR assistant",
                    color = TexTokens.TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Context banner
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = TexTokens.space20)
                .clip(RoundedCornerShape(12.dp))
                .background(TexTokens.Success.copy(0.08f))
                .border(1.dp, TexTokens.Success.copy(0.25f), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text(
                "This layer assists with AUVYRR systems — search, explain cosmic objects, help edit, organize, and surface device/security context. It is not a general-purpose open chatbot.",
                color = TexTokens.TextPrimary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            placeholder = { Text("Ask about AUVYRR features…", color = TexTokens.TextSecondary) },
            trailingIcon = {
                IconButton(onClick = {
                    // Host can intercept and route; here we keep UI only
                }) {
                    Icon(Icons.Rounded.Send, null, tint = TexTokens.Success)
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = TexTokens.Success,
                unfocusedBorderColor = TexTokens.Outline,
                focusedContainerColor = TexTokens.Surface,
                unfocusedContainerColor = TexTokens.Surface,
                cursorColor = TexTokens.Success,
                focusedTextColor = TexTokens.TextPrimary,
                unfocusedTextColor = TexTokens.TextPrimary
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = TexTokens.space20)
        )

        Spacer(Modifier.height(16.dp))

        LazyColumn(
            contentPadding = PaddingValues(start = TexTokens.space20, top = 0.dp, end = TexTokens.space20, bottom = 100.dp
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    "SUGGESTED",
                    color = TexTokens.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp
                )
            }

            items(suggestions) { action ->
                SuggestionRow(action) { onSuggestAction(action) }
            }

            item {
                Text(
                    "When offline, Intelligence falls back to local explanations and navigation only. Online enrichment is used only where the existing project already supports it.",
                    color = TexTokens.TextSecondary.copy(0.7f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 16.dp, bottom = 24.dp)
                )
            }
        }
    }
}

enum class IntelligenceRoute {
    CosmicExplain, MusicEditorHelp, VeltrixAssist,
    DeviceCapabilities, SecuritySummary, VaultSearch
}

data class IntelligenceAction(
    val title: String,
    val domain: String,
    val icon: ImageVector,
    val route: IntelligenceRoute
)

@Composable
private fun SuggestionRow(
    action: IntelligenceAction,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TexTokens.Surface)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(TexTokens.Success.copy(0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(action.icon, null, tint = TexTokens.Success, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(action.title, color = TexTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(action.domain, color = TexTokens.TextSecondary, fontSize = 12.sp)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = TexTokens.TextSecondary, modifier = Modifier.size(18.dp))
    }
}
