package com.texgen.music.texwave.ui.screens.nexus

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens
import kotlinx.coroutines.delay

/**
 * AUVYRR NEXUS — Universal Command Center (premium final polish)
 *
 * Surfaces the entire ecosystem in one coherent, cinematic overview.
 * Routes into existing systems — does not duplicate them.
 */
@Composable
fun AuvyrrNexusScreen(
    nowPlayingTitle: String? = null,
    nowPlayingArtist: String? = null,
    isPlaying: Boolean = false,
    recentProjectCount: Int = 0,
    achievementCount: Int = 0,
    deviceConnected: Boolean = false,
    deviceName: String? = null,
    securityScore: Int = 82,
    onNavigate: (NexusDestination) -> Unit = {},
    onBack: () -> Unit = {},
) {
    val headerAlpha = remember { Animatable(0f) }
    val contentAlpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        headerAlpha.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
        contentAlpha.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(TexTokens.Bg)
    ) {
        // Layered ambient (cinematic, not neon)
        Box(
            Modifier
                .fillMaxWidth()
                .height(340.dp)
                .background(
                    Brush.verticalGradient(
                        0f to TexTokens.Cyan.copy(alpha = 0.07f),
                        0.45f to TexTokens.Violet.copy(alpha = 0.04f),
                        1f to Color.Transparent
                    )
                )
        )
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .offset(x = 40.dp, y = (-20).dp)
                .size(180.dp)
                .background(
                    Brush.radialGradient(
                        listOf(TexTokens.Violet.copy(0.08f), Color.Transparent)
                    )
                )
        )

        Column(Modifier.fillMaxSize()) {
            // ── Header ──────────────────────────────────────────────────
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
                    .alpha(headerAlpha.value),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(TexTokens.Elevated.copy(alpha = 0.8f))
                ) {
                    Icon(Icons.Rounded.ArrowBack, "Back", tint = TexTokens.TextPrimary, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "NEXUS",
                        color = TexTokens.Cyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.4.sp
                    )
                    Text(
                        "Command Center",
                        color = TexTokens.TextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = (-0.3).sp
                    )
                }
                // Live status cluster
                Row(
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(TexTokens.Elevated.copy(0.9f))
                        .border(1.dp, TexTokens.OutlineStrong, RoundedCornerShape(999.dp))
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    PremiumDot(if (isPlaying) TexTokens.Success else TexTokens.TextSecondary.copy(0.45f), pulse = isPlaying)
                    PremiumDot(if (deviceConnected) TexTokens.Cyan else TexTokens.TextSecondary.copy(0.45f))
                    PremiumDot(
                        when {
                            securityScore >= 80 -> TexTokens.Success
                            securityScore >= 50 -> Color(0xFFFFB020)
                            else -> TexTokens.Danger
                        }
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(start = 20.dp, top = 0.dp, end = 20.dp, bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.alpha(contentAlpha.value)
            ) {
                // Now Playing — hero card
                item {
                    PremiumNowPlayingCard(
                        title = nowPlayingTitle ?: "Nothing playing",
                        artist = nowPlayingArtist ?: "Open library to start",
                        isPlaying = isPlaying,
                        onClick = { onNavigate(NexusDestination.NowPlaying) }
                    )
                }

                // Quick actions
                item {
                    SectionLabel("QUICK ACTIONS")
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        itemsIndexed(quickActions) { index, action ->
                            var visible by remember { mutableStateOf(false) }
                            LaunchedEffect(Unit) {
                                delay(40L * index)
                                visible = true
                            }
                            AnimatedVisibility(
                                visible = visible,
                                enter = fadeIn(tween(280)) + slideInVertically(
                                    tween(280),
                                    initialOffsetY = { it / 5 }
                                )
                            ) {
                                PremiumQuickChip(
                                    icon = action.icon,
                                    label = action.label,
                                    accent = action.accent,
                                    onClick = { onNavigate(action.dest) }
                                )
                            }
                        }
                    }
                }

                // Ecosystem pillars
                item {
                    SectionLabel("ECOSYSTEM")
                    Spacer(Modifier.height(6.dp))
                }

                itemsIndexed(pillars.chunked(2)) { rowIndex, row ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        row.forEachIndexed { col, pillar ->
                            var visible by remember { mutableStateOf(false) }
                            LaunchedEffect(Unit) {
                                delay(50L * (rowIndex * 2 + col))
                                visible = true
                            }
                            AnimatedVisibility(
                                visible = visible,
                                enter = fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 6 },
                                modifier = Modifier.weight(1f)
                            ) {
                                PremiumPillarCard(
                                    pillar = pillar,
                                    onClick = { onNavigate(pillar.dest) }
                                )
                            }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }

                // System status
                item {
                    SectionLabel("SYSTEM STATUS")
                    Spacer(Modifier.height(6.dp))
                    PremiumSystemStatusCard(
                        deviceConnected = deviceConnected,
                        deviceName = deviceName,
                        securityScore = securityScore,
                        recentProjects = recentProjectCount,
                        achievements = achievementCount,
                        onDevice = { onNavigate(NexusDestination.DeviceHub) },
                        onSecurity = { onNavigate(NexusDestination.Security) },
                        onVault = { onNavigate(NexusDestination.Vault) },
                        onAchievements = { onNavigate(NexusDestination.Achievements) }
                    )
                }

                // Recent
                item {
                    SectionLabel("RECENT")
                    Spacer(Modifier.height(6.dp))
                    PremiumRecentStrip(
                        items = listOf(
                            RecentItem("Cosmic Explorer", "Solar System · last viewed", Icons.Rounded.Public, NexusDestination.Cosmic),
                            RecentItem("Music Editor", "Project draft", Icons.Rounded.MusicNote, NexusDestination.CreatorStudio),
                            RecentItem("Veltrix", "Automation flow", Icons.Rounded.AutoAwesome, NexusDestination.Veltrix),
                        ),
                        onClick = onNavigate
                    )
                }

                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }
}

// ─── Models ────────────────────────────────────────────────────────────────

enum class NexusDestination {
    NowPlaying, Library, Cosmic, CreatorStudio, Intelligence,
    Veltrix, Security, DeviceHub, Vault, Lab, Arena, Social,
    Achievements, Alarms, Settings, Home
}

private data class QuickAction(val icon: ImageVector, val label: String, val accent: Color, val dest: NexusDestination)
private data class Pillar(val title: String, val subtitle: String, val icon: ImageVector, val accent: Color, val dest: NexusDestination)
private data class RecentItem(val title: String, val subtitle: String, val icon: ImageVector, val dest: NexusDestination)

private val quickActions = listOf(
    QuickAction(Icons.Rounded.PlayArrow, "Player", TexTokens.Cyan, NexusDestination.NowPlaying),
    QuickAction(Icons.Rounded.LibraryMusic, "Library", TexTokens.Violet, NexusDestination.Library),
    QuickAction(Icons.Rounded.Public, "Cosmic", Color(0xFF6B8AFF), NexusDestination.Cosmic),
    QuickAction(Icons.Rounded.Edit, "Create", TexTokens.Magenta, NexusDestination.CreatorStudio),
    QuickAction(Icons.Rounded.Psychology, "AI", TexTokens.Success, NexusDestination.Intelligence),
    QuickAction(Icons.Rounded.SportsEsports, "Arena", Color(0xFFFF8A5C), NexusDestination.Arena),
)

private val pillars = listOf(
    Pillar("Explore", "Universe · Stars · Planets", Icons.Rounded.Public, Color(0xFF6B8AFF), NexusDestination.Cosmic),
    Pillar("Create", "Music · Media · Projects", Icons.Rounded.Brush, TexTokens.Magenta, NexusDestination.CreatorStudio),
    Pillar("Intelligence", "Assistant over AUVYRR", Icons.Rounded.Psychology, TexTokens.Success, NexusDestination.Intelligence),
    Pillar("Automate", "Veltrix workflows", Icons.Rounded.AutoAwesome, TexTokens.Violet, NexusDestination.Veltrix),
    Pillar("Protect", "Security · Privacy", Icons.Rounded.Shield, TexTokens.Cyan, NexusDestination.Security),
    Pillar("Experiment", "Lab · Protocol", Icons.Rounded.Science, Color(0xFFFFB020), NexusDestination.Lab),
    Pillar("Play", "Arena · Challenges", Icons.Rounded.SportsEsports, Color(0xFFFF8A5C), NexusDestination.Arena),
    Pillar("Connect", "Social · Chat", Icons.Rounded.Forum, Color(0xFF3DFFB0), NexusDestination.Social),
)

// ─── Premium UI pieces ─────────────────────────────────────────────────────

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        color = TexTokens.TextSecondary.copy(alpha = 0.85f),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.4.sp,
        modifier = Modifier.padding(top = 10.dp)
    )
}

@Composable
private fun PremiumDot(color: Color, pulse: Boolean = false) {
    val scale by animateFloatAsState(
        targetValue = if (pulse) 1.15f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessLow, dampingRatio = 0.55f),
        label = "dot"
    )
    Box(
        Modifier
            .size(7.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(color)
    )
}

@Composable
private fun PremiumNowPlayingCard(
    title: String,
    artist: String,
    isPlaying: Boolean,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.98f else if (isPlaying) 1.01f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "np"
    )

    Row(
        Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        TexTokens.Elevated,
                        Color(0xFF0C1220)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(
                        TexTokens.Cyan.copy(0.35f),
                        TexTokens.Violet.copy(0.2f),
                        TexTokens.Outline
                    )
                ),
                RoundedCornerShape(20.dp)
            )
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        listOf(TexTokens.Cyan.copy(0.28f), TexTokens.Violet.copy(0.22f))
                    )
                )
                .border(1.dp, TexTokens.Cyan.copy(0.25f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (isPlaying) Icons.Rounded.GraphicEq else Icons.Rounded.MusicNote,
                null,
                tint = TexTokens.Cyan,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = TexTokens.TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                letterSpacing = (-0.2).sp
            )
            Spacer(Modifier.height(2.dp))
            Text(
                artist,
                color = TexTokens.TextSecondary,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Box(
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(TexTokens.Cyan.copy(0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.ChevronRight, null, tint = TexTokens.Cyan, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun PremiumQuickChip(
    icon: ImageVector,
    label: String,
    accent: Color,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "qc")

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .scale(scale)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 2.dp, vertical = 2.dp)
    ) {
        Box(
            Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(accent.copy(alpha = 0.11f))
                .border(1.dp, accent.copy(alpha = 0.28f), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = accent, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = TexTokens.TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun PremiumPillarCard(
    pillar: Pillar,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "pc")

    Column(
        Modifier
            .scale(scale)
            .clip(RoundedCornerShape(18.dp))
            .background(TexTokens.Surface)
            .border(1.dp, TexTokens.Outline, RoundedCornerShape(18.dp))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(14.dp)
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(pillar.accent.copy(0.14f))
                .border(1.dp, pillar.accent.copy(0.22f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(pillar.icon, null, tint = pillar.accent, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(
            pillar.title,
            color = TexTokens.TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = (-0.2).sp
        )
        Spacer(Modifier.height(3.dp))
        Text(
            pillar.subtitle,
            color = TexTokens.TextSecondary,
            fontSize = 11.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 14.sp
        )
    }
}

@Composable
private fun PremiumSystemStatusCard(
    deviceConnected: Boolean,
    deviceName: String?,
    securityScore: Int,
    recentProjects: Int,
    achievements: Int,
    onDevice: () -> Unit,
    onSecurity: () -> Unit,
    onVault: () -> Unit,
    onAchievements: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(TexTokens.Surface)
            .border(1.dp, TexTokens.Outline, RoundedCornerShape(18.dp))
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        StatusRow(
            Icons.Rounded.Headphones,
            "Device",
            if (deviceConnected) (deviceName ?: "Connected") else "No device",
            if (deviceConnected) TexTokens.Cyan else TexTokens.TextSecondary,
            onDevice
        )
        StatusRow(
            Icons.Rounded.Shield,
            "Security",
            "$securityScore / 100",
            when {
                securityScore >= 80 -> TexTokens.Success
                securityScore >= 50 -> Color(0xFFFFB020)
                else -> TexTokens.Danger
            },
            onSecurity
        )
        StatusRow(
            Icons.Rounded.Folder,
            "Vault",
            if (recentProjects > 0) "$recentProjects projects" else "Ready",
            TexTokens.Violet,
            onVault
        )
        StatusRow(
            Icons.Rounded.EmojiEvents,
            "Achievements",
            if (achievements > 0) "$achievements unlocked" else "—",
            Color(0xFFFFB020),
            onAchievements
        )
    }
}

@Composable
private fun StatusRow(
    icon: ImageVector,
    label: String,
    value: String,
    accent: Color,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val bg by animateFloatAsState(if (pressed) 0.08f else 0f, label = "sr")

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TexTokens.TextPrimary.copy(alpha = bg))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, color = TexTokens.TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = TexTokens.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(6.dp))
        Icon(Icons.Rounded.ChevronRight, null, tint = TexTokens.TextSecondary.copy(0.6f), modifier = Modifier.size(16.dp))
    }
}

@Composable
private fun PremiumRecentStrip(
    items: List<RecentItem>,
    onClick: (NexusDestination) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            val interaction = remember { MutableInteractionSource() }
            val pressed by interaction.collectIsPressedAsState()
            val scale by animateFloatAsState(if (pressed) 0.98f else 1f, label = "rs")

            Row(
                Modifier
                    .fillMaxWidth()
                    .scale(scale)
                    .clip(RoundedCornerShape(14.dp))
                    .background(TexTokens.Surface)
                    .border(1.dp, TexTokens.Outline, RoundedCornerShape(14.dp))
                    .clickable(interactionSource = interaction, indication = null) { onClick(item.dest) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TexTokens.Elevated)
                        .border(1.dp, TexTokens.Outline, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(item.icon, null, tint = TexTokens.Cyan, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, color = TexTokens.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text(item.subtitle, color = TexTokens.TextSecondary, fontSize = 12.sp)
                }
                Icon(Icons.Rounded.ChevronRight, null, tint = TexTokens.TextSecondary.copy(0.55f), modifier = Modifier.size(18.dp))
            }
        }
    }
}
