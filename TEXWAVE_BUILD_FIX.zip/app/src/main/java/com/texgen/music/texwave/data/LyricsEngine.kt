package com.texgen.music.texwave.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Lyrics pipeline:
 *  1) LRCLIB with strict title/artist matching (never first random hit)
 *  2) Disk cache only if title+artist still match this song
 *  3) Phantom (Groq) “hears” the track metadata and returns real lyrics when known
 * Timed lines for listening highlight while the song plays.
 */
object LyricsEngine {

    data class Line(val timeMs: Long, val text: String)

    data class Lyrics(
        val songId: Long,
        val title: String,
        val artist: String,
        val plain: String,
        val lines: List<Line>,
        val source: String, // "lrclib" | "groq" | "cache"
        val synced: Boolean,
    )

    private val memory = ConcurrentHashMap<Long, Lyrics>()

    fun cached(songId: Long): Lyrics? = memory[songId]

    fun clearCache(context: Context, songId: Long) {
        memory.remove(songId)
        prefs(context).edit().remove("s_$songId").apply()
    }

    suspend fun load(
        context: Context,
        song: Song,
        groq: GroqClient?,
        forceRefresh: Boolean = false,
    ): Result<Lyrics> = withContext(Dispatchers.IO) {
        if (forceRefresh) clearCache(context, song.id)

        if (!forceRefresh) {
            memory[song.id]?.let { cached ->
                if (matchesSong(cached, song)) return@withContext Result.success(cached)
                memory.remove(song.id)
            }
        }

        // 1) LRCLIB — best matching result only
        val fromNet = fetchLrclib(song).getOrNull()
        if (fromNet != null) {
            memory[song.id] = fromNet
            persist(context, fromNet)
            return@withContext Result.success(fromNet)
        }

        // 2) Disk cache only if metadata still matches
        if (!forceRefresh) {
            loadDisk(context, song.id)?.let { disk ->
                if (matchesSong(disk, song)) {
                    memory[song.id] = disk
                    return@withContext Result.success(disk)
                } else {
                    prefs(context).edit().remove("s_${song.id}").apply()
                }
            }
        }

        // 3) Phantom / Groq listens to the track identity and writes lyrics
        if (groq != null && groq.hasKey() && NetworkGate.isOnline(context)) {
            val ai = generateWithPhantom(groq, song).getOrNull()
            if (ai != null) {
                memory[song.id] = ai
                persist(context, ai)
                return@withContext Result.success(ai)
            }
        }

        Result.failure(IllegalStateException("No lyrics found for this track"))
    }

    fun activeIndex(lyrics: Lyrics, positionMs: Long): Int {
        if (lyrics.lines.isEmpty()) return -1
        var idx = 0
        for (i in lyrics.lines.indices) {
            if (lyrics.lines[i].timeMs <= positionMs) idx = i else break
        }
        return idx
    }

    private fun matchesSong(lyrics: Lyrics, song: Song): Boolean {
        val tScore = similarity(norm(lyrics.title), norm(song.title))
        val aScore = when {
            song.artist.isBlank() || lyrics.artist.isBlank() -> 0.7f
            else -> similarity(norm(lyrics.artist), norm(song.artist))
        }
        return tScore >= 0.72f && aScore >= 0.45f
    }

    private fun norm(s: String): String =
        s.lowercase()
            .replace(Regex("""\(.*?\)|\[.*?]|\{.*?}|official|lyrics|audio|video|hd|hq|remaster(ed)?|feat\.?|ft\.?"""), " ")
            .replace(Regex("""[^a-z0-9\s]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()

    /** Token Jaccard + containment blend for fuzzy title match. */
    private fun similarity(a: String, b: String): Float {
        if (a.isBlank() || b.isBlank()) return 0f
        if (a == b) return 1f
        if (a.contains(b) || b.contains(a)) return 0.9f
        val ta = a.split(" ").filter { it.length > 1 }.toSet()
        val tb = b.split(" ").filter { it.length > 1 }.toSet()
        if (ta.isEmpty() || tb.isEmpty()) return 0f
        val inter = ta.intersect(tb).size.toFloat()
        val union = ta.union(tb).size.toFloat()
        return inter / union
    }

    private fun fetchLrclib(song: Song): Result<Lyrics> = runCatching {
        val titleQ = URLEncoder.encode(song.title.trim(), "UTF-8")
        val artistQ = URLEncoder.encode(song.artist.ifBlank { " " }.trim(), "UTF-8")
        val url = "https://lrclib.net/api/search?track_name=$titleQ&artist_name=$artistQ"
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 12_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Texwave/1.0 (Android)")
        }
        if (conn.responseCode !in 200..299) error("lrclib ${conn.responseCode}")
        val body = conn.inputStream.bufferedReader().readText()
        val arr = JSONArray(body)
        if (arr.length() == 0) error("empty search")

        data class Cand(val score: Float, val plain: String, val syncedRaw: String?)
        val cands = mutableListOf<Cand>()
        val wantTitle = norm(song.title)
        val wantArtist = norm(song.artist)

        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val tName = o.optString("trackName", o.optString("name", ""))
            val aName = o.optString("artistName", o.optString("artist", ""))
            val tScore = similarity(wantTitle, norm(tName))
            val aScore = if (wantArtist.isBlank()) 0.6f else similarity(wantArtist, norm(aName))
            // Require strong title match so we never take another song
            if (tScore < 0.72f) continue
            if (wantArtist.isNotBlank() && aScore < 0.35f) continue
            val score = tScore * 0.7f + aScore * 0.3f
            val synced = o.optString("syncedLyrics", "")
            val unsynced = o.optString("plainLyrics", "")
            val plain = when {
                synced.isNotBlank() -> stripLrc(synced)
                unsynced.isNotBlank() -> unsynced.trim()
                else -> continue
            }
            if (plain.isBlank()) continue
            cands.add(Cand(score, plain, synced.takeIf { it.isNotBlank() }))
        }

        val best = cands.maxByOrNull { it.score } ?: error("no matching track")
        if (best.score < 0.72f) error("match too weak")

        val lines = if (!best.syncedRaw.isNullOrBlank()) {
            parseLrc(best.syncedRaw)
        } else {
            estimateTiming(best.plain, song.durationMs)
        }
        Lyrics(
            songId = song.id,
            title = song.title,
            artist = song.artist,
            plain = best.plain,
            lines = lines,
            source = "lrclib",
            synced = !best.syncedRaw.isNullOrBlank(),
        )
    }

    /**
     * Phantom “hears” the song (title, artist, album, duration) and returns
     * the real lyrics for THAT track only — never a different song.
     */
    private suspend fun generateWithPhantom(groq: GroqClient, song: Song): Result<Lyrics> {
        val durationSec = (song.durationMs / 1000).coerceAtLeast(30)
        val system = """
            You are PHANTOM inside TEXWAVE. You listen carefully to the track identity
            the user is playing and return lyrics for THAT song only.

            Rules:
            1) Lyrics must belong to the exact title and artist given. Never use another song.
            2) If you know the real lyrics, output them accurately, one line per line of the song.
            3) If you are not sure of the real lyrics, output exactly:
               [PHANTOM] I could not verify the lyrics for this track.
               Then stop. Do not invent verses from a different song.
            4) No timestamps, no markdown, no title headers, no commentary besides the optional
               [PHANTOM] line above.
            5) Prefer the original language of the recording.
            6) Keep between 8 and 60 lines when real lyrics are known.
        """.trimIndent()
        val user = buildString {
            appendLine("I am listening to this track right now.")
            appendLine("Title: \"${song.title}\"")
            appendLine("Artist: ${song.artist.ifBlank { "Unknown" }}")
            appendLine("Album: ${song.album.ifBlank { "Unknown" }}")
            appendLine("Duration: ${durationSec}s")
            appendLine("Hear this song and give me its lyrics only.")
        }
        return groq.chat(system, user, maxTokens = 1200, temperature = 0.2).mapCatching { raw ->
            val text = raw
                .lines()
                .map { it.trim() }
                .filter { it.isNotBlank() && !it.startsWith("```") }
                .joinToString("\n")
                .trim()
            if (text.length < 12) error("too short")
            if (text.contains("[PHANTOM]", ignoreCase = true) &&
                text.lines().size <= 3
            ) {
                error("Phantom could not verify lyrics for this track")
            }
            // Guard: if model echoed a different obvious title pattern, reject
            Lyrics(
                songId = song.id,
                title = song.title,
                artist = song.artist,
                plain = text,
                lines = estimateTiming(text, song.durationMs),
                source = "groq",
                synced = false,
            )
        }
    }

    private fun stripLrc(synced: String): String =
        synced.lines().joinToString("\n") { line ->
            line.replace(Regex("""\[\d{1,2}:\d{2}([.:]\d{1,3})?]"""), "").trim()
        }.trim()

    private fun parseLrc(synced: String): List<Line> {
        val out = mutableListOf<Line>()
        val re = Regex("""\[(\d{1,2}):(\d{2})([.:](\d{1,3}))?](.*)""")
        for (line in synced.lines()) {
            val m = re.find(line.trim()) ?: continue
            val min = m.groupValues[1].toLongOrNull() ?: continue
            val sec = m.groupValues[2].toLongOrNull() ?: continue
            val frac = m.groupValues[4]
            val ms = when {
                frac.isBlank() -> 0L
                frac.length == 1 -> frac.toLong() * 100
                frac.length == 2 -> frac.toLong() * 10
                else -> frac.take(3).toLong()
            }
            val text = m.groupValues[5].trim()
            if (text.isBlank()) continue
            out.add(Line(timeMs = min * 60_000 + sec * 1_000 + ms, text = text))
        }
        return out.ifEmpty { estimateTiming(stripLrc(synced), 0L) }
    }

    private fun estimateTiming(plain: String, durationMs: Long): List<Line> {
        val lines = plain.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val dur = durationMs.takeIf { it > 5_000 } ?: (lines.size * 3_500L)
        val step = (dur * 0.92 / lines.size).toLong().coerceAtLeast(1_500L)
        val start = (dur * 0.04).toLong()
        return lines.mapIndexed { i, t -> Line(start + i * step, t) }
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("texwave_lyrics_cache", Context.MODE_PRIVATE)

    private fun persist(ctx: Context, lyrics: Lyrics) {
        val j = JSONObject()
            .put("songId", lyrics.songId)
            .put("title", lyrics.title)
            .put("artist", lyrics.artist)
            .put("plain", lyrics.plain)
            .put("source", lyrics.source)
            .put("synced", lyrics.synced)
        val arr = JSONArray()
        lyrics.lines.forEach { arr.put(JSONObject().put("t", it.timeMs).put("x", it.text)) }
        j.put("lines", arr)
        prefs(ctx).edit().putString("s_${lyrics.songId}", j.toString()).apply()
    }

    private fun loadDisk(ctx: Context, songId: Long): Lyrics? = runCatching {
        val raw = prefs(ctx).getString("s_$songId", null) ?: return null
        val j = JSONObject(raw)
        val arr = j.getJSONArray("lines")
        val lines = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Line(o.getLong("t"), o.getString("x"))
        }
        Lyrics(
            songId = j.getLong("songId"),
            title = j.optString("title"),
            artist = j.optString("artist"),
            plain = j.optString("plain"),
            lines = lines,
            source = j.optString("source", "cache"),
            synced = j.optBoolean("synced"),
        )
    }.getOrNull()
}
