package com.texgen.music.texwave.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.abs
import kotlin.random.Random

enum class EmotionMode(val id: String, val label: String, val emoji: String, val hint: String) {
    RAINY_NIGHT("rainy", "Rainy Night", "🌧️", "Atmospheric · mellow"),
    UNSTOPPABLE("unstoppable", "Unstoppable", "⚡", "High energy"),
    LOST_IN_SPACE("space", "Lost in Space", "🌌", "Dreamy · atmospheric"),
    LET_ME_THINK("think", "Let Me Think", "🥀", "Calm · reflective"),
    FINAL_BOSS("boss", "Final Boss", "🔥", "Intense · dramatic"),
    FOCUS("focus", "Deep Focus", "🧠", "Steady · unobtrusive"),
    NIGHT_DRIVE("drive", "Night Drive", "🚗", "Cruise · cinematic"),
}

data class MemoryNote(
    val songId: Long,
    val note: String,
    val createdAt: Long = System.currentTimeMillis(),
)

data class SoundProfile(
    val id: String,
    val name: String,
    val bassBoost: Int = 0,
    val treble: Int = 0,
    val virtualizer: Int = 0,
    val speed: Float = 1f,
)

enum class AlchemistPreset(val id: String, val label: String, val emoji: String) {
    SPATIAL("spatial", "Spatial atmosphere", "🌌"),
    WARM("warm", "Warm & soft", "🌙"),
    CINEMATIC("cinematic", "Cinematic ambience", "🎬"),
    BASS("bass", "Bass-focused", "🔊"),
    WIDE("wide", "Wider stereo", "🎧"),
    NEUTRAL("neutral", "Original", "⚪"),
}

enum class FocusGoal(val id: String, val label: String) {
    READING("reading", "Reading"),
    STUDYING("studying", "Studying"),
    CODING("coding", "Coding"),
    RELAXING("relaxing", "Relaxing"),
    CREATIVE("creative", "Creative work"),
}

enum class DayPart { MORNING, AFTERNOON, EVENING, LATE_NIGHT }

/**
 * PHANTOM — fully offline-capable. Learns the user (likes, plays, skips,
 * memories, emotion feedback) and the environment (time of day). Always
 * optimizes for a happier listen. Internet + Groq only boost quality.
 */
class PhantomEngine(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("texwave_phantom", Context.MODE_PRIVATE)
    val groq = GroqClient(app)

    fun isOnline(): Boolean = NetworkGate.isOnline(app)
    fun hasGroqKey(): Boolean = groq.hasKey()
    fun isPhantomReady(): Boolean = true
    fun isUniverseAvailable(): Boolean = true

    fun dayPart(): DayPart {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) {
            in 5..11 -> DayPart.MORNING
            in 12..16 -> DayPart.AFTERNOON
            in 17..21 -> DayPart.EVENING
            else -> DayPart.LATE_NIGHT
        }
    }

    fun recordSkip(songId: Long) {
        val map = loadCounts(KEY_SKIPS)
        map[songId] = (map[songId] ?: 0) + 1
        saveCounts(KEY_SKIPS, map)
    }

    fun recordEnjoy(songId: Long) {
        val map = loadCounts(KEY_ENJOY)
        map[songId] = (map[songId] ?: 0) + 1
        saveCounts(KEY_ENJOY, map)
    }

    fun skipCount(songId: Long): Int = loadCounts(KEY_SKIPS)[songId] ?: 0
    fun enjoyCount(songId: Long): Int = loadCounts(KEY_ENJOY)[songId] ?: 0

    private fun loadCounts(key: String): MutableMap<Long, Int> {
        val raw = prefs.getString(key, null) ?: return mutableMapOf()
        return try {
            val o = JSONObject(raw)
            o.keys().asSequence().mapNotNull { k ->
                k.toLongOrNull()?.let { it to o.getInt(k) }
            }.toMap().toMutableMap()
        } catch (_: Exception) {
            mutableMapOf()
        }
    }

    private fun saveCounts(key: String, map: Map<Long, Int>) {
        val o = JSONObject()
        map.entries.sortedByDescending { it.value }.take(400).forEach { (k, v) ->
            o.put(k.toString(), v)
        }
        prefs.edit().putString(key, o.toString()).apply()
    }

    fun happinessScore(
        s: Song,
        liked: Set<Long>,
        playCounts: Map<Long, Int>,
        mode: EmotionMode? = null,
    ): Double {
        var score = 0.0
        if (s.id in liked) score += 4.0
        score += enjoyCount(s.id) * 1.2
        score -= skipCount(s.id) * 2.5
        val plays = playCounts[s.id] ?: 0
        score += when {
            plays == 0 -> 0.3
            plays in 1..8 -> 1.5 + plays * 0.15
            plays in 9..25 -> 1.0
            else -> 0.2
        }
        if (mode != null) score += heuristic(mode, s) * 1.4
        score += timeOfDayBoost(s)
        if (memoryFor(s.id) != null) score += 2.0
        if (s.artist == "Unknown artist" && plays == 0 && s.id !in liked) score -= 0.15
        return score
    }

    private fun timeOfDayBoost(s: Song): Double {
        val t = (s.title + " " + s.artist).lowercase()
        return when (dayPart()) {
            DayPart.MORNING -> when {
                listOf("soft", "calm", "lofi", "morning", "chill", "acoustic").any { it in t } -> 1.2
                listOf("dark", "night", "rage", "hard", "metal").any { it in t } -> -0.4
                else -> 0.1
            }
            DayPart.AFTERNOON -> when {
                listOf("energy", "up", "happy", "fun", "drive").any { it in t } -> 0.8
                else -> 0.15
            }
            DayPart.EVENING -> when {
                listOf("night", "drive", "city", "synth", "chill", "slow").any { it in t } -> 1.0
                else -> 0.2
            }
            DayPart.LATE_NIGHT -> when {
                listOf("slow", "reverb", "ambient", "night", "soft", "dream", "lofi", "sad").any { it in t } -> 1.4
                listOf("hype", "party", "loud").any { it in t } -> -0.5
                else -> 0.1
            }
        }
    }

    fun suggestedEmotion(): EmotionMode = when (dayPart()) {
        DayPart.MORNING -> EmotionMode.FOCUS
        DayPart.AFTERNOON -> EmotionMode.UNSTOPPABLE
        DayPart.EVENING -> EmotionMode.NIGHT_DRIVE
        DayPart.LATE_NIGHT -> EmotionMode.RAINY_NIGHT
    }

    fun loadEmotionLikes(): Map<String, Set<Long>> {
        val raw = prefs.getString(KEY_EMOTION, null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            o.keys().asSequence().associateWith { k ->
                val arr = o.getJSONArray(k)
                (0 until arr.length()).map { arr.getLong(it) }.toSet()
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun saveEmotionLike(modeId: String, songId: Long) {
        val map = loadEmotionLikes().toMutableMap()
        map[modeId] = (map[modeId] ?: emptySet()) + songId
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, JSONArray(v.toList())) }
        prefs.edit().putString(KEY_EMOTION, o.toString()).apply()
    }

    /** Songs the user has explicitly added to a mood session. */
    fun emotionAssignedSongs(mode: EmotionMode, allSongs: List<Song>): List<Song> {
        val ids = loadEmotionLikes()[mode.id] ?: return emptyList()
        val byId = allSongs.associateBy { it.id }
        return ids.mapNotNull { byId[it] }
    }

    fun emotionMixLocal(
        mode: EmotionMode,
        songs: List<Song>,
        liked: Set<Long>,
        playCounts: Map<Long, Int> = emptyMap(),
        limit: Int = 25,
    ): List<Song> {
        if (songs.isEmpty()) return emptyList()
        val feedback = loadEmotionLikes()[mode.id] ?: emptySet()
        return songs
            .map { s ->
                var score = happinessScore(s, liked, playCounts, mode)
                if (s.id in feedback) score += 5.0
                s to score
            }
            .sortedByDescending { it.second }
            .map { it.first }
            .distinctBy { it.id }
            .take(limit)
    }

    suspend fun emotionMixBest(
        mode: EmotionMode,
        songs: List<Song>,
        liked: Set<Long>,
        playCounts: Map<Long, Int> = emptyMap(),
        limit: Int = 25,
    ): List<Song> {
        if (songs.isEmpty()) return emptyList()
        if (isOnline() && groq.hasKey()) {
            val pool = emotionMixLocal(mode, songs, liked, playCounts, 50)
            val ranked = groq.emotionRank(mode.label + " — " + mode.hint, pool, limit)
            ranked.getOrNull()?.let { ids ->
                val byId = songs.associateBy { it.id }
                val ordered = ids.mapNotNull { byId[it] }
                if (ordered.isNotEmpty()) return ordered
            }
        }
        return emotionMixLocal(mode, songs, liked, playCounts, limit)
    }

    private fun heuristic(mode: EmotionMode, s: Song): Double {
        val t = (s.title + " " + s.artist + " " + s.album).lowercase()
        val dur = s.durationMs / 1000.0
        return when (mode) {
            EmotionMode.RAINY_NIGHT -> kw(t, "slow", "rain", "night", "soft", "lofi", "ambient", "chill", "sad", "reverb") + durBoost(dur, 150.0, 360.0)
            EmotionMode.UNSTOPPABLE -> kw(t, "energy", "power", "fast", "pump", "bass", "hype", "fire", "boss") + durBoost(dur, 120.0, 240.0)
            EmotionMode.LOST_IN_SPACE -> kw(t, "space", "dream", "atmos", "echo", "void", "star", "cosmos", "ambient") + if (dur > 200) 0.5 else 0.0
            EmotionMode.LET_ME_THINK -> kw(t, "think", "calm", "soft", "piano", "slow", "quiet", "reflect") + durBoost(dur, 180.0, 400.0)
            EmotionMode.FINAL_BOSS -> kw(t, "epic", "intense", "dark", "battle", "metal", "hard", "rage", "super") + durBoost(dur, 90.0, 300.0)
            EmotionMode.FOCUS -> kw(t, "focus", "study", "lofi", "instrumental", "calm", "soft") + if (dur > 150) 0.4 else 0.0
            EmotionMode.NIGHT_DRIVE -> kw(t, "drive", "night", "city", "cruise", "synth", "wave", "neon") + durBoost(dur, 180.0, 360.0)
        }
    }

    private fun kw(t: String, vararg words: String) = if (words.any { it in t }) 2.0 else 0.0
    private fun durBoost(dur: Double, a: Double, b: Double) = if (dur in a..b) 0.5 else 0.0

    fun infiniteMixLocal(
        songs: List<Song>,
        liked: Set<Long> = emptySet(),
        playCounts: Map<Long, Int> = emptyMap(),
    ): List<Song> {
        if (songs.size <= 2) return songs
        val ranked = songs
            .map { it to happinessScore(it, liked, playCounts) }
            .sortedByDescending { it.second }
        val core = ranked.take((songs.size * 0.7).toInt().coerceAtLeast(3)).map { it.first }
        fun energy(s: Song): Double {
            val t = s.title.lowercase()
            var e = 0.5
            if (listOf("slow", "soft", "calm", "ambient", "lofi", "rain").any { it in t }) e -= 0.25
            if (listOf("fast", "bass", "power", "fire", "energy", "hard", "super").any { it in t }) e += 0.3
            e += ((s.durationMs / 1000.0) - 180) / 600.0
            if (dayPart() == DayPart.LATE_NIGHT) e *= 0.75
            if (dayPart() == DayPart.MORNING) e *= 0.85
            return e.coerceIn(0.0, 1.0)
        }
        val remaining = core.map { it to energy(it) }.shuffled(Random(System.currentTimeMillis() / 60_000)).toMutableList()
        val result = mutableListOf<Song>()
        var target = when (dayPart()) {
            DayPart.MORNING, DayPart.LATE_NIGHT -> 0.2
            else -> 0.3
        }
        while (remaining.isNotEmpty()) {
            val best = remaining.minByOrNull { abs(it.second - target) } ?: break
            remaining.remove(best)
            result.add(best.first)
            target = (target + 0.11).coerceAtMost(0.88)
            if (result.size > core.size * 0.55) target = (target - 0.07).coerceAtLeast(0.18)
        }
        val knownIds = result.map { it.id }.toSet()
        val discovery = ranked.map { it.first }.filter { it.id !in knownIds }.take(5)
        return result + discovery
    }

    suspend fun infiniteMixBest(
        songs: List<Song>,
        liked: Set<Long> = emptySet(),
        playCounts: Map<Long, Int> = emptyMap(),
    ): List<Song> {
        if (songs.isEmpty()) return emptyList()
        if (isOnline() && groq.hasKey() && songs.size >= 3) {
            val seed = infiniteMixLocal(songs, liked, playCounts).take(40)
            val orderedIds = groq.infiniteMixOrder(seed).getOrNull()
            if (orderedIds != null) {
                val byId = songs.associateBy { it.id }
                val ordered = orderedIds.mapNotNull { byId[it] }
                if (ordered.isNotEmpty()) {
                    val missing = seed.filter { it.id !in orderedIds.toSet() }
                    return ordered + missing
                }
            }
        }
        return infiniteMixLocal(songs, liked, playCounts)
    }

    data class DnaCluster(val label: String, val songs: List<Song>)

    fun musicDnaLocal(songs: List<Song>): List<DnaCluster> {
        if (songs.isEmpty()) return emptyList()
        val slowed = songs.filter { "slow" in it.title.lowercase() || "reverb" in it.title.lowercase() }
        val energetic = songs.filter {
            val t = it.title.lowercase()
            listOf("fast", "bass", "energy", "fire", "super", "hard").any { k -> k in t }
        }
        val loved = songs.filter { enjoyCount(it.id) > 0 }
        return listOfNotNull(
            slowed.takeIf { it.isNotEmpty() }?.let { DnaCluster("Atmospheric / Slowed", it.take(20)) },
            energetic.takeIf { it.isNotEmpty() }?.let { DnaCluster("High energy", it.take(20)) },
            loved.takeIf { it.isNotEmpty() }?.let { DnaCluster("Tracks you stay with", it.take(20)) },
            songs.filter { it.durationMs < 150_000 }.takeIf { it.isNotEmpty() }?.let { DnaCluster("Short form", it.take(15)) },
            songs.filter { it.durationMs >= 300_000 }.takeIf { it.isNotEmpty() }?.let { DnaCluster("Long form", it.take(15)) },
        )
    }

    fun musicDnaOfflineStory(
        songs: List<Song>,
        liked: Set<Long>,
        playCounts: Map<Long, Int>,
    ): String {
        if (songs.isEmpty()) return "Add music to your phone — PHANTOM will learn your taste."
        val top = songs
            .map { it to happinessScore(it, liked, playCounts) }
            .sortedByDescending { it.second }
            .take(5)
            .map { it.first }
        val part = when (dayPart()) {
            DayPart.MORNING -> "mornings"
            DayPart.AFTERNOON -> "afternoons"
            DayPart.EVENING -> "evenings"
            DayPart.LATE_NIGHT -> "late nights"
        }
        val clusters = musicDnaLocal(songs)
        return buildString {
            appendLine("Your Music DNA (on-device)")
            appendLine("· Right now it feels like a $part kind of listen.")
            appendLine("· Library size: ${songs.size} tracks · Liked: ${liked.size}")
            if (top.isNotEmpty()) {
                appendLine("· Tracks PHANTOM thinks you'll enjoy most:")
                top.forEach { appendLine("  — ${it.title}") }
            }
            clusters.forEach {
                appendLine("· ${it.label}: ${it.songs.size} tracks")
            }
            appendLine()
            appendLine("PHANTOM keeps learning from plays, skips, likes, and memories — fully offline.")
        }
    }

    suspend fun musicDnaExplain(
        songs: List<Song>,
        liked: Set<Long> = emptySet(),
        playCounts: Map<Long, Int> = emptyMap(),
    ): String {
        if (isOnline() && groq.hasKey()) {
            groq.musicDnaExplain(songs).getOrNull()?.let { return it }
        }
        return musicDnaOfflineStory(songs, liked, playCounts)
    }

    fun universeNeighbors(seed: Song, library: List<Song>, limit: Int = 16): List<Song> {
        return library.filter { it.id != seed.id }
            .map { s ->
                var sc = 0.0
                if (s.artist == seed.artist) sc += 3
                if (s.albumId == seed.albumId) sc += 2
                if (s.album == seed.album) sc += 1
                val dDiff = abs(s.durationMs - seed.durationMs) / 1000.0
                sc += 1.0 - (dDiff / 300.0).coerceIn(0.0, 1.0)
                sc += enjoyCount(s.id) * 0.4
                sc -= skipCount(s.id) * 0.8
                s to sc
            }
            .sortedByDescending { it.second }
            .map { it.first }
            .take(limit)
    }

    fun universeOfflineStory(seed: Song, neighbors: List<Song>): String {
        if (neighbors.isEmpty()) return "Play more music — your universe grows with every listen."
        val sameArtist = neighbors.count { it.artist == seed.artist }
        return buildString {
            appendLine("Constellation around \"${seed.title}\"")
            appendLine("· ${neighbors.size} nearby stars in your library")
            if (sameArtist > 0) appendLine("· $sameArtist from the same artist")
            appendLine("· Ordered by similarity + what you tend to stay with")
            neighbors.take(6).forEach { appendLine("  ★ ${it.title}") }
        }
    }

    suspend fun universeExplain(seed: Song, neighbors: List<Song>): String {
        if (isOnline() && groq.hasKey()) {
            groq.universeLinks(seed, neighbors).getOrNull()?.let { return it }
        }
        return universeOfflineStory(seed, neighbors)
    }

    fun loadMemories(): List<MemoryNote> {
        val raw = prefs.getString(KEY_MEMORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                MemoryNote(o.getLong("id"), o.getString("note"), o.getLong("at"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveMemory(note: MemoryNote) {
        val list = loadMemories().filter { it.songId != note.songId } + note
        val arr = JSONArray()
        list.takeLast(200).forEach {
            arr.put(JSONObject().put("id", it.songId).put("note", it.note).put("at", it.createdAt))
        }
        prefs.edit().putString(KEY_MEMORY, arr.toString()).apply()
    }

    fun memoryFor(songId: Long): MemoryNote? = loadMemories().find { it.songId == songId }

    fun alchemistToProfile(preset: AlchemistPreset): SoundProfile = when (preset) {
        AlchemistPreset.SPATIAL -> SoundProfile("spatial", "Spatial", virtualizer = 70, treble = 10)
        AlchemistPreset.WARM -> SoundProfile("warm", "Warm", bassBoost = 25, treble = -20)
        AlchemistPreset.CINEMATIC -> SoundProfile("cinematic", "Cinematic", bassBoost = 40, treble = 15, virtualizer = 30)
        AlchemistPreset.BASS -> SoundProfile("bass", "Bass", bassBoost = 80)
        AlchemistPreset.WIDE -> SoundProfile("wide", "Wide", virtualizer = 90, treble = 20)
        AlchemistPreset.NEUTRAL -> SoundProfile("neutral", "Neutral")
    }

    fun suggestedAlchemist(): AlchemistPreset = when (dayPart()) {
        DayPart.LATE_NIGHT -> AlchemistPreset.WARM
        DayPart.EVENING -> AlchemistPreset.CINEMATIC
        DayPart.MORNING -> AlchemistPreset.SPATIAL
        DayPart.AFTERNOON -> AlchemistPreset.WIDE
    }

    fun focusMix(
        goal: FocusGoal,
        stage: Int,
        songs: List<Song>,
        liked: Set<Long>,
        playCounts: Map<Long, Int> = emptyMap(),
    ): List<Song> {
        val mode = when (goal) {
            FocusGoal.READING, FocusGoal.STUDYING, FocusGoal.CODING -> when (stage) {
                0 -> EmotionMode.LET_ME_THINK
                1 -> EmotionMode.FOCUS
                2 -> EmotionMode.RAINY_NIGHT
                else -> EmotionMode.UNSTOPPABLE
            }
            FocusGoal.RELAXING -> EmotionMode.RAINY_NIGHT
            FocusGoal.CREATIVE -> when (stage) {
                0 -> EmotionMode.LOST_IN_SPACE
                1 -> EmotionMode.FOCUS
                else -> EmotionMode.NIGHT_DRIVE
            }
        }
        return emotionMixLocal(mode, songs, liked, playCounts, 20)
    }

    suspend fun soundDetective(song: Song): String {
        if (isOnline() && groq.hasKey()) {
            groq.soundDetective(song).getOrNull()?.let { return it }
        }
        val secs = (song.durationMs / 1000).toInt().coerceAtLeast(1)
        val mid = secs / 2
        val enjoy = enjoyCount(song.id)
        val skips = skipCount(song.id)
        return buildString {
            appendLine("Sound Detective — ${song.title}")
            appendLine("Artist: ${song.artist}")
            appendLine("Duration: ${secs / 60}:${(secs % 60).toString().padStart(2, '0')}")
            appendLine()
            appendLine("Estimated structure (on-device):")
            appendLine("0:00 — Intro")
            if (secs > 60) appendLine("${secs / 6}s — Early development")
            appendLine("${mid / 60}:${(mid % 60).toString().padStart(2, '0')} — Mid / energy window")
            if (secs > 90) appendLine("${(secs * 3 / 4)}s — Late section")
            appendLine("${secs / 60}:${(secs % 60).toString().padStart(2, '0')} — End")
            appendLine()
            when {
                enjoy > skips && enjoy > 0 -> appendLine("You've stayed with this track before — PHANTOM will keep it close.")
                skips > enjoy && skips > 1 -> appendLine("You've skipped this often — PHANTOM will ease it out of mixes.")
                else -> appendLine("Still learning how you feel about this one.")
            }
        }
    }

    fun loadProfiles(): List<SoundProfile> {
        val raw = prefs.getString(KEY_PROFILES, null) ?: return defaultProfiles()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                SoundProfile(
                    o.getString("id"), o.getString("name"),
                    o.optInt("bass", 0), o.optInt("treble", 0),
                    o.optInt("virt", 0), o.optDouble("speed", 1.0).toFloat(),
                )
            }
        } catch (_: Exception) {
            defaultProfiles()
        }
    }

    private fun defaultProfiles() = listOf(
        SoundProfile("neutral", "Neutral"),
        SoundProfile("bass", "Bass boost", bassBoost = 70),
        SoundProfile("night", "Late night", bassBoost = 20, treble = -15),
        SoundProfile("headphones", "Headphones", treble = 20, virtualizer = 40),
        SoundProfile("speaker", "Phone speaker", bassBoost = 40, treble = 10),
    )

    fun loadBookmarks(songId: Long): List<Long> {
        val raw = prefs.getString("$KEY_BM$songId", null) ?: return emptyList()
        return raw.split(',').mapNotNull { it.toLongOrNull() }
    }

    fun addBookmark(songId: Long, positionMs: Long) {
        val next = (loadBookmarks(songId) + positionMs).distinct().sorted()
        prefs.edit().putString("$KEY_BM$songId", next.joinToString(",")).apply()
    }

    private companion object {
        const val KEY_EMOTION = "emotion_likes"
        const val KEY_MEMORY = "memories"
        const val KEY_PROFILES = "sound_profiles"
        const val KEY_BM = "bm_"
        const val KEY_SKIPS = "skip_counts"
        const val KEY_ENJOY = "enjoy_counts"
    }
}
