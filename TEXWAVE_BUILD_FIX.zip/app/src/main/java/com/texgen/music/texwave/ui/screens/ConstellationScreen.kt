package com.texgen.music.texwave.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.ui.components.drawComet
import com.texgen.music.texwave.ui.theme.seedColors
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

private class CStar(
    val song: Song,
    val x: Float,          // world coordinates (0..1000 wide)
    val y: Float,
    val size: Float,       // world radius
    val color: Color,
    val cluster: Int,
    val phase: Float,
)

private class CCluster(val artist: String, val cx: Float, val cy: Float, val members: List<Int>)

private class Comet(val from: Offset, val to: Offset, val born: Float, val dur: Float, val lands: Boolean, val accent: Color)

/**
 * TEXWAVE Constellation — your library as a night sky.
 * Every artist is its own constellation (their songs are the stars, joined by glowing lines).
 * Drag to pan, pinch to zoom, tap a star: a comet streaks in, lands on it and the song plays.
 */
@OptIn(ExperimentalTextApi::class)
@Composable
fun ConstellationScreen(
    songs: List<Song>,
    onPlay: (Song) -> Unit,
    onOpenLibrary: () -> Unit,
    currentSongId: Long? = null,
    isPlaying: Boolean = false,
    onBack: () -> Unit = {},
) {
    val textMeasurer = rememberTextMeasurer()

    // ---------- build the sky ----------
    val sky = remember(songs) {
        val pool = songs.take(160)
        val byArtist = pool.groupBy { it.artist }.entries.sortedByDescending { it.value.size }
        val stars = ArrayList<CStar>()
        val clusters = ArrayList<CCluster>()
        byArtist.forEachIndexed { k, (artist, list) ->
            val ang = k * 2.3999632f
            val rad = 150f * sqrt(k + 0.35f)
            val cx = 500f + rad * cos(ang)
            val cy = 700f + rad * sin(ang) * 1.25f
            val rnd = Random(artist.hashCode())
            val idx = ArrayList<Int>()
            val spread = 42f + 22f * sqrt(list.size.toFloat())
            list.forEachIndexed { j, s ->
                val a2 = j * 2.3999632f + rnd.nextFloat() * 0.8f
                val r2 = if (list.size == 1) 0f else spread * sqrt((j + 0.6f) / list.size) * (0.7f + rnd.nextFloat() * 0.5f)
                val (c1, _) = seedColors(s.album)
                val col = Color(
                    red = 0.55f + 0.45f * c1.red,
                    green = 0.55f + 0.45f * c1.green,
                    blue = 0.65f + 0.35f * c1.blue,
                )
                idx.add(stars.size)
                stars.add(
                    CStar(
                        s, cx + r2 * cos(a2), cy + r2 * sin(a2) * 0.85f,
                        3.2f + min(s.durationMs / 60_000f, 6f) * 0.75f,
                        col, k, rnd.nextFloat() * 6.28f,
                    )
                )
            }
            clusters.add(CCluster(artist, cx, cy, idx))
        }
        stars to clusters
    }
    val stars = sky.first
    val clusters = sky.second

    val bgStars = remember {
        val r = Random(42)
        List(220) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.3f + r.nextFloat() * 0.7f, r.nextFloat() * 6.28f, r.nextFloat()) }
    }

    // ---------- state ----------
    var clock by remember { mutableFloatStateOf(0f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var selected by remember { mutableStateOf<CStar?>(null) }
    var comets by remember { mutableStateOf<List<Comet>>(emptyList()) }
    var bursts by remember { mutableStateOf<List<Triple<Offset, Float, Color>>>(emptyList()) } // world pos, born, color
    var viewW by remember { mutableFloatStateOf(1f) }
    var viewH by remember { mutableFloatStateOf(1f) }
    var nextAmbient by remember { mutableFloatStateOf(1.5f) }

    // world -> screen
    fun baseScale(): Float = viewW / 1000f
    fun toScreen(x: Float, y: Float): Offset =
        Offset(viewW / 2f + (x - 500f) * baseScale() * zoom + pan.x, viewH / 2f + (y - 700f) * baseScale() * zoom + pan.y)

    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            clock += ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
            last = now
            // when a landing comet arrives, spawn the impact burst (world coordinates)
            comets.forEach { c ->
                if (c.lands && clock - c.born >= c.dur && bursts.none { abs(it.second - c.born) < 0.001f }) {
                    val wx = 500f + (c.to.x - viewW / 2f - pan.x) / (baseScale() * zoom)
                    val wy = 700f + (c.to.y - viewH / 2f - pan.y) / (baseScale() * zoom)
                    bursts = bursts + Triple(Offset(wx, wy), c.born, c.accent)
                }
            }
            if (comets.isNotEmpty()) comets = comets.filter { clock - it.born < it.dur + 0.1f }
            if (bursts.isNotEmpty()) bursts = bursts.filter { clock - it.second < 0.9f }
            if (clock > nextAmbient && viewW > 10f) {
                nextAmbient = clock + 3.5f + Random.nextFloat() * 4f
                val y0 = viewH * (0.05f + Random.nextFloat() * 0.45f)
                val from = Offset(viewW * (0.55f + Random.nextFloat() * 0.5f), y0)
                val to = Offset(from.x - viewW * (0.9f + Random.nextFloat() * 0.4f), y0 + viewH * (0.25f + Random.nextFloat() * 0.2f))
                comets = comets + Comet(from, to, clock, 1.1f, false, Color(0xFF7BDCFF))
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF010007), Color(0xFF070319), Color(0xFF0C0522), Color(0xFF010007)))),
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { centroid, panChange, zoomChange, _ ->
                        val nz = (zoom * zoomChange).coerceIn(0.6f, 4.5f)
                        // keep the point under the fingers fixed while zooming
                        val k = nz / zoom
                        val cx = centroid.x - viewW / 2f
                        val cy = centroid.y - viewH / 2f
                        pan = Offset(cx - (cx - pan.x) * k + panChange.x, cy - (cy - pan.y) * k + panChange.y)
                        zoom = nz
                    }
                }
                .pointerInput(stars) {
                    detectTapGestures { off ->
                        var best: CStar? = null
                        var bestD = 40f * density
                        for (st in stars) {
                            val p = toScreen(st.x, st.y)
                            val d = sqrt((p.x - off.x).pow(2) + (p.y - off.y).pow(2))
                            if (d < bestD) { bestD = d; best = st }
                        }
                        best?.let { st ->
                            selected = st
                            val target = toScreen(st.x, st.y)
                            // comet comes in from the top-right, lands on the star
                            val from = Offset(target.x + viewW * 0.75f, target.y - viewH * 0.42f)
                            comets = comets + Comet(from, target, clock, 0.75f, true, st.color)
                            onPlay(st.song)
                        }
                    }
                },
        ) {
            viewW = size.width
            viewH = size.height
            val w = size.width
            val h = size.height
            val d = density

            // nebula clouds (drift very slowly, shift a little with pan for depth)
            fun cloud(col: Color, fx: Float, fy: Float, rr: Float, a: Float, par: Float) {
                val c = Offset(w * fx + pan.x * par + 30f * sin(clock * 0.15f + fx * 5f), h * fy + pan.y * par + 24f * cos(clock * 0.12f + fy * 4f))
                drawCircle(Brush.radialGradient(listOf(col.copy(alpha = a), col.copy(alpha = a * 0.3f), Color.Transparent), c, rr), rr, c)
            }
            cloud(Color(0xFF5B2BFF), 0.25f, 0.25f, w * 1.0f, 0.28f, 0.10f)
            cloud(Color(0xFFFF2FC2), 0.90f, 0.55f, w * 0.8f, 0.16f, 0.14f)
            cloud(Color(0xFF1FD5FF), 0.35f, 0.88f, w * 0.9f, 0.14f, 0.08f)

            // parallax background stars
            for (s in bgStars) {
                val par = 0.05f + s[4] * 0.25f
                var x = (s[0] * w + pan.x * par) % w; if (x < 0) x += w
                var y = (s[1] * h + pan.y * par) % h; if (y < 0) y += h
                val tw = 0.45f + 0.55f * (0.5f + 0.5f * sin(clock * (1f + s[4] * 1.5f) + s[3]))
                drawCircle(Color(0xFFE9E2FF).copy(alpha = 0.55f * tw * s[2]), (0.5f + s[4] * 0.9f) * d, Offset(x, y))
            }

            // constellation lines
            clusters.forEach { cl ->
                val m = cl.members
                if (m.size >= 2) {
                    val accent = stars[m[0]].color
                    for (i in 0 until m.size) {
                        val a = stars[m[i]]
                        val b = stars[m[(i + 1) % m.size]]
                        if (m.size == 2 && i == 1) break
                        val pa = toScreen(a.x, a.y)
                        val pb = toScreen(b.x, b.y)
                        val al = if (selected?.cluster == a.cluster) 0.55f else 0.22f
                        drawLine(accent.copy(alpha = al * 0.5f), pa, pb, strokeWidth = 3.6f * d, cap = StrokeCap.Round)
                        drawLine(Color.White.copy(alpha = al), pa, pb, strokeWidth = 1.1f * d, cap = StrokeCap.Round)
                    }
                }
            }

            // stars
            stars.forEach { st ->
                val p = toScreen(st.x, st.y)
                if (p.x < -60 || p.x > w + 60 || p.y < -60 || p.y > h + 60) return@forEach
                val tw = 0.78f + 0.22f * sin(clock * 2.1f + st.phase)
                val r = st.size * baseScale() * zoom * d * 0.55f * tw
                val isCur = st.song.id == currentSongId
                val isSel = selected?.song?.id == st.song.id
                val glowR = r * (if (isCur) 9f else 6f)
                drawCircle(
                    Brush.radialGradient(
                        listOf(st.color.copy(alpha = if (isCur) 0.75f else 0.42f * tw), st.color.copy(alpha = 0.08f), Color.Transparent),
                        p, glowR,
                    ),
                    glowR, p,
                )
                // diffraction spikes on the bigger stars
                if (st.size > 5.5f || isCur || isSel) {
                    val sp = r * (if (isCur) 7f else 4.2f)
                    drawLine(Color.White.copy(alpha = 0.55f * tw), Offset(p.x - sp, p.y), Offset(p.x + sp, p.y), strokeWidth = 1f * d, cap = StrokeCap.Round)
                    drawLine(Color.White.copy(alpha = 0.55f * tw), Offset(p.x, p.y - sp), Offset(p.x, p.y + sp), strokeWidth = 1f * d, cap = StrokeCap.Round)
                }
                drawCircle(Color.White.copy(alpha = 0.95f), r * 0.55f + 1f * d, p)
                drawCircle(st.color.copy(alpha = 0.9f), r, p, style = Stroke(1.2f * d))
                if (isCur) {
                    val pr = r * (2.2f + 0.8f * sin(clock * 3.2f))
                    drawCircle(Color(0xFF2FE6FF).copy(alpha = if (isPlaying) 0.8f else 0.4f), pr, p, style = Stroke(1.6f * d))
                }
                if (isSel) {
                    val pr = r * (3.2f + 0.5f * sin(clock * 4f))
                    drawCircle(Color.White.copy(alpha = 0.85f), pr, p, style = Stroke(1.4f * d))
                }
            }

            // artist labels
            if (zoom > 0.75f) {
                clusters.forEach { cl ->
                    val p = toScreen(cl.cx, cl.cy)
                    if (p.x < -80 || p.x > w + 80 || p.y < -40 || p.y > h + 40) return@forEach
                    val label = cl.artist.take(22)
                    val layout = textMeasurer.measure(
                        label,
                        TextStyle(color = Color.White.copy(alpha = if (cl.members.size > 1) 0.62f else 0.38f), fontSize = (10f + zoom * 1.5f).sp, fontWeight = FontWeight.Medium, letterSpacing = 0.8.sp),
                        overflow = TextOverflow.Ellipsis,
                        maxLines = 1,
                    )
                    val extra = (stars[cl.members.first()].size + 22f) * baseScale() * zoom * d * 0.7f
                    drawText(layout, topLeft = Offset(p.x - layout.size.width / 2f, p.y + extra))
                }
            }

            // landing bursts
            bursts.forEach { (wp, born, col) ->
                val a = ((clock - born) / 0.9f).coerceIn(0f, 1f)
                val p = toScreen(wp.x, wp.y)
                drawCircle(col.copy(alpha = (1f - a) * 0.9f), 8f * d + a * 70f * d, p, style = Stroke((3f * (1f - a) + 0.6f) * d))
                drawCircle(Color.White.copy(alpha = (1f - a) * 0.6f), 4f * d + a * 34f * d, p, style = Stroke(1.2f * d))
                for (k in 0 until 10) {
                    val ang = k * 0.6283f + born
                    val rr = a * 46f * d
                    drawCircle(Color.White.copy(alpha = (1f - a)), (1.6f * (1f - a) + 0.4f) * d, Offset(p.x + cos(ang) * rr, p.y + sin(ang) * rr))
                }
            }

            // comets (ambient + landing)
            comets.forEach { c ->
                val t = ((clock - c.born) / c.dur).coerceIn(0f, 1f)
                val e = if (c.lands) 1f - (1f - t).pow(2.4f) else t
                val head = Offset(c.from.x + (c.to.x - c.from.x) * e, c.from.y + (c.to.y - c.from.y) * e)
                val dx = c.to.x - c.from.x
                val dy = c.to.y - c.from.y
                val len = sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                val dir = Offset(dx / len, dy / len)
                val fade = if (c.lands) (if (t < 0.9f) 1f else (1f - t) * 10f) else sin(t * Math.PI.toFloat())
                drawComet(head, dir, min(len * 0.55f, w * 0.6f) * (if (c.lands) (0.35f + 0.65f * (1f - t)) else 1f), fade.coerceIn(0f, 1f), accent = c.accent)
            }
        }

        // header
        Row(
            Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x22FFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape).clickable { onBack() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("CONSTELLATION", color = Color(0xFF7BDCFF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Your universe", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Light)
                Text(
                    "${stars.size} stars · ${clusters.size} constellations · drag, pinch, tap",
                    color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, maxLines = 1,
                )
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x22FFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape).clickable { onOpenLibrary() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.LibraryMusic, "Library", tint = Color.White) }
        }

        // selected / now playing card
        val shown = selected?.song ?: stars.firstOrNull { it.song.id == currentSongId }?.song
        if (shown != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xE6150C30), Color(0xE608041A))))
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(Color(0xAA2FE6FF), Color(0x33FFFFFF), Color(0xAAA37CFF))),
                        RoundedCornerShape(22.dp),
                    )
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF2FE6FF), Color(0xFFA37CFF), Color(0xFFFF3DCB)))),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.PlayArrow, null, tint = Color.White) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(shown.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(shown.artist, color = Color(0xFF9FB4FF), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        if (stars.isEmpty()) {
            Text(
                "Scan your library to light the sky",
                color = Color.White.copy(alpha = 0.5f),
                modifier = Modifier.align(Alignment.Center),
            )
        }
    }
}
