package com.texgen.music.texwave.ui.screens

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAlarm
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.AlarmEngine
import com.texgen.music.texwave.ui.ref.AlarmBackdrop
import com.texgen.music.texwave.ui.ref.AlarmPresets
import com.texgen.music.texwave.ui.ref.DefaultAlarmTheme
import com.texgen.music.texwave.ui.ref.Ref
import com.texgen.music.texwave.ui.ref.RefBackground
import com.texgen.music.texwave.ui.ref.ScreenTitle
import com.texgen.music.texwave.ui.ref.refCard
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar

private data class TexAlarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String,
    val daily: Boolean,
    val enabled: Boolean,
    val trigger: Long,
    /** "" = default alarm tone, "silent" = Phantom speaks only, otherwise a content/file uri. */
    val soundUri: String?,
    val soundName: String,
    val theme: String,
)

private data class Draft(
    val id: Int?,
    val hour: Int,
    val minute: Int,
    val label: String,
    val daily: Boolean,
    val sound: String,
    val soundName: String,
    val theme: String,
)

private fun soundTitle(a: TexAlarm): String = when {
    a.soundUri == "silent" -> "Phantom voice only"
    a.soundUri.isNullOrBlank() -> "Default alarm tone"
    else -> a.soundName.ifBlank { "Custom sound" }
}

private fun untilLabel(trigger: Long): String {
    val m = ((trigger - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0)
    val h = m / 60
    return when {
        h >= 24 -> "in ${h / 24}d ${h % 24}h"
        h > 0 -> "in ${h}h ${m % 60}m"
        else -> "in ${m}m"
    }
}

@Composable
fun AlarmScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("texwave_alarms", Context.MODE_PRIVATE) }
    var alarms by remember { mutableStateOf(loadAlarms(prefs)) }
    var draft by remember { mutableStateOf<Draft?>(null) }

    fun persist(next: List<TexAlarm>) {
        alarms = next
        val arr = JSONArray()
        val ed = prefs.edit()
        next.forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id); put("hour", a.hour); put("minute", a.minute)
                put("label", a.label); put("daily", a.daily); put("enabled", a.enabled)
                put("trigger", a.trigger)
                put("soundUri", a.soundUri ?: JSONObject.NULL)
                put("soundName", a.soundName)
                put("theme", a.theme)
            })
            ed.putString("theme_${a.id}", a.theme)
        }
        ed.putString("alarms", arr.toString()).apply()
    }

    fun schedule(a: TexAlarm) {
        AlarmEngine.schedule(
            context, id = a.id, hour = a.hour, minute = a.minute,
            label = a.label, soundUri = a.soundUri, triggerAt = a.trigger,
        )
    }

    fun save(d: Draft) {
        val at = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, d.hour); set(Calendar.MINUTE, d.minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val id = d.id ?: ((alarms.maxOfOrNull { it.id } ?: 1000) + 1)
        val a = TexAlarm(
            id, d.hour, d.minute, d.label.ifBlank { "TEXWAVE Alarm" }, d.daily, true, at.timeInMillis,
            d.sound.ifBlank { null }, d.soundName, d.theme,
        )
        if (d.id != null) AlarmEngine.cancel(context, id)
        persist(if (d.id != null) alarms.map { if (it.id == id) a else it } else alarms + a)
        schedule(a)
        draft = null
        Toast.makeText(context, "Alarm set for %02d:%02d (%s)".format(d.hour, d.minute, untilLabel(a.trigger)), Toast.LENGTH_SHORT).show()
    }

    fun ensureExact() { AlarmEngine.ensureExactPermission(context) }

    fun newDraft(): Draft {
        val now = Calendar.getInstance()
        return Draft(
            null, (now.get(Calendar.HOUR_OF_DAY) + 1) % 24, 0, "", true,
            prefs.getString("default_sound", "") ?: "",
            prefs.getString("default_sound_name", "") ?: "",
            prefs.getString("default_theme", DefaultAlarmTheme) ?: DefaultAlarmTheme,
        )
    }

    val next = alarms.filter { it.enabled }.minByOrNull { AlarmEngine.nextTrigger(it.hour, it.minute) }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 14.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) { ScreenTitle("Alarms") }
                Box(
                    Modifier.size(44.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Ref.Purple, Ref.Blue)))
                        .clickable { ensureExact(); draft = newDraft() },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.AddAlarm, "New alarm", tint = Color.White, modifier = Modifier.size(24.dp)) }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    val shape = RoundedCornerShape(26.dp)
                    Box(
                        Modifier.fillMaxWidth().height(170.dp).clip(shape)
                            .border(1.5.dp, Brush.linearGradient(listOf(Ref.Violet, Ref.Blue, Ref.Magenta.copy(alpha = 0.8f))), shape)
                            .clickable { if (next == null) { ensureExact(); draft = newDraft() } },
                    ) {
                        AlarmBackdrop(next?.theme ?: prefs.getString("default_theme", DefaultAlarmTheme), scrim = 0.35f)
                        Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                            if (next != null) {
                                Text("NEXT ALARM", color = Ref.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Text("%02d:%02d".format(next.hour, next.minute), color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Light)
                                Text(untilLabel(AlarmEngine.nextTrigger(next.hour, next.minute)) + " · " + next.label, color = Color(0xFFD5DBFF), fontSize = 14.sp)
                            } else {
                                Text("No alarms yet", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                                Text("Tap to create one — pick a sound, or let Phantom wake you.", color = Color(0xFFD5DBFF), fontSize = 14.sp)
                            }
                        }
                    }
                }

                items(alarms, key = { it.id }) { a ->
                    Row(
                        Modifier.fillMaxWidth().refCard(20.dp).clickable {
                            draft = Draft(a.id, a.hour, a.minute, a.label, a.daily, a.soundUri.orEmpty(), a.soundName, a.theme)
                        }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(68.dp).clip(RoundedCornerShape(16.dp))) { AlarmBackdrop(a.theme, scrim = 0.2f) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("%02d:%02d".format(a.hour, a.minute), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
                            Text(
                                a.label + if (a.daily) " · Daily" else " · Once",
                                color = Ref.Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            Text(soundTitle(a), color = if (a.soundUri == "silent") Ref.Lavender else Ref.Cyan, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Switch(
                            checked = a.enabled,
                            colors = SwitchDefaults.colors(checkedTrackColor = Ref.Purple, checkedThumbColor = Color.White),
                            onCheckedChange = { on ->
                                val up = a.copy(
                                    enabled = on,
                                    trigger = AlarmEngine.nextTrigger(a.hour, a.minute),
                                )
                                persist(alarms.map { if (it.id == a.id) up else it })
                                if (on) { ensureExact(); schedule(up) } else AlarmEngine.cancel(context, a.id)
                            },
                        )
                        Icon(
                            Icons.Rounded.Delete, "Delete", tint = Color(0xFFFF6D9B),
                            modifier = Modifier.padding(start = 6.dp, end = 4.dp).size(26.dp).clickable {
                                AlarmEngine.cancel(context, a.id)
                                persist(alarms.filterNot { it.id == a.id })
                            },
                        )
                    }
                }

                item { BriefingOptions(prefs) }
            }
        }

        draft?.let { d ->
            BackHandler { draft = null }
            AlarmEditor(
                d = d, prefs = prefs,
                onChange = { draft = it },
                onSave = { save(it) },
                onCancel = { draft = null },
            )
        }
    }
}

@Composable
private fun AlarmEditor(d: Draft, prefs: android.content.SharedPreferences, onChange: (Draft) -> Unit, onSave: (Draft) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current

    val songPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        onChange(d.copy(sound = uri.toString(), soundName = uri.lastPathSegment?.substringAfterLast('/') ?: "My song"))
    }
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        @Suppress("DEPRECATION")
        val uri = r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        if (uri != null) {
            val name = runCatching { RingtoneManager.getRingtone(context, uri).getTitle(context) }.getOrDefault("Ringtone")
            onChange(d.copy(sound = uri.toString(), soundName = name))
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            val out = File(context.filesDir, "alarm_theme_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
            onChange(d.copy(theme = out.absolutePath))
        }.onFailure { Toast.makeText(context, "Could not load that picture", Toast.LENGTH_SHORT).show() }
    }

    Box(Modifier.fillMaxSize().background(Ref.Bg).clickable(enabled = false) { }) {
        AlarmBackdrop(d.theme, scrim = 0.75f)
        Column(
            Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
        ) {
            Text(if (d.id == null) "New alarm" else "Edit alarm", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(16.dp))

            // Time
            Column(
                Modifier.fillMaxWidth().refCard(24.dp, hot = true).clickable {
                    TimePickerDialog(context, { _, h, m -> onChange(d.copy(hour = h, minute = m)) }, d.hour, d.minute, true).show()
                }.padding(vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("%02d:%02d".format(d.hour, d.minute), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
                Text("Tap to change time · " + untilLabel(AlarmEngine.nextTrigger(d.hour, d.minute)), color = Ref.Cyan, fontSize = 13.sp)
            }

            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = d.label, onValueChange = { onChange(d.copy(label = it.take(40))) },
                singleLine = true, placeholder = { Text("Label (optional)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Repeat daily", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = d.daily, onCheckedChange = { onChange(d.copy(daily = it)) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Ref.Purple, checkedThumbColor = Color.White),
                )
            }

            Spacer(Modifier.height(10.dp))
            Text("Wake-up sound", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            SoundOption(
                Icons.Rounded.AutoAwesome, "Phantom voice only", "Silent alarm — Phantom talks you awake",
                selected = d.sound == "silent",
            ) { onChange(d.copy(sound = "silent", soundName = "Phantom voice only")) }
            SoundOption(
                Icons.Rounded.VolumeUp, "Default alarm tone", "Your phone's alarm sound",
                selected = d.sound.isBlank(),
            ) { onChange(d.copy(sound = "", soundName = "")) }
            SoundOption(
                Icons.Rounded.Notifications, "System ringtone", if (d.sound.isNotBlank() && d.sound != "silent" && d.soundName.isNotBlank()) d.soundName else "Choose from your phone's list",
                selected = false,
            ) {
                val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Alarm sound")
                }
                ringtonePicker.launch(i)
            }
            SoundOption(
                Icons.Rounded.MusicNote, "My song", "Pick any audio file from your phone",
                selected = false,
            ) { songPicker.launch("audio/*") }
            if (d.sound.isNotBlank() && d.sound != "silent") {
                Text("Selected: ${d.soundName.ifBlank { "Custom sound" }}", color = Ref.Cyan, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp, top = 4.dp))
            }

            Spacer(Modifier.height(18.dp))
            Text("Alarm picture", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Shown full-screen when the alarm rings", color = Ref.Muted, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(AlarmPresets, key = { it.id }) { p ->
                    val sel = d.theme == "preset:" + p.id
                    val s = RoundedCornerShape(18.dp)
                    Column(Modifier.width(86.dp).clickable { onChange(d.copy(theme = "preset:" + p.id)) }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(86.dp, 112.dp).clip(s)
                                .border(if (sel) 2.5.dp else 1.dp, if (sel) Ref.Cyan else Ref.Line, s),
                        ) {
                            androidx.compose.foundation.Image(painterResource(p.res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
                            if (sel) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp).background(Ref.Cyan, CircleShape))
                        }
                        Text(p.label, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                item {
                    val custom = d.theme.startsWith("/")
                    val s = RoundedCornerShape(18.dp)
                    Column(Modifier.width(86.dp).clickable { imagePicker.launch("image/*") }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(86.dp, 112.dp).clip(s).background(Ref.Card)
                                .border(if (custom) 2.5.dp else 1.dp, if (custom) Ref.Cyan else Ref.Violet.copy(alpha = 0.6f), s),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (custom) AlarmBackdrop(d.theme, scrim = 0.1f)
                            Icon(Icons.Rounded.Image, null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        Text("My photo", color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    Modifier.weight(1f).height(54.dp).refCard(27.dp).clickable(onClick = onCancel),
                    contentAlignment = Alignment.Center,
                ) { Text("Cancel", color = Color.White, fontSize = 16.sp) }
                Box(
                    Modifier.weight(1.4f).height(54.dp).clip(RoundedCornerShape(27.dp))
                        .background(Brush.horizontalGradient(listOf(Ref.Purple, Ref.Blue)))
                        .clickable {
                            prefs.edit().putString("default_sound", d.sound).putString("default_sound_name", d.soundName).putString("default_theme", d.theme).apply()
                            onSave(d)
                        },
                    contentAlignment = Alignment.Center,
                ) { Text("Save alarm", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SoundOption(icon: ImageVector, title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).refCard(18.dp, hot = selected).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = if (selected) Ref.Cyan else Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = Ref.Sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (selected) Icon(Icons.Rounded.Check, null, tint = Ref.Cyan, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun BriefingOptions(prefs: android.content.SharedPreferences) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().refCard(20.dp).padding(14.dp)) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = Ref.Violet, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Phantom morning briefing", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text("What Phantom says when the alarm rings", color = Ref.Sub, fontSize = 12.sp)
            }
            Text(if (open) "Hide" else "Edit", color = Ref.Cyan, fontSize = 14.sp)
        }
        if (open) {
            var city by remember { mutableStateOf(prefs.getString("briefing_city", "Delhi") ?: "Delhi") }
            OutlinedTextField(
                value = city, onValueChange = { city = it; prefs.edit().putString("briefing_city", it.trim()).apply() },
                label = { Text("City for weather") }, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp), shape = RoundedCornerShape(16.dp),
            )
            listOf(
                "say_greeting" to "Greeting", "say_time" to "Time & day", "say_label" to "Alarm label",
                "say_weather" to "Weather", "say_battery" to "Battery",
            ).forEach { (key, name) ->
                var on by remember { mutableStateOf(prefs.getBoolean(key, true)) }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = Color(0xFFDCE5FF), fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Switch(
                        checked = on, onCheckedChange = { on = it; prefs.edit().putBoolean(key, it).apply() },
                        colors = SwitchDefaults.colors(checkedTrackColor = Ref.Purple, checkedThumbColor = Color.White),
                    )
                }
            }
        }
    }
}

private fun loadAlarms(prefs: android.content.SharedPreferences): List<TexAlarm> = runCatching {
    val arr = JSONArray(prefs.getString("alarms", "[]"))
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        TexAlarm(
            o.getInt("id"), o.getInt("hour"), o.getInt("minute"),
            o.optString("label", "TEXWAVE Alarm"), o.optBoolean("daily"), o.optBoolean("enabled", true),
            o.optLong("trigger"),
            if (o.isNull("soundUri")) null else o.optString("soundUri", ""),
            o.optString("soundName", ""),
            o.optString("theme", DefaultAlarmTheme).ifBlank { DefaultAlarmTheme },
        )
    }
}.getOrDefault(emptyList())
