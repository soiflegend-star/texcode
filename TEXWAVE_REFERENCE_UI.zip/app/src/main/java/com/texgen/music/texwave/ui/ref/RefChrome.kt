package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.player.PlayerState

/**
 * Reference bottom bar: Home · Library · [orb] · Phantom · More.
 * selected: 0 Home, 1 Library, 3 Phantom, 4 More, anything else = none.
 */
@Composable
fun RefNavBar(
    selected: Int,
    onHome: () -> Unit,
    onLibrary: () -> Unit,
    onOrb: () -> Unit,
    onPhantom: () -> Unit,
    onMore: () -> Unit,
) {
    val none = remember { MutableInteractionSource() }
    Box(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xF2060B1E), Color(0xFA03050F))))
            .drawBehind {
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Ref.Violet.copy(alpha = 0.8f), Ref.Cyan.copy(alpha = 0.6f), Color.Transparent),
                    ),
                    topLeft = Offset(size.width * 0.15f, 0f),
                    size = Size(size.width * 0.7f, 1.5.dp.toPx()),
                )
                drawRect(Ref.Line.copy(alpha = 0.6f), size = Size(size.width, 1.dp.toPx()))
            }
            .navigationBarsPadding(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(70.dp)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NavItem("Home", Icons.Outlined.Home, selected == 0, Modifier.weight(1f), onHome)
            NavItem("Library", Icons.Rounded.VideoLibrary, selected == 1, Modifier.weight(1f), onLibrary)
            Box(
                Modifier
                    .weight(1f)
                    .clickable(interactionSource = none, indication = null, onClick = onOrb),
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.offset(y = (-6).dp).size(58.dp), contentAlignment = Alignment.Center) {
                    GlowRing(Modifier.size(58.dp), strokeDp = 2.5.dp, speedMs = 6000)
                    Image(
                        painterResource(R.drawable.ref_nav_orb), null,
                        Modifier.size(46.dp).clip(CircleShape).border(1.dp, Ref.Violet.copy(alpha = 0.7f), CircleShape),
                        contentScale = ContentScale.Crop,
                    )
                }
            }
            NavItem("Phantom", Icons.Rounded.SmartToy, selected == 3, Modifier.weight(1f), onPhantom)
            NavItem("More", Icons.Rounded.FormatListBulleted, selected == 4, Modifier.weight(1f), onMore)
        }
    }
}

@Composable
private fun NavItem(
    label: String,
    icon: ImageVector,
    on: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val tint = if (on) Ref.Cyan else Color(0xFFC9D6FF)
    Column(
        modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.drawBehind {
                if (on) {
                    drawCircle(
                        Brush.radialGradient(listOf(Ref.Cyan.copy(alpha = 0.35f), Color.Transparent)),
                        radius = 26.dp.toPx(),
                    )
                }
            },
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, label, tint = tint, modifier = Modifier.size(26.dp))
        }
        Text(label, color = tint, fontSize = 11.5.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
    }
}

/** Reference mini player: cover · title/artist · prev · pause · next. */
@Composable
fun RefMiniPlayer(
    state: PlayerState,
    position: State<Long>,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
) {
    val song = state.current ?: return
    Row(
        Modifier
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .fillMaxWidth()
            .height(62.dp)
            .refCard(18.dp)
            .clickable(onClick = onOpen)
            .drawBehind {
                val d = state.durationMs
                if (d > 0) {
                    val f = (position.value.toFloat() / d).coerceIn(0f, 1f)
                    drawRect(
                        Brush.horizontalGradient(listOf(Ref.Cyan, Ref.Violet)),
                        topLeft = Offset(0f, size.height - 2.dp.toPx()),
                        size = Size(size.width * f, 2.dp.toPx()),
                    )
                }
            }
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SongThumb(song, Modifier.size(46.dp), RoundedCornerShape(10.dp), fallback = R.drawable.ref_mini_art)
        Box(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, color = Ref.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(
            Icons.Rounded.SkipPrevious, "Previous", tint = Color.White,
            modifier = Modifier.size(34.dp).clickable(onClick = onPrevious).padding(4.dp),
        )
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color(0xFF0B1636))
                .border(1.dp, Ref.Blue.copy(alpha = 0.7f), CircleShape)
                .clickable(onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                if (state.isPlaying) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(24.dp),
            )
        }
        Icon(
            Icons.Rounded.SkipNext, "Next", tint = Color.White,
            modifier = Modifier.size(34.dp).clickable(onClick = onNext).padding(4.dp),
        )
    }
}
