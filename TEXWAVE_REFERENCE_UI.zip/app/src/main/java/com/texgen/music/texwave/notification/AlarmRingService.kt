package com.texgen.music.texwave.notification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.texgen.music.texwave.AlarmRingActivity
import com.texgen.music.texwave.R

/**
 * Foreground service that actually makes the alarm ring. Alarm broadcasts may start foreground
 * services even when the app is in the background, whereas starting an activity or relying on
 * notification permission can silently fail on modern Android. The service owns the sound and
 * vibration, posts the full-screen notification, and tries to open the ring screen.
 */
class AlarmRingService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wake: PowerManager.WakeLock? = null
    private var alarmId = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        alarmId = intent?.getIntExtra("alarm_id", 0) ?: 0
        val label = intent?.getStringExtra("alarm_label") ?: "TEXWAVE Alarm"
        val sound = intent?.getStringExtra("alarm_sound").orEmpty()

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Ringing alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(null, null)
                    enableVibration(false)
                    setBypassDnd(true)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                },
            )
        }
        val ringIntent = Intent(this, AlarmRingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(AlarmRingActivity.EXTRA_ALARM_ID, alarmId)
            putExtra(AlarmRingActivity.EXTRA_LABEL, label)
            putExtra(AlarmRingActivity.EXTRA_SOUND, sound)
        }
        val pi = PendingIntent.getActivity(
            this, alarmId + 2000, ringIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif_small)
            .setContentTitle(label)
            .setContentText("Alarm ringing — tap to open")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        running = true

        runCatching {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "texwave:alarm").apply { acquire(10 * 60_000L) }
        }
        if (sound != "silent") startSound(sound)
        startVibrate()
        // Best effort: open the ring screen right away (the full-screen notification covers the locked case)
        runCatching { startActivity(ringIntent) }
        return START_NOT_STICKY
    }

    private fun startSound(sound: String) {
        val fallback = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        val candidates = buildList {
            if (sound.isNotBlank()) add(Uri.parse(sound))
            if (fallback != null) add(fallback)
        }
        for (uri in candidates) {
            try {
                val mp = MediaPlayer().apply {
                    setDataSource(this@AlarmRingService, uri)
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build(),
                    )
                    isLooping = true
                    prepare()
                    start()
                }
                player = mp
                AlarmRingActivity.activePlayer = mp
                return
            } catch (_: Exception) {
            }
        }
    }

    private fun startVibrate() {
        runCatching {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as? Vibrator
            }
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 300, 600, 300, 600), 0))
        }
    }

    override fun onDestroy() {
        running = false
        runCatching { player?.stop(); player?.release() }
        if (AlarmRingActivity.activePlayer === player) AlarmRingActivity.activePlayer = null
        player = null
        runCatching { vibrator?.cancel() }
        runCatching { if (wake?.isHeld == true) wake?.release() }
        runCatching {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(alarmId)
        }
        super.onDestroy()
    }

    companion object {
        private const val CH = "texwave_alarm_ringing"
        private const val NOTIF_ID = 424242
        const val ACTION_STOP = "com.texgen.music.texwave.STOP_ALARM"
        @Volatile var running: Boolean = false

        fun start(context: Context, id: Int, label: String, sound: String) {
            val i = Intent(context, AlarmRingService::class.java).apply {
                putExtra("alarm_id", id)
                putExtra("alarm_label", label)
                putExtra("alarm_sound", sound)
            }
            ContextCompat.startForegroundService(context, i)
        }

        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, AlarmRingService::class.java)) }
        }
    }
}
