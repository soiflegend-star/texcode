package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState

private data class Cat(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val colors: List<Color>)

private val cats = listOf(
    Cat("Artists", Icons.Rounded.Person, listOf(Color(0xFFB04DFF), Color(0xFF6D3FF0))),
    Cat("Songs", Icons.Rounded.MusicNote, listOf(Color(0xFF7B5CFF), Color(0xFF3A3FD8))),
    Cat("Albums", Icons.Rounded.Album, listOf(Color(0xFF2F7BFF), Color(0xFF19D3F2))),
    Cat("Playlists", Icons.Rounded.PlaylistPlay, listOf(Color(0xFF19D3F2), Color(0xFF1AE0B0))),
)

/** Reference screen 4 — Search. */
@Composable
fun RefSearchScreen(
    lib: LibraryState,
    player: PlayerState,
    onPlay: (List<Song>, Int) -> Unit,
    onMore: (Song) -> Unit,
    onOpenPlaylistId: (String) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var cat by rememberSaveable { mutableIntStateOf(-1) }
    var allArtists by rememberSaveable { mutableStateOf(false) }
    val q = query.trim().lowercase()

    val topArtists = remember(lib.songs, lib.playCounts) {
        lib.songs.groupBy { it.artist }.entries
            .sortedByDescending { e -> e.value.sumOf { lib.playCounts[it.id] ?: 0 } * 1000 + e.value.size }
            .map { it.key }.take(10)
    }
    val results = remember(lib.songs, q, cat) {
        if (q.isEmpty()) emptyList() else lib.songs.filter {
            when (cat) {
                0 -> it.artist.lowercase().contains(q)
                2 -> it.album.lowercase().contains(q)
                else -> it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
            }
        }
    }
    val resPlaylists = remember(lib.playlists, q) {
        if (q.isEmpty()) emptyList() else lib.playlists.filter { it.name.lowercase().contains(q) }
    }

    RefBackground {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
            item {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.weight(1f)) { ScreenTitle("Search") }
                    Icon(
                        Icons.Rounded.Tune, "Clear filters", tint = Color.White,
                        modifier = Modifier.size(24.dp).clickable { cat = -1; query = ""; allArtists = false },
                    )
                }
            }
            item {
                RefSearchField(
                    value = query, onChange = { query = it }, placeholder = "Search anything...",
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp), height = 52.dp, textSize = 16.sp,
                )
            }
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                    cats.forEachIndexed { i, c ->
                        NeonTile(
                            Modifier.weight(1f).height(86.dp).clickable { cat = if (cat == i) -1 else i },
                            colors = if (cat == i) listOf(Color.White, c.colors.last()) else c.colors,
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(c.icon, null, tint = c.colors.first(), modifier = Modifier.size(30.dp))
                                Spacer(Modifier.height(6.dp))
                                Text(c.label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            if (q.isNotEmpty()) {
                item { Spacer(Modifier.height(20.dp)) }
                item { SectionTitle("Results", null) }
                item { Spacer(Modifier.height(8.dp)) }
                if (cat == 3 || cat == -1) {
                    itemsIndexed(resPlaylists, key = { _, p -> "pl" + p.id }) { _, p ->
                        val first = lib.songs.firstOrNull { it.id == p.songIds.firstOrNull() }
                        RefRow(
                            title = p.name, subtitle = "Playlist • ${p.songIds.size} songs",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp),
                            onClick = { onOpenPlaylistId(p.id) },
                        ) { SongThumb(first, Modifier.size(62.dp), RoundedCornerShape(14.dp)) }
                    }
                }
                if (cat != 3) {
                    itemsIndexed(results, key = { _, s -> s.id }) { i, s ->
                        RefRow(
                            title = s.title, subtitle = s.artist,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp),
                            onChevron = { onMore(s) },
                            onClick = { onPlay(results, i) },
                        ) { SongThumb(s, Modifier.size(62.dp), RoundedCornerShape(14.dp)) }
                    }
                }
            } else {
                item { Spacer(Modifier.height(24.dp)) }
                item { SectionTitle("Trending Artists", if (allArtists) "Less" else "See All") { allArtists = !allArtists } }
                item { Spacer(Modifier.height(14.dp)) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 18.dp),
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(14.dp),
                    ) {
                        itemsIndexed(topArtists) { i, name ->
                            Column(
                                Modifier.width(76.dp).clickable {
                                    val list = lib.songs.filter { it.artist == name }
                                    if (list.isNotEmpty()) onPlay(list, 0)
                                },
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                InitialsAvatar(
                                    name, Modifier.size(70.dp),
                                    ringColors = when (i % 4) {
                                        0 -> listOf(Ref.Violet, Ref.Purple)
                                        1 -> listOf(Ref.Blue, Ref.Cyan)
                                        2 -> listOf(Ref.Blue, Ref.Violet)
                                        else -> listOf(Ref.Cyan, Ref.Blue)
                                    },
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    name, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
                if (allArtists) {
                    val every = lib.songs.groupBy { it.artist }.keys.sorted()
                    itemsIndexed(every, key = { _, n -> "artist_" + n }) { _, name ->
                        RefRow(
                            title = name, subtitle = "${lib.songs.count { it.artist == name }} songs",
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp),
                            onClick = {
                                val l = lib.songs.filter { it.artist == name }
                                if (l.isNotEmpty()) onPlay(l, 0)
                            },
                        ) { InitialsAvatar(name, Modifier.size(54.dp)) }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
                item { SectionTitle("Recommended For You", null) }
                item { Spacer(Modifier.height(10.dp)) }
                // Real playlists first, then smart mixes built from the library.
                val liked = lib.songs.filter { it.id in lib.liked }
                val byPlays = lib.songs.sortedByDescending { lib.playCounts[it.id] ?: 0 }.take(50)
                val recentSongs = lib.recents.mapNotNull { id -> lib.songs.firstOrNull { it.id == id } }
                val mixes = buildList<Triple<String, List<Song>, Int>> {
                    lib.playlists.forEach { p ->
                        val l = p.songIds.mapNotNull { id -> lib.songs.firstOrNull { it.id == id } }
                        add(Triple(p.name, l, R.drawable.ref_pl_chill))
                    }
                    if (liked.isNotEmpty()) add(Triple("Liked Songs", liked, R.drawable.ref_pl_focus))
                    if (byPlays.isNotEmpty()) add(Triple("Most Played", byPlays, R.drawable.ref_pl_workout))
                    if (recentSongs.isNotEmpty()) add(Triple("Recently Played", recentSongs, R.drawable.ref_pl_chill))
                    if (lib.songs.isNotEmpty()) add(Triple("Shuffle Mix", lib.songs.shuffled(java.util.Random(42)).take(40), R.drawable.ref_pl_focus))
                }.take(6)
                itemsIndexed(mixes, key = { i, m -> "${i}_${m.first}" }) { i, m ->
                    val fb = intArrayOf(R.drawable.ref_pl_chill, R.drawable.ref_pl_focus, R.drawable.ref_pl_workout)[i % 3]
                    RefRow(
                        title = m.first, subtitle = "Playlist • ${m.second.size} songs",
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 5.dp),
                        onClick = { if (m.second.isNotEmpty()) onPlay(m.second, 0) },
                    ) { SongThumb(m.second.firstOrNull(), Modifier.size(62.dp), RoundedCornerShape(14.dp), fallback = fb) }
                }
            }
        }
    }
}
