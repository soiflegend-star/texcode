package com.texgen.music.texwave.ui.ref

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.ConversationPreview
import com.texgen.music.texwave.data.chat.FriendsStore
import com.texgen.music.texwave.data.chat.Profile
import com.texgen.music.texwave.data.chat.Resonance
import com.texgen.music.texwave.data.chat.SocialFeedRepository
import com.texgen.music.texwave.data.chat.SocialPost
import com.texgen.music.texwave.data.chat.avatarModel
import com.texgen.music.texwave.data.chat.parseIsoMillis
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

internal fun agoLabel(ms: Long): String {
    if (ms <= 0L) return ""
    val d = System.currentTimeMillis() - ms
    return when {
        d < 60_000 -> "now"
        d < 3_600_000 -> "${d / 60_000}m ago"
        d < 86_400_000 -> "${d / 3_600_000}h ago"
        else -> "${d / 86_400_000}d ago"
    }
}

/** Underlined two/three-tab header used by Feed, Messages and Groups. */
@Composable
internal fun RefTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            labels.forEachIndexed { i, t ->
                val on = i == selected
                Column(
                    Modifier.weight(1f).clickable { onSelect(i) }.padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        t, fontSize = 16.sp,
                        color = if (on) Ref.Lavender else Color.White,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                    )
                    Spacer(Modifier.height(7.dp))
                    Box(
                        Modifier.height(2.dp).fillMaxWidth(0.75f).background(
                            if (on) Brush.horizontalGradient(listOf(Ref.Cyan, Ref.Violet))
                            else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)),
                        ),
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Ref.Line.copy(alpha = 0.7f)))
    }
}

/** Rounded-square avatar with violet ring: remote photo, reference art, or initials. */
@Composable
internal fun RingAvatar(
    name: String,
    model: Any?,
    modifier: Modifier = Modifier,
    fallbackRes: Int? = null,
    shapeRadius: androidx.compose.ui.unit.Dp = 999.dp,
    ring: List<Color> = listOf(Ref.Violet, Ref.Magenta.copy(alpha = 0.8f)),
) {
    val shape = RoundedCornerShape(shapeRadius)
    Box(
        modifier.clip(shape)
            .background(Brush.linearGradient(listOf(Ref.Purple.copy(alpha = 0.7f), Ref.Blue.copy(alpha = 0.5f))))
            .border(2.dp, Brush.linearGradient(ring), shape),
        contentAlignment = Alignment.Center,
    ) {
        if (fallbackRes != null) {
            Image(painterResource(fallbackRes), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
        } else {
            val ini = name.trim().take(1).uppercase().ifEmpty { "T" }
            Text(ini, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 20.sp)
        }
        if (model != null) {
            AsyncImage(model = model, contentDescription = null, contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High, modifier = Modifier.fillMaxSize())
        }
    }
}

/** Reference screen 7 — Social Feed. */
@Composable
fun RefFeedScreen(onCompose: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { SocialFeedRepository.get(context) }
    val chat = remember { ChatRepository.get(context) }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var posts by remember { mutableStateOf<List<SocialPost>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    val profiles = remember { mutableStateMapOf<String, Profile>() }
    val likeCounts = remember { mutableStateMapOf<String, Int>() }
    val liked = remember { mutableStateMapOf<String, Boolean>() }
    val commentCounts = remember { mutableStateMapOf<String, Int>() }
    var commentPost by remember { mutableStateOf<SocialPost?>(null) }
    var comments by remember { mutableStateOf<List<com.texgen.music.texwave.data.chat.SocialComment>>(emptyList()) }
    var commentDraft by remember { mutableStateOf("") }
    LaunchedEffect(commentPost?.id) {
        val p = commentPost ?: return@LaunchedEffect
        comments = repo.commentsFor(p.id).getOrNull() ?: emptyList()
    }

    LaunchedEffect(Unit) {
        repo.feed().onSuccess { list ->
            posts = list.filter { it.media_type == "image" }
        }
        loaded = true
        posts.forEach { p ->
            if (profiles[p.user_id] == null) chat.getProfile(p.user_id).getOrNull()?.let { profiles[p.user_id] = it }
            repo.likesFor(p.id).onSuccess { l ->
                likeCounts[p.id] = l.size
                liked[p.id] = l.any { it.user_id == repo.myUserId() }
            }
            repo.commentsFor(p.id).onSuccess { c -> commentCounts[p.id] = c.size }
        }
    }

    commentPost?.let { cp ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { commentPost = null },
            title = { Text("Comments") },
            text = {
                Column {
                    if (comments.isEmpty()) Text("No comments yet.")
                    comments.takeLast(8).forEach { c -> Text("• " + c.body, modifier = Modifier.padding(vertical = 2.dp)) }
                    androidx.compose.material3.OutlinedTextField(
                        value = commentDraft, onValueChange = { commentDraft = it },
                        placeholder = { Text("Add a comment…") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    val body = commentDraft.trim()
                    if (body.isNotEmpty()) scope.launch {
                        repo.addComment(cp.id, body).onSuccess {
                            commentDraft = ""
                            comments = repo.commentsFor(cp.id).getOrNull() ?: comments
                            commentCounts[cp.id] = comments.size
                        }
                    }
                }) { Text("Send") }
            },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { commentPost = null }) { Text("Close") } },
        )
    }

    val friends = remember { FriendsStore.ids(context) }
    val shown = if (tab == 0) posts else posts.filter { it.user_id in friends }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) { RefWordmark(24.sp) }
                Box(
                    Modifier.size(40.dp).clip(CircleShape).border(1.5.dp, Ref.Violet, CircleShape).clickable(onClick = onCompose),
                ) { Image(painterResource(R.drawable.ref_logo_orb), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High) }
            }
            RefTabs(listOf("For You", "Following"), tab, { tab = it })
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(shown, key = { it.id }) { p ->
                    val prof = profiles[p.user_id]
                    val name = prof?.displayName ?: prof?.username ?: "Member"
                    val isLiked = liked[p.id] == true
                    PostCard(
                        name = name, avatarModel = prof?.avatarModel, avatarRes = null,
                        time = agoLabel(parseIsoMillis(p.created_at)), text = p.caption,
                        image = p.media_url, imageRes = null,
                        likes = likeCounts[p.id] ?: 0, comments = commentCounts[p.id] ?: 0, liked = isLiked,
                        onComment = { commentPost = p; commentDraft = "" },
                        onCamera = onCompose,
                        onLike = {
                            scope.launch {
                                repo.toggleLike(p.id, isLiked).onSuccess {
                                    liked[p.id] = !isLiked
                                    likeCounts[p.id] = ((likeCounts[p.id] ?: 0) + if (isLiked) -1 else 1).coerceAtLeast(0)
                                }
                            }
                        },
                        onShare = {
                            val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, p.media_url)
                            }
                            context.startActivity(android.content.Intent.createChooser(i, "Share").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                        },
                    )
                }
                if (loaded && shown.isEmpty()) {
                    item {
                        Column(
                            Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 56.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                if (tab == 0) "No posts yet" else "Nothing from friends yet",
                                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (tab == 0) "Be the first to share something. Posts from everyone on TEXWAVE show up here."
                                else "Add friends to see their posts here.",
                                color = Ref.Sub, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                            Spacer(Modifier.height(18.dp))
                            Box(
                                Modifier.clip(RoundedCornerShape(24.dp))
                                    .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Ref.Purple, Ref.Blue)))
                                    .clickable(onClick = onCompose).padding(horizontal = 26.dp, vertical = 12.dp),
                            ) { Text("Create post", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PostCard(
    name: String, avatarModel: Any?, avatarRes: Int?, time: String, text: String,
    image: String?, imageRes: Int?, likes: Int, comments: Int, liked: Boolean,
    onLike: () -> Unit, onShare: () -> Unit, onComment: () -> Unit, onCamera: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(top = 14.dp)) {
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            RingAvatar(name, avatarModel, Modifier.size(50.dp), fallbackRes = avatarRes, shapeRadius = 16.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(time, color = Ref.Sub, fontSize = 12.sp)
            }
            Icon(Icons.Rounded.CameraAlt, "New post", tint = Color(0xFFDCE5FF), modifier = Modifier.size(22.dp).clickable(onClick = onCamera))
        }
        if (text.isNotBlank()) {
            Text(text, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp))
        }
        val shape = RoundedCornerShape(14.dp)
        Box(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp).fillMaxWidth().aspectRatio(1.34f)
                .clip(shape).border(1.dp, Ref.Line, shape),
        ) {
            if (imageRes != null) Image(painterResource(imageRes), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
            if (image != null) AsyncImage(model = image, contentDescription = null, contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High, modifier = Modifier.fillMaxSize())
        }
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).clickable(onClick = onLike), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                    tint = if (liked) Ref.Magenta else Color.White, modifier = Modifier.size(24.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(countLabel(likes), color = Color.White, fontSize = 13.sp)
            }
            Row(Modifier.weight(1f).clickable(onClick = onComment), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.ChatBubbleOutline, null, tint = Color.White, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(8.dp))
                Text(countLabel(comments), color = Color.White, fontSize = 13.sp)
            }
            Row(Modifier.weight(1f).clickable(onClick = onShare), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Share, null, tint = Color.White, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(8.dp))
                Text("Share", color = Color.White, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Ref.Line.copy(alpha = 0.6f)))
    }
}

internal fun countLabel(n: Int): String = when {
    n >= 1_000_000 -> "%.1fM".format(n / 1_000_000f)
    n >= 1_000 -> "%.1fK".format(n / 1_000f)
    else -> n.toString()
}

/** Reference screen 9 — Messages (Chats · Groups · Requests). */
@Composable
fun RefMessagesScreen(
    repo: ChatRepository,
    onOpenConversation: (conversationId: String, title: String) -> Unit,
    onSearchUsers: () -> Unit,
    onCreateGroup: () -> Unit,
) {
    val context = LocalContext.current
    val convs by repo.conversations.collectAsState()
    val onlineIds by repo.onlineUserIds.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        runCatching { repo.loadConversations() }
        runCatching { com.texgen.music.texwave.data.chat.ChatKeepAliveService.start(context) }
        launch { repo.inboxEvents.collect { delay(400); runCatching { repo.loadConversations() } } }
        while (true) { delay(15_000); runCatching { repo.loadConversations() } }
    }
    LaunchedEffect(convs) { FriendsStore.syncFromConversations(context, convs) }

    val shown = when (tab) {
        0 -> convs.filter { !it.conversation.isGroup }
        1 -> convs.filter { it.conversation.isGroup }
        else -> emptyList()
    }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 18.dp, top = 14.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) { ScreenTitle("Messages") }
                Box(Modifier.clickable { if (tab == 1) onCreateGroup() else onSearchUsers() }) {
                    Icon(Icons.Rounded.Edit, "New", tint = Color.White, modifier = Modifier.size(26.dp))
                    Box(Modifier.align(Alignment.TopEnd).size(8.dp).clip(CircleShape).background(Ref.Magenta))
                }
            }
            RefTabs(listOf("Chats", "Groups", "Requests"), tab, { tab = it })
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 16.dp)) {
                if (shown.isEmpty()) {
                    item {
                        Text(
                            when (tab) {
                                0 -> "No chats yet — tap ✎ to find people."
                                1 -> "No groups yet — tap ✎ to create one."
                                else -> "No message requests."
                            },
                            color = Ref.Muted, fontSize = 14.sp, modifier = Modifier.padding(24.dp),
                        )
                    }
                }
                items(shown, key = { it.conversation.id }) { pv -> ChatRow(pv, onlineIds, onOpenConversation) }
            }
        }
    }
}

@Composable
private fun ChatRow(pv: ConversationPreview, onlineIds: Set<String>, onOpen: (String, String) -> Unit) {
    val group = pv.conversation.isGroup
    val name = if (group) pv.conversation.title ?: "Group" else pv.otherUser?.displayName ?: pv.otherUser?.username ?: "Unknown"
    val body = pv.lastMessage?.body
    val last = when {
        Resonance.isResonance(body) -> "♪ Resonance"
        body != null -> body.take(48)
        pv.lastMessage != null -> "Attachment"
        else -> if (group) "Group created" else "Tap to chat"
    }
    val online = pv.otherUser?.id?.let { it in onlineIds } == true
    val time = agoLabel(parseIsoMillis(pv.lastMessage?.createdAt)).removeSuffix(" ago")
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).refCard(18.dp)
            .clickable { onOpen(pv.conversation.id, name) }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            RingAvatar(name, pv.otherUser?.avatarModel, Modifier.size(62.dp))
            if (online) Box(Modifier.align(Alignment.BottomEnd).size(14.dp).clip(CircleShape).background(Color(0xFF28E0A0)).border(2.dp, Ref.Bg, CircleShape))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                last, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (pv.unreadCount > 0) Color.White else Ref.Sub,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(time, color = Color(0xFFDCE5FF), fontSize = 13.sp)
            if (pv.unreadCount > 0) {
                Spacer(Modifier.height(6.dp))
                Box(Modifier.size(20.dp).clip(CircleShape).background(Ref.Cyan), contentAlignment = Alignment.Center) {
                    Text(if (pv.unreadCount > 9) "9+" else pv.unreadCount.toString(), color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** Reference screen 11 — Community / Groups. */
@Composable
fun RefGroupsScreen(repo: ChatRepository, onOpenConversation: (String, String) -> Unit, onCreateGroup: () -> Unit = {}) {
    val context = LocalContext.current
    val convs by repo.conversations.collectAsState()
    LaunchedEffect(Unit) { runCatching { repo.loadConversations() } }
    val real = convs.filter { it.conversation.isGroup }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 18.dp, top = 14.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Groups", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.Add, "Create group", tint = Color.White, modifier = Modifier.size(28.dp).clickable(onClick = onCreateGroup))
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 16.dp)) {
                items(real, key = { "real_" + it.conversation.id }) { pv ->
                    val name = pv.conversation.title ?: "Group"
                    GroupRow(name, "Group chat", null, "Open", true) { onOpenConversation(pv.conversation.id, name) }
                }
                item {
                    if (real.isEmpty()) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No groups yet", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            Text("Create a group and invite friends to chat and share music.", color = Ref.Sub, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                    Box(
                        Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(24.dp))
                            .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Ref.Purple, Ref.Blue)))
                            .clickable(onClick = onCreateGroup).padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("Create a group", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
}

@Composable
private fun GroupRow(name: String, sub: String, art: Int?, action: String, filled: Boolean, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).refCard(18.dp).padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RingAvatar(name, null, Modifier.size(62.dp), fallbackRes = art ?: R.drawable.ref_grp_official, shapeRadius = 18.dp, ring = listOf(Ref.Cyan, Ref.Violet))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Ref.Sub, fontSize = 14.sp)
        }
        val s = RoundedCornerShape(22.dp)
        Box(
            Modifier.clip(s)
                .background(if (filled) Color(0xFF111B45) else Color(0xFF1A1550))
                .border(1.dp, if (filled) Ref.Line else Ref.Violet.copy(alpha = 0.5f), s)
                .clickable(onClick = onAction)
                .padding(horizontal = 22.dp, vertical = 11.dp),
            contentAlignment = Alignment.Center,
        ) { Text(action, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
    }
}
