package com.texgen.music.texwave.ui.ref

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import kotlinx.coroutines.launch

private data class Bubble(val mine: Boolean, val text: String)

/**
 * Reference screen 6 — Phantom, "Your AI Companion".
 * Chats inline through [onSend]; the full studio (images, voice, API key) stays one tap away via [onOpenStudio].
 */
@Composable
fun RefPhantomScreen(
    onBack: () -> Unit,
    onSend: suspend (text: String, history: List<Pair<String, String>>) -> Result<String>,
    onOpenStudio: () -> Unit,
    onQuickHome: () -> Unit,
    onQuickReels: () -> Unit,
    onQuickSearch: () -> Unit,
    onQuickShare: () -> Unit,
) {
    val msgs = remember { mutableStateListOf<Bubble>() }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        val history = msgs.map { (if (it.mine) "user" else "assistant") to it.text }
        msgs.add(Bubble(true, text))
        draft = ""
        busy = true
        scope.launch {
            val r = try { onSend(text, history) } catch (e: Exception) { Result.failure(e) }
            msgs.add(Bubble(false, r.getOrElse { e -> e.message ?: "Something went wrong" }.ifBlank { "…" }))
            busy = false
        }
    }
    LaunchedEffect(msgs.size, busy) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size)
    }

    val t = rememberInfiniteTransition(label = "orb")
    val spin by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart), label = "spin",
    )
    val breathe by t.animateFloat(
        0.96f, 1.04f, infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "breathe",
    )
    val chatting = msgs.isNotEmpty()

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)) {
                Box(
                    Modifier.align(Alignment.CenterStart).size(44.dp).clip(CircleShape)
                        .background(Color(0xFF0C1740)).border(1.dp, Ref.Line, CircleShape)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(22.dp)) }
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Phantom",
                        style = TextStyle(
                            brush = Brush.horizontalGradient(listOf(Color(0xFFE9DFFF), Color(0xFFB9A0FF), Color(0xFFE9DFFF))),
                            fontSize = 30.sp, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Medium,
                        ),
                    )
                    Text("Your AI Companion", color = Color.White, fontSize = 14.sp)
                }
                Icon(
                    Icons.Rounded.OpenInNew, "Open studio", tint = Ref.Muted,
                    modifier = Modifier.align(Alignment.CenterEnd).size(24.dp).clickable(onClick = onOpenStudio),
                )
            }

            if (!chatting) {
                Column(Modifier.weight(1f).padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    val shape = RoundedCornerShape(24.dp)
                    Column(
                        Modifier.fillMaxWidth().padding(top = 8.dp).clip(shape)
                            .background(Brush.verticalGradient(listOf(Color(0xFF0F1B4A), Color(0xFF0A1236))))
                            .border(1.2.dp, Brush.horizontalGradient(listOf(Ref.Violet.copy(alpha = 0.8f), Ref.Blue.copy(alpha = 0.7f))), shape)
                            .padding(20.dp),
                    ) {
                        Text("Hey ${Ref.UserName} 💜", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "I'm Phantom. Your AI companion.\nAsk me anything, create, explore,\nor just talk...",
                            color = Color.White, fontSize = 15.sp, lineHeight = 22.sp,
                        )
                    }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Image(
                            painterResource(R.drawable.ref_phantom_orb), null,
                            Modifier.fillMaxWidth(0.88f).aspectRatio(1f)
                                .graphicsLayer { scaleX = breathe; scaleY = breathe },
                            contentScale = ContentScale.Fit,
                        )
                        GlowRing(Modifier.fillMaxWidth(0.52f).aspectRatio(1f), strokeDp = 2.dp, speedMs = 7000)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Chip("Explain something", null, listOf(Ref.Violet, Ref.Purple), Modifier.weight(1.15f)) { send("Explain something interesting to me") }
                        Chip("Give me ideas", null, listOf(Ref.Blue, Ref.Violet), Modifier.weight(1f)) { send("Give me some ideas") }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Chip("Help me create", Icons.Rounded.Create, listOf(Ref.Cyan, Ref.Violet), Modifier.weight(1.1f)) { send("Help me create something") }
                        Chip("Just chat", Icons.Rounded.Chat, listOf(Ref.Cyan, Ref.Blue), Modifier.weight(1f)) { send("Hey Phantom, just chat with me") }
                    }
                    Spacer(Modifier.height(18.dp))
                }
            } else {
                Box(Modifier.size(84.dp).align(Alignment.CenterHorizontally)) {
                    Image(
                        painterResource(R.drawable.ref_phantom_orb), null,
                        Modifier.fillMaxSize().graphicsLayer { rotationZ = spin * 0f; scaleX = breathe; scaleY = breathe },
                        contentScale = ContentScale.Fit,
                    )
                }
                LazyColumn(
                    Modifier.weight(1f).padding(horizontal = 18.dp),
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(msgs.size) { i ->
                        val m = msgs[i]
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
                            val shape = RoundedCornerShape(20.dp)
                            Text(
                                m.text, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp,
                                modifier = Modifier
                                    .fillMaxWidth(0.82f)
                                    .clip(shape)
                                    .background(
                                        if (m.mine) Brush.linearGradient(listOf(Color(0xFF4A27C8), Color(0xFF253D9C)))
                                        else Brush.verticalGradient(listOf(Color(0xFF0F1B4A), Color(0xFF0A1236))),
                                    )
                                    .border(1.dp, if (m.mine) Ref.Violet.copy(alpha = 0.6f) else Ref.Line, shape)
                                    .padding(14.dp),
                                textAlign = TextAlign.Start,
                            )
                        }
                    }
                    item {
                        if (busy) Text("Phantom is thinking…", color = Ref.Muted, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp))
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }

            // Input pill with send button
            val pill = RoundedCornerShape(30.dp)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(56.dp).clip(pill)
                    .background(Brush.horizontalGradient(listOf(Color(0xFF0C1740), Color(0xFF0A1236))))
                    .border(1.2.dp, Brush.horizontalGradient(listOf(Ref.LineHi, Ref.Violet.copy(alpha = 0.6f), Ref.Cyan.copy(alpha = 0.5f))), pill)
                    .padding(start = 20.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = draft, onValueChange = { draft = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(Ref.Cyan),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (draft.isEmpty()) Text("Type a message...", color = Color(0xFF8FA0E0), fontSize = 15.sp)
                            inner()
                        }
                    },
                )
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF6B7BE0)).clickable { send(draft) },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Send, "Send", tint = Color.White, modifier = Modifier.size(22.dp)) }
            }

            // Faint 4-icon quick bar from the reference
            Row(
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 36.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                QuickIcon(Icons.Rounded.Home, onQuickHome)
                QuickIcon(Icons.Rounded.VideoLibrary, onQuickReels)
                QuickIcon(Icons.Rounded.Public, onQuickSearch)
                QuickIcon(Icons.Rounded.Share, onQuickShare)
            }
        }
    }
}

@Composable
private fun QuickIcon(icon: ImageVector, onClick: () -> Unit) {
    Icon(icon, null, tint = Ref.Faint, modifier = Modifier.size(24.dp).clickable(onClick = onClick))
}

@Composable
private fun Chip(label: String, icon: ImageVector?, colors: List<Color>, modifier: Modifier, onClick: () -> Unit) {
    val s = RoundedCornerShape(26.dp)
    Row(
        modifier.height(50.dp).clip(s)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0C1740), Color(0xFF0A1236))))
            .border(1.5.dp, Brush.horizontalGradient(colors), s)
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Ref.Cyan, modifier = Modifier.size(16.dp))
            Spacer(Modifier.size(6.dp))
        }
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}
