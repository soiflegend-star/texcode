package com.texgen.music.texwave.ui.ref

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** Reference screen 5 — Now Playing. Same parameters as the legacy player so it drops in. */
@Composable
fun RefNowPlayingScreen(
    state: PlayerState,
    position: State<Long>,
    liked: Boolean,
    artOverride: String? = null,
    playbackSpeed: Float = 1f,
    vinylMode: Boolean = false,
    onClose: () -> Unit,
    onToggleLike: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onQueue: () -> Unit,
    onSettings: () -> Unit = {},
    onEqualizer: () -> Unit = {},
    onEditor: () -> Unit = {},
    onSleepTimer: () -> Unit = {},
    onSpeed: () -> Unit = {},
    onLyrics: () -> Unit = {},
    onSeekBackward: () -> Unit = {},
    onPlaySimilar: () -> Unit = {},
    onSetImage: () -> Unit = {},
    onResetImage: () -> Unit = {},
    hasCustomCover: Boolean = false,
    onOpenSimilarScreen: () -> Unit = {},
) {
    val song = state.current ?: return
    var menu by remember { mutableStateOf(false) }
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = state.durationMs.coerceAtLeast(1L)
    val frac = (position.value.toFloat() / dur).coerceIn(0f, 1f)
    val shown = drag ?: frac

    val t = rememberInfiniteTransition(label = "np")
    val phase by t.animateFloat(
        0f, 6.2831855f,
        infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart),
        label = "wavePhase",
    )
    val pulse by t.animateFloat(
        0.985f, 1.015f,
        infiniteRepeatable(tween(1600), RepeatMode.Reverse),
        label = "pulse",
    )

    val ctx = androidx.compose.ui.platform.LocalContext.current
    val uiPrefs = remember { ctx.getSharedPreferences("texwave_ui", android.content.Context.MODE_PRIVATE) }
    var themeKey by remember { mutableStateOf(uiPrefs.getString("np_theme", "") ?: "") }
    var themeDialog by remember { mutableStateOf(false) }
    fun setTheme(k: String) { themeKey = k; uiPrefs.edit().putString("np_theme", k).apply() }
    val pickPhoto = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri: android.net.Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            val out = java.io.File(ctx.filesDir, "np_theme_${System.currentTimeMillis()}.jpg")
            ctx.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { i.copyTo(it) } }
            setTheme(out.absolutePath)
        }.onFailure { android.widget.Toast.makeText(ctx, "Could not load that picture", android.widget.Toast.LENGTH_SHORT).show() }
    }
    if (themeDialog) PlayerThemeDialog(
        current = themeKey,
        onPick = { setTheme(it); themeDialog = false },
        onGallery = { themeDialog = false; pickPhoto.launch("image/*") },
        onDismiss = { themeDialog = false },
    )

    RefBackground {
        when {
            themeKey == "art" -> {
                SongThumb(song, Modifier.fillMaxSize().graphicsLayer { alpha = 0.55f }.then(if (android.os.Build.VERSION.SDK_INT >= 31) Modifier.blur(48.dp) else Modifier), RoundedCornerShape(0.dp), artOverride = artOverride)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x9902040C), Color(0xCC02040C)))))
            }
            themeKey.isNotBlank() -> AlarmBackdrop(themeKey, scrim = 0.5f)
        }
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Top bar
            Box(Modifier.fillMaxWidth().padding(top = 12.dp).height(44.dp)) {
                Icon(
                    Icons.Rounded.KeyboardArrowDown, "Close", tint = Color.White,
                    modifier = Modifier.align(Alignment.CenterStart).size(34.dp).clickable(onClick = onClose),
                )
                Text("Now Playing", color = Color.White, fontSize = 17.sp, modifier = Modifier.align(Alignment.Center))
                Box(Modifier.align(Alignment.CenterEnd)) {
                    Icon(
                        Icons.Rounded.MoreVert, "More", tint = Color.White,
                        modifier = Modifier.size(32.dp).clickable { menu = true },
                    )
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        val items = buildList<Pair<String, () -> Unit>> {
                            add("Queue" to onQueue)
                            add("Lyrics" to onLyrics)
                            add("Equalizer" to onEqualizer)
                            add("Playback speed (${"%.2f".format(playbackSpeed)}x)" to onSpeed)
                            add("Sleep timer" to onSleepTimer)
                            add("Similar songs" to onOpenSimilarScreen)
                            add("Play similar" to onPlaySimilar)
                            add("Music editor" to onEditor)
                            add("Player theme" to { themeDialog = true })
                            add("Set cover image" to onSetImage)
                            if (hasCustomCover) add("Reset cover image" to onResetImage)
                            add("Settings" to onSettings)
                        }
                        items.forEach { (label, action) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = { menu = false; action() })
                        }
                    }
                }
            }

            Spacer(Modifier.weight(0.5f))

            // Art with glowing ring
            Box(
                Modifier.fillMaxWidth(0.86f).aspectRatio(1f),
                contentAlignment = Alignment.Center,
            ) {
                val s = if (state.isPlaying) pulse else 1f
                Box(Modifier.fillMaxSize().drawBehind {
                    drawCircle(
                        Brush.radialGradient(listOf(Ref.Blue.copy(alpha = 0.28f), Color.Transparent)),
                        radius = size.minDimension * 0.62f,
                    )
                })
                GlowRing(Modifier.fillMaxSize(), strokeDp = 3.dp, speedMs = 12000)
                SongThumb(
                    song,
                    Modifier.fillMaxSize().padding(16.dp).graphicsLayer { scaleX = s; scaleY = s },
                    CircleShape,
                    fallback = R.drawable.ref_np_art,
                    artOverride = artOverride,
                    hiRes = 1200,
                )
            }

            Spacer(Modifier.weight(0.4f))

            Text(
                song.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                song.artist, color = Ref.Cyan, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )

            Spacer(Modifier.height(18.dp))
            Waveform(
                seed = song.id, progress = shown, phase = if (state.isPlaying) phase else 0f,
                modifier = Modifier.fillMaxWidth().height(64.dp),
            )
            Spacer(Modifier.height(10.dp))
            Slider(
                value = shown,
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
                colors = SliderDefaults.colors(
                    thumbColor = Ref.Cyan,
                    activeTrackColor = Ref.Cyan,
                    inactiveTrackColor = Color(0xFF14224F),
                ),
                modifier = Modifier.fillMaxWidth().height(24.dp),
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmt((shown * dur).toLong()), color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text(fmt(state.durationMs), color = Color.White, fontSize = 12.sp)
            }

            Spacer(Modifier.height(22.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Rounded.Shuffle, "Shuffle",
                    tint = if (state.shuffle) Ref.Cyan else Ref.Violet,
                    modifier = Modifier.size(28.dp).clickable(onClick = onShuffle),
                )
                Icon(
                    Icons.Rounded.SkipPrevious, "Previous", tint = Color.White,
                    modifier = Modifier.size(44.dp).clickable(onClick = onPrevious),
                )
                Box(
                    Modifier
                        .size(78.dp)
                        .drawBehind {
                            drawCircle(
                                Brush.radialGradient(listOf(Ref.Violet.copy(alpha = 0.35f), Color.Transparent)),
                                radius = size.minDimension * 0.85f,
                            )
                        }
                        .clip(CircleShape)
                        .background(Color(0xFF0E0A2E))
                        .border(2.dp, Brush.linearGradient(listOf(Ref.Purple, Ref.Violet, Ref.Blue)), CircleShape)
                        .clickable(onClick = onToggle),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(40.dp),
                    )
                }
                Icon(
                    Icons.Rounded.SkipNext, "Next", tint = Color.White,
                    modifier = Modifier.size(44.dp).clickable(onClick = onNext),
                )
                Icon(
                    if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Like",
                    tint = if (liked) Ref.Magenta else Color(0xFF3DE0D0),
                    modifier = Modifier.size(28.dp).clickable(onClick = onToggleLike),
                )
            }

            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 36.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Icon(Icons.Rounded.Undo, "Back", tint = Ref.Faint, modifier = Modifier.size(22.dp).clickable(onClick = onSeekBackward))
                Icon(
                    if (state.repeatMode == androidx.media3.common.Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repeat",
                    tint = if (state.repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) Ref.Violet else Ref.Faint,
                    modifier = Modifier.size(22.dp).clickable(onClick = onRepeat),
                )
                Icon(Icons.Rounded.QueueMusic, "Queue", tint = Ref.Faint, modifier = Modifier.size(22.dp).clickable(onClick = onQueue))
            }
            Spacer(Modifier.weight(0.3f))
        }
    }
}

@Composable
private fun Waveform(seed: Long, progress: Float, phase: Float, modifier: Modifier = Modifier) {
    val bars = 58
    Canvas(modifier) {
        val gap = size.width / bars
        val w = 3.dp.toPx()
        val sd = (seed % 97).toFloat()
        val brush = Brush.horizontalGradient(
            listOf(Ref.Blue, Ref.Cyan, Ref.Blue, Ref.Violet, Ref.Magenta.copy(alpha = 0.85f)),
        )
        for (i in 0 until bars) {
            val x = gap * (i + 0.5f)
            val env = 0.35f + 0.65f * (1f - abs(i - bars / 2f) / (bars / 2f))
            val raw = abs(sin(i * 0.45f + sd + phase) * cos(i * 0.17f + sd * 0.7f - phase * 0.5f))
            val h = (0.12f + 0.88f * raw * env) * size.height
            val lit = (i + 0.5f) / bars <= progress || progress <= 0.001f
            drawLine(
                brush = brush,
                start = Offset(x, size.height / 2f - h / 2f),
                end = Offset(x, size.height / 2f + h / 2f),
                strokeWidth = w,
                cap = StrokeCap.Round,
                alpha = if (lit) 1f else 0.45f,
            )
        }
    }
}


@Composable
private fun PlayerThemeDialog(current: String, onPick: (String) -> Unit, onGallery: () -> Unit, onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF0A1236)).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Player theme", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("Pick the picture behind your player", color = Ref.Sub, fontSize = 13.sp)
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item { ThemeChip("Default", null, current.isBlank()) { onPick("") } }
                item { ThemeChip("Album art", null, current == "art") { onPick("art") } }
                items(AlarmPresets.size) { i ->
                    val p = AlarmPresets[i]
                    ThemeChip(p.label, p.res, current == "preset:" + p.id) { onPick("preset:" + p.id) }
                }
                item { ThemeChip("My photo", null, current.startsWith("/"), onGallery) }
            }
        }
    }
}

@Composable
private fun ThemeChip(label: String, res: Int?, selected: Boolean, onClick: () -> Unit) {
    val s = RoundedCornerShape(16.dp)
    Column(Modifier.width(78.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(78.dp, 100.dp).clip(s).background(Color(0xFF111B45))
                .border(if (selected) 2.5.dp else 1.dp, if (selected) Ref.Cyan else Ref.Line, s),
            contentAlignment = Alignment.Center,
        ) {
            if (res != null) Image(painterResource(res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
            else Text(if (label == "My photo") "+" else if (label == "Album art") "♪" else "○", color = Color.White, fontSize = 26.sp)
        }
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
    }
}
