package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Playlist
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState

private val tabs = listOf("Songs", "Albums", "Artists", "Playlists")

/** Reference pill search field. */
@Composable
fun RefSearchField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    height: androidx.compose.ui.unit.Dp = 46.dp,
    textSize: androidx.compose.ui.unit.TextUnit = 14.sp,
) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0C1740), Color(0xFF0A1236))))
            .border(1.2.dp, Brush.horizontalGradient(listOf(Ref.LineHi, Ref.Violet.copy(alpha = 0.6f), Ref.LineHi)), shape)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, null, tint = Color(0xFFCFD9FF), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = textSize),
            cursorBrush = SolidColor(Ref.Cyan),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(placeholder, color = Color(0xFF6F86C8), fontSize = textSize)
                    inner()
                }
            },
        )
    }
}

/** Reference screen 3 — Library (Songs · Albums · Artists · Playlists). */
@Composable
fun RefLibraryScreen(
    lib: LibraryState,
    player: PlayerState,
    initialTab: Int = 0,
    onPlay: (List<Song>, Int) -> Unit,
    onMore: (Song) -> Unit,
    onOpenPlaylist: (Playlist) -> Unit,
    onNewPlaylist: () -> Unit,
    onSearch: () -> Unit,
    onProfile: () -> Unit,
) {
    var tab by rememberSaveable { mutableIntStateOf(initialTab.coerceIn(0, 3)) }
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim().lowercase()

    val songs = remember(lib.songs, q) {
        if (q.isEmpty()) lib.songs
        else lib.songs.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q) }
    }
    val albums = remember(lib.songs, q) {
        lib.songs.groupBy { it.albumId }.values
            .map { it to it.first() }
            .filter { (_, f) -> q.isEmpty() || f.album.lowercase().contains(q) || f.artist.lowercase().contains(q) }
            .sortedBy { it.second.album.lowercase() }
    }
    val artists = remember(lib.songs, q) {
        lib.songs.groupBy { it.artist }.entries
            .filter { q.isEmpty() || it.key.lowercase().contains(q) }
            .sortedBy { it.key.lowercase() }
    }
    val playlists = remember(lib.playlists, q) {
        lib.playlists.filter { q.isEmpty() || it.name.lowercase().contains(q) }
    }

    RefBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) { ScreenTitle("Library") }
                IconCircle(Icons.Rounded.Search, onSearch)
                Spacer(Modifier.width(8.dp))
                IconCircle(Icons.Rounded.Person, onProfile)
            }
            Row(Modifier.fillMaxWidth().padding(top = 14.dp, start = 12.dp, end = 12.dp)) {
                tabs.forEachIndexed { i, t ->
                    val on = i == tab
                    Column(
                        Modifier.weight(1f).clickable { tab = i }.padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            t, fontSize = 16.sp,
                            color = if (on) Ref.Lavender else Color.White,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                        )
                        Spacer(Modifier.height(6.dp))
                        Box(
                            Modifier.height(2.dp).fillMaxWidth(0.8f)
                                .background(if (on) Brush.horizontalGradient(listOf(Ref.Cyan, Ref.Blue)) else SolidColor(Color.Transparent)),
                        )
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Ref.Line.copy(alpha = 0.7f)))
            RefSearchField(
                value = query, onChange = { query = it },
                placeholder = "Search songs, artists, albums...",
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                height = 44.dp, textSize = 13.sp,
            )
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 12.dp, bottom = 16.dp)) {
                when (tab) {
                    0 -> itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                        val playing = player.current?.id == s.id
                        RefRow(
                            title = s.title, subtitle = s.artist, card = false, thumbBorder = playing,
                            modifier = Modifier.padding(vertical = 4.dp),
                            onChevron = { onMore(s) },
                            onClick = { onPlay(songs, i) },
                        ) { SongThumb(s, Modifier.size(58.dp), RoundedCornerShape(14.dp)) }
                    }
                    1 -> itemsIndexed(albums, key = { _, a -> a.second.albumId }) { _, a ->
                        val list = a.first
                        RefRow(
                            title = a.second.album, subtitle = "${a.second.artist} • ${list.size} songs", card = false,
                            modifier = Modifier.padding(vertical = 4.dp),
                            onClick = { onPlay(list, 0) },
                        ) { SongThumb(a.second, Modifier.size(58.dp), RoundedCornerShape(14.dp)) }
                    }
                    2 -> itemsIndexed(artists, key = { _, a -> a.key }) { _, a ->
                        RefRow(
                            title = a.key, subtitle = "${a.value.size} songs", card = false,
                            modifier = Modifier.padding(vertical = 4.dp),
                            onClick = { onPlay(a.value, 0) },
                        ) { InitialsAvatar(a.key, Modifier.size(58.dp)) }
                    }
                    else -> {
                        item {
                            RefRow(
                                title = "New playlist", subtitle = "Create a collection", card = true,
                                modifier = Modifier.padding(vertical = 6.dp), onClick = onNewPlaylist,
                            ) {
                                Box(
                                    Modifier.size(58.dp).clip(RoundedCornerShape(14.dp))
                                        .background(Brush.linearGradient(listOf(Ref.Purple.copy(alpha = 0.6f), Ref.Blue.copy(alpha = 0.4f)))),
                                    contentAlignment = Alignment.Center,
                                ) { Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
                            }
                        }
                        itemsIndexed(playlists, key = { _, p -> p.id }) { _, p ->
                            val first = lib.songs.firstOrNull { it.id == p.songIds.firstOrNull() }
                            RefRow(
                                title = p.name, subtitle = "Playlist • ${p.songIds.size} songs", card = false,
                                modifier = Modifier.padding(vertical = 4.dp),
                                onClick = { onOpenPlaylist(p) },
                            ) { SongThumb(first, Modifier.size(58.dp), RoundedCornerShape(14.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IconCircle(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
}
