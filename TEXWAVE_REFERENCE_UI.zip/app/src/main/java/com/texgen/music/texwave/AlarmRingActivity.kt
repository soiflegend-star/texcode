package com.texgen.music.texwave

import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.Manifest
import android.content.pm.PackageManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlarmOff
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Send
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.material.icons.rounded.Snooze
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.GroqClient
import com.texgen.music.texwave.util.SpeechOut
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Full-screen alarm experience. Shows over lock screen, plays sound,
 * lets user snooze/dismiss, and talk to TEXWAVE like a human.
 */
class AlarmRingActivity : ComponentActivity() {

    companion object {
        const val EXTRA_ALARM_ID = "alarm_id"
        const val EXTRA_LABEL = "alarm_label"
        const val EXTRA_SOUND = "alarm_sound"
        const val EXTRA_BRIEFING = "alarm_briefing"

        /** Latest briefing written by the receiver so a already-open ring screen can pick it up. */
        @Volatile
        var pendingBriefing: String? = null

        @Volatile
        var activePlayer: MediaPlayer? = null

        fun stopAlarmSound() {
            runCatching {
                activePlayer?.stop()
                activePlayer?.release()
            }
            activePlayer = null
        }

        fun duckAlarmSound(level: Float = 0.15f) {
            runCatching { activePlayer?.setVolume(level, level) }
        }

        fun unduckAlarmSound() {
            runCatching { activePlayer?.setVolume(1f, 1f) }
        }
    }

    private var speech: SpeechOut? = null
    private var vibrator: Vibrator? = null
    private var briefingSpoken = false
    private val liveBriefing = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show over lock screen / turn screen on
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(KeyguardManager::class.java)
            km?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val alarmId = intent.getIntExtra(EXTRA_ALARM_ID, 0)
        val label = intent.getStringExtra(EXTRA_LABEL) ?: "TEXWAVE Alarm"
        val soundExtra = intent.getStringExtra(EXTRA_SOUND).orEmpty()
        val briefing = intent.getStringExtra(EXTRA_BRIEFING).orEmpty()
            .ifBlank { pendingBriefing.orEmpty() }
            .ifBlank { "Your TEXWAVE alarm is ringing. $label. Time to wake up." }
        liveBriefing.value = briefing
        pendingBriefing = briefing

        // Keep notification briefly so OEM full-screen paths can attach; cancel shortly after UI up
        window.decorView.postDelayed({
            try {
                (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(alarmId)
            } catch (_: Exception) {
            }
        }, 2500)

        if (soundExtra != "silent") startAlarmSound(soundExtra)
        startVibrate()
        val themeKey = getSharedPreferences("texwave_alarms", MODE_PRIVATE)
            .getString("theme_$alarmId", com.texgen.music.texwave.ui.ref.DefaultAlarmTheme)

        speech = SpeechOut(this, audioUsage = android.media.AudioAttributes.USAGE_ALARM)
        // Immediate spoken fallback — do not wait only on delayed briefing
        window.decorView.postDelayed({
            val line = liveBriefing.value.ifBlank { "Your TEXWAVE alarm is ringing." }
            speech?.speak(line)
        }, 700)

        setContent {
            val currentBriefing by liveBriefing
            AlarmRingScreen(
                themeKey = themeKey,
                label = label,
                briefing = currentBriefing,
                onSnooze = { minutes ->
                    stopEverything()
                    scheduleSnooze(alarmId, label, soundExtra, minutes)
                    finish()
                },
                onDismiss = {
                    stopEverything()
                    finish()
                },
                onAsk = { question, onReply ->
                    handleAsk(question, onReply)
                },
                speak = { text -> speech?.speak(text) },
            )
        }

        // Speak briefing after a short delay so TTS is ready
        scheduleBriefingSpeak(briefing)

        // If receiver finishes weather after we opened, poll pending briefly
        window.decorView.postDelayed({
            val late = pendingBriefing
            if (!late.isNullOrBlank() && liveBriefing.value.isBlank()) {
                liveBriefing.value = late
                scheduleBriefingSpeak(late)
            }
        }, 1800)
        window.decorView.postDelayed({
            val late = pendingBriefing
            if (!late.isNullOrBlank() && liveBriefing.value != late) {
                liveBriefing.value = late
                scheduleBriefingSpeak(late)
            }
        }, 3500)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val briefing = intent.getStringExtra(EXTRA_BRIEFING).orEmpty()
            .ifBlank { pendingBriefing.orEmpty() }
        if (briefing.isNotBlank()) {
            liveBriefing.value = briefing
            scheduleBriefingSpeak(briefing)
        }
    }

    private fun scheduleBriefingSpeak(text: String) {
        if (text.isBlank()) return
        // Retry TTS — engine often needs 1–2s after Activity create
        val delays = longArrayOf(600L, 1400L, 2800L)
        delays.forEachIndexed { i, d ->
            window.decorView.postDelayed({
                if (i == 0 || !briefingSpoken) {
                    speech?.speak(text)
                    briefingSpoken = true
                }
            }, d)
        }
    }

    private fun startAlarmSound(soundExtra: String) {
        stopAlarmSound()
        val soundUri: Uri = when {
            soundExtra.isNotBlank() -> Uri.parse(soundExtra)
            else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: return
        }
        try {
            val mp = MediaPlayer().apply {
                setDataSource(this@AlarmRingActivity, soundUri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build(),
                )
                isLooping = true
                prepare()
                start()
            }
            activePlayer = mp
        } catch (_: Exception) {
            // fallback: system ringtone via notification already played
        }
    }

    private fun startVibrate() {
        try {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as? Vibrator
            }
            vibrator?.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 600, 300, 600, 300, 600), 0),
            )
        } catch (_: Exception) {
        }
    }

    private fun stopEverything() {
        stopAlarmSound()
        try {
            vibrator?.cancel()
        } catch (_: Exception) {
        }
        speech?.stop()
    }

    private fun scheduleSnooze(id: Int, label: String, sound: String, minutes: Int) {
        val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
        val trigger = System.currentTimeMillis() + minutes * 60_000L
        val intent = Intent(this, com.texgen.music.texwave.notification.TexwaveAlarmReceiver::class.java).apply {
            putExtra("alarm_id", id)
            putExtra("alarm_label", "$label (snoozed)")
            putExtra("alarm_sound", sound)
        }
        val pi = android.app.PendingIntent.getBroadcast(
            this, id + 50_000, intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE,
        )
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, trigger, pi)
            } else {
                am.setExact(android.app.AlarmManager.RTC_WAKEUP, trigger, pi)
            }
        } catch (_: Exception) {
            am.set(android.app.AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    private fun handleAsk(question: String, onReply: (String) -> Unit) {
        val client = GroqClient(this)
        val scope = kotlinx.coroutines.CoroutineScope(Dispatchers.Main)
        scope.launch {
            val reply = withContext(Dispatchers.IO) {
                if (client.hasKey()) {
                    client.chat(
                        system = """You are TEXWAVE, a warm, helpful morning companion inside an alarm clock.
Be concise (2-4 short sentences), friendly, and human. Current time context: alarm just rang.
Help with anything: weather chat, motivation, jokes, reminders, or just conversation.
Never say you are an AI unless asked.""",
                        user = question,
                        temperature = 0.7,
                        maxTokens = 220,
                    ).getOrElse { "I'm here with you. $it".take(120).ifBlank { "I'm listening — try again in a moment." } }
                } else {
                    // Offline fallback
                    when {
                        question.contains("weather", true) -> "I couldn't reach the sky right now, but the day is yours either way."
                        question.contains("time", true) -> {
                            val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Calendar.getInstance().time)
                            "It's $t. You've got this."
                        }
                        question.contains("joke", true) -> "Why did the alarm go to therapy? It had too many unresolved issues… every morning."
                        else -> "Good morning. I'm TEXWAVE — set a Groq key in Settings for full chat, or just breathe and start the day."
                    }
                }
            }
            onReply(reply)
            speech?.speak(reply)
        }
    }

    override fun onDestroy() {
        stopEverything()
        speech?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun AlarmRingScreen(
    themeKey: String?,
    label: String,
    briefing: String,
    onSnooze: (Int) -> Unit,
    onDismiss: () -> Unit,
    onAsk: (String, (String) -> Unit) -> Unit,
    speak: (String) -> Unit,
) {
    val context = LocalContext.current
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse),
        label = "glow",
    )
    val micPulse by pulse.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "micPulse",
    )
    var input by remember { mutableStateOf("") }
    val chat = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var thinking by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var voiceStatus by remember { mutableStateOf("Tap the mic for morning talk") }
    val scope = rememberCoroutineScope()

    val timeStr = remember {
        SimpleDateFormat("h:mm", Locale.getDefault()).format(Calendar.getInstance().time)
    }
    val amPm = remember {
        SimpleDateFormat("a", Locale.getDefault()).format(Calendar.getInstance().time)
    }
    val dateStr = remember {
        SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Calendar.getInstance().time)
    }

    fun submitQuestion(q: String) {
        val cleaned = q.trim()
        if (cleaned.isEmpty() || thinking) return
        chat.add(true to cleaned)
        input = ""
        thinking = true
        voiceStatus = "Thinking…"
        AlarmRingActivity.duckAlarmSound(0.12f)
        onAsk(cleaned) { reply ->
            thinking = false
            chat.add(false to reply)
            voiceStatus = "Tap mic to talk again"
            // keep ducked while TTS plays, then unduck
            android.os.Handler(context.mainLooper).postDelayed({
                AlarmRingActivity.unduckAlarmSound()
            }, 4000)
        }
    }

    val recognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    DisposableEffect(Unit) {
        val listener = object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {
                listening = true
                voiceStatus = "Listening…"
                AlarmRingActivity.duckAlarmSound(0.08f)
            }
            override fun onBeginningOfSpeech() { voiceStatus = "Hearing you…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                listening = false
                voiceStatus = "Processing…"
            }
            override fun onError(error: Int) {
                listening = false
                voiceStatus = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that — try again"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission needed"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network needed for voice"
                    else -> "Voice error — type below"
                }
                AlarmRingActivity.unduckAlarmSound()
            }
            override fun onResults(results: android.os.Bundle?) {
                listening = false
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) {
                    voiceStatus = "You said: $text"
                    submitQuestion(text)
                } else {
                    voiceStatus = "No words recognized"
                    AlarmRingActivity.unduckAlarmSound()
                }
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!text.isNullOrBlank()) voiceStatus = text
            }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        }
        recognizer?.setRecognitionListener(listener)
        onDispose {
            runCatching {
                recognizer?.cancel()
                recognizer?.destroy()
            }
        }
    }

    fun startListening() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) {
            voiceStatus = "Allow microphone…"
            runCatching {
                (context as? android.app.Activity)?.requestPermissions(
                    arrayOf(Manifest.permission.RECORD_AUDIO),
                    9911,
                )
            }
            return
        }
        if (recognizer == null) {
            voiceStatus = "Voice recognition not available on this device"
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Good morning — talk to TEXWAVE")
        }
        runCatching {
            recognizer.startListening(intent)
            listening = true
            voiceStatus = "Listening…"
            AlarmRingActivity.duckAlarmSound(0.08f)
        }.onFailure {
            voiceStatus = "Could not start mic"
            AlarmRingActivity.unduckAlarmSound()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        com.texgen.music.texwave.ui.ref.AlarmBackdrop(themeKey, scrim = 0.6f)
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 60.dp)
                .size(240.dp)
                .background(
                    Brush.radialGradient(listOf(Color(0xFF2FE6FF).copy(alpha = glow * 0.25f), Color.Transparent)),
                    CircleShape,
                ),
        )
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 100.dp, end = 10.dp)
                .size(180.dp)
                .background(
                    Brush.radialGradient(listOf(Color(0xFF7B5CFF).copy(alpha = glow * 0.2f), Color.Transparent)),
                    CircleShape,
                ),
        )

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(28.dp))
            Text(dateStr, color = Color(0xFF9AA3C2), fontSize = 14.sp, letterSpacing = 1.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(timeStr, color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Light)
                Text(amPm, color = Color(0xFF2FE6FF), fontSize = 20.sp, modifier = Modifier.padding(bottom = 14.dp, start = 8.dp))
            }
            Text(label, color = Color(0xFFE8E4FF), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            if (briefing.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    briefing,
                    color = Color(0xFFB8C0E0),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x14FFFFFF))
                        .padding(12.dp),
                )
            }

            Spacer(Modifier.height(12.dp))
            // Big mic
            Box(
                Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(
                        if (listening) Color(0xFF2FE6FF) else Color(0xFF1A1430),
                    )
                    .border(
                        2.dp,
                        if (listening) Color.White else Color(0xFF7B5CFF),
                        CircleShape,
                    )
                    .clickable {
                        if (listening) {
                            recognizer?.stopListening()
                            listening = false
                        } else startListening()
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (listening) Icons.Rounded.Mic else Icons.Rounded.Mic,
                    contentDescription = "Morning voice",
                    tint = if (listening) Color.Black else Color(0xFF2FE6FF),
                    modifier = Modifier.size(40.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(voiceStatus, color = Color(0xFF9AA3C2), fontSize = 12.sp, textAlign = TextAlign.Center)

            Spacer(Modifier.height(12.dp))
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                chat.forEach { (mine, text) ->
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (mine) Color(0x332FE6FF) else Color(0x22FFFFFF))
                            .padding(12.dp),
                    ) {
                        Text(text, color = Color.White, fontSize = 14.sp)
                    }
                }
                if (thinking) {
                    Text("TEXWAVE is thinking…", color = Color(0xFF2FE6FF), fontSize = 13.sp)
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0x14FFFFFF))
                    .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(28.dp))
                    .padding(horizontal = 12.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { if (!listening) startListening() else recognizer?.stopListening() }) {
                    Icon(
                        if (listening) Icons.Rounded.Mic else Icons.Rounded.Mic,
                        null,
                        tint = if (listening) Color(0xFFFF6B8A) else Color(0xFF2FE6FF),
                    )
                }
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(Color(0xFF2FE6FF)),
                    singleLine = true,
                    decorationBox = { inner ->
                        if (input.isEmpty()) {
                            Text("Or type to TEXWAVE…", color = Color(0xFF6B7390), fontSize = 15.sp)
                        }
                        inner()
                    },
                )
                IconButton(
                    onClick = { submitQuestion(input) },
                ) {
                    Icon(Icons.Rounded.Send, null, tint = Color(0xFF2FE6FF))
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .background(Color(0x227B5CFF))
                            .border(1.5.dp, Color(0xFF7B5CFF), CircleShape)
                            .clickable { onSnooze(5) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Snooze, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Text("Snooze 5m", color = Color(0xFF9AA3C2), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .background(Color(0x33FF4D6A))
                            .border(1.5.dp, Color(0xFFFF4D6A), CircleShape)
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.AlarmOff, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Text("Dismiss", color = Color(0xFF9AA3C2), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}
