# TEXWAVE – 12-screen reference UI

New code: app/src/main/java/com/texgen/music/texwave/ui/ref/ (RefKit, RefChrome, RefHome, RefLibrary, RefSearch,
RefNowPlaying, RefPhantom, RefSplash, RefSocial, RefProfileSettings). Reels restyled in place. MusicApp.kt rewired.

Artwork (res/drawable-nodpi/ref_*.png) was cut from the reference image at its native ~190px/phone resolution.
To sharpen: replace any ref_*.png with a higher-res file of the same name.

Bottom bar: Home | Library | orb (Now Playing) | Phantom | More. "More" opens every other screen
(Search, Feed, Reels, Messages, Groups, Profile, Settings, Equalizer, Alarms, Downloads, Explore, Phantom Lab, All features).

NOT compiled: no Android SDK/Maven access in the build sandbox. Syntax-checked only. Build with ./gradlew assembleDebug.
Old screens kept: legacy Library sessions (More > All features), legacy Settings (rows in new Settings), MyProfile editor (Edit Profile), Phantom Lab.

## Button wiring (all real)
Home: shuffle, hero, rows. Library: tabs/filter/more/new playlist. Search: filters, See All, clear, mixes.
Now Playing: seek, transport, like, menu (queue, lyrics, EQ, speed, sleep, editor, cover).
Phantom: chips + input -> real assistant. Feed: like/comment/share/compose. Reels: like/next/share/follow.
Messages: live Supabase chats. Groups: real group chats + create. Profile: highlights navigate, Edit Profile.
Settings: Notifications/Appearance/Music/Phantom deep-link into real settings; Privacy opens Android app permissions;
Storage clears cache; About dialog.
