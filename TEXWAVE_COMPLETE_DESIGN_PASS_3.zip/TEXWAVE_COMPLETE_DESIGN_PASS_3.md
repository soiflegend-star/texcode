# TEXWAVE Complete Design Pass 3

## Design target
Use the supplied TEXWAVE reference as the visual target: near-black cinematic backgrounds, electric cyan + violet + magenta accents, restrained glass panels, readable typography, constellation/portal artwork, and one coherent visual language across music, library, Phantom, search, and social surfaces.

## Source-level changes in this pass
- Unified the runtime palette in `ui/theme/Theme.kt` and static layout tokens in `ui/theme/DesignTokens.kt` around near-black, electric cyan, violet, and magenta.
- Refined shared page chrome in `ui/theme/ScreenChrome.kt`: page inset, title hierarchy, and card surface gradient.
- Refined shared screen headers in `ui/components/CosmicParts.kt` for more consistent alignment and title/subtitle hierarchy.
- Tuned the floating navigation dock in `ui/components/TexNavBar.kt` toward a quieter glass surface and a more consistent accent border, retaining its destinations and callbacks.
- Updated `ui/components/Components.kt` song rows with a clearer current-track treatment and subtle resting surface while preserving row callbacks and song metadata.
- Added a fine gradient media edge and tightened vertical rhythm in `ui/components/FeedComponents.kt` without changing post actions or media aspect ratio.
- Refined the Home hero copy, typography, and dimensions in `ui/screens/HomeScreen.kt`; retained existing artwork, play/shuffle callback, and data-driven sections.
- Aligned hard-coded brand accents in Library, Phantom, Search and other UI screens with the shared palette.

## Scope and verification
- Existing Android project retained; this is not a replacement mock app.
- Existing screen routes, player controls, and social action callbacks were not intentionally removed.
- ZIP archive integrity is checked with `unzip -t`.
- An Android debug build could not be verified in this environment: the Gradle wrapper needs Gradle 8.5 from `services.gradle.org`, but DNS/network access failed before Gradle configuration began. Therefore this package is **not APK/build verified**.
- Visual match is not claimed to be pixel-perfect. A final device-side pass still needs screenshots from a successful build and fixes based on those screenshots, especially for responsive sizing and any screen-specific edge cases.
