# TEXWAVE Ultra-Luxury UI — Reference Reconstruction Pass

## What changed in this source package

This pass works inside the existing Android project and keeps its feature wiring rather than replacing the app with a static mockup.

- **Home:** the lead Moodwave card now uses the project's supplied `portal_universe` artwork as a full-bleed hero, with a dark cinematic gradient, restrained brand edge, editorial copy, and a clear shuffle/entry action.
- **Now Playing:** retained the existing full-screen player architecture, circular artwork, animated orbit rings, reactive waveform, seek control, transport controls, lyrics, and similar-song actions. The palette now aligns with the darker luxury direction.
- **Library:** kept the real song/album/artist/playlist model and the existing interactive constellation view as the main library experience, with the shared header refined to title case and calmer typography.
- **Phantom:** the animated companion orb now uses the existing Phantom figure artwork, surrounded by the existing orbit/glow animation; memory and listening-insight functionality remains wired to the real app state.
- **Shared UI:** refined common screen-header typography and harmonized the global ink/violet/cyan palette. The app's navigation and feature code are retained.

## Design direction

Near-black ink backgrounds, dark glass surfaces, thin low-contrast borders, restrained violet/cyan illumination, generous rounded corners, editorial typography, full-bleed atmospheric artwork, and motion used to guide attention rather than decorate every element.

## Important accuracy statement

This is a source-level implementation pass inspired by the supplied reference image, **not a claim of literal pixel identity**. The reference is a flattened concept image, not original layout source/Figma or a full asset pack; exact typography, geometry, and every screen's artwork cannot be guaranteed identical from that alone. The source contains many other social/chat/settings screens that would need device-by-device visual QA for a genuinely complete all-screen match.

## Build verification

`./gradlew assembleDebug --offline` was attempted. It could not run because the Gradle wrapper tried to fetch Gradle 8.5 from `services.gradle.org`, and network/DNS access was unavailable (`UnknownHostException`). No APK or successful compile is claimed. Build and test on an Android environment with Gradle 8.5 available before release.
