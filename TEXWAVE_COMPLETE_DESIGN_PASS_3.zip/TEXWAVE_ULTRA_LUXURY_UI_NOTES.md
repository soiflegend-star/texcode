# TEXWAVE Ultra-Luxury UI pass

This pass updates the existing Android Compose project rather than introducing a mock app.

## Design direction
- Obsidian-black foundation with deep midnight-blue surfaces.
- Electric cyan and controlled violet for interaction; magenta is a rare highlight, not a rainbow wash.
- More restrained ambient lighting and star density so content remains legible and premium.
- Unified uppercase screen headers, smaller tracking-rich subtitles, and quieter glass-card edges.
- Home hero copy follows the supplied “The Universe Awaits” concept.
- Existing screen destinations, player callbacks, library state, and navigation wiring are intentionally preserved.

## Important scope note
This is a source-level visual pass across shared design tokens and reusable UI chrome, with targeted Home changes. It does not claim pixel-perfect implementation of every reference screenshot, and no successful Android build is claimed. The next implementation pass should individually reconstruct Home, Now Playing, Library constellation, Phantom memory, and then the social/chat surfaces against the reference.
