package com.texgen.music.texwave.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Shadow
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.alpha
import com.texgen.music.texwave.ui.components.WaveBars
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable
import com.texgen.music.texwave.ui.components.rememberUiSound
import com.texgen.music.texwave.util.UiSound
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.State
import kotlin.math.sin
import com.texgen.music.texwave.ui.components.ParticleField
import com.texgen.music.texwave.ui.components.TwinkleField
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.geometry.Offset
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.components.Artwork
import com.texgen.music.texwave.ui.components.WaterFlowVisualizer
import com.texgen.music.texwave.ui.components.rememberMusicHardness
import com.texgen.music.texwave.ui.theme.Tx
import com.texgen.music.texwave.ui.theme.seedColors
import com.texgen.music.texwave.util.formatDuration
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.YoutubeDiscover
import androidx.compose.ui.platform.LocalContext

@Composable
fun NowPlayingScreen(
    state: PlayerState,
    position: State<Long>,
    liked: Boolean,
    artOverride: String? = null,
    playbackSpeed: Float = 1f,
    vinylMode: Boolean = false,
    onClose: () -> Unit,
    onToggleLike: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onQueue: () -> Unit,
    onSettings: () -> Unit = {},
    onEqualizer: () -> Unit = {},
    onEditor: () -> Unit = {},
    onSleepTimer: () -> Unit = {},
    onSpeed: () -> Unit = {},
    onLyrics: () -> Unit = {},
    onToggleVinyl: () -> Unit = {},
    onSeekForward: () -> Unit = {},
    onSeekBackward: () -> Unit = {},
    onPlaySimilar: () -> Unit = {},
    onSetImage: () -> Unit = {},
    onResetImage: () -> Unit = {},
    hasCustomCover: Boolean = false,
    particles: Boolean = true,
    reactiveViz: Boolean = false,
    audioSessionId: Int = 0,
    playerBackgroundUri: String? = null,
    similarSongs: List<Song> = emptyList(),
    onPlaySimilarSong: (Song) -> Unit = {},
    onOpenSimilarScreen: () -> Unit = {},
) {
    val song = state.current ?: return
    val sound = rememberUiSound()
    val hardness = rememberMusicHardness(audioSessionId = audioSessionId, active = state.isPlaying, enabled = reactiveViz)
    val tint by animateColorAsState(
        remember(song.album) { seedColors(song.album).first }.copy(alpha = 0.34f).compositeOver(Tx.Bg),
        label = "tint",
    )
    val artScale by animateFloatAsState(if (state.isPlaying) 1f else 0.93f, spring(dampingRatio = 0.65f), label = "artScale")

    val infinite = rememberInfiniteTransition(label = "np")
    val rotation = infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "rot")
    val ringSpin = infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "ringSpin")
    val glow = infinite.animateFloat(
        0.35f, 0.9f,
        infiniteRepeatable(tween(1800), androidx.compose.animation.core.RepeatMode.Reverse),
        label = "glow",
    )
    var coverMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var swipeAcc by remember { mutableFloatStateOf(0f) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.5f), Color(0xFF03050A), Color(0xFF010204))))
            .sonicAtmosphere(opaque = false)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        when {
                            swipeAcc < -80f -> { sound(UiSound.Kind.TAP); onNext() }
                            swipeAcc > 80f -> { sound(UiSound.Kind.TAP); onPrevious() }
                        }
                        swipeAcc = 0f
                    },
                    onHorizontalDrag = { _, dx -> swipeAcc += dx },
                )
            }
    ) {
        // High-quality gallery background theme (full-bleed, premium dark overlay)
        if (!playerBackgroundUri.isNullOrBlank()) {
            coil.compose.AsyncImage(
                model = playerBackgroundUri,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                alpha = 0.42f,
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xCC010105),
                                Color(0x99010105),
                                Color(0xEE000000),
                            )
                        )
                    )
            )
        }
        var waveT by remember { mutableFloatStateOf(0f) }
        LaunchedEffect(Unit) {
            try {
                var last = withFrameNanos { it }
                while (true) {
                    val now = withFrameNanos { it }
                    waveT += ((now - last) / 1e9f).toFloat().coerceIn(0f, 0.033f)
                    last = now
                }
            } catch (_: Exception) {}
        }
        // nebula behind the cover + glowing blue waves along the bottom
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            // Deep nebula core behind the artwork
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x668A5CFF), Color(0x338A5CFF), Color(0x2200DDF5), Color.Transparent),
                    center = Offset(w * 0.5f, h * 0.28f),
                    radius = w * 0.78f,
                ),
                radius = w * 0.78f,
                center = Offset(w * 0.5f, h * 0.28f),
            )
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x22D94BFF), Color(0x2200DDF5), Color.Transparent),
                    center = Offset(w * 0.72f, h * 0.18f),
                    radius = w * 0.45f,
                ),
                radius = w * 0.45f,
                center = Offset(w * 0.72f, h * 0.18f),
            )
            for (layer in 0..3) {
                val yBase = h * (0.93f + layer * 0.012f)
                val path = Path()
                path.moveTo(0f, yBase)
                var x = 0f
                while (x <= w) {
                    path.lineTo(x, yBase + sin(x * 0.011f + waveT * (0.9f + layer * 0.25f) + layer) * (13f + layer * 4f) * density)
                    x += 7f
                }
                val col = listOf(Tx.Accent2, Color(0xFF386BD6), Color(0xFF7653C8), Color(0xFF8B4CB4))[layer]
                drawPath(path, col.copy(alpha = 0.34f - layer * 0.05f), style = Stroke(width = (2.2f + layer * 0.5f) * density, cap = StrokeCap.Round))
            }
        }
        if (particles) {
            ParticleField(active = particles, modifier = Modifier.fillMaxSize(), count = 80, energy = if (reactiveViz) hardness else null)
            TwinkleField(Modifier.fillMaxSize(), count = 40, tint = Color(0xFFCFE8FF))
        }

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // top bar: chevron down ... more
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { sound(UiSound.Kind.TAP); onClose() }) {
                    Icon(Icons.Rounded.KeyboardArrowDown, "Close", tint = Tx.Text, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.weight(1f))
                Box {
                    IconButton(onClick = { sound(UiSound.Kind.TAP); moreMenu = true }) {
                        Icon(Icons.Rounded.MoreVert, "More", tint = Tx.Text)
                    }
                    DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                        // Three-dots → Settings only; EQ / Editor / Theme live in the always-available side nav
                        DropdownMenuItem(text = { Text("Settings") }, onClick = { moreMenu = false; onSettings() })
                        DropdownMenuItem(text = { Text("Queue") }, onClick = { moreMenu = false; onQueue() })
                        DropdownMenuItem(text = { Text("Sleep timer") }, onClick = { moreMenu = false; onSleepTimer() })
                        DropdownMenuItem(text = { Text("Speed  ${playbackSpeed}x") }, onClick = { moreMenu = false; onSpeed() })
                        DropdownMenuItem(text = { Text(if (vinylMode) "Vinyl mode: on" else "Vinyl mode: off") }, onClick = { moreMenu = false; onToggleVinyl() })
                        DropdownMenuItem(text = { Text("Play similar") }, onClick = { moreMenu = false; onPlaySimilar() })
                        DropdownMenuItem(text = { Text("Choose cover image") }, onClick = { moreMenu = false; onSetImage() })
                        if (hasCustomCover) {
                            DropdownMenuItem(text = { Text("Remove cover image") }, onClick = { moreMenu = false; onResetImage() })
                        }
                    }
                }
            }

            Spacer(Modifier.weight(0.25f))

            // cover: glowing orbit rings around a circular artwork
            Box(
                Modifier
                    .appear(0)
                    .fillMaxWidth(0.86f)
                    .aspectRatio(1f)
                    .graphicsLayer { scaleX = artScale; scaleY = artScale },
                contentAlignment = Alignment.Center,
            ) {
                // Outer rotating neon ring (always present)
                Canvas(Modifier.fillMaxSize().graphicsLayer { rotationZ = if (state.isPlaying) ringSpin.value else 0f }) {
                    val r = size.minDimension / 2f
                    drawCircle(
                        Brush.sweepGradient(listOf(Color(0x0000E5FF), Color(0xCC00DDF5), Color(0x009B70FF), Color(0xCCFF58D8), Color(0x0000E5FF))),
                        r * 0.995f, center, style = Stroke(width = 3.2f * density),
                    )
                }
                // Soft nebula glow ring — always on, regardless of cover
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2f
                    drawCircle(Tx.Accent.copy(alpha = 0.18f + 0.28f * glow.value), r * 0.97f, center, style = Stroke(width = 18f * density))
                    drawCircle(Tx.Accent2.copy(alpha = 0.08f + 0.12f * glow.value), r * 1.02f, center, style = Stroke(width = 8f * density))
                }
                Box(
                    Modifier
                        .fillMaxSize(0.92f)
                        .graphicsLayer { if (vinylMode) rotationZ = if (state.isPlaying) rotation.value else 0f }
                        .shadow(40.dp, CircleShape, ambientColor = Tx.Accent2.copy(alpha = 0.55f), spotColor = Tx.Accent.copy(alpha = 0.6f))
                        .clip(CircleShape)
                        .border(
                            3.5.dp,
                            Brush.sweepGradient(listOf(Tx.Accent2, Color(0xFF5B8CFF), Tx.Accent, Tx.Accent3, Tx.Accent2)),
                            CircleShape,
                        )
                        .pointerInput(Unit) { detectTapGestures(onLongPress = { onSetImage() }) },
                    contentAlignment = Alignment.Center,
                ) {
                    // Always show nebula glow behind whatever cover is used
                    Canvas(Modifier.fillMaxSize()) {
                        drawCircle(
                            Brush.radialGradient(
                                listOf(Color(0x668B5CFF), Color(0x3300E5FF), Color(0x22FF58D8), Color.Transparent),
                                center = center,
                                radius = size.minDimension * 0.55f,
                            ),
                            radius = size.minDimension * 0.55f,
                            center = center,
                        )
                    }
                    Artwork(
                        song,
                        Modifier.fillMaxSize().padding(4.dp),
                        corner = 999.dp,
                        iconSize = 96.dp,
                        artOverride = artOverride,
                    )
                    // Always write TEXWAVE across the circular art (as in the mockup)
                    Text(
                        "TEXWAVE",
                        style = TextStyle(
                            brush = Brush.horizontalGradient(
                                listOf(Color(0xAAFFE0FF), Color(0xCCFFFFFF), Color(0xAA7FE8FF))
                            ),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Light,
                            letterSpacing = 6.sp,
                            shadow = Shadow(Color(0x8800E5FF), Offset.Zero, 10f),
                        ),
                        modifier = Modifier.align(Alignment.Center),
                    )
                }
            }

            Spacer(Modifier.weight(0.25f))

            // title + like
            Row(Modifier.appear(120).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        song.artist.ifBlank { "Unknown artist" },
                        color = Tx.Muted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                val heartScale by animateFloatAsState(if (liked) 1.15f else 1f, spring(dampingRatio = 0.35f, stiffness = 400f), label = "heart")
                IconButton(onClick = { sound(UiSound.Kind.LIKE); onToggleLike() }) {
                    Icon(
                        if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (liked) "Unlike" else "Like",
                        tint = if (liked) Color(0xFFFF5AA8) else Color(0xFFE56AD0),
                        modifier = Modifier.size(28.dp).graphicsLayer { scaleX = heartScale; scaleY = heartScale },
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            // Neon waving bars that react to the music (exact mockup style)
            WaveBars(
                active = state.isPlaying,
                modifier = Modifier.appear(200).fillMaxWidth().height(76.dp),
                bars = 68,
                energyState = if (reactiveViz) hardness else null,
            )
            Spacer(Modifier.height(8.dp))

            GlowSeekBar(
                position = position,
                durationMs = state.durationMs,
                onSeek = onSeek,
                onSeekBackward = onSeekBackward,
                onSeekForward = onSeekForward,
            )

            Spacer(Modifier.height(10.dp))

            // transport
            Row(
                Modifier.appear(260).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { sound(UiSound.Kind.TAP); onShuffle() }) {
                    Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (state.shuffle) Tx.Accent2 else Tx.Text.copy(alpha = 0.6f))
                }
                IconButton(onClick = { sound(UiSound.Kind.TAP); onPrevious() }) {
                    Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(38.dp))
                }
                val breathe = infinite.animateFloat(
                    1f, 1.045f,
                    infiniteRepeatable(tween(1500), androidx.compose.animation.core.RepeatMode.Reverse),
                    label = "playBreath",
                )
                Box(
                    Modifier
                        .size(76.dp)
                        .graphicsLayer {
                            val b = if (state.isPlaying) breathe.value else 1f
                            scaleX = b; scaleY = b
                        }
                        .shadow(22.dp, CircleShape, ambientColor = Tx.Accent.copy(alpha = 0.7f), spotColor = Tx.Accent2.copy(alpha = 0.6f))
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF2EC8FF), Tx.Accent, Color(0xFFE040C0)),
                                start = Offset(0f, 0f), end = Offset(220f, 220f),
                            )
                        )
                        .pressable(0.9f) {
                            sound(if (state.isPlaying) UiSound.Kind.PAUSE else UiSound.Kind.PLAY)
                            onToggle()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        if (state.isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(40.dp),
                    )
                }
                IconButton(onClick = { sound(UiSound.Kind.TAP); onNext() }) {
                    Icon(Icons.Rounded.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(38.dp))
                }
                IconButton(onClick = { sound(UiSound.Kind.TAP); onRepeat() }) {
                    val icon = if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat
                    Icon(icon, "Repeat", tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) Tx.Accent2 else Tx.Text.copy(alpha = 0.6f))
                }
            }

            Spacer(Modifier.height(14.dp))

            // Small Lyrics button (exact mockup style)
            Row(
                Modifier
                    .appear(340)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x44101830))
                    .border(1.dp, Color(0x553DE0FF), RoundedCornerShape(16.dp))
                    .pressable(0.95f) { sound(UiSound.Kind.TAB); onLyrics() }
                    .padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.GraphicEq, null, tint = Tx.Accent2, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text("Lyrics", color = Color(0xFFD0D8F0), fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }

            Spacer(Modifier.height(8.dp))

            // Thin auto-similar strip — library neighbors + YouTube
            val ctx = LocalContext.current
            SimilarStrip(
                seed = song,
                neighbors = similarSongs,
                onPlay = onPlaySimilarSong,
                onOpenFull = onOpenSimilarScreen,
                onYoutube = { s ->
                    YoutubeDiscover.openYoutubeSearch(ctx, "${s.title} ${s.artist}")
                },
                modifier = Modifier.appear(380).fillMaxWidth(),
            )

            Spacer(Modifier.height(10.dp))
        }

        // Soft footer accent lines — kept very low so they never cover controls / similar
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            for (layer in 0..1) {
                val yBase = h * (0.97f + layer * 0.01f)
                val path = Path()
                path.moveTo(0f, yBase)
                var x = 0f
                while (x <= w) {
                    path.lineTo(
                        x,
                        yBase + sin(x * 0.01f + waveT * (0.6f + layer * 0.2f) + layer) * (4f + layer * 2f) * density
                    )
                    x += 8f
                }
                val col = listOf(Tx.Accent2, Color(0xFF6A5CFF))[layer]
                drawPath(
                    path,
                    col.copy(alpha = 0.14f - layer * 0.04f),
                    style = Stroke(width = (1.2f + layer * 0.3f) * density, cap = StrokeCap.Round),
                )
            }
        }
    }
}

/** Thin glowing seek bar (pink → violet → blue) with a draggable dot. Only this composable ticks. */
@Composable
private fun GlowSeekBar(
    position: State<Long>,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    onSeekBackward: () -> Unit,
    onSeekForward: () -> Unit,
) {
    var dragging by remember { mutableStateOf(false) }
    var dragFrac by remember { mutableFloatStateOf(0f) }
    val duration = durationMs.coerceAtLeast(1L)
    val frac = if (dragging) dragFrac else (position.value.toFloat() / duration).coerceIn(0f, 1f)

    Canvas(
        Modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(duration) {
                detectTapGestures { o -> onSeek((o.x / size.width).coerceIn(0f, 1f).times(duration).toLong()) }
            }
            .pointerInput(duration) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> dragging = true; dragFrac = (o.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { onSeek((dragFrac * duration).toLong()); dragging = false },
                    onDragCancel = { dragging = false },
                    onHorizontalDrag = { change, _ -> dragFrac = (change.position.x / size.width).coerceIn(0f, 1f) },
                )
            },
    ) {
        val y = size.height / 2f
        val x = size.width * frac
        drawLine(Color(0x26FFFFFF), Offset(0f, y), Offset(size.width, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        if (x > 0f) {
            val grad = Brush.horizontalGradient(listOf(Tx.Accent3, Tx.Accent, Color(0xFF3A8CFF)), 0f, size.width)
            drawLine(grad, Offset(0f, y), Offset(x, y), strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round, alpha = 0.22f)
            drawLine(grad, Offset(0f, y), Offset(x, y), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        }
        drawCircle(Color(0x44B7A8FF), (if (dragging) 13.dp else 10.dp).toPx(), Offset(x, y))
        drawCircle(Color(0xFFEDE8FF), 5.dp.toPx(), Offset(x, y))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(formatDuration((frac * duration).toLong()), color = Tx.Muted, fontSize = 11.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "\u221210", color = Color(0xFF8FA6FF), fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onSeekBackward).padding(horizontal = 12.dp, vertical = 2.dp),
            )
            Text(
                "+10", color = Color(0xFF8FA6FF), fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onSeekForward).padding(horizontal = 12.dp, vertical = 2.dp),
            )
        }
        Text(formatDuration(duration), color = Tx.Muted, fontSize = 11.sp)
    }
}
