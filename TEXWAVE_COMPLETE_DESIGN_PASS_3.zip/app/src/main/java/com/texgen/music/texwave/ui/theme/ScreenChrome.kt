package com.texgen.music.texwave.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.components.sonicAtmosphere

/**
 * Single projected chrome for the whole app — every screen should sit inside this language.
 * Dark high-tech · RGB accent · calm hierarchy · no random rainbow cards.
 */
object Chrome {
    val PagePad = 20.dp
    val CardRadius = 20.dp
    val Hairline = 1.dp
    val RgbBorder: Brush
        get() = Brush.linearGradient(
            listOf(
                Tx.Accent.copy(alpha = 0.55f),
                Tx.Accent2.copy(alpha = 0.45f),
                Tx.Accent3.copy(alpha = 0.20f),
                Tx.Accent.copy(alpha = 0.35f),
            ),
        )
    val CardBg: Brush
        get() = Brush.verticalGradient(
            listOf(Color(0xF20D1320), Color(0xF204070D)),
        )
}

@Composable
fun TexPage(
    modifier: Modifier = Modifier,
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    Box(
        modifier
            .fillMaxSize()
            .background(Tx.Bg)
            .sonicAtmosphere()
            .statusBarsPadding(),
    ) {
        val colMod = Modifier
            .fillMaxSize()
            .then(if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier)
            .padding(horizontal = Chrome.PagePad)
            .padding(bottom = 100.dp)
        Column(colMod, content = content)
    }
}

@Composable
fun TexPageTitle(
    title: String,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 12.dp, bottom = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = Tx.Text,
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.8).sp,
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = Tx.Muted, fontSize = 12.sp)
            }
        }
        trailing?.invoke()
    }
}

@Composable
fun TexSectionLabel(text: String) {
    Text(
        text.uppercase(),
        color = Tx.Muted,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.4.sp,
        modifier = Modifier.padding(top = 18.dp, bottom = 8.dp),
    )
}

@Composable
fun TexCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .glassCard(16)
            .padding(14.dp),
        content = content,
    )
}

@Composable
fun TexEmptyState(title: String, body: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = Tx.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Text(body, color = Tx.Muted, fontSize = 12.sp)
    }
}
