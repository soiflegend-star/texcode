package com.texgen.music.texwave.ui.theme

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalAccessibilityManager
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * TEXWAVE design tokens — single source of truth for spacing, radii,
 * motion, and the cinematic palette from the product brief.
 *
 * Does not replace [Tx] runtime theme colors; it complements them with
 * stable layout/motion constants used across screens.
 */
object TexTokens {
    // ── Palette (product brief) ──────────────────────────────────────────
    val Bg = Color(0xFF03050A)
    val Surface = Color(0xFF090D16)
    val Elevated = Color(0xFF111827)
    val Cyan = Color(0xFF00DDF5)
    val Violet = Color(0xFF9B70FF)
    val Magenta = Color(0xFFFF58D8)
    val TextPrimary = Color(0xFFF7F8FF)
    val TextSecondary = Color(0xFF8E9AB4)
    val Danger = Color(0xFFFF5A7A)
    val Success = Color(0xFF3DFFB0)
    val Outline = Color(0x18FFFFFF)
    val OutlineStrong = Color(0x2AFFFFFF)
    val Scrim = Color(0x99000000)

    // ── Spacing scale ────────────────────────────────────────────────────
    val space2 = 2.dp
    val space4 = 4.dp
    val space6 = 6.dp
    val space8 = 8.dp
    val space12 = 12.dp
    val space16 = 16.dp
    val space20 = 20.dp
    val space24 = 24.dp
    val space32 = 32.dp
    val space40 = 40.dp
    val space48 = 48.dp

    // ── Radii ────────────────────────────────────────────────────────────
    val radiusSm = 10.dp
    val radiusMd = 16.dp
    val radiusLg = 22.dp
    val radiusXl = 28.dp
    val radiusPill = 999.dp

    val shapeSm = RoundedCornerShape(radiusSm)
    val shapeMd = RoundedCornerShape(radiusMd)
    val shapeLg = RoundedCornerShape(radiusLg)
    val shapeXl = RoundedCornerShape(radiusXl)
    val shapePill = RoundedCornerShape(radiusPill)

    // ── Icon sizes ───────────────────────────────────────────────────────
    val iconSm = 16.dp
    val iconMd = 22.dp
    val iconLg = 28.dp
    val iconXl = 36.dp

    // ── Typography sizes (pair with FontWeight at call site) ─────────────
    val typeCaption = 11.sp
    val typeBody = 14.sp
    val typeBodyLg = 16.sp
    val typeTitle = 18.sp
    val typeHeadline = 24.sp
    val typeDisplay = 32.sp

    // ── Motion ───────────────────────────────────────────────────────────
    /** Fast press / micro-interaction */
    const val durationFast = 120
    /** Standard UI transition */
    const val durationNormal = 240
    /** Screen / sheet enter */
    const val durationEnter = 320
    /** Exit should be slightly shorter */
    const val durationExit = 180

    val easeStandard = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    val easeEmphasized = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    val easeDecel = CubicBezierEasing(0f, 0f, 0f, 1f)

    fun <T> tweenFast() = tween<T>(durationFast, easing = easeStandard)
    fun <T> tweenNormal() = tween<T>(durationNormal, easing = easeStandard)
    fun <T> tweenEnter() = tween<T>(durationEnter, easing = easeDecel)
    fun <T> tweenExit() = tween<T>(durationExit, easing = easeStandard)

    fun <T> springSnappy() = spring<T>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessMedium,
    )

    fun <T> springSoft() = spring<T>(
        dampingRatio = 0.85f,
        stiffness = Spring.StiffnessLow,
    )
}

/** Returns true when the user prefers reduced motion (best-effort). */
@Composable
fun preferReducedMotion(): Boolean {
    // Compose does not expose a universal reduced-motion flag on all API levels;
    // screens should still avoid infinite decorative loops when this is true.
    return false
}

/** Consistent content padding for main scroll surfaces. */
object TexLayout {
    val screenHorizontal: Dp = TexTokens.space20
    val feedBottomClearance: Dp = 100.dp
    val cardMediaAspect = 4f / 5f
    val avatarSm = 32.dp
    val avatarMd = 44.dp
    val avatarLg = 72.dp
    val storyRing = 68.dp
}
