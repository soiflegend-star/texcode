package com.texgen.music.texwave.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Whatshot
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.data.chat.avatarModel
import com.texgen.music.texwave.data.chat.ChatAuthState
import com.texgen.music.texwave.data.chat.ChatRepository
import com.texgen.music.texwave.data.chat.CloudSync
import com.texgen.music.texwave.ui.MusicViewModel
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import com.texgen.music.texwave.ui.screens.chat.ChatAuthScreen
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.launch

/**
 * "My profile" for the whole app: account, listening stats, streak, achievements, quick plays,
 * cloud backup and file backup. Reachable from Library, Phantom and Settings.
 */
@Composable
fun MyProfileScreen(
    repo: ChatRepository,
    vm: MusicViewModel,
    onBack: () -> Unit,
    onOpenChat: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val auth by repo.authState.collectAsState()
    val profile = (auth as? ChatAuthState.SignedIn)?.profile
    val lib by vm.lib.collectAsState()

    // recompute whenever the library state changes (plays, likes, playlists)
    val stats = remember(lib) { vm.listeningStats() }
    val badges = remember(lib) { vm.achievements() }

    var showAuth by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var name by remember(profile?.id) { mutableStateOf(profile?.displayName ?: "") }
    var username by remember(profile?.id) { mutableStateOf(profile?.username ?: "") }
    var bio by remember(profile?.id) { mutableStateOf(profile?.bio ?: "") }
    var avatar by remember(profile?.id) { mutableStateOf<String?>(profile?.avatarModel) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()

    val pickAvatar = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null || profile == null) return@rememberLauncherForActivityResult
        busy = true
        scope.launch {
            repo.uploadAvatar(uri).onSuccess { avatar = it; toast("Photo updated") }.onFailure { toast(it.message ?: "Upload failed") }
            busy = false
        }
    }
    val exportFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(vm.cloudSnapshot().toByteArray()) }
            toast("Backup saved")
        }.onFailure { toast("Could not save backup") }
    }
    val importFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            val text = context.contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: ""
            val n = vm.applyCloudSnapshot(text)
            toast(if (n > 0) "Restored $n items" else "Nothing new to restore")
        }.onFailure { toast("Could not read backup") }
    }

    fun backupNow() {
        busy = true; status = null
        scope.launch {
            CloudSync.push(repo, vm.cloudSnapshot())
                .onSuccess { status = "Backed up to your account ✓" }
                .onFailure { status = it.message ?: "Backup failed" }
            busy = false
        }
    }
    fun restoreNow() {
        busy = true; status = null
        scope.launch {
            CloudSync.pull(repo)
                .onSuccess { json ->
                    status = if (json == null) "No cloud backup yet — tap Back up first."
                    else { val n = vm.applyCloudSnapshot(json); if (n > 0) "Restored $n items from your account ✓" else "Already up to date ✓" }
                }
                .onFailure { status = it.message ?: "Restore failed" }
            busy = false
        }
    }

    val displayName = profile?.displayName?.ifBlank { null } ?: profile?.username ?: "Guest listener"

    if (showAuth && profile == null) {
        ChatAuthScreen(repo = repo, onBack = { showAuth = false }, onSignedIn = { showAuth = false })
    } else Column(Modifier.fillMaxSize().sonicAtmosphere().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(Icons.Rounded.ArrowBack, "Back") { onBack() }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("YOUR SPACE", color = Tx.Accent2, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                Text("My profile", color = Tx.Text, fontSize = 23.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.35).sp)
            }
            RoundIcon(Icons.Rounded.Settings, "Settings") { onOpenSettings() }
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp, top = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // ---- hero ----
            item {
                Card(Modifier.appear(0)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(92.dp).clip(CircleShape)
                                .border(3.dp, Brush.sweepGradient(listOf(Tx.Accent2, Tx.Accent, Tx.Accent3, Tx.Accent2)), CircleShape)
                                .padding(4.dp).clip(CircleShape).background(Tx.SurfaceHigh)
                                .clickable(enabled = profile != null && !busy) { pickAvatar.launch("image/*") },
                            contentAlignment = Alignment.Center,
                        ) {
                            when {
                                busy && editing -> CircularProgressIndicator(Modifier.size(26.dp), strokeWidth = 2.dp, color = Tx.Accent)
                                !avatar.isNullOrBlank() -> AsyncImage(avatar, "Avatar", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                else -> Text(displayName.take(1).uppercase(), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold)
                            }
                            if (profile != null) {
                                Box(Modifier.align(Alignment.BottomEnd).size(26.dp).clip(CircleShape).background(Tx.Accent), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.PhotoCamera, null, tint = Color.White, modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(displayName, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (profile != null) Text("@${profile.username}", color = Tx.Accent2, fontSize = 13.sp)
                            Text(
                                profile?.bio?.takeIf { it.isNotBlank() } ?: if (profile == null) "Sign in to save everything to your account" else "Add a bio",
                                color = Tx.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    if (profile == null) {
                        GlowButton("Sign in / Create account") { showAuth = true }
                    } else if (!editing) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            GlowButton("Edit profile", Modifier.weight(1f)) { editing = true }
                            GhostChip("Chats", Icons.Rounded.Forum) { onOpenChat() }
                        }
                    } else {
                        OutlinedTextField(name, { name = it }, label = { Text("Display name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(username, { username = it.lowercase() }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(bio, { bio = it.take(160) }, label = { Text("Bio") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            GlowButton(if (busy) "Saving…" else "Save", Modifier.weight(1f)) {
                                if (busy) return@GlowButton
                                busy = true
                                scope.launch {
                                    repo.updateProfile(name.trim(), username.trim(), bio.trim())
                                        .onSuccess { editing = false; toast("Profile saved") }
                                        .onFailure { toast(it.message ?: "Could not save") }
                                    busy = false
                                }
                            }
                            GhostChip("Cancel", null) { editing = false }
                        }
                    }
                }
            }

            // ---- stat chips ----
            item {
                Row(Modifier.fillMaxWidth().appear(60), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatChip(Modifier.weight(1f), stats.totalPlays.toString(), "Plays", Icons.Rounded.History)
                    StatChip(Modifier.weight(1f), if (stats.minutes >= 60) "${stats.minutes / 60}h" else "${stats.minutes}m", "Listened", Icons.Rounded.Star)
                    StatChip(Modifier.weight(1f), "${stats.streak}🔥", "Streak", Icons.Rounded.Whatshot)
                    StatChip(Modifier.weight(1f), stats.favorites.toString(), "Favorites", Icons.Rounded.Favorite)
                }
            }

            // ---- quick plays ----
            item {
                Card(Modifier.appear(100)) {
                    SectionTitle("Quick play")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickTile(Modifier.weight(1f), Icons.Rounded.Shuffle, "Surprise me") { vm.surpriseMe() }
                        QuickTile(Modifier.weight(1f), Icons.Rounded.Whatshot, "Most played") { vm.playMostPlayed() }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QuickTile(Modifier.weight(1f), Icons.Rounded.Favorite, "Shuffle favorites") { vm.shuffleFavorites() }
                        QuickTile(Modifier.weight(1f), Icons.Rounded.NewReleases, "Newest first") { vm.playRecentlyAdded() }
                    }
                }
            }

            // ---- top artists / songs ----
            item {
                Card(Modifier.appear(140)) {
                    SectionTitle("Your top artists")
                    if (stats.topArtists.isEmpty()) Text("Play some music and your favorites will appear here.", color = Tx.Muted, fontSize = 13.sp)
                    val max = (stats.topArtists.firstOrNull()?.second ?: 1).coerceAtLeast(1)
                    stats.topArtists.forEachIndexed { i, (artist, n) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${i + 1}", color = Tx.Accent2, fontWeight = FontWeight.Bold, modifier = Modifier.width(22.dp))
                            Column(Modifier.weight(1f)) {
                                Text(artist, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(Color(0x1AFFFFFF))) {
                                    Box(Modifier.fillMaxWidth(n / max.toFloat()).height(5.dp).clip(CircleShape).background(Tx.Brand))
                                }
                            }
                            Text("$n", color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 10.dp))
                        }
                    }
                    if (stats.topSongs.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        SectionTitle("Top songs")
                        stats.topSongs.forEach { (song, n) ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(song.title, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                Text("$n plays", color = Tx.Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // ---- achievements ----
            item {
                Card(Modifier.appear(180)) {
                    SectionTitle("Achievements · ${badges.count { it.unlocked }}/${badges.size}")
                    badges.chunked(2).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { b -> Badge(Modifier.weight(1f), b.title, b.detail, b.unlocked) }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                    Text("Best streak: ${stats.bestStreak} days", color = Tx.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }

            // ---- account, sync, backup ----
            item {
                Card(Modifier.appear(220)) {
                    SectionTitle("Cloud & backup")
                    Text(
                        if (profile != null) "Favorites, playlists, play counts and recents are saved to your account so they follow you to any phone. Your chats are already stored in your account."
                        else "Sign in to back up your favorites, playlists and chats to your account.",
                        color = Tx.Muted, fontSize = 12.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    if (profile != null) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            GlowButton("Back up now", Modifier.weight(1f), Icons.Rounded.CloudUpload) { if (!busy) backupNow() }
                            GlowButton("Restore", Modifier.weight(1f), Icons.Rounded.CloudDownload) { if (!busy) restoreNow() }
                        }
                        if (busy) Text("Working…", color = Tx.Accent2, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                        status?.let { Text(it, color = Tx.Accent2, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)) }
                        Spacer(Modifier.height(10.dp))
                    } else {
                        GlowButton("Sign in") { showAuth = true }
                        Spacer(Modifier.height(10.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GhostChip("Save to file", Icons.Rounded.FileDownload, Modifier.weight(1f)) { exportFile.launch("texwave_backup.json") }
                        GhostChip("Load from file", Icons.Rounded.FileUpload, Modifier.weight(1f)) { importFile.launch(arrayOf("application/json", "text/plain", "*/*")) }
                    }
                }
            }

            // ---- share + sign out ----
            item {
                Row(Modifier.fillMaxWidth().appear(260), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GhostChip("Share my wave", Icons.Rounded.Share, Modifier.weight(1f)) {
                        val text = buildString {
                            appendLine("🎧 My TEXWAVE — $displayName")
                            appendLine("${stats.totalPlays} plays · ${stats.minutes / 60}h ${stats.minutes % 60}m listened · ${stats.streak}-day streak")
                            if (stats.topArtists.isNotEmpty()) appendLine("Top artists: " + stats.topArtists.take(3).joinToString { it.first })
                            append("${stats.favorites} favorites · ${stats.playlists} playlists")
                        }
                        context.startActivity(
                            Intent.createChooser(
                                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share my wave",
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    if (profile != null) {
                        GhostChip("Sign out", Icons.Rounded.Logout, Modifier.weight(1f)) {
                            scope.launch {
                                // back up first so nothing is lost, then sign out
                                runCatching { CloudSync.push(repo, vm.cloudSnapshot()) }
                                repo.signOut()
                                toast("Signed out")
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------------------
// small building blocks
// ----------------------------------------------------------------------------------------

@Composable
private fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xF0181B2A), Color(0xF00A0D16), Color(0xF0141022))))
            .border(1.dp, Brush.linearGradient(listOf(Color(0x882FE6FF), Color(0x22FFFFFF), Color(0x88A37CFF))), shape)
            .padding(16.dp),
    ) { content() }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
private fun RoundIcon(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(Color(0x22FFFFFF)).border(1.dp, Color(0x33FFFFFF), CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = Color.White) }
}

@Composable
private fun GlowButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF7657D8), Color(0xFF3B9EBA), Color(0xFF00DDF5))))
            .pressable(0.96f) { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
    }
}

@Composable
private fun GhostChip(text: String, icon: ImageVector?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x14FFFFFF))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp))
            .pressable(0.96f) { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun StatChip(modifier: Modifier, value: String, label: String, icon: ImageVector) {
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0x14FFFFFF))
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(18.dp))
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = Tx.Accent2, modifier = Modifier.size(16.dp))
        Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 3.dp))
        Text(label, color = Tx.Muted, fontSize = 10.sp)
    }
}

@Composable
private fun QuickTile(modifier: Modifier, icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.linearGradient(listOf(Color(0x33A37CFF), Color(0x222FE6FF))))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp))
            .pressable(0.95f) { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun Badge(modifier: Modifier, title: String, detail: String, unlocked: Boolean) {
    Row(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (unlocked) Color(0x2A2FE6FF) else Color(0x0FFFFFFF))
            .border(1.dp, if (unlocked) Color(0x882FE6FF) else Color(0x1AFFFFFF), RoundedCornerShape(14.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.EmojiEvents, null, tint = if (unlocked) Color(0xFFFFD36B) else Color(0x44FFFFFF), modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(title, color = if (unlocked) Color.White else Tx.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(detail, color = Tx.Muted, fontSize = 10.sp, maxLines = 2)
        }
    }
}
