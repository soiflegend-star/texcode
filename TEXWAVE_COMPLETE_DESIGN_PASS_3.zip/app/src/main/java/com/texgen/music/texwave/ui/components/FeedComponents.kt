package com.texgen.music.texwave.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import com.texgen.music.texwave.ui.theme.TexLayout
import com.texgen.music.texwave.ui.theme.TexTokens
import com.texgen.music.texwave.ui.theme.Tx

/**
 * Press scale feedback — fast, non-blocking, respects snappy motion token.
 */
@Composable
fun Modifier.texPressable(
    enabled: Boolean = true,
    onClick: () -> Unit,
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = TexTokens.tweenFast(),
        label = "pressScale",
    )
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(
            interactionSource = interaction,
            indication = null,
            enabled = enabled,
            onClick = onClick,
        )
}

/** Soft placeholder while remote media loads. */
@Composable
fun MediaPlaceholder(modifier: Modifier = Modifier) {
    Box(
        modifier
            .background(
                Brush.linearGradient(
                    listOf(TexTokens.Elevated, TexTokens.Surface, TexTokens.Elevated)
                )
            )
    )
}

/**
 * Premium media post card for the home / discovery feed.
 * Media-first hierarchy; actions stay secondary.
 */
@Composable
fun SocialPostCard(
    creatorName: String,
    creatorHandle: String,
    avatarUrl: String?,
    mediaUrl: String?,
    caption: String,
    likeCount: Int,
    commentCount: Int,
    liked: Boolean,
    saved: Boolean,
    timeLabel: String,
    onOpenProfile: () -> Unit,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit,
    onMore: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(bottom = TexTokens.space20)
    ) {
        // Header
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = TexLayout.screenHorizontal, vertical = TexTokens.space8),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(TexLayout.avatarSm)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(TexTokens.Violet, TexTokens.Cyan)))
                    .texPressable(onClick = onOpenProfile),
                contentAlignment = Alignment.Center,
            ) {
                if (!avatarUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = avatarUrl,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                        contentScale = ContentScale.Crop,
                    )
                } else {
                    Text(
                        creatorName.take(1).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                    )
                }
            }
            Spacer(Modifier.width(TexTokens.space12))
            Column(Modifier.weight(1f).texPressable(onClick = onOpenProfile)) {
                Text(
                    creatorName,
                    color = TexTokens.TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "@$creatorHandle · $timeLabel",
                    color = TexTokens.TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Icon(
                Icons.Rounded.MoreHoriz,
                contentDescription = "More",
                tint = TexTokens.TextSecondary,
                modifier = Modifier
                    .size(TexTokens.iconMd)
                    .texPressable(onClick = onMore),
            )
        }

        // Media
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = TexTokens.space12)
                .clip(TexTokens.shapeLg)
                .aspectRatio(TexLayout.cardMediaAspect)
                .background(TexTokens.Elevated)
                .border(
                    0.8.dp,
                    Brush.linearGradient(listOf(Tx.Accent2.copy(alpha = 0.20f), Color(0x18FFFFFF), Tx.Accent.copy(alpha = 0.18f))),
                    TexTokens.shapeLg,
                )
        ) {
            if (!mediaUrl.isNullOrBlank()) {
                SubcomposeAsyncImage(
                    model = mediaUrl,
                    contentDescription = caption.take(80),
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    loading = { MediaPlaceholder(Modifier.fillMaxSize()) },
                    error = { MediaPlaceholder(Modifier.fillMaxSize()) },
                )
            } else {
                MediaPlaceholder(Modifier.fillMaxSize())
                Text(
                    "No media",
                    color = TexTokens.TextSecondary,
                    modifier = Modifier.align(Alignment.Center),
                    fontSize = 13.sp,
                )
            }
        }

        // Actions
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = TexLayout.screenHorizontal, vertical = TexTokens.space12),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FeedAction(
                icon = if (liked) Icons.Rounded.Favorite else Icons.Outlined.FavoriteBorder,
                label = formatCount(likeCount),
                tint = if (liked) TexTokens.Magenta else TexTokens.TextPrimary,
                onClick = onLike,
            )
            Spacer(Modifier.width(TexTokens.space20))
            FeedAction(
                icon = Icons.Outlined.ChatBubbleOutline,
                label = formatCount(commentCount),
                onClick = onComment,
            )
            Spacer(Modifier.width(TexTokens.space20))
            FeedAction(
                icon = Icons.Rounded.Share,
                label = "Share",
                onClick = onShare,
            )
            Spacer(Modifier.weight(1f))
            Icon(
                if (saved) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                contentDescription = "Save",
                tint = if (saved) TexTokens.Cyan else TexTokens.TextPrimary,
                modifier = Modifier
                    .size(TexTokens.iconMd)
                    .texPressable(onClick = onSave),
            )
        }

        // Caption
        if (caption.isNotBlank()) {
            Text(
                text = buildString {
                    append(creatorHandle)
                    append("  ")
                    append(caption)
                },
                color = TexTokens.TextPrimary,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = TexLayout.screenHorizontal),
            )
        }
    }
}

@Composable
private fun FeedAction(
    icon: ImageVector,
    label: String,
    tint: Color = TexTokens.TextPrimary,
    onClick: () -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.texPressable(onClick = onClick),
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(TexTokens.iconMd))
        Spacer(Modifier.width(TexTokens.space6))
        Text(label, color = TexTokens.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

/** Horizontal story / temporary-update ring. */
@Composable
fun StoryRingItem(
    label: String,
    imageUrl: String?,
    seen: Boolean,
    isOwn: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .width(76.dp)
            .texPressable(onClick = onClick),
    ) {
        Box(
            Modifier
                .size(TexLayout.storyRing)
                .border(
                    width = 2.dp,
                    brush = if (seen) {
                        Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x22FFFFFF)))
                    } else {
                        Tx.StoryRing
                    },
                    shape = CircleShape,
                )
                .padding(3.dp)
                .clip(CircleShape)
                .background(TexTokens.Elevated),
            contentAlignment = Alignment.Center,
        ) {
            if (!imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = label,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text(
                    if (isOwn) "+" else label.take(1).uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                )
            }
        }
        Spacer(Modifier.height(TexTokens.space6))
        Text(
            label,
            color = TexTokens.TextSecondary,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

private fun formatCount(n: Int): String = when {
    n >= 1_000_000 -> String.format("%.1fM", n / 1_000_000.0)
    n >= 1_000 -> String.format("%.1fK", n / 1_000.0)
    else -> n.toString()
}
