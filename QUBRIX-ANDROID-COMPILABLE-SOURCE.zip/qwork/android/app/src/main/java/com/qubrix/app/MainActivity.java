package com.qubrix.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.net.URI;

public final class MainActivity extends Activity {
    private static final String PREF_SERVER = "qubrix_server_url";
    private static final int BG = Color.rgb(11, 11, 18);
    private static final int PANEL = Color.rgb(25, 23, 38);
    private static final int FG = Color.rgb(247, 245, 255);
    private static final int MUTED = Color.rgb(175, 169, 194);
    private static final int ACCENT = Color.rgb(155, 140, 255);

    private WebView webView;
    private ProgressBar progress;
    private TextView connectionMessage;
    private String serverUrl = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        serverUrl = getPreferences(MODE_PRIVATE).getString(PREF_SERVER, "");
        if (isValidHttpsUrl(serverUrl)) showWebApp(); else showSetup(null);
    }

    private void showSetup(String error) {
        destroyWebView();
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_VERTICAL);
        page.setPadding(dp(26), dp(28), dp(26), dp(28));
        page.setBackgroundColor(BG);

        TextView logo = label("Q", 40, ACCENT, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(round(PANEL, 22));
        page.addView(logo, new LinearLayout.LayoutParams(dp(76), dp(76)));

        TextView title = label("QUBRIX", 30, FG, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(24);
        page.addView(title, titleLp);
        TextView subtitle = label("Adaptive learning · PRISM intelligence", 14, MUTED, false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(8);
        subLp.bottomMargin = dp(28);
        page.addView(subtitle, subLp);

        page.addView(label("Connect your QUBRIX service", 18, FG, true));
        TextView note = label("The Android application can be installed without a server. Enter your deployed HTTPS address when the service is ready.", 14, MUTED, false);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(9);
        noteLp.bottomMargin = dp(18);
        page.addView(note, noteLp);

        EditText address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(FG);
        address.setHintTextColor(MUTED);
        address.setHint("https://your-qubrix-domain.com");
        address.setText(serverUrl);
        address.setTextSize(15);
        address.setPadding(dp(14), dp(10), dp(14), dp(10));
        address.setBackground(round(PANEL, 12));
        page.addView(address, new LinearLayout.LayoutParams(-1, dp(54)));

        if (error != null) {
            TextView err = label(error, 13, Color.rgb(255, 125, 145), false);
            LinearLayout.LayoutParams errLp = new LinearLayout.LayoutParams(-1, -2);
            errLp.topMargin = dp(8);
            page.addView(err, errLp);
        }

        Button connect = new Button(this);
        connect.setText("Connect");
        connect.setAllCaps(false);
        connect.setTextColor(BG);
        connect.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        connect.setBackground(round(ACCENT, 12));
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1, dp(52));
        buttonLp.topMargin = dp(18);
        page.addView(connect, buttonLp);
        connect.setOnClickListener(v -> {
            String candidate = normalizeUrl(address.getText().toString());
            if (!isValidHttpsUrl(candidate)) {
                showSetup("Enter a valid HTTPS URL with a real hostname.");
                return;
            }
            serverUrl = candidate;
            getPreferences(MODE_PRIVATE).edit().putString(PREF_SERVER, serverUrl).apply();
            showWebApp();
        });
        setContentView(page);
    }

    private void showWebApp() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        root.addView(layout, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), 0, dp(12), 0);
        bar.setBackgroundColor(BG);
        layout.addView(bar, new LinearLayout.LayoutParams(-1, dp(50)));
        bar.addView(label("QUBRIX", 17, FG, true), new LinearLayout.LayoutParams(0, -2, 1));
        TextView server = label("SERVER", 11, ACCENT, true);
        server.setPadding(dp(12), dp(10), dp(8), dp(10));
        bar.addView(server);
        server.setOnClickListener(v -> showSetup(null));

        FrameLayout webContainer = new FrameLayout(this);
        layout.addView(webContainer, new LinearLayout.LayoutParams(-1, 0, 1));
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        settings.setUserAgentString(settings.getUserAgentString() + " QUBRIXAndroid/1.0");
        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, false);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        webContainer.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        webContainer.addView(progress, new FrameLayout.LayoutParams(-1, dp(2), Gravity.TOP));
        connectionMessage = label("", 14, MUTED, false);
        connectionMessage.setGravity(Gravity.CENTER);
        connectionMessage.setBackgroundColor(BG);
        connectionMessage.setVisibility(View.GONE);
        webContainer.addView(connectionMessage, new FrameLayout.LayoutParams(-1, -1));

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if ("https".equalsIgnoreCase(scheme)) return false;
                if ("mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                }
                return true;
            }
            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                showConnectionError("Secure connection failed. Check the website certificate.");
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) showConnectionError("QUBRIX could not be reached. Check the internet connection and server URL.");
            }
            @Override public void onPageFinished(WebView view, String url) {
                CookieManager.getInstance().flush();
                if (connectionMessage != null) connectionMessage.setVisibility(View.GONE);
            }
        });
        setContentView(root);
        webView.loadUrl(serverUrl);
    }

    private void showConnectionError(String message) {
        if (connectionMessage == null) return;
        connectionMessage.setText(message + "\n\nTap to retry.");
        connectionMessage.setVisibility(View.VISIBLE);
        connectionMessage.setOnClickListener(v -> { connectionMessage.setVisibility(View.GONE); if (webView != null) webView.reload(); });
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else if (webView != null) webView.loadUrl(serverUrl);
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        destroyWebView();
        super.onDestroy();
    }

    private void destroyWebView() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private android.graphics.drawable.GradientDrawable round(int color, int radiusDp) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private String normalizeUrl(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.isEmpty()) return "";
        if (!value.matches("(?i)^https://.*")) value = "https://" + value;
        return value.replaceAll("/+$", "");
    }

    private boolean isValidHttpsUrl(String value) {
        if (value == null || value.trim().isEmpty()) return false;
        try {
            URI uri = new URI(value);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null;
        } catch (Exception ignored) { return false; }
    }
}
