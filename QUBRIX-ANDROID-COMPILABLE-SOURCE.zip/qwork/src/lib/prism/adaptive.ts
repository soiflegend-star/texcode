/**
 * PRISM Adaptive Brain & Difficulty Controller — max-capability, hot-path friendly.
 */
import { masteryOf, recentAccuracy } from "../learn/review.ts";
import type { AppState } from "../learn/state.ts";
import { topicKey } from "../learn/state.ts";
import type { Difficulty, SessionKind } from "../learn/types.ts";
import type { AdaptiveSignals, PrismFamily } from "./types.ts";

const RANK: Record<Difficulty, number> = { easy: 0, medium: 1, hard: 2 };
const BY_RANK: Difficulty[] = ["easy", "medium", "hard"];

export function computeSignals(
  state: AppState | null,
  board: string,
  grade: number,
  subjectId?: string,
  topicId?: string,
): AdaptiveSignals {
  if (!state) {
    return {
      accuracy: 0.5, recentAccuracy: 0.5, weakTopics: [], strongTopics: [],
      recentMistakes: [], preferredDifficulty: "medium", exposureCount: 0,
    };
  }
  const globalTotal = Math.max(1, state.totals.answered);
  let scopedAnswered = 0;
  let scopedCorrect = 0;
  let recentCorrect = 0;
  let recentAnswered = 0;
  let exposureCount = 0;
  const weak: string[] = [];
  const strong: string[] = [];
  const prefix = `${board}:${grade}:`;

  for (const [tk, t] of Object.entries(state.topics)) {
    if (!tk.startsWith(prefix)) continue;
    const parts = tk.split(":");
    const storedSubject = parts[2] ?? "";
    if (subjectId && storedSubject !== subjectId) continue;
    const attempts = Math.max(0, t.attempts ?? 0);
    scopedAnswered += attempts;
    scopedCorrect += Math.min(attempts, Math.max(0, t.correct ?? 0));
    exposureCount += attempts;
    const mastery = masteryOf(t);
    const tid = parts.slice(3).join(":") || tk;
    if (mastery === "learning" || mastery === "not-started") {
      if (weak.length < 8) weak.push(tid);
    } else if (mastery === "strong") {
      if (strong.length < 8) strong.push(tid);
    }
    // Aggregate all matching topic windows; do not let object iteration order
    // make the learner's latest signal come from an arbitrary single topic.
    const recentBits = t.recent ?? "";
    for (let i = 0; i < recentBits.length; i++) {
      if (recentBits[i] === "1") recentCorrect++;
      if (recentBits[i] === "0" || recentBits[i] === "1") recentAnswered++;
    }
  }

  const accuracy = scopedAnswered ? scopedCorrect / scopedAnswered : state.totals.correct / globalTotal;
  const recent = recentAnswered ? recentCorrect / recentAnswered : 0.5;
  if (topicId) {
    const tk = topicKey(board, grade, subjectId ?? "", topicId);
    const t = state.topics[tk];
    if (t) {
      const topicRecent = recentAccuracy(t);
      if (topicRecent !== null) {
        // A specifically requested topic takes precedence over the aggregate.
        return {
          accuracy, recentAccuracy: topicRecent, weakTopics: weak, strongTopics: strong,
          recentMistakes: collectRecentMistakes(state), preferredDifficulty: preferDifficulty(accuracy, topicRecent),
          exposureCount,
        };
      }
    }
  }

  return {
    accuracy,
    recentAccuracy: recent,
    weakTopics: weak,
    strongTopics: strong,
    recentMistakes: collectRecentMistakes(state),
    preferredDifficulty: preferDifficulty(accuracy, recent),
    exposureCount,
  };
}

function collectRecentMistakes(state: AppState): string[] {
  return Object.entries(state.mistakes ?? {})
    .filter(([, value]) => (value?.count ?? 0) > 0 && value.resolved !== true)
    .sort((a, b) => (b[1].lastAt ?? 0) - (a[1].lastAt ?? 0))
    .slice(0, 12)
    .map(([key]) => key);
}

/** Gradual difficulty — never punish with endless easy. */
export function preferDifficulty(overall: number, recent: number): Difficulty {
  const score = 0.35 * overall + 0.65 * recent;
  if (score >= 0.78) return "hard";
  if (score >= 0.52) return "medium";
  return "easy";
}

export function nextDifficulty(
  current: Difficulty,
  lastCorrect: boolean,
  consecutiveCorrect: number,
  consecutiveWrong: number,
): Difficulty {
  const r = RANK[current];
  if (lastCorrect && consecutiveCorrect >= 3 && r < 2) return BY_RANK[r + 1]!;
  if (!lastCorrect && consecutiveWrong >= 3 && r > 0) return BY_RANK[r - 1]!;
  // Micro-promote after 5 correct at medium
  if (lastCorrect && consecutiveCorrect >= 5 && current === "medium") return "hard";
  return current;
}

export function scoreCandidate(
  signals: AdaptiveSignals,
  difficulty: Difficulty | undefined,
  topicId: string,
  family?: PrismFamily,
  lastFamilies: PrismFamily[] = [],
): number {
  let score = 50;
  const d = difficulty ?? "medium";
  score -= Math.abs(RANK[d] - RANK[signals.preferredDifficulty]) * 12;
  if (signals.weakTopics.includes(topicId)) score += 18;
  if (signals.strongTopics.includes(topicId) && d === "hard") score += 8;
  if (family && lastFamilies.length) {
    let same = 0;
    for (let i = lastFamilies.length - 1; i >= 0 && i >= lastFamilies.length - 3; i--) {
      if (lastFamilies[i] === family) same++;
    }
    score -= same * 15;
  }
  return score;
}

export function modeDifficultyBias(kind: SessionKind): Difficulty {
  switch (kind) {
    case "quick":
    case "daily":
      return "medium";
    case "exam":
      return "hard";
    case "revision":
      return "easy";
    default:
      return "medium";
  }
}
