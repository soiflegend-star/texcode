import { hashString, mulberry32 } from "../quiz/core.ts";
import { buildExposureIndex, checkNoveltyFast, markSeen, poolExhaustedMessage, type ExposureIndex } from "../prism/novelty.ts";
import { computeSignals, preferDifficulty, scoreCandidate } from "../prism/adaptive.ts";
import { shouldRotateType } from "../prism/variety.ts";
import { authoredFor } from "./content/authored-wbbse10.ts";
import { practiceTopics, type TopicInfo } from "./registry.ts";
import { authoredKey, genKey, resolveQuestion, signature, streamQuestion } from "./resolve.ts";
import { dateKeyOf, isDue, recentAccuracy } from "./review.ts";
import { topicKey, type AppState } from "./state.ts";
import type { Difficulty, QuestionRecord, SessionItem, SessionKind } from "./types.ts";

export type Plan = { items: SessionItem[]; notes: string[]; cursorAdvance: Record<string, number> };
const RANK: Record<Difficulty, number> = { easy: 0, medium: 1, hard: 2 };

export type TopicRef = { board: string; grade: number; subjectId: string; topicId: string };

/** PRISM Novelty Guard (fast path): one ExposureIndex per plan, O(1) checks, tight miss bound. */
function collectTopic(
  state: AppState | null, t: TopicRef, count: number, seen: Set<string>,
  pref?: Difficulty, reason?: string, kind: SessionKind = "practice",
  index?: ExposureIndex | null,
): { items: SessionItem[]; consumed: number; exhausted?: boolean } {
  const items: SessionItem[] = [];
  const tk = topicKey(t.board, t.grade, t.subjectId, t.topicId);
  const attempted = (k: string) => (state?.questions[k]?.attempts ?? 0) > 0;
  const idx = index ?? (state ? buildExposureIndex(state) : null);
  let auth = authoredFor(t.board, t.grade, t.subjectId, t.topicId);
  if (pref) {
    const pr = RANK[pref];
    auth = [...auth].sort((a, b) => Math.abs(RANK[a.difficulty ?? "medium"] - pr) - Math.abs(RANK[b.difficulty ?? "medium"] - pr));
  }
  const push = (r: QuestionRecord) => {
    const decision = checkNoveltyFast(idx, r, kind, seen);
    if (!decision.ok) return false;
    markSeen(seen, r);
    seen.add(signature(r));
    items.push({ key: r.id, reason: reason ?? (decision.reason === "revision-allowed" ? "Revision" : undefined) });
    return true;
  };
  for (const r of auth) {
    if (items.length >= count) break;
    if (!attempted(r.id) || kind === "revision") push(r);
  }
  let n = state?.topics[tk]?.cursor ?? 0;
  const start = n;
  // Tighter miss bound: stop early when stream is sparse
  const missLimit = Math.min(count * 6 + 12, 80);
  let misses = 0;
  while (items.length < count && misses < missLimit) {
    const r = streamQuestion(t.board, t.grade, t.subjectId, t.topicId, n);
    n++;
    if (!r) {
      if (n - start > 20000) break;
      misses++;
      continue;
    }
    if (!push(r)) misses++;
    else misses = 0; // reset on success to keep scanning productive ranges
  }
  if (items.length < count) {
    const rest = auth.filter((r) => attempted(r.id)).sort((a, b) => (state?.questions[a.id]?.lastAt ?? 0) - (state?.questions[b.id]?.lastAt ?? 0));
    for (const r of rest) { if (items.length >= count) break; push(r); }
  }
  return { items, consumed: n - start, exhausted: items.length < count && kind !== "revision" };
}

function sequenceVariety(items: SessionItem[]): SessionItem[] {
  // Greedy, stable sequencing: avoid three identical question types in a row
  // whenever another selected type is available. Never drops or duplicates items.
  const remaining = [...items];
  const ordered: SessionItem[] = [];
  const recent: import("./types.ts").QuestionType[] = [];
  const questionCache = new Map<string, QuestionRecord | null>();
  const questionFor = (key: string) => {
    if (!questionCache.has(key)) questionCache.set(key, resolveQuestion(key));
    return questionCache.get(key) ?? null;
  };
  while (remaining.length) {
    let at = remaining.findIndex((item) => {
      const q = questionFor(item.key);
      return q ? shouldRotateType(recent, q.type) : true;
    });
    if (at < 0) at = 0;
    const [next] = remaining.splice(at, 1);
    if (!next) break;
    ordered.push(next);
    const q = questionFor(next.key);
    if (q) recent.push(q.type);
  }
  return ordered;
}

function planFor(items: SessionItem[], cursorAdvance: Record<string, number>, want: number, what: string, exhausted?: boolean, topicTitle?: string): Plan {
  items = sequenceVariety(items);
  const notes: string[] = [];
  if (items.length < want) notes.push(`Only ${items.length} distinct ${what} questions are available right now (requested ${want}).`);
  if (exhausted) notes.push(poolExhaustedMessage(topicTitle));
  return { items, notes, cursorAdvance };
}

export function planTopic(state: AppState, t: TopicRef, count: number, kind: SessionKind = "practice"): Plan {
  const index = buildExposureIndex(state);
  const { items, consumed, exhausted } = collectTopic(state, t, count, new Set(), undefined, undefined, kind, index);
  return planFor(items, { [topicKey(t.board, t.grade, t.subjectId, t.topicId)]: consumed }, count, "topic", exhausted);
}

export function planQuick(state: AppState, topics: TopicRef[], count: number): Plan {
  const seen = new Set<string>();
  const index = buildExposureIndex(state);
  const adv: Record<string, number> = {};
  const lists = topics.map((t) => {
    const r = collectTopic(state, t, Math.ceil(count / Math.max(1, topics.length)) + 1, seen, undefined, undefined, "practice", index);
    adv[topicKey(t.board, t.grade, t.subjectId, t.topicId)] = r.consumed;
    return r.items;
  });
  const out: SessionItem[] = [];
  for (let i = 0; out.length < count && lists.some((l) => i < l.length); i++) for (const l of lists) if (i < l.length && out.length < count) out.push(l[i]!);
  return planFor(out, adv, count, "selected-topic");
}

export function adaptiveTarget(state: AppState, tk: string): Difficulty {
  const s = state.topics[tk];
  const acc = recentAccuracy(s);
  if (!s || acc === null || s.attempts < 5) return "easy";
  // PRISM gradual controller
  const overall = s.attempts > 0 ? (s.correct ?? 0) / s.attempts : 0.5;
  return preferDifficulty(overall, acc);
}

export function planAdaptive(state: AppState, board: string, grade: number, count: number, today: string, subjectId?: string): Plan {
  const topics = practiceTopics(board, grade).filter((t) => !subjectId || t.subjectId === subjectId);
  const seen = new Set<string>();
  const index = buildExposureIndex(state);
  const signals = computeSignals(state, board, grade, subjectId);
  const items: SessionItem[] = [];
  const adv: Record<string, number> = {};
  if (topics.length === 0) return { items, notes: ["No available topics for this selection."], cursorAdvance: adv };
  // 1. Missed questions that are due for review come first (at most a third of the session).
  const dueRefs = Object.values(state.reviews).filter((r) => r.kind === "question" && isDue(r, today)).sort((a, b) => a.due.localeCompare(b.due));
  for (const r of dueRefs) {
    if (items.length >= Math.floor(count / 3)) break;
    const q = resolveQuestion(r.ref);
    if (!q || q.board !== board || q.grade !== grade || (subjectId && q.subjectId !== subjectId)) continue;
    const sig = signature(q);
    if (seen.has(sig) || seen.has(q.id)) continue;
    markSeen(seen, q);
    seen.add(sig);
    items.push({ key: q.id, reason: "Revisiting a question you missed" });
  }
  // 2. The rest are drawn from topics weighted by weakness. Seeded by progress so it is reproducible.
  const rng = mulberry32(hashString(`adaptive|${board}|${grade}|${state.totals.answered}|${subjectId ?? "all"}`) || 1);
  const weight = (t: TopicInfo) => {
    const acc = recentAccuracy(state.topics[topicKey(board, grade, t.subjectId, t.id)]);
    const base = acc === null ? 2 : 0.5 + (1 - acc) ** 2 * 6;
    const stats = state.topics[topicKey(board, grade, t.subjectId, t.id)];
    const target = stats && stats.attempts >= 5
      ? adaptiveTarget(state, topicKey(board, grade, t.subjectId, t.id))
      : signals.preferredDifficulty;
    const prismScore = scoreCandidate(signals, target, t.id);
    return base * (0.5 + Math.max(0, prismScore) / 100);
  };
  let guard = 0;
  while (items.length < count && guard++ < count * 10) {
    const total = topics.reduce((n, t) => n + weight(t), 0);
    let r = rng() * total;
    let pick = topics[0]!;
    for (const t of topics) { r -= weight(t); if (r <= 0) { pick = t; break; } }
    const tk = topicKey(board, grade, pick.subjectId, pick.id);
    const acc = recentAccuracy(state.topics[tk]);
    const topicStats = state.topics[tk];
    const target = topicStats && topicStats.attempts >= 5
      ? adaptiveTarget(state, tk)
      : signals.preferredDifficulty;
    const reason = acc === null
      ? `New topic for you: ${pick.title}`
      : `${pick.title}: ${Math.round(acc * 100)}% recent accuracy${acc < 0.65 ? " — more practice here" : target === "hard" ? " — raising difficulty after consistent success" : ""}`;
    const cursorShift = adv[tk] ?? 0;
    const shifted: AppState = cursorShift ? { ...state, topics: { ...state.topics, [tk]: { ...(state.topics[tk] ?? { attempts: 0, correct: 0, recent: "", lastAt: 0, cursor: 0 }), cursor: (state.topics[tk]?.cursor ?? 0) + cursorShift } } } : state;
    const got = collectTopic(shifted, { board, grade, subjectId: pick.subjectId, topicId: pick.id }, 1, seen, target, reason, "adaptive", index);
    adv[tk] = cursorShift + got.consumed;
    items.push(...got.items);
  }
  const notes = ["Difficulty steps apply to individually written questions; generated questions are served in sequence."];
  return { ...planFor(items, adv, count, "adaptive"), notes: [...notes, ...(items.length < count ? [`Only ${items.length} distinct adaptive questions were available.`] : [])] };
}

export function planRevision(state: AppState, count: number, today: string): Plan {
  const items: SessionItem[] = [];
  const seen = new Set<string>();
  const add = (key: string, reason: string) => {
    if (items.length >= count || seen.has(key)) return;
    const r = resolveQuestion(key);
    if (!r) return;
    const sig = signature(r);
    if (seen.has(sig)) return;
    seen.add(key); seen.add(sig);
    items.push({ key, reason });
  };
  Object.values(state.reviews).filter((r) => r.kind === "question" && isDue(r, today)).sort((a, b) => a.due.localeCompare(b.due)).forEach((r) => add(r.ref, "Due for spaced review"));
  Object.entries(state.mistakes).filter(([, m]) => !m.resolved).sort((a, b) => b[1].lastAt - a[1].lastAt).forEach(([k]) => add(k, "Missed earlier"));
  state.bookmarks.forEach((k) => add(k, "Bookmarked"));
  return { items, notes: items.length === 0 ? ["Nothing to revise yet — answer some questions first."] : [], cursorAdvance: {} };
}

/** Same date + curriculum always gives the same set, regardless of learner state. */
export function planDaily(dateKey: string, board: string, grade: number, size = 5): Plan {
  const topics = practiceTopics(board, grade);
  if (!topics.length) return { items: [], notes: ["No questions are available for this curriculum yet."], cursorAdvance: {} };
  const rng = mulberry32(hashString(`daily|${dateKey}|${board}|${grade}`) || 1);
  const order = [...topics].sort((a, b) => hashString(`${dateKey}|${a.subjectId}|${a.id}`) - hashString(`${dateKey}|${b.subjectId}|${b.id}`));
  const items: SessionItem[] = [];
  const seen = new Set<string>();
  for (let i = 0; items.length < size && i < size * 12; i++) {
    const t = order[i % order.length]!;
    const pool = Math.min(t.generated, 2000);
    const useAuthored = t.authored > 0 && (pool === 0 || rng() < 0.4);
    let rec: QuestionRecord | null = null;
    if (useAuthored) { const a = authoredFor(board, grade, t.subjectId, t.id); rec = a[Math.floor(rng() * a.length)] ?? null; }
    else if (pool > 0) rec = streamQuestion(board, grade, t.subjectId, t.id, Math.floor(rng() * pool));
    if (!rec) continue;
    const sig = signature(rec);
    if (seen.has(sig)) continue;
    seen.add(sig);
    items.push({ key: rec.id, reason: `${t.title}` });
  }
  return { items, notes: [], cursorAdvance: {} };
}

export function planMixed(state: AppState, board: string, grade: number, count: number): Plan {
  const topics = practiceTopics(board, grade);
  const bySubject = new Map<string, TopicInfo[]>();
  for (const t of topics) bySubject.set(t.subjectId, [...(bySubject.get(t.subjectId) ?? []), t]);
  const subjects = [...bySubject.keys()];
  const items: SessionItem[] = [];
  const seen = new Set<string>();
  const index = buildExposureIndex(state);
  const adv: Record<string, number> = {};
  let guard = 0;
  while (items.length < count && subjects.length && guard++ < count * 6) {
    const sid = subjects[items.length % subjects.length]!;
    const list = bySubject.get(sid)!;
    const t = list[Math.floor((items.length / subjects.length) + guard) % list.length]!;
    const tk = topicKey(board, grade, sid, t.id);
    const base = state.topics[tk] ?? { attempts: 0, correct: 0, recent: "", lastAt: 0, cursor: 0 };
    const shifted: AppState = { ...state, topics: { ...state.topics, [tk]: { ...base, cursor: base.cursor + (adv[tk] ?? 0) } } };
    const got = collectTopic(shifted, { board, grade, subjectId: sid, topicId: t.id }, 1, seen, undefined, t.title, "mixed", index);
    adv[tk] = (adv[tk] ?? 0) + got.consumed;
    items.push(...got.items);
  }
  return planFor(items, adv, count, "mixed");
}

export function planExam(board: string, grade: number, count: number, seed: string, subjectIds?: string[]): Plan {
  const topics = practiceTopics(board, grade).filter((t) => !subjectIds || subjectIds.includes(t.subjectId));
  if (!topics.length) return { items: [], notes: ["No questions available for this selection."], cursorAdvance: {} };
  const rng = mulberry32(hashString(`exam|${seed}`) || 1);
  const shuffled = [...topics].sort((a, b) => hashString(`${seed}|${a.id}`) - hashString(`${seed}|${b.id}`));
  const items: SessionItem[] = [];
  const seen = new Set<string>();
  for (let i = 0; items.length < count && i < count * 15; i++) {
    const t = shuffled[i % shuffled.length]!;
    const pool = Math.min(t.generated, 3000);
    let rec: QuestionRecord | null = null;
    if (t.authored > 0 && (pool === 0 || rng() < 0.3)) { const a = authoredFor(board, grade, t.subjectId, t.id); rec = a[Math.floor(rng() * a.length)] ?? null; }
    else if (pool > 0) rec = streamQuestion(board, grade, t.subjectId, t.id, Math.floor(rng() * pool));
    if (!rec) continue;
    const sig = signature(rec);
    if (seen.has(sig)) continue;
    seen.add(sig);
    items.push({ key: rec.id });
  }
  return planFor(items, {}, count, "test");
}

export { authoredKey, genKey };
