import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { unlockNew } from "@/lib/learn/achievements";
import { dateKeyOf } from "@/lib/learn/review";
import { resolveQuestion } from "@/lib/learn/resolve";
import { recordExposure } from "@/lib/prism/novelty";
import { planAdaptive, planDaily, planExam, planMixed, planQuick, planRevision, planTopic, type Plan, type TopicRef } from "@/lib/learn/selection";
import * as S from "@/lib/learn/session";
import {
  addToMistakes, advanceCursor, defaultState, ensureCard, finishSessionState, recordAnswer, reportQuestion, reviewCard,
  setChapterNote, setQuestionNote, STORAGE_KEY, toggleBookmark, sanitizeState, type AppState, type Profile,
} from "@/lib/learn/state";
import { browserKV, exportState, importState, loadState, resetAll, saveState, type KV } from "@/lib/learn/storage";
import type { Response, Session, SessionKind } from "@/lib/learn/types";

export type View =
  | { name: "home" } | { name: "learn" } | { name: "subject"; subjectId: string } | { name: "topic"; subjectId: string; topicId: string }
  | { name: "practice" } | { name: "session" } | { name: "tests" } | { name: "revise" } | { name: "cards" } | { name: "notebook" }
  | { name: "me" } | { name: "settings" } | { name: "search" } | { name: "reference" } | { name: "curriculum" };

export type StartParams =
  | { kind: "practice"; topic: TopicRef; count: number }
  | { kind: "quick"; topics: TopicRef[]; count: number }
  | { kind: "adaptive"; count: number; subjectId?: string }
  | { kind: "revision"; count: number }
  | { kind: "daily" }
  | { kind: "mixed"; count: number }
  | { kind: "exam"; count: number; minutes: number; subjectIds?: string[] };

type Store = {
  ready: boolean; state: AppState; view: View; busy: string | null; toast: string | null; storageOk: boolean; loadMessage: string | null; online: boolean;
  nav: (v: View, opts?: { replace?: boolean }) => void; back: () => void;
  patchProfile: (p: Partial<Profile>) => void;
  start: (p: StartParams) => Promise<void>;
  answer: (i: number, r: Response) => void; clear: (i: number) => void; reveal: (i: number) => void; hint: (i: number) => void; mark: (i: number) => void; goto: (i: number) => void;
  submitExam: (reason?: "manual" | "timeout") => void; finishPractice: () => void; dismissActive: () => void;
  bookmark: (key: string) => void; addMistake: (key: string) => void; report: (key: string, reason: string) => void; qNote: (key: string, text: string) => void; chapterNote: (tk: string, text: string) => void;
  cardReview: (id: string, ref: string, ok: boolean) => void; ensureCards: (ids: { id: string; ref: string }[]) => void;
  exportJson: () => string; importJson: (text: string) => string | null; resetData: () => void; say: (m: string) => void;
};
const Ctx = createContext<Store | null>(null);
export function useStore(): Store { const s = useContext(Ctx); if (!s) throw new Error("QUBRIX store missing"); return s; }
const newId = (p: string) => `${p}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => defaultState());
  const [ready, setReady] = useState(false);
  const [view, setView] = useState<View>({ name: "home" });
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [storageOk, setStorageOk] = useState(true);
  const [loadMessage, setLoadMessage] = useState<string | null>(null);
  const [online, setOnline] = useState(true);
  const kvRef = useRef<KV | null>(null);
  const stack = useRef<View[]>([]);
  const dirty = useRef(false);

  const say = useCallback((m: string) => { setToast(m); window.setTimeout(() => setToast((t) => (t === m ? null : t)), 3200); }, []);
  const update = useCallback((fn: (s: AppState) => AppState) => { dirty.current = true; setState((p) => { const n = fn(p); return n === p ? p : unlockNew({ ...n, rev: p.rev + 1 }, Date.now()); }); }, []);

  // Load once on the client.
  useEffect(() => {
    const kv = browserKV();
    kvRef.current = kv;
    const r = loadState(kv);
    setState(r.state); setStorageOk(kv !== null); setLoadMessage(r.message ?? null); setReady(true);
    setOnline(navigator.onLine);
    const on = () => setOnline(true), off = () => setOnline(false);
    window.addEventListener("online", on); window.addEventListener("offline", off);
    // Another tab wrote newer data: adopt it instead of overwriting it.
    const onStorage = (e: StorageEvent) => {
      if (e.key !== STORAGE_KEY || !e.newValue) return;
      try { const s = sanitizeState(JSON.parse(e.newValue)); if (s) { dirty.current = false; setState((p) => (s.rev > p.rev ? s : p)); } } catch { /* ignore */ }
    };
    window.addEventListener("storage", onStorage);
    if (import.meta.env.PROD && "serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); window.removeEventListener("storage", onStorage); };
  }, []);

  useEffect(() => {
    if (!ready || !dirty.current) return;
    const res = saveState(kvRef.current, state);
    setStorageOk(res.ok);
  }, [state, ready]);

  // Browser/Android back button support.
  const nav = useCallback((v: View, opts?: { replace?: boolean }) => {
    setView((cur) => { if (!opts?.replace) stack.current.push(cur); return v; });
    if (!opts?.replace) window.history.pushState({ qx: stack.current.length }, "");
    window.scrollTo({ top: 0 });
  }, []);
  const back = useCallback(() => {
    if (stack.current.length === 0) {
      setView({ name: "home" });
      window.scrollTo({ top: 0 });
      return;
    }
    // Let popstate update the in-app stack as well as the visible screen.
    // Previously the app popped its own stack but left the browser history
    // entry behind, so the next Android/browser Back could skip a screen.
    window.history.back();
  }, []);
  useEffect(() => {
    const onPop = () => { const prev = stack.current.pop(); setView(prev ?? { name: "home" }); };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  // Resume / auto-submit an exam that expired while the app was closed.
  useEffect(() => {
    if (!ready) return;
    setState((p) => {
      const a = p.active;
      if (a && a.kind === "exam" && S.isExpired(a, Date.now())) return finalize(p, S.submit(a, Date.now(), "timeout"), Date.now());
      return p;
    });
  }, [ready]);

  const start = useCallback(async (p: StartParams) => {
    setBusy("Preparing questions…");
    await new Promise((r) => window.setTimeout(r, 30));
    try {
      const st = state; const { board, grade } = st.profile; const now = Date.now(); const today = dateKeyOf(now);
      let plan: Plan; let title: string; let kind: SessionKind = p.kind; let durationSec: number | undefined; let dateKey: string | undefined;
      switch (p.kind) {
        case "practice": plan = planTopic(st, p.topic, p.count); title = "Topic practice"; break;
        case "quick": plan = planQuick(st, p.topics, p.count); title = "Quick practice"; break;
        case "adaptive": plan = planAdaptive(st, board, grade, p.count, today, p.subjectId); title = "Adaptive practice"; break;
        case "revision": plan = planRevision(st, p.count, today); title = "Revision"; break;
        case "mixed": plan = planMixed(st, board, grade, p.count); title = "Mixed challenge"; break;
        case "daily": plan = planDaily(today, board, grade); title = "Daily challenge"; dateKey = today; break;
        case "exam": plan = planExam(board, grade, p.count, newId("seed"), p.subjectIds); title = `Mock test · ${p.count} questions`; durationSec = p.minutes * 60; break;
      }
      if (plan.items.length === 0) { say(plan.notes[0] ?? "No questions are available for that selection yet."); return; }
      const session = S.newSession({ id: newId(kind), kind, title, board, grade, items: plan.items, now, durationSec, notes: plan.notes, dateKey });
      update((s) => {
        let n: AppState = { ...s, active: session };
        for (const [tk, by] of Object.entries(plan.cursorAdvance)) n = advanceCursor(n, tk, by);
        return n;
      });
      nav({ name: "session" }, { replace: false });
    } finally { setBusy(null); }
  }, [state, nav, say, update]);

  const patchActive = useCallback((fn: (a: Session) => Session) => update((s) => (s.active ? { ...s, active: fn(s.active) } : s)), [update]);

  const answer = useCallback((i: number, r: Response) => {
    update((s) => {
      const a = s.active; if (!a || a.status !== "active") return s;
      const q = resolveQuestion(a.items[i]!.key); if (!q) return s;
      const now = Date.now();
      if (a.kind === "exam") return { ...s, active: S.setExamResponse(a, i, r, now) };
      const next = S.answerPractice(a, i, q, r, now);
      if (next === a) return s;
      const ans = next.answers[i]!;
      const withSession = { ...s, active: next };
      const recorded = recordAnswer(withSession, { eventId: `${a.id}:${i}`, key: q.id, board: q.board, grade: q.grade, subjectId: q.subjectId, topicId: q.topicId, correct: ans.correct, hinted: ans.hinted, revealed: false, xp: S.xpForItem(next, i), now, streakAfter: S.streakAfter(next, i) });
      return recordExposure(recorded, q, a.id, now);
    });
  }, [update]);

  const clear = useCallback((i: number) => patchActive((a) => S.setExamResponse(a, i, null, Date.now())), [patchActive]);
  const reveal = useCallback((i: number) => {
    update((s) => {
      const a = s.active; if (!a || a.status !== "active" || a.kind === "exam") return s;
      const q = resolveQuestion(a.items[i]!.key); if (!q) return s;
      const next = S.revealPractice(a, i, Date.now());
      if (next === a) return s;
      const now = Date.now();
      const recorded = recordAnswer({ ...s, active: next }, { eventId: `${a.id}:${i}`, key: q.id, board: q.board, grade: q.grade, subjectId: q.subjectId, topicId: q.topicId, correct: false, hinted: false, revealed: true, xp: 0, now });
      return recordExposure(recorded, q, a.id, now);
    });
  }, [update]);
  const hint = useCallback((i: number) => patchActive((a) => S.useHint(a, i)), [patchActive]);
  const mark = useCallback((i: number) => patchActive((a) => S.toggleMark(a, i)), [patchActive]);
  const goto = useCallback((i: number) => patchActive((a) => S.goTo(a, i)), [patchActive]);

  const submitExam = useCallback((reason: "manual" | "timeout" = "manual") => {
    update((s) => {
      const a = s.active; if (!a || a.status === "submitted") return s;
      return finalize(s, S.submit(a, Date.now(), reason), Date.now());
    });
  }, [update]);
  const finishPractice = useCallback(() => {
    update((s) => {
      const a = s.active; if (!a || a.status === "submitted") return s;
      const done = S.submit(a, Date.now());
      return finalize(s, done, Date.now());
    });
  }, [update]);
  const dismissActive = useCallback(() => { update((s) => ({ ...s, active: null })); nav({ name: "home" }, { replace: true }); stack.current = []; }, [update, nav]);

  const value = useMemo<Store>(() => ({
    ready, state, view, busy, toast, storageOk, loadMessage, online, nav, back, say,
    patchProfile: (p) => update((s) => ({ ...s, profile: { ...s.profile, ...p } })),
    start, answer, clear, reveal, hint, mark, goto, submitExam, finishPractice, dismissActive,
    bookmark: (k) => update((s) => toggleBookmark(s, k)),
    addMistake: (k) => { update((s) => addToMistakes(s, k, Date.now())); say("Added to your mistakes notebook."); },
    report: (k, reason) => { update((s) => reportQuestion(s, k, reason, Date.now())); say("Thanks — the report is saved on this device."); },
    qNote: (k, t) => update((s) => setQuestionNote(s, k, t)),
    chapterNote: (tk, t) => update((s) => setChapterNote(s, tk, t)),
    cardReview: (id, ref, ok) => update((s) => reviewCard(ensureCard(s, id, ref, Date.now()), id, ok, Date.now())),
    ensureCards: (ids) => update((s) => ids.reduce((acc, c) => ensureCard(acc, c.id, c.ref, Date.now()), s)),
    exportJson: () => exportState(state),
    importJson: (text) => {
      const r = importState(text);
      if (!r.ok) return r.error;
      dirty.current = true; setState({ ...r.state, rev: state.rev + 1 }); return null;
    },
    resetData: () => { resetAll(kvRef.current); dirty.current = false; setState(defaultState()); stack.current = []; setView({ name: "home" }); },
  }), [ready, state, view, busy, toast, storageOk, loadMessage, online, nav, back, say, update, start, answer, clear, reveal, hint, mark, goto, submitExam, finishPractice, dismissActive]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

function finalize(s: AppState, done: Session, now: number): AppState {
  const result = S.computeResult(done);
  let n: AppState = { ...s, active: done };
  if (done.kind === "exam") {
    // Exam answers are recorded only now, once, with no per-answer XP.
    done.items.forEach((it, i) => {
      const a = done.answers[i]; const q = resolveQuestion(it.key);
      if (!q || !a?.response) return;
      n = recordAnswer(n, { eventId: `${done.id}:${i}`, key: q.id, board: q.board, grade: q.grade, subjectId: q.subjectId, topicId: q.topicId, correct: a.correct, hinted: false, revealed: false, xp: 0, now });
      n = recordExposure(n, q, done.id, now);
    });
    // Skipped questions go to the notebook so they can be revised.
    done.items.forEach((it, i) => { if (!done.answers[i]?.response) n = addToMistakes(n, it.key, now); });
  }
  return finishSessionState(n, done, result, now);
}
