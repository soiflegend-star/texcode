# QUBRIX Android application

The Android application project is in `android/`. The existing QUBRIX React/TypeScript and PRISM source remains at the repository root and is not discarded.

## Build the Android APK

Requirements:
- Android SDK Platform 35 and Build Tools 35.0.0
- JDK 17
- Internet access on the first build (the included Gradle bootstrap script downloads Gradle 8.9)

From the repository root:

```sh
cd android
./gradlew :app:assembleDebug
```

Windows:

```bat
cd android
gradlew.bat :app:assembleDebug
```

APK output:

`android/app/build/outputs/apk/debug/app-debug.apk`

You can also open the `android/` directory in Android Studio and sync the Gradle project.

## Application behavior

- Package: `com.qubrix.app`
- Minimum Android: API 23
- Compile/target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9

The native Android shell can be installed and launched without a deployed QUBRIX server. On first launch it shows a setup screen asking for the HTTPS address of the deployed QUBRIX service. The existing React/PRISM experience and server-backed authentication/data require that service to be deployed; they are not falsely represented as offline features in the APK.

The app enables JavaScript and DOM storage for the existing web client, supports first-party cookies, rejects cleartext HTTP and mixed content, disables local file/content access, and handles Android back navigation.

## GitHub build

The `.github/workflows/android.yml` workflow installs JDK 17 and Android SDK Platform 35, runs `:app:assembleDebug`, and publishes `app-debug.apk` as the `qubrix-debug-apk` artifact. No server URL is needed to compile the APK.

## Scope

This is a native Android WebView host for the existing server-backed QUBRIX application. It is a real installable Android package, but it does not turn server routes, authentication, or database operations into offline native functionality. A deployment URL is only needed at runtime to use those existing features, not at build time.
