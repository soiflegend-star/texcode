# QUBRIX source fixes

This update changes application code and tests. It does not change GitHub Actions or any workflow files.

## Fixed

- PRISM adaptive signals now parse the same colon-delimited topic keys that QUBRIX stores (`board:grade:subject:topic`). The previous delimiter mismatch caused subject-scoped topic signals to be skipped.
- Recent accuracy is aggregated across the matching topic histories instead of being overwritten by whichever topic happened to be iterated last.
- Subject-scoped overall accuracy now comes from that subject's topic statistics, with the global total used only when no scoped history exists.
- Adaptive practice now uses PRISM's learner signals and candidate scoring when choosing topic weights and the initial difficulty target for topics with limited history.
- Existing progress from saves created before the PRISM exposure ledger is upgraded into fingerprint-aware novelty checks when the question can be resolved.
- Adaptive sessions mark due-review questions with the same multi-level seen markers as the rest of the session, preventing structural duplicates from slipping into the same session.
- The in-app Back action now delegates to browser history so Android/browser Back and the app's own navigation stack stay synchronized.
- The main test command now includes the PRISM regression tests, and a dedicated `test:prism` script is available.

## Verification performed

- PRISM tests: 22 passed, 0 failed.
- Adaptive-selection regression test: 1 passed, 0 failed.
- Quiz engine tests: 21 passed, 0 failed.
- Curriculum tests: 3 passed, 0 failed.
- Content validation tests: 14 passed, 0 failed; the content report test takes about 38 seconds in this environment.

## Not verified here

A full TypeScript check and Vite production build could not be run because dependencies could not be installed in this environment. The supplied GitHub log itself stops at a missing working directory before the application build starts, so it contains no TypeScript or application compiler error to diagnose.
