package com.texgen.music.texwave.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.texgen.music.texwave.data.Album
import com.texgen.music.texwave.data.AppSettings
import com.texgen.music.texwave.data.ArtistGroup
import com.texgen.music.texwave.data.LastSession
import com.texgen.music.texwave.data.LibraryStore
import com.texgen.music.texwave.data.AlchemistPreset
import com.texgen.music.texwave.data.EmotionMode
import com.texgen.music.texwave.data.FocusGoal
import com.texgen.music.texwave.data.MemoryNote
import com.texgen.music.texwave.data.MusicRepository
import com.texgen.music.texwave.data.NetworkGate
import com.texgen.music.texwave.data.OfflineAssistant
import com.texgen.music.texwave.data.PhantomEngine
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.data.Playlist
import com.texgen.music.texwave.data.ThemeCatalog
import com.texgen.music.texwave.notification.NotifMedia
import com.texgen.music.texwave.notification.NotifVideoFrames
import com.texgen.music.texwave.player.EqualizerController
import com.texgen.music.texwave.player.PlaybackConnection
import com.texgen.music.texwave.ui.theme.Tx
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class LibraryState(
    val songs: List<Song> = emptyList(),
    val loading: Boolean = false,
    val scanned: Boolean = false,
    val error: String? = null,
    val liked: Set<Long> = emptySet(),
    val playlists: List<Playlist> = emptyList(),
    val recents: List<Long> = emptyList(),
    val playCounts: Map<Long, Int> = emptyMap(),
    val blacklist: Set<Long> = emptySet(),
    val sortMode: SortMode = SortMode.DATE_ADDED,
    val sortAsc: Boolean = false,
    val gridView: Boolean = false,
)

enum class SortMode(val label: String, val defaultAsc: Boolean) {
    DATE_ADDED("Date added", false),
    TITLE("A–Z", true),
    DURATION("Length", false),
    ARTIST("Artist", true),
    ALBUM("Album", true),
    MOST_PLAYED("Most played", false),
}

data class SettingsState(
    val themeId: String = "default",
    val notifStyleId: String = "default",
    val customArt: Map<Long, String> = emptyMap(),
    val notifCustomUri: String? = null,
    val playerBackgroundUri: String? = null,
    val speed: Float = 1f,
    val crossfade: Boolean = false,
    val vinylMode: Boolean = false,
    val gapless: Boolean = true,
    val sleepTimerMinutes: Int? = null,
    val skipSilence: Boolean = false,
    val seekStepSec: Int = 10,
    val notifSoif: Boolean = false,
    val notifSoifStyled: Boolean = false,
    val notifVideoFrames: Int = 0,
    val notifVideoBusy: Boolean = false,
    val particles: Boolean = true,
    val reactiveViz: Boolean = false,
    val wakeEnabled: Boolean = false,
    val wakeWord: String = "phantom",
    val wakeSilenceMs: Int = 2000,
    val snowOverlay: Boolean = false,
)

class MusicViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MusicRepository(app)
    private val store = LibraryStore(app)
    private val settingsStore = AppSettings(app)
    private val phantom = PhantomEngine(app)
    private val connection = PlaybackConnection(app)
    val equalizer = EqualizerController(settingsStore)

    /** Background loops must never be able to kill the app. */
    private val safe = kotlinx.coroutines.CoroutineExceptionHandler { _, t ->
        com.texgen.music.texwave.CrashGuard.nonFatal("vm", t)
    }

    private val positions = store.loadPositions().toMutableMap()

    private val _lib = MutableStateFlow(
        LibraryState(
            liked = store.loadLiked(),
            playlists = store.loadPlaylists(),
            recents = store.loadRecents(),
            playCounts = store.loadPlayCounts(),
            blacklist = store.loadBlacklist(),
            sortMode = runCatching { SortMode.valueOf(settingsStore.loadSortMode()) }.getOrDefault(SortMode.DATE_ADDED),
            sortAsc = settingsStore.loadSortAsc(),
        )
    )
    val lib: StateFlow<LibraryState> = _lib.asStateFlow()
    val player = connection.state
    val position = connection.position

    private val _settings = MutableStateFlow(
        SettingsState(
            themeId = settingsStore.loadThemeId(),
            notifStyleId = settingsStore.loadNotifStyleId(),
            customArt = settingsStore.loadCustomArt(),
            notifCustomUri = settingsStore.loadNotifCustomUri(),
            speed = settingsStore.loadSpeed(),
            crossfade = settingsStore.loadCrossfade(),
            vinylMode = settingsStore.loadVinylMode(),
            gapless = settingsStore.loadGapless(),
            skipSilence = settingsStore.loadSkipSilence(),
            notifSoif = settingsStore.loadNotifSoif(),
            notifSoifStyled = settingsStore.loadNotifSoifStyled(),
            notifVideoFrames = settingsStore.loadNotifVideoFrames(),
            particles = settingsStore.loadParticles(),
            reactiveViz = settingsStore.loadReactiveViz(),
            wakeEnabled = settingsStore.loadWakeEnabled(),
            wakeWord = settingsStore.loadWakeWord(),
            wakeSilenceMs = settingsStore.loadWakeSilenceMs(),
            snowOverlay = settingsStore.loadSnowOverlay(),
            playerBackgroundUri = settingsStore.loadPlayerBackgroundUri(),
        )
    )
    val settings: StateFlow<SettingsState> = _settings.asStateFlow()

    private var lastTrackedId: Long? = null

    init {
        try {
            Tx.apply(ThemeCatalog.byId(settingsStore.loadThemeId()))
        } catch (_: Exception) {
        }
        try {
            com.texgen.music.texwave.player.PlaybackService.skipSilence = settingsStore.loadSkipSilence()
        } catch (_: Exception) {
        }
        // Connect media only after UI has settled (OEM permission transitions crash if too early)
        viewModelScope.launch(safe) {
            try {
                kotlinx.coroutines.delay(2000)
                if (!com.texgen.music.texwave.CrashGuard.safeMode) {
                    connection.connect()
                }
            } catch (_: Exception) {
            }
        }

        viewModelScope.launch(safe) {
            while (true) {
                if (player.value.isPlaying) {
                    connection.tick()
                    player.value.current?.let { s -> positions[s.id] = position.value }
                    delay(400)
                } else {
                    delay(800)
                }
            }
        }

        viewModelScope.launch(safe) {
            player.map { it.current?.id }.distinctUntilChanged().collect { id ->
                if (id != null) {
                    addRecent(id)
                    bumpPlayCount(id)
                    // Resume saved position if jumping to a track with progress
                    val saved = positions[id]
                    if (saved != null && saved > 5_000 && lastTrackedId != id) {
                        // only auto-seek if not already near start
                        if (position.value < 2_000) connection.seekTo(saved)
                    }
                    lastTrackedId = id
                    // Auto lyrics: LRCLIB, then Groq if key is active
                    val song = player.value.current
                    if (song != null) {
                        launch(safe) {
                            runCatching {
                                com.texgen.music.texwave.data.LyricsEngine.load(
                                    getApplication(),
                                    song,
                                    phantom.groq.takeIf { it.hasKey() },
                                )
                            }
                        }
                    }
                }
            }
        }

        viewModelScope.launch(safe) {
            kotlinx.coroutines.delay(3000)
            while (true) {
                try {
                    if (!com.texgen.music.texwave.CrashGuard.safeMode) {
                        val sid = connection.audioSessionId()
                        if (sid != 0) equalizer.attach(sid)
                    }
                } catch (_: Exception) {
                }
                delay(2500)
            }
        }

        // Persist session periodically
        viewModelScope.launch(safe) {
            while (true) {
                delay(5_000)
                persistSession()
            }
        }
    }

    // ---- Library --------------------------------------------------------------------

    fun scanLibrary() {
        if (_lib.value.loading) return
        _lib.update { it.copy(loading = true, error = null) }
        viewModelScope.launch(safe) {
            try {
                val list = withContext(Dispatchers.IO) { repo.loadAllSongs() }
                val ids = list.map { it.id }.toSet()
                connection.updateLibrary(list)
                _lib.update {
                    it.copy(
                        songs = applySort(list, it.sortMode, it.sortAsc, it.playCounts),
                        loading = false,
                        scanned = true,
                        liked = it.liked.filter { id -> id in ids }.toSet(),
                        recents = it.recents.filter { id -> id in ids },
                        playlists = it.playlists.map { p -> p.copy(songIds = p.songIds.filter { id -> id in ids }) },
                        error = if (list.isEmpty()) "No music found on this device." else null,
                    )
                }
                // Offer resume
                restoreSessionIfNeeded(list)
            } catch (t: Throwable) {
                _lib.update { it.copy(loading = false, scanned = true, error = t.message ?: "Scan failed") }
            }
        }
    }

    private fun restoreSessionIfNeeded(songs: List<Song>) {
        if (com.texgen.music.texwave.CrashGuard.safeMode) return
        try {
            val session = store.loadLastSession() ?: return
            val byId = songs.associateBy { it.id }
            val queue = session.queueIds.mapNotNull { byId[it] }
            if (queue.isEmpty()) return
            val idx = session.queueIndex.coerceIn(0, queue.lastIndex)
            // Load paused: no playback and no foreground service at launch.
            connection.load(queue, idx, session.positionMs)
        } catch (t: Throwable) {
            com.texgen.music.texwave.CrashGuard.nonFatal("restore", t)
        }
    }

    private fun persistSession() {
        val st = player.value
        if (!st.isPlaying) return
        val song = st.current ?: return
        store.saveLastSession(
            LastSession(
                songId = song.id,
                positionMs = position.value,
                queueIds = st.queue.map { it.id },
                queueIndex = st.queueIndex.coerceAtLeast(0),
            )
        )
        store.savePositions(positions)
    }

    private fun applySort(songs: List<Song>, mode: SortMode, asc: Boolean, counts: Map<Long, Int>): List<Song> {
        val byTitle = compareBy<Song> { it.title.lowercase() }
        val cmp: Comparator<Song> = when (mode) {
            SortMode.TITLE -> byTitle
            SortMode.ARTIST -> compareBy<Song> { it.artist.lowercase() }.then(byTitle)
            SortMode.ALBUM -> compareBy<Song> { it.album.lowercase() }.thenBy { it.trackNumber }.then(byTitle)
            SortMode.DATE_ADDED -> compareBy<Song> { it.dateAdded }.then(byTitle)
            SortMode.DURATION -> compareBy<Song> { it.durationMs }.then(byTitle)
            SortMode.MOST_PLAYED -> compareBy<Song> { counts[it.id] ?: 0 }.then(byTitle)
        }
        return songs.sortedWith(if (asc) cmp else cmp.reversed())
    }

    /** Tapping the active mode flips its direction; tapping another mode uses that mode's natural direction. */
    fun setSortMode(mode: SortMode) {
        _lib.update {
            val asc = if (it.sortMode == mode) !it.sortAsc else mode.defaultAsc
            settingsStore.saveSort(mode.name, asc)
            it.copy(sortMode = mode, sortAsc = asc, songs = applySort(it.songs, mode, asc, it.playCounts))
        }
    }

    fun toggleGridView() {
        _lib.update { it.copy(gridView = !it.gridView) }
    }

    // ---- Playback -------------------------------------------------------------------

    fun playResonanceOrDownload(
        title: String,
        artist: String,
        storagePath: String?,
        chatRepo: com.texgen.music.texwave.data.chat.ChatRepository,
    ) {
        val all = _lib.value.songs
        val hit = all.firstOrNull {
            it.title.equals(title, true) ||
                (it.title.contains(title, true) && (artist.isBlank() || it.artist.contains(artist, true)))
        } ?: all.firstOrNull { it.title.contains(title.take(16), true) }
        if (hit != null) {
            playSongs(all, all.indexOfFirst { it.id == hit.id }.coerceAtLeast(0))
            return
        }
        if (storagePath.isNullOrBlank()) return
        viewModelScope.launch(safe) {
            chatRepo.downloadResonanceAudio(storagePath)
                .onSuccess { bytes ->
                    // Persist into Music/TEXWAVE so it survives and appears in library for everyone
                    val saved = saveResonanceToLibrary(bytes, title, artist)
                    playExternalFile(saved, title, artist)
                    // Soft-refresh library so the new track shows up
                    try { scanLibrary() } catch (_: Exception) {}
                }
        }
    }

    /** Write resonance audio into public Music folder and register with MediaStore. */
    private fun saveResonanceToLibrary(bytes: ByteArray, title: String, artist: String): String {
        val app = getApplication<android.app.Application>()
        val safeTitle = title.replace(Regex("[^a-zA-Z0-9._ -]"), "_").trim().take(48).ifBlank { "Resonance" }
        val safeArtist = artist.replace(Regex("[^a-zA-Z0-9._ -]"), "_").trim().take(32).ifBlank { "TEXWAVE" }
        val fileName = "${safeArtist} - ${safeTitle}.m4a"

        // Prefer Music/TEXWAVE on shared storage
        val musicRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_MUSIC,
        )
        val dir = java.io.File(musicRoot, "TEXWAVE")
        if (!dir.exists()) dir.mkdirs()
        val out = java.io.File(dir, fileName)
        out.writeBytes(bytes)

        // Register in MediaStore so scanners / our library pick it up
        try {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.Audio.Media.TITLE, title)
                put(android.provider.MediaStore.Audio.Media.ARTIST, artist.ifBlank { "Resonance" })
                put(android.provider.MediaStore.Audio.Media.ALBUM, "TEXWAVE Resonance")
                put(android.provider.MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(android.provider.MediaStore.Audio.Media.IS_MUSIC, 1)
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    put(android.provider.MediaStore.Audio.Media.RELATIVE_PATH, "Music/TEXWAVE")
                    put(android.provider.MediaStore.Audio.Media.IS_PENDING, 0)
                } else {
                    put(android.provider.MediaStore.Audio.Media.DATA, out.absolutePath)
                }
            }
            val uri = app.contentResolver.insert(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                values,
            )
            if (uri != null && android.os.Build.VERSION.SDK_INT >= 29) {
                app.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            }
            // Trigger media scan for older APIs
            android.media.MediaScannerConnection.scanFile(
                app, arrayOf(out.absolutePath), arrayOf("audio/mp4"), null,
            )
        } catch (_: Exception) {
            // still play from file path
        }
        return out.absolutePath
    }

    fun playExternalFile(path: String, title: String, artist: String) {
        val song = Song(
            id = path.hashCode().toLong() and 0x7FFFFFFFFFFFFFFFL,
            title = title,
            artist = artist.ifBlank { "Resonance" },
            album = "TEXWAVE Resonance",
            albumId = 0L,
            durationMs = 0L,
            dateAdded = System.currentTimeMillis() / 1000,
            contentUri = android.net.Uri.fromFile(java.io.File(path)).toString(),
            path = path,
        )
        connection.play(listOf(song), 0, startPositionMs = 0L)
    }

    fun playSongs(list: List<Song>, index: Int, resume: Boolean = false) {
        // The tapped song is identified by id, NOT by position: hiding songs (blacklist) shifts
        // positions and used to make a different song play than the one that was tapped.
        if (list.isEmpty()) return
        val tapped = list.getOrNull(index.coerceIn(0, list.lastIndex.coerceAtLeast(0)))
        val hidden = _lib.value.blacklist
        val filtered = list.filter { it.id !in hidden || it.id == tapped?.id }.ifEmpty { list }
        if (filtered.isEmpty()) return
        val start = (tapped?.let { t -> filtered.indexOfFirst { it.id == t.id } } ?: 0).coerceAtLeast(0)
        val song = filtered.getOrNull(start)
        // Only resume mid-track when explicitly requested (session restore).
        // Library / search taps always start at 0 so play never "fails" near the end.
        val pos = if (resume) {
            song?.let { positions[it.id] }?.takeIf { it > 5_000 && it < (song.durationMs - 10_000) } ?: 0L
        } else 0L
        // Ensure media session is connected before issuing play
        connection.connect()
        connection.play(filtered, start, startPositionMs = pos)
    }

    fun shuffleAll(list: List<Song> = _lib.value.songs) {
        val filtered = list.filter { it.id !in _lib.value.blacklist }.ifEmpty { list }
        if (filtered.isEmpty()) return
        connection.play(filtered, filtered.indices.random(), shuffle = true)
    }

    fun playShuffled(list: List<Song>) = shuffleAll(list)

    fun togglePlay() = connection.togglePlay()
    fun next() {
        recordSkipCurrent()
        val q = player.value.queue
        val idx = player.value.queueIndex
        if (q.size > 1 && idx >= 0 && idx < q.lastIndex) {
            // Clear saved position so next song starts clean
            q.getOrNull(idx + 1)?.id?.let { positions.remove(it) }
            connection.skipTo(idx + 1)
            return
        }
        val all = _lib.value.songs.filter { it.id !in _lib.value.blacklist }
        val cur = player.value.current
        if (all.isEmpty() || cur == null) {
            connection.next()
            return
        }
        val i = all.indexOfFirst { it.id == cur.id }
        val nextIdx = when {
            i >= 0 && i < all.lastIndex -> i + 1
            i == all.lastIndex -> 0
            else -> -1
        }
        if (nextIdx >= 0) playSongs(all, nextIdx)
        else connection.next()
    }
    fun previous() {
        // Always jump to the previous song in ONE tap (never restart current first).
        val q = player.value.queue
        val idx = player.value.queueIndex.coerceAtLeast(0)
        if (q.size > 1) {
            val target = if (idx > 0) idx - 1 else q.lastIndex
            positions.remove(q[target].id)
            // Also drop current resume so we don't bounce back mid-track later
            q.getOrNull(idx)?.id?.let { positions.remove(it) }
            connection.skipTo(target)
            return
        }
        val all = _lib.value.songs.filter { it.id !in _lib.value.blacklist }
        val cur = player.value.current
        if (all.isEmpty() || cur == null) {
            connection.previous()
            return
        }
        val i = all.indexOfFirst { it.id == cur.id }
        val prevIdx = when {
            i > 0 -> i - 1
            i == 0 -> all.lastIndex
            else -> -1
        }
        if (prevIdx >= 0) {
            positions.remove(all[prevIdx].id)
            positions.remove(cur.id)
            playSongs(all, prevIdx)
        } else connection.previous()
    }
    fun seekTo(ms: Long) = connection.seekTo(ms)
    fun skipTo(index: Int) = connection.skipTo(index)
    fun toggleShuffle() = connection.toggleShuffle()
    fun cycleRepeat() = connection.cycleRepeat()
    fun playNext(song: Song) = connection.playNext(song)
    fun addToQueue(song: Song) = connection.addToQueue(song)
    fun removeFromQueue(index: Int) = connection.removeFromQueue(index)
    fun clearQueue() = connection.clearQueue()
    fun seekForward() = connection.seekBy(_settings.value.seekStepSec * 1000L)
    fun seekBackward() = connection.seekBy(-_settings.value.seekStepSec * 1000L)

    fun playAlbum(album: Album, index: Int = 0) = playSongs(album.songs, index)
    fun playArtist(artist: ArtistGroup, index: Int = 0) = playSongs(artist.songs, index)

    fun playSimilar(song: Song) {
        val neighbors = phantom.universeNeighbors(song, _lib.value.songs, limit = 24)
        val queue = (listOf(song) + neighbors).distinctBy { it.id }
        playSongs(queue, 0)
    }

    fun queueRestOfAlbum(song: Song) {
        val albumSongs = _lib.value.songs
            .filter { it.albumId == song.albumId }
            .sortedBy { it.trackNumber }
        val idx = albumSongs.indexOfFirst { it.id == song.id }
        if (idx >= 0) {
            albumSongs.drop(idx + 1).forEach { connection.addToQueue(it) }
        }
    }

    // ---- Likes / playlists / history / counts ---------------------------------------

    fun toggleLike(id: Long) {
        _lib.update {
            val next = if (id in it.liked) it.liked - id else it.liked + id
            store.saveLiked(next)
            it.copy(liked = next)
        }
    }

    fun toggleBlacklist(id: Long) {
        _lib.update {
            val next = if (id in it.blacklist) it.blacklist - id else it.blacklist + id
            store.saveBlacklist(next)
            it.copy(blacklist = next)
        }
    }

    private fun bumpPlayCount(id: Long) {
        phantom.recordEnjoy(id)
        recordListenDay()
        _lib.update {
            val next = it.playCounts.toMutableMap()
            next[id] = (next[id] ?: 0) + 1
            store.savePlayCounts(next)
            it.copy(playCounts = next)
        }
    }

    fun createPlaylist(name: String, firstSongId: Long? = null): String {
        val playlist = Playlist(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifEmpty { "New playlist" },
            songIds = listOfNotNull(firstSongId),
        )
        _lib.update {
            val next = it.playlists + playlist
            store.savePlaylists(next)
            it.copy(playlists = next)
        }
        return playlist.id
    }

    fun deletePlaylist(id: String) = updatePlaylists { list -> list.filterNot { it.id == id } }

    fun addToPlaylist(playlistId: String, songId: Long) = updatePlaylists { list ->
        list.map { p ->
            if (p.id == playlistId && songId !in p.songIds) p.copy(songIds = p.songIds + songId) else p
        }
    }

    fun addManyToPlaylist(playlistId: String, songIds: List<Long>) = updatePlaylists { list ->
        list.map { p ->
            if (p.id == playlistId) p.copy(songIds = (p.songIds + songIds).distinct()) else p
        }
    }

    fun removeFromPlaylist(playlistId: String, songId: Long) = updatePlaylists { list ->
        list.map { p -> if (p.id == playlistId) p.copy(songIds = p.songIds - songId) else p }
    }

    private fun updatePlaylists(transform: (List<Playlist>) -> List<Playlist>) {
        _lib.update {
            val next = transform(it.playlists)
            store.savePlaylists(next)
            it.copy(playlists = next)
        }
    }

    private fun addRecent(id: Long) {
        _lib.update {
            val next = (listOf(id) + it.recents.filter { r -> r != id }).take(40)
            store.saveRecents(next)
            it.copy(recents = next)
        }
    }

    // ---- Derived library views ------------------------------------------------------

    fun albums(): List<Album> {
        return _lib.value.songs.groupBy { it.albumId }
            .map { (id, list) ->
                val first = list.first()
                Album(id, first.album, first.artist, list.size, list.sortedBy { it.trackNumber })
            }
            .sortedBy { it.name.lowercase() }
    }

    fun artists(): List<ArtistGroup> {
        return _lib.value.songs.groupBy { it.artist }
            .map { (name, list) ->
                ArtistGroup(name, list.size, list.map { it.albumId }.toSet().size, list)
            }
            .sortedBy { it.name.lowercase() }
    }

    fun folders(): List<Pair<String, List<Song>>> {
        return _lib.value.songs
            .filter { it.path.isNotBlank() }
            .groupBy { it.path.substringBeforeLast('/', missingDelimiterValue = "Root") }
            .map { (path, list) -> path to list.sortedBy { it.title.lowercase() } }
            .sortedBy { it.first.lowercase() }
    }

    fun topPlayed(limit: Int = 20): List<Song> {
        val counts = _lib.value.playCounts
        return _lib.value.songs.sortedByDescending { counts[it.id] ?: 0 }.take(limit)
            .filter { (counts[it.id] ?: 0) > 0 }
    }

    fun dailyMix(): List<Song> {
        val lib = _lib.value
        val ids = (lib.liked + lib.recents).distinct().shuffled()
        val byId = lib.songs.associateBy { it.id }
        return ids.mapNotNull { byId[it] }
            .filter { it.id !in lib.blacklist }
            .ifEmpty { lib.songs.filter { it.id !in lib.blacklist }.shuffled() }
            .take(30)
    }

    fun shareText(song: Song): String =
        "🎵 ${song.title}\n👤 ${song.artist}\n💿 ${song.album}\n— via Texwave"

    // ---- Settings -------------------------------------------------------------------

    fun setTheme(id: String) {
        settingsStore.saveThemeId(id)
        Tx.apply(ThemeCatalog.byId(id))
        _settings.update { it.copy(themeId = id) }
    }

    /** High-quality gallery background for the player / app surfaces. Copied into app storage at high res. */
    fun setPlayerBackground(source: android.net.Uri?) {
        viewModelScope.launch(safe) {
            val stored = if (source == null) null else withContext(Dispatchers.IO) {
                NotifMedia.importImage(getApplication(), source, "player-bg", maxSide = 2048, keepAspect = true)
            }
            if (source != null && stored == null) return@launch
            settingsStore.savePlayerBackgroundUri(stored)
            _settings.update { it.copy(playerBackgroundUri = stored) }
        }
    }

    fun clearPlayerBackground() = setPlayerBackground(null)

    fun setNotifStyle(id: String) {
        settingsStore.saveNotifStyleId(id)
        _settings.update { it.copy(notifStyleId = id) }
    }

    /** Sets (or with null, clears) the cover for one song. The picked image is copied into app storage. */
    fun setCustomArt(songId: Long, source: android.net.Uri?) {
        viewModelScope.launch(safe) {
            val stored = if (source == null) null else withContext(Dispatchers.IO) {
                NotifMedia.importImage(getApplication(), source, "song-$songId")
            }
            if (source != null && stored == null) return@launch
            settingsStore.setCustomArt(songId, stored)
            _settings.update { it.copy(customArt = settingsStore.loadCustomArt()) }
        }
    }

    fun clearCustomArt(songId: Long) = setCustomArt(songId, null)

    /** One image used for the whole notification ("Your Image" style). */
    fun setNotifImage(source: android.net.Uri?) {
        viewModelScope.launch(safe) {
            val stored = if (source == null) null else withContext(Dispatchers.IO) {
                NotifMedia.importImage(getApplication(), source, "notif")
            }
            if (source != null && stored == null) return@launch
            settingsStore.saveNotifCustomUri(stored)
            if (stored != null) settingsStore.saveNotifStyleId("custom")
            _settings.update {
                it.copy(notifCustomUri = stored, notifStyleId = if (stored != null) "custom" else it.notifStyleId)
            }
        }
    }

    /** Picks a video; ~20 frames are extracted and then played as the notification animation. */
    fun setNotifVideo(source: android.net.Uri?) {
        if (_settings.value.notifVideoBusy) return
        viewModelScope.launch(safe) {
            if (source == null) {
                withContext(Dispatchers.IO) { NotifVideoFrames.clear(getApplication()) }
                settingsStore.saveNotifVideoFrames(0)
                _settings.update { it.copy(notifVideoFrames = 0) }
                return@launch
            }
            _settings.update { it.copy(notifVideoBusy = true) }
            val n = withContext(Dispatchers.IO) { NotifVideoFrames.extract(getApplication(), source) }
            settingsStore.saveNotifVideoFrames(n)
            if (n > 0) settingsStore.saveNotifStyleId("video")
            _settings.update {
                it.copy(
                    notifVideoBusy = false,
                    notifVideoFrames = n,
                    notifStyleId = if (n > 0) "video" else it.notifStyleId,
                )
            }
        }
    }

    fun setNotifSoif(on: Boolean) {
        settingsStore.saveNotifSoif(on)
        _settings.update { it.copy(notifSoif = on) }
    }

    fun setNotifSoifStyled(on: Boolean) {
        settingsStore.saveNotifSoifStyled(on)
        _settings.update { it.copy(notifSoifStyled = on) }
    }

    fun setParticles(on: Boolean) {
        settingsStore.saveParticles(on)
        _settings.update { it.copy(particles = on) }
    }

    fun setWakeEnabled(on: Boolean) {
        settingsStore.saveWakeEnabled(on)
        _settings.update { it.copy(wakeEnabled = on) }
    }
    fun setWakeWord(word: String) {
        val w = word.trim().lowercase().ifBlank { "phantom" }
        settingsStore.saveWakeWord(w)
        _settings.update { it.copy(wakeWord = w) }
    }
    fun setSnowOverlay(on: Boolean) {
        settingsStore.saveSnowOverlay(on)
        _settings.update { it.copy(snowOverlay = on) }
    }

    fun setWakeSilenceMs(ms: Int) {
        settingsStore.saveWakeSilenceMs(ms)
        _settings.update { it.copy(wakeSilenceMs = ms) }
    }

    fun setReactiveViz(on: Boolean) {
        settingsStore.saveReactiveViz(on)
        _settings.update { it.copy(reactiveViz = on) }
    }

    fun setSpeed(speed: Float) {
        settingsStore.saveSpeed(speed)
        _settings.update { it.copy(speed = speed) }
        connection.setPlaybackSpeed(speed)
    }

    fun toggleVinyl() {
        val next = !_settings.value.vinylMode
        settingsStore.saveVinylMode(next)
        _settings.update { it.copy(vinylMode = next) }
    }

    fun setCrossfade(on: Boolean) {
        settingsStore.saveCrossfade(on)
        _settings.update { it.copy(crossfade = on) }
    }

    fun setGapless(on: Boolean) {
        settingsStore.saveGapless(on)
        _settings.update { it.copy(gapless = on) }
    }

    fun setSkipSilence(on: Boolean) {
        settingsStore.saveSkipSilence(on)
        _settings.update { it.copy(skipSilence = on) }
        com.texgen.music.texwave.player.PlaybackService.skipSilence = on
    }

    fun setSleepTimer(minutes: Int?) {
        _settings.update { it.copy(sleepTimerMinutes = minutes) }
        if (minutes != null && minutes > 0) {
            viewModelScope.launch(safe) {
                delay(minutes * 60_000L)
                if (_settings.value.sleepTimerMinutes == minutes) {
                    connection.pause()
                    _settings.update { it.copy(sleepTimerMinutes = null) }
                }
            }
        }
    }

    
    // ---- PHANTOM ----------------------------------------------------------------

    fun emotionMix(mode: EmotionMode): List<Song> =
        phantom.emotionMixLocal(mode, _lib.value.songs, _lib.value.liked)

    fun playEmotion(mode: EmotionMode) {
        viewModelScope.launch(safe) {
            // If the user has manually added songs to this mood, play ONLY those.
            // Otherwise fall back to the smart auto-mix.
            val assigned = phantom.emotionAssignedSongs(mode, _lib.value.songs)
            val mix = if (assigned.isNotEmpty()) {
                assigned
            } else {
                phantom.emotionMixBest(
                    mode, _lib.value.songs, _lib.value.liked, _lib.value.playCounts
                )
            }
            if (mix.isNotEmpty()) {
                // Clear positions so mood sessions always start clean
                mix.forEach { positions.remove(it.id) }
                playSongs(mix, 0)
            }
        }
    }

    /** Add the current (or given) song to a MoodWave session. */
    fun addSongToMood(mode: EmotionMode, songId: Long) {
        phantom.saveEmotionLike(mode.id, songId)
    }

    fun feedbackEmotion(mode: EmotionMode, songId: Long) {
        phantom.saveEmotionLike(mode.id, songId)
    }

    fun infiniteMixPlay(list: List<Song> = _lib.value.songs) {
        viewModelScope.launch(safe) {
            val pool = list.filter { it.id !in _lib.value.blacklist }
            val mix = phantom.infiniteMixBest(pool, _lib.value.liked, _lib.value.playCounts)
            if (mix.isNotEmpty()) playSongs(mix, 0)
        }
    }

    fun musicDna() = phantom.musicDnaLocal(_lib.value.songs)

    fun similarTracks(song: Song) = phantom.universeNeighbors(song, _lib.value.songs)

    fun saveMemory(songId: Long, note: String) {
        phantom.saveMemory(MemoryNote(songId, note.trim()))
    }

    fun memoryFor(songId: Long) = phantom.memoryFor(songId)

    fun addBookmark(positionMs: Long) {
        val id = player.value.current?.id ?: return
        phantom.addBookmark(id, positionMs)
    }

    fun bookmarksForCurrent(): List<Long> {
        val id = player.value.current?.id ?: return emptyList()
        return phantom.loadBookmarks(id)
    }

    fun soundProfiles() = phantom.loadProfiles()


    
    fun isOnline(): Boolean = NetworkGate.isOnline(getApplication())
    private val _groqKeyPresent = MutableStateFlow(phantom.groq.hasKey())
    val groqKeyPresent: StateFlow<Boolean> = _groqKeyPresent.asStateFlow()

    fun saveGroqKey(key: String) {
        phantom.groq.apiKey = key
        _groqKeyPresent.value = phantom.groq.hasKey()
    }

    fun hasGroqKey(): Boolean = phantom.groq.hasKey()

    /**
     * PHANTOM Chat: web lookup (when useful) + Groq answer.
     * Requires internet + API key.
     */
    suspend fun phantomChat(
        userText: String,
        history: List<Pair<String, String>>,
    ): Result<String> {
        val q = userText.trim()
        if (q.isBlank()) return Result.success("")

        // 1) Offline brain — always first (works with zero internet)
        val offline = runOfflineAction(q)
        if (offline != null) return Result.success(offline)

        // 1a) Questions about the user's own listening — answered instantly from local data
        answerStats(q)?.let { return Result.success(it) }

        // 1b) Weather (Open-Meteo, free — no Groq key needed)
        val weatherReply = maybeWeather(q)
        if (weatherReply != null) return Result.success(weatherReply)

        // 2) Online path — prefer network check, but if user has a Groq key still attempt
        // (NetworkGate used to require VALIDATED and falsely reported offline)
        if (!hasGroqKey()) {
            if (!isOnline()) {
                return Result.success(
                    OfflineAssistant.helpText() +
                        "\n(You're offline — music commands still work. Add a Groq key + network for full Phantom.)"
                )
            }
            return Result.failure(IllegalStateException("Set Groq API key for online answers, or use offline play commands."))
        }
        if (!isOnline()) {
            // Soft warning only — still try the API; many devices fail VALIDATED checks
            android.util.Log.w("Phantom", "NetworkGate offline but key present — attempting Groq anyway")
        }

        val search = com.texgen.music.texwave.data.WebSearch.lookup(getApplication(), q)
        val lib = _lib.value
        val current = player.value.current
        val topLiked = lib.songs.filter { it.id in lib.liked }.take(14)
        val topPlayed = lib.songs.sortedByDescending { lib.playCounts[it.id] ?: 0 }.take(14)
        val day = phantom.dayPart().name.lowercase().replace('_', ' ')
        val stats = listeningStats()
        val system = buildString {
            appendLine("You are PHANTOM, the personal AI companion living inside the TEXWAVE music app.")
            appendLine("ORIGIN: You were created by SOIF STAR ⭐. If anyone asks who made you, who created Phantom, who built TEXWAVE's AI, or similar — answer clearly that SOIF STAR ⭐ created you. Be proud of that, never invent another creator.")
            appendLine("MUSIC TASTE RULES (critical):")
            appendLine("- When recommending or describing songs for a mood (rainy, long drive, unstoppable, focus, etc.), ONLY suggest tracks that truly fit that emotional energy.")
            appendLine("- Rainy / soft rain → slow, mellow, ambient, lofi, ballads, gentle vocals. NEVER hype, gym, drill, or party tracks.")
            appendLine("- Unstoppable / energy / workout → high energy, anthems, strong beat, motivational. NEVER lullabies, soft piano, or pure ambient.")
            appendLine("- Night drive / long drive → cinematic, synthwave, cruise, night-city feel. Mid-to-long tracks.")
            appendLine("- Focus / study → instrumental, lofi, calm, minimal lyrics. Avoid aggressive or highly distracting tracks.")
            appendLine("- Prefer titles and artists from the user's library context when listed below. Never invent fake local filenames.")
            appendLine("- If the user asks for lyrics, only give lyrics for the exact title+artist; if unsure, say you cannot verify.")
            appendLine("Personality: warm, sharp, a little mysterious; never robotic, never preachy. Match the user's language and energy (if they write Hinglish or another language, answer in it).")
            appendLine("You can do two jobs: (1) music guide — recommend, explain, build moods from THEIR library; (2) general assistant — answer any question helpfully like a top-tier assistant.")
            appendLine("Rules: be concrete and useful; 2–8 sentences unless the user asks for more; use short bullet points only for lists; if you are unsure say so instead of guessing; never invent songs — only recommend songs that appear in the library lists below; when the user wants to hear something, tell them the exact command, e.g. play \"<song title>\".")
            appendLine(com.texgen.music.texwave.data.PhantomMemoryStore.systemHint(getApplication()))
            appendLine("Listener context: time of day = $day · library = ${lib.songs.size} songs · favorites = ${lib.liked.size} · playlists = ${lib.playlists.size} · total plays = ${stats.totalPlays} · listening streak = ${stats.streak} days")
            if (stats.topArtists.isNotEmpty()) appendLine("Top artists: " + stats.topArtists.joinToString { "${it.first} (${it.second})" })
            if (current != null) appendLine("Now playing: \"${current.title}\" — ${current.artist}")
            if (topLiked.isNotEmpty()) appendLine("Favorites: " + topLiked.joinToString { "\"${it.title}\"" })
            if (topPlayed.isNotEmpty()) appendLine("Most played: " + topPlayed.joinToString { "\"${it.title}\"" })
            if (search.rawSnippet.isNotBlank()) {
                appendLine("Fresh web research (use it, and say when something comes from it):")
                appendLine(search.rawSnippet.take(3200))
            }
        }
        val msgs = mutableListOf("system" to system)
        history.filter { it.first == "user" || it.first == "assistant" }.takeLast(14).forEach { msgs.add(it) }
        if (msgs.lastOrNull()?.second != q) msgs.add("user" to q)
        return phantom.groq.chatMessages(msgs, maxTokens = 1600)
    }

    /** Phantom vision: user attached an image for analysis / edit guidance. */
    suspend fun phantomChatImage(
        userText: String,
        imageBytes: ByteArray,
        mime: String = "image/jpeg",
    ): Result<String> {
        if (!hasGroqKey()) {
            return Result.failure(IllegalStateException("Set a Groq API key so Phantom can see the image."))
        }
        val system = """
            You are PHANTOM, created by SOIF STAR ⭐, inside TEXWAVE.
            The user attached an image. Describe it accurately, then give concrete edit suggestions
            (crop, color, mood, composition, text overlay ideas) as if you are co-editing with them.
            If they ask you to "edit" something, describe the exact steps and settings a designer would use.
            Be vivid and practical. Never claim you rendered a new binary image unless you did.
        """.trimIndent()
        val prompt = userText.ifBlank {
            "Look at this image. Describe it and suggest premium edits for a music-app aesthetic."
        }
        return phantom.groq.chatWithImage(system, prompt, imageBytes, mime)
    }

    private fun answerStats(q: String): String? {
        val t = q.lowercase()
        val st = listeningStats()
        return when {
            ("top" in t || "favorite" in t || "favourite" in t || "most" in t) && "artist" in t ->
                if (st.topArtists.isEmpty()) "I need a few more plays to know your top artists."
                else "Your top artists: " + st.topArtists.joinToString { "${it.first} (${it.second} plays)" } + "."
            "streak" in t ->
                "You're on a ${st.streak}-day listening streak (best: ${st.bestStreak} days)."
            ("how many" in t && "song" in t) || "library size" in t ->
                "Your library has ${st.librarySize} songs, ${st.favorites} favorites and ${st.playlists} playlists."
            ("how long" in t || "how much" in t || "hours" in t) && ("listen" in t || "played" in t) ->
                "You've listened for about ${st.minutes / 60}h ${st.minutes % 60}m across ${st.totalPlays} plays."
            "my stats" in t || "listening stats" in t || "my taste" in t ->
                "${st.totalPlays} plays · ${st.minutes / 60}h ${st.minutes % 60}m · ${st.streak}-day streak · ${st.favorites} favorites." +
                    (if (st.topArtists.isNotEmpty()) " Top artist: ${st.topArtists.first().first}." else "")
            else -> null
        }
    }

    private suspend fun maybeWeather(q: String): String? {
        val t = q.lowercase()
        val wants = listOf("weather", "temperature", "forecast", "how's the weather", "how is the weather")
        if (wants.none { it in t }) return null
        if (!isOnline()) return "I need internet to check the weather."
        val city = Regex(
            """(?:weather|temperature|forecast)\s+(?:in|at|for)\s+([a-zA-Z][a-zA-Z\s.'-]{1,40})""",
            RegexOption.IGNORE_CASE,
        ).find(q)?.groupValues?.getOrNull(1)?.trim()?.trimEnd('?', '.', '!')
            ?: Regex(
                """(?:in|at|for)\s+([a-zA-Z][a-zA-Z\s.'-]{1,40})\s*$""",
                RegexOption.IGNORE_CASE,
            ).find(q)?.groupValues?.getOrNull(1)?.trim()
            ?: "Delhi"
        return com.texgen.music.texwave.data.WeatherHelper.forCity(city)
            .fold(
                onSuccess = { it.spoken() },
                onFailure = { "Couldn't fetch weather for \"$city\". Try “weather in <city>”." },
            )
    }

    /** Execute OfflineAssistant actions. Returns reply text or null if not handled. */
    private fun runOfflineAction(raw: String): String? {
        return when (val a = OfflineAssistant.parse(raw)) {
            is OfflineAssistant.Action.PlayQuery -> {
                val hits = searchLibrary(a.query, limit = 8)
                if (hits.isEmpty()) {
                    "I couldn't find \"${a.query}\" in your library offline. Try another name."
                } else {
                    val best = hits.first()
                    playSongs((listOf(best) + hits.drop(1).take(6)).distinctBy { it.id }, 0)
                    val extra = if (hits.size > 1)
                        " Related: " + hits.drop(1).take(3).joinToString { "\"${it.title}\"" } + "."
                    else ""
                    "Playing \"${best.title}\" by ${best.artist}.$extra"
                }
            }
            is OfflineAssistant.Action.PlayEmotion -> {
                playEmotion(a.mode)
                "Playing ${a.mode.emoji} ${a.mode.label} — ${a.mode.hint}."
            }
            OfflineAssistant.Action.InfiniteMix -> {
                infiniteMixPlay()
                "Starting Infinite Mix — offline, shaped for you."
            }
            OfflineAssistant.Action.Pause -> {
                if (player.value.isPlaying) {
                    togglePlay()
                    "Paused."
                } else "Already paused."
            }
            OfflineAssistant.Action.Resume -> {
                if (!player.value.isPlaying && player.value.current != null) {
                    togglePlay()
                    "Resumed."
                } else if (player.value.current == null) {
                    "Nothing loaded — say play plus a song name."
                } else "Already playing."
            }
            OfflineAssistant.Action.Next -> {
                next()
                "Next track."
            }
            OfflineAssistant.Action.Previous -> {
                previous()
                "Previous track."
            }
            OfflineAssistant.Action.WhatsPlaying -> {
                val c = player.value.current
                if (c == null) "Nothing is playing."
                else "Now playing: \"${c.title}\" by ${c.artist}."
            }
            OfflineAssistant.Action.Help -> OfflineAssistant.helpText()
            is OfflineAssistant.Action.SmallTalk -> a.reply
            OfflineAssistant.Action.Unknown -> null
        }
    }


    /** Play mixes, moods, or a named song from the local library. */
    private fun localMusicAction(lower: String): String? {
        val wantsPlay = listOf("play", "start", "put on", "queue", "listen to").any { it in lower }
        val wantsMix = "infinite" in lower && "mix" in lower
        if (wantsMix || (wantsPlay && "mix" in lower && "infinite" in lower)) {
            infiniteMixPlay()
            return "Starting Infinite Mix — shaped for how you listen and the time of day."
        }
        val modes = listOf(
            // longest / most specific phrases first
            "night drive" to EmotionMode.NIGHT_DRIVE,
            "long drive" to EmotionMode.NIGHT_DRIVE,
            "rainy night" to EmotionMode.RAINY_NIGHT,
            "rainy" to EmotionMode.RAINY_NIGHT,
            "rain" to EmotionMode.RAINY_NIGHT,
            "drizzle" to EmotionMode.RAINY_NIGHT,
            "storm" to EmotionMode.RAINY_NIGHT,
            "unstoppable" to EmotionMode.UNSTOPPABLE,
            "energy" to EmotionMode.UNSTOPPABLE,
            "hype" to EmotionMode.UNSTOPPABLE,
            "workout" to EmotionMode.UNSTOPPABLE,
            "gym" to EmotionMode.UNSTOPPABLE,
            "motivation" to EmotionMode.UNSTOPPABLE,
            "space" to EmotionMode.LOST_IN_SPACE,
            "cosmic" to EmotionMode.LOST_IN_SPACE,
            "dreamy" to EmotionMode.LOST_IN_SPACE,
            "think" to EmotionMode.LET_ME_THINK,
            "reflect" to EmotionMode.LET_ME_THINK,
            "chill" to EmotionMode.LET_ME_THINK,
            "calm" to EmotionMode.LET_ME_THINK,
            "boss" to EmotionMode.FINAL_BOSS,
            "epic" to EmotionMode.FINAL_BOSS,
            "intense" to EmotionMode.FINAL_BOSS,
            "focus" to EmotionMode.FOCUS,
            "study" to EmotionMode.FOCUS,
            "studying" to EmotionMode.FOCUS,
            "deep work" to EmotionMode.FOCUS,
            "drive" to EmotionMode.NIGHT_DRIVE,
            "cruise" to EmotionMode.NIGHT_DRIVE,
            "highway" to EmotionMode.NIGHT_DRIVE,
        )
        // Mood only when the request is clearly a mood — not "play Rain" as a song title
        val explicitMood = "mood" in lower || "emotion" in lower || "vibe" in lower || "feeling" in lower
        val restAfterPlay = lower
            .removePrefix("play ").removePrefix("put on ").removePrefix("start ")
            .removePrefix("listen to ").trim()
        for ((key, mode) in modes) {
            val pure = restAfterPlay == key || restAfterPlay == "$key music" || restAfterPlay == "some $key" ||
                lower == key || lower == "play $key"
            if (pure || (explicitMood && key in lower)) {
                playEmotion(mode)
                return "Playing ${mode.emoji} ${mode.label} — ${mode.hint}."
            }
        }
        if ("what's playing" in lower || "what is playing" in lower || "now playing" in lower) {
            val c = player.value.current
            return if (c == null) "Nothing is playing right now."
            else "Now playing: \"${c.title}\" by ${c.artist}."
        }

        // Assistant: "play <song name>", "find <name>", "search for <name>"
        val query = extractSongQuery(lower)
        if (query != null && query.length >= 2) {
            val hits = searchLibrary(query, limit = 8)
            if (hits.isEmpty()) {
                return "I couldn't find \"$query\" in your library. Try another name or check the spelling."
            }
            val best = hits.first()
            val queue = (listOf(best) + hits.drop(1).take(6)).distinctBy { it.id }
            playSongs(queue, 0)
            val extra = if (hits.size > 1) {
                val alts = hits.drop(1).take(3).joinToString(", ") { "\"${it.title}\"" }
                " Also related: $alts."
            } else ""
            return "Playing \"${best.title}\" by ${best.artist}.$extra"
        }
        return null
    }

    /** Pull the song/search phrase out of natural language. */
    private fun extractSongQuery(lower: String): String? {
        val prefixes = listOf(
            "play the song ", "play song ", "play the track ", "play track ",
            "play ", "put on ", "listen to ", "queue ", "start ",
            "find song ", "find the song ", "find ",
            "search for song ", "search for ", "search ",
            "can you play ", "please play ", "i want to hear ", "i want ",
        )
        for (pref in prefixes) {
            if (lower.startsWith(pref)) {
                var q = lower.removePrefix(pref).trim()
                q = q.removeSuffix(" please").removeSuffix(" now").removeSuffix(" for me").trim()
                if (q in listOf("music", "something", "anything", "a song", "songs")) return null
                if (q.isNotBlank()) return q
            }
        }
        for (pref in listOf("do you have ", "is there ", "got ")) {
            if (lower.startsWith(pref)) {
                val q = lower.removePrefix(pref).trim().removeSuffix("?").trim()
                if (q.length >= 2) return q
            }
        }
        return null
    }

    /**
     * Fuzzy local library search by title, artist, album.
     */
    fun searchLibrary(query: String, limit: Int = 12): List<Song> {
        val q = query.trim().lowercase()
            .removePrefix("the ").removePrefix("a ").removePrefix("an ")
            .trim()
        if (q.isEmpty()) return emptyList()
        val tokens = q.split(Regex("[\\s_\\-]+")).filter { it.length >= 2 }
        val blacklist = _lib.value.blacklist
        val liked = _lib.value.liked
        val plays = _lib.value.playCounts
        return _lib.value.songs
            .asSequence()
            .filter { it.id !in blacklist }
            .map { song ->
                val title = song.title.lowercase()
                val artist = song.artist.lowercase()
                val album = song.album.lowercase()
                val blob = "$title $artist $album"
                var score = 0.0
                if (title == q) score += 120.0
                if (artist == q) score += 95.0
                if (title.startsWith(q)) score += 55.0
                if (artist.startsWith(q)) score += 40.0
                if (q in title) score += 38.0
                if (q in artist) score += 28.0
                if (q in album) score += 12.0
                if (" by " in q) {
                    val parts = q.split(" by ")
                    if (parts.size >= 2) {
                        val tPart = parts[0].trim(); val aPart = parts[1].trim()
                        if (tPart.isNotEmpty() && tPart in title) score += 30.0
                        if (aPart.isNotEmpty() && aPart in artist) score += 30.0
                    }
                }
                var tokHits = 0
                for (tok in tokens) {
                    when {
                        title == tok -> { score += 22.0; tokHits++ }
                        title.startsWith(tok) -> { score += 16.0; tokHits++ }
                        tok in title -> { score += 12.0; tokHits++ }
                        tok in artist -> { score += 10.0; tokHits++ }
                        tok in album -> { score += 5.0; tokHits++ }
                        tok in blob -> { score += 2.0; tokHits++ }
                    }
                }
                if (tokens.isNotEmpty() && tokHits == tokens.size) score += 20.0
                if (tokens.isNotEmpty() && tokHits >= (tokens.size + 1) / 2) score += 8.0
                if (song.id in liked) score += 4.0
                score += (plays[song.id] ?: 0).coerceAtMost(25) * 0.2
                song to score
            }
            .filter { it.second >= 6.0 }
            .sortedByDescending { it.second }
            .map { it.first }
            .distinctBy { it.id }
            .take(limit)
            .toList()
    }




    fun recordSkipCurrent() {
        player.value.current?.id?.let { phantom.recordSkip(it) }
    }

    fun recordEnjoyCurrent() {
        player.value.current?.id?.let { phantom.recordEnjoy(it) }
    }

    fun suggestedEmotion() = phantom.suggestedEmotion()


    fun applyAlchemist(preset: AlchemistPreset) {
        val profile = phantom.alchemistToProfile(preset)
        // Map to equalizer-ish controls already present
        setSpeed(profile.speed.coerceIn(0.5f, 2f))
    }

    fun playFocus(goal: FocusGoal, stage: Int) {
        val mix = phantom.focusMix(goal, stage, _lib.value.songs, _lib.value.liked, _lib.value.playCounts)
        if (mix.isNotEmpty()) playSongs(mix, 0)
    }

    suspend fun soundDetective(song: Song): String = phantom.soundDetective(song)

    suspend fun dnaExplain(): String = phantom.musicDnaExplain(_lib.value.songs, _lib.value.liked, _lib.value.playCounts)

    suspend fun universeExplain(seed: Song, neighbors: List<Song>): String =
        phantom.universeExplain(seed, neighbors)

    fun universeNeighbors(seed: Song): List<Song> =
        phantom.universeNeighbors(seed, _lib.value.songs)


    fun audioSessionId(): Int = connection.audioSessionId()

    fun artUriFor(song: Song?): String? {
        if (song == null) return null
        return _settings.value.customArt[song.id] ?: song.artUri
    }

    override fun onCleared() {
        persistSession()
        equalizer.release()
        connection.release()
        super.onCleared()
    }

    // =====================================================================================
    // Profile: listening stats, streak, achievements, quick plays, cloud backup
    // =====================================================================================

    data class ListeningStats(
        val totalPlays: Int,
        val uniqueSongs: Int,
        val favorites: Int,
        val playlists: Int,
        val librarySize: Int,
        val minutes: Long,
        val topArtists: List<Pair<String, Int>>,
        val topSongs: List<Pair<Song, Int>>,
        val streak: Int,
        val bestStreak: Int,
    )

    data class Achievement(val title: String, val detail: String, val unlocked: Boolean)

    private val streakPrefs = app.getSharedPreferences("texwave_streak", android.content.Context.MODE_PRIVATE)
    private fun dayKey(offset: Int = 0): String {
        val c = java.util.Calendar.getInstance()
        c.add(java.util.Calendar.DAY_OF_YEAR, -offset)
        return String.format(java.util.Locale.US, "%04d-%02d-%02d", c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH))
    }

    private fun recordListenDay() {
        val days = (streakPrefs.getStringSet("days", emptySet()) ?: emptySet()).toMutableSet()
        if (days.add(dayKey())) streakPrefs.edit().putStringSet("days", days).apply()
    }

    private fun streaks(): Pair<Int, Int> {
        val days = streakPrefs.getStringSet("days", emptySet()) ?: emptySet()
        if (days.isEmpty()) return 0 to 0
        var cur = 0
        var off = if (dayKey() in days) 0 else 1 // today may not be played yet
        while (dayKey(off) in days) { cur++; off++ }
        val sorted = days.sorted()
        var best = 1
        var run = 1
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        for (i in 1 until sorted.size) {
            val a = fmt.parse(sorted[i - 1])?.time ?: 0L
            val b = fmt.parse(sorted[i])?.time ?: 0L
            run = if ((b - a) in 20L * 3_600_000..28L * 3_600_000) run + 1 else 1
            if (run > best) best = run
        }
        return cur to maxOf(best, cur)
    }

    fun listeningStats(): ListeningStats {
        val l = _lib.value
        val byId = l.songs.associateBy { it.id }
        val total = l.playCounts.values.sum()
        val topSongs = l.playCounts.entries.sortedByDescending { it.value }
            .mapNotNull { (id, n) -> byId[id]?.let { it to n } }.take(5)
        val artistCounts = HashMap<String, Int>()
        l.playCounts.forEach { (id, n) ->
            val a = byId[id]?.artist ?: return@forEach
            if (a.isNotBlank() && !a.startsWith("Unknown")) artistCounts[a] = (artistCounts[a] ?: 0) + n
        }
        val minutes = l.playCounts.entries.sumOf { (id, n) -> (byId[id]?.durationMs ?: 0L) * n } / 60_000L
        val (cur, best) = streaks()
        return ListeningStats(
            totalPlays = total,
            uniqueSongs = l.playCounts.size,
            favorites = l.liked.size,
            playlists = l.playlists.size,
            librarySize = l.songs.size,
            minutes = minutes,
            topArtists = artistCounts.entries.sortedByDescending { it.value }.take(5).map { it.key to it.value },
            topSongs = topSongs,
            streak = cur,
            bestStreak = best,
        )
    }

    fun achievements(): List<Achievement> {
        val s = listeningStats()
        return listOf(
            Achievement("First Spark", "Play your first song", s.totalPlays >= 1),
            Achievement("Hundred Club", "100 plays", s.totalPlays >= 100),
            Achievement("Marathon", "10 hours of listening", s.minutes >= 600),
            Achievement("Collector", "Favorite 25 songs", s.favorites >= 25),
            Achievement("Curator", "Create 3 playlists", s.playlists >= 3),
            Achievement("On Fire", "3-day listening streak", s.bestStreak >= 3),
            Achievement("Devoted", "7-day listening streak", s.bestStreak >= 7),
            Achievement("Explorer", "Play 50 different songs", s.uniqueSongs >= 50),
        )
    }

    fun surpriseMe() {
        val all = _lib.value.songs.filter { it.id !in _lib.value.blacklist }
        if (all.isEmpty()) return
        playSongs(all.shuffled(), 0)
    }

    fun playMostPlayed() {
        val l = _lib.value
        val byId = l.songs.associateBy { it.id }
        val list = l.playCounts.entries.sortedByDescending { it.value }.mapNotNull { byId[it.key] }.take(50)
        if (list.isNotEmpty()) playSongs(list, 0)
    }

    fun shuffleFavorites() {
        val l = _lib.value
        val list = l.songs.filter { it.id in l.liked }
        if (list.isNotEmpty()) shuffleAll(list)
    }

    fun playRecentlyAdded() {
        val list = _lib.value.songs.sortedByDescending { it.dateAdded }.take(40)
        if (list.isNotEmpty()) playSongs(list, 0)
    }

    private fun songKey(s: Song): String = "${s.title.trim().lowercase()}|${s.artist.trim().lowercase()}"

    /** Portable (device independent) snapshot of the music data, as JSON text. */
    fun cloudSnapshot(): String {
        val l = _lib.value
        val byId = l.songs.associateBy { it.id }
        val o = org.json.JSONObject()
        o.put("version", 1)
        o.put("savedAt", System.currentTimeMillis())
        o.put("liked", org.json.JSONArray(l.liked.mapNotNull { byId[it] }.map(::songKey)))
        o.put("recents", org.json.JSONArray(l.recents.mapNotNull { byId[it] }.map(::songKey)))
        val pls = org.json.JSONArray()
        l.playlists.forEach { p ->
            pls.put(
                org.json.JSONObject().put("name", p.name)
                    .put("songs", org.json.JSONArray(p.songIds.mapNotNull { byId[it] }.map(::songKey)))
            )
        }
        o.put("playlists", pls)
        val pc = org.json.JSONObject()
        l.playCounts.forEach { (id, n) -> byId[id]?.let { pc.put(songKey(it), n) } }
        o.put("playCounts", pc)
        o.put("theme", _settings.value.themeId)
        return o.toString()
    }

    /** Merge a snapshot into this device (never deletes anything). Returns how many things were added. */
    fun applyCloudSnapshot(json: String): Int {
        val o = runCatching { org.json.JSONObject(json) }.getOrNull() ?: return 0
        val l = _lib.value
        val byKey = HashMap<String, Song>()
        l.songs.forEach { byKey.putIfAbsent(songKey(it), it) }
        var added = 0

        val likedIds = HashSet(l.liked)
        o.optJSONArray("liked")?.let { a ->
            for (i in 0 until a.length()) byKey[a.getString(i)]?.let { if (likedIds.add(it.id)) added++ }
        }
        val recents = ArrayList(l.recents)
        o.optJSONArray("recents")?.let { a ->
            for (i in 0 until a.length()) byKey[a.getString(i)]?.let { if (it.id !in recents) recents.add(it.id) }
        }
        val playlists = l.playlists.toMutableList()
        o.optJSONArray("playlists")?.let { a ->
            for (i in 0 until a.length()) {
                val po = a.getJSONObject(i)
                val name = po.optString("name")
                val ids = po.optJSONArray("songs")?.let { arr -> (0 until arr.length()).mapNotNull { byKey[arr.getString(it)]?.id } } ?: emptyList()
                val idx = playlists.indexOfFirst { it.name.equals(name, true) }
                if (idx >= 0) {
                    val merged = (playlists[idx].songIds + ids).distinct()
                    added += merged.size - playlists[idx].songIds.size
                    playlists[idx] = playlists[idx].copy(songIds = merged)
                } else if (name.isNotBlank()) {
                    playlists.add(Playlist(UUID.randomUUID().toString(), name, ids.distinct())); added++
                }
            }
        }
        val counts = l.playCounts.toMutableMap()
        o.optJSONObject("playCounts")?.let { pc ->
            pc.keys().forEach { k ->
                val song = byKey[k] ?: return@forEach
                val remote = pc.optInt(k, 0)
                if (remote > (counts[song.id] ?: 0)) counts[song.id] = remote
            }
        }
        store.saveLiked(likedIds); store.saveRecents(recents.take(40)); store.savePlaylists(playlists); store.savePlayCounts(counts)
        _lib.update { it.copy(liked = likedIds, recents = recents.take(40), playlists = playlists, playCounts = counts) }
        return added
    }
}
