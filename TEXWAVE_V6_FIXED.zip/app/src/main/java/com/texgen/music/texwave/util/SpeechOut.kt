package com.texgen.music.texwave.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/** Clear, natural PHANTOM voice replies. */
class SpeechOut(context: Context) : TextToSpeech.OnInitListener {
    private val app = context.applicationContext
    private var tts: TextToSpeech? = TextToSpeech(app, this)
    private var ready = false

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) return
        val engine = tts ?: return
        // Prefer a clear English voice when available
        val en = Locale.US
        engine.language = en
        try {
            val voices = engine.voices
            val best = voices
                ?.filter { v ->
                    v.locale.language == "en" &&
                        !v.isNetworkConnectionRequired &&
                        v.quality >= Voice.QUALITY_NORMAL
                }
                ?.sortedByDescending { it.quality }
                ?.firstOrNull()
            if (best != null) engine.voice = best
        } catch (_: Exception) {
        }
        engine.setSpeechRate(0.96f) // slightly slower = clearer
        engine.setPitch(1.02f)
        pendingText?.let { p -> pendingText = null; speak(p) }
    }

    private var pendingText: String? = null

    fun speak(text: String) {
        if (text.isBlank()) return
        if (!ready) {
            pendingText = text
            // retry shortly while engine boots
            android.os.Handler(app.mainLooper).postDelayed({
                val p = pendingText
                if (ready && p != null) {
                    pendingText = null
                    speak(p)
                }
            }, 800)
            return
        }
        val clean = text
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("[*_#>`\\[\\]]"), "")
            .replace(Regex("https?://\\S+"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(900)
        if (clean.isBlank()) return
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "phantom_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
