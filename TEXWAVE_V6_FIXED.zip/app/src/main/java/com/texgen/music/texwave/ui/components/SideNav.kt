package com.texgen.music.texwave.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Biotech
import androidx.compose.material.icons.rounded.WbTwilight
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.NearMe
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.ui.theme.TexTokens

/** Everything the side navigation (and the Library "Explore" tab) can open. */
enum class NavTarget {
    Home, Search, Library, LibraryOrb, Stars, Radar, Explore,
    // Library sessions — keep these contiguous and in this order
    SesCinema, SesGps, SesTwin, SesPulse, SesAutopsy, SesCapsule, SesSanctuary,
    SesFrequency, SesIdentity, SesRepair, SesDream, SesLab,
    SesWeather, SesAnchors, SesGhost, SesLiving, SesUnplayed,
    LovedRooms,
    Chats, Phantom, PhantomChat, PhantomKey, PhantomCode, PhantomImage,
    Equalizer, Editor, Alarms, SleepTimer, Rescan, Theme, Sounds,
    Profile, Settings, Notifications,
}

data class NavItem(
    val target: NavTarget,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val section: String,
)

private val Cyan = Color(0xFF3DE0FF)
private val Violet = Color(0xFFB388FF)
private val Pink = Color(0xFFFF4FB0)
private val Mint = Color(0xFF3DFFB0)
private val Amber = Color(0xFFFFC857)
private val Blue = Color(0xFF6C8CFF)

val NavCatalog: List<NavItem> = listOf(
    // ── The main sessions ──
    NavItem(NavTarget.Home, "Home", "Mixes, moods and recents", Icons.Rounded.Home, Cyan, "SESSIONS"),
    NavItem(NavTarget.Search, "Search", "Find any song or artist", Icons.Rounded.Search, Cyan, "SESSIONS"),
    NavItem(NavTarget.Library, "Library", "Your music orb and recents", Icons.Rounded.LibraryMusic, Violet, "SESSIONS"),
    NavItem(NavTarget.Chats, "Chats", "Messages, calls, groups", Icons.Rounded.Chat, Cyan, "SESSIONS"),
    NavItem(NavTarget.Phantom, "Phantom", "Your AI companion", Icons.Rounded.SmartToy, Violet, "SESSIONS"),
    NavItem(NavTarget.Alarms, "Alarms", "Wake up to your music", Icons.Rounded.Alarm, Amber, "SESSIONS"),
    NavItem(NavTarget.Stars, "Constellation", "Your songs as a star map", Icons.Rounded.AutoAwesome, Violet, "SESSIONS"),
    NavItem(NavTarget.Radar, "Pulse Radar", "Listening map and smart mixes", Icons.Rounded.TrackChanges, Mint, "SESSIONS"),
    NavItem(NavTarget.LibraryOrb, "Songs", "All your songs", Icons.Rounded.LibraryMusic, Blue, "SESSIONS"),
    NavItem(NavTarget.Explore, "All features", "Grid of everything in the app", Icons.Rounded.Dashboard, Amber, "SESSIONS"),
    // ── Library sessions ──
    NavItem(NavTarget.SesCinema, "Memory Cinema", "Your listening year as a film", Icons.Rounded.Movie, Pink, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesGps, "Emotional GPS", "Pick where you need to arrive", Icons.Rounded.NearMe, Cyan, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesTwin, "Twin Room", "Listen in sync with a twin", Icons.Rounded.People, Violet, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesPulse, "Shared Pulse", "Feel the same beat together", Icons.Rounded.Favorite, Pink, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesAutopsy, "Song Autopsy", "Break a song apart", Icons.Rounded.Science, Mint, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesCapsule, "Time Capsule", "Songs from your past", Icons.Rounded.HourglassBottom, Amber, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesSanctuary, "Sanctuary", "Rules only, no recommendations", Icons.Rounded.Lock, Cyan, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesFrequency, "World Frequency", "Global feeling heatmap", Icons.Rounded.Public, Violet, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesIdentity, "Identity Soundtrack", "Build a character in songs", Icons.Rounded.Face, Pink, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesRepair, "Repair Session", "Calm things down with music", Icons.Rounded.SelfImprovement, Cyan, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesDream, "Dream Mode", "Overnight landing sequence", Icons.Rounded.WbTwilight, Violet, "LIBRARY SESSIONS"),
    NavItem(NavTarget.SesLab, "Resonance Lab", "How your community listens", Icons.Rounded.Biotech, Pink, "LIBRARY SESSIONS"),
    // ── Rituals (new) ──
    NavItem(NavTarget.SesWeather, "Emotional Weather", "Music that matches the sky inside", Icons.Rounded.WbTwilight, Cyan, "RITUALS"),
    NavItem(NavTarget.SesAnchors, "Memory Anchors", "Songs locked to real moments", Icons.Rounded.HourglassBottom, Pink, "RITUALS"),
    NavItem(NavTarget.SesGhost, "Ghost Queue", "The timeline you almost lived", Icons.Rounded.People, Violet, "RITUALS"),
    NavItem(NavTarget.SesLiving, "Living Songs", "Tracks that grow a soul", Icons.Rounded.Favorite, Mint, "RITUALS"),
    NavItem(NavTarget.SesUnplayed, "The Unplayed", "Sacred tracks never finished", Icons.Rounded.Lock, Amber, "RITUALS"),
    NavItem(NavTarget.LovedRooms, "Rooms I’d stay in", "Ten screens made to feel human", Icons.Rounded.AutoAwesome, Pink, "RITUALS"),
    // ── Phantom ──
    NavItem(NavTarget.PhantomChat, "Phantom chat", "Talk to Phantom", Icons.Rounded.Chat, Violet, "PHANTOM"),
    NavItem(NavTarget.PhantomKey, "Phantom API key", "Add or change your key", Icons.Rounded.Key, Amber, "PHANTOM"),
    NavItem(NavTarget.PhantomCode, "Code studio", "Ask Phantom to write code", Icons.Rounded.Code, Mint, "PHANTOM"),
    NavItem(NavTarget.PhantomImage, "Image studio", "Ask Phantom about images", Icons.Rounded.Image, Pink, "PHANTOM"),
    // ── Tools and settings (everything from the old 3-dot menu) ──
    NavItem(NavTarget.Equalizer, "Equalizer", "Bands, bass and presets", Icons.Rounded.Equalizer, Cyan, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Editor, "Music editor", "Trim and edit songs", Icons.Rounded.Tune, Violet, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Rescan, "Rescan library", "Look for new songs", Icons.Rounded.Refresh, Mint, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Sounds, "UI sounds", "Tap sounds on or off", Icons.Rounded.VolumeUp, Cyan, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.SleepTimer, "Sleep timer", "Stop playback later", Icons.Rounded.Bedtime, Blue, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Theme, "Player background", "Pick your own image", Icons.Rounded.Palette, Violet, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Profile, "My profile", "Edit profile, stats, cloud backup", Icons.Rounded.Person, Pink, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Notifications, "Notifications", "Alerts and message settings", Icons.Rounded.Notifications, Amber, "TOOLS AND SETTINGS"),
    NavItem(NavTarget.Settings, "Settings", "Everything else", Icons.Rounded.Settings, Blue, "TOOLS AND SETTINGS"),
)

private sealed class Row2 {
    data class Header(val text: String) : Row2()
    data class Entry(val item: NavItem) : Row2()
}

/**
 * Side navigation — same look as the Chat sidebar. Shown first, closed with one tap
 * (X, the dark area, a swipe left, or Back), brought back with the edge handle.
 */
@Composable
fun SideNavDrawer(
    visible: Boolean,
    soundsOn: Boolean,
    selected: NavTarget?,
    onDismiss: () -> Unit,
    onSelect: (NavTarget) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = visible, enter = fadeIn(tween(200)), exit = fadeOut(tween(180))) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x66000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        query = ""; onDismiss()
                    },
            )
        }
        AnimatedVisibility(
            visible = visible,
            enter = slideInHorizontally(tween(260)) { -it } + fadeIn(tween(220)),
            exit = slideOutHorizontally(tween(220)) { -it } + fadeOut(tween(180)),
            modifier = Modifier.align(Alignment.CenterStart),
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .width(300.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xE6080C18),
                                Color(0xF0050814),
                                Color(0xF0080A16),
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            listOf(
                                TexTokens.Cyan.copy(alpha = 0.22f),
                                TexTokens.Violet.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        ),
                        shape = RoundedCornerShape(topEnd = 26.dp, bottomEnd = 26.dp),
                    )
                    .clip(RoundedCornerShape(topEnd = 26.dp, bottomEnd = 26.dp))
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { _, dx -> if (dx < -18f) { query = ""; onDismiss() } }
                    }
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(bottom = 12.dp),
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("TEXWAVE", color = TexTokens.Cyan.copy(alpha = 0.92f), fontWeight = FontWeight.Bold, fontSize = 17.sp, letterSpacing = 1.4.sp)
                        Text("Menu", color = TexTokens.TextSecondary, fontSize = 12.sp)
                    }
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(Color(0x22FFFFFF))
                            .clickable { query = ""; onDismiss() },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Close, "Close menu", tint = Color.White, modifier = Modifier.size(18.dp)) }
                }
                Box(
                    Modifier.fillMaxWidth().height(1.dp).padding(horizontal = 16.dp).background(
                        Brush.horizontalGradient(listOf(Color.Transparent, TexTokens.Violet.copy(0.28f), Color.Transparent))
                    )
                )
                Row(
                    Modifier
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x0FFFFFFF))
                        .border(1.dp, Color(0x14FFFFFF), RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Search, null, tint = Color(0xFF7A829E), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Find a screen or setting", color = Color(0xFF6B7392), fontSize = 14.sp)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                            cursorBrush = SolidColor(TexTokens.Cyan),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                val rows = remember(query) {
                    val q = query.trim().lowercase()
                    val list = NavCatalog.filter {
                        q.isEmpty() || it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q)
                    }
                    buildList<Row2> {
                        var last = ""
                        for (entry in list) {
                            if (entry.section != last) { add(Row2.Header(entry.section)); last = entry.section }
                            add(Row2.Entry(entry))
                        }
                    }
                }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    if (rows.isEmpty()) {
                        item { Text("Nothing matches \"$query\"", color = Color(0xFF7A829E), fontSize = 13.sp, modifier = Modifier.padding(16.dp)) }
                    }
                    items(rows) { r ->
                        when (r) {
                            is Row2.Header -> Text(
                                r.text,
                                color = Color(0xFF6B7392).copy(alpha = 0.85f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.6.sp,
                                modifier = Modifier.padding(start = 8.dp, top = 14.dp, bottom = 4.dp),
                            )
                            is Row2.Entry -> NavRow(r.item, r.item.target == selected, soundsOn) { query = ""; onSelect(r.item.target) }
                        }
                    }
                }
                Text(
                    "Tap the X to hide this menu",
                    color = TexTokens.TextSecondary.copy(alpha = 0.6f), fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun NavRow(item: NavItem, selected: Boolean, soundsOn: Boolean, onClick: () -> Unit) {
    val isSound = item.target == NavTarget.Sounds
    val icon = if (isSound && !soundsOn) Icons.Rounded.VolumeOff else item.icon
    val label = if (isSound) (if (soundsOn) "UI sounds: on" else "UI sounds: off") else item.title
    val shape = RoundedCornerShape(16.dp)
    val accent = item.accent
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                if (selected)
                    Brush.horizontalGradient(
                        listOf(accent.copy(alpha = 0.18f), TexTokens.Cyan.copy(alpha = 0.08f), Color.Transparent)
                    )
                else
                    Brush.horizontalGradient(listOf(Color(0x0AFFFFFF), Color.Transparent))
            )
            .then(
                if (selected) Modifier.border(
                    1.dp,
                    Brush.horizontalGradient(
                        listOf(accent.copy(alpha = 0.55f), TexTokens.Cyan.copy(alpha = 0.35f))
                    ),
                    shape,
                ) else Modifier
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(
                    if (selected) accent.copy(alpha = 0.22f)
                    else Color(0x12FFFFFF)
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                label,
                tint = if (selected) accent else Color(0xFFB8C0D8),
                modifier = Modifier.size(20.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                label,
                color = if (selected) Color(0xFFF4F2FF) else Color(0xFFE4E8F5),
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                fontSize = 14.sp,
                maxLines = 1,
            )
            if (!isSound && item.subtitle.isNotBlank()) {
                Text(
                    item.subtitle,
                    color = Color(0xFF7A849E),
                    fontSize = 11.sp,
                    maxLines = 1,
                )
            }
        }
        if (selected) {
            Box(
                Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(accent)
            )
        }
    }
}

/** Slim tab on the left edge. Tap it or drag it to the right to open the menu. */
@Composable
fun SideNavHandle(onOpen: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .width(18.dp)
            .height(64.dp)
            .clip(RoundedCornerShape(topEnd = 14.dp, bottomEnd = 14.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Violet.copy(alpha = 0.45f), Cyan.copy(alpha = 0.35f))
                )
            )
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Cyan.copy(0.4f), Violet.copy(0.25f))),
                RoundedCornerShape(topEnd = 14.dp, bottomEnd = 14.dp),
            )
            .pointerInput(Unit) { detectHorizontalDragGestures { _, dx -> if (dx > 10f) onOpen() } }
            .clickable(onClick = onOpen),
        contentAlignment = Alignment.Center,
    ) { Text("›", color = Color.White.copy(alpha = 0.9f), fontSize = 17.sp, fontWeight = FontWeight.Bold) }
}


/** Always-visible slim icon rail. Menu = expand the full drawer, chevron = hide the rail. */
@Composable
fun SideNavRail(
    selected: NavTarget?,
    soundsOn: Boolean,
    onSelect: (NavTarget) -> Unit,
    onExpand: () -> Unit,
    onHide: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxHeight()
            .width(RailWidth)
            .background(Brush.verticalGradient(listOf(Color(0xE60A0E1E), Color(0xF0070A16), Color(0xF00C0820))))
            .border(width = 1.dp, color = Color(0x183DE0FF))
            .statusBarsPadding()
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.padding(top = 8.dp).size(42.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Cyan.copy(0.35f), Violet.copy(0.35f))))
                .clickable(onClick = onExpand),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.Menu, "Open menu", tint = Color.White) }
        Spacer(Modifier.height(6.dp))
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            var lastSection = ""
            NavCatalog.forEach { item ->
                if (item.section != lastSection) {
                    if (lastSection.isNotEmpty()) {
                        Box(Modifier.padding(vertical = 6.dp).width(24.dp).height(1.dp).background(Color(0x223DE0FF)))
                    }
                    lastSection = item.section
                }
                val on = item.target == selected
                val icon = if (item.target == NavTarget.Sounds && !soundsOn) Icons.Rounded.VolumeOff else item.icon
                Box(
                    Modifier.padding(vertical = 2.dp).size(44.dp).clip(RoundedCornerShape(14.dp))
                        .background(if (on) item.accent.copy(0.28f) else Color.Transparent)
                        .then(if (on) Modifier.border(1.dp, item.accent.copy(0.6f), RoundedCornerShape(14.dp)) else Modifier)
                        .clickable { onSelect(item.target) },
                    contentAlignment = Alignment.Center,
                ) { Icon(icon, item.title, tint = if (on) item.accent else Color(0xFF8A92B0), modifier = Modifier.size(22.dp)) }
            }
        }
        Box(
            Modifier.padding(vertical = 8.dp).size(40.dp).clip(CircleShape).clickable(onClick = onHide),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Rounded.ChevronLeft, "Hide menu", tint = Color(0xFF9AA2C2)) }
    }
}

val RailWidth = 56.dp
