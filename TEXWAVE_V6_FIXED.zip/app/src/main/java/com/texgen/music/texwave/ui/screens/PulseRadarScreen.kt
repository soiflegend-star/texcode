package com.texgen.music.texwave.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Nightlife
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.data.Song
import com.texgen.music.texwave.player.PlayerState
import com.texgen.music.texwave.ui.LibraryState
import com.texgen.music.texwave.ui.components.appear
import com.texgen.music.texwave.ui.components.pressable
import com.texgen.music.texwave.ui.components.rememberUiSound
import com.texgen.music.texwave.ui.components.sonicAtmosphere
import com.texgen.music.texwave.util.UiSound
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Pulse Radar — high-tech listening map + one-tap intelligence mixes.
 * Selectable from Library like constellation / songs.
 */
@Composable
fun PulseRadarScreen(
    lib: LibraryState,
    player: PlayerState,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onEmotion: (String) -> Unit = {},
) {
    val sound = rememberUiSound()
    val t = rememberInfiniteTransition(label = "radar")
    val sweep = t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(4800, easing = LinearEasing)),
        label = "sweep",
    )
    val pulse = t.animateFloat(
        0.92f, 1.08f,
        infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse",
    )

    val liked = remember(lib.songs, lib.liked) { lib.songs.filter { it.id in lib.liked } }
    val recent = remember(lib.songs, lib.recents) {
        val byId = lib.songs.associateBy { it.id }
        lib.recents.mapNotNull { byId[it] }.distinctBy { it.id }.take(24)
    }
    val night = remember(lib.songs) {
        lib.songs.filter {
            val n = (it.title + it.album).lowercase()
            listOf("night", "dark", "moon", "sleep", "chill", "rain").any { k -> k in n }
        }.ifEmpty { lib.songs.shuffled().take(20) }
    }
    val energy = remember(lib.songs, lib.playCounts) {
        lib.songs.sortedByDescending { lib.playCounts[it.id] ?: 0 }.take(30)
            .ifEmpty { lib.songs.shuffled().take(20) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .sonicAtmosphere()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(
            "PULSE RADAR",
            color = Color(0xFF3DE0FF),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 3.sp,
            modifier = Modifier.appear(0),
        )
        Text(
            "Live map of your sound · one-tap intelligence",
            color = Color(0xFF7A829E),
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 14.dp).appear(40),
        )

        // Radar canvas
        Box(
            Modifier
                .fillMaxWidth()
                .height(280.dp)
                .appear(80)
                .shadow(24.dp, RoundedCornerShape(28.dp), ambientColor = Color(0xFF8A5CFF).copy(0.45f))
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF0A1230), Color(0xFF050814), Color(0xFF000000)),
                    )
                )
                .border(
                    1.dp,
                    Brush.linearGradient(listOf(Color(0x883DE0FF), Color(0x668A5CFF), Color(0x44E056A0))),
                    RoundedCornerShape(28.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize().padding(12.dp)) {
                val c = Offset(size.width / 2f, size.height / 2f)
                val maxR = min(size.width, size.height) * 0.42f
                // rings
                for (i in 1..4) {
                    drawCircle(
                        Color(0xFF3DE0FF).copy(alpha = 0.12f + i * 0.04f),
                        maxR * (i / 4f),
                        c,
                        style = Stroke(width = 1.2f * density),
                    )
                }
                // crosshair
                drawLine(Color(0x553DE0FF), Offset(c.x - maxR, c.y), Offset(c.x + maxR, c.y), 1f * density)
                drawLine(Color(0x553DE0FF), Offset(c.x, c.y - maxR), Offset(c.x, c.y + maxR), 1f * density)
                // sweep wedge
                val ang = Math.toRadians(sweep.value.toDouble())
                val ex = c.x + cos(ang).toFloat() * maxR
                val ey = c.y + sin(ang).toFloat() * maxR
                drawLine(
                    Brush.linearGradient(
                        listOf(Color(0x003DE0FF), Color(0xCC3DE0FF)),
                        c, Offset(ex, ey),
                    ),
                    c, Offset(ex, ey),
                    strokeWidth = 3f * density,
                    cap = StrokeCap.Round,
                )
                // blips = library stats
                val blips = listOf(
                    lib.songs.size to Color(0xFFB27CFF),
                    lib.liked.size to Color(0xFFFF4FB0),
                    lib.playlists.size to Color(0xFF3DE0FF),
                    recent.size to Color(0xFF7B6CFF),
                )
                blips.forEachIndexed { i, (n, col) ->
                    val a = Math.toRadians((i * 72.0 + sweep.value * 0.15) % 360.0)
                    val rr = maxR * (0.35f + (i % 3) * 0.18f) * pulse.value
                    val p = Offset(c.x + cos(a).toFloat() * rr, c.y + sin(a).toFloat() * rr)
                    drawCircle(col.copy(alpha = 0.35f), 14f * density, p)
                    drawCircle(col, 5f * density, p)
                }
                // core
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFF3DE0FF), Color(0xFF8A5CFF), Color(0x00000000)),
                        c, maxR * 0.22f * pulse.value,
                    ),
                    maxR * 0.22f * pulse.value,
                    c,
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "${lib.songs.size}",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                )
                Text("SIGNALS", color = Color(0xFF3DE0FF), fontSize = 10.sp, letterSpacing = 2.sp)
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            "INTELLIGENCE MIXES",
            color = Color(0xFFE8ECFF),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.appear(120),
        )
        Spacer(Modifier.height(10.dp))

        RadarAction(
            Icons.Rounded.Bolt, "Energy Strike", "Most-played power queue",
            listOf(Color(0xFFFF6B35), Color(0xFFE63946)),
        ) {
            sound(UiSound.Kind.SELECT)
            if (energy.isNotEmpty()) onPlay(energy, 0)
        }
        RadarAction(
            Icons.Rounded.Nightlife, "Night Circuit", "Dark / chill / late hours",
            listOf(Color(0xFF4A90E2), Color(0xFF1B2838)),
        ) {
            sound(UiSound.Kind.SELECT)
            if (night.isNotEmpty()) onPlay(night, 0) else onEmotion("rainy")
        }
        RadarAction(
            Icons.Rounded.Favorite, "Heart Core", "Only tracks you loved",
            listOf(Color(0xFFFF4FB0), Color(0xFF8A5CFF)),
        ) {
            sound(UiSound.Kind.SELECT)
            if (liked.isNotEmpty()) onShuffle(liked)
        }
        RadarAction(
            Icons.Rounded.Spa, "Deep Focus", "Study & work mood wave",
            listOf(Color(0xFF00E5C3), Color(0xFF0A3D3A)),
        ) {
            sound(UiSound.Kind.SELECT)
            onEmotion("focus")
        }
        RadarAction(
            Icons.Rounded.Psychology, "Phantom Instinct", "Recent + favorites fused",
            listOf(Color(0xFFB27CFF), Color(0xFF3DE0FF)),
        ) {
            sound(UiSound.Kind.SELECT)
            val mix = (liked + recent).distinctBy { it.id }.shuffled()
            if (mix.isNotEmpty()) onPlay(mix, 0)
            else if (lib.songs.isNotEmpty()) onShuffle(lib.songs)
        }
        RadarAction(
            Icons.Rounded.Shuffle, "Full Spectrum", "Shuffle entire library",
            listOf(Color(0xFF3DE0FF), Color(0xFF8A5CFF)),
        ) {
            sound(UiSound.Kind.SELECT)
            if (lib.songs.isNotEmpty()) onShuffle(lib.songs)
        }

        Spacer(Modifier.height(20.dp))
        // Live now strip
        val cur = player.current
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF0A0E1A))
                .border(1.dp, Color(0x223DE0FF), RoundedCornerShape(18.dp))
                .padding(14.dp)
                .appear(200),
        ) {
            Column {
                Text("ACTIVE SIGNAL", color = Color(0xFF7A829E), fontSize = 10.sp, letterSpacing = 1.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    cur?.title ?: "No track locked",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                )
                Text(
                    cur?.artist?.ifBlank { "—" } ?: "Arm a mix above to begin",
                    color = Color(0xFF3DE0FF),
                    fontSize = 12.sp,
                )
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun RadarAction(
    icon: ImageVector,
    title: String,
    subtitle: String,
    colors: List<Color>,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(colors[0].copy(alpha = 0.22f), colors[1].copy(alpha = 0.12f), Color(0xFF080A12)),
                )
            )
            .border(1.dp, colors[0].copy(alpha = 0.45f), RoundedCornerShape(18.dp))
            .pressable(0.97f, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(colors)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.padding(start = 12.dp).weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color(0xFF9AA2C2), fontSize = 11.sp)
        }
    }
}
