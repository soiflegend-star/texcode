package com.texgen.music.texwave.sonara.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.texgen.music.texwave.sonara.data.Track

/** Persisted look & feel of the Sonara module (Appearance screen). */
object SonaraPrefs {
    private var sp: SharedPreferences? = null
    var themeMode by mutableStateOf(1)          // 0 light, 1 dark, 2 auto
    var accent by mutableStateOf(0xFF8B6CFF.toInt())
    var glass by mutableStateOf(true)
    var dynamic by mutableStateOf(true)
    var visualizer by mutableStateOf(true)
    var systemDark by mutableStateOf(true)
    val followed = mutableStateListOf<String>()

    val isLight: Boolean get() = themeMode == 0 || (themeMode == 2 && !systemDark)

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences("sonara_ui", Context.MODE_PRIVATE)
        sp = p
        themeMode = p.getInt("theme", 1)
        accent = p.getInt("accent", 0xFF8B6CFF.toInt())
        glass = p.getBoolean("glass", true)
        dynamic = p.getBoolean("dynamic", true)
        visualizer = p.getBoolean("visualizer", true)
        followed.clear(); followed.addAll(p.getStringSet("followed", emptySet()) ?: emptySet())
    }

    fun setTheme(v: Int) { themeMode = v; sp?.edit()?.putInt("theme", v)?.apply() }
    fun setAccent(v: Int) { accent = v; sp?.edit()?.putInt("accent", v)?.apply() }
    fun setGlass(v: Boolean) { glass = v; sp?.edit()?.putBoolean("glass", v)?.apply() }
    fun setDynamic(v: Boolean) { dynamic = v; sp?.edit()?.putBoolean("dynamic", v)?.apply() }
    fun setVisualizer(v: Boolean) { visualizer = v; sp?.edit()?.putBoolean("visualizer", v)?.apply() }
    fun toggleFollow(name: String) {
        if (!followed.remove(name)) followed.add(name)
        sp?.edit()?.putStringSet("followed", followed.toSet())?.apply()
    }
}

/** Sonara palette: smoky near-black with a violet accent, or a soft light variant. */
object SC {
    private val L: Boolean get() = SonaraPrefs.isLight
    val Bg: Color get() = if (L) Color(0xFFF3F2F8) else Color(0xFF050507)
    val Card: Color get() = if (L) Color.White else Color(0xFF141418)
    val CardHi: Color get() = if (L) Color(0xFFE8E6F1) else Color(0xFF202027)
    val Text: Color get() = if (L) Color(0xFF15131C) else Color(0xFFF5F4FA)
    val Sub: Color get() = if (L) Color(0xFF6B6879) else Color(0xFF9C9AAB)
    val Line: Color get() = if (L) Color(0x1F000000) else Color(0x24FFFFFF)
    val Accent: Color get() = Color(SonaraPrefs.accent)
    val Accent2: Color get() = lerp(Accent, Color.White, 0.35f)
}

val AccentChoices = listOf(0xFF8B6CFF, 0xFF3B82F6, 0xFFFF3D9A, 0xFFFF9F1C, 0xFF22C55E, 0xFF14B8A6).map { it.toInt() }

fun Modifier.glass(radius: Dp = 18.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    val brush = if (SonaraPrefs.glass) {
        Brush.verticalGradient(
            if (SonaraPrefs.isLight) listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.65f))
            else listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f))
        )
    } else SolidColor(SC.Card)
    return this.clip(shape).background(brush, shape).border(1.dp, SC.Line, shape)
}

fun fmtMs(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

private val coverPalette = listOf(
    Color(0xFF6C3BFF), Color(0xFFFF4D8D), Color(0xFF16A394), Color(0xFFFF8A2B),
    Color(0xFF2D7DFF), Color(0xFFB4308B), Color(0xFF3FAE4F), Color(0xFFD9423A),
)

fun coverBrush(seed: String): Brush {
    val h = (seed.hashCode() and 0x7fffffff)
    val a = coverPalette[h % coverPalette.size]
    val b = coverPalette[(h / 7) % coverPalette.size]
    return Brush.linearGradient(listOf(a, b.copy(alpha = 0.75f)))
}

fun seedColor(seed: String): Color = coverPalette[(seed.hashCode() and 0x7fffffff) % coverPalette.size]

/** Smoky black background with soft accent glows and silk curves. [tint] recolours the glow (dynamic effect). */
@Composable
fun SonaraBackdrop(modifier: Modifier = Modifier, tint: Color? = null, content: @Composable BoxScope.() -> Unit = {}) {
    val acc = tint ?: SC.Accent
    val light = SonaraPrefs.isLight
    Box(
        modifier.fillMaxSize().background(SC.Bg).drawBehind {
            val a1 = if (light) 0.16f else 0.34f
            val a2 = if (light) 0.10f else 0.20f
            drawRect(Brush.radialGradient(listOf(acc.copy(alpha = a1), Color.Transparent), Offset(size.width * 0.95f, size.height * 0.08f), size.width * 0.95f))
            drawRect(Brush.radialGradient(listOf(acc.copy(alpha = a2), Color.Transparent), Offset(0f, size.height * 0.92f), size.width * 0.8f))
            val silk = if (light) Color.Black.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.07f)
            val p = Path().apply {
                moveTo(-size.width * 0.1f, size.height * 0.28f)
                cubicTo(size.width * 0.5f, size.height * 0.08f, size.width * 0.35f, size.height * 0.72f, size.width * 1.1f, size.height * 0.52f)
            }
            drawPath(p, silk, style = Stroke(width = 2.dp.toPx()))
            val p2 = Path().apply {
                moveTo(-size.width * 0.1f, size.height * 0.34f)
                cubicTo(size.width * 0.55f, size.height * 0.16f, size.width * 0.4f, size.height * 0.78f, size.width * 1.1f, size.height * 0.6f)
            }
            drawPath(p2, silk, style = Stroke(width = 1.dp.toPx()))
        },
        content = content,
    )
}

@Composable
fun Cover(url: String?, seed: String, size: Dp, radius: Dp = 10.dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(radius)
    Box(modifier.size(size).clip(shape).background(coverBrush(seed)), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.MusicNote, null, tint = Color.White.copy(alpha = 0.55f), modifier = Modifier.size(size * 0.4f))
        if (!url.isNullOrBlank()) {
            AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, action: String? = null, onAction: () -> Unit = {}) {
    Row(modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, color = SC.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (action != null) Text("$action  ›", color = SC.Accent2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onAction() })
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.clip(shape)
            .background(if (selected) SC.Accent.copy(alpha = 0.22f) else SC.CardHi.copy(alpha = if (SonaraPrefs.isLight) 1f else 0.55f), shape)
            .border(1.dp, if (selected) SC.Accent else SC.Line, shape)
            .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp),
    ) { Text(text, color = SC.Text, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium) }
}

@Composable
fun TrackRow(
    t: Track, liked: Boolean, playing: Boolean, onClick: () -> Unit, onLike: () -> Unit, onMore: (() -> Unit)? = null,
    index: Int? = null,
) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 18.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (index != null) Text("$index", color = SC.Sub, fontSize = 13.sp, modifier = Modifier.width(26.dp))
        Cover(t.artworkUrl, t.id, 48.dp, 10.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, color = if (playing) SC.Accent2 else SC.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (t.previewOnly) "${t.artist} · 30s preview" else t.artist, color = SC.Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(
            if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Like",
            tint = if (liked) SC.Accent else SC.Sub,
            modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onLike() }.padding(9.dp),
        )
        if (onMore != null) Icon(
            Icons.Filled.MoreVert, "More", tint = SC.Sub,
            modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onMore() }.padding(9.dp),
        )
    }
}

@Composable
fun SquareCard(title: String, subtitle: String, url: String?, seed: String, size: Dp = 112.dp, round: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.width(size).clickable { onClick() }) {
        Cover(url, seed, size, if (round) size / 2 else 14.dp, Modifier.border(1.dp, SC.Line, if (round) CircleShape else RoundedCornerShape(14.dp)))
        Spacer(Modifier.height(7.dp))
        Text(title, color = SC.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, color = SC.Sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun RoundPlay(onClick: () -> Unit, size: Dp = 56.dp, playing: Boolean = false) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(SC.Accent2, SC.Accent))).clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(size * 0.55f)) }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) Icon(Icons.Filled.ArrowBack, "Back", tint = SC.Text,
            modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onBack() }.padding(9.dp))
        else Spacer(Modifier.width(6.dp))
        Text(title, color = SC.Text, fontSize = if (onBack == null) 24.sp else 17.sp, fontWeight = if (onBack == null) FontWeight.ExtraBold else FontWeight.SemiBold,
            modifier = Modifier.weight(1f).padding(start = 4.dp))
        trailing()
    }
}

@Composable
fun IconBtn(icon: ImageVector, desc: String, onClick: () -> Unit, tint: Color = SC.Text) {
    Icon(icon, desc, tint = tint, modifier = Modifier.size(40.dp).clip(CircleShape).clickable { onClick() }.padding(9.dp))
}

@Composable
fun SettingRow(icon: ImageVector, title: String, value: String? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = SC.Text, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(title, color = SC.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (value != null) Text(value, color = SC.Accent2, fontSize = 12.sp, modifier = Modifier.padding(end = 6.dp))
        Icon(Icons.Filled.ChevronRight, null, tint = SC.Sub, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = SC.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(
            value, onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = SC.Accent, checkedThumbColor = Color.White, uncheckedTrackColor = SC.CardHi, uncheckedThumbColor = SC.Sub, uncheckedBorderColor = SC.Line),
        )
    }
}
