# TEXWAVE – 12-screen reference UI

New code: app/src/main/java/com/texgen/music/texwave/ui/ref/ (RefKit, RefChrome, RefHome, RefLibrary, RefSearch,
RefNowPlaying, RefPhantom, RefSplash, RefSocial, RefProfileSettings). Reels restyled in place. MusicApp.kt rewired.

Artwork (res/drawable-nodpi/ref_*.png) was cut from the reference image at its native ~190px/phone resolution.
To sharpen: replace any ref_*.png with a higher-res file of the same name.

Bottom bar: Home | Library | orb (Now Playing) | Phantom | More. "More" opens every other screen
(Search, Feed, Reels, Messages, Groups, Profile, Settings, Equalizer, Alarms, Downloads, Explore, Phantom Lab, All features).

NOT compiled: no Android SDK/Maven access in the build sandbox. Syntax-checked only. Build with ./gradlew assembleDebug.
Old screens kept: legacy Library sessions (More > All features), legacy Settings (rows in new Settings), MyProfile editor (Edit Profile), Phantom Lab.

## Button wiring (all real)
Home: shuffle, hero, rows. Library: tabs/filter/more/new playlist. Search: filters, See All, clear, mixes.
Now Playing: seek, transport, like, menu (queue, lyrics, EQ, speed, sleep, editor, cover).
Phantom: chips + input -> real assistant. Feed: like/comment/share/compose. Reels: like/next/share/follow.
Messages: live Supabase chats. Groups: real group chats + create. Profile: highlights navigate, Edit Profile.
Settings: Notifications/Appearance/Music/Phantom deep-link into real settings; Privacy opens Android app permissions;
Storage clears cache; About dialog.

## Polish pass
- Inter font bundled (res/font), applied app-wide via RefPolish; density scaled down on narrow phones (<400dp).
- Snow particle overlay removed.
- New NebulaOrb (Canvas) drives the splash (staged reveal) and the Phantom orb (faster while thinking).
- Feed / Profile grid / Groups show real data only, with empty states + create CTAs.
- Alarms: rewritten screen. Sound = Phantom voice only (silent) / default tone / system ringtone / own song.
  Per-alarm picture theme (6 presets or own photo) shown on the ring screen. Still uncompiled on Android — build in Android Studio.

## Phantom chat + previous/next
- Chat: wrap-content bubbles with tails, Phantom avatar, **bold**/bullet rendering, animated typing dots, tap-to-copy, retry on error, mic input, speak-replies toggle, new-chat button, history saved across restarts, quick-command chips (offline brain).
- Previous/Next now delegate to the real player (shuffle-aware, wraps); the old index math used a stale queueIndex and could jump to the wrong/last song.

## Round 4
- Alarm: new AlarmRingService (foreground service) owns sound/vibration + full-screen notification; backup double-fire removed; silent = Phantom only.
- Previous bug root cause: VM auto-resumed a song's old saved position on track change (a finished song reopened at its end). Removed.
- Discover page (RefDiscover.kt): YouTube-style feed over the free Internet Archive catalog (music + films), real download progress/cancel, Downloads tab, auto media-scan + library rescan. (No YouTube ripping — against YouTube ToS.)
- Images: full-res embedded cover art (HiResArt), FilterQuality.High everywhere, bundled placeholder art upscaled.
- Chat theme photos: shared via private-bucket token (sb:path) downloaded with the peer's session.
- Equalizer: custom vertical bands + response curve, bass boost / virtualizer / loudness, 13 presets, live prev/play/next strip, auto re-attach.
- Player theme: Now Playing menu -> Player theme (presets, album-art blur, gallery photo).
- Cockpit guide: "?" button + one-time briefing + HUD corners on Radar, Constellation, Universe hub & every Universe screen; Emotional GPS rebuilt as a live radar.
