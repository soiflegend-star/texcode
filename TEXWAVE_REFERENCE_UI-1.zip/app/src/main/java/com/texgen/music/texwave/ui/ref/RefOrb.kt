package com.texgen.music.texwave.ui.ref

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Living nebula orb drawn entirely on a Canvas: soft breathing glow, three counter-rotating
 * tilted rings, orbiting sparks and a pulsing four-point star. [energy] > 1 speeds everything
 * up (used while Phantom is thinking).
 */
@Composable
fun NebulaOrb(modifier: Modifier = Modifier, energy: Float = 1f) {
    val t = rememberInfiniteTransition(label = "nebula")
    val speed = energy.coerceIn(0.5f, 3f)
    val spin by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween((18000 / speed).toInt(), easing = LinearEasing), RepeatMode.Restart), label = "spin",
    )
    val spin2 by t.animateFloat(
        360f, 0f, infiniteRepeatable(tween((11000 / speed).toInt(), easing = LinearEasing), RepeatMode.Restart), label = "spin2",
    )
    val breathe by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween((2600 / speed).toInt()), RepeatMode.Reverse), label = "breathe",
    )
    val twinkle by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween((1300 / speed).toInt()), RepeatMode.Reverse), label = "twinkle",
    )

    Canvas(modifier.aspectRatio(1f)) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = size.minDimension / 2f
        val core = r * (0.50f + 0.04f * breathe)

        // outer aura
        drawCircle(
            Brush.radialGradient(
                listOf(Ref.Violet.copy(alpha = 0.34f + 0.12f * breathe), Ref.Blue.copy(alpha = 0.14f), Color.Transparent),
                center = c, radius = r,
            ),
            radius = r, center = c,
        )
        // body
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFFEFF6FF), Ref.Cyan.copy(alpha = 0.95f), Ref.Blue, Ref.Purple, Color(0xFF1A0E52)),
                center = Offset(c.x - core * 0.25f, c.y - core * 0.3f), radius = core * 1.35f,
            ),
            radius = core, center = c,
        )
        // glass highlight
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
                center = Offset(c.x - core * 0.38f, c.y - core * 0.45f), radius = core * 0.55f,
            ),
            radius = core * 0.55f, center = Offset(c.x - core * 0.38f, c.y - core * 0.45f),
        )

        // tilted rings
        fun ring(angle: Float, tilt: Float, color: Color, widthPx: Float, scale: Float) {
            rotate(angle, c) {
                val w = r * 2f * scale
                val h = w * tilt
                drawOval(
                    color, topLeft = Offset(c.x - w / 2f, c.y - h / 2f), size = Size(w, h),
                    style = Stroke(widthPx),
                )
            }
        }
        ring(spin, 0.32f, Ref.Cyan.copy(alpha = 0.85f), 2.2f * density, 0.96f)
        ring(spin2 + 60f, 0.42f, Ref.Violet.copy(alpha = 0.8f), 1.8f * density, 0.88f)
        ring(spin * 0.6f + 120f, 0.24f, Ref.Magenta.copy(alpha = 0.7f), 1.4f * density, 1.0f)

        // orbiting sparks
        for (i in 0 until 9) {
            val a = (spin * (if (i % 2 == 0) 1f else -1.4f) + i * 40f) * (PI.toFloat() / 180f)
            val rad = r * (0.62f + 0.3f * ((i * 37) % 10) / 10f)
            val p = Offset(c.x + cos(a) * rad, c.y + sin(a) * rad * 0.6f)
            val al = 0.35f + 0.65f * (if (i % 2 == 0) twinkle else 1f - twinkle)
            drawCircle(Color.White.copy(alpha = al), radius = (1.2f + (i % 3) * 0.7f) * density, center = p)
        }

        // pulsing star
        val s = core * (0.34f + 0.12f * twinkle)
        val star = Path().apply {
            moveTo(c.x, c.y - s)
            quadraticBezierTo(c.x, c.y, c.x + s, c.y)
            quadraticBezierTo(c.x, c.y, c.x, c.y + s)
            quadraticBezierTo(c.x, c.y, c.x - s, c.y)
            quadraticBezierTo(c.x, c.y, c.x, c.y - s)
            close()
        }
        drawPath(star, Color.White.copy(alpha = 0.95f))
    }
}
