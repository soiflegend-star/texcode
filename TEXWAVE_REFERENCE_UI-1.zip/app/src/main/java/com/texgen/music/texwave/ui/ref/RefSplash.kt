package com.texgen.music.texwave.ui.ref

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.texgen.music.texwave.R

/** Reference screen 1 — Splash. Fast: finishes in ~2.4s. */
@Composable
fun RefSplashScreen(onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val done by rememberUpdatedState(onFinished)
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(2200, easing = FastOutSlowInEasing))
        kotlinx.coroutines.delay(250)
        done()
    }
    val reveal = remember { Animatable(0f) }
    val textIn = remember { Animatable(0f) }
    LaunchedEffect(Unit) { reveal.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(500); textIn.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }

    Box(Modifier.fillMaxSize().background(Ref.Bg)) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(Ref.Violet.copy(alpha = 0.22f * reveal.value), Color.Transparent),
                    center = Offset(540f, 700f), radius = 1100f,
                ),
            ),
        )
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier.fillMaxWidth().fillMaxHeight(0.58f).padding(horizontal = 36.dp),
                contentAlignment = Alignment.Center,
            ) {
                NebulaOrb(
                    Modifier.fillMaxWidth().graphicsLayer {
                        val s = 0.6f + 0.4f * reveal.value
                        scaleX = s; scaleY = s; alpha = reveal.value
                    },
                    energy = 1.2f,
                )
            }
            Column(
                Modifier.align(Alignment.CenterHorizontally).graphicsLayer {
                    alpha = textIn.value; translationY = (1f - textIn.value) * 24f
                },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
            RefWordmark(fontSize = 38.sp)
            Spacer(Modifier.height(18.dp))
            Row {
                Text("Your Sound", color = Color(0xFF7FD6F5), fontSize = 16.sp)
                Text("   •   ", color = Ref.Cyan, fontSize = 16.sp)
                Text("Your World", color = Ref.Cyan, fontSize = 16.sp)
            }
            }
            Spacer(Modifier.weight(1f))
            Text(
                "Initializing your wave...", color = Color(0xFFA9B6E6), fontSize = 14.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(14.dp))
            Canvas(Modifier.fillMaxWidth().padding(horizontal = 36.dp).height(12.dp)) {
                val h = 6.dp.toPx()
                val y = (size.height - h) / 2f
                drawRoundRect(Color(0xFF0B1A5A), Offset(0f, y), Size(size.width, h), CornerRadius(h, h))
                val w = size.width * progress.value
                if (w > 0f) {
                    drawRoundRect(
                        Brush.horizontalGradient(listOf(Ref.Cyan, Ref.Blue)),
                        Offset(0f, y), Size(w, h), CornerRadius(h, h),
                    )
                    drawCircle(Color.White, radius = 4.dp.toPx(), center = Offset(w, size.height / 2f))
                }
            }
            Spacer(Modifier.height(52.dp).navigationBarsPadding())
        }
    }
}
