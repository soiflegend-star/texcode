package com.texgen.music.texwave.ui.ref

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/** One instrument on a cockpit-style screen and what it means. */
data class GuideStep(val label: String, val text: String)

data class ScreenGuide(val id: String, val title: String, val tagline: String, val steps: List<GuideStep>)

/** Briefings for the "cockpit" screens (radar, GPS, constellation, universe lab). */
object Guides {
    val radar = ScreenGuide(
        "radar", "Library Radar", "Your whole library as a sky-map. Find music by feel, not by name.",
        listOf(
            GuideStep("Light", "Every glowing dot is one song from your library."),
            GuideStep("Size & brightness", "Bigger and brighter = you play it more, or you liked it."),
            GuideStep("Distance from centre", "Songs near the middle are your core favourites; the rim holds rarely-played tracks."),
            GuideStep("Tap a light", "Selects it — see the title and tap Play to start it."),
            GuideStep("Moving ring", "Just the radar sweep — it shows the map is live."),
        ),
    )
    val stars = ScreenGuide(
        "stars", "Constellation", "Your library as a night sky. Every artist is its own constellation.",
        listOf(
            GuideStep("Star", "One song. Tap it and a comet carries it in — the song starts playing."),
            GuideStep("Connected lines", "Stars joined together belong to the same artist."),
            GuideStep("Drag / pinch", "Drag to fly across the sky, pinch to zoom in on an artist."),
            GuideStep("Pulsing star", "The song that is playing right now."),
        ),
    )
    val gps = ScreenGuide(
        "gps", "Emotional GPS", "Tell it how you feel — it plots a route of songs to take you somewhere else.",
        listOf(
            GuideStep("Radar blips", "Each blip is a mood destination: Calm, Focus, Courage, Release, Joy, Night."),
            GuideStep("Bright blip", "Your chosen destination. Tap a blip or a mood chip to switch."),
            GuideStep("Path list", "The songs from YOUR library that match that mood, in order."),
            GuideStep("Play this path", "Starts the route as a queue."),
        ),
    )
    val hub = ScreenGuide(
        "hub", "Universe Lab", "Experimental screens built around memory, mood and sharing.",
        listOf(
            GuideStep("Cards", "Each card opens a different experience. Tap one to enter."),
            GuideStep("Tag (HOME / CHAT…)", "Where that feature normally lives in the app."),
            GuideStep("? button", "Every screen has one — it explains what you are looking at."),
        ),
    )
    fun generic(id: String, title: String, subtitle: String) = ScreenGuide(
        id, title, subtitle,
        listOf(
            GuideStep("What it is", subtitle),
            GuideStep("Songs shown", "Always taken from YOUR library — nothing is invented."),
            GuideStep("Play buttons", "Start a queue built for this screen."),
            GuideStep("Back arrow", "Returns to the Universe Lab."),
        ),
    )
}

/**
 * Wraps a screen in a cockpit frame: HUD corner brackets, a "?" instrument legend button,
 * and a one-time briefing the first time the screen is opened.
 */
@Composable
fun CockpitGuide(guide: ScreenGuide, content: @Composable BoxScope.() -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("texwave_ui", android.content.Context.MODE_PRIVATE) }
    var open by remember(guide.id) { mutableStateOf(false) }
    LaunchedEffect(guide.id) {
        if (!prefs.getBoolean("guide_seen_${guide.id}", false)) {
            kotlinx.coroutines.delay(500)
            open = true
        }
    }
    Box(Modifier.fillMaxSize()) {
        content()
        Canvas(Modifier.fillMaxSize()) {
            val c = Color(0x6619D3F2); val l = 22.dp.toPx(); val m = 8.dp.toPx(); val w = 1.6.dp.toPx()
            fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                drawLine(c, Offset(x, y), Offset(x + dx * l, y), w)
                drawLine(c, Offset(x, y), Offset(x, y + dy * l), w)
            }
            corner(m, m, 1f, 1f); corner(size.width - m, m, -1f, 1f)
            corner(m, size.height - m, 1f, -1f); corner(size.width - m, size.height - m, -1f, -1f)
        }
        Box(
            Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 8.dp, end = 14.dp)
                .size(36.dp).clip(CircleShape).background(Color(0xCC0C1740))
                .border(1.2.dp, Brush.linearGradient(listOf(Ref.Cyan, Ref.Violet)), CircleShape)
                .clickable { open = true },
            contentAlignment = Alignment.Center,
        ) { Text("?", color = Ref.Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
    }
    if (open) Dialog(onDismissRequest = { open = false; prefs.edit().putBoolean("guide_seen_${guide.id}", true).apply() }) {
        val shape = RoundedCornerShape(24.dp)
        Column(
            Modifier.fillMaxWidth().clip(shape).background(Brush.verticalGradient(listOf(Color(0xFF0F1B4A), Color(0xFF070D26))))
                .border(1.2.dp, Brush.linearGradient(listOf(Ref.Cyan.copy(alpha = 0.8f), Ref.Violet.copy(alpha = 0.7f))), shape)
                .padding(20.dp),
        ) {
            Text("COCKPIT BRIEFING", color = Ref.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.5.sp)
            Text(guide.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
            Text(guide.tagline, color = Color(0xFFB9C6F5), fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
            Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                guide.steps.forEachIndexed { i, s ->
                    Row(verticalAlignment = Alignment.Top) {
                        Box(
                            Modifier.size(26.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Ref.Purple, Ref.Blue))),
                            contentAlignment = Alignment.Center,
                        ) { Text("${i + 1}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(s.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text(s.text, color = Ref.Sub, fontSize = 13.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(Ref.Purple, Ref.Blue)))
                    .clickable { open = false; prefs.edit().putBoolean("guide_seen_${guide.id}", true).apply() }.padding(vertical = 13.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Got it", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}
