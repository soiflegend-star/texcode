package com.texgen.music.texwave.data

import android.content.Context
import org.json.JSONObject

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadThemeId(): String = prefs.getString(KEY_THEME, "default") ?: "default"
    fun saveThemeId(id: String) = prefs.edit().putString(KEY_THEME, id).apply()

    fun loadCustomArt(): Map<Long, String> {
        val raw = prefs.getString(KEY_CUSTOM_ART, null) ?: return emptyMap()
        return try {
            val o = JSONObject(raw)
            o.keys().asSequence().mapNotNull { k ->
                k.toLongOrNull()?.let { it to o.getString(k) }
            }.toMap()
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun saveCustomArt(map: Map<Long, String>) {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k.toString(), v) }
        prefs.edit().putString(KEY_CUSTOM_ART, o.toString()).apply()
    }

    fun setCustomArt(songId: Long, uri: String?) {
        val next = loadCustomArt().toMutableMap()
        if (uri == null) next.remove(songId) else next[songId] = uri
        saveCustomArt(next)
    }

    fun loadNotifStyleId(): String = prefs.getString(KEY_NOTIF_STYLE, "lyrics") ?: "lyrics"
    fun saveNotifStyleId(id: String) = prefs.edit().putString(KEY_NOTIF_STYLE, id).apply()

    fun loadNotifCustomUri(): String? = prefs.getString(KEY_NOTIF_URI, null)
    fun saveNotifCustomUri(uri: String?) {
        prefs.edit().apply {
            if (uri == null) remove(KEY_NOTIF_URI) else putString(KEY_NOTIF_URI, uri)
        }.apply()
    }

    fun getInt(key: String, def: Int): Int = prefs.getInt(key, def)
    fun putInt(key: String, v: Int) = prefs.edit().putInt(key, v).apply()

    fun loadEqEnabled(): Boolean = prefs.getBoolean(KEY_EQ_ON, false)
    fun saveEqEnabled(on: Boolean) = prefs.edit().putBoolean(KEY_EQ_ON, on).apply()

    fun loadEqPreset(): Int = prefs.getInt(KEY_EQ_PRESET, 0)
    fun saveEqPreset(index: Int) = prefs.edit().putInt(KEY_EQ_PRESET, index).apply()

    fun loadEqBands(): IntArray {
        val raw = prefs.getString(KEY_EQ_BANDS, null) ?: return intArrayOf(0, 0, 0, 0, 0)
        return try {
            raw.split(',').map { it.toInt() }.toIntArray()
        } catch (_: Exception) {
            intArrayOf(0, 0, 0, 0, 0)
        }
    }

    fun saveEqBands(bands: IntArray) {
        prefs.edit().putString(KEY_EQ_BANDS, bands.joinToString(",")).apply()
    }

    fun loadSpeed(): Float = prefs.getFloat(KEY_SPEED, 1f)
    fun saveSpeed(v: Float) = prefs.edit().putFloat(KEY_SPEED, v).apply()

    fun loadCrossfade(): Boolean = prefs.getBoolean(KEY_CROSSFADE, false)
    fun saveCrossfade(on: Boolean) = prefs.edit().putBoolean(KEY_CROSSFADE, on).apply()

    fun loadVinylMode(): Boolean = prefs.getBoolean(KEY_VINYL, false)
    fun saveVinylMode(on: Boolean) = prefs.edit().putBoolean(KEY_VINYL, on).apply()

    fun loadGapless(): Boolean = prefs.getBoolean(KEY_GAPLESS, true)
    fun saveGapless(on: Boolean) = prefs.edit().putBoolean(KEY_GAPLESS, on).apply()

    fun loadSkipSilence(): Boolean = prefs.getBoolean(KEY_SKIP_SILENCE, false)
    fun saveSkipSilence(on: Boolean) = prefs.edit().putBoolean(KEY_SKIP_SILENCE, on).apply()

    // ---- Sorting ----
    fun loadSortMode(): String = prefs.getString(KEY_SORT_MODE, "DATE_ADDED") ?: "DATE_ADDED"
    fun loadSortAsc(): Boolean = prefs.getBoolean(KEY_SORT_ASC, false)
    fun saveSort(mode: String, asc: Boolean) {
        prefs.edit().putString(KEY_SORT_MODE, mode).putBoolean(KEY_SORT_ASC, asc).apply()
    }

    // ---- Notification ----
    fun loadNotifVideoFrames(): Int = prefs.getInt(KEY_NOTIF_VIDEO_FRAMES, 0)
    fun saveNotifVideoFrames(n: Int) = prefs.edit().putInt(KEY_NOTIF_VIDEO_FRAMES, n).apply()

    fun loadNotifSoif(): Boolean = prefs.getBoolean(KEY_NOTIF_SOIF, false)
    fun saveNotifSoif(on: Boolean) = prefs.edit().putBoolean(KEY_NOTIF_SOIF, on).apply()

    fun loadNotifSoifStyled(): Boolean = prefs.getBoolean(KEY_NOTIF_SOIF_STYLED, false)
    fun saveNotifSoifStyled(on: Boolean) = prefs.edit().putBoolean(KEY_NOTIF_SOIF_STYLED, on).apply()

    // ---- Visuals ----
    fun loadParticles(): Boolean = prefs.getBoolean(KEY_PARTICLES, true)
    fun saveParticles(on: Boolean) = prefs.edit().putBoolean(KEY_PARTICLES, on).apply()

    fun loadReactiveViz(): Boolean = prefs.getBoolean(KEY_REACTIVE_VIZ, false)
    fun saveReactiveViz(on: Boolean) = prefs.edit().putBoolean(KEY_REACTIVE_VIZ, on).apply()

    fun loadWakeEnabled(): Boolean = prefs.getBoolean(KEY_WAKE_ON, false)
    fun saveWakeEnabled(on: Boolean) = prefs.edit().putBoolean(KEY_WAKE_ON, on).apply()
    fun loadWakeWord(): String = prefs.getString(KEY_WAKE_WORD, "phantom") ?: "phantom"
    fun saveWakeWord(word: String) = prefs.edit().putString(KEY_WAKE_WORD, word.trim().lowercase().ifBlank { "phantom" }).apply()
    fun loadWakeSilenceMs(): Int = prefs.getInt(KEY_WAKE_SILENCE, 2000)
    fun saveWakeSilenceMs(ms: Int) = prefs.edit().putInt(KEY_WAKE_SILENCE, ms.coerceIn(800, 5000)).apply()

    fun savePendingWakeCommand(text: String) =
        prefs.edit().putString(KEY_PENDING_WAKE, text.trim()).apply()

    fun consumePendingWakeCommand(): String? {
        val t = prefs.getString(KEY_PENDING_WAKE, null)?.trim()?.takeIf { it.isNotEmpty() }
        if (t != null) prefs.edit().remove(KEY_PENDING_WAKE).apply()
        return t
    }

    fun loadSnowOverlay(): Boolean = prefs.getBoolean(KEY_SNOW_OVERLAY, false)
    fun saveSnowOverlay(on: Boolean) = prefs.edit().putBoolean(KEY_SNOW_OVERLAY, on).apply()

    /** High-quality player / app background image from gallery (content URI string). */
    fun loadPlayerBackgroundUri(): String? = prefs.getString(KEY_PLAYER_BG, null)
    fun savePlayerBackgroundUri(uri: String?) {
        prefs.edit().apply {
            if (uri.isNullOrBlank()) remove(KEY_PLAYER_BG) else putString(KEY_PLAYER_BG, uri)
        }.apply()
    }

    companion object {
        const val PREFS_NAME = "texwave_settings"
        const val KEY_NOTIF_VIDEO_FRAMES = "notif_video_frames"
        const val KEY_NOTIF_SOIF = "notif_soif"
        const val KEY_NOTIF_SOIF_STYLED = "notif_soif_styled"
        const val KEY_SORT_MODE = "sort_mode"
        const val KEY_SORT_ASC = "sort_asc"
        const val KEY_PARTICLES = "particles"
        const val KEY_REACTIVE_VIZ = "reactive_viz"
        const val KEY_WAKE_ON = "wake_on"
        const val KEY_WAKE_WORD = "wake_word"
        const val KEY_WAKE_SILENCE = "wake_silence_ms"
        const val KEY_PENDING_WAKE = "pending_wake_cmd"
        const val KEY_SNOW_OVERLAY = "snow_overlay"
        const val KEY_PLAYER_BG = "player_background_uri"

        const val KEY_THEME = "theme_id"
        const val KEY_CUSTOM_ART = "custom_art"
        const val KEY_NOTIF_STYLE = "notif_style"
        const val KEY_NOTIF_URI = "notif_uri"
        const val KEY_EQ_ON = "eq_on"
        const val KEY_EQ_PRESET = "eq_preset"
        const val KEY_EQ_BANDS = "eq_bands"
        const val KEY_SPEED = "speed"
        const val KEY_CROSSFADE = "crossfade"
        const val KEY_VINYL = "vinyl"
        const val KEY_GAPLESS = "gapless"
        const val KEY_SKIP_SILENCE = "skip_silence"
    }
}

data class AppTheme(
    val id: String,
    val name: String,
    val description: String,
    val primary: Long,
    val secondary: Long,
    val background: Long,
    val surface: Long,
    val isRemote: Boolean = false,
)

object ThemeCatalog {
    val all: List<AppTheme> = listOf(
        AppTheme("default", "Texwave", "Obsidian violet → electric cyan", 0xFFA37CFF, 0xFF2FE6FF, 0xFF010105, 0xFF08060F),
        AppTheme("midnight", "Midnight", "Deep blue night sky", 0xFF4A90E2, 0xFF7B68EE, 0xFF010105, 0xFF08060F),
        AppTheme("ember", "Ember", "Warm orange & crimson", 0xFFFF6B35, 0xFFE63946, 0xFF050403, 0xFF0F0A09),
        AppTheme("forest", "Forest", "Fresh green nature", 0xFF2ECC71, 0xFF27AE60, 0xFF040805, 0xFF090F0C),
        AppTheme("rose", "Rose Gold", "Soft pink & gold", 0xFFE91E63, 0xFFFFB74D, 0xFF080407, 0xFF100A0E),
        AppTheme("ocean", "Ocean", "Cyan deep sea", 0xFF00BCD4, 0xFF0288D1, 0xFF02070A, 0xFF070F15),
        AppTheme("mono", "Mono", "Clean black & white", 0xFFE0E0E0, 0xFF9E9E9E, 0xFF000000, 0xFF0A0A0A),
        AppTheme("amoled", "AMOLED Black", "Pure black battery saver", 0xFFBB86FC, 0xFF03DAC6, 0xFF000000, 0xFF060606, isRemote = true),
        AppTheme("neon", "Neon Pulse", "Electric magenta & lime", 0xFFFF00FF, 0xFF39FF14, 0xFF040007, 0xFF0C0010, isRemote = true),
        AppTheme("aurora", "Aurora", "Northern lights blend", 0xFF00FFA3, 0xFF7B2FFF, 0xFF020307, 0xFF070913, isRemote = true),
        AppTheme("sunset", "Sunset Drive", "Golden hour gradient", 0xFFFF8A65, 0xFFFF5252, 0xFF070303, 0xFF0F0909, isRemote = true),
        AppTheme("cyber", "Cyberpunk", "Neon city nights", 0xFF00F0FF, 0xFFFF00A0, 0xFF020207, 0xFF06060F, isRemote = true),
        AppTheme("lavender", "Lavender Dream", "Soft purple haze", 0xFFB388FF, 0xFFEA80FC, 0xFF050408, 0xFF0D0A12, isRemote = true),
    )

    fun byId(id: String): AppTheme = all.find { it.id == id } ?: all.first()
}

data class NotifStyle(
    val id: String,
    val name: String,
    val description: String,
    val previewSeed: String,
    val isAnimated: Boolean = false,
)

object NotifCatalog {
    val all: List<NotifStyle> = listOf(
        NotifStyle("default", "Classic", "Clean album art", "default"),
        NotifStyle("wave", "Sound Wave", "Dancing bars rise over the cover", "wave", isAnimated = true),
        NotifStyle("pulse", "Pulse Glow", "A soft accent glow that breathes", "pulse", isAnimated = true),
        NotifStyle("vinyl", "Vinyl Spin", "A spinning record with your cover as the label", "vinyl", isAnimated = true),
        NotifStyle("particles", "Snow", "Soft white snowflakes falling", "particles", isAnimated = true),
        NotifStyle("lyrics", "Lyrics Rise", "Lines fade in from the bottom and drift upward", "lyrics", isAnimated = true),
        NotifStyle("spectrum", "Spectrum", "Mirrored frequency bars", "spectrum", isAnimated = true),
        NotifStyle("galaxy", "Galaxy", "Twinkling stars and a turning spiral", "galaxy", isAnimated = true),
        NotifStyle("liquid", "Liquid Metal", "Flowing metallic shimmer", "liquid", isAnimated = true),
        NotifStyle("neon_grid", "Neon Grid", "Retro grid with a scan line", "neon_grid", isAnimated = true),
        NotifStyle("video", "Your Video", "Plays frames from a video you pick", "video", isAnimated = true),
        NotifStyle("custom", "Your Image", "One image of your choice", "custom"),
    )

    fun byId(id: String): NotifStyle = all.find { it.id == id } ?: all.first()
}
