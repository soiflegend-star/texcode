package com.texgen.music.texwave.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.util.Log
import com.texgen.music.texwave.data.AppSettings

/**
 * Wraps Android's Equalizer audio effect attached to the ExoPlayer audio session.
 * Safe to call from any thread; internal state is guarded.
 */
class EqualizerController(private val settings: AppSettings) {
    private var equalizer: Equalizer? = null
    private var sessionId: Int = 0
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var loud: LoudnessEnhancer? = null

    /** Re-attaches to the live player session whenever effects are missing (e.g. the screen opened before playback). */
    fun ensureAttached() {
        val sid = PlaybackService.audioSessionId
        if (sid != 0 && (equalizer == null || sid != sessionId)) attach(sid)
    }

    val hasEffects: Boolean get() = equalizer != null

    fun bassStrength(): Int = settings.getInt("eq_bass", 0)
    fun virtStrength(): Int = settings.getInt("eq_virt", 0)
    fun loudGain(): Int = settings.getInt("eq_loud", 0)

    fun setBass(v: Int) {
        settings.putInt("eq_bass", v)
        runCatching { bass?.setStrength(v.toShort()); bass?.enabled = v > 0 && isEnabled() }
    }
    fun setVirtualizer(v: Int) {
        settings.putInt("eq_virt", v)
        runCatching { virt?.setStrength(v.toShort()); virt?.enabled = v > 0 && isEnabled() }
    }
    fun setLoudness(mb: Int) {
        settings.putInt("eq_loud", mb)
        runCatching { loud?.setTargetGain(mb); loud?.enabled = mb > 0 && isEnabled() }
    }

    private fun attachExtras(session: Int) {
        runCatching { bass?.release() }; runCatching { virt?.release() }; runCatching { loud?.release() }
        bass = runCatching { BassBoost(0, session) }.getOrNull()
        virt = runCatching { Virtualizer(0, session) }.getOrNull()
        loud = runCatching { LoudnessEnhancer(session) }.getOrNull()
        val on = settings.loadEqEnabled()
        runCatching { bass?.setStrength(bassStrength().toShort()); bass?.enabled = on && bassStrength() > 0 }
        runCatching { virt?.setStrength(virtStrength().toShort()); virt?.enabled = on && virtStrength() > 0 }
        runCatching { loud?.setTargetGain(loudGain()); loud?.enabled = on && loudGain() > 0 }
    }

    val bandCount: Int get() = equalizer?.numberOfBands?.toInt() ?: 5
    val bandLevelRange: ShortArray get() = equalizer?.bandLevelRange ?: shortArrayOf(-1500, 1500)

    fun attach(audioSessionId: Int) {
        if (audioSessionId == 0 || audioSessionId == sessionId) return
        release()
        sessionId = audioSessionId
        try {
            equalizer = Equalizer(0, audioSessionId).apply {
                enabled = settings.loadEqEnabled()
                val bands = settings.loadEqBands()
                val n = numberOfBands.toInt().coerceAtMost(bands.size)
                for (i in 0 until n) {
                    setBandLevel(i.toShort(), bands[i].toShort())
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Equalizer unavailable: ${e.message}")
            equalizer = null
        }
        attachExtras(audioSessionId)
    }

    fun setEnabled(on: Boolean) {
        settings.saveEqEnabled(on)
        try {
            equalizer?.enabled = on
        } catch (_: Exception) { }
        runCatching { bass?.enabled = on && bassStrength() > 0 }
        runCatching { virt?.enabled = on && virtStrength() > 0 }
        runCatching { loud?.enabled = on && loudGain() > 0 }
    }

    fun isEnabled(): Boolean = try {
        equalizer?.enabled == true
    } catch (_: Exception) {
        settings.loadEqEnabled()
    }

    fun getBandLevel(band: Int): Int = try {
        equalizer?.getBandLevel(band.toShort())?.toInt() ?: 0
    } catch (_: Exception) {
        settings.loadEqBands().getOrElse(band) { 0 }
    }

    fun setBandLevel(band: Int, levelMillibels: Int) {
        try {
            equalizer?.setBandLevel(band.toShort(), levelMillibels.toShort())
        } catch (_: Exception) { }
        val bands = settings.loadEqBands().copyOf(bandCount.coerceAtLeast(5))
        if (band in bands.indices) bands[band] = levelMillibels
        settings.saveEqBands(bands)
    }

    fun getCenterFreq(band: Int): Int = try {
        (equalizer?.getCenterFreq(band.toShort()) ?: 0) / 1000  // Hz
    } catch (_: Exception) {
        when (band) {
            0 -> 60; 1 -> 230; 2 -> 910; 3 -> 3600; else -> 14000
        }
    }

    fun applyPreset(index: Int) {
        settings.saveEqPreset(index)
        val base = PRESETS.getOrNull(index) ?: return
        val n = bandCount
        for (i in 0 until n) {
            // stretch the 5-point curve across however many bands this device exposes
            val pos = if (n == 1) 0f else i * (base.size - 1) / (n - 1).toFloat()
            val lo = pos.toInt().coerceIn(0, base.size - 1)
            val hi = (lo + 1).coerceAtMost(base.size - 1)
            val v = base[lo] + ((base[hi] - base[lo]) * (pos - lo)).toInt()
            val r = bandLevelRange
            setBandLevel(i, v.coerceIn(r[0].toInt(), r[1].toInt()))
        }
        setEnabled(true)
    }

    fun release() {
        try {
            equalizer?.release()
        } catch (_: Exception) { }
        runCatching { bass?.release() }; runCatching { virt?.release() }; runCatching { loud?.release() }
        bass = null; virt = null; loud = null
        equalizer = null
        sessionId = 0
    }

    companion object {
        private const val TAG = "EqController"

        val PRESET_NAMES = listOf(
            "Flat", "Bass Boost", "Treble Boost", "Vocal", "Rock", "Electronic", "Classical",
            "Pop", "Hip-Hop", "Jazz", "Dance", "Acoustic", "Late Night"
        )

        /** 5-band levels in millibels */
        private val PRESETS = listOf(
            intArrayOf(0, 0, 0, 0, 0),
            intArrayOf(800, 400, 0, 0, 0),
            intArrayOf(0, 0, 0, 400, 800),
            intArrayOf(-200, 200, 600, 400, 0),
            intArrayOf(500, 300, -100, 200, 400),
            intArrayOf(600, 200, -200, 300, 600),
            intArrayOf(0, 200, 0, 200, 0),
            intArrayOf(-100, 300, 500, 300, -100),
            intArrayOf(700, 500, 0, 200, 300),
            intArrayOf(400, 200, -200, 200, 500),
            intArrayOf(600, 0, 200, 400, 300),
            intArrayOf(400, 100, 200, 300, 300),
            intArrayOf(500, 200, -300, 100, -200),
        )
    }
}
